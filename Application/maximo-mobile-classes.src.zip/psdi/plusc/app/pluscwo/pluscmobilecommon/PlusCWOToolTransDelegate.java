/*   1:    */ package psdi.plusc.app.pluscwo.pluscmobilecommon;
/*   2:    */ 
/*   3:    */ import com.ibm.tivoli.maximo.util.mboadapter.MboAdapter;
/*   4:    */ import com.ibm.tivoli.maximo.util.mboadapter.MboSetAdapter;
/*   5:    */ import java.util.Date;
/*   6:    */ 
/*   7:    */ public abstract class PlusCWOToolTransDelegate
/*   8:    */ {
/*   9:    */   protected MboAdapter thisMbo;
/*  10:    */   
/*  11:    */   public PlusCWOToolTransDelegate(MboAdapter mbo)
/*  12:    */   {
/*  13: 35 */     this.thisMbo = mbo;
/*  14:    */   }
/*  15:    */   
/*  16:    */   public abstract MboSetAdapter getToolItemSet()
/*  17:    */     throws Exception;
/*  18:    */   
/*  19:    */   public abstract MboSetAdapter getAssetSet()
/*  20:    */     throws Exception;
/*  21:    */   
/*  22:    */   public void validateBufferSolution()
/*  23:    */     throws Exception
/*  24:    */   {
/*  25: 47 */     boolean toolIsSolution = false;
/*  26: 49 */     if (!this.thisMbo.isNull("ITEMNUM"))
/*  27:    */     {
/*  28: 52 */       MboSetAdapter toolItemSet = getToolItemSet();
/*  29: 54 */       if ((toolItemSet != null) && (!toolItemSet.isEmpty())) {
/*  30: 55 */         toolIsSolution = toolItemSet.getMbo(0).getBoolean("PLUSCSOLUTION");
/*  31:    */       }
/*  32:    */     }
/*  33: 61 */     boolean assetIsSolution = false;
/*  34: 62 */     if (!this.thisMbo.isNull("ASSETNUM"))
/*  35:    */     {
/*  36: 65 */       MboSetAdapter assetSet = getAssetSet();
/*  37: 67 */       if ((assetSet != null) && (!assetSet.isEmpty())) {
/*  38: 68 */         assetIsSolution = assetSet.getMbo(0).getBoolean("PLUSCSOLUTION");
/*  39:    */       }
/*  40:    */     }
/*  41: 72 */     if ((toolIsSolution) || (assetIsSolution)) {
/*  42: 74 */       if ((this.thisMbo.isNull("PLUSCTYPE")) || (this.thisMbo.isNull("PLUSCMANUFACTURER")) || (this.thisMbo.isNull("PLUSCLOTNUM")) || (this.thisMbo.isNull("PLUSCEXPIRYDATE")))
/*  43:    */       {
/*  44: 77 */         Object[] errParams = { this.thisMbo.getString("ITEMNUM") };
/*  45: 78 */         throw this.thisMbo.newApplicationException("pluscwt", "BufferSolutionFieldsNotFilled", errParams);
/*  46:    */       }
/*  47:    */     }
/*  48:    */   }
/*  49:    */   
/*  50:    */   public void validateDates()
/*  51:    */     throws Exception
/*  52:    */   {
/*  53: 90 */     Date expiryDate = this.thisMbo.getDate("PLUSCEXPIRYDATE");
/*  54: 93 */     if (expiryDate != null)
/*  55:    */     {
/*  56: 94 */       Date enterDate = null;
/*  57: 95 */       if (!this.thisMbo.isNull("ENTERDATE"))
/*  58:    */       {
/*  59: 96 */         enterDate = this.thisMbo.getDate("ENTERDATE");
/*  60: 98 */         if (expiryDate.before(enterDate)) {
/*  61: 99 */           throw this.thisMbo.newApplicationException("pluscwt", "ExpiryDateEnterDate");
/*  62:    */         }
/*  63:    */       }
/*  64:103 */       Date useDate = null;
/*  65:104 */       if (!this.thisMbo.isNull("PLUSCTOOLUSEDATE"))
/*  66:    */       {
/*  67:105 */         useDate = this.thisMbo.getDate("PLUSCTOOLUSEDATE");
/*  68:107 */         if (expiryDate.before(useDate)) {
/*  69:108 */           throw this.thisMbo.newApplicationException("pluscwt", "ExpiryDateToolUseDate");
/*  70:    */         }
/*  71:    */       }
/*  72:    */     }
/*  73:    */   }
/*  74:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     psdi.plusc.app.pluscwo.pluscmobilecommon.PlusCWOToolTransDelegate
 * JD-Core Version:    0.7.0.1
 */