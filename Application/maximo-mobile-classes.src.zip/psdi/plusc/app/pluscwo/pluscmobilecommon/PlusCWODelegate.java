/*  1:   */ package psdi.plusc.app.pluscwo.pluscmobilecommon;
/*  2:   */ 
/*  3:   */ import com.ibm.tivoli.maximo.util.mboadapter.MboAdapter;
/*  4:   */ import com.ibm.tivoli.maximo.util.mboadapter.MboSetAdapter;
/*  5:   */ import psdi.plusc.app.pluscds.pluscmobilecommon.PlusCWODsDelegate;
/*  6:   */ 
/*  7:   */ public abstract class PlusCWODelegate
/*  8:   */ {
/*  9:   */   protected MboAdapter thisMbo;
/* 10:   */   
/* 11:   */   public PlusCWODelegate(MboAdapter mbo)
/* 12:   */   {
/* 13:35 */     this.thisMbo = mbo;
/* 14:   */   }
/* 15:   */   
/* 16:   */   protected abstract MboSetAdapter getWOLocationSet()
/* 17:   */     throws Exception;
/* 18:   */   
/* 19:   */   public abstract MboSetAdapter getWOToolTransSet()
/* 20:   */     throws Exception;
/* 21:   */   
/* 22:   */   protected abstract MboSetAdapter getWODsSet()
/* 23:   */     throws Exception;
/* 24:   */   
/* 25:   */   protected abstract PlusCWODsDelegate getWoDsDelegate(MboAdapter paramMboAdapter);
/* 26:   */   
/* 27:   */   public void copyLoopFlagFromLocation()
/* 28:   */     throws Exception
/* 29:   */   {
/* 30:48 */     MboSetAdapter locationSet = getWOLocationSet();
/* 31:50 */     if (!locationSet.isEmpty())
/* 32:   */     {
/* 33:51 */       MboAdapter location = locationSet.getMbo(0);
/* 34:52 */       this.thisMbo.setValue("PLUSCLOOP", location.getBoolean("PLUSCLOOP"));
/* 35:   */     }
/* 36:   */   }
/* 37:   */   
/* 38:   */   public boolean isChangeOK(String currentStatus, String desiredStatus)
/* 39:   */     throws Exception
/* 40:   */   {
/* 41:65 */     if ((desiredStatus.equals("COMP")) || (desiredStatus.equals("CLOSE")))
/* 42:   */     {
/* 43:67 */       MboSetAdapter wodsDataBean = getWODsSet();
/* 44:   */       
/* 45:69 */       int i = 0;
/* 46:   */       MboAdapter wodsMbo;
/* 47:71 */       while ((wodsMbo = wodsDataBean.getMbo(i++)) != null)
/* 48:   */       {
/* 49:73 */         PlusCWODsDelegate woDs = getWoDsDelegate(wodsMbo);
/* 50:75 */         if (!woDs.isAllEntered()) {
/* 51:76 */           return false;
/* 52:   */         }
/* 53:   */       }
/* 54:   */     }
/* 55:81 */     return true;
/* 56:   */   }
/* 57:   */   
/* 58:   */   public boolean hasAssociatedTool()
/* 59:   */     throws Exception
/* 60:   */   {
/* 61:85 */     return !getWOToolTransSet().isEmpty();
/* 62:   */   }
/* 63:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     psdi.plusc.app.pluscwo.pluscmobilecommon.PlusCWODelegate
 * JD-Core Version:    0.7.0.1
 */