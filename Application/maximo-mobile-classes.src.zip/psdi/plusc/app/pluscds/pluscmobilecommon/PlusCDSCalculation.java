/*    1:     */ package psdi.plusc.app.pluscds.pluscmobilecommon;
/*    2:     */ 
/*    3:     */ import java.text.DecimalFormatSymbols;
/*    4:     */ import java.util.HashMap;
/*    5:     */ import java.util.Locale;
/*    6:     */ 
/*    7:     */ public class PlusCDSCalculation
/*    8:     */ {
/*    9:  39 */   public static int MAXFRACTION = 10;
/*   10:     */   public static final int INPUT_FROM = 0;
/*   11:     */   public static final int INPUT_TO = 1;
/*   12:     */   public static final int OUTPUT_FROM = 2;
/*   13:     */   public static final int OUTPUT_TO = 3;
/*   14:     */   public static final int DEVIATION_N = 1;
/*   15:     */   public static final int DEVIATION_N_MINUS_1 = 2;
/*   16:     */   private static final long NOACCESSCHECK = 2L;
/*   17:  64 */   private HashMap dsconfig = new HashMap();
/*   18:     */   
/*   19:     */   public PlusCDSCalculation(HashMap dsConfig)
/*   20:     */   {
/*   21:  73 */     this.dsconfig = dsConfig;
/*   22:     */   }
/*   23:     */   
/*   24:     */   public int getTolPrecision(int minOutputPrecision, int actualOutputPrecision, int actualInputPrecision)
/*   25:     */   {
/*   26:  87 */     int rightPrecision = 0;
/*   27:  89 */     switch (getTolError())
/*   28:     */     {
/*   29:     */     case 1: 
/*   30:  92 */       rightPrecision = minOutputPrecision + getTolNPlaces();
/*   31:  93 */       break;
/*   32:     */     case 2: 
/*   33:  95 */       rightPrecision = actualInputPrecision > actualOutputPrecision ? actualInputPrecision : actualOutputPrecision + 1;
/*   34:  96 */       break;
/*   35:     */     default: 
/*   36:  98 */       rightPrecision = minOutputPrecision;
/*   37:     */     }
/*   38: 102 */     return rightPrecision;
/*   39:     */   }
/*   40:     */   
/*   41:     */   public int getAssetPrecision(int minOutputPrecision, int actualOutputPrecision, int actualInputPrecision)
/*   42:     */   {
/*   43: 117 */     int rightPrecision = 0;
/*   44: 119 */     switch (getAssetError())
/*   45:     */     {
/*   46:     */     case 1: 
/*   47: 122 */       rightPrecision = minOutputPrecision + getAssetNPlaces();
/*   48: 123 */       break;
/*   49:     */     case 2: 
/*   50: 125 */       rightPrecision = actualInputPrecision > actualOutputPrecision ? actualInputPrecision : actualOutputPrecision;
/*   51: 126 */       break;
/*   52:     */     default: 
/*   53: 128 */       rightPrecision = minOutputPrecision;
/*   54:     */     }
/*   55: 132 */     return rightPrecision;
/*   56:     */   }
/*   57:     */   
/*   58:     */   public int getTolError()
/*   59:     */   {
/*   60: 144 */     int tolError = 1;
/*   61:     */     
/*   62: 146 */     tolError = Integer.parseInt((String)this.dsconfig.get("TOLERROR"));
/*   63:     */     
/*   64: 148 */     return tolError;
/*   65:     */   }
/*   66:     */   
/*   67:     */   public int getAssetError()
/*   68:     */   {
/*   69: 160 */     int assetError = 1;
/*   70:     */     
/*   71: 162 */     assetError = Integer.parseInt((String)this.dsconfig.get("ASSETERROR"));
/*   72:     */     
/*   73: 164 */     return assetError;
/*   74:     */   }
/*   75:     */   
/*   76:     */   public int getTolNPlaces()
/*   77:     */   {
/*   78: 176 */     int tolNPlaces = 0;
/*   79:     */     
/*   80: 178 */     tolNPlaces = Integer.parseInt((String)this.dsconfig.get("TOLNPLACES"));
/*   81:     */     
/*   82: 180 */     return tolNPlaces;
/*   83:     */   }
/*   84:     */   
/*   85:     */   public int getAssetNPlaces()
/*   86:     */   {
/*   87: 192 */     int assetNPlaces = 0;
/*   88:     */     
/*   89: 194 */     assetNPlaces = Integer.parseInt((String)this.dsconfig.get("ASSETNPLACES"));
/*   90:     */     
/*   91: 196 */     return assetNPlaces;
/*   92:     */   }
/*   93:     */   
/*   94:     */   public boolean getTolTruncate()
/*   95:     */   {
/*   96: 208 */     boolean shouldTruncate = true;
/*   97:     */     
/*   98: 210 */     shouldTruncate = Integer.parseInt((String)this.dsconfig.get("TOLTRUNCATE")) == 1;
/*   99:     */     
/*  100: 212 */     return shouldTruncate;
/*  101:     */   }
/*  102:     */   
/*  103:     */   public boolean getAssetTruncate()
/*  104:     */   {
/*  105: 224 */     boolean shouldTruncate = true;
/*  106:     */     
/*  107: 226 */     shouldTruncate = Integer.parseInt((String)this.dsconfig.get("ASSETTRUNCATE")) == 1;
/*  108:     */     
/*  109: 228 */     return shouldTruncate;
/*  110:     */   }
/*  111:     */   
/*  112:     */   public boolean getDesiredOutputTruncate()
/*  113:     */   {
/*  114: 239 */     boolean shouldTruncate = true;
/*  115:     */     
/*  116: 241 */     shouldTruncate = Integer.parseInt((String)this.dsconfig.get("OUTPUTTRUNCATE")) == 1;
/*  117:     */     
/*  118: 243 */     return shouldTruncate;
/*  119:     */   }
/*  120:     */   
/*  121:     */   public int getStdDeviationType()
/*  122:     */   {
/*  123: 253 */     return Integer.parseInt((String)this.dsconfig.get("STDDEV"));
/*  124:     */   }
/*  125:     */   
/*  126:     */   protected int getPointTolPrecision(PlusCMboRemote point, String fieldPrefix)
/*  127:     */   {
/*  128: 266 */     int rightPrecision = 0;
/*  129: 267 */     String planType = point.getString("PLANTYPE");
/*  130: 269 */     if (planType.equalsIgnoreCase("ANALOG"))
/*  131:     */     {
/*  132: 271 */       int minOutputPrecision = point.getInt("OUTPUTPRECISION").intValue();
/*  133: 272 */       int actualInputPrecision = PlusCToolKitTOCommon.getDecimalDigits(fieldPrefix.equals("") ? point.getString("INPUTVALUE") : point.getString(fieldPrefix + "INPUT"));
/*  134:     */       
/*  135:     */ 
/*  136:     */ 
/*  137: 276 */       int actualOutputPrecision = PlusCToolKitTOCommon.getDecimalDigits(fieldPrefix.equals("") ? point.getString("OUTPUTVALUE") : point.getString(fieldPrefix + "OUTPUT"));
/*  138:     */       
/*  139:     */ 
/*  140:     */ 
/*  141: 280 */       rightPrecision = getTolPrecision(minOutputPrecision, actualOutputPrecision, actualInputPrecision);
/*  142:     */     }
/*  143: 282 */     else if (planType.equalsIgnoreCase("DISCRETE"))
/*  144:     */     {
/*  145: 286 */       int actualSetPointPrecision = PlusCToolKitTOCommon.getDecimalDigits(fieldPrefix.equals("") ? point.getString("SETPOINTVALUE") : point.getString(fieldPrefix + "SETPOINT"));
/*  146:     */       
/*  147:     */ 
/*  148:     */ 
/*  149:     */ 
/*  150: 291 */       rightPrecision = actualSetPointPrecision;
/*  151:     */     }
/*  152: 296 */     return rightPrecision;
/*  153:     */   }
/*  154:     */   
/*  155:     */   private boolean calculateTolerances(PlusCMboRemote owner, String fieldName)
/*  156:     */   {
/*  157: 313 */     String sPrefix = "";
/*  158: 314 */     String auxTolLower = "";
/*  159: 315 */     String auxTolUpper = "";
/*  160:     */     
/*  161:     */ 
/*  162: 318 */     boolean shouldRound = !getTolTruncate();
/*  163: 320 */     if ((fieldName.equalsIgnoreCase("ASFOUNDINPUT")) || (fieldName.equalsIgnoreCase("ASFOUNDSETPOINT"))) {
/*  164: 322 */       sPrefix = "asfound";
/*  165:     */     }
/*  166: 325 */     if ((fieldName.equalsIgnoreCase("ASLEFTINPUT")) || (fieldName.equalsIgnoreCase("ASLEFTSETPOINT"))) {
/*  167: 327 */       sPrefix = "asleft";
/*  168:     */     }
/*  169: 331 */     int rightPrecision = getPointTolPrecision(owner, sPrefix);
/*  170: 333 */     if (owner == null) {
/*  171: 334 */       return true;
/*  172:     */     }
/*  173: 337 */     String planType = owner.getString("plantype");
/*  174:     */     
/*  175:     */ 
/*  176: 340 */     double ISpanByOSpan = 0.0D;
/*  177: 341 */     double desiredOutputValue = 0.0D;
/*  178: 342 */     double setPointValue = 0.0D;
/*  179: 343 */     Locale locale = owner.getLocale();
/*  180:     */     
/*  181:     */ 
/*  182: 346 */     String tollowervalue = "";
/*  183: 347 */     String toluppervalue = "";
/*  184: 348 */     String sumEU = "";
/*  185: 349 */     String sumRead = "";
/*  186: 350 */     String sumSpan = "";
/*  187: 351 */     String sumURV = "";
/*  188:     */     
/*  189: 353 */     String toleranceLower = "0.0000000000000";
/*  190: 354 */     String toleranceUpper = "0.0000000000000";
/*  191: 356 */     if (((owner instanceof PlusCWODSPointTO)) && ((fieldName.equalsIgnoreCase("OUTPUTVALUE")) || (fieldName.equalsIgnoreCase("SETPOINTVALUE"))) && (!owner.getBoolean("NONLINEAR").booleanValue())) {
/*  192: 362 */       return true;
/*  193:     */     }
/*  194: 366 */     boolean isOutputRangeLimit = owner.getBoolean("outputrange").booleanValue();
/*  195: 370 */     for (int tol = 1; tol < 5; tol++)
/*  196:     */     {
/*  197: 372 */       String toltype = owner.getString("tol" + tol + "type");
/*  198: 373 */       if (toltype == null) {
/*  199: 374 */         toltype = "";
/*  200:     */       }
/*  201: 377 */       String sumDirection = owner.getString("tol" + tol + "SUMDIRECTION");
/*  202: 378 */       if (sumDirection == null) {
/*  203: 379 */         sumDirection = "";
/*  204:     */       }
/*  205: 383 */       if (((toltype.equals("")) || ((owner.isNull("TOL" + tol + "LOWERVALUE")) && (owner.isNull("TOL" + tol + "UPPERVALUE")))) && ((sumDirection.equals("")) || ((owner.isNull("TOL" + tol + "SUMEU")) && (owner.isNull("TOL" + tol + "SUMREAD")) && (owner.isNull("TOL" + tol + "SUMSPAN")) && (owner.isNull("TOL" + tol + "SUMURV")))))
/*  206:     */       {
/*  207: 397 */         if (!sPrefix.equalsIgnoreCase("")) {
/*  208: 398 */           clearToleranceFields(owner, sPrefix, tol);
/*  209:     */         }
/*  210:     */       }
/*  211:     */       else
/*  212:     */       {
/*  213:     */         String[] tolPrefixes;
/*  214:     */         String[] tolPrefixes;
/*  215: 403 */         if (((owner instanceof PlusCWODSPointTO)) && (sPrefix.equals("")) && (owner.getBoolean("NONLINEAR").booleanValue())) {
/*  216: 404 */           tolPrefixes = new String[] { "ASFOUND", "ASLEFT" };
/*  217:     */         } else {
/*  218: 406 */           tolPrefixes = new String[] { sPrefix };
/*  219:     */         }
/*  220: 409 */         for (int i = 0; i < tolPrefixes.length; i++)
/*  221:     */         {
/*  222: 411 */           owner.setValue(tolPrefixes[i] + "tol" + tol + "lower", "", 9L);
/*  223: 412 */           owner.setValue(tolPrefixes[i] + "tol" + tol + "upper", "", 9L);
/*  224:     */         }
/*  225: 418 */         String from = owner.getString("tol" + tol + "lowervalue");
/*  226: 419 */         String to = owner.getString("tol" + tol + "uppervalue");
/*  227: 420 */         tollowervalue = owner.getString("tol" + tol + "lowervalue");
/*  228: 422 */         if (tollowervalue == null) {
/*  229: 423 */           tollowervalue = "";
/*  230:     */         }
/*  231: 426 */         toluppervalue = owner.getString("tol" + tol + "uppervalue");
/*  232: 428 */         if (toluppervalue == null) {
/*  233: 429 */           toluppervalue = "";
/*  234:     */         }
/*  235: 435 */         boolean calcSummedRDG = false;
/*  236: 436 */         boolean calcSummedEU = false;
/*  237: 437 */         boolean calcSummedSpan = false;
/*  238: 438 */         boolean calcSummedURV = false;
/*  239:     */         
/*  240: 440 */         sumEU = owner.getString("tol" + tol + "sumeu");
/*  241: 441 */         if ((sumEU == null) || (sumEU.equals(""))) {
/*  242: 442 */           sumEU = "";
/*  243:     */         } else {
/*  244: 444 */           calcSummedEU = true;
/*  245:     */         }
/*  246: 447 */         sumRead = owner.getString("tol" + tol + "sumread");
/*  247: 449 */         if ((sumRead == null) || (sumRead.equals(""))) {
/*  248: 450 */           sumRead = "";
/*  249:     */         } else {
/*  250: 452 */           calcSummedRDG = true;
/*  251:     */         }
/*  252: 455 */         sumSpan = owner.getString("tol" + tol + "sumspan");
/*  253: 457 */         if ((sumSpan == null) || (sumSpan.equals(""))) {
/*  254: 458 */           sumSpan = "";
/*  255:     */         } else {
/*  256: 460 */           calcSummedSpan = true;
/*  257:     */         }
/*  258: 463 */         sumURV = owner.getString("tol" + tol + "sumurv");
/*  259: 465 */         if ((sumURV == null) || (sumURV.equals(""))) {
/*  260: 466 */           sumURV = "";
/*  261:     */         } else {
/*  262: 468 */           calcSummedURV = true;
/*  263:     */         }
/*  264: 473 */         if ((calcSummedEU) || (calcSummedRDG) || (calcSummedSpan) || (calcSummedURV))
/*  265:     */         {
/*  266: 479 */           boolean[] summedCalcTypes = { calcSummedEU, calcSummedRDG, calcSummedSpan, calcSummedURV };
/*  267:     */           
/*  268:     */ 
/*  269: 482 */           summedToleranceEquations(owner, fieldName, tol, summedCalcTypes);
/*  270:     */         }
/*  271:     */         else
/*  272:     */         {
/*  273: 486 */           double equationSpecificVariable = 0.0D;
/*  274:     */           
/*  275:     */ 
/*  276: 489 */           double inputFrom = 0.0D;
/*  277: 490 */           double inputTo = 0.0D;
/*  278: 491 */           double outputFrom = 0.0D;
/*  279: 492 */           double outputTo = 0.0D;
/*  280:     */           
/*  281: 494 */           double[] verification = directionCheck(owner, locale);
/*  282: 495 */           inputFrom = verification[0];
/*  283: 496 */           inputTo = verification[1];
/*  284: 497 */           outputFrom = verification[2];
/*  285: 498 */           outputTo = verification[3];
/*  286: 499 */           boolean checkRoundUp = owner.isRoundUpField();
/*  287:     */           
/*  288: 501 */           double instrInputSpan = inputTo - inputFrom;
/*  289: 502 */           double instrOutputSpan = outputTo - outputFrom;
/*  290: 503 */           ISpanByOSpan = instrOutputSpan / instrInputSpan;
/*  291: 509 */           if ((toltype.equals("EU")) || (!sumEU.equals("")))
/*  292:     */           {
/*  293: 514 */             if (!sPrefix.equals("")) {
/*  294: 515 */               desiredOutputValue = PlusCToolKitTOCommon.stringToDouble(doWOUpdateOutputValue(owner, sPrefix), locale);
/*  295: 526 */             } else if (owner.getBoolean("nonlinear").booleanValue()) {
/*  296: 527 */               desiredOutputValue = PlusCToolKitTOCommon.stringToDouble(owner.getString("OUTPUTVALUE_NP"), locale);
/*  297:     */             } else {
/*  298: 533 */               desiredOutputValue = PlusCToolKitTOCommon.stringToDouble(owner.getString("OUTPUTVALUE_ROUNDING"), locale);
/*  299:     */             }
/*  300: 541 */             if ((planType.equalsIgnoreCase("DISCRETE")) || (isOutputRangeLimit) || (fieldName.equalsIgnoreCase("SETPOINTVALUE")) || (fieldName.equalsIgnoreCase("ASFOUNDSETPOINT")) || (fieldName.equalsIgnoreCase("ASLEFTSETPOINT")))
/*  301:     */             {
/*  302: 546 */               if ((planType.equalsIgnoreCase("DISCRETE")) || (fieldName.equalsIgnoreCase("SETPOINTVALUE")) || (fieldName.equalsIgnoreCase("ASFOUNDSETPOINT")) || (fieldName.equalsIgnoreCase("ASLEFTSETPOINT")))
/*  303:     */               {
/*  304: 553 */                 setPointValue = PlusCToolKitTOCommon.stringToDouble(PlusCToolKitTOCommon.formatDouble(owner.getString("SETPOINTVALUE"), rightPrecision, locale, true), locale);
/*  305:     */                 
/*  306:     */ 
/*  307:     */ 
/*  308:     */ 
/*  309:     */ 
/*  310:     */ 
/*  311:     */ 
/*  312: 561 */                 toleranceLower = String.valueOf(setPointValue + PlusCToolKitTOCommon.getDouble(from, locale));
/*  313:     */                 
/*  314: 563 */                 toleranceUpper = String.valueOf(setPointValue + PlusCToolKitTOCommon.getDouble(to, locale));
/*  315:     */               }
/*  316:     */               else
/*  317:     */               {
/*  318: 566 */                 toleranceLower = String.valueOf(desiredOutputValue + PlusCToolKitTOCommon.getDouble(from, locale));
/*  319:     */                 
/*  320: 568 */                 toleranceUpper = String.valueOf(desiredOutputValue + PlusCToolKitTOCommon.getDouble(to, locale));
/*  321:     */               }
/*  322: 577 */               auxTolLower = PlusCToolKitTOCommon.formatDouble(String.valueOf(toleranceLower), 10, locale, true);
/*  323:     */               
/*  324:     */ 
/*  325: 580 */               auxTolUpper = PlusCToolKitTOCommon.formatDouble(String.valueOf(toleranceUpper), 10, locale, true);
/*  326:     */               
/*  327:     */ 
/*  328:     */ 
/*  329:     */ 
/*  330:     */ 
/*  331: 586 */               toleranceLower = PlusCToolKitTOCommon.formatDoubleMax(toleranceLower, rightPrecision, locale, checkRoundUp, shouldRound);
/*  332:     */               
/*  333:     */ 
/*  334: 589 */               toleranceUpper = PlusCToolKitTOCommon.formatDoubleMax(toleranceUpper, rightPrecision, locale, checkRoundUp, shouldRound);
/*  335:     */             }
/*  336:     */             else
/*  337:     */             {
/*  338: 594 */               if (!from.equalsIgnoreCase(""))
/*  339:     */               {
/*  340: 597 */                 double calcRangeDiff = PlusCToolKitTOCommon.stringToDouble(from, locale) * ISpanByOSpan;
/*  341:     */                 
/*  342: 599 */                 toleranceLower = String.valueOf(desiredOutputValue + calcRangeDiff);
/*  343:     */               }
/*  344:     */               else
/*  345:     */               {
/*  346: 603 */                 toleranceLower = "";
/*  347:     */               }
/*  348: 607 */               if (!to.equalsIgnoreCase(""))
/*  349:     */               {
/*  350: 611 */                 double calcRangeDiff = PlusCToolKitTOCommon.stringToDouble(to, locale) * ISpanByOSpan;
/*  351: 612 */                 toleranceUpper = String.valueOf(desiredOutputValue + calcRangeDiff);
/*  352:     */               }
/*  353:     */               else
/*  354:     */               {
/*  355: 616 */                 toleranceUpper = "";
/*  356:     */               }
/*  357:     */             }
/*  358:     */           }
/*  359: 623 */           else if (((toltype.equals("%READING")) || (!sumRead.equals(""))) && (planType.equalsIgnoreCase("DISCRETE")))
/*  360:     */           {
/*  361: 630 */             if (!sPrefix.equals(""))
/*  362:     */             {
/*  363: 631 */               desiredOutputValue = PlusCToolKitTOCommon.stringToDouble(doWOUpdateOutputValue(owner, sPrefix), locale);
/*  364:     */             }
/*  365:     */             else
/*  366:     */             {
/*  367: 642 */               double outputrounding = PlusCToolKitTOCommon.stringToDouble(owner.getString("OUTPUTVALUE_ROUNDING"), locale);
/*  368:     */               
/*  369:     */ 
/*  370:     */ 
/*  371: 646 */               double outputnp = PlusCToolKitTOCommon.stringToDouble(owner.getString("OUTPUTVALUE_NP"), locale);
/*  372:     */               
/*  373:     */ 
/*  374:     */ 
/*  375:     */ 
/*  376: 651 */               desiredOutputValue = owner.getBoolean("nonlinear").booleanValue() ? outputrounding : outputrounding != outputnp ? outputnp : outputrounding;
/*  377:     */             }
/*  378: 655 */             if ((planType.equalsIgnoreCase("DISCRETE")) || (isOutputRangeLimit) || (fieldName.equalsIgnoreCase("SETPOINTVALUE")) || (fieldName.equalsIgnoreCase("ASFOUNDSETPOINT")) || (fieldName.equalsIgnoreCase("ASLEFTSETPOINT")))
/*  379:     */             {
/*  380: 660 */               if ((planType.equalsIgnoreCase("DISCRETE")) || (fieldName.equalsIgnoreCase("SETPOINTVALUE")) || (fieldName.equalsIgnoreCase("ASFOUNDSETPOINT")) || (fieldName.equalsIgnoreCase("ASLEFTSETPOINT")))
/*  381:     */               {
/*  382: 668 */                 double readingEq = 0.0D;
/*  383: 669 */                 if (!sPrefix.equals("")) {
/*  384: 670 */                   readingEq = Math.abs(PlusCToolKitTOCommon.stringToDouble(owner.getString(sPrefix + "SETPOINT"), locale)) / 100.0D;
/*  385:     */                 } else {
/*  386: 674 */                   readingEq = Math.abs(PlusCToolKitTOCommon.stringToDouble(owner.getString("SETPOINTVALUE"), locale)) / 100.0D;
/*  387:     */                 }
/*  388: 682 */                 setPointValue = PlusCToolKitTOCommon.stringToDouble(PlusCToolKitTOCommon.formatDouble(owner.getString("SETPOINTVALUE"), rightPrecision, locale, true), locale);
/*  389:     */                 
/*  390:     */ 
/*  391:     */ 
/*  392:     */ 
/*  393:     */ 
/*  394:     */ 
/*  395:     */ 
/*  396: 690 */                 toleranceLower = String.valueOf(setPointValue + PlusCToolKitTOCommon.stringToDouble(from, locale) * readingEq);
/*  397:     */                 
/*  398: 692 */                 toleranceUpper = String.valueOf(setPointValue + PlusCToolKitTOCommon.stringToDouble(to, locale) * readingEq);
/*  399:     */               }
/*  400:     */               else
/*  401:     */               {
/*  402: 695 */                 toleranceLower = String.valueOf(desiredOutputValue + PlusCToolKitTOCommon.stringToDouble(from, locale));
/*  403:     */                 
/*  404: 697 */                 toleranceUpper = String.valueOf(desiredOutputValue + PlusCToolKitTOCommon.stringToDouble(to, locale));
/*  405:     */               }
/*  406: 706 */               auxTolLower = PlusCToolKitTOCommon.formatDouble(String.valueOf(toleranceLower), 10, locale, true);
/*  407:     */               
/*  408:     */ 
/*  409: 709 */               auxTolUpper = PlusCToolKitTOCommon.formatDouble(String.valueOf(toleranceUpper), 10, locale, true);
/*  410:     */               
/*  411:     */ 
/*  412:     */ 
/*  413:     */ 
/*  414:     */ 
/*  415: 715 */               toleranceLower = PlusCToolKitTOCommon.formatDoubleMax(toleranceLower, rightPrecision, locale, checkRoundUp, shouldRound);
/*  416:     */               
/*  417:     */ 
/*  418: 718 */               toleranceUpper = PlusCToolKitTOCommon.formatDoubleMax(toleranceUpper, rightPrecision, locale, checkRoundUp, shouldRound);
/*  419:     */             }
/*  420:     */           }
/*  421: 733 */           else if (!isOutputRangeLimit)
/*  422:     */           {
/*  423: 746 */             if (!sPrefix.equals("")) {
/*  424: 747 */               desiredOutputValue = PlusCToolKitTOCommon.stringToDouble(doWOUpdateOutputValue(owner, sPrefix), locale);
/*  425:     */             } else {
/*  426: 750 */               desiredOutputValue = PlusCToolKitTOCommon.stringToDouble(owner.getString("OUTPUTVALUE_ROUNDING"), locale);
/*  427:     */             }
/*  428: 755 */             if (((toltype.equals("%SPAN")) || (!sumSpan.equals(""))) && (planType.equalsIgnoreCase("ANALOG"))) {
/*  429: 757 */               equationSpecificVariable = inputTo - inputFrom;
/*  430: 758 */             } else if (((toltype.equals("%URV")) || (!sumURV.equals(""))) && (planType.equalsIgnoreCase("ANALOG"))) {
/*  431: 761 */               equationSpecificVariable = Math.abs(inputTo);
/*  432: 762 */             } else if (((toltype.equals("%READING")) || (!sumRead.equals(""))) && (planType.equalsIgnoreCase("ANALOG"))) {
/*  433: 764 */               if (!sPrefix.equals("")) {
/*  434: 765 */                 equationSpecificVariable = Math.abs(PlusCToolKitTOCommon.stringToDouble(owner.getString(sPrefix + "INPUT"), locale));
/*  435:     */               } else {
/*  436: 769 */                 equationSpecificVariable = Math.abs(PlusCToolKitTOCommon.stringToDouble(owner.getString("INPUTVALUE"), locale));
/*  437:     */               }
/*  438:     */             }
/*  439: 777 */             toleranceLower = String.valueOf(desiredOutputValue + PlusCToolKitTOCommon.stringToDouble(PlusCToolKitTOCommon.formatDouble(from, locale), locale) * (equationSpecificVariable / 100.0D) * ISpanByOSpan);
/*  440:     */             
/*  441:     */ 
/*  442:     */ 
/*  443:     */ 
/*  444:     */ 
/*  445: 783 */             toleranceUpper = String.valueOf(desiredOutputValue + PlusCToolKitTOCommon.stringToDouble(PlusCToolKitTOCommon.formatDouble(to, locale), locale) * (equationSpecificVariable / 100.0D * ISpanByOSpan));
/*  446:     */           }
/*  447:     */           else
/*  448:     */           {
/*  449: 798 */             if (owner.getBoolean("NONLINEAR").booleanValue()) {
/*  450: 799 */               desiredOutputValue = PlusCToolKitTOCommon.stringToDouble(owner.getString("OUTPUTVALUE_NP"), locale);
/*  451: 804 */             } else if (!sPrefix.equals("")) {
/*  452: 805 */               desiredOutputValue = PlusCToolKitTOCommon.stringToDouble(doWOUpdateOutputValue(owner, sPrefix), locale);
/*  453:     */             } else {
/*  454: 809 */               desiredOutputValue = PlusCToolKitTOCommon.stringToDouble(owner.getString("OUTPUTVALUE_ROUNDING"), locale);
/*  455:     */             }
/*  456: 816 */             if (((toltype.equals("%SPAN")) || (!sumSpan.equals(""))) && (planType.equalsIgnoreCase("ANALOG"))) {
/*  457: 818 */               equationSpecificVariable = outputTo - outputFrom;
/*  458: 819 */             } else if (((toltype.equals("%URV")) || (!sumURV.equals(""))) && (planType.equalsIgnoreCase("ANALOG"))) {
/*  459: 821 */               equationSpecificVariable = Math.abs(outputTo);
/*  460: 822 */             } else if (((toltype.equals("%READING")) || (!sumRead.equals(""))) && (planType.equalsIgnoreCase("ANALOG"))) {
/*  461: 824 */               if (!sPrefix.equals("")) {
/*  462: 826 */                 equationSpecificVariable = desiredOutputValue;
/*  463:     */               } else {
/*  464: 831 */                 equationSpecificVariable = Math.abs(PlusCToolKitTOCommon.stringToDouble(owner.getString("OUTPUTVALUE_ROUNDING"), locale));
/*  465:     */               }
/*  466:     */             }
/*  467: 841 */             toleranceLower = String.valueOf(desiredOutputValue + PlusCToolKitTOCommon.stringToDouble(PlusCToolKitTOCommon.formatDouble(from, rightPrecision, locale, shouldRound), locale) * (equationSpecificVariable / 100.0D));
/*  468:     */             
/*  469:     */ 
/*  470:     */ 
/*  471:     */ 
/*  472:     */ 
/*  473:     */ 
/*  474: 848 */             toleranceUpper = String.valueOf(desiredOutputValue + PlusCToolKitTOCommon.stringToDouble(PlusCToolKitTOCommon.formatDouble(to, rightPrecision, locale, shouldRound), locale) * (equationSpecificVariable / 100.0D));
/*  475:     */           }
/*  476: 858 */           if (!sPrefix.equals(""))
/*  477:     */           {
/*  478: 859 */             toleranceLower = String.valueOf(addGuardBand(owner, PlusCToolKitTOCommon.stringToDouble(toleranceLower, locale), tol, "from", isOutputRangeLimit, ISpanByOSpan, locale));
/*  479:     */             
/*  480:     */ 
/*  481:     */ 
/*  482: 863 */             toleranceUpper = String.valueOf(addGuardBand(owner, PlusCToolKitTOCommon.stringToDouble(toleranceUpper, locale), tol, "to", isOutputRangeLimit, ISpanByOSpan, locale));
/*  483:     */           }
/*  484: 874 */           auxTolLower = PlusCToolKitTOCommon.formatDouble(String.valueOf(toleranceLower), 10, locale, true);
/*  485:     */           
/*  486:     */ 
/*  487: 877 */           auxTolUpper = PlusCToolKitTOCommon.formatDouble(String.valueOf(toleranceUpper), 10, locale, true);
/*  488:     */           
/*  489:     */ 
/*  490:     */ 
/*  491:     */ 
/*  492: 882 */           boolean bTrimTolerances = owner.getBoolean("CLIPLIMITS").booleanValue();
/*  493: 884 */           if (bTrimTolerances)
/*  494:     */           {
/*  495: 885 */             double dToleranceLower = Math.min(Math.max(Double.valueOf(toleranceLower).doubleValue(), outputFrom), outputTo);
/*  496:     */             
/*  497:     */ 
/*  498: 888 */             double dToleranceUpper = Math.max(Math.min(Double.valueOf(toleranceUpper).doubleValue(), outputTo), outputFrom);
/*  499:     */             
/*  500:     */ 
/*  501:     */ 
/*  502:     */ 
/*  503:     */ 
/*  504:     */ 
/*  505:     */ 
/*  506:     */ 
/*  507: 897 */             auxTolLower = PlusCToolKitTOCommon.formatDouble(String.valueOf(dToleranceLower), 10, locale, true);
/*  508:     */             
/*  509: 899 */             auxTolUpper = PlusCToolKitTOCommon.formatDouble(String.valueOf(dToleranceUpper), 10, locale, true);
/*  510:     */             
/*  511:     */ 
/*  512:     */ 
/*  513:     */ 
/*  514: 904 */             toleranceLower = PlusCToolKitTOCommon.formatDouble(String.valueOf(dToleranceLower), rightPrecision, locale, shouldRound);
/*  515:     */             
/*  516:     */ 
/*  517: 907 */             toleranceUpper = PlusCToolKitTOCommon.formatDouble(String.valueOf(dToleranceUpper), rightPrecision, locale, shouldRound);
/*  518:     */           }
/*  519: 915 */           toleranceLower = PlusCToolKitTOCommon.formatDouble(String.valueOf(toleranceLower), rightPrecision, locale, shouldRound);
/*  520: 916 */           toleranceUpper = PlusCToolKitTOCommon.formatDouble(String.valueOf(toleranceUpper), rightPrecision, locale, shouldRound);
/*  521:     */           
/*  522: 918 */           DecimalFormatSymbols df = new DecimalFormatSymbols(locale);
/*  523:     */           
/*  524: 920 */           String decimalSeparator = String.valueOf(df.getDecimalSeparator());
/*  525: 921 */           String[] splitDecimals = PlusCToolKitTOCommon.split(toleranceLower, decimalSeparator);
/*  526: 922 */           String[] splitDecimalsUpper = PlusCToolKitTOCommon.split(toleranceUpper, decimalSeparator);
/*  527: 923 */           boolean splitLower = splitDecimals.length > 1;
/*  528: 924 */           boolean splitUpper = splitDecimalsUpper.length > 1;
/*  529: 926 */           if ((splitLower) || (splitUpper))
/*  530:     */           {
/*  531: 927 */             if ((splitLower) && 
/*  532: 928 */               (splitDecimals[1].length() > rightPrecision))
/*  533:     */             {
/*  534: 932 */               toleranceLower = PlusCToolKitTOCommon.formatDoubleMax(toleranceLower, rightPrecision, locale, checkRoundUp, shouldRound);
/*  535:     */               
/*  536:     */ 
/*  537: 935 */               splitDecimals = PlusCToolKitTOCommon.split(toleranceLower, decimalSeparator);
/*  538: 936 */               if (splitDecimals.length > 1)
/*  539:     */               {
/*  540: 937 */                 if (splitDecimals[1].length() < rightPrecision)
/*  541:     */                 {
/*  542: 943 */                   auxTolLower = PlusCToolKitTOCommon.formatDouble(String.valueOf(toleranceLower), 10, locale, true);
/*  543:     */                   
/*  544:     */ 
/*  545:     */ 
/*  546:     */ 
/*  547:     */ 
/*  548: 949 */                   toleranceLower = PlusCToolKitTOCommon.formatDouble(String.valueOf(toleranceLower), rightPrecision, locale, shouldRound);
/*  549:     */                 }
/*  550:     */               }
/*  551:     */               else
/*  552:     */               {
/*  553: 958 */                 auxTolLower = PlusCToolKitTOCommon.formatDouble(String.valueOf(toleranceLower), 10, locale, true);
/*  554:     */                 
/*  555:     */ 
/*  556: 961 */                 auxTolUpper = PlusCToolKitTOCommon.formatDouble(String.valueOf(toleranceUpper), 10, locale, true);
/*  557:     */                 
/*  558:     */ 
/*  559:     */ 
/*  560:     */ 
/*  561:     */ 
/*  562: 967 */                 toleranceLower = PlusCToolKitTOCommon.formatDouble(String.valueOf(toleranceLower), rightPrecision, locale, shouldRound);
/*  563:     */                 
/*  564: 969 */                 toleranceUpper = PlusCToolKitTOCommon.formatDouble(String.valueOf(toleranceUpper), rightPrecision, locale, shouldRound);
/*  565:     */               }
/*  566:     */             }
/*  567: 975 */             splitDecimals = PlusCToolKitTOCommon.split(toleranceUpper, decimalSeparator);
/*  568: 977 */             if ((toleranceUpper.indexOf(decimalSeparator) != -1) && 
/*  569: 978 */               (splitDecimals[1].length() > rightPrecision))
/*  570:     */             {
/*  571: 982 */               toleranceUpper = PlusCToolKitTOCommon.formatDoubleMax(toleranceUpper, rightPrecision, locale, checkRoundUp, shouldRound);
/*  572: 983 */               splitDecimals = PlusCToolKitTOCommon.split(toleranceUpper, decimalSeparator);
/*  573: 984 */               if (splitDecimals.length > 1)
/*  574:     */               {
/*  575: 985 */                 if (splitDecimals[1].length() < rightPrecision)
/*  576:     */                 {
/*  577: 991 */                   auxTolUpper = PlusCToolKitTOCommon.formatDouble(String.valueOf(toleranceUpper), 10, locale, true);
/*  578:     */                   
/*  579:     */ 
/*  580:     */ 
/*  581:     */ 
/*  582:     */ 
/*  583: 997 */                   toleranceUpper = PlusCToolKitTOCommon.formatDouble(String.valueOf(toleranceUpper), rightPrecision, locale, shouldRound);
/*  584:     */                 }
/*  585:     */               }
/*  586:     */               else
/*  587:     */               {
/*  588:1006 */                 auxTolLower = PlusCToolKitTOCommon.formatDouble(String.valueOf(toleranceLower), 10, locale, true);
/*  589:     */                 
/*  590:     */ 
/*  591:1009 */                 auxTolUpper = PlusCToolKitTOCommon.formatDouble(String.valueOf(toleranceUpper), 10, locale, true);
/*  592:     */                 
/*  593:     */ 
/*  594:     */ 
/*  595:     */ 
/*  596:     */ 
/*  597:1015 */                 toleranceLower = PlusCToolKitTOCommon.formatDouble(String.valueOf(toleranceLower), rightPrecision, locale, shouldRound);
/*  598:     */                 
/*  599:     */ 
/*  600:1018 */                 toleranceUpper = PlusCToolKitTOCommon.formatDouble(String.valueOf(toleranceUpper), rightPrecision, locale, shouldRound);
/*  601:     */               }
/*  602:     */             }
/*  603:     */           }
/*  604:1029 */           if ((owner instanceof PlusCWODSPointTO))
/*  605:     */           {
/*  606:1031 */             if (auxTolLower.length() > 10) {
/*  607:1032 */               auxTolLower = auxTolLower.substring(0, 9);
/*  608:     */             }
/*  609:1034 */             if (auxTolUpper.length() > 10) {
/*  610:1035 */               auxTolUpper = auxTolUpper.substring(0, 9);
/*  611:     */             }
/*  612:     */           }
/*  613:1044 */           if (!sPrefix.equalsIgnoreCase(""))
/*  614:     */           {
/*  615:1048 */             auxTolLower = checkAndAdjustFldValueSize(auxTolLower, df, 10, locale);
/*  616:1049 */             auxTolUpper = checkAndAdjustFldValueSize(auxTolUpper, df, 10, locale);
/*  617:     */             
/*  618:1051 */             owner.setValue(sPrefix + "tol" + tol + "lw_orig", auxTolLower, 9L);
/*  619:1052 */             owner.setValue(sPrefix + "tol" + tol + "up_orig", auxTolUpper, 9L);
/*  620:     */           }
/*  621:1056 */           for (int i = 0; i < tolPrefixes.length; i++)
/*  622:     */           {
/*  623:1058 */             owner.setValue(tolPrefixes[i] + "tol" + tol + "lower", toleranceLower, 9L);
/*  624:1059 */             owner.setValue(tolPrefixes[i] + "tol" + tol + "lower_np", toleranceLower, 9L);
/*  625:1060 */             owner.setValue(tolPrefixes[i] + "tol" + tol + "upper_np", toleranceUpper, 9L);
/*  626:1061 */             owner.setValue(tolPrefixes[i] + "tol" + tol + "upper", toleranceUpper, 9L);
/*  627:     */           }
/*  628:1067 */           if ((fieldName.equalsIgnoreCase("ASFOUNDINPUT")) || (fieldName.equalsIgnoreCase("ASLEFTINPUT"))) {
/*  629:1069 */             if (owner.getString(fieldName).equals("")) {
/*  630:1070 */               clearToleranceFields(owner, sPrefix, tol);
/*  631:     */             }
/*  632:     */           }
/*  633:1073 */           if ((fieldName.equalsIgnoreCase("ASFOUNDOUTPUT")) || (fieldName.equalsIgnoreCase("ASLEFOUTPUT"))) {
/*  634:1075 */             if ((owner.getString(fieldName).equals("")) && (owner.getString(sPrefix + "INPUT").equals(""))) {
/*  635:1077 */               clearToleranceFields(owner, sPrefix, tol);
/*  636:     */             }
/*  637:     */           }
/*  638:     */         }
/*  639:     */       }
/*  640:     */     }
/*  641:1082 */     return true;
/*  642:     */   }
/*  643:     */   
/*  644:     */   private void clearToleranceFields(PlusCMboRemote owner, String sPrefix, int tol)
/*  645:     */   {
/*  646:1087 */     owner.setValue(sPrefix + "tol" + tol + "lower_np", "", 9L);
/*  647:1088 */     owner.setValue(sPrefix + "tol" + tol + "lower", "", 9L);
/*  648:1089 */     owner.setValue(sPrefix + "tol" + tol + "upper_np", "", 9L);
/*  649:1090 */     owner.setValue(sPrefix + "tol" + tol + "upper", "", 9L);
/*  650:     */   }
/*  651:     */   
/*  652:     */   private double addGuardBand(PlusCMboRemote mbo, double tolerance, int tol, String direction, boolean doNotApplySpanRatio, double spanRatio, Locale locale)
/*  653:     */   {
/*  654:1117 */     if (hasGuardbandFields(mbo, tol))
/*  655:     */     {
/*  656:1119 */       double gb = PlusCToolKitTOCommon.stringToDouble(mbo.getString("GB" + direction + tol), locale) * (doNotApplySpanRatio ? 1.0D : spanRatio);
/*  657:     */       
/*  658:     */ 
/*  659:     */ 
/*  660:1123 */       double gbSign = mbo.getString("gbsumdirection" + tol).equals("-") ? -1.0D : 1.0D;
/*  661:     */       
/*  662:1125 */       return tolerance + gbSign * gb;
/*  663:     */     }
/*  664:1128 */     return tolerance;
/*  665:     */   }
/*  666:     */   
/*  667:     */   public double[] summedToleranceEquationsTightesWidest(PlusCMboRemote owner, String fieldName, int tol, boolean[] summedCalcTypes)
/*  668:     */   {
/*  669:1153 */     boolean shouldRound = !getTolTruncate();
/*  670:     */     
/*  671:     */ 
/*  672:1156 */     String planType = owner.getString("plantype");
/*  673:     */     
/*  674:1158 */     boolean isOutputRangeLimit = owner.getBoolean("outputrange").booleanValue();
/*  675:     */     
/*  676:     */ 
/*  677:1161 */     double ISpanByOSpan = 0.0D;
/*  678:1162 */     double summedToleranceFrom = 0.0D;
/*  679:1163 */     double summedToleranceTo = 0.0D;
/*  680:1164 */     double desiredOutputValue = 0.0D;
/*  681:     */     
/*  682:1166 */     double summedEUValue = 0.0D;
/*  683:1167 */     double summedREADINGValue = 0.0D;
/*  684:1168 */     double summedSPANValue = 0.0D;
/*  685:1169 */     double summedURVValue = 0.0D;
/*  686:     */     
/*  687:     */ 
/*  688:1172 */     boolean summedTolDirectionBOTH = false;
/*  689:1173 */     boolean summedTolDirectionPLUS = false;
/*  690:1174 */     boolean summedTolDirectionMINUS = false;
/*  691:1175 */     boolean calcSummedEU = summedCalcTypes[0];
/*  692:1176 */     boolean calcSummedRDG = summedCalcTypes[1];
/*  693:1177 */     boolean calcSummedSpan = summedCalcTypes[2];
/*  694:1178 */     boolean calcSummedURV = summedCalcTypes[3];
/*  695:     */     
/*  696:1180 */     String toleranceLower = "0.0000000000000";
/*  697:1181 */     String toleranceUpper = "0.0000000000000";
/*  698:     */     
/*  699:1183 */     Locale locale = owner.getLocale();
/*  700:     */     
/*  701:1185 */     String sPrefix = "";
/*  702:1187 */     if ((fieldName.equalsIgnoreCase("ASFOUNDINPUT")) || (fieldName.equalsIgnoreCase("ASFOUNDSETPOINT"))) {
/*  703:1188 */       sPrefix = "asfound";
/*  704:     */     }
/*  705:1191 */     if ((fieldName.equalsIgnoreCase("ASLEFTINPUT")) || (fieldName.equalsIgnoreCase("ASLEFTSETPOINT"))) {
/*  706:1192 */       sPrefix = "asleft";
/*  707:     */     }
/*  708:1195 */     int minOutputPrecision = owner.getInt("OUTPUTPRECISION").intValue();
/*  709:1196 */     int actualInputPrecision = PlusCToolKitTOCommon.getDecimalDigits(sPrefix.equals("") ? owner.getString("INPUTVALUE") : owner.getString(sPrefix + "INPUT"));
/*  710:     */     
/*  711:     */ 
/*  712:     */ 
/*  713:1200 */     int actualOutputPrecision = PlusCToolKitTOCommon.getDecimalDigits(sPrefix.equals("") ? owner.getString("OUTPUTVALUE") : owner.getString(sPrefix + "OUTPUT"));
/*  714:     */     
/*  715:     */ 
/*  716:     */ 
/*  717:1204 */     int precision = minOutputPrecision;
/*  718:1205 */     int rightPrecision = getTolPrecision(minOutputPrecision, actualOutputPrecision, actualInputPrecision);
/*  719:     */     
/*  720:1207 */     double equationSpecificVariable = 0.0D;
/*  721:     */     
/*  722:1209 */     String sumDirection = owner.getString("tol" + tol + "SUMDIRECTION");
/*  723:1210 */     if (sumDirection == null) {
/*  724:1211 */       sumDirection = "";
/*  725:     */     }
/*  726:1215 */     sumDirection = owner.getString("tol" + tol + "SUMDIRECTION");
/*  727:1217 */     if (sumDirection.equals("+")) {
/*  728:1218 */       summedTolDirectionPLUS = true;
/*  729:1219 */     } else if (sumDirection.equals("-")) {
/*  730:1220 */       summedTolDirectionMINUS = true;
/*  731:1221 */     } else if (sumDirection.equals("+/-")) {
/*  732:1222 */       summedTolDirectionBOTH = true;
/*  733:     */     }
/*  734:1232 */     if (!sPrefix.equals("")) {
/*  735:1233 */       desiredOutputValue = PlusCToolKitTOCommon.stringToDouble(doWOUpdateOutputValue(owner, sPrefix), locale);
/*  736:     */     } else {
/*  737:1235 */       desiredOutputValue = PlusCToolKitTOCommon.stringToDouble(owner.getString("OUTPUTVALUE_NP"), locale);
/*  738:     */     }
/*  739:1239 */     double inputFrom = 0.0D;
/*  740:1240 */     double inputTo = 0.0D;
/*  741:1241 */     double outputFrom = 0.0D;
/*  742:1242 */     double outputTo = 0.0D;
/*  743:     */     
/*  744:1244 */     double[] verification = directionCheck(owner, locale);
/*  745:1245 */     inputFrom = verification[0];
/*  746:1246 */     inputTo = verification[1];
/*  747:1247 */     outputFrom = verification[2];
/*  748:1248 */     outputTo = verification[3];
/*  749:1250 */     if (calcSummedEU) {
/*  750:1252 */       if (isOutputRangeLimit)
/*  751:     */       {
/*  752:1254 */         summedEUValue = PlusCToolKitTOCommon.stringToDouble(owner.getString("tol" + tol + "sumeu"), locale);
/*  753:     */       }
/*  754:     */       else
/*  755:     */       {
/*  756:1257 */         double instrInputSpan = inputTo - inputFrom;
/*  757:1258 */         double instrOutputSpan = outputTo - outputFrom;
/*  758:1259 */         ISpanByOSpan = instrOutputSpan / instrInputSpan;
/*  759:1260 */         double calcRangeDiff = PlusCToolKitTOCommon.stringToDouble(owner.getString("tol" + tol + "sumeu"), locale) * ISpanByOSpan;
/*  760:     */         
/*  761:1262 */         summedEUValue = calcRangeDiff;
/*  762:     */       }
/*  763:     */     }
/*  764:1271 */     if (!isOutputRangeLimit)
/*  765:     */     {
/*  766:1282 */       if (!sPrefix.equals("")) {
/*  767:1283 */         desiredOutputValue = PlusCToolKitTOCommon.stringToDouble(doWOUpdateOutputValue(owner, sPrefix), locale);
/*  768:     */       } else {
/*  769:1285 */         desiredOutputValue = PlusCToolKitTOCommon.stringToDouble(owner.getString("OUTPUTVALUE_ROUNDING"), locale);
/*  770:     */       }
/*  771:1287 */       double instrInputSpan = inputTo - inputFrom;
/*  772:1288 */       double instrOutputSpan = outputTo - outputFrom;
/*  773:1289 */       ISpanByOSpan = instrOutputSpan / instrInputSpan;
/*  774:1290 */       double calcRangeDiff = PlusCToolKitTOCommon.stringToDouble(owner.getString("tol" + tol + "sumeu"), locale) * ISpanByOSpan;
/*  775:1291 */       summedEUValue = calcRangeDiff;
/*  776:1294 */       if ((calcSummedSpan) && (planType.equalsIgnoreCase("ANALOG")))
/*  777:     */       {
/*  778:1295 */         equationSpecificVariable = inputTo - inputFrom;
/*  779:     */         
/*  780:1297 */         summedSPANValue = PlusCToolKitTOCommon.stringToDouble(owner.getString("tol" + tol + "SumSpan"), locale) * (equationSpecificVariable / 100.0D * ISpanByOSpan);
/*  781:     */       }
/*  782:1299 */       if ((calcSummedURV) && (planType.equalsIgnoreCase("ANALOG")))
/*  783:     */       {
/*  784:1300 */         equationSpecificVariable = inputTo;
/*  785:     */         
/*  786:1302 */         summedURVValue = PlusCToolKitTOCommon.stringToDouble(owner.getString("tol" + tol + "SumURV"), locale) * (Math.abs(equationSpecificVariable) / 100.0D * ISpanByOSpan);
/*  787:     */       }
/*  788:1304 */       if ((calcSummedRDG) && (planType.equalsIgnoreCase("ANALOG")))
/*  789:     */       {
/*  790:1305 */         if (!sPrefix.equals("")) {
/*  791:1306 */           equationSpecificVariable = PlusCToolKitTOCommon.stringToDouble(owner.getString(sPrefix + "INPUT"), locale);
/*  792:     */         } else {
/*  793:1308 */           equationSpecificVariable = PlusCToolKitTOCommon.stringToDouble(owner.getString("INPUTVALUE"), locale);
/*  794:     */         }
/*  795:1311 */         summedREADINGValue = PlusCToolKitTOCommon.stringToDouble(owner.getString("tol" + tol + "SumRead"), locale) * (Math.abs(equationSpecificVariable) / 100.0D * ISpanByOSpan);
/*  796:     */       }
/*  797:     */     }
/*  798:     */     else
/*  799:     */     {
/*  800:1319 */       if (!sPrefix.equals("")) {
/*  801:1320 */         desiredOutputValue = PlusCToolKitTOCommon.stringToDouble(doWOUpdateOutputValue(owner, sPrefix), locale);
/*  802:     */       } else {
/*  803:1322 */         desiredOutputValue = PlusCToolKitTOCommon.stringToDouble(owner.getString("OUTPUTVALUE_NP"), locale);
/*  804:     */       }
/*  805:1325 */       if ((calcSummedSpan) && (planType.equalsIgnoreCase("ANALOG")))
/*  806:     */       {
/*  807:1326 */         equationSpecificVariable = outputTo - outputFrom;
/*  808:     */         
/*  809:1328 */         summedSPANValue = PlusCToolKitTOCommon.stringToDouble(owner.getString("tol" + tol + "SumSpan"), locale) * (equationSpecificVariable / 100.0D);
/*  810:     */         
/*  811:1330 */         summedSPANValue = PlusCToolKitTOCommon.stringToDouble(PlusCToolKitTOCommon.formatDouble(String.valueOf(summedSPANValue), minOutputPrecision, locale, true), locale);
/*  812:     */       }
/*  813:1333 */       if ((calcSummedURV) && (planType.equalsIgnoreCase("ANALOG")))
/*  814:     */       {
/*  815:1334 */         equationSpecificVariable = outputTo;
/*  816:     */         
/*  817:1336 */         summedURVValue = PlusCToolKitTOCommon.stringToDouble(owner.getString("tol" + tol + "SumURV"), locale) * (Math.abs(equationSpecificVariable) / 100.0D);
/*  818:     */       }
/*  819:1338 */       if ((calcSummedRDG) && (planType.equalsIgnoreCase("ANALOG")))
/*  820:     */       {
/*  821:1340 */         equationSpecificVariable = PlusCToolKitTOCommon.stringToDouble(PlusCToolKitTOCommon.formatDouble(owner.getString("OUTPUTVALUE_NP"), minOutputPrecision, locale, true), locale);
/*  822:     */         
/*  823:1342 */         summedREADINGValue = PlusCToolKitTOCommon.stringToDouble(owner.getString("tol" + tol + "SumRead"), locale) * (Math.abs(equationSpecificVariable) / 100.0D);
/*  824:     */       }
/*  825:     */     }
/*  826:1347 */     if (summedTolDirectionMINUS)
/*  827:     */     {
/*  828:1348 */       summedToleranceFrom = desiredOutputValue - summedEUValue - summedSPANValue - summedURVValue - summedREADINGValue;
/*  829:1349 */       summedToleranceTo = desiredOutputValue;
/*  830:     */     }
/*  831:1350 */     else if (summedTolDirectionPLUS)
/*  832:     */     {
/*  833:1351 */       summedToleranceFrom = desiredOutputValue;
/*  834:1352 */       summedToleranceTo = desiredOutputValue + summedEUValue + summedSPANValue + summedURVValue + summedREADINGValue;
/*  835:     */     }
/*  836:1353 */     else if (summedTolDirectionBOTH)
/*  837:     */     {
/*  838:1354 */       summedToleranceFrom = desiredOutputValue - summedEUValue - summedSPANValue - summedURVValue - summedREADINGValue;
/*  839:1355 */       summedToleranceTo = desiredOutputValue + summedEUValue + summedSPANValue + summedURVValue + summedREADINGValue;
/*  840:     */     }
/*  841:1364 */     String auxTolLower = PlusCToolKitTOCommon.formatDouble(String.valueOf(summedToleranceFrom), 10, locale, true);
/*  842:1365 */     String auxTolUpper = PlusCToolKitTOCommon.formatDouble(String.valueOf(summedToleranceTo), 10, locale, true);
/*  843:     */     
/*  844:     */ 
/*  845:     */ 
/*  846:     */ 
/*  847:1370 */     toleranceLower = PlusCToolKitTOCommon.formatDouble(String.valueOf(summedToleranceFrom), rightPrecision, locale, shouldRound);
/*  848:1371 */     toleranceUpper = PlusCToolKitTOCommon.formatDouble(String.valueOf(summedToleranceTo), rightPrecision, locale, shouldRound);
/*  849:     */     
/*  850:     */ 
/*  851:1374 */     boolean bTrimTolerances = owner.getBoolean("CLIPLIMITS").booleanValue();
/*  852:1375 */     if (bTrimTolerances)
/*  853:     */     {
/*  854:1376 */       double dToleranceLower = Math.min(Math.max(summedToleranceFrom, outputFrom), outputTo);
/*  855:1377 */       double dToleranceUpper = Math.max(Math.min(summedToleranceTo, outputTo), outputFrom);
/*  856:     */       
/*  857:     */ 
/*  858:     */ 
/*  859:     */ 
/*  860:     */ 
/*  861:1383 */       auxTolLower = PlusCToolKitTOCommon.formatDouble(String.valueOf(dToleranceLower), 10, locale, true);
/*  862:1384 */       auxTolUpper = PlusCToolKitTOCommon.formatDouble(String.valueOf(dToleranceUpper), 10, locale, true);
/*  863:     */       
/*  864:     */ 
/*  865:     */ 
/*  866:     */ 
/*  867:1389 */       toleranceLower = PlusCToolKitTOCommon.formatDouble(String.valueOf(dToleranceLower), rightPrecision, locale, shouldRound);
/*  868:1390 */       toleranceUpper = PlusCToolKitTOCommon.formatDouble(String.valueOf(dToleranceUpper), rightPrecision, locale, shouldRound);
/*  869:     */     }
/*  870:1393 */     DecimalFormatSymbols df = new DecimalFormatSymbols(locale);
/*  871:1394 */     String decimalSeparator = String.valueOf(df.getDecimalSeparator());
/*  872:1395 */     String[] splitDecimals = PlusCToolKitTOCommon.split(toleranceLower, decimalSeparator);
/*  873:1396 */     String[] splitDecimalsUpper = PlusCToolKitTOCommon.split(toleranceUpper, decimalSeparator);
/*  874:1397 */     boolean splitLower = splitDecimals.length > 1;
/*  875:1398 */     boolean splitUpper = splitDecimalsUpper.length > 1;
/*  876:1399 */     boolean checkRoundUp = owner.isRoundUpField();
/*  877:1401 */     if ((splitLower) || (splitUpper))
/*  878:     */     {
/*  879:1402 */       if ((splitLower) && 
/*  880:1403 */         (splitDecimals[1].length() > precision))
/*  881:     */       {
/*  882:1407 */         toleranceLower = PlusCToolKitTOCommon.formatDoubleMax(toleranceLower, rightPrecision, locale, checkRoundUp, shouldRound);
/*  883:1408 */         splitDecimals = PlusCToolKitTOCommon.split(toleranceLower, decimalSeparator);
/*  884:1409 */         if (splitDecimals.length > 1)
/*  885:     */         {
/*  886:1410 */           if (splitDecimals[1].length() < precision)
/*  887:     */           {
/*  888:1417 */             auxTolLower = PlusCToolKitTOCommon.formatDouble(String.valueOf(toleranceLower), 10, locale, true);
/*  889:     */             
/*  890:     */ 
/*  891:     */ 
/*  892:     */ 
/*  893:1422 */             toleranceLower = PlusCToolKitTOCommon.formatDouble(String.valueOf(toleranceLower), rightPrecision, locale, shouldRound);
/*  894:     */           }
/*  895:     */         }
/*  896:     */         else
/*  897:     */         {
/*  898:1431 */           auxTolLower = PlusCToolKitTOCommon.formatDouble(String.valueOf(toleranceLower), 10, locale, true);
/*  899:1432 */           auxTolUpper = PlusCToolKitTOCommon.formatDouble(String.valueOf(toleranceUpper), 10, locale, true);
/*  900:     */           
/*  901:     */ 
/*  902:     */ 
/*  903:     */ 
/*  904:1437 */           toleranceLower = PlusCToolKitTOCommon.formatDouble(String.valueOf(toleranceLower), rightPrecision, locale, shouldRound);
/*  905:1438 */           toleranceUpper = PlusCToolKitTOCommon.formatDouble(String.valueOf(toleranceUpper), rightPrecision, locale, shouldRound);
/*  906:     */         }
/*  907:     */       }
/*  908:1442 */       splitDecimals = PlusCToolKitTOCommon.split(toleranceUpper, decimalSeparator);
/*  909:1444 */       if ((toleranceUpper.indexOf(String.valueOf(df.getDecimalSeparator())) != -1) && 
/*  910:1445 */         (splitDecimals[1].length() > precision))
/*  911:     */       {
/*  912:1449 */         toleranceUpper = PlusCToolKitTOCommon.formatDoubleMax(toleranceUpper, rightPrecision, locale, checkRoundUp, shouldRound);
/*  913:1450 */         splitDecimals = PlusCToolKitTOCommon.split(toleranceUpper, decimalSeparator);
/*  914:1451 */         if (splitDecimals.length > 1)
/*  915:     */         {
/*  916:1452 */           if (splitDecimals[1].length() < precision)
/*  917:     */           {
/*  918:1458 */             auxTolUpper = PlusCToolKitTOCommon.formatDouble(String.valueOf(toleranceUpper), 10, locale, true);
/*  919:     */             
/*  920:     */ 
/*  921:     */ 
/*  922:     */ 
/*  923:1463 */             toleranceUpper = PlusCToolKitTOCommon.formatDouble(String.valueOf(toleranceUpper), rightPrecision, locale, shouldRound);
/*  924:     */           }
/*  925:     */         }
/*  926:     */         else
/*  927:     */         {
/*  928:1472 */           auxTolLower = PlusCToolKitTOCommon.formatDouble(String.valueOf(toleranceLower), 10, locale, true);
/*  929:1473 */           auxTolUpper = PlusCToolKitTOCommon.formatDouble(String.valueOf(toleranceUpper), 10, locale, true);
/*  930:     */           
/*  931:     */ 
/*  932:     */ 
/*  933:     */ 
/*  934:1478 */           toleranceLower = PlusCToolKitTOCommon.formatDouble(String.valueOf(toleranceLower), rightPrecision, locale, shouldRound);
/*  935:1479 */           toleranceUpper = PlusCToolKitTOCommon.formatDouble(String.valueOf(toleranceUpper), rightPrecision, locale, shouldRound);
/*  936:     */         }
/*  937:     */       }
/*  938:     */     }
/*  939:1489 */     if ((owner instanceof PlusCWODSPointTO))
/*  940:     */     {
/*  941:1491 */       if (auxTolLower.length() > 10) {
/*  942:1492 */         auxTolLower = auxTolLower.substring(0, 9);
/*  943:     */       }
/*  944:1494 */       if (auxTolUpper.length() > 10) {
/*  945:1495 */         auxTolUpper = auxTolUpper.substring(0, 9);
/*  946:     */       }
/*  947:     */     }
/*  948:1505 */     if (!sPrefix.equalsIgnoreCase(""))
/*  949:     */     {
/*  950:1508 */       auxTolLower = checkAndAdjustFldValueSize(auxTolLower, df, 10, locale);
/*  951:1509 */       auxTolUpper = checkAndAdjustFldValueSize(auxTolUpper, df, 10, locale);
/*  952:     */       
/*  953:1511 */       owner.setValue(sPrefix + "tol" + tol + "lw_orig", auxTolLower, 9L);
/*  954:1512 */       owner.setValue(sPrefix + "tol" + tol + "up_orig", auxTolUpper, 9L);
/*  955:     */     }
/*  956:1515 */     return new double[] { summedToleranceFrom, summedToleranceTo };
/*  957:     */   }
/*  958:     */   
/*  959:     */   public String squaredDesiredOutputValue(PlusCMboRemote owner)
/*  960:     */   {
/*  961:1525 */     String desiredOutputValue = "";
/*  962:1526 */     if (owner == null) {
/*  963:1527 */       return desiredOutputValue;
/*  964:     */     }
/*  965:1529 */     Locale locale = owner.getLocale();
/*  966:1530 */     double i = PlusCToolKitTOCommon.stringToDouble(owner.getString("inputvalue"), locale);
/*  967:1531 */     double iLower = PlusCToolKitTOCommon.stringToDouble(owner.getString("instrcalrangefrom"), locale);
/*  968:1532 */     double inputSpan = PlusCToolKitTOCommon.stringToDouble(owner.getString("instrcalrangeto"), locale) - PlusCToolKitTOCommon.stringToDouble(owner.getString("instrcalrangefrom"), locale);
/*  969:1533 */     double outputSpan = PlusCToolKitTOCommon.stringToDouble(owner.getString("instroutrangeto"), locale) - PlusCToolKitTOCommon.stringToDouble(owner.getString("instroutrangefrom"), locale);
/*  970:1534 */     double oLower = PlusCToolKitTOCommon.stringToDouble(owner.getString("instroutrangefrom"), locale);
/*  971:1535 */     int precision = owner.getInt("OUTPUTPRECISION").intValue();
/*  972:1536 */     double finalValue = 0.0D;
/*  973:1537 */     boolean checkRoundUp = owner.isRoundUpField();
/*  974:1538 */     double exp = 2.0D;
/*  975:     */     
/*  976:1540 */     finalValue = Math.pow((i - iLower) / inputSpan, exp) * outputSpan + oLower;
/*  977:     */     
/*  978:1542 */     desiredOutputValue = PlusCToolKitTOCommon.formatDouble(String.valueOf(finalValue), precision, locale, false);
/*  979:     */     
/*  980:1544 */     DecimalFormatSymbols df = new DecimalFormatSymbols(locale);
/*  981:1545 */     String decimalSeparator = String.valueOf(df.getDecimalSeparator());
/*  982:1546 */     String[] splitDecimals = PlusCToolKitTOCommon.split(desiredOutputValue, decimalSeparator);
/*  983:1548 */     if ((splitDecimals.length > 1) && 
/*  984:1549 */       (splitDecimals[1].length() > precision))
/*  985:     */     {
/*  986:1551 */       desiredOutputValue = PlusCToolKitTOCommon.formatDoubleMax(desiredOutputValue, precision, locale, checkRoundUp, false);
/*  987:1552 */       splitDecimals = PlusCToolKitTOCommon.split(desiredOutputValue, decimalSeparator);
/*  988:1553 */       if (splitDecimals.length > 1)
/*  989:     */       {
/*  990:1554 */         if (splitDecimals[1].length() < precision) {
/*  991:1556 */           desiredOutputValue = PlusCToolKitTOCommon.formatDouble(String.valueOf(desiredOutputValue), precision, locale, false);
/*  992:     */         }
/*  993:     */       }
/*  994:     */       else {
/*  995:1560 */         desiredOutputValue = PlusCToolKitTOCommon.formatDouble(String.valueOf(desiredOutputValue), precision, locale, false);
/*  996:     */       }
/*  997:     */     }
/*  998:1564 */     return desiredOutputValue;
/*  999:     */   }
/* 1000:     */   
/* 1001:     */   public String squareRootDesiredOutputValue(PlusCMboRemote owner)
/* 1002:     */   {
/* 1003:1576 */     String desiredOutputValue = "";
/* 1004:1577 */     if (owner == null) {
/* 1005:1578 */       return desiredOutputValue;
/* 1006:     */     }
/* 1007:1580 */     Locale locale = owner.getLocale();
/* 1008:1581 */     double i = PlusCToolKitTOCommon.stringToDouble(owner.getString("inputvalue"), locale);
/* 1009:1582 */     double iUpper = PlusCToolKitTOCommon.stringToDouble(owner.getString("instrcalrangeto"), locale);
/* 1010:1583 */     double outputSpan = PlusCToolKitTOCommon.stringToDouble(owner.getString("instroutrangeto"), locale) - PlusCToolKitTOCommon.stringToDouble(owner.getString("instroutrangefrom"), locale);
/* 1011:1584 */     double oLower = PlusCToolKitTOCommon.stringToDouble(owner.getString("instroutrangefrom"), locale);
/* 1012:1585 */     int precision = owner.getInt("OUTPUTPRECISION").intValue();
/* 1013:1586 */     double finalValue = 0.0D;
/* 1014:1587 */     boolean checkRoundUp = owner.isRoundUpField();
/* 1015:     */     
/* 1016:     */ 
/* 1017:1590 */     finalValue = Math.sqrt(i / iUpper) * outputSpan + oLower;
/* 1018:     */     
/* 1019:     */ 
/* 1020:     */ 
/* 1021:     */ 
/* 1022:     */ 
/* 1023:1596 */     desiredOutputValue = PlusCToolKitTOCommon.formatDouble(String.valueOf(finalValue), precision, locale, checkRoundUp);
/* 1024:     */     
/* 1025:1598 */     DecimalFormatSymbols df = new DecimalFormatSymbols(locale);
/* 1026:1599 */     String decimalSeparator = String.valueOf(df.getDecimalSeparator());
/* 1027:1600 */     String[] splitDecimals = PlusCToolKitTOCommon.split(desiredOutputValue, decimalSeparator);
/* 1028:1602 */     if ((splitDecimals.length > 1) && 
/* 1029:1603 */       (splitDecimals[1].length() > precision))
/* 1030:     */     {
/* 1031:1609 */       desiredOutputValue = PlusCToolKitTOCommon.formatDouble(desiredOutputValue, precision, locale, false);
/* 1032:     */       
/* 1033:1611 */       splitDecimals = PlusCToolKitTOCommon.split(desiredOutputValue, decimalSeparator);
/* 1034:1612 */       if (splitDecimals.length > 1)
/* 1035:     */       {
/* 1036:1613 */         if (splitDecimals[1].length() < precision) {
/* 1037:1615 */           desiredOutputValue = PlusCToolKitTOCommon.formatDouble(String.valueOf(desiredOutputValue), precision, locale, false);
/* 1038:     */         }
/* 1039:     */       }
/* 1040:     */       else {
/* 1041:1619 */         desiredOutputValue = PlusCToolKitTOCommon.formatDouble(String.valueOf(desiredOutputValue), precision, locale, false);
/* 1042:     */       }
/* 1043:     */     }
/* 1044:1623 */     return desiredOutputValue;
/* 1045:     */   }
/* 1046:     */   
/* 1047:     */   public static String squareRootOutputValueNegative(Locale locale, String instrcalrangeto, String instroutrangefrom, String instrOutputSpan, String invalue)
/* 1048:     */   {
/* 1049:1639 */     String desiredOutputValue = String.valueOf(PlusCToolKitTOCommon.stringToDouble(instroutrangefrom, locale) - Math.sqrt(PlusCToolKitTOCommon.stringToDouble(invalue, locale) / PlusCToolKitTOCommon.stringToDouble(instrcalrangeto, locale)) * PlusCToolKitTOCommon.stringToDouble(instrOutputSpan, locale));
/* 1050:     */     
/* 1051:     */ 
/* 1052:     */ 
/* 1053:     */ 
/* 1054:     */ 
/* 1055:1645 */     return desiredOutputValue;
/* 1056:     */   }
/* 1057:     */   
/* 1058:     */   public static String squaredOutputValueNegative(Locale locale, String instrcalrangefrom, String instrcalrangeto, String instroutrangefrom, String instrOutputSpan, String invalue, int precision)
/* 1059:     */   {
/* 1060:1661 */     double i = PlusCToolKitTOCommon.stringToDouble(invalue, locale);
/* 1061:1662 */     double sign = i < 0.0D ? -1.0D : 1.0D;
/* 1062:1663 */     return squaredOutputValue(locale, instrcalrangefrom, instrcalrangeto, instroutrangefrom, instrOutputSpan, invalue, sign, precision);
/* 1063:     */   }
/* 1064:     */   
/* 1065:     */   public static String squaredOutputValue(Locale locale, String instrcalrangefrom, String instrcalrangeto, String instroutrangefrom, String instrOutputSpan, String invalue, double sign, int precision)
/* 1066:     */   {
/* 1067:1683 */     double i = PlusCToolKitTOCommon.stringToDouble(invalue, locale);
/* 1068:1684 */     double iLower = PlusCToolKitTOCommon.stringToDouble(instrcalrangefrom, locale);
/* 1069:1685 */     double inputSpan = PlusCToolKitTOCommon.stringToDouble(instrcalrangeto, locale) - PlusCToolKitTOCommon.stringToDouble(instrcalrangefrom, locale);
/* 1070:1686 */     double outputSpan = PlusCToolKitTOCommon.stringToDouble(instrOutputSpan, locale);
/* 1071:1687 */     double oLower = PlusCToolKitTOCommon.stringToDouble(instroutrangefrom, locale);
/* 1072:1688 */     double finalValue = 0.0D;
/* 1073:1689 */     double exp = 2.0D;
/* 1074:     */     
/* 1075:1691 */     finalValue = sign * (Math.pow((i - iLower) / inputSpan, exp) * outputSpan) + oLower;
/* 1076:     */     
/* 1077:1693 */     String desiredOutputValue = PlusCToolKitTOCommon.formatDouble(String.valueOf(finalValue), precision, locale, false);
/* 1078:     */     
/* 1079:1695 */     return desiredOutputValue;
/* 1080:     */   }
/* 1081:     */   
/* 1082:     */   public boolean calculateToleranceRangeSquareRoot(PlusCMboRemote owner, String fieldName)
/* 1083:     */   {
/* 1084:1711 */     boolean shouldRound = !getTolTruncate();
/* 1085:1714 */     if (owner == null) {
/* 1086:1715 */       return false;
/* 1087:     */     }
/* 1088:1722 */     Locale locale = owner.getLocale();
/* 1089:1725 */     for (int tol = 1; tol < 5; tol++)
/* 1090:     */     {
/* 1091:1726 */       String planType = owner.getString("plantype");
/* 1092:     */       
/* 1093:1728 */       String toltype = owner.getString("tol" + tol + "type");
/* 1094:1730 */       if (toltype.equals("")) {
/* 1095:1731 */         toltype = null;
/* 1096:     */       }
/* 1097:1737 */       String sPrefix = "";
/* 1098:1738 */       if ((fieldName.equalsIgnoreCase("ASFOUNDINPUT")) || (fieldName.equalsIgnoreCase("ASFOUNDSETPOINT"))) {
/* 1099:1740 */         sPrefix = "asfound";
/* 1100:     */       }
/* 1101:1743 */       if ((fieldName.equalsIgnoreCase("ASLEFTINPUT")) || (fieldName.equalsIgnoreCase("ASLEFTSETPOINT"))) {
/* 1102:1745 */         sPrefix = "asleft";
/* 1103:     */       }
/* 1104:1749 */       double iLower = PlusCToolKitTOCommon.stringToDouble(owner.getString("instrcalrangefrom"), locale);
/* 1105:1750 */       double iUpper = PlusCToolKitTOCommon.stringToDouble(owner.getString("instrcalrangeto"), locale);
/* 1106:1751 */       double inputSpan = iUpper - iLower;
/* 1107:1752 */       double outputSpan = PlusCToolKitTOCommon.stringToDouble(owner.getString("instroutrangeto"), locale) - PlusCToolKitTOCommon.stringToDouble(owner.getString("instroutrangefrom"), locale);
/* 1108:     */       
/* 1109:     */ 
/* 1110:1755 */       double oLower = PlusCToolKitTOCommon.stringToDouble(owner.getString("instroutrangefrom"), locale);
/* 1111:     */       
/* 1112:1757 */       double oUpper = PlusCToolKitTOCommon.stringToDouble(owner.getString("instroutrangeto"), locale);
/* 1113:1758 */       double tolLower = 0.0D;
/* 1114:1759 */       double tolUpper = 0.0D;
/* 1115:1760 */       if ((!owner.getString("tol" + tol + "lowervalue").equals("")) || (!owner.getString("tol" + tol + "uppervalue").equals("")))
/* 1116:     */       {
/* 1117:1762 */         tolLower = PlusCToolKitTOCommon.stringToDouble(owner.getString("tol" + tol + "lowervalue"), locale);
/* 1118:     */         
/* 1119:1764 */         tolUpper = PlusCToolKitTOCommon.stringToDouble(owner.getString("tol" + tol + "uppervalue"), locale);
/* 1120:     */       }
/* 1121:1767 */       int minOutputPrecision = owner.getInt("OUTPUTPRECISION").intValue();
/* 1122:1768 */       int actualInputPrecision = PlusCToolKitTOCommon.getDecimalDigits(sPrefix.equals("") ? owner.getString("INPUTVALUE") : owner.getString(sPrefix + "INPUT"));
/* 1123:     */       
/* 1124:     */ 
/* 1125:     */ 
/* 1126:1772 */       int actualOutputPrecision = PlusCToolKitTOCommon.getDecimalDigits(sPrefix.equals("") ? owner.getString("OUTPUTVALUE") : owner.getString(sPrefix + "OUTPUT"));
/* 1127:     */       
/* 1128:     */ 
/* 1129:     */ 
/* 1130:1776 */       int precision = minOutputPrecision;
/* 1131:1777 */       int rightPrecision = getTolPrecision(minOutputPrecision, actualOutputPrecision, actualInputPrecision);
/* 1132:     */       
/* 1133:1779 */       double desiredOutputValue = 0.0D;
/* 1134:     */       double i;
/* 1135:     */       double i;
/* 1136:1784 */       if (!sPrefix.equals(""))
/* 1137:     */       {
/* 1138:1785 */         desiredOutputValue = PlusCToolKitTOCommon.stringToDouble(doWOUpdateOutputValue(owner, sPrefix), locale);
/* 1139:1786 */         i = PlusCToolKitTOCommon.stringToDouble(owner.getString(sPrefix + "input"), locale);
/* 1140:     */       }
/* 1141:     */       else
/* 1142:     */       {
/* 1143:1788 */         desiredOutputValue = PlusCToolKitTOCommon.stringToDouble(owner.getString("OUTPUTVALUE_NP"), locale);
/* 1144:1789 */         i = PlusCToolKitTOCommon.stringToDouble(owner.getString("inputvalue"), locale);
/* 1145:     */       }
/* 1146:1792 */       double sqrtFrom = 0.0D;
/* 1147:1793 */       double sqrtTo = 0.0D;
/* 1148:     */       
/* 1149:     */ 
/* 1150:     */ 
/* 1151:     */ 
/* 1152:1798 */       boolean calcSummedRDG = false;
/* 1153:1799 */       boolean calcSummedEU = false;
/* 1154:1800 */       boolean calcSummedSpan = false;
/* 1155:1801 */       boolean calcSummedURV = false;
/* 1156:     */       
/* 1157:     */ 
/* 1158:1804 */       String toleranceLower = "";
/* 1159:1805 */       String toleranceUpper = "";
/* 1160:1806 */       String sumEU = "";
/* 1161:1807 */       String sumRead = "";
/* 1162:1808 */       String sumSpan = "";
/* 1163:1809 */       String sumURV = "";
/* 1164:     */       
/* 1165:1811 */       boolean checkRoundUp = owner.isRoundUpField();
/* 1166:     */       
/* 1167:     */ 
/* 1168:1814 */       sumEU = owner.getString("tol" + tol + "sumeu");
/* 1169:1815 */       if ((sumEU == null) || (sumEU.equals(""))) {
/* 1170:1816 */         sumEU = "";
/* 1171:     */       } else {
/* 1172:1818 */         calcSummedEU = true;
/* 1173:     */       }
/* 1174:1821 */       sumRead = owner.getString("tol" + tol + "sumread");
/* 1175:1823 */       if ((sumRead == null) || (sumRead.equals(""))) {
/* 1176:1824 */         sumRead = "";
/* 1177:     */       } else {
/* 1178:1826 */         calcSummedRDG = true;
/* 1179:     */       }
/* 1180:1829 */       sumSpan = owner.getString("tol" + tol + "sumspan");
/* 1181:1831 */       if ((sumSpan == null) || (sumSpan.equals(""))) {
/* 1182:1832 */         sumSpan = "";
/* 1183:     */       } else {
/* 1184:1834 */         calcSummedSpan = true;
/* 1185:     */       }
/* 1186:1837 */       sumURV = owner.getString("tol" + tol + "sumurv");
/* 1187:1839 */       if ((sumURV == null) || (sumURV.equals(""))) {
/* 1188:1840 */         sumURV = "";
/* 1189:     */       } else {
/* 1190:1842 */         calcSummedURV = true;
/* 1191:     */       }
/* 1192:1846 */       double gbFrom = 0.0D;
/* 1193:1847 */       double gbTo = 0.0D;
/* 1194:1848 */       if (!sPrefix.equals(""))
/* 1195:     */       {
/* 1196:1850 */         gbFrom = addGuardBand(owner, 0.0D, tol, "from", true, 0.0D, locale);
/* 1197:1851 */         gbTo = addGuardBand(owner, 0.0D, tol, "to", true, 0.0D, locale);
/* 1198:     */       }
/* 1199:1855 */       if ((!calcSummedEU) && (!calcSummedRDG) && (!calcSummedSpan) && (!calcSummedURV))
/* 1200:     */       {
/* 1201:1856 */         String auxTolLower = "";
/* 1202:1857 */         String auxTolUpper = "";
/* 1203:1858 */         if (toltype != null)
/* 1204:     */         {
/* 1205:1860 */           if (((toltype.equals("EU")) || (!sumEU.equals(""))) && (planType.equalsIgnoreCase("ANALOG")))
/* 1206:     */           {
/* 1207:1863 */             sqrtFrom = sqrtToleranceEU(i, iUpper, outputSpan, oLower, tolLower, gbFrom);
/* 1208:1864 */             sqrtTo = sqrtToleranceEU(i, iUpper, outputSpan, oLower, tolUpper, gbTo);
/* 1209:     */           }
/* 1210:1866 */           else if (((toltype.equals("%SPAN")) || (!sumSpan.equals(""))) && (planType.equalsIgnoreCase("ANALOG")))
/* 1211:     */           {
/* 1212:1869 */             sqrtFrom = sqrtTolerancePercentSpan(i, iUpper, inputSpan, outputSpan, oLower, tolLower, gbFrom);
/* 1213:1870 */             sqrtTo = sqrtTolerancePercentSpan(i, iUpper, inputSpan, outputSpan, oLower, tolUpper, gbTo);
/* 1214:     */           }
/* 1215:1872 */           else if (((toltype.equals("%URV")) || (!sumURV.equals(""))) && (planType.equalsIgnoreCase("ANALOG")))
/* 1216:     */           {
/* 1217:1875 */             sqrtFrom = sqrtTolerancePercentURV(i, iUpper, outputSpan, oLower, tolLower, gbFrom);
/* 1218:1876 */             sqrtTo = sqrtTolerancePercentURV(i, iUpper, outputSpan, oLower, tolUpper, gbTo);
/* 1219:     */           }
/* 1220:1878 */           else if (((toltype.equals("%READING")) || (!sumRead.equals(""))) && (planType.equalsIgnoreCase("ANALOG")))
/* 1221:     */           {
/* 1222:1881 */             sqrtFrom = sqrtTolerancePercentReading(i, iUpper, outputSpan, oLower, tolLower, gbFrom);
/* 1223:1882 */             sqrtTo = sqrtTolerancePercentReading(i, iUpper, outputSpan, oLower, tolUpper, gbTo);
/* 1224:     */           }
/* 1225:1892 */           auxTolLower = PlusCToolKitTOCommon.formatDouble(String.valueOf(sqrtFrom), 10, locale, true);
/* 1226:1893 */           auxTolUpper = PlusCToolKitTOCommon.formatDouble(String.valueOf(sqrtTo), 10, locale, true);
/* 1227:     */           
/* 1228:     */ 
/* 1229:     */ 
/* 1230:     */ 
/* 1231:1898 */           toleranceLower = PlusCToolKitTOCommon.formatDouble(String.valueOf(sqrtFrom), rightPrecision, locale, shouldRound);
/* 1232:1899 */           toleranceUpper = PlusCToolKitTOCommon.formatDouble(String.valueOf(sqrtTo), rightPrecision, locale, shouldRound);
/* 1233:     */           
/* 1234:     */ 
/* 1235:1902 */           boolean bTrimTolerances = owner.getBoolean("CLIPLIMITS").booleanValue();
/* 1236:1904 */           if (bTrimTolerances)
/* 1237:     */           {
/* 1238:1905 */             double dToleranceLower = Math.min(Math.max(PlusCToolKitTOCommon.stringToDouble(toleranceLower, locale), oLower), oUpper);
/* 1239:     */             
/* 1240:1907 */             double dToleranceUpper = Math.max(Math.min(PlusCToolKitTOCommon.stringToDouble(toleranceUpper, locale), oUpper), oLower);
/* 1241:     */             
/* 1242:     */ 
/* 1243:     */ 
/* 1244:     */ 
/* 1245:     */ 
/* 1246:     */ 
/* 1247:     */ 
/* 1248:1915 */             auxTolLower = PlusCToolKitTOCommon.formatDouble(String.valueOf(dToleranceLower), 10, locale, true);
/* 1249:1916 */             auxTolUpper = PlusCToolKitTOCommon.formatDouble(String.valueOf(dToleranceUpper), 10, locale, true);
/* 1250:     */             
/* 1251:     */ 
/* 1252:     */ 
/* 1253:     */ 
/* 1254:1921 */             toleranceLower = PlusCToolKitTOCommon.formatDouble(String.valueOf(dToleranceLower), rightPrecision, locale, shouldRound);
/* 1255:1922 */             toleranceUpper = PlusCToolKitTOCommon.formatDouble(String.valueOf(dToleranceUpper), rightPrecision, locale, shouldRound);
/* 1256:     */           }
/* 1257:1926 */           toleranceLower = PlusCToolKitTOCommon.formatDoubleMax(toleranceLower, precision, locale, checkRoundUp, shouldRound);
/* 1258:1927 */           toleranceUpper = PlusCToolKitTOCommon.formatDoubleMax(toleranceUpper, precision, locale, checkRoundUp, shouldRound);
/* 1259:1928 */           auxTolLower = PlusCToolKitTOCommon.formatDoubleMax(auxTolLower, 10, locale, checkRoundUp, shouldRound);
/* 1260:1929 */           auxTolUpper = PlusCToolKitTOCommon.formatDoubleMax(auxTolUpper, 10, locale, checkRoundUp, shouldRound);
/* 1261:     */           
/* 1262:1931 */           DecimalFormatSymbols df = new DecimalFormatSymbols(locale);
/* 1263:1938 */           if ((owner instanceof PlusCWODSPointTO))
/* 1264:     */           {
/* 1265:1940 */             if (auxTolLower.length() > 10) {
/* 1266:1941 */               auxTolLower = auxTolLower.substring(0, 9);
/* 1267:     */             }
/* 1268:1943 */             if (auxTolUpper.length() > 10) {
/* 1269:1944 */               auxTolUpper = auxTolUpper.substring(0, 9);
/* 1270:     */             }
/* 1271:     */           }
/* 1272:1953 */           if (!sPrefix.equalsIgnoreCase(""))
/* 1273:     */           {
/* 1274:1957 */             auxTolLower = checkAndAdjustFldValueSize(auxTolLower, df, 10, locale);
/* 1275:1958 */             auxTolUpper = checkAndAdjustFldValueSize(auxTolUpper, df, 10, locale);
/* 1276:     */             
/* 1277:1960 */             owner.setValue(sPrefix + "tol" + tol + "lw_orig", auxTolLower, 9L);
/* 1278:     */             
/* 1279:1962 */             owner.setValue(sPrefix + "tol" + tol + "up_orig", auxTolUpper, 9L);
/* 1280:     */           }
/* 1281:1969 */           owner.setValue(sPrefix + "tol" + tol + "lower_np", toleranceLower, 9L);
/* 1282:     */           
/* 1283:1971 */           owner.setValue(sPrefix + "tol" + tol + "lower", toleranceLower, 9L);
/* 1284:     */           
/* 1285:1973 */           owner.setValue(sPrefix + "tol" + tol + "upper_np", toleranceUpper, 9L);
/* 1286:     */           
/* 1287:1975 */           owner.setValue(sPrefix + "tol" + tol + "upper", toleranceUpper, 9L);
/* 1288:     */         }
/* 1289:     */       }
/* 1290:     */       else
/* 1291:     */       {
/* 1292:1981 */         boolean summedTolDirectionBOTH = false;
/* 1293:1982 */         boolean summedTolDirectionPLUS = false;
/* 1294:1983 */         boolean summedTolDirectionMINUS = false;
/* 1295:     */         
/* 1296:1985 */         double sumTolEU = PlusCToolKitTOCommon.stringToDouble(owner.getString("tol" + tol + "sumeu") == null ? "0" : owner.getString("tol" + tol + "sumeu"), locale);
/* 1297:     */         
/* 1298:1987 */         double sumTolSPAN = PlusCToolKitTOCommon.stringToDouble(owner.getString("tol" + tol + "SumSpan") == null ? "0" : owner.getString("tol" + tol + "SumSpan"), locale);
/* 1299:     */         
/* 1300:1989 */         double sumTolURV = PlusCToolKitTOCommon.stringToDouble(owner.getString("tol" + tol + "SumURV") == null ? "0" : owner.getString("tol" + tol + "SumURV"), locale);
/* 1301:     */         
/* 1302:1991 */         double sumTolREADING = PlusCToolKitTOCommon.stringToDouble(owner.getString("tol" + tol + "SumRead") == null ? "0" : owner.getString("tol" + tol + "SumRead"), locale);
/* 1303:     */         
/* 1304:     */ 
/* 1305:     */ 
/* 1306:1995 */         String sumDirection = owner.getString("tol" + tol + "SUMDIRECTION");
/* 1307:2000 */         if (sumDirection.equals("+")) {
/* 1308:2001 */           summedTolDirectionPLUS = true;
/* 1309:2002 */         } else if (sumDirection.equals("-")) {
/* 1310:2003 */           summedTolDirectionMINUS = true;
/* 1311:2004 */         } else if (sumDirection.equals("+/-")) {
/* 1312:2005 */           summedTolDirectionBOTH = true;
/* 1313:     */         }
/* 1314:2010 */         double sumSummedTol = sumTolEU + sumTolSPAN + sumTolURV + sumTolREADING;
/* 1315:     */         
/* 1316:2012 */         sumSummedTol = Math.sqrt(sumSummedTol);
/* 1317:     */         
/* 1318:2014 */         String auxTolLower = "";
/* 1319:2015 */         String auxTolUpper = "";
/* 1320:2017 */         if ((summedTolDirectionMINUS) || (summedTolDirectionBOTH)) {
/* 1321:2018 */           sqrtFrom = sqrtToleranceSummed(i, iUpper, inputSpan, outputSpan, oLower, -sumTolEU, -sumTolSPAN, -sumTolURV, -sumTolREADING, -gbFrom);
/* 1322:     */         } else {
/* 1323:2022 */           sqrtFrom = desiredOutputValue;
/* 1324:     */         }
/* 1325:2025 */         if ((summedTolDirectionPLUS) || (summedTolDirectionBOTH)) {
/* 1326:2026 */           sqrtTo = sqrtToleranceSummed(i, iUpper, inputSpan, outputSpan, oLower, sumTolEU, sumTolSPAN, sumTolURV, sumTolREADING, gbTo);
/* 1327:     */         } else {
/* 1328:2030 */           sqrtTo = desiredOutputValue;
/* 1329:     */         }
/* 1330:2040 */         auxTolLower = PlusCToolKitTOCommon.formatDouble(String.valueOf(sqrtFrom), 10, locale, true);
/* 1331:2041 */         auxTolUpper = PlusCToolKitTOCommon.formatDouble(String.valueOf(sqrtTo), 10, locale, true);
/* 1332:     */         
/* 1333:     */ 
/* 1334:     */ 
/* 1335:     */ 
/* 1336:2046 */         toleranceLower = PlusCToolKitTOCommon.formatDouble(String.valueOf(sqrtFrom), rightPrecision, locale, shouldRound);
/* 1337:2047 */         toleranceUpper = PlusCToolKitTOCommon.formatDouble(String.valueOf(sqrtTo), rightPrecision, locale, shouldRound);
/* 1338:     */         
/* 1339:     */ 
/* 1340:2050 */         boolean bTrimTolerances = owner.getBoolean("CLIPLIMITS").booleanValue();
/* 1341:2052 */         if (bTrimTolerances)
/* 1342:     */         {
/* 1343:2054 */           double dToleranceLower = Math.min(Math.max(PlusCToolKitTOCommon.stringToDouble(toleranceLower, locale), oLower), oUpper);
/* 1344:     */           
/* 1345:     */ 
/* 1346:2057 */           double dToleranceUpper = Math.max(Math.min(PlusCToolKitTOCommon.stringToDouble(toleranceUpper, locale), oUpper), oLower);
/* 1347:     */           
/* 1348:     */ 
/* 1349:     */ 
/* 1350:     */ 
/* 1351:     */ 
/* 1352:     */ 
/* 1353:     */ 
/* 1354:     */ 
/* 1355:2066 */           auxTolLower = PlusCToolKitTOCommon.formatDouble(String.valueOf(dToleranceLower), 10, locale, true);
/* 1356:     */           
/* 1357:2068 */           auxTolUpper = PlusCToolKitTOCommon.formatDouble(String.valueOf(dToleranceUpper), 10, locale, true);
/* 1358:     */           
/* 1359:     */ 
/* 1360:     */ 
/* 1361:     */ 
/* 1362:     */ 
/* 1363:2074 */           toleranceLower = PlusCToolKitTOCommon.formatDouble(String.valueOf(dToleranceLower), rightPrecision, locale, shouldRound);
/* 1364:     */           
/* 1365:2076 */           toleranceUpper = PlusCToolKitTOCommon.formatDouble(String.valueOf(dToleranceUpper), rightPrecision, locale, shouldRound);
/* 1366:     */         }
/* 1367:2080 */         toleranceLower = PlusCToolKitTOCommon.formatDoubleMax(toleranceLower, precision, locale, checkRoundUp, shouldRound);
/* 1368:2081 */         toleranceUpper = PlusCToolKitTOCommon.formatDoubleMax(toleranceUpper, precision, locale, checkRoundUp, shouldRound);
/* 1369:2082 */         auxTolLower = PlusCToolKitTOCommon.formatDoubleMax(auxTolLower, 10, locale, checkRoundUp, shouldRound);
/* 1370:2083 */         auxTolUpper = PlusCToolKitTOCommon.formatDoubleMax(auxTolUpper, 10, locale, checkRoundUp, shouldRound);
/* 1371:     */         
/* 1372:     */ 
/* 1373:2086 */         DecimalFormatSymbols df = new DecimalFormatSymbols(locale);
/* 1374:2093 */         if ((owner instanceof PlusCWODSPointTO))
/* 1375:     */         {
/* 1376:2095 */           if (auxTolLower.length() > 10) {
/* 1377:2096 */             auxTolLower = auxTolLower.substring(0, 9);
/* 1378:     */           }
/* 1379:2098 */           if (auxTolUpper.length() > 10) {
/* 1380:2099 */             auxTolUpper = auxTolUpper.substring(0, 9);
/* 1381:     */           }
/* 1382:     */         }
/* 1383:2108 */         if (!sPrefix.equalsIgnoreCase(""))
/* 1384:     */         {
/* 1385:2111 */           auxTolLower = checkAndAdjustFldValueSize(auxTolLower, df, 10, locale);
/* 1386:2112 */           auxTolUpper = checkAndAdjustFldValueSize(auxTolUpper, df, 10, locale);
/* 1387:     */           
/* 1388:2114 */           owner.setValue(sPrefix + "tol" + tol + "lw_orig", auxTolLower, 9L);
/* 1389:     */           
/* 1390:2116 */           owner.setValue(sPrefix + "tol" + tol + "up_orig", auxTolUpper, 9L);
/* 1391:     */         }
/* 1392:2121 */         owner.setValue(sPrefix + "tol" + tol + "lower_np", toleranceLower, 9L);
/* 1393:     */         
/* 1394:2123 */         owner.setValue(sPrefix + "tol" + tol + "lower", toleranceLower, 9L);
/* 1395:2124 */         owner.setValue(sPrefix + "tol" + tol + "upper_np", toleranceUpper, 9L);
/* 1396:     */         
/* 1397:2126 */         owner.setValue(sPrefix + "tol" + tol + "upper", toleranceUpper, 9L);
/* 1398:     */       }
/* 1399:     */     }
/* 1400:2132 */     return true;
/* 1401:     */   }
/* 1402:     */   
/* 1403:     */   protected double sqrToleranceGeneral(double iUpper, double outputSpan, double oLower, double linearTol)
/* 1404:     */   {
/* 1405:2145 */     double sign = linearTol < 0.0D ? -1.0D : 1.0D;
/* 1406:2146 */     return oLower + sign * Math.sqrt(Math.abs(linearTol) / iUpper) * outputSpan;
/* 1407:     */   }
/* 1408:     */   
/* 1409:     */   protected double sqrtToleranceSummed(double i, double iUpper, double inputSpan, double outputSpan, double oLower, double sumTolEU, double sumTolSPAN, double sumTolURV, double sumTolREADING, double guardBand)
/* 1410:     */   {
/* 1411:2169 */     double linearTol = i + sumTolEU + sumTolSPAN * (inputSpan / 100.0D) + sumTolURV * (Math.abs(iUpper) / 100.0D) + sumTolREADING * (Math.abs(i) / 100.0D) + guardBand;
/* 1412:     */     
/* 1413:     */ 
/* 1414:     */ 
/* 1415:     */ 
/* 1416:     */ 
/* 1417:2175 */     return sqrToleranceGeneral(iUpper, outputSpan, oLower, linearTol);
/* 1418:     */   }
/* 1419:     */   
/* 1420:     */   protected double sqrtTolerancePercentReading(double i, double iUpper, double outputSpan, double oLower, double tol, double guardBand)
/* 1421:     */   {
/* 1422:2191 */     double linearTol = i + tol * (Math.abs(i) / 100.0D) + guardBand;
/* 1423:2192 */     return sqrToleranceGeneral(iUpper, outputSpan, oLower, linearTol);
/* 1424:     */   }
/* 1425:     */   
/* 1426:     */   protected double sqrtTolerancePercentURV(double i, double iUpper, double outputSpan, double oLower, double tol, double guardBand)
/* 1427:     */   {
/* 1428:2208 */     double linearTol = i + tol * (Math.abs(iUpper) / 100.0D) + guardBand;
/* 1429:2209 */     return sqrToleranceGeneral(iUpper, outputSpan, oLower, linearTol);
/* 1430:     */   }
/* 1431:     */   
/* 1432:     */   protected double sqrtTolerancePercentSpan(double i, double iUpper, double inputSpan, double outputSpan, double oLower, double tol, double guardBand)
/* 1433:     */   {
/* 1434:2225 */     double linearTol = i + tol * (inputSpan / 100.0D) + guardBand;
/* 1435:2226 */     return sqrToleranceGeneral(iUpper, outputSpan, oLower, linearTol);
/* 1436:     */   }
/* 1437:     */   
/* 1438:     */   protected double sqrtToleranceEU(double i, double iUpper, double outputSpan, double oLower, double tol, double guardBand)
/* 1439:     */   {
/* 1440:2241 */     double linearTol = i + tol + guardBand;
/* 1441:2242 */     return sqrToleranceGeneral(iUpper, outputSpan, oLower, linearTol);
/* 1442:     */   }
/* 1443:     */   
/* 1444:     */   public boolean calculateToleranceRangeSquared(PlusCMboRemote owner, String fieldName)
/* 1445:     */   {
/* 1446:2259 */     boolean shouldRound = !getTolTruncate();
/* 1447:2262 */     if (owner == null) {
/* 1448:2263 */       return false;
/* 1449:     */     }
/* 1450:2269 */     String auxTolLower = "";
/* 1451:2270 */     String auxTolUpper = "";
/* 1452:     */     
/* 1453:2272 */     Locale locale = owner.getLocale();
/* 1454:2275 */     for (int tol = 1; tol < 5; tol++)
/* 1455:     */     {
/* 1456:2276 */       String planType = owner.getString("plantype");
/* 1457:     */       
/* 1458:2278 */       String toltype = owner.getString("tol" + tol + "type");
/* 1459:2280 */       if (toltype.equals("")) {
/* 1460:2281 */         toltype = null;
/* 1461:     */       }
/* 1462:2287 */       String sPrefix = "";
/* 1463:2288 */       if ((fieldName.equalsIgnoreCase("ASFOUNDINPUT")) || (fieldName.equalsIgnoreCase("ASFOUNDSETPOINT"))) {
/* 1464:2290 */         sPrefix = "asfound";
/* 1465:     */       }
/* 1466:2293 */       if ((fieldName.equalsIgnoreCase("ASLEFTINPUT")) || (fieldName.equalsIgnoreCase("ASLEFTSETPOINT"))) {
/* 1467:2295 */         sPrefix = "asleft";
/* 1468:     */       }
/* 1469:2299 */       double iLower = PlusCToolKitTOCommon.stringToDouble(owner.getString("instrcalrangefrom"), locale);
/* 1470:2300 */       double iUpper = PlusCToolKitTOCommon.stringToDouble(owner.getString("instrcalrangeto"), locale);
/* 1471:2301 */       double inputSpan = iUpper - iLower;
/* 1472:2302 */       double outputSpan = PlusCToolKitTOCommon.stringToDouble(owner.getString("instroutrangeto"), locale) - PlusCToolKitTOCommon.stringToDouble(owner.getString("instroutrangefrom"), locale);
/* 1473:     */       
/* 1474:     */ 
/* 1475:2305 */       double oLower = PlusCToolKitTOCommon.stringToDouble(owner.getString("instroutrangefrom"), locale);
/* 1476:     */       
/* 1477:2307 */       double oUpper = PlusCToolKitTOCommon.stringToDouble(owner.getString("instroutrangeto"), locale);
/* 1478:2308 */       double tolLower = 0.0D;
/* 1479:2309 */       double tolUpper = 0.0D;
/* 1480:2310 */       if ((!owner.getString("tol" + tol + "lowervalue").equals("")) || (!owner.getString("tol" + tol + "uppervalue").equals("")))
/* 1481:     */       {
/* 1482:2312 */         tolLower = PlusCToolKitTOCommon.stringToDouble(owner.getString("tol" + tol + "lowervalue"), locale);
/* 1483:     */         
/* 1484:2314 */         tolUpper = PlusCToolKitTOCommon.stringToDouble(owner.getString("tol" + tol + "uppervalue"), locale);
/* 1485:     */       }
/* 1486:2317 */       int minOutputPrecision = owner.getInt("OUTPUTPRECISION").intValue();
/* 1487:2318 */       int actualInputPrecision = PlusCToolKitTOCommon.getDecimalDigits(sPrefix.equals("") ? owner.getString("INPUTVALUE") : owner.getString(sPrefix + "INPUT"));
/* 1488:     */       
/* 1489:     */ 
/* 1490:     */ 
/* 1491:2322 */       int actualOutputPrecision = PlusCToolKitTOCommon.getDecimalDigits(sPrefix.equals("") ? owner.getString("OUTPUTVALUE") : owner.getString(sPrefix + "OUTPUT"));
/* 1492:     */       
/* 1493:     */ 
/* 1494:     */ 
/* 1495:2326 */       int rightPrecision = getTolPrecision(minOutputPrecision, actualOutputPrecision, actualInputPrecision);
/* 1496:     */       
/* 1497:2328 */       double desiredOutputValue = 0.0D;
/* 1498:     */       double i;
/* 1499:     */       double i;
/* 1500:2333 */       if (!sPrefix.equals(""))
/* 1501:     */       {
/* 1502:2334 */         desiredOutputValue = PlusCToolKitTOCommon.stringToDouble(doWOUpdateOutputValue(owner, sPrefix), locale);
/* 1503:2335 */         i = PlusCToolKitTOCommon.stringToDouble(owner.getString(sPrefix + "input"), locale);
/* 1504:     */       }
/* 1505:     */       else
/* 1506:     */       {
/* 1507:2337 */         desiredOutputValue = PlusCToolKitTOCommon.stringToDouble(owner.getString("OUTPUTVALUE_NP"), locale);
/* 1508:2338 */         i = PlusCToolKitTOCommon.stringToDouble(owner.getString("inputvalue"), locale);
/* 1509:     */       }
/* 1510:2341 */       double sqrtFrom = 0.0D;
/* 1511:2342 */       double sqrtTo = 0.0D;
/* 1512:     */       
/* 1513:     */ 
/* 1514:     */ 
/* 1515:     */ 
/* 1516:2347 */       boolean calcSummedRDG = false;
/* 1517:2348 */       boolean calcSummedEU = false;
/* 1518:2349 */       boolean calcSummedSpan = false;
/* 1519:2350 */       boolean calcSummedURV = false;
/* 1520:     */       
/* 1521:     */ 
/* 1522:2353 */       String toleranceLower = "";
/* 1523:2354 */       String toleranceUpper = "";
/* 1524:2355 */       String sumEU = "";
/* 1525:2356 */       String sumRead = "";
/* 1526:2357 */       String sumSpan = "";
/* 1527:2358 */       String sumURV = "";
/* 1528:     */       
/* 1529:2360 */       boolean checkRoundUp = owner.isRoundUpField();
/* 1530:     */       
/* 1531:     */ 
/* 1532:2363 */       sumEU = owner.getString("tol" + tol + "sumeu");
/* 1533:2364 */       if ((sumEU == null) || (sumEU.equals(""))) {
/* 1534:2365 */         sumEU = "";
/* 1535:     */       } else {
/* 1536:2367 */         calcSummedEU = true;
/* 1537:     */       }
/* 1538:2370 */       sumRead = owner.getString("tol" + tol + "sumread");
/* 1539:2372 */       if ((sumRead == null) || (sumRead.equals(""))) {
/* 1540:2373 */         sumRead = "";
/* 1541:     */       } else {
/* 1542:2375 */         calcSummedRDG = true;
/* 1543:     */       }
/* 1544:2378 */       sumSpan = owner.getString("tol" + tol + "sumspan");
/* 1545:2380 */       if ((sumSpan == null) || (sumSpan.equals(""))) {
/* 1546:2381 */         sumSpan = "";
/* 1547:     */       } else {
/* 1548:2383 */         calcSummedSpan = true;
/* 1549:     */       }
/* 1550:2386 */       sumURV = owner.getString("tol" + tol + "sumurv");
/* 1551:2388 */       if ((sumURV == null) || (sumURV.equals(""))) {
/* 1552:2389 */         sumURV = "";
/* 1553:     */       } else {
/* 1554:2391 */         calcSummedURV = true;
/* 1555:     */       }
/* 1556:2394 */       double exp = 2.0D;
/* 1557:     */       
/* 1558:     */ 
/* 1559:2397 */       double gbFrom = 0.0D;
/* 1560:2398 */       double gbTo = 0.0D;
/* 1561:2399 */       if (!sPrefix.equals(""))
/* 1562:     */       {
/* 1563:2401 */         gbFrom = addGuardBand(owner, 0.0D, tol, "from", true, 0.0D, locale);
/* 1564:2402 */         gbTo = addGuardBand(owner, 0.0D, tol, "to", true, 0.0D, locale);
/* 1565:     */       }
/* 1566:2406 */       if ((!calcSummedEU) && (!calcSummedRDG) && (!calcSummedSpan) && (!calcSummedURV))
/* 1567:     */       {
/* 1568:2407 */         if ((toltype != null) && (planType.equalsIgnoreCase("ANALOG")))
/* 1569:     */         {
/* 1570:2409 */           if ((toltype.equals("EU")) || (!sumEU.equals("")))
/* 1571:     */           {
/* 1572:2413 */             sqrtFrom = Math.pow((i - iLower + tolLower + gbFrom) / inputSpan, exp) * outputSpan + oLower;
/* 1573:2414 */             sqrtTo = Math.pow((i - iLower + tolUpper + gbTo) / inputSpan, exp) * outputSpan + oLower;
/* 1574:     */           }
/* 1575:2415 */           else if ((toltype.equals("%SPAN")) || (!sumSpan.equals("")))
/* 1576:     */           {
/* 1577:2419 */             sqrtFrom = Math.pow((i - iLower + tolLower * (inputSpan / 100.0D) + gbFrom) / inputSpan, exp) * outputSpan + oLower;
/* 1578:2420 */             sqrtTo = Math.pow((i - iLower + tolUpper * (inputSpan / 100.0D) + gbTo) / inputSpan, exp) * outputSpan + oLower;
/* 1579:     */           }
/* 1580:2421 */           else if ((toltype.equals("%URV")) || (!sumURV.equals("")))
/* 1581:     */           {
/* 1582:2425 */             sqrtFrom = Math.pow((i - iLower + tolLower * (Math.abs(iUpper) / 100.0D) + gbFrom) / inputSpan, exp) * outputSpan + oLower;
/* 1583:2426 */             sqrtTo = Math.pow((i - iLower + tolUpper * (Math.abs(iUpper) / 100.0D) + gbTo) / inputSpan, exp) * outputSpan + oLower;
/* 1584:     */           }
/* 1585:2427 */           else if ((toltype.equals("%READING")) || (!sumRead.equals("")))
/* 1586:     */           {
/* 1587:2431 */             sqrtFrom = Math.pow((i - iLower + tolLower * (Math.abs(i) / 100.0D) + gbFrom) / inputSpan, exp) * outputSpan + oLower;
/* 1588:2432 */             sqrtTo = Math.pow((i - iLower + tolUpper * (Math.abs(i) / 100.0D) + gbTo) / inputSpan, exp) * outputSpan + oLower;
/* 1589:     */           }
/* 1590:2442 */           auxTolLower = PlusCToolKitTOCommon.formatDouble(String.valueOf(sqrtFrom), 10, locale, true);
/* 1591:2443 */           auxTolUpper = PlusCToolKitTOCommon.formatDouble(String.valueOf(sqrtTo), 10, locale, true);
/* 1592:     */           
/* 1593:     */ 
/* 1594:     */ 
/* 1595:     */ 
/* 1596:     */ 
/* 1597:2449 */           toleranceLower = PlusCToolKitTOCommon.formatDouble(String.valueOf(sqrtFrom), rightPrecision, locale, shouldRound);
/* 1598:2450 */           toleranceUpper = PlusCToolKitTOCommon.formatDouble(String.valueOf(sqrtTo), rightPrecision, locale, shouldRound);
/* 1599:     */           
/* 1600:     */ 
/* 1601:2453 */           boolean bTrimTolerances = owner.getBoolean("CLIPLIMITS").booleanValue();
/* 1602:2455 */           if (bTrimTolerances)
/* 1603:     */           {
/* 1604:2456 */             double dToleranceLower = Math.min(Math.max(PlusCToolKitTOCommon.stringToDouble(toleranceLower, locale), oLower), oUpper);
/* 1605:     */             
/* 1606:2458 */             double dToleranceUpper = Math.max(Math.min(PlusCToolKitTOCommon.stringToDouble(toleranceUpper, locale), oUpper), oLower);
/* 1607:     */             
/* 1608:     */ 
/* 1609:     */ 
/* 1610:     */ 
/* 1611:     */ 
/* 1612:     */ 
/* 1613:     */ 
/* 1614:2466 */             auxTolLower = PlusCToolKitTOCommon.formatDouble(String.valueOf(dToleranceLower), 10, locale, true);
/* 1615:2467 */             auxTolUpper = PlusCToolKitTOCommon.formatDouble(String.valueOf(dToleranceUpper), 10, locale, true);
/* 1616:     */             
/* 1617:     */ 
/* 1618:     */ 
/* 1619:     */ 
/* 1620:2472 */             toleranceLower = PlusCToolKitTOCommon.formatDouble(String.valueOf(dToleranceLower), rightPrecision, locale, shouldRound);
/* 1621:2473 */             toleranceUpper = PlusCToolKitTOCommon.formatDouble(String.valueOf(dToleranceUpper), rightPrecision, locale, shouldRound);
/* 1622:     */           }
/* 1623:2477 */           DecimalFormatSymbols df = new DecimalFormatSymbols(locale);
/* 1624:     */           
/* 1625:2479 */           String decimalSeparator = String.valueOf(df.getDecimalSeparator());
/* 1626:2480 */           String[] splitDecimals = PlusCToolKitTOCommon.split(toleranceLower, decimalSeparator);
/* 1627:2482 */           if (splitDecimals.length > 1)
/* 1628:     */           {
/* 1629:2483 */             if (splitDecimals[1].length() > rightPrecision)
/* 1630:     */             {
/* 1631:2489 */               auxTolLower = PlusCToolKitTOCommon.formatDouble(String.valueOf(toleranceLower), 10, locale, true);
/* 1632:     */               
/* 1633:     */ 
/* 1634:2492 */               toleranceLower = PlusCToolKitTOCommon.formatDoubleMax(toleranceLower, rightPrecision, locale, checkRoundUp, shouldRound);
/* 1635:     */               
/* 1636:     */ 
/* 1637:     */ 
/* 1638:2496 */               splitDecimals = PlusCToolKitTOCommon.split(toleranceLower, decimalSeparator);
/* 1639:2497 */               if (splitDecimals.length > 1)
/* 1640:     */               {
/* 1641:2498 */                 if (splitDecimals[1].length() < rightPrecision)
/* 1642:     */                 {
/* 1643:2505 */                   auxTolLower = PlusCToolKitTOCommon.formatDouble(String.valueOf(toleranceLower), 10, locale, true);
/* 1644:     */                   
/* 1645:     */ 
/* 1646:     */ 
/* 1647:     */ 
/* 1648:2510 */                   toleranceLower = PlusCToolKitTOCommon.formatDouble(String.valueOf(toleranceLower), rightPrecision, locale, shouldRound);
/* 1649:     */                 }
/* 1650:     */               }
/* 1651:     */               else
/* 1652:     */               {
/* 1653:2519 */                 auxTolLower = PlusCToolKitTOCommon.formatDouble(String.valueOf(toleranceLower), 10, locale, true);
/* 1654:2520 */                 auxTolUpper = PlusCToolKitTOCommon.formatDouble(String.valueOf(toleranceUpper), 10, locale, true);
/* 1655:     */                 
/* 1656:     */ 
/* 1657:     */ 
/* 1658:     */ 
/* 1659:2525 */                 toleranceLower = PlusCToolKitTOCommon.formatDouble(String.valueOf(toleranceLower), rightPrecision, locale, shouldRound);
/* 1660:2526 */                 toleranceUpper = PlusCToolKitTOCommon.formatDouble(String.valueOf(toleranceUpper), rightPrecision, locale, shouldRound);
/* 1661:     */               }
/* 1662:     */             }
/* 1663:2530 */             splitDecimals = PlusCToolKitTOCommon.split(toleranceUpper, decimalSeparator);
/* 1664:2532 */             if (splitDecimals[1].length() > rightPrecision)
/* 1665:     */             {
/* 1666:2539 */               auxTolUpper = PlusCToolKitTOCommon.formatDouble(String.valueOf(toleranceUpper), 10, locale, true);
/* 1667:     */               
/* 1668:     */ 
/* 1669:2542 */               toleranceUpper = PlusCToolKitTOCommon.formatDoubleMax(toleranceUpper, rightPrecision, locale, checkRoundUp, shouldRound);
/* 1670:2543 */               splitDecimals = PlusCToolKitTOCommon.split(toleranceUpper, decimalSeparator);
/* 1671:2544 */               if (splitDecimals.length > 1)
/* 1672:     */               {
/* 1673:2545 */                 if (splitDecimals[1].length() < rightPrecision)
/* 1674:     */                 {
/* 1675:2552 */                   auxTolUpper = PlusCToolKitTOCommon.formatDouble(String.valueOf(toleranceUpper), 10, locale, true);
/* 1676:     */                   
/* 1677:     */ 
/* 1678:     */ 
/* 1679:     */ 
/* 1680:2557 */                   toleranceUpper = PlusCToolKitTOCommon.formatDouble(String.valueOf(toleranceUpper), rightPrecision, locale, shouldRound);
/* 1681:     */                 }
/* 1682:     */               }
/* 1683:     */               else
/* 1684:     */               {
/* 1685:2566 */                 auxTolLower = PlusCToolKitTOCommon.formatDouble(String.valueOf(toleranceLower), 10, locale, true);
/* 1686:     */                 
/* 1687:2568 */                 auxTolUpper = PlusCToolKitTOCommon.formatDouble(String.valueOf(toleranceUpper), 10, locale, true);
/* 1688:     */                 
/* 1689:     */ 
/* 1690:     */ 
/* 1691:     */ 
/* 1692:     */ 
/* 1693:2574 */                 toleranceLower = PlusCToolKitTOCommon.formatDouble(String.valueOf(toleranceLower), rightPrecision, locale, shouldRound);
/* 1694:     */                 
/* 1695:2576 */                 toleranceUpper = PlusCToolKitTOCommon.formatDouble(String.valueOf(toleranceUpper), rightPrecision, locale, shouldRound);
/* 1696:     */               }
/* 1697:     */             }
/* 1698:     */           }
/* 1699:2586 */           if ((owner instanceof PlusCWODSPointTO))
/* 1700:     */           {
/* 1701:2588 */             if (auxTolLower.length() > 10) {
/* 1702:2589 */               auxTolLower = auxTolLower.substring(0, 9);
/* 1703:     */             }
/* 1704:2591 */             if (auxTolUpper.length() > 10) {
/* 1705:2592 */               auxTolUpper = auxTolUpper.substring(0, 9);
/* 1706:     */             }
/* 1707:     */           }
/* 1708:2601 */           if (!sPrefix.equalsIgnoreCase(""))
/* 1709:     */           {
/* 1710:2605 */             auxTolLower = checkAndAdjustFldValueSize(auxTolLower, df, 10, locale);
/* 1711:2606 */             auxTolUpper = checkAndAdjustFldValueSize(auxTolUpper, df, 10, locale);
/* 1712:     */             
/* 1713:2608 */             owner.setValue(sPrefix + "tol" + tol + "lw_orig", auxTolLower, 9L);
/* 1714:     */             
/* 1715:2610 */             owner.setValue(sPrefix + "tol" + tol + "up_orig", auxTolUpper, 9L);
/* 1716:     */           }
/* 1717:2617 */           owner.setValue(sPrefix + "tol" + tol + "lower_np", toleranceLower, 9L);
/* 1718:     */           
/* 1719:2619 */           owner.setValue(sPrefix + "tol" + tol + "lower", toleranceLower, 9L);
/* 1720:     */           
/* 1721:2621 */           owner.setValue(sPrefix + "tol" + tol + "upper_np", toleranceUpper, 9L);
/* 1722:     */           
/* 1723:2623 */           owner.setValue(sPrefix + "tol" + tol + "upper", toleranceUpper, 9L);
/* 1724:     */         }
/* 1725:     */       }
/* 1726:     */       else
/* 1727:     */       {
/* 1728:2629 */         boolean summedTolDirectionBOTH = false;
/* 1729:2630 */         boolean summedTolDirectionPLUS = false;
/* 1730:2631 */         boolean summedTolDirectionMINUS = false;
/* 1731:     */         
/* 1732:2633 */         double sumTolEU = PlusCToolKitTOCommon.stringToDouble(owner.getString("tol" + tol + "sumeu") == null ? "0" : owner.getString("tol" + tol + "sumeu"), locale);
/* 1733:     */         
/* 1734:2635 */         double sumTolSPAN = PlusCToolKitTOCommon.stringToDouble(owner.getString("tol" + tol + "SumSpan") == null ? "0" : owner.getString("tol" + tol + "SumSpan"), locale);
/* 1735:     */         
/* 1736:2637 */         double sumTolURV = PlusCToolKitTOCommon.stringToDouble(owner.getString("tol" + tol + "SumURV") == null ? "0" : owner.getString("tol" + tol + "SumURV"), locale);
/* 1737:     */         
/* 1738:2639 */         double sumTolREADING = PlusCToolKitTOCommon.stringToDouble(owner.getString("tol" + tol + "SumRead") == null ? "0" : owner.getString("tol" + tol + "SumRead"), locale);
/* 1739:     */         
/* 1740:     */ 
/* 1741:     */ 
/* 1742:2643 */         String sumDirection = owner.getString("tol" + tol + "SUMDIRECTION");
/* 1743:2648 */         if (sumDirection.equals("+")) {
/* 1744:2649 */           summedTolDirectionPLUS = true;
/* 1745:2650 */         } else if (sumDirection.equals("-")) {
/* 1746:2651 */           summedTolDirectionMINUS = true;
/* 1747:2652 */         } else if (sumDirection.equals("+/-")) {
/* 1748:2653 */           summedTolDirectionBOTH = true;
/* 1749:     */         }
/* 1750:2658 */         if ((summedTolDirectionPLUS) || (summedTolDirectionBOTH)) {
/* 1751:2661 */           sqrtTo = Math.pow((i - iLower + sumTolEU + sumTolSPAN * (inputSpan / 100.0D) + sumTolURV * (Math.abs(iUpper) / 100.0D) + sumTolREADING * (Math.abs(i) / 100.0D) + gbTo) / inputSpan, exp) * outputSpan + oLower;
/* 1752:     */         } else {
/* 1753:2675 */           sqrtTo = desiredOutputValue;
/* 1754:     */         }
/* 1755:2679 */         if ((summedTolDirectionMINUS) || (summedTolDirectionBOTH)) {
/* 1756:2682 */           sqrtFrom = Math.pow((i - iLower - sumTolEU - sumTolSPAN * (inputSpan / 100.0D) - sumTolURV * (Math.abs(iUpper) / 100.0D) - sumTolREADING * (Math.abs(i) / 100.0D) + gbFrom) / inputSpan, exp) * outputSpan + oLower;
/* 1757:     */         } else {
/* 1758:2696 */           sqrtFrom = desiredOutputValue;
/* 1759:     */         }
/* 1760:2766 */         auxTolLower = PlusCToolKitTOCommon.formatDouble(String.valueOf(sqrtFrom), 10, locale, true);
/* 1761:2767 */         auxTolUpper = PlusCToolKitTOCommon.formatDouble(String.valueOf(sqrtTo), 10, locale, true);
/* 1762:     */         
/* 1763:     */ 
/* 1764:     */ 
/* 1765:     */ 
/* 1766:2772 */         toleranceLower = PlusCToolKitTOCommon.formatDouble(String.valueOf(sqrtFrom), rightPrecision, locale, shouldRound);
/* 1767:2773 */         toleranceUpper = PlusCToolKitTOCommon.formatDouble(String.valueOf(sqrtTo), rightPrecision, locale, shouldRound);
/* 1768:     */         
/* 1769:     */ 
/* 1770:     */ 
/* 1771:2777 */         boolean bTrimTolerances = owner.getBoolean("CLIPLIMITS").booleanValue();
/* 1772:2779 */         if (bTrimTolerances)
/* 1773:     */         {
/* 1774:2781 */           double dToleranceLower = Math.min(Math.max(PlusCToolKitTOCommon.stringToDouble(toleranceLower, locale), oLower), oUpper);
/* 1775:     */           
/* 1776:     */ 
/* 1777:2784 */           double dToleranceUpper = Math.max(Math.min(PlusCToolKitTOCommon.stringToDouble(toleranceUpper, locale), oUpper), oLower);
/* 1778:     */           
/* 1779:     */ 
/* 1780:     */ 
/* 1781:     */ 
/* 1782:     */ 
/* 1783:     */ 
/* 1784:     */ 
/* 1785:     */ 
/* 1786:2793 */           auxTolLower = PlusCToolKitTOCommon.formatDouble(String.valueOf(dToleranceLower), 10, locale, true);
/* 1787:     */           
/* 1788:2795 */           auxTolUpper = PlusCToolKitTOCommon.formatDouble(String.valueOf(dToleranceUpper), 10, locale, true);
/* 1789:     */           
/* 1790:     */ 
/* 1791:     */ 
/* 1792:     */ 
/* 1793:     */ 
/* 1794:2801 */           toleranceLower = PlusCToolKitTOCommon.formatDouble(String.valueOf(dToleranceLower), rightPrecision, locale, shouldRound);
/* 1795:     */           
/* 1796:2803 */           toleranceUpper = PlusCToolKitTOCommon.formatDouble(String.valueOf(dToleranceUpper), rightPrecision, locale, shouldRound);
/* 1797:     */         }
/* 1798:2808 */         DecimalFormatSymbols df = new DecimalFormatSymbols(locale);
/* 1799:     */         
/* 1800:2810 */         String decimalSeparator = String.valueOf(df.getDecimalSeparator());
/* 1801:2811 */         String[] splitDecimals = PlusCToolKitTOCommon.split(toleranceLower, decimalSeparator);
/* 1802:2813 */         if (splitDecimals.length > 1)
/* 1803:     */         {
/* 1804:2815 */           if (splitDecimals[1].length() > rightPrecision)
/* 1805:     */           {
/* 1806:2821 */             auxTolLower = PlusCToolKitTOCommon.formatDouble(String.valueOf(toleranceLower), 10, locale, true);
/* 1807:     */             
/* 1808:     */ 
/* 1809:     */ 
/* 1810:2825 */             toleranceLower = PlusCToolKitTOCommon.formatDoubleMax(toleranceLower, rightPrecision, locale, checkRoundUp, shouldRound);
/* 1811:     */             
/* 1812:     */ 
/* 1813:     */ 
/* 1814:2829 */             splitDecimals = PlusCToolKitTOCommon.split(toleranceLower, decimalSeparator);
/* 1815:2830 */             if (splitDecimals.length > 1)
/* 1816:     */             {
/* 1817:2831 */               if (splitDecimals[1].length() < rightPrecision)
/* 1818:     */               {
/* 1819:2838 */                 auxTolLower = PlusCToolKitTOCommon.formatDouble(String.valueOf(toleranceLower), 10, locale, true);
/* 1820:     */                 
/* 1821:     */ 
/* 1822:     */ 
/* 1823:     */ 
/* 1824:     */ 
/* 1825:     */ 
/* 1826:     */ 
/* 1827:2846 */                 toleranceLower = PlusCToolKitTOCommon.formatDouble(String.valueOf(toleranceLower), rightPrecision, locale, shouldRound);
/* 1828:     */               }
/* 1829:     */             }
/* 1830:     */             else
/* 1831:     */             {
/* 1832:2857 */               auxTolLower = PlusCToolKitTOCommon.formatDouble(String.valueOf(toleranceLower), 10, locale, true);
/* 1833:     */               
/* 1834:2859 */               auxTolUpper = PlusCToolKitTOCommon.formatDouble(String.valueOf(toleranceUpper), 10, locale, true);
/* 1835:     */               
/* 1836:     */ 
/* 1837:     */ 
/* 1838:     */ 
/* 1839:     */ 
/* 1840:2865 */               toleranceLower = PlusCToolKitTOCommon.formatDouble(String.valueOf(toleranceLower), rightPrecision, locale, shouldRound);
/* 1841:     */               
/* 1842:     */ 
/* 1843:2868 */               toleranceUpper = PlusCToolKitTOCommon.formatDouble(String.valueOf(toleranceUpper), rightPrecision, locale, shouldRound);
/* 1844:     */             }
/* 1845:     */           }
/* 1846:2874 */           splitDecimals = PlusCToolKitTOCommon.split(toleranceUpper, decimalSeparator);
/* 1847:2876 */           if (splitDecimals[1].length() > rightPrecision)
/* 1848:     */           {
/* 1849:2882 */             auxTolUpper = PlusCToolKitTOCommon.formatDouble(String.valueOf(toleranceUpper), 10, locale, true);
/* 1850:     */             
/* 1851:     */ 
/* 1852:     */ 
/* 1853:2886 */             toleranceUpper = PlusCToolKitTOCommon.formatDoubleMax(toleranceUpper, rightPrecision, locale, checkRoundUp, shouldRound);
/* 1854:     */             
/* 1855:     */ 
/* 1856:2889 */             splitDecimals = PlusCToolKitTOCommon.split(toleranceUpper, decimalSeparator);
/* 1857:2891 */             if (splitDecimals.length > 1)
/* 1858:     */             {
/* 1859:2892 */               if (splitDecimals[1].length() < rightPrecision)
/* 1860:     */               {
/* 1861:2898 */                 auxTolUpper = PlusCToolKitTOCommon.formatDouble(String.valueOf(toleranceUpper), 10, locale, true);
/* 1862:     */                 
/* 1863:     */ 
/* 1864:     */ 
/* 1865:     */ 
/* 1866:     */ 
/* 1867:     */ 
/* 1868:     */ 
/* 1869:2906 */                 toleranceUpper = PlusCToolKitTOCommon.formatDouble(String.valueOf(toleranceUpper), rightPrecision, locale, shouldRound);
/* 1870:     */               }
/* 1871:     */             }
/* 1872:     */             else
/* 1873:     */             {
/* 1874:2917 */               auxTolLower = PlusCToolKitTOCommon.formatDouble(String.valueOf(toleranceLower), 10, locale, true);
/* 1875:     */               
/* 1876:2919 */               auxTolUpper = PlusCToolKitTOCommon.formatDouble(String.valueOf(toleranceUpper), 10, locale, true);
/* 1877:     */               
/* 1878:     */ 
/* 1879:     */ 
/* 1880:     */ 
/* 1881:     */ 
/* 1882:2925 */               toleranceLower = PlusCToolKitTOCommon.formatDouble(String.valueOf(toleranceLower), rightPrecision, locale, shouldRound);
/* 1883:     */               
/* 1884:     */ 
/* 1885:2928 */               toleranceUpper = PlusCToolKitTOCommon.formatDouble(String.valueOf(toleranceUpper), rightPrecision, locale, shouldRound);
/* 1886:     */             }
/* 1887:     */           }
/* 1888:     */         }
/* 1889:2939 */         if ((owner instanceof PlusCWODSPointTO))
/* 1890:     */         {
/* 1891:2941 */           if (auxTolLower.length() > 10) {
/* 1892:2942 */             auxTolLower = auxTolLower.substring(0, 9);
/* 1893:     */           }
/* 1894:2944 */           if (auxTolUpper.length() > 10) {
/* 1895:2945 */             auxTolUpper = auxTolUpper.substring(0, 9);
/* 1896:     */           }
/* 1897:     */         }
/* 1898:2954 */         if (!sPrefix.equalsIgnoreCase(""))
/* 1899:     */         {
/* 1900:2957 */           auxTolLower = checkAndAdjustFldValueSize(auxTolLower, df, 10, locale);
/* 1901:2958 */           auxTolUpper = checkAndAdjustFldValueSize(auxTolUpper, df, 10, locale);
/* 1902:     */           
/* 1903:2960 */           owner.setValue(sPrefix + "tol" + tol + "lw_orig", auxTolLower, 9L);
/* 1904:     */           
/* 1905:2962 */           owner.setValue(sPrefix + "tol" + tol + "up_orig", auxTolUpper, 9L);
/* 1906:     */         }
/* 1907:2967 */         owner.setValue(sPrefix + "tol" + tol + "lower_np", toleranceLower, 9L);
/* 1908:     */         
/* 1909:2969 */         owner.setValue(sPrefix + "tol" + tol + "lower", toleranceLower, 9L);
/* 1910:2970 */         owner.setValue(sPrefix + "tol" + tol + "upper_np", toleranceUpper, 9L);
/* 1911:     */         
/* 1912:2972 */         owner.setValue(sPrefix + "tol" + tol + "upper", toleranceUpper, 9L);
/* 1913:     */       }
/* 1914:     */     }
/* 1915:2978 */     return true;
/* 1916:     */   }
/* 1917:     */   
/* 1918:     */   public void calcPointRangeLimits(PlusCMboRemote mboRemote)
/* 1919:     */   {
/* 1920:2990 */     Locale locale = mboRemote.getLocale();
/* 1921:     */     
/* 1922:     */ 
/* 1923:2993 */     double input = PlusCToolKitTOCommon.stringToDouble(mboRemote.getString("inputvalue"), locale);
/* 1924:2994 */     double rangeLimitLower = PlusCToolKitTOCommon.stringToDouble(mboRemote.getString("RON1LOWERVALUE"), locale);
/* 1925:2995 */     double rangeLimitUpper = PlusCToolKitTOCommon.stringToDouble(mboRemote.getString("RON1UPPERVALUE"), locale);
/* 1926:2996 */     double inputLower = PlusCToolKitTOCommon.stringToDouble(mboRemote.getString("INSTRCALRANGEFROM"), locale);
/* 1927:2997 */     double inputUpper = PlusCToolKitTOCommon.stringToDouble(mboRemote.getString("INSTRCALRANGETO"), locale);
/* 1928:2998 */     double inputSpan = inputUpper - inputLower;
/* 1929:2999 */     String calcLimitLower = "";
/* 1930:3000 */     String calcLimitUpper = "";
/* 1931:3001 */     int precision = mboRemote.getInt("INPUTPRECISION").intValue();
/* 1932:3002 */     boolean checkRoundUp = mboRemote.isRoundUpField();
/* 1933:     */     
/* 1934:     */ 
/* 1935:3005 */     String ronType = mboRemote.getString("RON1TYPE");
/* 1936:3007 */     if (ronType == null) {
/* 1937:3008 */       ronType = "";
/* 1938:     */     }
/* 1939:3012 */     if (ronType.equals("EU"))
/* 1940:     */     {
/* 1941:3014 */       calcLimitLower = String.valueOf(input + rangeLimitLower);
/* 1942:     */       
/* 1943:3016 */       calcLimitUpper = String.valueOf(input + rangeLimitUpper);
/* 1944:     */     }
/* 1945:3018 */     else if (ronType.equals("%SPAN"))
/* 1946:     */     {
/* 1947:3020 */       calcLimitLower = String.valueOf(input + inputSpan / 100.0D * rangeLimitLower);
/* 1948:     */       
/* 1949:3022 */       calcLimitUpper = String.valueOf(input + inputSpan / 100.0D * rangeLimitUpper);
/* 1950:     */     }
/* 1951:3024 */     else if (ronType.equals("%URV"))
/* 1952:     */     {
/* 1953:3026 */       calcLimitLower = String.valueOf(input + Math.abs(inputUpper) / 100.0D * rangeLimitLower);
/* 1954:     */       
/* 1955:3028 */       calcLimitUpper = String.valueOf(input + Math.abs(inputUpper) / 100.0D * rangeLimitUpper);
/* 1956:     */     }
/* 1957:3030 */     else if (ronType.equals("%READING"))
/* 1958:     */     {
/* 1959:3032 */       calcLimitLower = String.valueOf(input + Math.abs(input) / 100.0D * rangeLimitLower);
/* 1960:     */       
/* 1961:3034 */       calcLimitUpper = String.valueOf(input + Math.abs(input) / 100.0D * rangeLimitUpper);
/* 1962:     */     }
/* 1963:3039 */     boolean bTrimTolerances = mboRemote.getBoolean("CLIPLIMITS").booleanValue();
/* 1964:3040 */     if (bTrimTolerances)
/* 1965:     */     {
/* 1966:3042 */       calcLimitLower = String.valueOf(Math.min(Math.max(Double.valueOf(calcLimitLower).doubleValue(), inputLower), inputUpper));
/* 1967:3043 */       calcLimitUpper = String.valueOf(Math.max(Math.min(Double.valueOf(calcLimitUpper).doubleValue(), inputUpper), input));
/* 1968:     */     }
/* 1969:3049 */     boolean shouldRound = !getRangeLimitsTruncate();
/* 1970:3050 */     calcLimitLower = PlusCToolKitTOCommon.formatDouble(String.valueOf(calcLimitLower), precision, locale, shouldRound);
/* 1971:3051 */     calcLimitUpper = PlusCToolKitTOCommon.formatDouble(String.valueOf(calcLimitUpper), precision, locale, shouldRound);
/* 1972:     */     
/* 1973:     */ 
/* 1974:     */ 
/* 1975:3055 */     mboRemote.setValue("RON1LOWER_np", calcLimitLower, 9L);
/* 1976:3056 */     mboRemote.setValue("RON1LOWER", calcLimitLower, 9L);
/* 1977:3057 */     mboRemote.setValue("RON1UPPER_np", calcLimitUpper, 9L);
/* 1978:3058 */     mboRemote.setValue("RON1UPPER", calcLimitUpper, 9L);
/* 1979:3059 */     mboRemote.setValue("RON1TYPE", ronType, 9L);
/* 1980:     */   }
/* 1981:     */   
/* 1982:     */   public boolean getRangeLimitsTruncate()
/* 1983:     */   {
/* 1984:3071 */     boolean shouldTruncate = true;
/* 1985:     */     
/* 1986:3073 */     shouldTruncate = Integer.parseInt((String)this.dsconfig.get("RANGETRUNCATE")) == 1;
/* 1987:     */     
/* 1988:3075 */     return shouldTruncate;
/* 1989:     */   }
/* 1990:     */   
/* 1991:     */   public boolean summedToleranceEquations(PlusCMboRemote owner, String fieldName, int tol, boolean[] summedCalcTypes)
/* 1992:     */   {
/* 1993:3097 */     boolean shouldRound = !getTolTruncate();
/* 1994:3100 */     if (owner == null) {
/* 1995:3101 */       return true;
/* 1996:     */     }
/* 1997:3104 */     String planType = owner.getString("plantype");
/* 1998:     */     
/* 1999:3106 */     boolean isOutputRangeLimit = owner.getBoolean("outputrange").booleanValue();
/* 2000:     */     
/* 2001:     */ 
/* 2002:     */ 
/* 2003:3110 */     double ISpanByOSpan = 0.0D;
/* 2004:3111 */     double summedToleranceFrom = 0.0D;
/* 2005:3112 */     double summedToleranceTo = 0.0D;
/* 2006:3113 */     double desiredOutputValue = 0.0D;
/* 2007:3114 */     Locale locale = owner.getLocale();
/* 2008:3115 */     double summedEUValue = 0.0D;
/* 2009:3116 */     double summedREADINGValue = 0.0D;
/* 2010:3117 */     double summedSPANValue = 0.0D;
/* 2011:3118 */     double summedURVValue = 0.0D;
/* 2012:     */     
/* 2013:     */ 
/* 2014:3121 */     boolean summedTolDirectionBOTH = false;
/* 2015:3122 */     boolean summedTolDirectionPLUS = false;
/* 2016:3123 */     boolean summedTolDirectionMINUS = false;
/* 2017:3124 */     boolean calcSummedEU = summedCalcTypes[0];
/* 2018:3125 */     boolean calcSummedRDG = summedCalcTypes[1];
/* 2019:3126 */     boolean calcSummedSpan = summedCalcTypes[2];
/* 2020:3127 */     boolean calcSummedURV = summedCalcTypes[3];
/* 2021:     */     
/* 2022:3129 */     String toleranceLower = "0.0000000000000";
/* 2023:3130 */     String toleranceUpper = "0.0000000000000";
/* 2024:     */     
/* 2025:3132 */     String sPrefix = "";
/* 2026:3134 */     if ((fieldName.equalsIgnoreCase("ASFOUNDINPUT")) || (fieldName.equalsIgnoreCase("ASFOUNDSETPOINT"))) {
/* 2027:3136 */       sPrefix = "asfound";
/* 2028:     */     }
/* 2029:3139 */     if ((fieldName.equalsIgnoreCase("ASLEFTINPUT")) || (fieldName.equalsIgnoreCase("ASLEFTSETPOINT"))) {
/* 2030:3141 */       sPrefix = "asleft";
/* 2031:     */     }
/* 2032:3144 */     int minOutputPrecision = owner.getInt("OUTPUTPRECISION").intValue();
/* 2033:3145 */     int actualInputPrecision = PlusCToolKitTOCommon.getDecimalDigits(sPrefix.equals("") ? owner.getString("INPUTVALUE") : owner.getString(sPrefix + "INPUT"));
/* 2034:     */     
/* 2035:     */ 
/* 2036:     */ 
/* 2037:3149 */     int actualOutputPrecision = PlusCToolKitTOCommon.getDecimalDigits(sPrefix.equals("") ? owner.getString("OUTPUTVALUE") : owner.getString(sPrefix + "OUTPUT"));
/* 2038:     */     
/* 2039:     */ 
/* 2040:     */ 
/* 2041:3153 */     int precision = minOutputPrecision;
/* 2042:3154 */     int rightPrecision = getTolPrecision(minOutputPrecision, actualOutputPrecision, actualInputPrecision);
/* 2043:     */     
/* 2044:3156 */     double equationSpecificVariable = 0.0D;
/* 2045:     */     
/* 2046:     */ 
/* 2047:3159 */     String sumDirection = owner.getString("tol" + tol + "SUMDIRECTION");
/* 2048:3160 */     if (sumDirection == null) {
/* 2049:3161 */       sumDirection = "";
/* 2050:     */     }
/* 2051:3165 */     sumDirection = owner.getString("tol" + tol + "SUMDIRECTION");
/* 2052:3167 */     if (sumDirection.equals("+")) {
/* 2053:3168 */       summedTolDirectionPLUS = true;
/* 2054:3169 */     } else if (sumDirection.equals("-")) {
/* 2055:3170 */       summedTolDirectionMINUS = true;
/* 2056:3171 */     } else if (sumDirection.equals("+/-")) {
/* 2057:3172 */       summedTolDirectionBOTH = true;
/* 2058:     */     }
/* 2059:3181 */     if (!sPrefix.equals("")) {
/* 2060:3182 */       desiredOutputValue = PlusCToolKitTOCommon.stringToDouble(doWOUpdateOutputValue(owner, sPrefix), locale);
/* 2061:     */     } else {
/* 2062:3185 */       desiredOutputValue = PlusCToolKitTOCommon.stringToDouble(owner.getString("OUTPUTVALUE_NP"), locale);
/* 2063:     */     }
/* 2064:3190 */     double inputFrom = 0.0D;
/* 2065:3191 */     double inputTo = 0.0D;
/* 2066:3192 */     double outputFrom = 0.0D;
/* 2067:3193 */     double outputTo = 0.0D;
/* 2068:     */     
/* 2069:3195 */     double[] verification = directionCheck(owner, locale);
/* 2070:3196 */     inputFrom = verification[0];
/* 2071:3197 */     inputTo = verification[1];
/* 2072:3198 */     outputFrom = verification[2];
/* 2073:3199 */     outputTo = verification[3];
/* 2074:3201 */     if (calcSummedEU) {
/* 2075:3204 */       if (isOutputRangeLimit)
/* 2076:     */       {
/* 2077:3208 */         summedEUValue = PlusCToolKitTOCommon.getDouble(owner.getString("tol" + tol + "sumeu"), locale);
/* 2078:     */       }
/* 2079:     */       else
/* 2080:     */       {
/* 2081:3212 */         double instrInputSpan = inputTo - inputFrom;
/* 2082:3213 */         double instrOutputSpan = outputTo - outputFrom;
/* 2083:3214 */         ISpanByOSpan = instrOutputSpan / instrInputSpan;
/* 2084:3215 */         double calcRangeDiff = PlusCToolKitTOCommon.getDouble(owner.getString("tol" + tol + "sumeu"), locale) * ISpanByOSpan;
/* 2085:     */         
/* 2086:     */ 
/* 2087:3218 */         summedEUValue = calcRangeDiff;
/* 2088:     */       }
/* 2089:     */     }
/* 2090:3226 */     if (!isOutputRangeLimit)
/* 2091:     */     {
/* 2092:3237 */       if (!sPrefix.equals("")) {
/* 2093:3238 */         desiredOutputValue = PlusCToolKitTOCommon.stringToDouble(doWOUpdateOutputValue(owner, sPrefix), locale);
/* 2094:     */       } else {
/* 2095:3241 */         desiredOutputValue = PlusCToolKitTOCommon.stringToDouble(owner.getString("OUTPUTVALUE_ROUNDING"), locale);
/* 2096:     */       }
/* 2097:3245 */       double instrInputSpan = inputTo - inputFrom;
/* 2098:3246 */       double instrOutputSpan = outputTo - outputFrom;
/* 2099:3247 */       ISpanByOSpan = instrOutputSpan / instrInputSpan;
/* 2100:3248 */       double calcRangeDiff = PlusCToolKitTOCommon.getDouble(owner.getString("tol" + tol + "sumeu"), locale) * ISpanByOSpan;
/* 2101:     */       
/* 2102:3250 */       summedEUValue = calcRangeDiff;
/* 2103:3253 */       if ((calcSummedSpan) && (planType.equalsIgnoreCase("ANALOG")))
/* 2104:     */       {
/* 2105:3254 */         equationSpecificVariable = inputTo - inputFrom;
/* 2106:     */         
/* 2107:3256 */         summedSPANValue = PlusCToolKitTOCommon.getDouble(owner.getString("tol" + tol + "SumSpan"), locale) * (equationSpecificVariable / 100.0D * ISpanByOSpan);
/* 2108:     */       }
/* 2109:3261 */       if ((calcSummedURV) && (planType.equalsIgnoreCase("ANALOG")))
/* 2110:     */       {
/* 2111:3262 */         equationSpecificVariable = inputTo;
/* 2112:     */         
/* 2113:3264 */         summedURVValue = PlusCToolKitTOCommon.getDouble(owner.getString("tol" + tol + "SumURV"), locale) * (Math.abs(equationSpecificVariable) / 100.0D * ISpanByOSpan);
/* 2114:     */       }
/* 2115:3270 */       if ((calcSummedRDG) && (planType.equalsIgnoreCase("ANALOG")))
/* 2116:     */       {
/* 2117:3271 */         if (!sPrefix.equals("")) {
/* 2118:3272 */           equationSpecificVariable = PlusCToolKitTOCommon.getDouble(owner.getString(sPrefix + "INPUT"), locale);
/* 2119:     */         } else {
/* 2120:3276 */           equationSpecificVariable = PlusCToolKitTOCommon.getDouble(owner.getString("INPUTVALUE"), locale);
/* 2121:     */         }
/* 2122:3282 */         summedREADINGValue = PlusCToolKitTOCommon.getDouble(owner.getString("tol" + tol + "SumRead"), locale) * (Math.abs(equationSpecificVariable) / 100.0D * ISpanByOSpan);
/* 2123:     */       }
/* 2124:     */     }
/* 2125:     */     else
/* 2126:     */     {
/* 2127:3292 */       if (!sPrefix.equals("")) {
/* 2128:3293 */         desiredOutputValue = PlusCToolKitTOCommon.stringToDouble(doWOUpdateOutputValue(owner, sPrefix), locale);
/* 2129:     */       } else {
/* 2130:3300 */         desiredOutputValue = PlusCToolKitTOCommon.stringToDouble(owner.getString("OUTPUTVALUE_ROUNDING"), locale);
/* 2131:     */       }
/* 2132:3306 */       if ((calcSummedSpan) && (planType.equalsIgnoreCase("ANALOG")))
/* 2133:     */       {
/* 2134:3307 */         equationSpecificVariable = outputTo - outputFrom;
/* 2135:     */         
/* 2136:3309 */         summedSPANValue = PlusCToolKitTOCommon.stringToDouble(owner.getString("tol" + tol + "SumSpan"), locale) * (equationSpecificVariable / 100.0D);
/* 2137:     */         
/* 2138:     */ 
/* 2139:3312 */         summedSPANValue = PlusCToolKitTOCommon.stringToDouble(PlusCToolKitTOCommon.formatDouble(String.valueOf(summedSPANValue), minOutputPrecision, locale, true), locale);
/* 2140:     */       }
/* 2141:3319 */       if ((calcSummedURV) && (planType.equalsIgnoreCase("ANALOG")))
/* 2142:     */       {
/* 2143:3320 */         equationSpecificVariable = outputTo;
/* 2144:     */         
/* 2145:3322 */         summedURVValue = PlusCToolKitTOCommon.stringToDouble(owner.getString("tol" + tol + "SumURV"), locale) * (Math.abs(equationSpecificVariable) / 100.0D);
/* 2146:     */       }
/* 2147:3328 */       if ((calcSummedRDG) && (planType.equalsIgnoreCase("ANALOG")))
/* 2148:     */       {
/* 2149:3330 */         if (!sPrefix.equals("")) {
/* 2150:3331 */           equationSpecificVariable = PlusCToolKitTOCommon.stringToDouble(PlusCToolKitTOCommon.formatDouble(doWOUpdateOutputValue(owner, sPrefix), minOutputPrecision, locale, true), locale);
/* 2151:     */         } else {
/* 2152:3335 */           equationSpecificVariable = PlusCToolKitTOCommon.stringToDouble(PlusCToolKitTOCommon.formatDouble(owner.getString("OUTPUTVALUE_ROUNDING"), minOutputPrecision, locale, true), locale);
/* 2153:     */         }
/* 2154:3340 */         summedREADINGValue = PlusCToolKitTOCommon.stringToDouble(owner.getString("tol" + tol + "SumRead"), locale) * (Math.abs(equationSpecificVariable) / 100.0D);
/* 2155:     */       }
/* 2156:     */     }
/* 2157:3348 */     double gbFrom = 0.0D;
/* 2158:3349 */     double gbTo = 0.0D;
/* 2159:3350 */     if (!sPrefix.equals(""))
/* 2160:     */     {
/* 2161:3351 */       gbFrom = addGuardBand(owner, 0.0D, tol, "from", isOutputRangeLimit, ISpanByOSpan, locale);
/* 2162:     */       
/* 2163:3353 */       gbTo = addGuardBand(owner, 0.0D, tol, "to", isOutputRangeLimit, ISpanByOSpan, locale);
/* 2164:     */     }
/* 2165:3359 */     if (summedTolDirectionMINUS)
/* 2166:     */     {
/* 2167:3360 */       summedToleranceFrom = desiredOutputValue - summedEUValue - summedSPANValue - summedURVValue - summedREADINGValue + gbFrom;
/* 2168:     */       
/* 2169:     */ 
/* 2170:3363 */       summedToleranceTo = desiredOutputValue;
/* 2171:     */     }
/* 2172:3364 */     else if (summedTolDirectionPLUS)
/* 2173:     */     {
/* 2174:3365 */       summedToleranceFrom = desiredOutputValue;
/* 2175:3366 */       summedToleranceTo = desiredOutputValue + summedEUValue + summedSPANValue + summedURVValue + summedREADINGValue + gbTo;
/* 2176:     */     }
/* 2177:3369 */     else if (summedTolDirectionBOTH)
/* 2178:     */     {
/* 2179:3370 */       summedToleranceFrom = desiredOutputValue - summedEUValue - summedSPANValue - summedURVValue - summedREADINGValue + gbFrom;
/* 2180:     */       
/* 2181:     */ 
/* 2182:3373 */       summedToleranceTo = desiredOutputValue + summedEUValue + summedSPANValue + summedURVValue + summedREADINGValue + gbTo;
/* 2183:     */     }
/* 2184:3382 */     String auxTolLower = PlusCToolKitTOCommon.formatDouble(String.valueOf(summedToleranceFrom), 10, locale, true);
/* 2185:     */     
/* 2186:3384 */     String auxTolUpper = PlusCToolKitTOCommon.formatDouble(String.valueOf(summedToleranceTo), 10, locale, true);
/* 2187:     */     
/* 2188:     */ 
/* 2189:     */ 
/* 2190:     */ 
/* 2191:     */ 
/* 2192:3390 */     toleranceLower = PlusCToolKitTOCommon.formatDouble(String.valueOf(summedToleranceFrom), rightPrecision, locale, shouldRound);
/* 2193:     */     
/* 2194:3392 */     toleranceUpper = PlusCToolKitTOCommon.formatDouble(String.valueOf(summedToleranceTo), rightPrecision, locale, shouldRound);
/* 2195:     */     
/* 2196:     */ 
/* 2197:     */ 
/* 2198:3396 */     boolean bTrimTolerances = owner.getBoolean("CLIPLIMITS").booleanValue();
/* 2199:3397 */     if (bTrimTolerances)
/* 2200:     */     {
/* 2201:3399 */       double dToleranceLower = Math.min(Math.max(summedToleranceFrom, outputFrom), outputTo);
/* 2202:     */       
/* 2203:3401 */       double dToleranceUpper = Math.max(Math.min(summedToleranceTo, outputTo), outputFrom);
/* 2204:     */       
/* 2205:     */ 
/* 2206:     */ 
/* 2207:     */ 
/* 2208:     */ 
/* 2209:     */ 
/* 2210:3408 */       auxTolLower = PlusCToolKitTOCommon.formatDouble(String.valueOf(dToleranceLower), 10, locale, true);
/* 2211:     */       
/* 2212:3410 */       auxTolUpper = PlusCToolKitTOCommon.formatDouble(String.valueOf(dToleranceUpper), 10, locale, true);
/* 2213:     */       
/* 2214:     */ 
/* 2215:     */ 
/* 2216:     */ 
/* 2217:     */ 
/* 2218:3416 */       toleranceLower = PlusCToolKitTOCommon.formatDouble(String.valueOf(dToleranceLower), rightPrecision, locale, shouldRound);
/* 2219:     */       
/* 2220:3418 */       toleranceUpper = PlusCToolKitTOCommon.formatDouble(String.valueOf(dToleranceUpper), rightPrecision, locale, shouldRound);
/* 2221:     */     }
/* 2222:3422 */     DecimalFormatSymbols df = new DecimalFormatSymbols(locale);
/* 2223:3423 */     String decimalSeparator = String.valueOf(df.getDecimalSeparator());
/* 2224:3424 */     String[] splitDecimals = PlusCToolKitTOCommon.split(toleranceLower, decimalSeparator);
/* 2225:3425 */     String[] splitDecimalsUpper = PlusCToolKitTOCommon.split(toleranceUpper, decimalSeparator);
/* 2226:3426 */     boolean splitLower = splitDecimals.length > 1;
/* 2227:3427 */     boolean splitUpper = splitDecimalsUpper.length > 1;
/* 2228:3428 */     boolean checkRoundUp = owner.isRoundUpField();
/* 2229:3429 */     if ((splitLower) || (splitUpper))
/* 2230:     */     {
/* 2231:3431 */       if ((splitLower) && 
/* 2232:3432 */         (splitDecimals[1].length() > precision))
/* 2233:     */       {
/* 2234:3436 */         toleranceLower = PlusCToolKitTOCommon.formatDoubleMax(toleranceLower, rightPrecision, locale, checkRoundUp, shouldRound);
/* 2235:     */         
/* 2236:     */ 
/* 2237:3439 */         splitDecimals = PlusCToolKitTOCommon.split(toleranceLower, decimalSeparator);
/* 2238:3440 */         if (splitDecimals.length > 1)
/* 2239:     */         {
/* 2240:3441 */           if (splitDecimals[1].length() < precision)
/* 2241:     */           {
/* 2242:3447 */             auxTolLower = PlusCToolKitTOCommon.formatDouble(String.valueOf(toleranceLower), 10, locale, true);
/* 2243:     */             
/* 2244:     */ 
/* 2245:     */ 
/* 2246:     */ 
/* 2247:     */ 
/* 2248:3453 */             toleranceLower = PlusCToolKitTOCommon.formatDouble(String.valueOf(toleranceLower), rightPrecision, locale, shouldRound);
/* 2249:     */           }
/* 2250:     */         }
/* 2251:     */         else
/* 2252:     */         {
/* 2253:3463 */           auxTolLower = PlusCToolKitTOCommon.formatDouble(String.valueOf(toleranceLower), 10, locale, true);
/* 2254:     */           
/* 2255:3465 */           auxTolUpper = PlusCToolKitTOCommon.formatDouble(String.valueOf(toleranceUpper), 10, locale, true);
/* 2256:     */           
/* 2257:     */ 
/* 2258:     */ 
/* 2259:     */ 
/* 2260:     */ 
/* 2261:3471 */           toleranceLower = PlusCToolKitTOCommon.formatDouble(String.valueOf(toleranceLower), rightPrecision, locale, shouldRound);
/* 2262:     */           
/* 2263:     */ 
/* 2264:3474 */           toleranceUpper = PlusCToolKitTOCommon.formatDouble(String.valueOf(toleranceUpper), rightPrecision, locale, shouldRound);
/* 2265:     */         }
/* 2266:     */       }
/* 2267:3481 */       splitDecimals = PlusCToolKitTOCommon.split(toleranceUpper, decimalSeparator);
/* 2268:3483 */       if (toleranceUpper.indexOf(decimalSeparator) != -1) {
/* 2269:3485 */         if (splitDecimals[1].length() > precision)
/* 2270:     */         {
/* 2271:3489 */           toleranceUpper = PlusCToolKitTOCommon.formatDoubleMax(toleranceUpper, rightPrecision, locale, checkRoundUp, shouldRound);
/* 2272:     */           
/* 2273:3491 */           splitDecimals = PlusCToolKitTOCommon.split(toleranceUpper, decimalSeparator);
/* 2274:3492 */           if (splitDecimals.length > 1)
/* 2275:     */           {
/* 2276:3493 */             if (splitDecimals[1].length() < precision)
/* 2277:     */             {
/* 2278:3498 */               auxTolUpper = PlusCToolKitTOCommon.formatDouble(String.valueOf(toleranceUpper), 10, locale, true);
/* 2279:     */               
/* 2280:     */ 
/* 2281:     */ 
/* 2282:     */ 
/* 2283:3503 */               toleranceUpper = PlusCToolKitTOCommon.formatDouble(String.valueOf(toleranceUpper), rightPrecision, locale, shouldRound);
/* 2284:     */             }
/* 2285:     */           }
/* 2286:     */           else
/* 2287:     */           {
/* 2288:3513 */             auxTolLower = PlusCToolKitTOCommon.formatDouble(String.valueOf(toleranceLower), 10, locale, true);
/* 2289:     */             
/* 2290:3515 */             auxTolUpper = PlusCToolKitTOCommon.formatDouble(String.valueOf(toleranceUpper), 10, locale, true);
/* 2291:     */             
/* 2292:     */ 
/* 2293:     */ 
/* 2294:     */ 
/* 2295:     */ 
/* 2296:3521 */             toleranceLower = PlusCToolKitTOCommon.formatDouble(String.valueOf(toleranceLower), rightPrecision, locale, shouldRound);
/* 2297:     */             
/* 2298:     */ 
/* 2299:3524 */             toleranceUpper = PlusCToolKitTOCommon.formatDouble(String.valueOf(toleranceUpper), rightPrecision, locale, shouldRound);
/* 2300:     */           }
/* 2301:     */         }
/* 2302:     */       }
/* 2303:     */     }
/* 2304:3536 */     if ((owner instanceof PlusCWODSPointTO))
/* 2305:     */     {
/* 2306:3538 */       if (auxTolLower.length() > 10) {
/* 2307:3539 */         auxTolLower = auxTolLower.substring(0, 9);
/* 2308:     */       }
/* 2309:3541 */       if (auxTolUpper.length() > 10) {
/* 2310:3542 */         auxTolUpper = auxTolUpper.substring(0, 9);
/* 2311:     */       }
/* 2312:     */     }
/* 2313:3550 */     if (!sPrefix.equalsIgnoreCase(""))
/* 2314:     */     {
/* 2315:3553 */       auxTolLower = checkAndAdjustFldValueSize(auxTolLower, df, 10, locale);
/* 2316:3554 */       auxTolUpper = checkAndAdjustFldValueSize(auxTolUpper, df, 10, locale);
/* 2317:     */       
/* 2318:3556 */       owner.setValue(sPrefix + "tol" + tol + "lw_orig", auxTolLower, 9L);
/* 2319:3557 */       owner.setValue(sPrefix + "tol" + tol + "up_orig", auxTolUpper, 9L);
/* 2320:     */     }
/* 2321:3562 */     owner.setValue(sPrefix + "tol" + tol + "lower", toleranceLower, 9L);
/* 2322:3563 */     owner.setValue(sPrefix + "tol" + tol + "lower_NP", toleranceLower, 9L);
/* 2323:3564 */     owner.setValue(sPrefix + "tol" + tol + "upper_NP", toleranceUpper, 9L);
/* 2324:3565 */     owner.setValue(sPrefix + "tol" + tol + "upper", toleranceUpper, 9L);
/* 2325:     */     
/* 2326:3567 */     return true;
/* 2327:     */   }
/* 2328:     */   
/* 2329:     */   public static double[] directionCheck(PlusCMboRemote owner, Locale locale)
/* 2330:     */   {
/* 2331:3578 */     double inputFrom = 0.0D;
/* 2332:3579 */     double inputTo = 0.0D;
/* 2333:3580 */     double outputFrom = 0.0D;
/* 2334:3581 */     double outputTo = 0.0D;
/* 2335:     */     
/* 2336:3583 */     double instrCalRangeFrom = PlusCToolKitTOCommon.getDouble(owner.getString("instrcalrangefrom"), locale);
/* 2337:3584 */     double instrCalRangeTo = PlusCToolKitTOCommon.getDouble(owner.getString("instrcalrangeto"), locale);
/* 2338:3585 */     double instrOutRangeFrom = PlusCToolKitTOCommon.getDouble(owner.getString("instroutrangefrom"), locale);
/* 2339:3586 */     double instrOutRangeTo = PlusCToolKitTOCommon.getDouble(owner.getString("instroutrangeto"), locale);
/* 2340:3588 */     if ((instrCalRangeFrom - instrCalRangeTo < 0.0D) && (instrOutRangeFrom - instrOutRangeTo >= 0.0D))
/* 2341:     */     {
/* 2342:3591 */       inputFrom = instrCalRangeFrom;
/* 2343:3592 */       inputTo = instrCalRangeTo;
/* 2344:3593 */       outputFrom = instrOutRangeTo;
/* 2345:3594 */       outputTo = instrOutRangeFrom;
/* 2346:     */     }
/* 2347:3595 */     else if ((instrCalRangeFrom - instrCalRangeTo > 0.0D) && (instrOutRangeFrom - instrOutRangeTo <= 0.0D))
/* 2348:     */     {
/* 2349:3598 */       inputFrom = instrCalRangeTo;
/* 2350:3599 */       inputTo = instrCalRangeFrom;
/* 2351:3600 */       outputFrom = instrOutRangeFrom;
/* 2352:3601 */       outputTo = instrOutRangeTo;
/* 2353:     */     }
/* 2354:3602 */     else if ((instrCalRangeFrom - instrCalRangeTo > 0.0D) && (instrOutRangeFrom - instrOutRangeTo >= 0.0D))
/* 2355:     */     {
/* 2356:3605 */       inputFrom = instrCalRangeTo;
/* 2357:3606 */       inputTo = instrCalRangeFrom;
/* 2358:3607 */       outputFrom = instrOutRangeTo;
/* 2359:3608 */       outputTo = instrOutRangeFrom;
/* 2360:     */     }
/* 2361:     */     else
/* 2362:     */     {
/* 2363:3611 */       inputFrom = instrCalRangeFrom;
/* 2364:3612 */       inputTo = instrCalRangeTo;
/* 2365:3613 */       outputFrom = instrOutRangeFrom;
/* 2366:3614 */       outputTo = instrOutRangeTo;
/* 2367:     */     }
/* 2368:3616 */     return new double[] { inputFrom, inputTo, outputFrom, outputTo };
/* 2369:     */   }
/* 2370:     */   
/* 2371:     */   public void doUpdateOutputValue(PlusCMboRemote mboRemote, boolean bValidateWhenSetting)
/* 2372:     */   {
/* 2373:3629 */     if (mboRemote.isNull("inputvalue")) {
/* 2374:3630 */       return;
/* 2375:     */     }
/* 2376:3633 */     PlusCMboRemote owner = mboRemote;
/* 2377:3634 */     Locale locale = owner.getLocale();
/* 2378:     */     
/* 2379:3636 */     int minInputFraction = owner.getInt("INPUTPRECISION").intValue();
/* 2380:3637 */     int minOutputFraction = owner.getInt("OUTPUTPRECISION").intValue();
/* 2381:     */     
/* 2382:3639 */     String instrcalrangefrom = String.valueOf(PlusCToolKitTOCommon.stringToDouble(PlusCToolKitTOCommon.convertNumberToRightLocale(owner.getString("instrcalrangefrom"), locale), locale));
/* 2383:     */     
/* 2384:     */ 
/* 2385:3642 */     String instrcalrangeto = String.valueOf(PlusCToolKitTOCommon.stringToDouble(PlusCToolKitTOCommon.convertNumberToRightLocale(owner.getString("instrcalrangeto"), locale), locale));
/* 2386:     */     
/* 2387:     */ 
/* 2388:     */ 
/* 2389:3646 */     double resultSpan1 = new Double(instrcalrangeto).doubleValue() - new Double(instrcalrangefrom).doubleValue();
/* 2390:     */     
/* 2391:     */ 
/* 2392:3649 */     String instroutrangefrom = String.valueOf(PlusCToolKitTOCommon.stringToDouble(PlusCToolKitTOCommon.convertNumberToRightLocale(owner.getString("instroutrangefrom"), locale), locale));
/* 2393:     */     
/* 2394:     */ 
/* 2395:3652 */     String instroutrangeto = String.valueOf(PlusCToolKitTOCommon.stringToDouble(PlusCToolKitTOCommon.convertNumberToRightLocale(owner.getString("instroutrangeto"), locale), locale));
/* 2396:     */     
/* 2397:     */ 
/* 2398:     */ 
/* 2399:3656 */     double resultSpan2 = new Double(instroutrangeto).doubleValue() - new Double(instroutrangefrom).doubleValue();
/* 2400:     */     
/* 2401:3658 */     String instrOutputSpan = String.valueOf(resultSpan2);
/* 2402:     */     
/* 2403:     */ 
/* 2404:3661 */     String formatedInputValue = "";
/* 2405:3662 */     double dInvalue = PlusCToolKitTOCommon.stringToDouble(PlusCToolKitTOCommon.convertNumberToRightLocale(mboRemote.getString("inputvalue"), locale), locale);
/* 2406:     */     
/* 2407:     */ 
/* 2408:3665 */     double dInstrcalrangefrom = PlusCToolKitTOCommon.stringToDouble(PlusCToolKitTOCommon.convertNumberToRightLocale(owner.getString("instrcalrangefrom"), locale), locale);
/* 2409:     */     
/* 2410:     */ 
/* 2411:3668 */     double dInstrcalrangeto = PlusCToolKitTOCommon.stringToDouble(PlusCToolKitTOCommon.convertNumberToRightLocale(owner.getString("instrcalrangeto"), locale), locale);
/* 2412:     */     
/* 2413:     */ 
/* 2414:     */ 
/* 2415:3672 */     double dInstroutrangefrom = PlusCToolKitTOCommon.stringToDouble(PlusCToolKitTOCommon.convertNumberToRightLocale(owner.getString("instroutrangefrom"), locale), locale);
/* 2416:     */     
/* 2417:     */ 
/* 2418:3675 */     double dInstroutrangeto = PlusCToolKitTOCommon.stringToDouble(PlusCToolKitTOCommon.convertNumberToRightLocale(owner.getString("instroutrangeto"), locale), locale);
/* 2419:     */     
/* 2420:     */ 
/* 2421:     */ 
/* 2422:3679 */     String desiredOutputValue = "";
/* 2423:3680 */     String invalue = String.valueOf(dInvalue);
/* 2424:3681 */     int square = 0;
/* 2425:     */     
/* 2426:3683 */     square = owner.getBoolean("squared").booleanValue() ? 2 : owner.getBoolean("squareroot").booleanValue() ? 1 : 0;
/* 2427:3685 */     if (square > 0)
/* 2428:     */     {
/* 2429:3686 */       double d = dInvalue;
/* 2430:3687 */       int negZeroPos = 1;
/* 2431:3689 */       if (invalue.startsWith("-"))
/* 2432:     */       {
/* 2433:3690 */         invalue = invalue.substring(1);
/* 2434:3691 */         negZeroPos = -1;
/* 2435:     */       }
/* 2436:3692 */       else if (d == 0.0D)
/* 2437:     */       {
/* 2438:3693 */         negZeroPos = 0;
/* 2439:     */       }
/* 2440:3696 */       if (negZeroPos == -1) {
/* 2441:3698 */         switch (square)
/* 2442:     */         {
/* 2443:     */         case 1: 
/* 2444:3701 */           desiredOutputValue = squareRootOutputValueNegative(locale, instrcalrangeto, instroutrangefrom, instrOutputSpan, invalue);
/* 2445:3702 */           break;
/* 2446:     */         case 2: 
/* 2447:3704 */           desiredOutputValue = squaredOutputValueNegative(locale, instrcalrangefrom, instrcalrangeto, instroutrangefrom, instrOutputSpan, invalue, owner.getInt("OUTPUTPRECISION").intValue());
/* 2448:3705 */           break;
/* 2449:     */         }
/* 2450:3709 */       } else if (negZeroPos == 0) {
/* 2451:3710 */         desiredOutputValue = instroutrangefrom;
/* 2452:     */       } else {
/* 2453:3713 */         switch (square)
/* 2454:     */         {
/* 2455:     */         case 1: 
/* 2456:3716 */           desiredOutputValue = squareRootDesiredOutputValue(owner);
/* 2457:3717 */           break;
/* 2458:     */         case 2: 
/* 2459:3719 */           desiredOutputValue = squaredDesiredOutputValue(owner);
/* 2460:3720 */           break;
/* 2461:     */         }
/* 2462:     */       }
/* 2463:     */     }
/* 2464:3730 */     else if (((dInstrcalrangefrom - dInstrcalrangeto < 0.0D) && (dInstroutrangefrom - dInstroutrangeto <= 0.0D)) || ((dInstrcalrangefrom - dInstrcalrangeto > 0.0D) && (dInstroutrangefrom - dInstroutrangeto >= 0.0D)))
/* 2465:     */     {
/* 2466:3736 */       desiredOutputValue = String.valueOf((dInvalue - dInstrcalrangefrom) * (resultSpan2 / resultSpan1) + dInstroutrangefrom);
/* 2467:     */     }
/* 2468:3741 */     else if (((dInstrcalrangefrom - dInstrcalrangeto < 0.0D) && (dInstroutrangefrom - dInstroutrangeto >= 0.0D)) || ((dInstrcalrangefrom - dInstrcalrangeto > 0.0D) && (dInstroutrangefrom - dInstroutrangeto <= 0.0D)))
/* 2469:     */     {
/* 2470:3747 */       desiredOutputValue = String.valueOf(dInstroutrangefrom - (dInvalue - dInstrcalrangefrom) * ((dInstroutrangefrom - dInstroutrangeto) / resultSpan1));
/* 2471:     */     }
/* 2472:3755 */     if ((mboRemote instanceof PlusCDSPointTO))
/* 2473:     */     {
/* 2474:3756 */       String numberAux = "";
/* 2475:3758 */       if (PlusCToolKitTOCommon.formatDouble(desiredOutputValue, 10, locale, true).length() > 10)
/* 2476:     */       {
/* 2477:3759 */         numberAux = PlusCToolKitTOCommon.formatDouble(desiredOutputValue, 10, locale, true).substring(0, 9);
/* 2478:     */         
/* 2479:3761 */         mboRemote.setValue("OUTPUTVALUE_ROUNDING", numberAux, 11L);
/* 2480:     */       }
/* 2481:     */       else
/* 2482:     */       {
/* 2483:3763 */         mboRemote.setValue("OUTPUTVALUE_ROUNDING", PlusCToolKitTOCommon.formatDouble(desiredOutputValue, 10, locale, true), 11L);
/* 2484:     */       }
/* 2485:     */     }
/* 2486:3768 */     boolean shouldRoundDesiredOutput = !getDesiredOutputTruncate();
/* 2487:3769 */     desiredOutputValue = PlusCToolKitTOCommon.formatDouble(desiredOutputValue, minOutputFraction, locale, shouldRoundDesiredOutput);
/* 2488:3770 */     String _inValue = String.valueOf(dInvalue);
/* 2489:3773 */     if (PlusCToolKitTOCommon.getDecimalDigits(_inValue) <= minInputFraction) {
/* 2490:3774 */       formatedInputValue = PlusCToolKitTOCommon.formatDouble(_inValue, minInputFraction, locale, false);
/* 2491:     */     } else {
/* 2492:3776 */       formatedInputValue = PlusCToolKitTOCommon.formatDouble(_inValue, locale);
/* 2493:     */     }
/* 2494:3779 */     DecimalFormatSymbols df = new DecimalFormatSymbols(locale);
/* 2495:3780 */     String decimalSeparator = String.valueOf(df.getDecimalSeparator()).trim();
/* 2496:3781 */     String[] splitDecimals = PlusCToolKitTOCommon.split(desiredOutputValue, decimalSeparator);
/* 2497:3783 */     if ((splitDecimals.length > 1) && 
/* 2498:3784 */       (splitDecimals[1].length() > minOutputFraction)) {
/* 2499:3785 */       desiredOutputValue = PlusCToolKitTOCommon.formatDoubleMax(desiredOutputValue, minOutputFraction, locale);
/* 2500:     */     }
/* 2501:3788 */     if (bValidateWhenSetting)
/* 2502:     */     {
/* 2503:3790 */       mboRemote.setValue("INPUTVALUE_NP", String.valueOf(formatedInputValue), 9L);
/* 2504:     */       
/* 2505:3792 */       mboRemote.setValue("OUTPUTVALUE_NP", String.valueOf(desiredOutputValue), 9L);
/* 2506:3797 */       if (desiredOutputValue.indexOf(decimalSeparator) >= 0)
/* 2507:     */       {
/* 2508:3798 */         int dec = PlusCToolKitTOCommon.getDecimalDigits(desiredOutputValue);
/* 2509:3800 */         if (dec < 10) {
/* 2510:3801 */           mboRemote.setValue("OUTPUTVALUE", desiredOutputValue + "0");
/* 2511:     */         } else {
/* 2512:3803 */           mboRemote.setValue("OUTPUTVALUE", desiredOutputValue);
/* 2513:     */         }
/* 2514:     */       }
/* 2515:     */       else
/* 2516:     */       {
/* 2517:3807 */         mboRemote.setValue("OUTPUTVALUE", desiredOutputValue + decimalSeparator + "0");
/* 2518:     */       }
/* 2519:     */     }
/* 2520:     */     else
/* 2521:     */     {
/* 2522:3812 */       mboRemote.setValue("OUTPUTVALUE", desiredOutputValue, 9L);
/* 2523:3813 */       mboRemote.setValue("OUTPUTVALUE_NP", desiredOutputValue, 9L);
/* 2524:     */     }
/* 2525:3818 */     if ((!mboRemote.isNull("INPUTVALUE")) && (!mboRemote.isNull("RON1LOWERVALUE")) && (!mboRemote.isNull("RON1UPPERVALUE")) && (!mboRemote.isNull("RON1TYPE"))) {
/* 2526:3822 */       calcPointRangeLimits(mboRemote);
/* 2527:     */     }
/* 2528:     */   }
/* 2529:     */   
/* 2530:     */   public String doWOUpdateOutputValue(PlusCMboRemote owner, String sPrefix)
/* 2531:     */   {
/* 2532:3835 */     if (owner.isNull(sPrefix + "input_np")) {
/* 2533:3836 */       return "";
/* 2534:     */     }
/* 2535:3838 */     Locale locale = owner.getLocale();
/* 2536:     */     
/* 2537:3840 */     String instrcalrangefrom = String.valueOf(PlusCToolKitTOCommon.stringToDouble(PlusCToolKitTOCommon.convertNumberToRightLocale(owner.getString("instrcalrangefrom"), locale), locale));
/* 2538:3841 */     String instrcalrangeto = String.valueOf(PlusCToolKitTOCommon.stringToDouble(PlusCToolKitTOCommon.convertNumberToRightLocale(owner.getString("instrcalrangeto"), locale), locale));
/* 2539:     */     
/* 2540:3843 */     double resultSpan1 = new Double(instrcalrangeto).doubleValue() - new Double(instrcalrangefrom).doubleValue();
/* 2541:     */     
/* 2542:3845 */     String instroutrangefrom = String.valueOf(PlusCToolKitTOCommon.stringToDouble(PlusCToolKitTOCommon.convertNumberToRightLocale(owner.getString("instroutrangefrom"), locale), locale));
/* 2543:3846 */     String instroutrangeto = String.valueOf(PlusCToolKitTOCommon.stringToDouble(PlusCToolKitTOCommon.convertNumberToRightLocale(owner.getString("instroutrangeto"), locale), locale));
/* 2544:     */     
/* 2545:3848 */     double resultSpan2 = new Double(instroutrangeto).doubleValue() - new Double(instroutrangefrom).doubleValue();
/* 2546:3849 */     String instrOutputSpan = String.valueOf(resultSpan2);
/* 2547:     */     
/* 2548:3851 */     double dInvalue = PlusCToolKitTOCommon.stringToDouble(PlusCToolKitTOCommon.convertNumberToRightLocale(owner.getString(sPrefix + "input_np"), locale), locale);
/* 2549:3852 */     double dInstrcalrangefrom = PlusCToolKitTOCommon.stringToDouble(PlusCToolKitTOCommon.convertNumberToRightLocale(owner.getString("instrcalrangefrom"), locale), locale);
/* 2550:3853 */     double dInstrcalrangeto = PlusCToolKitTOCommon.stringToDouble(PlusCToolKitTOCommon.convertNumberToRightLocale(owner.getString("instrcalrangeto"), locale), locale);
/* 2551:     */     
/* 2552:3855 */     double dInstroutrangefrom = PlusCToolKitTOCommon.stringToDouble(PlusCToolKitTOCommon.convertNumberToRightLocale(owner.getString("instroutrangefrom"), locale), locale);
/* 2553:3856 */     double dInstroutrangeto = PlusCToolKitTOCommon.stringToDouble(PlusCToolKitTOCommon.convertNumberToRightLocale(owner.getString("instroutrangeto"), locale), locale);
/* 2554:     */     
/* 2555:3858 */     String desiredOutputValue = "";
/* 2556:3859 */     String invalue = String.valueOf(dInvalue);
/* 2557:     */     
/* 2558:3861 */     int square = 0;
/* 2559:     */     
/* 2560:3863 */     square = owner.getBoolean("squared").booleanValue() ? 2 : owner.getBoolean("squareroot").booleanValue() ? 1 : 0;
/* 2561:3865 */     if (square > 0)
/* 2562:     */     {
/* 2563:3868 */       double d = PlusCToolKitTOCommon.stringToDouble(owner.getString("asfoundinput"), locale);
/* 2564:3869 */       int negZeroPos = 1;
/* 2565:3870 */       if (invalue.startsWith("-"))
/* 2566:     */       {
/* 2567:3871 */         invalue = invalue.substring(1);
/* 2568:3872 */         negZeroPos = -1;
/* 2569:     */       }
/* 2570:3873 */       else if (d == 0.0D)
/* 2571:     */       {
/* 2572:3874 */         negZeroPos = 0;
/* 2573:     */       }
/* 2574:3876 */       if (negZeroPos == -1) {
/* 2575:3878 */         switch (square)
/* 2576:     */         {
/* 2577:     */         case 1: 
/* 2578:3881 */           desiredOutputValue = squareRootOutputValueNegative(locale, instrcalrangeto, instroutrangefrom, instrOutputSpan, invalue);
/* 2579:3882 */           break;
/* 2580:     */         case 2: 
/* 2581:3884 */           desiredOutputValue = squaredOutputValueNegative(locale, instrcalrangefrom, instrcalrangeto, instroutrangefrom, instrOutputSpan, invalue, owner.getInt("OUTPUTPRECISION").intValue());
/* 2582:3885 */           break;
/* 2583:     */         }
/* 2584:3889 */       } else if (negZeroPos == 0) {
/* 2585:3890 */         desiredOutputValue = instroutrangefrom;
/* 2586:     */       } else {
/* 2587:3893 */         switch (square)
/* 2588:     */         {
/* 2589:     */         case 1: 
/* 2590:3896 */           desiredOutputValue = squareRootDesiredOutputValue(owner);
/* 2591:3897 */           break;
/* 2592:     */         case 2: 
/* 2593:3899 */           desiredOutputValue = squaredDesiredOutputValue(owner);
/* 2594:3900 */           break;
/* 2595:     */         }
/* 2596:     */       }
/* 2597:     */     }
/* 2598:3911 */     else if (((dInstrcalrangefrom - dInstrcalrangeto < 0.0D) && (dInstroutrangefrom - dInstroutrangeto <= 0.0D)) || ((dInstrcalrangefrom - dInstrcalrangeto > 0.0D) && (dInstroutrangefrom - dInstroutrangeto >= 0.0D)))
/* 2599:     */     {
/* 2600:3915 */       desiredOutputValue = String.valueOf((dInvalue - dInstrcalrangefrom) * (resultSpan2 / resultSpan1) + dInstroutrangefrom);
/* 2601:     */     }
/* 2602:3916 */     else if (((dInstrcalrangefrom - dInstrcalrangeto < 0.0D) && (dInstroutrangefrom - dInstroutrangeto >= 0.0D)) || ((dInstrcalrangefrom - dInstrcalrangeto > 0.0D) && (dInstroutrangefrom - dInstroutrangeto <= 0.0D)))
/* 2603:     */     {
/* 2604:3920 */       desiredOutputValue = String.valueOf(dInstroutrangefrom - (dInvalue - dInstrcalrangefrom) * ((dInstroutrangefrom - dInstroutrangeto) / resultSpan1));
/* 2605:     */     }
/* 2606:3925 */     return PlusCToolKitTOCommon.convertNumberToRightLocale(desiredOutputValue, locale);
/* 2607:     */   }
/* 2608:     */   
/* 2609:     */   public void doUpdateRonValues(PlusCMboRemote mboRemote)
/* 2610:     */   {
/* 2611:3933 */     if (mboRemote == null) {
/* 2612:3934 */       return;
/* 2613:     */     }
/* 2614:3937 */     String fieldName = "";
/* 2615:     */     
/* 2616:3939 */     PlusCMboRemote owner = mboRemote;
/* 2617:3943 */     if (owner == null) {
/* 2618:3944 */       return;
/* 2619:     */     }
/* 2620:3947 */     String planType = owner.getString("plantype");
/* 2621:3949 */     if (planType.equalsIgnoreCase("DISCRETE")) {
/* 2622:3950 */       fieldName = "SETPOINTVALUE";
/* 2623:     */     } else {
/* 2624:3952 */       fieldName = "INPUTVALUE";
/* 2625:     */     }
/* 2626:3955 */     for (int tol = 1; tol < 2; tol++)
/* 2627:     */     {
/* 2628:3956 */       String rontype = owner.getString("ron" + tol + "type");
/* 2629:3958 */       if (rontype == null) {
/* 2630:3959 */         rontype = "";
/* 2631:     */       }
/* 2632:3962 */       if ((!rontype.equals("")) && (!rontype.equals("MANUAL"))) {
/* 2633:3966 */         if ((mboRemote.getString(fieldName) == null) || (mboRemote.getString(fieldName).equals("")))
/* 2634:     */         {
/* 2635:3968 */           mboRemote.setValue("ron" + tol + "lower", "", 9L);
/* 2636:3969 */           mboRemote.setValue("ron" + tol + "upper", "", 9L);
/* 2637:     */         }
/* 2638:     */       }
/* 2639:     */     }
/* 2640:     */   }
/* 2641:     */   
/* 2642:     */   public boolean doUpdateTolValues(PlusCMboRemote mboRemote, String fieldName)
/* 2643:     */   {
/* 2644:3983 */     if (mboRemote == null) {
/* 2645:3984 */       return true;
/* 2646:     */     }
/* 2647:3987 */     PlusCMboRemote owner = mboRemote;
/* 2648:     */     
/* 2649:3989 */     Locale locale = mboRemote.getLocale();
/* 2650:3991 */     if (owner == null) {
/* 2651:3992 */       return true;
/* 2652:     */     }
/* 2653:3995 */     if (fieldName == null) {
/* 2654:3996 */       fieldName = "";
/* 2655:     */     }
/* 2656:4001 */     double invalue = PlusCToolKitTOCommon.getDouble(mboRemote.getString("inputvalue"), locale);
/* 2657:     */     
/* 2658:4003 */     double instrcalrangefrom = PlusCToolKitTOCommon.getDouble(owner.getString("instrcalrangefrom"), locale);
/* 2659:     */     
/* 2660:4005 */     double instrcalrangeto = PlusCToolKitTOCommon.getDouble(owner.getString("instrcalrangeto"), locale);
/* 2661:     */     
/* 2662:4007 */     double instrInputSpan = instrcalrangeto - instrcalrangefrom;
/* 2663:     */     
/* 2664:4009 */     double instroutrangefrom = PlusCToolKitTOCommon.getDouble(owner.getString("instroutrangefrom"), locale);
/* 2665:     */     
/* 2666:4011 */     double instroutrangeto = PlusCToolKitTOCommon.getDouble(owner.getString("instroutrangeto"), locale);
/* 2667:     */     
/* 2668:4013 */     double instrOutputSpan = instroutrangeto - instroutrangefrom;
/* 2669:4015 */     if ((fieldName.equalsIgnoreCase("SETPOINTVALUE")) || (fieldName.equalsIgnoreCase("ASFOUNDSETPOINT")) || (fieldName.equalsIgnoreCase("ASLEFTSETPOINT")))
/* 2670:     */     {
/* 2671:4018 */       instroutrangefrom = instrcalrangefrom;
/* 2672:4019 */       instroutrangeto = instrcalrangeto;
/* 2673:4020 */       instrOutputSpan = instrInputSpan;
/* 2674:     */     }
/* 2675:4023 */     String sPrefix = "";
/* 2676:4025 */     if ((fieldName.equalsIgnoreCase("ASFOUNDINPUT")) || (fieldName.equalsIgnoreCase("ASFOUNDSETPOINT"))) {
/* 2677:4027 */       sPrefix = "asfound";
/* 2678:     */     }
/* 2679:4030 */     if ((fieldName.equalsIgnoreCase("ASLEFTINPUT")) || (fieldName.equalsIgnoreCase("ASLEFTSETPOINT"))) {
/* 2680:4032 */       sPrefix = "asleft";
/* 2681:     */     }
/* 2682:4035 */     String planType = owner.getString("plantype");
/* 2683:     */     
/* 2684:4037 */     int minOutputPrecision = 0;
/* 2685:4039 */     if (planType.equalsIgnoreCase("DISCRETE")) {
/* 2686:4040 */       minOutputPrecision = owner.getInt("INPUTPRECISION").intValue();
/* 2687:     */     } else {
/* 2688:4042 */       minOutputPrecision = owner.getInt("OUTPUTPRECISION").intValue();
/* 2689:     */     }
/* 2690:4045 */     int actualInputPrecision = PlusCToolKitTOCommon.getDecimalDigits(sPrefix.equals("") ? owner.getString("INPUTVALUE") : owner.getString(sPrefix + "INPUT"));
/* 2691:     */     
/* 2692:     */ 
/* 2693:     */ 
/* 2694:4049 */     int actualOutputPrecision = PlusCToolKitTOCommon.getDecimalDigits(sPrefix.equals("") ? owner.getString("OUTPUTVALUE") : owner.getString(sPrefix + "OUTPUT"));
/* 2695:     */     
/* 2696:     */ 
/* 2697:     */ 
/* 2698:4053 */     int rightPrecision = getTolPrecision(minOutputPrecision, actualOutputPrecision, actualInputPrecision);
/* 2699:4057 */     if (((owner instanceof PlusCDSPointTO)) && (((planType.equalsIgnoreCase("DISCRETE")) && (fieldName.equalsIgnoreCase("SETPOINTVALUE")) && (mboRemote.isNull("SETPOINTVALUE"))) || ((planType.equalsIgnoreCase("ANALOG")) && ((mboRemote.isNull("INPUTVALUE")) || (mboRemote.isNull("OUTPUTVALUE")) || (instrInputSpan == 0.0D) || (instrOutputSpan == 0.0D)))))
/* 2700:     */     {
/* 2701:4071 */       for (int tol = 1; tol < 5; tol++)
/* 2702:     */       {
/* 2703:4072 */         String tType = owner.getString("tol" + tol + "type");
/* 2704:4073 */         if (tType == null) {
/* 2705:4074 */           tType = "";
/* 2706:     */         }
/* 2707:4076 */         String sDirection = owner.getString("tol" + tol + "SUMDIRECTION");
/* 2708:4078 */         if (sDirection == null) {
/* 2709:4079 */           sDirection = "";
/* 2710:     */         }
/* 2711:4084 */         if (((!tType.equals("")) && ((!owner.isNull("TOL" + tol + "LOWERVALUE")) || (!owner.isNull("TOL" + tol + "UPPERVALUE")))) || ((!sDirection.equals("")) && ((!owner.isNull("TOL" + tol + "SUMEU")) || (!owner.isNull("TOL" + tol + "SUMREAD")) || (!owner.isNull("TOL" + tol + "SUMSPAN")) || (!owner.isNull("TOL" + tol + "SUMURV")))))
/* 2712:     */         {
/* 2713:4095 */           mboRemote.setValue("tol" + tol + "lower", "", 9L);
/* 2714:4096 */           mboRemote.setValue("tol" + tol + "upper", "", 9L);
/* 2715:     */           
/* 2716:     */ 
/* 2717:4099 */           mboRemote.setValue("tol" + tol + "lower_np", "", 9L);
/* 2718:4100 */           mboRemote.setValue("tol" + tol + "upper_np", "", 9L);
/* 2719:4101 */           mboRemote.setValue("OUTPUTVALUE", "", 9L);
/* 2720:4102 */           mboRemote.setValue("OUTPUTVALUE_NP", "", 9L);
/* 2721:4103 */           mboRemote.setValue("RON1LOWER_NP", "", 9L);
/* 2722:4104 */           mboRemote.setValue("RON1LOWER", "", 9L);
/* 2723:4105 */           mboRemote.setValue("RON1UPPER_NP", "", 9L);
/* 2724:4106 */           mboRemote.setValue("RON1UPPER", "", 9L);
/* 2725:     */         }
/* 2726:     */       }
/* 2727:4109 */       return true;
/* 2728:     */     }
/* 2729:4112 */     if (((fieldName.equalsIgnoreCase("ASFOUNDINPUT")) && (!mboRemote.isNull("ASFOUNDINPUT"))) || ((fieldName.equalsIgnoreCase("ASLEFTINPUT")) && (!mboRemote.isNull("ASLEFTINPUT")))) {
/* 2730:4116 */       PlusCToolKitTOCommon.formatDouble(mboRemote.getString(fieldName), rightPrecision, locale, true);
/* 2731:4119 */     } else if ((fieldName.equalsIgnoreCase("ASFOUNDSETPOINT")) || (fieldName.equalsIgnoreCase("ASLEFTSETPOINT"))) {
/* 2732:4123 */       PlusCToolKitTOCommon.formatDouble(mboRemote.getString("SETPOINTVALUE"), rightPrecision, locale, true);
/* 2733:4126 */     } else if (planType.equalsIgnoreCase("DISCRETE")) {
/* 2734:4127 */       PlusCToolKitTOCommon.formatDouble(mboRemote.getString("SETPOINTVALUE"), rightPrecision, locale, true);
/* 2735:     */     } else {
/* 2736:4130 */       PlusCToolKitTOCommon.formatDouble(mboRemote.getString("INPUTVALUE"), rightPrecision, locale, true);
/* 2737:     */     }
/* 2738:4135 */     double InputToOutputFactor = 0.0D;
/* 2739:4137 */     if ((instrOutputSpan != 0.0D) && (instrInputSpan != 0.0D)) {
/* 2740:4138 */       InputToOutputFactor = instrOutputSpan / instrInputSpan;
/* 2741:     */     }
/* 2742:4141 */     String desiredOutputValue = "0";
/* 2743:4143 */     if (((fieldName.equalsIgnoreCase("ASFOUNDINPUT")) && (!mboRemote.isNull("ASFOUNDINPUT"))) || ((fieldName.equalsIgnoreCase("ASLEFTINPUT")) && (!mboRemote.isNull("ASLEFTINPUT"))))
/* 2744:     */     {
/* 2745:4147 */       if (owner.getBoolean("squareroot").booleanValue())
/* 2746:     */       {
/* 2747:4148 */         if (invalue == 0.0D) {
/* 2748:4149 */           desiredOutputValue = String.valueOf(instroutrangefrom);
/* 2749:4150 */         } else if (invalue > 0.0D) {
/* 2750:4151 */           desiredOutputValue = String.valueOf(instroutrangefrom + Math.sqrt(invalue / instrcalrangeto) * instrOutputSpan);
/* 2751:     */         }
/* 2752:     */       }
/* 2753:4155 */       else if (owner.getBoolean("squared").booleanValue())
/* 2754:     */       {
/* 2755:4156 */         if (invalue < 0.0D) {
/* 2756:4157 */           desiredOutputValue = squaredOutputValue(locale, String.valueOf(instrcalrangefrom), String.valueOf(instrcalrangeto), String.valueOf(instroutrangefrom), String.valueOf(instrOutputSpan), String.valueOf(invalue), -1.0D, rightPrecision);
/* 2757:4162 */         } else if (invalue == 0.0D) {
/* 2758:4163 */           desiredOutputValue = String.valueOf(instroutrangefrom);
/* 2759:     */         } else {
/* 2760:4166 */           desiredOutputValue = squaredOutputValue(locale, String.valueOf(instrcalrangefrom), String.valueOf(instrcalrangeto), String.valueOf(instroutrangefrom), String.valueOf(instrOutputSpan), String.valueOf(invalue), 1.0D, rightPrecision);
/* 2761:     */         }
/* 2762:     */       }
/* 2763:     */       else {
/* 2764:4173 */         desiredOutputValue = String.valueOf((invalue - instrcalrangefrom) * InputToOutputFactor + instroutrangefrom);
/* 2765:     */       }
/* 2766:     */     }
/* 2767:4180 */     else if (planType.equalsIgnoreCase("DISCRETE")) {
/* 2768:4182 */       desiredOutputValue = PlusCToolKitTOCommon.formatDouble(mboRemote.getString("SETPOINTVALUE"), minOutputPrecision, locale, false);
/* 2769:     */     } else {
/* 2770:4187 */       desiredOutputValue = PlusCToolKitTOCommon.formatDouble(mboRemote.getString("OUTPUTVALUE"), minOutputPrecision, locale, false);
/* 2771:     */     }
/* 2772:4195 */     if (((mboRemote instanceof PlusCWODSPointTO)) && ((fieldName.equalsIgnoreCase("OUTPUTVALUE")) || (fieldName.equalsIgnoreCase("SETPOINTVALUE"))) && (!mboRemote.getBoolean("NONLINEAR").booleanValue())) {
/* 2773:4201 */       return true;
/* 2774:     */     }
/* 2775:4211 */     if (owner.getBoolean("squareroot").booleanValue()) {
/* 2776:4212 */       calculateToleranceRangeSquareRoot(mboRemote, fieldName);
/* 2777:4213 */     } else if (owner.getBoolean("squared").booleanValue()) {
/* 2778:4214 */       calculateToleranceRangeSquared(mboRemote, fieldName);
/* 2779:     */     } else {
/* 2780:4216 */       calculateTolerances(mboRemote, fieldName);
/* 2781:     */     }
/* 2782:4221 */     if ((mboRemote instanceof PlusCDSPointTO))
/* 2783:     */     {
/* 2784:4222 */       double lower = 0.0D;
/* 2785:4223 */       double higher = 0.0D;
/* 2786:4224 */       double width = 0.0D;
/* 2787:     */       
/* 2788:4226 */       double tollower = 0.0D;
/* 2789:4227 */       double tolhigher = 0.0D;
/* 2790:4228 */       double tolwidth = 0.0D;
/* 2791:4230 */       for (int tol = 1; tol < 5; tol++) {
/* 2792:4231 */         if ((mboRemote.isNull("tol" + tol + "lower_NP")) || (mboRemote.isNull("tol" + tol + "upper_NP")))
/* 2793:     */         {
/* 2794:4233 */           if (tol == 1) {
/* 2795:     */             break;
/* 2796:     */           }
/* 2797:     */         }
/* 2798:     */         else
/* 2799:     */         {
/* 2800:4248 */           double inputFrom = 0.0D;
/* 2801:4249 */           double inputTo = 0.0D;
/* 2802:4250 */           double outputFrom = 0.0D;
/* 2803:4251 */           double outputTo = 0.0D;
/* 2804:     */           
/* 2805:     */ 
/* 2806:4254 */           double[] verification = directionCheck(owner, locale);
/* 2807:     */           
/* 2808:4256 */           inputFrom = verification[0];
/* 2809:4257 */           inputTo = verification[1];
/* 2810:4258 */           outputFrom = verification[2];
/* 2811:4259 */           outputTo = verification[3];
/* 2812:     */           
/* 2813:4261 */           String from = owner.getString("tol" + tol + "lowervalue");
/* 2814:4262 */           String to = owner.getString("tol" + tol + "uppervalue");
/* 2815:4263 */           String toltype = owner.getString("tol" + tol + "type");
/* 2816:4264 */           if (toltype == null) {
/* 2817:4265 */             toltype = "";
/* 2818:     */           }
/* 2819:4267 */           double equationSpecificVariable = 0.0D;
/* 2820:4268 */           double instrInputSpanCalc = inputTo - inputFrom;
/* 2821:4269 */           double instrOutputSpanCalc = outputTo - outputFrom;
/* 2822:4270 */           double ISpanByOSpan = instrOutputSpanCalc / instrInputSpanCalc;
/* 2823:     */           
/* 2824:     */ 
/* 2825:     */ 
/* 2826:     */ 
/* 2827:4275 */           boolean calcSummedRDG = false;
/* 2828:4276 */           boolean calcSummedEU = false;
/* 2829:4277 */           boolean calcSummedSpan = false;
/* 2830:4278 */           boolean calcSummedURV = false;
/* 2831:4279 */           String sumEU = "";
/* 2832:4280 */           String sumRead = "";
/* 2833:4281 */           String sumSpan = "";
/* 2834:4282 */           String sumURV = "";
/* 2835:     */           
/* 2836:     */ 
/* 2837:4285 */           sumEU = owner.getString("tol" + tol + "sumeu");
/* 2838:4286 */           if ((sumEU == null) || (sumEU.equals(""))) {
/* 2839:4287 */             sumEU = "";
/* 2840:     */           } else {
/* 2841:4289 */             calcSummedEU = true;
/* 2842:     */           }
/* 2843:4292 */           sumRead = owner.getString("tol" + tol + "sumread");
/* 2844:4294 */           if ((sumRead == null) || (sumRead.equals(""))) {
/* 2845:4295 */             sumRead = "";
/* 2846:     */           } else {
/* 2847:4297 */             calcSummedRDG = true;
/* 2848:     */           }
/* 2849:4300 */           sumSpan = owner.getString("tol" + tol + "sumspan");
/* 2850:4302 */           if ((sumSpan == null) || (sumSpan.equals(""))) {
/* 2851:4303 */             sumSpan = "";
/* 2852:     */           } else {
/* 2853:4305 */             calcSummedSpan = true;
/* 2854:     */           }
/* 2855:4308 */           sumURV = owner.getString("tol" + tol + "sumurv");
/* 2856:4310 */           if ((sumURV == null) || (sumURV.equals(""))) {
/* 2857:4311 */             sumURV = "";
/* 2858:     */           } else {
/* 2859:4313 */             calcSummedURV = true;
/* 2860:     */           }
/* 2861:4316 */           if ((calcSummedEU) || (calcSummedSpan) || (calcSummedRDG) || (calcSummedURV))
/* 2862:     */           {
/* 2863:4319 */             boolean[] summedCalcTypes = { calcSummedEU, calcSummedRDG, calcSummedSpan, calcSummedURV };
/* 2864:     */             
/* 2865:4321 */             double[] lowerHigherValues = new double[2];
/* 2866:4322 */             if (mboRemote != null)
/* 2867:     */             {
/* 2868:4323 */               lowerHigherValues = summedToleranceEquationsTightesWidest(mboRemote, fieldName, tol, summedCalcTypes);
/* 2869:     */               
/* 2870:     */ 
/* 2871:     */ 
/* 2872:     */ 
/* 2873:4328 */               lower = lowerHigherValues[0];
/* 2874:4329 */               higher = lowerHigherValues[1];
/* 2875:     */             }
/* 2876:     */           }
/* 2877:     */           else
/* 2878:     */           {
/* 2879:4334 */             instrOutputSpan = outputTo - outputFrom;
/* 2880:4335 */             instrInputSpan = inputTo - inputFrom;
/* 2881:4336 */             ISpanByOSpan = instrOutputSpan / instrInputSpan;
/* 2882:4337 */             double calcRangeDiff = PlusCToolKitTOCommon.stringToDouble(from, locale) * ISpanByOSpan;
/* 2883:4340 */             if ((toltype.equals("EU")) || (!sumSpan.equals("")))
/* 2884:     */             {
/* 2885:4342 */               lower = PlusCToolKitTOCommon.stringToDouble(desiredOutputValue, locale) + calcRangeDiff;
/* 2886:     */               
/* 2887:     */ 
/* 2888:4345 */               calcRangeDiff = PlusCToolKitTOCommon.stringToDouble(to, locale) * ISpanByOSpan;
/* 2889:4346 */               higher = PlusCToolKitTOCommon.stringToDouble(desiredOutputValue, locale) + calcRangeDiff;
/* 2890:     */             }
/* 2891:     */             else
/* 2892:     */             {
/* 2893:4352 */               if (((toltype.equals("%SPAN")) || (!sumSpan.equals(""))) && (planType.equalsIgnoreCase("ANALOG"))) {
/* 2894:4354 */                 equationSpecificVariable = inputTo - inputFrom;
/* 2895:4355 */               } else if (((toltype.equals("%URV")) || (!sumURV.equals(""))) && (planType.equalsIgnoreCase("ANALOG"))) {
/* 2896:4358 */                 equationSpecificVariable = Math.abs(inputTo);
/* 2897:4359 */               } else if (((toltype.equals("%READING")) || (!sumRead.equals(""))) && (planType.equalsIgnoreCase("ANALOG"))) {
/* 2898:4362 */                 if (!sPrefix.equals("")) {
/* 2899:4363 */                   equationSpecificVariable = Math.abs(PlusCToolKitTOCommon.stringToDouble(mboRemote.getString(sPrefix + "INPUT"), locale));
/* 2900:     */                 } else {
/* 2901:4368 */                   equationSpecificVariable = Math.abs(PlusCToolKitTOCommon.stringToDouble(mboRemote.getString("INPUTVALUE"), locale));
/* 2902:     */                 }
/* 2903:     */               }
/* 2904:4377 */               lower = PlusCToolKitTOCommon.stringToDouble(from, locale) * (equationSpecificVariable / 100.0D * ISpanByOSpan);
/* 2905:     */               
/* 2906:4379 */               higher = Math.abs(PlusCToolKitTOCommon.stringToDouble(to, locale) * (equationSpecificVariable / 100.0D * ISpanByOSpan));
/* 2907:     */             }
/* 2908:     */           }
/* 2909:4385 */           if (lower > higher) {
/* 2910:4386 */             width = lower - higher;
/* 2911:4387 */           } else if (higher > lower) {
/* 2912:4388 */             width = higher - lower;
/* 2913:     */           } else {
/* 2914:4390 */             width = 0.0D;
/* 2915:     */           }
/* 2916:4393 */           if (tol == 1)
/* 2917:     */           {
/* 2918:4394 */             tollower = lower;
/* 2919:4395 */             tolhigher = higher;
/* 2920:4396 */             tolwidth = width;
/* 2921:     */           }
/* 2922:     */           else
/* 2923:     */           {
/* 2924:4401 */             if (((lower > tollower) && (higher < tolhigher)) || (width < tolwidth) || ((lower > tollower) && (higher <= tolhigher)) || ((higher < tolhigher) && (lower >= tollower))) {
/* 2925:4405 */               return false;
/* 2926:     */             }
/* 2927:4408 */             tollower = lower;
/* 2928:4409 */             tolhigher = higher;
/* 2929:4410 */             tolwidth = width;
/* 2930:     */           }
/* 2931:     */         }
/* 2932:     */       }
/* 2933:     */     }
/* 2934:4414 */     return true;
/* 2935:     */   }
/* 2936:     */   
/* 2937:     */   public boolean doUpdateErrorValues(PlusCMboRemote mboRemote, String asFoundOrLeft, boolean bShowOutOfTolMsg)
/* 2938:     */   {
/* 2939:4427 */     if (mboRemote == null) {
/* 2940:4428 */       return true;
/* 2941:     */     }
/* 2942:4431 */     boolean shouldRoundTol = !getTolTruncate();
/* 2943:4432 */     boolean shouldRoundAsset = !getAssetTruncate();
/* 2944:     */     
/* 2945:4434 */     boolean bTolWithinLimits = true;
/* 2946:     */     
/* 2947:4436 */     PlusCMboRemote owner = mboRemote;
/* 2948:     */     
/* 2949:4438 */     Locale locale = mboRemote.getLocale();
/* 2950:4440 */     if (owner == null) {
/* 2951:4441 */       return true;
/* 2952:     */     }
/* 2953:4444 */     String sPrefix = asFoundOrLeft;
/* 2954:     */     
/* 2955:4446 */     String planType = owner.getString("plantype");
/* 2956:     */     
/* 2957:4448 */     int minOutputPrecision = 0;
/* 2958:4450 */     if (planType.equalsIgnoreCase("DISCRETE")) {
/* 2959:4451 */       minOutputPrecision = owner.getInt("INPUTPRECISION").intValue();
/* 2960:     */     } else {
/* 2961:4453 */       minOutputPrecision = owner.getInt("OUTPUTPRECISION").intValue();
/* 2962:     */     }
/* 2963:4456 */     int actualInputPrecision = PlusCToolKitTOCommon.getDecimalDigits(sPrefix.equals("") ? owner.getString("INPUTVALUE") : owner.getString(sPrefix + "INPUT"));
/* 2964:     */     
/* 2965:     */ 
/* 2966:     */ 
/* 2967:4460 */     int actualOutputPrecision = PlusCToolKitTOCommon.getDecimalDigits(sPrefix.equals("") ? owner.getString("OUTPUTVALUE") : owner.getString(sPrefix + "OUTPUT"));
/* 2968:     */     
/* 2969:     */ 
/* 2970:     */ 
/* 2971:     */ 
/* 2972:     */ 
/* 2973:4466 */     String instrcalrangefrom = String.valueOf(PlusCToolKitTOCommon.stringToDouble(PlusCToolKitTOCommon.convertNumberToRightLocale(owner.getString("instrcalrangefrom"), locale), locale));
/* 2974:     */     
/* 2975:     */ 
/* 2976:4469 */     String instrcalrangeto = String.valueOf(PlusCToolKitTOCommon.stringToDouble(PlusCToolKitTOCommon.convertNumberToRightLocale(owner.getString("instrcalrangeto"), locale), locale));
/* 2977:     */     
/* 2978:     */ 
/* 2979:     */ 
/* 2980:     */ 
/* 2981:4474 */     double instrcalrangeto_double = PlusCToolKitTOCommon.stringToDouble(PlusCToolKitTOCommon.convertNumberToRightLocale(instrcalrangeto, locale), locale);
/* 2982:     */     
/* 2983:4476 */     double instrcalrangefrom_double = PlusCToolKitTOCommon.stringToDouble(PlusCToolKitTOCommon.convertNumberToRightLocale(instrcalrangefrom, locale), locale);
/* 2984:     */     
/* 2985:     */ 
/* 2986:4479 */     double resultSpan1 = instrcalrangeto_double - instrcalrangefrom_double;
/* 2987:4480 */     String instrInputSpan = String.valueOf(resultSpan1);
/* 2988:4481 */     double instroutrangeto_double = PlusCToolKitTOCommon.stringToDouble(PlusCToolKitTOCommon.convertNumberToRightLocale(owner.getString("instroutrangeto"), locale), locale);
/* 2989:     */     
/* 2990:     */ 
/* 2991:4484 */     double instroutrangefrom_double = PlusCToolKitTOCommon.stringToDouble(PlusCToolKitTOCommon.convertNumberToRightLocale(owner.getString("instroutrangefrom"), locale), locale);
/* 2992:     */     
/* 2993:     */ 
/* 2994:     */ 
/* 2995:4488 */     String instroutrangefrom = String.valueOf(instroutrangefrom_double);
/* 2996:     */     
/* 2997:     */ 
/* 2998:4491 */     double resultSpan2 = instroutrangeto_double - instroutrangefrom_double;
/* 2999:4492 */     String instrOutputSpan = String.valueOf(resultSpan2);
/* 3000:     */     
/* 3001:     */ 
/* 3002:4495 */     double inputFrom = 0.0D;
/* 3003:4496 */     double inputTo = 0.0D;
/* 3004:4497 */     double outputFrom = 0.0D;
/* 3005:4498 */     double outputTo = 0.0D;
/* 3006:4499 */     boolean isOpposite = false;
/* 3007:4501 */     if ((instrcalrangefrom_double - instrcalrangeto_double < 0.0D) && (instroutrangefrom_double - instroutrangeto_double >= 0.0D))
/* 3008:     */     {
/* 3009:4504 */       inputFrom = instrcalrangefrom_double;
/* 3010:4505 */       inputTo = instrcalrangeto_double;
/* 3011:4506 */       outputFrom = instroutrangeto_double;
/* 3012:4507 */       outputTo = instroutrangefrom_double;
/* 3013:4508 */       isOpposite = true;
/* 3014:     */     }
/* 3015:4509 */     else if ((instrcalrangefrom_double - instrcalrangeto_double > 0.0D) && (instroutrangefrom_double - instroutrangeto_double <= 0.0D))
/* 3016:     */     {
/* 3017:4512 */       inputFrom = instrcalrangeto_double;
/* 3018:4513 */       inputTo = instrcalrangefrom_double;
/* 3019:4514 */       outputFrom = instroutrangefrom_double;
/* 3020:4515 */       outputTo = instroutrangeto_double;
/* 3021:4516 */       isOpposite = true;
/* 3022:     */     }
/* 3023:     */     else
/* 3024:     */     {
/* 3025:4519 */       inputFrom = instrcalrangefrom_double;
/* 3026:4520 */       inputTo = instrcalrangeto_double;
/* 3027:4521 */       outputFrom = instroutrangefrom_double;
/* 3028:4522 */       outputTo = instroutrangeto_double;
/* 3029:     */     }
/* 3030:4530 */     resultSpan1 = inputTo - inputFrom;
/* 3031:4531 */     instrInputSpan = String.valueOf(resultSpan1);
/* 3032:     */     
/* 3033:4533 */     resultSpan2 = outputTo - outputFrom;
/* 3034:4534 */     instrOutputSpan = String.valueOf(resultSpan2);
/* 3035:     */     
/* 3036:4536 */     String inputvalue = "0";
/* 3037:4538 */     if (planType.equalsIgnoreCase("DISCRETE")) {
/* 3038:4539 */       inputvalue = String.valueOf(PlusCToolKitTOCommon.getDouble(mboRemote.getString("setpointvalue"), locale));
/* 3039:     */     } else {
/* 3040:4542 */       inputvalue = String.valueOf(PlusCToolKitTOCommon.getDouble(mboRemote.getString(sPrefix + "input"), locale));
/* 3041:     */     }
/* 3042:4546 */     String outputValue = "0";
/* 3043:4548 */     if (planType.equalsIgnoreCase("DISCRETE")) {
/* 3044:4549 */       outputValue = String.valueOf(PlusCToolKitTOCommon.stringToDouble(mboRemote.getString(sPrefix + "setpoint"), locale));
/* 3045:     */     } else {
/* 3046:4552 */       outputValue = String.valueOf(PlusCToolKitTOCommon.stringToDouble(mboRemote.getString(sPrefix + "output"), locale));
/* 3047:     */     }
/* 3048:4557 */     int rightPrecision = getPointTolPrecision(mboRemote, sPrefix);
/* 3049:4560 */     for (int tol = 1; tol < 5; tol++) {
/* 3050:4561 */       if ((mboRemote.isNull(sPrefix + "tol" + tol + "upper")) || (mboRemote.isNull(sPrefix + "tol" + tol + "lower")))
/* 3051:     */       {
/* 3052:4563 */         mboRemote.setValue(sPrefix + "ERROR" + tol, "", 9L);
/* 3053:     */       }
/* 3054:     */       else
/* 3055:     */       {
/* 3056:4566 */         if (planType.equalsIgnoreCase("DISCRETE"))
/* 3057:     */         {
/* 3058:4567 */           if (mboRemote.isNull(sPrefix + "setpoint"))
/* 3059:     */           {
/* 3060:4568 */             mboRemote.setValue(sPrefix + "ERROR" + tol, "", 9L);
/* 3061:4569 */             continue;
/* 3062:     */           }
/* 3063:     */         }
/* 3064:4572 */         else if (mboRemote.isNull(sPrefix + "output"))
/* 3065:     */         {
/* 3066:4573 */           mboRemote.setValue(sPrefix + "ERROR" + tol, "", 9L);
/* 3067:4574 */           continue;
/* 3068:     */         }
/* 3069:4578 */         String lowTolerance = mboRemote.getString(sPrefix + "tol" + tol + "lower");
/* 3070:     */         
/* 3071:4580 */         String highTolerance = mboRemote.getString(sPrefix + "tol" + tol + "upper");
/* 3072:     */         
/* 3073:     */ 
/* 3074:     */ 
/* 3075:     */ 
/* 3076:     */ 
/* 3077:     */ 
/* 3078:     */ 
/* 3079:     */ 
/* 3080:     */ 
/* 3081:     */ 
/* 3082:     */ 
/* 3083:     */ 
/* 3084:     */ 
/* 3085:     */ 
/* 3086:     */ 
/* 3087:     */ 
/* 3088:     */ 
/* 3089:     */ 
/* 3090:     */ 
/* 3091:4600 */         double outputValue_double = PlusCToolKitTOCommon.stringToDouble(PlusCToolKitTOCommon.convertNumberToRightLocale(outputValue, locale), locale);
/* 3092:     */         
/* 3093:4602 */         double lowTolerance_double = PlusCToolKitTOCommon.stringToDouble(PlusCToolKitTOCommon.convertNumberToRightLocale(lowTolerance, locale), locale);
/* 3094:     */         
/* 3095:4604 */         double highTolerance_double = PlusCToolKitTOCommon.stringToDouble(PlusCToolKitTOCommon.convertNumberToRightLocale(highTolerance, locale), locale);
/* 3096:     */         
/* 3097:     */ 
/* 3098:4607 */         String value = "";
/* 3099:4613 */         if ((outputValue_double >= lowTolerance_double) && (outputValue_double <= highTolerance_double))
/* 3100:     */         {
/* 3101:4615 */           value = PlusCToolKitTOCommon.formatDouble("0", rightPrecision, locale, shouldRoundTol);
/* 3102:     */         }
/* 3103:4621 */         else if (outputValue_double < lowTolerance_double)
/* 3104:     */         {
/* 3105:4626 */           double resultDerror = outputValue_double - lowTolerance_double;
/* 3106:     */           
/* 3107:     */ 
/* 3108:     */ 
/* 3109:     */ 
/* 3110:4631 */           value = PlusCToolKitTOCommon.formatDouble(String.valueOf(resultDerror), rightPrecision, locale, shouldRoundTol);
/* 3111:4635 */           if (bShowOutOfTolMsg) {
/* 3112:4636 */             bTolWithinLimits = false;
/* 3113:     */           }
/* 3114:     */         }
/* 3115:4638 */         else if (outputValue_double > highTolerance_double)
/* 3116:     */         {
/* 3117:4639 */           double resultDerror1 = outputValue_double - highTolerance_double;
/* 3118:     */           
/* 3119:4641 */           value = PlusCToolKitTOCommon.formatDouble(String.valueOf(resultDerror1), rightPrecision, locale, shouldRoundTol);
/* 3120:4644 */           if (bShowOutOfTolMsg) {
/* 3121:4645 */             bTolWithinLimits = false;
/* 3122:     */           }
/* 3123:     */         }
/* 3124:4649 */         value = checkAndAdjustFldValueSize(value, new DecimalFormatSymbols(locale), locale, shouldRoundTol);
/* 3125:4650 */         mboRemote.setValue(sPrefix + "ERROR" + tol, value, 9L);
/* 3126:     */       }
/* 3127:     */     }
/* 3128:4654 */     String error = "";
/* 3129:     */     
/* 3130:     */ 
/* 3131:4657 */     rightPrecision = getAssetPrecision(minOutputPrecision, actualOutputPrecision, actualInputPrecision);
/* 3132:     */     
/* 3133:     */ 
/* 3134:4660 */     String invalue1 = String.valueOf(PlusCToolKitTOCommon.stringToDouble(PlusCToolKitTOCommon.convertNumberToRightLocale(inputvalue, locale), locale));
/* 3135:     */     
/* 3136:4662 */     double invalue_double = PlusCToolKitTOCommon.stringToDouble(PlusCToolKitTOCommon.convertNumberToRightLocale(invalue1, locale), locale);
/* 3137:     */     
/* 3138:     */ 
/* 3139:4665 */     double instrOutputSpan_double = PlusCToolKitTOCommon.stringToDouble(PlusCToolKitTOCommon.convertNumberToRightLocale(instrOutputSpan, locale), locale);
/* 3140:     */     
/* 3141:     */ 
/* 3142:4668 */     double instrInputSpan_double = PlusCToolKitTOCommon.stringToDouble(PlusCToolKitTOCommon.convertNumberToRightLocale(instrInputSpan, locale), locale);
/* 3143:     */     
/* 3144:     */ 
/* 3145:4671 */     double outputValue_double = PlusCToolKitTOCommon.stringToDouble(PlusCToolKitTOCommon.convertNumberToRightLocale(outputValue, locale), locale);
/* 3146:4677 */     if (instrInputSpan_double == 0.0D) {
/* 3147:4678 */       return bTolWithinLimits;
/* 3148:     */     }
/* 3149:4687 */     if (planType.equalsIgnoreCase("DISCRETE"))
/* 3150:     */     {
/* 3151:4688 */       double errorResult = outputValue_double - invalue_double;
/* 3152:4689 */       error = PlusCToolKitTOCommon.formatDouble(String.valueOf(errorResult), minOutputPrecision, locale, shouldRoundAsset);
/* 3153:     */     }
/* 3154:     */     else
/* 3155:     */     {
/* 3156:     */       double inputInOutputEU_double;
/* 3157:     */       double inputInOutputEU_double;
/* 3158:4696 */       if (owner.getBoolean("NONLINEAR").booleanValue())
/* 3159:     */       {
/* 3160:4701 */         inputInOutputEU_double = PlusCToolKitTOCommon.stringToDouble(PlusCToolKitTOCommon.formatDouble(owner.getString("OUTPUTVALUE"), 10, locale, shouldRoundAsset), locale);
/* 3161:     */       }
/* 3162:     */       else
/* 3163:     */       {
/* 3164:4710 */         String inputInOutputEU = "";
/* 3165:4712 */         if (owner.getBoolean("squareroot").booleanValue())
/* 3166:     */         {
/* 3167:4713 */           String invalue = inputvalue;
/* 3168:4714 */           double d = PlusCToolKitTOCommon.stringToDouble(invalue, locale);
/* 3169:     */           
/* 3170:4716 */           int negZeroPos = 1;
/* 3171:4717 */           if (invalue.startsWith("-"))
/* 3172:     */           {
/* 3173:4718 */             invalue = invalue.substring(1);
/* 3174:4719 */             negZeroPos = -1;
/* 3175:     */           }
/* 3176:4720 */           else if (d == 0.0D)
/* 3177:     */           {
/* 3178:4721 */             negZeroPos = 0;
/* 3179:     */           }
/* 3180:4723 */           if (negZeroPos == -1)
/* 3181:     */           {
/* 3182:4724 */             double finalValue = outputFrom - Math.sqrt(invalue_double / inputTo) * instrOutputSpan_double;
/* 3183:     */             
/* 3184:4726 */             inputInOutputEU = String.valueOf(finalValue);
/* 3185:     */           }
/* 3186:4728 */           else if (negZeroPos == 0)
/* 3187:     */           {
/* 3188:4729 */             inputInOutputEU = instroutrangefrom;
/* 3189:     */           }
/* 3190:     */           else
/* 3191:     */           {
/* 3192:4731 */             double finalValue = outputFrom + Math.sqrt(invalue_double / inputTo) * instrOutputSpan_double;
/* 3193:     */             
/* 3194:4733 */             inputInOutputEU = String.valueOf(finalValue);
/* 3195:     */           }
/* 3196:     */         }
/* 3197:4736 */         else if (owner.getBoolean("squared").booleanValue())
/* 3198:     */         {
/* 3199:4737 */           String invalue = inputvalue;
/* 3200:4738 */           double d = PlusCToolKitTOCommon.stringToDouble(invalue, locale);
/* 3201:     */           
/* 3202:4740 */           int negZeroPos = 1;
/* 3203:4741 */           if (invalue.startsWith("-"))
/* 3204:     */           {
/* 3205:4742 */             invalue = invalue.substring(1);
/* 3206:4743 */             negZeroPos = -1;
/* 3207:     */           }
/* 3208:4744 */           else if (d == 0.0D)
/* 3209:     */           {
/* 3210:4745 */             negZeroPos = 0;
/* 3211:     */           }
/* 3212:4747 */           if (negZeroPos == -1)
/* 3213:     */           {
/* 3214:4748 */             double finalValue = outputFrom - Math.pow((invalue_double - inputFrom) / instrInputSpan_double, 2.0D) * instrOutputSpan_double;
/* 3215:     */             
/* 3216:     */ 
/* 3217:     */ 
/* 3218:     */ 
/* 3219:4753 */             inputInOutputEU = String.valueOf(finalValue);
/* 3220:     */           }
/* 3221:4755 */           else if (negZeroPos == 0)
/* 3222:     */           {
/* 3223:4756 */             inputInOutputEU = instroutrangefrom;
/* 3224:     */           }
/* 3225:     */           else
/* 3226:     */           {
/* 3227:4758 */             double finalValue = outputFrom + Math.pow((invalue_double - inputFrom) / instrInputSpan_double, 2.0D) * instrOutputSpan_double;
/* 3228:     */             
/* 3229:     */ 
/* 3230:     */ 
/* 3231:     */ 
/* 3232:4763 */             inputInOutputEU = String.valueOf(finalValue);
/* 3233:     */           }
/* 3234:     */         }
/* 3235:     */         else
/* 3236:     */         {
/* 3237:4767 */           double finalValue = 0.0D;
/* 3238:4769 */           if (isOpposite) {
/* 3239:4770 */             finalValue = outputTo - (invalue_double - inputFrom) * (instrOutputSpan_double / instrInputSpan_double);
/* 3240:     */           } else {
/* 3241:4773 */             finalValue = outputFrom + (invalue_double - inputFrom) * (instrOutputSpan_double / instrInputSpan_double);
/* 3242:     */           }
/* 3243:4776 */           inputInOutputEU = String.valueOf(finalValue);
/* 3244:     */         }
/* 3245:4781 */         inputInOutputEU = PlusCToolKitTOCommon.formatDouble(String.valueOf(inputInOutputEU), 10, locale, shouldRoundAsset);
/* 3246:     */         
/* 3247:4783 */         inputInOutputEU_double = PlusCToolKitTOCommon.stringToDouble(inputInOutputEU, locale);
/* 3248:     */       }
/* 3249:4786 */       double errorResult = outputValue_double - inputInOutputEU_double;
/* 3250:     */       
/* 3251:4788 */       error = PlusCToolKitTOCommon.formatDouble(String.valueOf(errorResult), rightPrecision, locale, true);
/* 3252:     */     }
/* 3253:4792 */     error = checkAndAdjustFldValueSize(error, new DecimalFormatSymbols(locale), locale, shouldRoundTol);
/* 3254:4794 */     if ((mboRemote.isNull(sPrefix + "INPUT")) && (mboRemote.isNull(sPrefix + "OUTPUT"))) {
/* 3255:4795 */       mboRemote.setValue(sPrefix + "OUTERROR", "", 9L);
/* 3256:     */     } else {
/* 3257:4800 */       mboRemote.setValue(sPrefix + "OUTERROR", error, 9L);
/* 3258:     */     }
/* 3259:4814 */     if (!owner.isNull("PROCESSEU")) {
/* 3260:4816 */       if ((owner.getBoolean("NONLINEAR").booleanValue()) || (owner.getString("PROCESSEU").equals(owner.getString("INSTROUTRANGEEU"))) || ((planType.equalsIgnoreCase("DISCRETE")) && (owner.getString("PROCESSEU").equals(owner.getString("INSTRCALRANGEEU")))))
/* 3261:     */       {
/* 3262:4823 */         error = checkAndAdjustFldValueSize(error, new DecimalFormatSymbols(locale), locale, shouldRoundTol);
/* 3263:4824 */         mboRemote.setValue(sPrefix + "PROERROR", error, 9L);
/* 3264:     */       }
/* 3265:4827 */       else if (owner.getString("PROCESSEU").equals(owner.getString("INSTRCALRANGEEU")))
/* 3266:     */       {
/* 3267:4831 */         double errorResult1 = 0.0D;
/* 3268:4833 */         if (isOpposite) {
/* 3269:4834 */           errorResult1 = instrInputSpan_double / instrOutputSpan_double * (outputValue_double - (outputTo - (invalue_double - inputFrom) * (instrOutputSpan_double / instrInputSpan_double)));
/* 3270:     */         } else {
/* 3271:4837 */           errorResult1 = instrInputSpan_double / instrOutputSpan_double * (outputValue_double - ((invalue_double - inputFrom) * (instrOutputSpan_double / instrInputSpan_double) + outputFrom));
/* 3272:     */         }
/* 3273:4842 */         error = PlusCToolKitTOCommon.formatDouble(String.valueOf(errorResult1), rightPrecision, locale, shouldRoundAsset);
/* 3274:     */         
/* 3275:4844 */         error = checkAndAdjustFldValueSize(error, new DecimalFormatSymbols(locale), locale, shouldRoundTol);
/* 3276:4845 */         mboRemote.setValue(sPrefix + "PROERROR", error, 9L);
/* 3277:     */       }
/* 3278:4848 */       else if (!owner.isNull("PROCESSEUFACTOR_NP"))
/* 3279:     */       {
/* 3280:4852 */         String factor = owner.getString("PROCESSEUFACTOR_NP");
/* 3281:4853 */         double factor_double = PlusCToolKitTOCommon.stringToDouble(owner.getString("PROCESSEUFACTOR_NP"), locale);
/* 3282:     */         
/* 3283:4855 */         factor = factor.replace(',', '.');
/* 3284:4857 */         if (PlusCToolKitTOCommon.strToDbl(factor) != 0.0D)
/* 3285:     */         {
/* 3286:4862 */           double error_double = PlusCToolKitTOCommon.stringToDouble(error, locale);
/* 3287:     */           
/* 3288:     */ 
/* 3289:4865 */           double result_error = error_double * factor_double;
/* 3290:     */           
/* 3291:     */ 
/* 3292:     */ 
/* 3293:4869 */           error = PlusCToolKitTOCommon.formatDouble(String.valueOf(result_error), rightPrecision, locale, shouldRoundAsset);
/* 3294:     */           
/* 3295:4871 */           error = checkAndAdjustFldValueSize(error, new DecimalFormatSymbols(locale), locale, shouldRoundTol);
/* 3296:4872 */           mboRemote.setValue(sPrefix + "PROERROR", error, 9L);
/* 3297:     */         }
/* 3298:     */       }
/* 3299:     */     }
/* 3300:4880 */     return bTolWithinLimits;
/* 3301:     */   }
/* 3302:     */   
/* 3303:     */   public String checkAndAdjustFldValueSize(String value, DecimalFormatSymbols df, int minFraction, Locale locale)
/* 3304:     */   {
/* 3305:4886 */     int rightFraction = minFraction;
/* 3306:4890 */     if (value.length() > 15)
/* 3307:     */     {
/* 3308:4895 */       String[] splitDecimals = PlusCToolKitTOCommon.split(value, String.valueOf(df.getDecimalSeparator()).trim());
/* 3309:4896 */       if (splitDecimals.length > 1)
/* 3310:     */       {
/* 3311:4899 */         if (minFraction == 10) {
/* 3312:4901 */           if (splitDecimals[0].length() + minFraction > 14) {
/* 3313:4903 */             rightFraction = 14 - splitDecimals[0].length();
/* 3314:     */           }
/* 3315:     */         }
/* 3316:4908 */         if ((splitDecimals[1].length() > minFraction) || (minFraction == 10)) {
/* 3317:4909 */           value = PlusCToolKitTOCommon.formatDoubleMax(value, rightFraction, locale);
/* 3318:     */         }
/* 3319:4910 */         splitDecimals = PlusCToolKitTOCommon.split(value, String.valueOf(df.getDecimalSeparator()));
/* 3320:4911 */         if ((splitDecimals.length > 1) && (minFraction != 10) && 
/* 3321:4912 */           (splitDecimals[1].length() < minFraction)) {
/* 3322:4913 */           value = PlusCToolKitTOCommon.formatDouble(String.valueOf(value), minFraction, locale, true);
/* 3323:     */         }
/* 3324:     */       }
/* 3325:     */     }
/* 3326:4920 */     return value;
/* 3327:     */   }
/* 3328:     */   
/* 3329:     */   public String checkAndAdjustFldValueSize(String value, DecimalFormatSymbols df, Locale locale, boolean shouldRound)
/* 3330:     */   {
/* 3331:4940 */     int fieldLength = 15;
/* 3332:4942 */     if (value.length() > 15)
/* 3333:     */     {
/* 3334:4944 */       String[] splitDecimals = PlusCToolKitTOCommon.split(value, String.valueOf(df.getDecimalSeparator()).trim());
/* 3335:4946 */       if (splitDecimals.length > 1)
/* 3336:     */       {
/* 3337:4948 */         String integerPart = splitDecimals[0];
/* 3338:4949 */         String fractionPart = splitDecimals[1];
/* 3339:     */         
/* 3340:4951 */         int rightFraction = 15 - integerPart.length() - 1;
/* 3341:4953 */         if (fractionPart.length() > rightFraction) {
/* 3342:4954 */           value = PlusCToolKitTOCommon.formatDouble(value, rightFraction, locale, shouldRound);
/* 3343:     */         }
/* 3344:     */       }
/* 3345:     */     }
/* 3346:4961 */     return value;
/* 3347:     */   }
/* 3348:     */   
/* 3349:     */   public boolean calculateAveragesAndStdDevs(PlusCMboRemote[] groupPoints, PlusCMboRemote groupAveragePoint, String fieldName)
/* 3350:     */   {
/* 3351:4978 */     Locale locale = groupAveragePoint.getLocale();
/* 3352:4979 */     boolean shouldRound = !getTolTruncate();
/* 3353:     */     
/* 3354:     */ 
/* 3355:     */ 
/* 3356:     */ 
/* 3357:4984 */     String stdDevFieldName = null;
/* 3358:4986 */     if (fieldName.equalsIgnoreCase("ASFOUNDINPUT")) {
/* 3359:4987 */       stdDevFieldName = "ASFINPUTSTDDEV";
/* 3360:4989 */     } else if (fieldName.equalsIgnoreCase("ASFOUNDOUTPUT")) {
/* 3361:4990 */       stdDevFieldName = "ASFOUTPUTSTDDEV";
/* 3362:4992 */     } else if (fieldName.equalsIgnoreCase("ASFOUNDSETPOINT")) {
/* 3363:4993 */       stdDevFieldName = "ASFSETPTSTDDEV";
/* 3364:4995 */     } else if (fieldName.equalsIgnoreCase("ASLEFTINPUT")) {
/* 3365:4996 */       stdDevFieldName = "ASLINPUTSTDDEV";
/* 3366:4998 */     } else if (fieldName.equalsIgnoreCase("ASLEFTOUTPUT")) {
/* 3367:4999 */       stdDevFieldName = "ASLOUTPUTSTDDEV";
/* 3368:5001 */     } else if (fieldName.equalsIgnoreCase("ASLEFTSETPOINT")) {
/* 3369:5002 */       stdDevFieldName = "ASLSETPTSTDDEV";
/* 3370:     */     }
/* 3371:5009 */     double[] values = new double[groupPoints.length];
/* 3372:5010 */     int precision = 0;
/* 3373:5012 */     for (int i = 0; i < groupPoints.length; i++)
/* 3374:     */     {
/* 3375:5015 */       if (groupPoints[i].isNull(fieldName))
/* 3376:     */       {
/* 3377:5016 */         groupAveragePoint.setValue(fieldName, "", 2L);
/* 3378:5017 */         groupAveragePoint.setValue(fieldName + "_NP", "", 2L);
/* 3379:5018 */         groupAveragePoint.setValue(stdDevFieldName, "", 2L);
/* 3380:5019 */         return false;
/* 3381:     */       }
/* 3382:5022 */       String value = groupPoints[i].getString(fieldName);
/* 3383:5023 */       values[i] = PlusCToolKitTOCommon.stringToDouble(value, locale);
/* 3384:     */       
/* 3385:     */ 
/* 3386:5026 */       int valuePrecision = PlusCToolKitTOCommon.getDecimalDigits(value);
/* 3387:5027 */       if (valuePrecision > precision) {
/* 3388:5028 */         precision = valuePrecision;
/* 3389:     */       }
/* 3390:     */     }
/* 3391:5035 */     double sum = 0.0D;
/* 3392:5036 */     for (int i = 0; i < values.length; i++) {
/* 3393:5037 */       sum += values[i];
/* 3394:     */     }
/* 3395:5039 */     double average = sum / values.length;
/* 3396:     */     
/* 3397:     */ 
/* 3398:5042 */     String strAverage = PlusCToolKitTOCommon.formatDouble(String.valueOf(average), precision, locale, shouldRound);
/* 3399:5043 */     groupAveragePoint.setValue(fieldName, strAverage, 2L);
/* 3400:5044 */     groupAveragePoint.setValue(fieldName + "_NP", strAverage, 2L);
/* 3401:     */     int n;
/* 3402:5050 */     switch (getStdDeviationType())
/* 3403:     */     {
/* 3404:     */     case 1: 
/* 3405:5052 */       n = values.length;
/* 3406:5053 */       break;
/* 3407:     */     case 2: 
/* 3408:5055 */       n = values.length - 1;
/* 3409:5056 */       break;
/* 3410:     */     default: 
/* 3411:5058 */       n = values.length;
/* 3412:     */     }
/* 3413:5061 */     double sumOfSquaredDiffs = 0.0D;
/* 3414:5062 */     for (int i = 0; i < values.length; i++) {
/* 3415:5063 */       sumOfSquaredDiffs += Math.pow(values[i] - average, 2.0D);
/* 3416:     */     }
/* 3417:5065 */     double stdDev = Math.sqrt(sumOfSquaredDiffs / n);
/* 3418:     */     
/* 3419:     */ 
/* 3420:5068 */     String strStdDev = PlusCToolKitTOCommon.formatDouble(String.valueOf(stdDev), precision, locale, shouldRound);
/* 3421:5069 */     groupAveragePoint.setValue(stdDevFieldName, strStdDev, 2L);
/* 3422:     */     
/* 3423:     */ 
/* 3424:5072 */     return true;
/* 3425:     */   }
/* 3426:     */   
/* 3427:     */   private boolean hasGuardbandFields(PlusCMboRemote mbo, int tol)
/* 3428:     */   {
/* 3429:5077 */     boolean isGBFromFilled = !mbo.isNull("GBFROM" + tol);
/* 3430:5078 */     boolean isGBToFilled = !mbo.isNull("GBTO" + tol);
/* 3431:5079 */     boolean isSumDirFilled = !mbo.isNull("GBSUMDIRECTION" + tol);
/* 3432:5081 */     if (((isGBFromFilled) && ((!isGBToFilled) || (!isSumDirFilled))) || ((isGBToFilled) && ((!isGBFromFilled) || (!isSumDirFilled))) || ((isSumDirFilled) && ((!isGBFromFilled) || (!isGBToFilled))) || ((!isGBFromFilled) && (!isGBToFilled) && (!isSumDirFilled))) {
/* 3433:5092 */       return false;
/* 3434:     */     }
/* 3435:5095 */     return true;
/* 3436:     */   }
/* 3437:     */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     psdi.plusc.app.pluscds.pluscmobilecommon.PlusCDSCalculation
 * JD-Core Version:    0.7.0.1
 */