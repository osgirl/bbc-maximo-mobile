/*   1:    */ package psdi.plusc.app.pluscds.pluscmobilecommon;
/*   2:    */ 
/*   3:    */ import java.math.BigDecimal;
/*   4:    */ import java.text.DecimalFormat;
/*   5:    */ import java.text.DecimalFormatSymbols;
/*   6:    */ import java.text.NumberFormat;
/*   7:    */ import java.text.ParseException;
/*   8:    */ import java.text.ParsePosition;
/*   9:    */ import java.util.ArrayList;
/*  10:    */ import java.util.HashSet;
/*  11:    */ import java.util.Locale;
/*  12:    */ 
/*  13:    */ public class PlusCToolKitTOCommon
/*  14:    */ {
/*  15:    */   public static final int MAXFRACTION = 10;
/*  16: 41 */   private static HashSet noRoundingSet = new HashSet();
/*  17: 42 */   private static boolean noRoundingSetLoaded = true;
/*  18:    */   
/*  19:    */   private static void loadNoRoundingSet()
/*  20:    */   {
/*  21: 53 */     noRoundingSetLoaded = false;
/*  22: 54 */     noRoundingSet.add("ASFOUNDINPUT");
/*  23: 55 */     noRoundingSet.add("ASFOUNDOUTPUT");
/*  24: 56 */     noRoundingSet.add("ASLEFTINPUT");
/*  25: 57 */     noRoundingSet.add("ASLEFTOUTPUT");
/*  26:    */   }
/*  27:    */   
/*  28:    */   public static double getDouble(String s, Locale locale)
/*  29:    */   {
/*  30: 63 */     String strValue = s.replace(',', '.');
/*  31: 65 */     if ((strValue == null) || (strValue.equals(""))) {
/*  32: 67 */       strValue = "0.0";
/*  33:    */     }
/*  34: 70 */     BigDecimal bd = new BigDecimal(strValue);
/*  35: 71 */     return bd.doubleValue();
/*  36:    */   }
/*  37:    */   
/*  38:    */   public static double stringToDouble(String s, Locale l)
/*  39:    */   {
/*  40: 81 */     if (s == null) {
/*  41: 82 */       throw new NullPointerException("String which should be converted to double mustn't be null!");
/*  42:    */     }
/*  43: 84 */     s = convertNumberToRightLocale(s, l);
/*  44: 86 */     if (isZero(s, l)) {
/*  45: 87 */       return 0.0D;
/*  46:    */     }
/*  47: 89 */     NumberFormat fmt = NumberFormat.getInstance(l);
/*  48: 90 */     Number num = null;
/*  49:    */     try
/*  50:    */     {
/*  51: 94 */       ParsePosition parsePosition = new ParsePosition(0);
/*  52: 95 */       num = fmt.parse(s, parsePosition);
/*  53: 97 */       if (parsePosition.getIndex() != s.length()) {
/*  54: 99 */         throw new ParseException("parseerror", 0);
/*  55:    */       }
/*  56:    */     }
/*  57:    */     catch (ParseException e)
/*  58:    */     {
/*  59:105 */       throw new NumberFormatException(s + " cannot be converted to double.");
/*  60:    */     }
/*  61:108 */     return num.doubleValue();
/*  62:    */   }
/*  63:    */   
/*  64:    */   private static boolean isZero(String s, Locale l)
/*  65:    */   {
/*  66:118 */     DecimalFormatSymbols symb = new DecimalFormatSymbols(l);
/*  67:120 */     for (int i = 0; i < s.length(); i++) {
/*  68:122 */       if ((s.charAt(i) != symb.getDecimalSeparator()) && (s.charAt(i) != symb.getGroupingSeparator()) && (s.charAt(i) != '0') && (s.charAt(i) != symb.getMinusSign())) {
/*  69:124 */         return false;
/*  70:    */       }
/*  71:    */     }
/*  72:127 */     return true;
/*  73:    */   }
/*  74:    */   
/*  75:    */   public static String convertNumberToRightLocale(String number, Locale locale)
/*  76:    */   {
/*  77:135 */     String formattedNumber = number;
/*  78:    */     
/*  79:137 */     DecimalFormatSymbols df = new DecimalFormatSymbols(locale);
/*  80:138 */     char decimalSeparator = df.getDecimalSeparator();
/*  81:139 */     if (number.indexOf(decimalSeparator) == -1) {
/*  82:140 */       if (decimalSeparator == ',')
/*  83:    */       {
/*  84:141 */         if ((formattedNumber.indexOf('.') >= 0) && (formattedNumber.lastIndexOf('.') != formattedNumber.indexOf('.'))) {
/*  85:142 */           formattedNumber = replace(number, ".", "");
/*  86:    */         } else {
/*  87:144 */           formattedNumber = number.replace('.', decimalSeparator);
/*  88:    */         }
/*  89:    */       }
/*  90:147 */       else if (decimalSeparator == '.') {
/*  91:148 */         if ((formattedNumber.indexOf(',') >= 0) && (formattedNumber.lastIndexOf(',') != formattedNumber.indexOf(','))) {
/*  92:149 */           formattedNumber = replace(number, ",", "");
/*  93:    */         } else {
/*  94:151 */           formattedNumber = number.replace(',', decimalSeparator);
/*  95:    */         }
/*  96:    */       }
/*  97:    */     }
/*  98:156 */     if ((formattedNumber.indexOf(decimalSeparator) >= 0) && (formattedNumber.lastIndexOf(decimalSeparator) != formattedNumber.indexOf(decimalSeparator))) {
/*  99:157 */       formattedNumber = replace(formattedNumber, decimalSeparator + "", "");
/* 100:159 */     } else if (decimalSeparator == ',') {
/* 101:160 */       formattedNumber = replace(formattedNumber, "\\.", "");
/* 102:161 */     } else if (decimalSeparator == '.') {
/* 103:162 */       formattedNumber = replace(formattedNumber, "\\,", "");
/* 104:    */     }
/* 105:165 */     return formattedNumber;
/* 106:    */   }
/* 107:    */   
/* 108:    */   public static String formatNumberWithMinPrecision(String value, int minFraction, Locale locale, boolean shouldRound)
/* 109:    */   {
/* 110:180 */     if (getDecimalDigits(value) >= minFraction) {
/* 111:182 */       return formatDouble(value, getDecimalDigits(value), locale, false);
/* 112:    */     }
/* 113:184 */     return formatDouble(value, minFraction, locale, shouldRound);
/* 114:    */   }
/* 115:    */   
/* 116:    */   public static String formatDouble(String value, int minFraction, Locale locale, boolean shouldRound)
/* 117:    */   {
/* 118:203 */     int maxFraction = 10;
/* 119:204 */     NumberFormat nf = NumberFormat.getInstance(locale);
/* 120:205 */     nf.setMinimumFractionDigits(minFraction);
/* 121:206 */     nf.setMaximumFractionDigits(maxFraction);
/* 122:207 */     nf.setGroupingUsed(false);
/* 123:    */     
/* 124:    */ 
/* 125:    */ 
/* 126:    */ 
/* 127:212 */     String strValue = "";
/* 128:    */     
/* 129:    */ 
/* 130:215 */     strValue = value.replace(',', '.');
/* 131:    */     try
/* 132:    */     {
/* 133:224 */       BigDecimal bd = new BigDecimal(strValue);
/* 134:227 */       if (shouldRound) {
/* 135:228 */         bd = bd.setScale(minFraction, 4);
/* 136:    */       } else {
/* 137:230 */         bd = bd.setScale(minFraction, 1);
/* 138:    */       }
/* 139:233 */       return nf.format(bd);
/* 140:    */     }
/* 141:    */     catch (NumberFormatException e) {}
/* 142:239 */     return "";
/* 143:    */   }
/* 144:    */   
/* 145:    */   public static String formatDouble(String fieldName, String value, int minFraction, Locale locale)
/* 146:    */   {
/* 147:250 */     int maxFraction = 10;
/* 148:251 */     NumberFormat nf = NumberFormat.getInstance(locale);
/* 149:252 */     nf.setMinimumFractionDigits(minFraction);
/* 150:253 */     nf.setMaximumFractionDigits(maxFraction);
/* 151:254 */     nf.setGroupingUsed(false);
/* 152:    */     
/* 153:    */ 
/* 154:    */ 
/* 155:    */ 
/* 156:259 */     String strValue = "";
/* 157:    */     
/* 158:    */ 
/* 159:    */ 
/* 160:    */ 
/* 161:    */ 
/* 162:    */ 
/* 163:    */ 
/* 164:    */ 
/* 165:268 */     strValue = value.replace(',', '.');
/* 166:272 */     if ((strValue == null) || (strValue.equals(""))) {
/* 167:274 */       strValue = "0.0";
/* 168:    */     }
/* 169:277 */     BigDecimal bd = new BigDecimal(strValue);
/* 170:279 */     if (shouldRoundUp(fieldName, strValue, minFraction)) {
/* 171:280 */       bd = bd.setScale(minFraction, 0);
/* 172:    */     }
/* 173:282 */     return nf.format(bd.doubleValue());
/* 174:    */   }
/* 175:    */   
/* 176:    */   public static String formatDoubleMax(String fieldName, String value, int maxFraction, Locale locale, boolean checkRoundUp)
/* 177:    */   {
/* 178:293 */     DecimalFormatSymbols dfs = new DecimalFormatSymbols(locale);
/* 179:    */     int minFraction;
/* 180:    */     int minFraction;
/* 181:295 */     if (maxFraction > 0) {
/* 182:296 */       minFraction = 1;
/* 183:    */     } else {
/* 184:298 */       minFraction = 0;
/* 185:    */     }
/* 186:301 */     String formatDouble = "";
/* 187:302 */     NumberFormat nf = NumberFormat.getInstance(locale);
/* 188:303 */     nf.setMinimumFractionDigits(minFraction);
/* 189:304 */     nf.setMaximumFractionDigits(maxFraction);
/* 190:305 */     nf.setGroupingUsed(false);
/* 191:    */     
/* 192:307 */     String strValue = value.replace(',', '.');
/* 193:309 */     if ((strValue == null) || (strValue.equals(""))) {
/* 194:311 */       strValue = "0.0";
/* 195:    */     }
/* 196:314 */     BigDecimal bd = new BigDecimal(strValue);
/* 197:316 */     if ((checkRoundUp) && (shouldRoundUp(fieldName, strValue, maxFraction))) {
/* 198:317 */       bd = bd.setScale(maxFraction, 0);
/* 199:    */     }
/* 200:319 */     formatDouble = nf.format(bd.doubleValue());
/* 201:    */     
/* 202:    */ 
/* 203:322 */     String[] splitDecimals = split(formatDouble, String.valueOf(dfs.getDecimalSeparator()).trim());
/* 204:325 */     if ((splitDecimals.length > 1) && (splitDecimals[1].length() < maxFraction))
/* 205:    */     {
/* 206:326 */       StringBuffer sb = new StringBuffer();
/* 207:    */       
/* 208:328 */       int loop = 0;
/* 209:329 */       String decimalPlaces = "";
/* 210:331 */       while (loop < maxFraction)
/* 211:    */       {
/* 212:332 */         sb.append("0");
/* 213:    */         
/* 214:334 */         loop++;
/* 215:    */       }
/* 216:336 */       decimalPlaces = sb.toString();
/* 217:337 */       DecimalFormat df = new DecimalFormat("0." + decimalPlaces);
/* 218:338 */       formatDouble = df.format(bd.doubleValue());
/* 219:    */     }
/* 220:342 */     return formatDouble = formatDouble.replace('.', dfs.getDecimalSeparator());
/* 221:    */   }
/* 222:    */   
/* 223:    */   private static boolean shouldRoundUp(String fieldName, String s, int prec)
/* 224:    */   {
/* 225:    */     try
/* 226:    */     {
/* 227:360 */       boolean shouldRoundUP = false;
/* 228:361 */       String sValue = s;
/* 229:    */       
/* 230:363 */       String field = fieldName == null ? "" : fieldName;
/* 231:370 */       if (noRoundingSetLoaded) {
/* 232:371 */         loadNoRoundingSet();
/* 233:    */       }
/* 234:374 */       if (noRoundingSet.contains(field))
/* 235:    */       {
/* 236:375 */         shouldRoundUP = false;
/* 237:    */       }
/* 238:    */       else
/* 239:    */       {
/* 240:377 */         String[] splitDecimals = split(s, ".");
/* 241:378 */         if ((splitDecimals.length >= 1) && (splitDecimals[1].length() >= prec) && (splitDecimals[1].indexOf("5") != splitDecimals[1].length() - 1))
/* 242:    */         {
/* 243:382 */           if ((s.charAt(sValue.indexOf(".") + prec + 1) == '5') && (sValue.indexOf(".") + prec + 1 == s.length() - 1)) {
/* 244:384 */             shouldRoundUP = false;
/* 245:385 */           } else if ((s.charAt(sValue.indexOf(".") + prec + 1) == '5') && (sValue.indexOf(".") + prec + 1 != s.length() - 1) && (prec != 0)) {
/* 246:388 */             shouldRoundUP = true;
/* 247:    */           }
/* 248:    */         }
/* 249:390 */         else if (s.charAt(sValue.indexOf(".") + prec + 1) == '5') {
/* 250:391 */           shouldRoundUP = true;
/* 251:392 */         } else if ((splitDecimals[1].length() != 2) || (splitDecimals[1].length() < prec) || (s.charAt(sValue.indexOf(".") + prec + 1) != '5') || (sValue.indexOf(".") + prec + 1 != s.length() - 1)) {}
/* 252:    */       }
/* 253:396 */       return false;
/* 254:    */     }
/* 255:    */     catch (Exception e) {}
/* 256:402 */     return false;
/* 257:    */   }
/* 258:    */   
/* 259:    */   public static String formatDoubleMax(String value, int maxFraction, Locale locale, boolean checkRoundUp, boolean shouldRound)
/* 260:    */   {
/* 261:421 */     return formatDouble(value, maxFraction, locale, shouldRound);
/* 262:    */   }
/* 263:    */   
/* 264:    */   public static String formatDoubleMax(String value, int maxFraction, Locale locale)
/* 265:    */   {
/* 266:499 */     return formatDoubleMax(value, maxFraction, locale, false, false);
/* 267:    */   }
/* 268:    */   
/* 269:    */   public static String formatDoubleMinMax(String value, int minFraction, int maxFraction, Locale locale)
/* 270:    */   {
/* 271:533 */     NumberFormat nf = NumberFormat.getInstance();
/* 272:    */     
/* 273:535 */     nf.setMinimumFractionDigits(minFraction);
/* 274:536 */     nf.setMaximumFractionDigits(maxFraction);
/* 275:537 */     nf.setGroupingUsed(false);
/* 276:    */     
/* 277:539 */     String number = "";
/* 278:    */     
/* 279:541 */     number = nf.format(stringToDouble(value, locale));
/* 280:    */     
/* 281:543 */     return number;
/* 282:    */   }
/* 283:    */   
/* 284:    */   public static double strToDbl(String a)
/* 285:    */   {
/* 286:548 */     if ((a == null) || (a.equals(""))) {
/* 287:550 */       return 0.0D;
/* 288:    */     }
/* 289:552 */     return new Double(a).doubleValue();
/* 290:    */   }
/* 291:    */   
/* 292:    */   public static int getDecimalDigits(String s)
/* 293:    */   {
/* 294:561 */     int pos = Math.max(s.lastIndexOf(','), s.lastIndexOf('.'));
/* 295:    */     
/* 296:563 */     return pos >= 0 ? s.length() - pos - 1 : 0;
/* 297:    */   }
/* 298:    */   
/* 299:    */   public static String formatDouble(String s, Locale locale)
/* 300:    */   {
/* 301:576 */     DecimalFormatSymbols df = new DecimalFormatSymbols(locale);
/* 302:    */     
/* 303:578 */     String strValue = "";
/* 304:    */     
/* 305:580 */     strValue = s.replace(',', '.');
/* 306:    */     
/* 307:582 */     NumberFormat nf = NumberFormat.getInstance(locale);
/* 308:585 */     if ((strValue == null) || (strValue.equals(""))) {
/* 309:587 */       strValue = "0.0";
/* 310:    */     }
/* 311:    */     try
/* 312:    */     {
/* 313:590 */       BigDecimal bd = new BigDecimal(strValue);
/* 314:    */       
/* 315:592 */       return nf.format(bd.doubleValue());
/* 316:    */     }
/* 317:    */     catch (NumberFormatException e)
/* 318:    */     {
/* 319:594 */       e.printStackTrace();
/* 320:    */     }
/* 321:595 */     return "";
/* 322:    */   }
/* 323:    */   
/* 324:    */   public static String[] split(String splitString, String splitToken)
/* 325:    */   {
/* 326:618 */     ArrayList splitBuffer = new ArrayList();
/* 327:619 */     String[] returnArray = null;
/* 328:620 */     int i = 0;
/* 329:621 */     int idx = splitString.indexOf(splitToken);
/* 330:622 */     int len = 0;
/* 331:623 */     int lenTok = splitToken.length();
/* 332:625 */     if (idx == -1)
/* 333:    */     {
/* 334:627 */       returnArray = new String[1];
/* 335:628 */       returnArray[0] = splitString;
/* 336:    */     }
/* 337:    */     else
/* 338:    */     {
/* 339:    */       do
/* 340:    */       {
/* 341:634 */         len = splitString.length();
/* 342:635 */         splitBuffer.add(i++, splitString.substring(0, idx));
/* 343:636 */         splitString = splitString.substring(idx + lenTok, len);
/* 344:637 */         idx = splitString.indexOf(splitToken);
/* 345:638 */       } while (idx != -1);
/* 346:640 */       splitBuffer.add(i, splitString);
/* 347:    */       
/* 348:    */ 
/* 349:    */ 
/* 350:    */ 
/* 351:645 */       returnArray = new String[splitBuffer.size()];
/* 352:646 */       for (i = 0; i < returnArray.length; i++) {
/* 353:648 */         returnArray[i] = splitBuffer.get(i).toString();
/* 354:    */       }
/* 355:    */     }
/* 356:652 */     return returnArray;
/* 357:    */   }
/* 358:    */   
/* 359:    */   public static String replace(String original, String pattern, String replace)
/* 360:    */   {
/* 361:669 */     if (original != null)
/* 362:    */     {
/* 363:671 */       int len = pattern.length();
/* 364:672 */       StringBuffer sb = new StringBuffer();
/* 365:673 */       int found = -1;
/* 366:674 */       int start = 0;
/* 367:676 */       while ((found = original.indexOf(pattern, start)) != -1)
/* 368:    */       {
/* 369:678 */         sb.append(original.substring(start, found));
/* 370:679 */         sb.append(replace);
/* 371:680 */         start = found + len;
/* 372:    */       }
/* 373:683 */       sb.append(original.substring(start));
/* 374:    */       
/* 375:685 */       return sb.toString();
/* 376:    */     }
/* 377:688 */     return "";
/* 378:    */   }
/* 379:    */   
/* 380:    */   public static boolean isValidNumber(String value, Locale userLocale)
/* 381:    */   {
/* 382:703 */     return (isValidNumberInLocale(value, userLocale)) || (isValidNumberInLocale(value, Locale.US)) || (isValidNumberInLocale(value, Locale.ITALIAN));
/* 383:    */   }
/* 384:    */   
/* 385:    */   public static boolean isValidNumberInLocale(String value, Locale locale)
/* 386:    */   {
/* 387:    */     try
/* 388:    */     {
/* 389:722 */       NumberFormat formatter = DecimalFormat.getInstance(locale);
/* 390:723 */       formatter.parse(value);
/* 391:    */       
/* 392:725 */       ParsePosition pp = new ParsePosition(0);
/* 393:726 */       Number parsedNumber = formatter.parse(value, pp);
/* 394:728 */       if ((value.length() == pp.getIndex()) && (parsedNumber != null)) {
/* 395:730 */         return true;
/* 396:    */       }
/* 397:734 */       return false;
/* 398:    */     }
/* 399:    */     catch (ParseException e) {}
/* 400:737 */     return false;
/* 401:    */   }
/* 402:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     psdi.plusc.app.pluscds.pluscmobilecommon.PlusCToolKitTOCommon
 * JD-Core Version:    0.7.0.1
 */