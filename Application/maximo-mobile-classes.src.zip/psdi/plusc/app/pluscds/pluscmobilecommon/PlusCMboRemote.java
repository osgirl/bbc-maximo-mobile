package psdi.plusc.app.pluscds.pluscmobilecommon;

import java.io.Serializable;
import java.util.Date;
import java.util.Locale;
import java.util.Set;

public abstract interface PlusCMboRemote
  extends Serializable
{
  public static final long NOVALIDATION = 1L;
  public static final long NOACCESSCHECK = 2L;
  public static final long DELAYVALIDATION = 4L;
  public static final long NOACTION = 8L;
  public static final long NOVALIDATION_AND_NOACTION = 9L;
  public static final long NONE = 0L;
  
  public abstract void setFieldName(String paramString);
  
  public abstract boolean isRoundUpField();
  
  public abstract String getString(String paramString);
  
  public abstract Integer getInt(String paramString);
  
  public abstract Long getLong(String paramString);
  
  public abstract Boolean getBoolean(String paramString);
  
  public abstract Object getObject(String paramString);
  
  public abstract Date getDate(String paramString);
  
  public abstract PlusCDSTO getPlusCDSTO();
  
  public abstract void setPlusCDSTO(PlusCDSTO paramPlusCDSTO);
  
  public abstract PlusCDSInstrTO getPlusCDSInstrTO();
  
  public abstract void setPlusCDSInstTO(PlusCDSInstrTO paramPlusCDSInstrTO);
  
  public abstract PlusCDSPointTO getPlusCDSPointTO();
  
  public abstract void setPlusCDSPointTO(PlusCDSPointTO paramPlusCDSPointTO);
  
  public abstract void setPlusCWODSTO(PlusCWODSTO paramPlusCWODSTO);
  
  public abstract PlusCWODSTO getPlusCWODSTO();
  
  public abstract void setPlusCWODSInstrTO(PlusCWODSInstrTO paramPlusCWODSInstrTO);
  
  public abstract PlusCWODSInstrTO getPlusCWODSInstrTO();
  
  public abstract void setPlusCWODSPointTO(PlusCWODSPointTO paramPlusCWODSPointTO);
  
  public abstract PlusCWODSPointTO getPlusCWODSPointTO();
  
  public abstract void setValue(String paramString, Object paramObject);
  
  public abstract void setValue(String paramString, Object paramObject, boolean paramBoolean);
  
  public abstract void setValue(String paramString, Object paramObject, long paramLong);
  
  public abstract void setValue(String paramString, Object paramObject, long paramLong, boolean paramBoolean);
  
  public abstract Locale getLocale();
  
  public abstract void setLocale(Locale paramLocale);
  
  public abstract boolean isNull(String paramString);
  
  public abstract Set getChangedFields();
  
  public abstract void clearAllChangedFieldsSets();
  
  public abstract long getValidationFlag(String paramString);
  
  public abstract Set getNonPersistentFieldsName();
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     psdi.plusc.app.pluscds.pluscmobilecommon.PlusCMboRemote
 * JD-Core Version:    0.7.0.1
 */