/*   1:    */ package psdi.plusc.app.pluscds.pluscmobilecommon;
/*   2:    */ 
/*   3:    */ import com.ibm.tivoli.maximo.util.mboadapter.MboAdapter;
/*   4:    */ import com.ibm.tivoli.maximo.util.mboadapter.MboAdapterConstants;
/*   5:    */ import com.ibm.tivoli.maximo.util.mboadapter.MboSetAdapter;
/*   6:    */ import java.util.Iterator;
/*   7:    */ 
/*   8:    */ public abstract class PlusCWODsSetDelegate
/*   9:    */   implements MboAdapterConstants
/*  10:    */ {
/*  11:    */   MboSetAdapter thisMboSet;
/*  12:    */   
/*  13:    */   public PlusCWODsSetDelegate(MboSetAdapter thisMboSet)
/*  14:    */   {
/*  15: 35 */     this.thisMboSet = thisMboSet;
/*  16:    */   }
/*  17:    */   
/*  18:    */   protected abstract PlusCWODsDelegate getWoDsDelegate(MboAdapter paramMboAdapter);
/*  19:    */   
/*  20:    */   public void applyRequiredRules(boolean changeValue)
/*  21:    */     throws Exception
/*  22:    */   {
/*  23: 50 */     if (this.thisMboSet.isEmpty()) {
/*  24: 54 */       return;
/*  25:    */     }
/*  26: 56 */     if (this.thisMboSet.count() == 1)
/*  27:    */     {
/*  28: 61 */       MboAdapter woDs = this.thisMboSet.getMbo(0);
/*  29: 62 */       woDs.setValueIfDifferent("REQUIRED", true, 3L);
/*  30: 63 */       woDs.setReadOnly("REQUIRED", true);
/*  31:    */     }
/*  32:    */     else
/*  33:    */     {
/*  34: 70 */       MboAdapter firstWoDs = null;
/*  35: 71 */       MboAdapter loopWoDs = null;
/*  36:    */       
/*  37: 73 */       Iterator it = this.thisMboSet.iterator();
/*  38: 74 */       while (it.hasNext())
/*  39:    */       {
/*  40: 75 */         MboAdapter woDsMbo = (MboAdapter)it.next();
/*  41: 76 */         PlusCWODsDelegate woDs = getWoDsDelegate(woDsMbo);
/*  42: 78 */         if (!woDsMbo.toBeDeleted())
/*  43:    */         {
/*  44: 80 */           if (firstWoDs == null) {
/*  45: 81 */             firstWoDs = woDsMbo;
/*  46:    */           }
/*  47: 87 */           boolean required = false;
/*  48: 89 */           if (woDsMbo.getBoolean("REQUIREDALWAYS")) {
/*  49: 90 */             required = true;
/*  50:    */           }
/*  51: 93 */           if (!woDs.allPointsAreCleared()) {
/*  52: 94 */             required = true;
/*  53:    */           }
/*  54: 97 */           if (woDs.isLoop())
/*  55:    */           {
/*  56: 98 */             required = true;
/*  57: 99 */             loopWoDs = woDsMbo;
/*  58:    */           }
/*  59:102 */           if (changeValue) {
/*  60:103 */             woDsMbo.setValueIfDifferent("REQUIRED", required, 3L);
/*  61:    */           }
/*  62:105 */           woDsMbo.setReadOnly("REQUIRED", required);
/*  63:    */         }
/*  64:    */       }
/*  65:112 */       if ((loopWoDs == null) && 
/*  66:113 */         (changeValue)) {
/*  67:114 */         firstWoDs.setValueIfDifferent("REQUIRED", true, 3L);
/*  68:    */       }
/*  69:    */     }
/*  70:    */   }
/*  71:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     psdi.plusc.app.pluscds.pluscmobilecommon.PlusCWODsSetDelegate
 * JD-Core Version:    0.7.0.1
 */