/*   1:    */ package psdi.plusc.app.pluscds.pluscmobilecommon;
/*   2:    */ 
/*   3:    */ import java.lang.reflect.Method;
/*   4:    */ import java.util.Date;
/*   5:    */ import java.util.HashMap;
/*   6:    */ import java.util.HashSet;
/*   7:    */ import java.util.Iterator;
/*   8:    */ import java.util.LinkedList;
/*   9:    */ import java.util.List;
/*  10:    */ import java.util.Locale;
/*  11:    */ import java.util.Map;
/*  12:    */ import java.util.Set;
/*  13:    */ 
/*  14:    */ public class PlusCDSTO
/*  15:    */   implements PlusCMboRemote
/*  16:    */ {
/*  17:    */   private static final long serialVersionUID = 1L;
/*  18: 42 */   private Set changedFields = new HashSet();
/*  19:    */   private String fieldName;
/*  20:    */   private Locale locale;
/*  21: 48 */   private Map mboData = new HashMap();
/*  22: 50 */   private Map validationFlags = new HashMap();
/*  23:    */   private PlusCDSPointTO plusCDSPointTO;
/*  24:    */   private PlusCDSInstrTO plusCDSInstrTO;
/*  25:    */   
/*  26:    */   public PlusCDSTO()
/*  27:    */   {
/*  28: 58 */     for (Iterator iter = getAttributeNames().iterator(); iter.hasNext();)
/*  29:    */     {
/*  30: 59 */       String element = (String)iter.next();
/*  31: 60 */       this.mboData.put(element, null);
/*  32:    */     }
/*  33:    */   }
/*  34:    */   
/*  35:    */   public void setValue(String key, Object object)
/*  36:    */   {
/*  37: 65 */     setValue(key, object, true);
/*  38:    */   }
/*  39:    */   
/*  40:    */   public void setValue(String keyName, Object object, boolean markField)
/*  41:    */   {
/*  42: 69 */     setValue(keyName, object, 0L, markField);
/*  43:    */   }
/*  44:    */   
/*  45:    */   public Boolean getBoolean(String key)
/*  46:    */   {
/*  47: 73 */     PlusCMboRemote suitable = getObjectOwner(key);
/*  48: 74 */     Object value = suitable.getObject(key);
/*  49: 75 */     return value == null ? new Boolean(false) : (Boolean)value;
/*  50:    */   }
/*  51:    */   
/*  52:    */   public String getCHANGEBY()
/*  53:    */   {
/*  54: 79 */     return getString("CHANGEBY");
/*  55:    */   }
/*  56:    */   
/*  57:    */   public Date getCHANGEDATE()
/*  58:    */   {
/*  59: 83 */     return getDate("CHANGEDATE");
/*  60:    */   }
/*  61:    */   
/*  62:    */   public Set getChangedFields()
/*  63:    */   {
/*  64: 87 */     return this.changedFields;
/*  65:    */   }
/*  66:    */   
/*  67:    */   public Date getDate(String key)
/*  68:    */   {
/*  69: 91 */     PlusCMboRemote suitable = getObjectOwner(key);
/*  70: 92 */     return (Date)suitable.getObject(key);
/*  71:    */   }
/*  72:    */   
/*  73:    */   public String getDESCRIPTION()
/*  74:    */   {
/*  75: 96 */     return getString("DESCRIPTION");
/*  76:    */   }
/*  77:    */   
/*  78:    */   public String getDESCRIPTION_LONGDESCRIPTION()
/*  79:    */   {
/*  80:100 */     return getString("DESCRIPTION_LONGDESCRIPTION");
/*  81:    */   }
/*  82:    */   
/*  83:    */   public String getDS1()
/*  84:    */   {
/*  85:104 */     return getString("DS1");
/*  86:    */   }
/*  87:    */   
/*  88:    */   public String getDS10()
/*  89:    */   {
/*  90:109 */     return getString("DS10");
/*  91:    */   }
/*  92:    */   
/*  93:    */   public String getDS2()
/*  94:    */   {
/*  95:114 */     return getString("DS2");
/*  96:    */   }
/*  97:    */   
/*  98:    */   public String getDS3()
/*  99:    */   {
/* 100:118 */     return getString("DS3");
/* 101:    */   }
/* 102:    */   
/* 103:    */   public String getDS4()
/* 104:    */   {
/* 105:123 */     return getString("DS4");
/* 106:    */   }
/* 107:    */   
/* 108:    */   public String getDS5()
/* 109:    */   {
/* 110:128 */     return getString("DS5");
/* 111:    */   }
/* 112:    */   
/* 113:    */   public String getDS6()
/* 114:    */   {
/* 115:133 */     return getString("DS6");
/* 116:    */   }
/* 117:    */   
/* 118:    */   public String getDS7()
/* 119:    */   {
/* 120:138 */     return getString("DS7");
/* 121:    */   }
/* 122:    */   
/* 123:    */   public String getDS8()
/* 124:    */   {
/* 125:143 */     return getString("DS8");
/* 126:    */   }
/* 127:    */   
/* 128:    */   public String getDS9()
/* 129:    */   {
/* 130:148 */     return getString("DS9");
/* 131:    */   }
/* 132:    */   
/* 133:    */   public String getDSPLANNUM()
/* 134:    */   {
/* 135:153 */     return getString("DSPLANNUM");
/* 136:    */   }
/* 137:    */   
/* 138:    */   public Boolean getHASLD()
/* 139:    */   {
/* 140:158 */     return getBoolean("HASLD");
/* 141:    */   }
/* 142:    */   
/* 143:    */   public Boolean getHISTORYFLAG()
/* 144:    */   {
/* 145:163 */     return getBoolean("HISTORYFLAG");
/* 146:    */   }
/* 147:    */   
/* 148:    */   public Integer getInt(String key)
/* 149:    */   {
/* 150:168 */     PlusCMboRemote suitable = getObjectOwner(key);
/* 151:169 */     Object value = suitable.getObject(key);
/* 152:170 */     return value == null ? new Integer(0) : (Integer)value;
/* 153:    */   }
/* 154:    */   
/* 155:    */   public String getLANGCODE()
/* 156:    */   {
/* 157:175 */     return getString("LANGCODE");
/* 158:    */   }
/* 159:    */   
/* 160:    */   public Locale getLocale()
/* 161:    */   {
/* 162:180 */     return this.locale;
/* 163:    */   }
/* 164:    */   
/* 165:    */   public Long getLong(String key)
/* 166:    */   {
/* 167:185 */     PlusCMboRemote suitable = getObjectOwner(key);
/* 168:186 */     Object value = suitable.getObject(key);
/* 169:187 */     return value == null ? new Long(0L) : (Long)value;
/* 170:    */   }
/* 171:    */   
/* 172:    */   public String getNP_STATUSMEMO()
/* 173:    */   {
/* 174:192 */     return getString("NP_STATUSMEMO");
/* 175:    */   }
/* 176:    */   
/* 177:    */   public Object getObject(String key)
/* 178:    */   {
/* 179:197 */     return this.mboData.get(key.toUpperCase());
/* 180:    */   }
/* 181:    */   
/* 182:    */   public String getORGID()
/* 183:    */   {
/* 184:202 */     return getString("ORGID");
/* 185:    */   }
/* 186:    */   
/* 187:    */   public PlusCDSInstrTO getPlusCDSInstrTO()
/* 188:    */   {
/* 189:207 */     return this.plusCDSInstrTO;
/* 190:    */   }
/* 191:    */   
/* 192:    */   public PlusCDSPointTO getPlusCDSPointTO()
/* 193:    */   {
/* 194:212 */     return this.plusCDSPointTO;
/* 195:    */   }
/* 196:    */   
/* 197:    */   public PlusCDSTO getPlusCDSTO()
/* 198:    */   {
/* 199:217 */     return this;
/* 200:    */   }
/* 201:    */   
/* 202:    */   public String getREVCOMMENTS()
/* 203:    */   {
/* 204:222 */     return getString("REVCOMMENTS");
/* 205:    */   }
/* 206:    */   
/* 207:    */   public String getREVCOMMENTS_LONGDESCRIPTION()
/* 208:    */   {
/* 209:227 */     return getString("REVCOMMENTS_LONGDESCRIPTION");
/* 210:    */   }
/* 211:    */   
/* 212:    */   public Integer getREVISIONNUM()
/* 213:    */   {
/* 214:232 */     return getInt("REVISIONNUM");
/* 215:    */   }
/* 216:    */   
/* 217:    */   public String getSITEID()
/* 218:    */   {
/* 219:237 */     return getString("SITEID");
/* 220:    */   }
/* 221:    */   
/* 222:    */   public String getSTATUS()
/* 223:    */   {
/* 224:242 */     return getString("STATUS");
/* 225:    */   }
/* 226:    */   
/* 227:    */   public Date getSTATUSDATE()
/* 228:    */   {
/* 229:247 */     return getDate("STATUSDATE");
/* 230:    */   }
/* 231:    */   
/* 232:    */   public String getString(String key)
/* 233:    */   {
/* 234:252 */     PlusCMboRemote suitable = getObjectOwner(key);
/* 235:253 */     Object value = suitable.getObject(key);
/* 236:254 */     return value == null ? "" : value.toString();
/* 237:    */   }
/* 238:    */   
/* 239:    */   public String getTOSITEID()
/* 240:    */   {
/* 241:259 */     return getString("TOSITEID");
/* 242:    */   }
/* 243:    */   
/* 244:    */   public Boolean getVIEWASLOOP()
/* 245:    */   {
/* 246:264 */     return getBoolean("VIEWASLOOP");
/* 247:    */   }
/* 248:    */   
/* 249:    */   public boolean isNull(String key)
/* 250:    */   {
/* 251:269 */     Object value = null;
/* 252:270 */     if ((getPlusCDSInstrTO() != null) && (getPlusCDSInstrTO().containsAttribute(key)))
/* 253:    */     {
/* 254:271 */       value = getPlusCDSInstrTO().getObject(key);
/* 255:272 */       return (value == null) || (value.toString().trim().equals(""));
/* 256:    */     }
/* 257:274 */     if ((getPlusCDSPointTO() != null) && (getPlusCDSPointTO().containsAttribute(key)))
/* 258:    */     {
/* 259:275 */       value = getPlusCDSPointTO().getObject(key);
/* 260:276 */       return (value == null) || (value.toString().trim().equals(""));
/* 261:    */     }
/* 262:278 */     if ((getPlusCDSTO() != null) && (getPlusCDSTO().containsAttribute(key)))
/* 263:    */     {
/* 264:279 */       value = getPlusCDSTO().getObject(key);
/* 265:280 */       return (value == null) || (value.toString().trim().equals(""));
/* 266:    */     }
/* 267:282 */     return true;
/* 268:    */   }
/* 269:    */   
/* 270:    */   public boolean isRoundUpField()
/* 271:    */   {
/* 272:287 */     String fieldName = this.fieldName;
/* 273:288 */     return (fieldName != null) && (!fieldName.equalsIgnoreCase("INSTRCALRANGEFROM")) && (!fieldName.equalsIgnoreCase("INSTRCALRANGETO")) && (!fieldName.equalsIgnoreCase("INSTROUTRANGEFROM")) && (!fieldName.equalsIgnoreCase("INSTROUTRANGETO")) && (!fieldName.equalsIgnoreCase("RON1LOWERVALUE")) && (!fieldName.equalsIgnoreCase("RON1UPPERVALUE")) && (!fieldName.equalsIgnoreCase("TOL1LOWERVALUE")) && (!fieldName.equalsIgnoreCase("TOL1UPPERVALUE")) && (!fieldName.equalsIgnoreCase("TOL2LOWERVALUE")) && (!fieldName.equalsIgnoreCase("TOL2UPPERVALUE")) && (!fieldName.equalsIgnoreCase("TOL3LOWERVALUE")) && (!fieldName.equalsIgnoreCase("TOL3UPPERVALUE")) && (!fieldName.equalsIgnoreCase("TOL4LOWERVALUE")) && (!fieldName.equalsIgnoreCase("TOL4UPPERVALUE")) && (!fieldName.equalsIgnoreCase("TOL1SUMEU")) && (!fieldName.equalsIgnoreCase("TOL1SUMREAD")) && (!fieldName.equalsIgnoreCase("TOL1SUMSPAN")) && (!fieldName.equalsIgnoreCase("TOL1SUMURV")) && (!fieldName.equalsIgnoreCase("TOL2SUMEU")) && (!fieldName.equalsIgnoreCase("TOL2SUMREAD")) && (!fieldName.equalsIgnoreCase("TOL2SUMSPAN")) && (!fieldName.equalsIgnoreCase("TOL2SUMURV")) && (!fieldName.equalsIgnoreCase("TOL3SUMEU")) && (!fieldName.equalsIgnoreCase("TOL3SUMREAD")) && (!fieldName.equalsIgnoreCase("TOL3SUMSPAN")) && (!fieldName.equalsIgnoreCase("TOL3SUMURV")) && (!fieldName.equalsIgnoreCase("TOL4SUMEU")) && (!fieldName.equalsIgnoreCase("TOL4SUMREAD")) && (!fieldName.equalsIgnoreCase("TOL4SUMSPAN")) && (!fieldName.equalsIgnoreCase("TOL4SUMURV"));
/* 274:    */   }
/* 275:    */   
/* 276:    */   public void setCHANGEBY(String changeby)
/* 277:    */   {
/* 278:322 */     setValue("CHANGEBY", changeby, false);
/* 279:    */   }
/* 280:    */   
/* 281:    */   public void setCHANGEDATE(Date changedate)
/* 282:    */   {
/* 283:327 */     setValue("CHANGEDATE", changedate, false);
/* 284:    */   }
/* 285:    */   
/* 286:    */   public void setDESCRIPTION(String description)
/* 287:    */   {
/* 288:332 */     setValue("DESCRIPTION", description, false);
/* 289:    */   }
/* 290:    */   
/* 291:    */   public void setDESCRIPTION_LONGDESCRIPTION(String description_longdescription)
/* 292:    */   {
/* 293:337 */     setValue("DESCRIPTION_LONGDESCRIPTION", description_longdescription, false);
/* 294:    */   }
/* 295:    */   
/* 296:    */   public void setDS1(String ds1)
/* 297:    */   {
/* 298:342 */     setValue("DS1", ds1, false);
/* 299:    */   }
/* 300:    */   
/* 301:    */   public void setDS10(String ds10)
/* 302:    */   {
/* 303:347 */     setValue("DS10", ds10, false);
/* 304:    */   }
/* 305:    */   
/* 306:    */   public void setDS2(String ds2)
/* 307:    */   {
/* 308:352 */     setValue("DS2", ds2, false);
/* 309:    */   }
/* 310:    */   
/* 311:    */   public void setDS3(String ds3)
/* 312:    */   {
/* 313:357 */     setValue("DS3", ds3, false);
/* 314:    */   }
/* 315:    */   
/* 316:    */   public void setDS4(String ds4)
/* 317:    */   {
/* 318:362 */     setValue("DS4", ds4, false);
/* 319:    */   }
/* 320:    */   
/* 321:    */   public void setDS5(String ds5)
/* 322:    */   {
/* 323:367 */     setValue("DS5", ds5, false);
/* 324:    */   }
/* 325:    */   
/* 326:    */   public void setDS6(String ds6)
/* 327:    */   {
/* 328:372 */     setValue("DS6", ds6, false);
/* 329:    */   }
/* 330:    */   
/* 331:    */   public void setDS7(String ds7)
/* 332:    */   {
/* 333:377 */     setValue("DS7", ds7, false);
/* 334:    */   }
/* 335:    */   
/* 336:    */   public void setDS8(String ds8)
/* 337:    */   {
/* 338:382 */     setValue("DS8", ds8, false);
/* 339:    */   }
/* 340:    */   
/* 341:    */   public void setDS9(String ds9)
/* 342:    */   {
/* 343:387 */     setValue("DS9", ds9, false);
/* 344:    */   }
/* 345:    */   
/* 346:    */   public void setDSPLANNUM(String dsplannum)
/* 347:    */   {
/* 348:392 */     setValue("DSPLANNUM", dsplannum, false);
/* 349:    */   }
/* 350:    */   
/* 351:    */   public void setFieldName(String name)
/* 352:    */   {
/* 353:397 */     this.fieldName = name;
/* 354:    */   }
/* 355:    */   
/* 356:    */   public void setHASLD(Boolean hasld)
/* 357:    */   {
/* 358:402 */     setValue("HASLD", hasld, false);
/* 359:    */   }
/* 360:    */   
/* 361:    */   public void setHISTORYFLAG(Boolean historyflag)
/* 362:    */   {
/* 363:407 */     setValue("HISTORYFLAG", historyflag, false);
/* 364:    */   }
/* 365:    */   
/* 366:    */   public void setLANGCODE(String langcode)
/* 367:    */   {
/* 368:412 */     setValue("LANGCODE", langcode, false);
/* 369:    */   }
/* 370:    */   
/* 371:    */   public void setLocale(Locale locale)
/* 372:    */   {
/* 373:417 */     this.locale = locale;
/* 374:    */   }
/* 375:    */   
/* 376:    */   public void setNP_STATUSMEMO(String np_statusmemo)
/* 377:    */   {
/* 378:422 */     setValue("NP_STATUSMEMO", np_statusmemo, false);
/* 379:    */   }
/* 380:    */   
/* 381:    */   public void setORGID(String orgid)
/* 382:    */   {
/* 383:427 */     setValue("ORGID", orgid, false);
/* 384:    */   }
/* 385:    */   
/* 386:    */   public void setREVCOMMENTS(String revcomments)
/* 387:    */   {
/* 388:432 */     setValue("REVCOMMENTS", revcomments, false);
/* 389:    */   }
/* 390:    */   
/* 391:    */   public void setREVCOMMENTS_LONGDESCRIPTION(String revcomments_longdescription)
/* 392:    */   {
/* 393:437 */     setValue("REVCOMMENTS_LONGDESCRIPTION", revcomments_longdescription, false);
/* 394:    */   }
/* 395:    */   
/* 396:    */   public void setREVISIONNUM(Integer revisionnum)
/* 397:    */   {
/* 398:442 */     setValue("REVISIONNUM", revisionnum, false);
/* 399:    */   }
/* 400:    */   
/* 401:    */   public void setSITEID(String siteid)
/* 402:    */   {
/* 403:447 */     setValue("SITEID", siteid, false);
/* 404:    */   }
/* 405:    */   
/* 406:    */   public void setSTATUS(String status)
/* 407:    */   {
/* 408:452 */     setValue("STATUS", status, false);
/* 409:    */   }
/* 410:    */   
/* 411:    */   public void setSTATUSDATE(Date statusdate)
/* 412:    */   {
/* 413:456 */     setValue("STATUSDATE", statusdate, false);
/* 414:    */   }
/* 415:    */   
/* 416:    */   public void setTOSITEID(String tositeid)
/* 417:    */   {
/* 418:460 */     setValue("TOSITEID", tositeid, false);
/* 419:    */   }
/* 420:    */   
/* 421:    */   public void setVIEWASLOOP(Boolean viewasloop)
/* 422:    */   {
/* 423:464 */     setValue("VIEWASLOOP", viewasloop, false);
/* 424:    */   }
/* 425:    */   
/* 426:    */   public void setPlusCDSTO(PlusCDSTO plusCDSTO)
/* 427:    */   {
/* 428:468 */     throw new UnsupportedOperationException("In this class this method is not implemented.");
/* 429:    */   }
/* 430:    */   
/* 431:    */   public void setPlusCDSInstTO(PlusCDSInstrTO plusCDSInstrTO)
/* 432:    */   {
/* 433:472 */     this.plusCDSInstrTO = plusCDSInstrTO;
/* 434:473 */     if (plusCDSInstrTO.getPlusCDSTO() != this) {
/* 435:474 */       plusCDSInstrTO.setPlusCDSTO(this);
/* 436:    */     }
/* 437:    */   }
/* 438:    */   
/* 439:    */   public void setPlusCDSPointTO(PlusCDSPointTO plusCDSPointTO)
/* 440:    */   {
/* 441:479 */     this.plusCDSPointTO = plusCDSPointTO;
/* 442:480 */     if (plusCDSPointTO.getPlusCDSTO() != this) {
/* 443:481 */       plusCDSPointTO.setPlusCDSTO(this);
/* 444:    */     }
/* 445:    */   }
/* 446:    */   
/* 447:    */   protected boolean containsAttribute(String attributeName)
/* 448:    */   {
/* 449:485 */     return this.mboData.containsKey(attributeName.toUpperCase());
/* 450:    */   }
/* 451:    */   
/* 452:    */   private PlusCMboRemote getObjectOwner(String attributeName)
/* 453:    */   {
/* 454:489 */     if (getPlusCDSInstrTO().containsAttribute(attributeName)) {
/* 455:490 */       return getPlusCDSInstrTO();
/* 456:    */     }
/* 457:493 */     if (getPlusCDSPointTO().containsAttribute(attributeName)) {
/* 458:494 */       return getPlusCDSPointTO();
/* 459:    */     }
/* 460:497 */     if (getPlusCDSTO().containsAttribute(attributeName)) {
/* 461:498 */       return getPlusCDSTO();
/* 462:    */     }
/* 463:501 */     throw new RuntimeException("Neither of suitable classes have the attribute " + attributeName);
/* 464:    */   }
/* 465:    */   
/* 466:    */   private static List getAttributeNames()
/* 467:    */   {
/* 468:505 */     List list = new LinkedList();
/* 469:506 */     Method[] methods = PlusCDSTO.class.getMethods();
/* 470:507 */     for (int i = 0; i < methods.length; i++) {
/* 471:508 */       if (methods[i].getName().indexOf("set") == 0) {
/* 472:509 */         list.add(methods[i].getName().substring(3).toUpperCase());
/* 473:    */       }
/* 474:    */     }
/* 475:512 */     return list;
/* 476:    */   }
/* 477:    */   
/* 478:    */   public void clearAllChangedFieldsSets()
/* 479:    */   {
/* 480:516 */     if (getPlusCDSInstrTO() != null) {
/* 481:517 */       getPlusCDSInstrTO().getChangedFields().clear();
/* 482:    */     }
/* 483:519 */     if (getPlusCDSTO() != null) {
/* 484:520 */       getPlusCDSTO().getChangedFields().clear();
/* 485:    */     }
/* 486:522 */     if (getPlusCDSPointTO() != null) {
/* 487:523 */       getPlusCDSPointTO().getChangedFields().clear();
/* 488:    */     }
/* 489:    */   }
/* 490:    */   
/* 491:    */   public void setPlusCWODSTO(PlusCWODSTO plusCWODSTO)
/* 492:    */   {
/* 493:528 */     throw new UnsupportedOperationException("In this class this method is not implemented.");
/* 494:    */   }
/* 495:    */   
/* 496:    */   public PlusCWODSTO getPlusCWODSTO()
/* 497:    */   {
/* 498:532 */     throw new UnsupportedOperationException("In this class this method is not implemented.");
/* 499:    */   }
/* 500:    */   
/* 501:    */   public void setPlusCWODSInstrTO(PlusCWODSInstrTO plusCWODSInstrTO)
/* 502:    */   {
/* 503:535 */     throw new UnsupportedOperationException("In this class this method is not implemented.");
/* 504:    */   }
/* 505:    */   
/* 506:    */   public PlusCWODSInstrTO getPlusCWODSInstrTO()
/* 507:    */   {
/* 508:539 */     throw new UnsupportedOperationException("In this class this method is not implemented.");
/* 509:    */   }
/* 510:    */   
/* 511:    */   public void setPlusCWODSPointTO(PlusCWODSPointTO plusCWODSPointTO)
/* 512:    */   {
/* 513:542 */     throw new UnsupportedOperationException("In this class this method is not implemented.");
/* 514:    */   }
/* 515:    */   
/* 516:    */   public PlusCWODSPointTO getPlusCWODSPointTO()
/* 517:    */   {
/* 518:546 */     throw new UnsupportedOperationException("In this class this method is not implemented.");
/* 519:    */   }
/* 520:    */   
/* 521:    */   public void setValue(String key, Object object, long validationFlag)
/* 522:    */   {
/* 523:550 */     setValue(key, object, validationFlag, true);
/* 524:    */   }
/* 525:    */   
/* 526:    */   public void setValue(String keyName, Object object, long validationFlag, boolean markField)
/* 527:    */   {
/* 528:555 */     if (containsAttribute(keyName))
/* 529:    */     {
/* 530:556 */       if (markField)
/* 531:    */       {
/* 532:557 */         this.changedFields.add(keyName.toUpperCase());
/* 533:558 */         this.validationFlags.put(keyName.toUpperCase(), new Long(validationFlag));
/* 534:    */       }
/* 535:    */       else
/* 536:    */       {
/* 537:560 */         this.validationFlags.remove(keyName.toUpperCase());
/* 538:    */       }
/* 539:562 */       this.mboData.put(keyName.toUpperCase(), object);
/* 540:    */     }
/* 541:564 */     else if ((this.plusCDSPointTO != null) && (getPlusCDSPointTO().containsAttribute(keyName)))
/* 542:    */     {
/* 543:565 */       getPlusCDSPointTO().setValue(keyName, object, validationFlag, markField);
/* 544:    */     }
/* 545:566 */     else if ((this.plusCDSInstrTO != null) && (getPlusCDSInstrTO().containsAttribute(keyName)))
/* 546:    */     {
/* 547:567 */       getPlusCDSInstrTO().setValue(keyName, object, validationFlag, markField);
/* 548:    */     }
/* 549:    */     else
/* 550:    */     {
/* 551:569 */       throw new RuntimeException("No suitable class to set " + keyName + " attribute");
/* 552:    */     }
/* 553:    */   }
/* 554:    */   
/* 555:    */   public long getValidationFlag(String key)
/* 556:    */   {
/* 557:576 */     String keyUpper = key.toUpperCase();
/* 558:577 */     PlusCMboRemote suitable = getObjectOwner(keyUpper);
/* 559:578 */     long value = 0L;
/* 560:579 */     if (suitable == this)
/* 561:    */     {
/* 562:580 */       Object o = this.validationFlags.get(keyUpper);
/* 563:581 */       value = o != null ? new Long(o.toString()).longValue() : 11L;
/* 564:    */     }
/* 565:    */     else
/* 566:    */     {
/* 567:583 */       suitable.getValidationFlag(key);
/* 568:    */     }
/* 569:585 */     return value;
/* 570:    */   }
/* 571:    */   
/* 572:    */   public Set getNonPersistentFieldsName()
/* 573:    */   {
/* 574:592 */     throw new UnsupportedOperationException("In this class this method is not implemented.");
/* 575:    */   }
/* 576:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     psdi.plusc.app.pluscds.pluscmobilecommon.PlusCDSTO
 * JD-Core Version:    0.7.0.1
 */