/*   1:    */ package psdi.plusc.app.pluscds.pluscmobilecommon;
/*   2:    */ 
/*   3:    */ import com.ibm.tivoli.maximo.util.mboadapter.MboAdapter;
/*   4:    */ import com.ibm.tivoli.maximo.util.mboadapter.MboAdapterConstants;
/*   5:    */ import com.ibm.tivoli.maximo.util.mboadapter.MboSetAdapter;
/*   6:    */ import java.util.Arrays;
/*   7:    */ import java.util.HashSet;
/*   8:    */ import java.util.Locale;
/*   9:    */ import java.util.Set;
/*  10:    */ 
/*  11:    */ public abstract class PlusCWODsPointDelegate
/*  12:    */   implements MboAdapterConstants
/*  13:    */ {
/*  14:    */   protected MboAdapter thisMbo;
/*  15:    */   protected PlusCWODsInstrDelegate woDsInstrDelegate;
/*  16:    */   
/*  17:    */   protected abstract PlusCWODsInstrDelegate findParentInstrDelegate()
/*  18:    */     throws Exception;
/*  19:    */   
/*  20:    */   protected abstract MboSetAdapter getAveragePointsSet()
/*  21:    */     throws Exception;
/*  22:    */   
/*  23:    */   public abstract PlusCWODsPointDelegate newInstance(MboAdapter paramMboAdapter, PlusCWODsInstrDelegate paramPlusCWODsInstrDelegate)
/*  24:    */     throws Exception;
/*  25:    */   
/*  26:    */   public PlusCWODsPointDelegate(MboAdapter mbo, PlusCWODsInstrDelegate woDsInstrDelegate)
/*  27:    */   {
/*  28: 50 */     this.thisMbo = mbo;
/*  29: 51 */     this.woDsInstrDelegate = woDsInstrDelegate;
/*  30:    */   }
/*  31:    */   
/*  32:    */   public PlusCWODsInstrDelegate getInstrDelegate()
/*  33:    */     throws Exception
/*  34:    */   {
/*  35: 55 */     if (this.woDsInstrDelegate != null) {
/*  36: 56 */       return this.woDsInstrDelegate;
/*  37:    */     }
/*  38: 58 */     return findParentInstrDelegate();
/*  39:    */   }
/*  40:    */   
/*  41:    */   public String getPlanType()
/*  42:    */     throws Exception
/*  43:    */   {
/*  44: 63 */     return getInstrDelegate().getType();
/*  45:    */   }
/*  46:    */   
/*  47:    */   public boolean isRepeatable()
/*  48:    */     throws Exception
/*  49:    */   {
/*  50: 67 */     return getInstrDelegate().isRepeatable();
/*  51:    */   }
/*  52:    */   
/*  53:    */   public boolean isCalPoint()
/*  54:    */     throws Exception
/*  55:    */   {
/*  56: 71 */     return getInstrDelegate().hasCalPoints();
/*  57:    */   }
/*  58:    */   
/*  59:    */   public boolean isFunctionCheck()
/*  60:    */     throws Exception
/*  61:    */   {
/*  62: 75 */     return getInstrDelegate().hasFunctionChecks();
/*  63:    */   }
/*  64:    */   
/*  65:    */   public boolean isDynamicCheck()
/*  66:    */     throws Exception
/*  67:    */   {
/*  68: 79 */     return getInstrDelegate().hasDynamicChecks();
/*  69:    */   }
/*  70:    */   
/*  71:    */   public boolean isAverage()
/*  72:    */     throws Exception
/*  73:    */   {
/*  74: 83 */     return this.thisMbo.getBoolean("ISAVERAGE");
/*  75:    */   }
/*  76:    */   
/*  77:    */   public boolean isAllEntered()
/*  78:    */     throws Exception
/*  79:    */   {
/*  80: 95 */     if (isCalPoint())
/*  81:    */     {
/*  82: 97 */       if (getPlanType().equalsIgnoreCase("ANALOG")) {
/*  83: 99 */         return (!this.thisMbo.isNull("ASFOUNDINPUT")) && (!this.thisMbo.isNull("ASFOUNDOUTPUT")) && (!this.thisMbo.isNull("ASLEFTINPUT")) && (!this.thisMbo.isNull("ASLEFTOUTPUT"));
/*  84:    */       }
/*  85:106 */       return (!this.thisMbo.isNull("ASFOUNDSETPOINT")) && (!this.thisMbo.isNull("ASLEFTSETPOINT"));
/*  86:    */     }
/*  87:111 */     if (isFunctionCheck()) {
/*  88:113 */       return ((!this.thisMbo.isNull("ASFOUNDPASS")) || (!this.thisMbo.isNull("ASFOUNDFAIL"))) && ((!this.thisMbo.isNull("ASLEFTPASS")) || (!this.thisMbo.isNull("ASLEFTFAIL")));
/*  89:    */     }
/*  90:118 */     if (isDynamicCheck()) {
/*  91:120 */       return (!this.thisMbo.isNull("ASFOUNDINPUT")) && (!this.thisMbo.isNull("ASLEFTINPUT"));
/*  92:    */     }
/*  93:125 */     return true;
/*  94:    */   }
/*  95:    */   
/*  96:    */   public boolean isAllEntered(String prefix)
/*  97:    */     throws Exception
/*  98:    */   {
/*  99:138 */     if (getPlanType().equalsIgnoreCase("ANALOG"))
/* 100:    */     {
/* 101:140 */       if ((!this.thisMbo.isNull(prefix + "INPUT")) && (!this.thisMbo.isNull(prefix + "OUTPUT"))) {
/* 102:141 */         return true;
/* 103:    */       }
/* 104:143 */       return false;
/* 105:    */     }
/* 106:148 */     return !this.thisMbo.isNull(prefix + "SETPOINT");
/* 107:    */   }
/* 108:    */   
/* 109:    */   public boolean isAllClear()
/* 110:    */     throws Exception
/* 111:    */   {
/* 112:161 */     if (getPlanType().equalsIgnoreCase("ANALOG")) {
/* 113:163 */       return (this.thisMbo.isNull("ASFOUNDINPUT")) && (this.thisMbo.isNull("ASFOUNDOUTPUT")) && (this.thisMbo.isNull("ASLEFTINPUT")) && (this.thisMbo.isNull("ASLEFTOUTPUT"));
/* 114:    */     }
/* 115:170 */     return (this.thisMbo.isNull("ASFOUNDSETPOINT")) && (this.thisMbo.isNull("ASLEFTSETPOINT"));
/* 116:    */   }
/* 117:    */   
/* 118:    */   public void setFunctionCheckPass(String fieldName, boolean status)
/* 119:    */     throws Exception
/* 120:    */   {
/* 121:190 */     boolean isFound = fieldName.indexOf("FOUND") > 0;
/* 122:191 */     boolean isPass = fieldName.indexOf("PASS") > 0;
/* 123:    */     
/* 124:193 */     String oppositeFieldName = "AS" + (isFound ? "FOUND" : "LEFT") + (isPass ? "FAIL" : "PASS");
/* 125:    */     
/* 126:195 */     this.thisMbo.setValue(fieldName, status, 11L);
/* 127:196 */     this.thisMbo.setValue(oppositeFieldName, !status, 11L);
/* 128:    */   }
/* 129:    */   
/* 130:    */   public MboAdapter getGroupAveragePoint()
/* 131:    */     throws Exception
/* 132:    */   {
/* 133:210 */     if ((this.thisMbo.getBoolean("ISAVERAGE")) || (!getInstrDelegate().isRepeatable())) {
/* 134:211 */       return this.thisMbo;
/* 135:    */     }
/* 136:214 */     MboSetAdapter averagesSet = getAveragePointsSet();
/* 137:215 */     return averagesSet.getMbo(0);
/* 138:    */   }
/* 139:    */   
/* 140:    */   public MboAdapter[] getGroupPoints()
/* 141:    */     throws Exception
/* 142:    */   {
/* 143:227 */     MboSetAdapter points = getInstrDelegate().getWODsPointSet(true);
/* 144:228 */     MboAdapter[] pointsArray = points.getMbosByAttribValues(new String[][] { { "POINT", this.thisMbo.getString("POINT") }, { "ISAVERAGE", "0" } });
/* 145:    */     
/* 146:    */ 
/* 147:    */ 
/* 148:232 */     return pointsArray;
/* 149:    */   }
/* 150:    */   
/* 151:    */   public boolean hasErrors()
/* 152:    */     throws Exception
/* 153:    */   {
/* 154:239 */     if ((isRepeatable()) && (!isAverage()))
/* 155:    */     {
/* 156:240 */       PlusCWODsPointDelegate averagePoint = newInstance(getGroupAveragePoint(), this.woDsInstrDelegate);
/* 157:241 */       return averagePoint.hasErrors();
/* 158:    */     }
/* 159:244 */     String[] errorFields = { "ASFOUNDERROR", "ASLEFTERROR" };
/* 160:246 */     for (int i = 0; i <= 1; i++) {
/* 161:248 */       for (int j = 1; j <= 4; j++)
/* 162:    */       {
/* 163:250 */         String fieldName = errorFields[i] + Integer.toString(j);
/* 164:    */         
/* 165:252 */         double errorValue = PlusCToolKitTOCommon.getDouble(this.thisMbo.getString(fieldName), Locale.US);
/* 166:253 */         if ((!this.thisMbo.isNull(fieldName)) && (errorValue != 0.0D)) {
/* 167:254 */           return true;
/* 168:    */         }
/* 169:    */       }
/* 170:    */     }
/* 171:261 */     return false;
/* 172:    */   }
/* 173:    */   
/* 174:    */   public boolean meetsNoAdjustmentConditions(String adjchoice)
/* 175:    */     throws Exception
/* 176:    */   {
/* 177:266 */     PlusCWODsInstrDelegate woDsInstr = getInstrDelegate();
/* 178:269 */     if (woDsInstr.hasCalPoints())
/* 179:    */     {
/* 180:271 */       if (this.thisMbo.isNull(adjchoice))
/* 181:    */       {
/* 182:275 */         Object[] params = { this.thisMbo.getString("POINT") };
/* 183:276 */         throw this.thisMbo.newApplicationException("plusdsplan", "AllPointsNotEntered", params);
/* 184:    */       }
/* 185:279 */       double errorValue = Double.parseDouble(PlusCToolKitTOCommon.formatDouble(this.thisMbo.getString(adjchoice), Locale.US));
/* 186:280 */       if (errorValue != 0.0D)
/* 187:    */       {
/* 188:284 */         Object[] params = { this.thisMbo.getString("POINT") };
/* 189:285 */         throw this.thisMbo.newApplicationException("plusdsplan", "AllPointsNotWithTolerance", params);
/* 190:    */       }
/* 191:    */     }
/* 192:288 */     else if (woDsInstr.hasFunctionChecks())
/* 193:    */     {
/* 194:290 */       boolean asFoundPass = this.thisMbo.isNull("ASFOUNDPASS") ? false : this.thisMbo.getBoolean("ASFOUNDPASS");
/* 195:    */       
/* 196:292 */       boolean asFoundFail = this.thisMbo.isNull("ASFOUNDFAIL") ? false : this.thisMbo.getBoolean("ASFOUNDFAIL");
/* 197:295 */       if ((!asFoundPass) && (!asFoundFail))
/* 198:    */       {
/* 199:299 */         Object[] params = { this.thisMbo.getString("POINT") };
/* 200:300 */         throw this.thisMbo.newApplicationException("plusdsplan", "AllFunctionChecksNotEntered", params);
/* 201:    */       }
/* 202:    */     }
/* 203:303 */     else if (woDsInstr.hasDynamicChecks())
/* 204:    */     {
/* 205:305 */       if (this.thisMbo.isNull("ASFOUNDINPUT"))
/* 206:    */       {
/* 207:309 */         Object[] params = { this.thisMbo.getString("POINT") };
/* 208:310 */         throw this.thisMbo.newApplicationException("plusdsplan", "AllDynamicChecksNotEntered", params);
/* 209:    */       }
/* 210:    */     }
/* 211:315 */     return true;
/* 212:    */   }
/* 213:    */   
/* 214:318 */   protected static final Set EDIT_CHECKED_FIELDS = new HashSet(Arrays.asList(new String[] { "ASFOUNDINPUT", "ASFOUNDOUTPUT", "ASFOUNDSETPOINT", "ASLEFTINPUT", "ASLEFTOUTPUT", "ASLEFTSETPOINT" }));
/* 215:    */   
/* 216:    */   public boolean warnChangeMeasuredValue(String attributeName, String previousValue, String newValue)
/* 217:    */     throws Exception
/* 218:    */   {
/* 219:335 */     boolean blockEditData = this.thisMbo.getMaxVarBoolean("PLUSCEDITDATA");
/* 220:336 */     if (!blockEditData) {
/* 221:336 */       return false;
/* 222:    */     }
/* 223:340 */     if (isDynamicCheck()) {
/* 224:340 */       return false;
/* 225:    */     }
/* 226:342 */     boolean wasEmpty = (previousValue == null) || (previousValue.equals(""));
/* 227:344 */     if ((EDIT_CHECKED_FIELDS.contains(attributeName.toUpperCase())) && (!wasEmpty) && (!previousValue.equals(newValue))) {
/* 228:347 */       return true;
/* 229:    */     }
/* 230:350 */     return false;
/* 231:    */   }
/* 232:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     psdi.plusc.app.pluscds.pluscmobilecommon.PlusCWODsPointDelegate
 * JD-Core Version:    0.7.0.1
 */