/*    1:     */ package psdi.plusc.app.pluscds.pluscmobilecommon;
/*    2:     */ 
/*    3:     */ import java.lang.reflect.Method;
/*    4:     */ import java.util.Date;
/*    5:     */ import java.util.HashMap;
/*    6:     */ import java.util.HashSet;
/*    7:     */ import java.util.Iterator;
/*    8:     */ import java.util.LinkedList;
/*    9:     */ import java.util.List;
/*   10:     */ import java.util.Locale;
/*   11:     */ import java.util.Map;
/*   12:     */ import java.util.Set;
/*   13:     */ 
/*   14:     */ public class PlusCWODSPointTO
/*   15:     */   implements PlusCMboRemote
/*   16:     */ {
/*   17:     */   private static final long serialVersionUID = 1L;
/*   18:  38 */   private Set changedFields = new HashSet();
/*   19:     */   private String fieldName;
/*   20:     */   private Locale locale;
/*   21:  44 */   private Map mboData = new HashMap();
/*   22:  46 */   private Map validationFlags = new HashMap();
/*   23:     */   private PlusCWODSInstrTO plusCWODSInstrTO;
/*   24:     */   private PlusCWODSTO plusCWODSTO;
/*   25:     */   private Set nonPersistentFields;
/*   26:     */   
/*   27:     */   public PlusCWODSPointTO()
/*   28:     */   {
/*   29:  56 */     for (Iterator iter = getAttributeNames().iterator(); iter.hasNext();)
/*   30:     */     {
/*   31:  57 */       String element = (String)iter.next();
/*   32:  58 */       this.mboData.put(element, null);
/*   33:     */     }
/*   34:     */   }
/*   35:     */   
/*   36:     */   public void setFieldName(String name)
/*   37:     */   {
/*   38:  63 */     this.fieldName = name;
/*   39:     */   }
/*   40:     */   
/*   41:     */   public boolean isRoundUpField()
/*   42:     */   {
/*   43:  67 */     String fieldName = this.fieldName;
/*   44:  68 */     return (fieldName != null) && (!fieldName.equalsIgnoreCase("INSTRCALRANGEFROM")) && (!fieldName.equalsIgnoreCase("INSTRCALRANGETO")) && (!fieldName.equalsIgnoreCase("INSTROUTRANGEFROM")) && (!fieldName.equalsIgnoreCase("INSTROUTRANGETO")) && (!fieldName.equalsIgnoreCase("RON1LOWERVALUE")) && (!fieldName.equalsIgnoreCase("RON1UPPERVALUE")) && (!fieldName.equalsIgnoreCase("TOL1LOWERVALUE")) && (!fieldName.equalsIgnoreCase("TOL1UPPERVALUE")) && (!fieldName.equalsIgnoreCase("TOL2LOWERVALUE")) && (!fieldName.equalsIgnoreCase("TOL2UPPERVALUE")) && (!fieldName.equalsIgnoreCase("TOL3LOWERVALUE")) && (!fieldName.equalsIgnoreCase("TOL3UPPERVALUE")) && (!fieldName.equalsIgnoreCase("TOL4LOWERVALUE")) && (!fieldName.equalsIgnoreCase("TOL4UPPERVALUE")) && (!fieldName.equalsIgnoreCase("TOL1SUMEU")) && (!fieldName.equalsIgnoreCase("TOL1SUMREAD")) && (!fieldName.equalsIgnoreCase("TOL1SUMSPAN")) && (!fieldName.equalsIgnoreCase("TOL1SUMURV")) && (!fieldName.equalsIgnoreCase("TOL2SUMEU")) && (!fieldName.equalsIgnoreCase("TOL2SUMREAD")) && (!fieldName.equalsIgnoreCase("TOL2SUMSPAN")) && (!fieldName.equalsIgnoreCase("TOL2SUMURV")) && (!fieldName.equalsIgnoreCase("TOL3SUMEU")) && (!fieldName.equalsIgnoreCase("TOL3SUMREAD")) && (!fieldName.equalsIgnoreCase("TOL3SUMSPAN")) && (!fieldName.equalsIgnoreCase("TOL3SUMURV")) && (!fieldName.equalsIgnoreCase("TOL4SUMEU")) && (!fieldName.equalsIgnoreCase("TOL4SUMREAD")) && (!fieldName.equalsIgnoreCase("TOL4SUMSPAN")) && (!fieldName.equalsIgnoreCase("TOL4SUMURV"));
/*   45:     */   }
/*   46:     */   
/*   47:     */   public String getString(String key)
/*   48:     */   {
/*   49: 101 */     PlusCMboRemote suitable = getObjectOwner(key);
/*   50: 102 */     Object value = suitable.getObject(key);
/*   51: 103 */     return value == null ? "" : value.toString();
/*   52:     */   }
/*   53:     */   
/*   54:     */   public Integer getInt(String key)
/*   55:     */   {
/*   56: 107 */     PlusCMboRemote suitable = getObjectOwner(key);
/*   57: 108 */     Object value = suitable.getObject(key);
/*   58: 109 */     return value == null ? new Integer(0) : (Integer)value;
/*   59:     */   }
/*   60:     */   
/*   61:     */   public Long getLong(String key)
/*   62:     */   {
/*   63: 113 */     PlusCMboRemote suitable = getObjectOwner(key);
/*   64: 114 */     Object value = suitable.getObject(key);
/*   65: 115 */     return value == null ? new Long(0L) : (Long)value;
/*   66:     */   }
/*   67:     */   
/*   68:     */   public Boolean getBoolean(String key)
/*   69:     */   {
/*   70: 119 */     PlusCMboRemote suitable = getObjectOwner(key);
/*   71: 120 */     Object value = suitable.getObject(key);
/*   72: 121 */     return value == null ? new Boolean(false) : (Boolean)value;
/*   73:     */   }
/*   74:     */   
/*   75:     */   public Object getObject(String key)
/*   76:     */   {
/*   77: 125 */     return this.mboData.get(key.toUpperCase());
/*   78:     */   }
/*   79:     */   
/*   80:     */   public Date getDate(String key)
/*   81:     */   {
/*   82: 129 */     PlusCMboRemote suitable = getObjectOwner(key);
/*   83: 130 */     return (Date)suitable.getObject(key);
/*   84:     */   }
/*   85:     */   
/*   86:     */   public PlusCDSTO getPlusCDSTO()
/*   87:     */   {
/*   88: 134 */     throw new UnsupportedOperationException("In this class this method is not implemented.");
/*   89:     */   }
/*   90:     */   
/*   91:     */   public void setPlusCDSTO(PlusCDSTO plusCDSTO)
/*   92:     */   {
/*   93: 139 */     throw new UnsupportedOperationException("In this class this method is not implemented.");
/*   94:     */   }
/*   95:     */   
/*   96:     */   public PlusCDSInstrTO getPlusCDSInstrTO()
/*   97:     */   {
/*   98: 145 */     throw new UnsupportedOperationException("In this class this method is not implemented.");
/*   99:     */   }
/*  100:     */   
/*  101:     */   public void setPlusCDSInstTO(PlusCDSInstrTO plusCDSInstrTO)
/*  102:     */   {
/*  103: 150 */     throw new UnsupportedOperationException("In this class this method is not implemented.");
/*  104:     */   }
/*  105:     */   
/*  106:     */   public PlusCDSPointTO getPlusCDSPointTO()
/*  107:     */   {
/*  108: 156 */     throw new UnsupportedOperationException("In this class this method is not implemented.");
/*  109:     */   }
/*  110:     */   
/*  111:     */   public void setPlusCDSPointTO(PlusCDSPointTO plusCDSPointTO)
/*  112:     */   {
/*  113: 161 */     throw new UnsupportedOperationException("In this class this method is not implemented.");
/*  114:     */   }
/*  115:     */   
/*  116:     */   public void setPlusCWODSTO(PlusCWODSTO plusCWODSTO)
/*  117:     */   {
/*  118: 167 */     this.plusCWODSTO = plusCWODSTO;
/*  119: 168 */     if (plusCWODSTO.getPlusCWODSPointTO() != this) {
/*  120: 169 */       plusCWODSTO.setPlusCWODSPointTO(this);
/*  121:     */     }
/*  122:     */   }
/*  123:     */   
/*  124:     */   public PlusCWODSTO getPlusCWODSTO()
/*  125:     */   {
/*  126: 174 */     return this.plusCWODSTO;
/*  127:     */   }
/*  128:     */   
/*  129:     */   public void setPlusCWODSInstrTO(PlusCWODSInstrTO plusCWODSInstrTO)
/*  130:     */   {
/*  131: 178 */     this.plusCWODSInstrTO = plusCWODSInstrTO;
/*  132: 179 */     if (plusCWODSInstrTO.getPlusCWODSPointTO() != this) {
/*  133: 180 */       plusCWODSInstrTO.setPlusCWODSPointTO(this);
/*  134:     */     }
/*  135:     */   }
/*  136:     */   
/*  137:     */   public PlusCWODSInstrTO getPlusCWODSInstrTO()
/*  138:     */   {
/*  139: 184 */     return this.plusCWODSInstrTO;
/*  140:     */   }
/*  141:     */   
/*  142:     */   public void setPlusCWODSPointTO(PlusCWODSPointTO plusCWODSPointTO)
/*  143:     */   {
/*  144: 188 */     throw new UnsupportedOperationException("In this class this method is not implemented.");
/*  145:     */   }
/*  146:     */   
/*  147:     */   public PlusCWODSPointTO getPlusCWODSPointTO()
/*  148:     */   {
/*  149: 193 */     return this;
/*  150:     */   }
/*  151:     */   
/*  152:     */   public void setValue(String key, Object object)
/*  153:     */   {
/*  154: 197 */     setValue(key, object, true);
/*  155:     */   }
/*  156:     */   
/*  157:     */   public void setValue(String key, Object object, boolean markAsChanged)
/*  158:     */   {
/*  159: 201 */     setValue(key, object, 0L, markAsChanged);
/*  160:     */   }
/*  161:     */   
/*  162:     */   public Locale getLocale()
/*  163:     */   {
/*  164: 206 */     return this.locale;
/*  165:     */   }
/*  166:     */   
/*  167:     */   public void setLocale(Locale locale)
/*  168:     */   {
/*  169: 210 */     this.locale = locale;
/*  170:     */   }
/*  171:     */   
/*  172:     */   public boolean isNull(String key)
/*  173:     */   {
/*  174: 214 */     Object value = null;
/*  175: 215 */     if ((getPlusCWODSInstrTO() != null) && (getPlusCWODSInstrTO().containsAttribute(key)))
/*  176:     */     {
/*  177: 216 */       value = getPlusCWODSInstrTO().getObject(key);
/*  178: 217 */       return (value == null) || (value.toString().trim().equals(""));
/*  179:     */     }
/*  180: 219 */     if ((getPlusCWODSPointTO() != null) && (getPlusCWODSPointTO().containsAttribute(key)))
/*  181:     */     {
/*  182: 220 */       value = getPlusCWODSPointTO().getObject(key);
/*  183: 221 */       return (value == null) || (value.toString().trim().equals(""));
/*  184:     */     }
/*  185: 223 */     if ((getPlusCWODSTO() != null) && (getPlusCWODSTO().containsAttribute(key)))
/*  186:     */     {
/*  187: 224 */       value = getPlusCWODSTO().getObject(key);
/*  188: 225 */       return (value == null) || (value.toString().trim().equals(""));
/*  189:     */     }
/*  190: 227 */     return true;
/*  191:     */   }
/*  192:     */   
/*  193:     */   public Set getChangedFields()
/*  194:     */   {
/*  195: 231 */     return this.changedFields;
/*  196:     */   }
/*  197:     */   
/*  198:     */   public void clearAllChangedFieldsSets()
/*  199:     */   {
/*  200: 235 */     if (getPlusCWODSInstrTO() != null) {
/*  201: 236 */       getPlusCWODSInstrTO().getChangedFields().clear();
/*  202:     */     }
/*  203: 238 */     if (getPlusCWODSTO() != null) {
/*  204: 239 */       getPlusCWODSTO().getChangedFields().clear();
/*  205:     */     }
/*  206: 241 */     if (getPlusCWODSPointTO() != null) {
/*  207: 242 */       getPlusCWODSPointTO().getChangedFields().clear();
/*  208:     */     }
/*  209:     */   }
/*  210:     */   
/*  211:     */   protected boolean containsAttribute(String attributeName)
/*  212:     */   {
/*  213: 247 */     return this.mboData.containsKey(attributeName.toUpperCase());
/*  214:     */   }
/*  215:     */   
/*  216:     */   private PlusCMboRemote getObjectOwner(String attributeName)
/*  217:     */   {
/*  218: 251 */     if ((getPlusCWODSInstrTO() != null) && (getPlusCWODSInstrTO().containsAttribute(attributeName))) {
/*  219: 252 */       return getPlusCWODSInstrTO();
/*  220:     */     }
/*  221: 255 */     if (getPlusCWODSPointTO().containsAttribute(attributeName)) {
/*  222: 256 */       return getPlusCWODSPointTO();
/*  223:     */     }
/*  224: 259 */     if ((getPlusCWODSTO() != null) && (getPlusCWODSTO().containsAttribute(attributeName))) {
/*  225: 260 */       return getPlusCWODSTO();
/*  226:     */     }
/*  227: 263 */     throw new RuntimeException("Neither of suitable classes have the attribute " + attributeName);
/*  228:     */   }
/*  229:     */   
/*  230:     */   private static List getAttributeNames()
/*  231:     */   {
/*  232: 267 */     List list = new LinkedList();
/*  233: 268 */     Method[] methods = PlusCWODSPointTO.class.getMethods();
/*  234: 269 */     for (int i = 0; i < methods.length; i++) {
/*  235: 270 */       if (methods[i].getName().indexOf("set") == 0) {
/*  236: 271 */         list.add(methods[i].getName().substring(3).toUpperCase());
/*  237:     */       }
/*  238:     */     }
/*  239: 274 */     return list;
/*  240:     */   }
/*  241:     */   
/*  242:     */   public String getASFOUNDERROR1()
/*  243:     */   {
/*  244: 278 */     return getString("ASFOUNDERROR1");
/*  245:     */   }
/*  246:     */   
/*  247:     */   public String getASFOUNDERROR2()
/*  248:     */   {
/*  249: 282 */     return getString("ASFOUNDERROR2");
/*  250:     */   }
/*  251:     */   
/*  252:     */   public String getASFOUNDERROR3()
/*  253:     */   {
/*  254: 286 */     return getString("ASFOUNDERROR3");
/*  255:     */   }
/*  256:     */   
/*  257:     */   public String getASFOUNDERROR4()
/*  258:     */   {
/*  259: 290 */     return getString("ASFOUNDERROR4");
/*  260:     */   }
/*  261:     */   
/*  262:     */   public String getASFOUNDIN()
/*  263:     */   {
/*  264: 294 */     return getString("ASFOUNDIN");
/*  265:     */   }
/*  266:     */   
/*  267:     */   public String getASFOUNDINPUT()
/*  268:     */   {
/*  269: 298 */     return getString("ASFOUNDINPUT");
/*  270:     */   }
/*  271:     */   
/*  272:     */   public String getASFOUNDINPUT_NP()
/*  273:     */   {
/*  274: 302 */     return getString("ASFOUNDINPUT_NP");
/*  275:     */   }
/*  276:     */   
/*  277:     */   public String getASFOUNDOUT()
/*  278:     */   {
/*  279: 306 */     return getString("ASFOUNDOUT");
/*  280:     */   }
/*  281:     */   
/*  282:     */   public String getASFOUNDOUTERROR()
/*  283:     */   {
/*  284: 310 */     return getString("ASFOUNDOUTERROR");
/*  285:     */   }
/*  286:     */   
/*  287:     */   public String getASFOUNDOUTPUT()
/*  288:     */   {
/*  289: 314 */     return getString("ASFOUNDOUTPUT");
/*  290:     */   }
/*  291:     */   
/*  292:     */   public String getASFOUNDOUTPUT_NP()
/*  293:     */   {
/*  294: 318 */     return getString("ASFOUNDOUTPUT_NP");
/*  295:     */   }
/*  296:     */   
/*  297:     */   public String getASFOUNDPROERROR()
/*  298:     */   {
/*  299: 322 */     return getString("ASFOUNDPROERROR");
/*  300:     */   }
/*  301:     */   
/*  302:     */   public Boolean getASFOUNDPTERROR()
/*  303:     */   {
/*  304: 326 */     return getBoolean("ASFOUNDPTERROR");
/*  305:     */   }
/*  306:     */   
/*  307:     */   public String getASFOUNDRESPONSE()
/*  308:     */   {
/*  309: 330 */     return getString("ASFOUNDRESPONSE");
/*  310:     */   }
/*  311:     */   
/*  312:     */   public String getASFOUNDRESPONSEEU()
/*  313:     */   {
/*  314: 334 */     return getString("ASFOUNDRESPONSEEU");
/*  315:     */   }
/*  316:     */   
/*  317:     */   public String getASFOUNDSETPOINT()
/*  318:     */   {
/*  319: 338 */     return getString("ASFOUNDSETPOINT");
/*  320:     */   }
/*  321:     */   
/*  322:     */   public String getASFOUNDSETPOINT_NP()
/*  323:     */   {
/*  324: 342 */     return getString("ASFOUNDSETPOINT_NP");
/*  325:     */   }
/*  326:     */   
/*  327:     */   public String getASFOUNDTOL1LOWER()
/*  328:     */   {
/*  329: 346 */     return getString("ASFOUNDTOL1LOWER");
/*  330:     */   }
/*  331:     */   
/*  332:     */   public String getASFOUNDTOL1LOWER_NP()
/*  333:     */   {
/*  334: 350 */     return getString("ASFOUNDTOL1LOWER_NP");
/*  335:     */   }
/*  336:     */   
/*  337:     */   public String getASFOUNDTOL1LW_ORIG()
/*  338:     */   {
/*  339: 354 */     return getString("ASFOUNDTOL1LW_ORIG");
/*  340:     */   }
/*  341:     */   
/*  342:     */   public String getASFOUNDTOL1UP_ORIG()
/*  343:     */   {
/*  344: 358 */     return getString("ASFOUNDTOL1UP_ORIG");
/*  345:     */   }
/*  346:     */   
/*  347:     */   public String getASFOUNDTOL1UPPER()
/*  348:     */   {
/*  349: 362 */     return getString("ASFOUNDTOL1UPPER");
/*  350:     */   }
/*  351:     */   
/*  352:     */   public String getASFOUNDTOL1UPPER_NP()
/*  353:     */   {
/*  354: 366 */     return getString("ASFOUNDTOL1UPPER_NP");
/*  355:     */   }
/*  356:     */   
/*  357:     */   public String getASFOUNDTOL2LOWER()
/*  358:     */   {
/*  359: 370 */     return getString("ASFOUNDTOL2LOWER");
/*  360:     */   }
/*  361:     */   
/*  362:     */   public String getASFOUNDTOL2LOWER_NP()
/*  363:     */   {
/*  364: 374 */     return getString("ASFOUNDTOL2LOWER_NP");
/*  365:     */   }
/*  366:     */   
/*  367:     */   public String getASFOUNDTOL2LW_ORIG()
/*  368:     */   {
/*  369: 378 */     return getString("ASFOUNDTOL2LW_ORIG");
/*  370:     */   }
/*  371:     */   
/*  372:     */   public String getASFOUNDTOL2UP_ORIG()
/*  373:     */   {
/*  374: 382 */     return getString("ASFOUNDTOL2UP_ORIG");
/*  375:     */   }
/*  376:     */   
/*  377:     */   public String getASFOUNDTOL2UPPER()
/*  378:     */   {
/*  379: 386 */     return getString("ASFOUNDTOL2UPPER");
/*  380:     */   }
/*  381:     */   
/*  382:     */   public String getASFOUNDTOL2UPPER_NP()
/*  383:     */   {
/*  384: 390 */     return getString("ASFOUNDTOL2UPPER_NP");
/*  385:     */   }
/*  386:     */   
/*  387:     */   public String getASFOUNDTOL3LOWER()
/*  388:     */   {
/*  389: 394 */     return getString("ASFOUNDTOL3LOWER");
/*  390:     */   }
/*  391:     */   
/*  392:     */   public String getASFOUNDTOL3LOWER_NP()
/*  393:     */   {
/*  394: 398 */     return getString("ASFOUNDTOL3LOWER_NP");
/*  395:     */   }
/*  396:     */   
/*  397:     */   public String getASFOUNDTOL3LW_ORIG()
/*  398:     */   {
/*  399: 402 */     return getString("ASFOUNDTOL3LW_ORIG");
/*  400:     */   }
/*  401:     */   
/*  402:     */   public String getASFOUNDTOL3UP_ORIG()
/*  403:     */   {
/*  404: 406 */     return getString("ASFOUNDTOL3UP_ORIG");
/*  405:     */   }
/*  406:     */   
/*  407:     */   public String getASFOUNDTOL3UPPER()
/*  408:     */   {
/*  409: 410 */     return getString("ASFOUNDTOL3UPPER");
/*  410:     */   }
/*  411:     */   
/*  412:     */   public String getASFOUNDTOL3UPPER_NP()
/*  413:     */   {
/*  414: 414 */     return getString("ASFOUNDTOL3UPPER_NP");
/*  415:     */   }
/*  416:     */   
/*  417:     */   public String getASFOUNDTOL4LOWER()
/*  418:     */   {
/*  419: 418 */     return getString("ASFOUNDTOL4LOWER");
/*  420:     */   }
/*  421:     */   
/*  422:     */   public String getASFOUNDTOL4LOWER_NP()
/*  423:     */   {
/*  424: 422 */     return getString("ASFOUNDTOL4LOWER_NP");
/*  425:     */   }
/*  426:     */   
/*  427:     */   public String getASFOUNDTOL4LW_ORIG()
/*  428:     */   {
/*  429: 426 */     return getString("ASFOUNDTOL4LW_ORIG");
/*  430:     */   }
/*  431:     */   
/*  432:     */   public String getASFOUNDTOL4UP_ORIG()
/*  433:     */   {
/*  434: 430 */     return getString("ASFOUNDTOL4UP_ORIG");
/*  435:     */   }
/*  436:     */   
/*  437:     */   public String getASFOUNDTOL4UPPER()
/*  438:     */   {
/*  439: 434 */     return getString("ASFOUNDTOL4UPPER");
/*  440:     */   }
/*  441:     */   
/*  442:     */   public String getASFOUNDTOL4UPPER_NP()
/*  443:     */   {
/*  444: 438 */     return getString("ASFOUNDTOL4UPPER_NP");
/*  445:     */   }
/*  446:     */   
/*  447:     */   public String getASLEFTERROR1()
/*  448:     */   {
/*  449: 442 */     return getString("ASLEFTERROR1");
/*  450:     */   }
/*  451:     */   
/*  452:     */   public String getASLEFTERROR2()
/*  453:     */   {
/*  454: 446 */     return getString("ASLEFTERROR2");
/*  455:     */   }
/*  456:     */   
/*  457:     */   public String getASLEFTERROR3()
/*  458:     */   {
/*  459: 450 */     return getString("ASLEFTERROR3");
/*  460:     */   }
/*  461:     */   
/*  462:     */   public String getASLEFTERROR4()
/*  463:     */   {
/*  464: 454 */     return getString("ASLEFTERROR4");
/*  465:     */   }
/*  466:     */   
/*  467:     */   public String getASLEFTIN()
/*  468:     */   {
/*  469: 458 */     return getString("ASLEFTIN");
/*  470:     */   }
/*  471:     */   
/*  472:     */   public String getASLEFTINPUT()
/*  473:     */   {
/*  474: 462 */     return getString("ASLEFTINPUT");
/*  475:     */   }
/*  476:     */   
/*  477:     */   public String getASLEFTINPUT_NP()
/*  478:     */   {
/*  479: 466 */     return getString("ASLEFTINPUT_NP");
/*  480:     */   }
/*  481:     */   
/*  482:     */   public String getASLEFTOUT()
/*  483:     */   {
/*  484: 470 */     return getString("ASLEFTOUT");
/*  485:     */   }
/*  486:     */   
/*  487:     */   public String getASLEFTOUTERROR()
/*  488:     */   {
/*  489: 474 */     return getString("ASLEFTOUTERROR");
/*  490:     */   }
/*  491:     */   
/*  492:     */   public String getASLEFTOUTPUT()
/*  493:     */   {
/*  494: 478 */     return getString("ASLEFTOUTPUT");
/*  495:     */   }
/*  496:     */   
/*  497:     */   public String getASLEFTOUTPUT_NP()
/*  498:     */   {
/*  499: 482 */     return getString("ASLEFTOUTPUT_NP");
/*  500:     */   }
/*  501:     */   
/*  502:     */   public String getASLEFTPROERROR()
/*  503:     */   {
/*  504: 486 */     return getString("ASLEFTPROERROR");
/*  505:     */   }
/*  506:     */   
/*  507:     */   public Boolean getASLEFTPTERROR()
/*  508:     */   {
/*  509: 490 */     return getBoolean("ASLEFTPTERROR");
/*  510:     */   }
/*  511:     */   
/*  512:     */   public String getASLEFTRESPONSE()
/*  513:     */   {
/*  514: 494 */     return getString("ASLEFTRESPONSE");
/*  515:     */   }
/*  516:     */   
/*  517:     */   public String getASLEFTRESPONSEEU()
/*  518:     */   {
/*  519: 498 */     return getString("ASLEFTRESPONSEEU");
/*  520:     */   }
/*  521:     */   
/*  522:     */   public String getASLEFTSETPOINT()
/*  523:     */   {
/*  524: 502 */     return getString("ASLEFTSETPOINT");
/*  525:     */   }
/*  526:     */   
/*  527:     */   public String getASLEFTSETPOINT_NP()
/*  528:     */   {
/*  529: 506 */     return getString("ASLEFTSETPOINT_NP");
/*  530:     */   }
/*  531:     */   
/*  532:     */   public String getASLEFTTOL1LOWER()
/*  533:     */   {
/*  534: 510 */     return getString("ASLEFTTOL1LOWER");
/*  535:     */   }
/*  536:     */   
/*  537:     */   public String getASLEFTTOL1LOWER_NP()
/*  538:     */   {
/*  539: 514 */     return getString("ASLEFTTOL1LOWER_NP");
/*  540:     */   }
/*  541:     */   
/*  542:     */   public String getASLEFTTOL1LW_ORIG()
/*  543:     */   {
/*  544: 518 */     return getString("ASLEFTTOL1LW_ORIG");
/*  545:     */   }
/*  546:     */   
/*  547:     */   public String getASLEFTTOL1UP_ORIG()
/*  548:     */   {
/*  549: 522 */     return getString("ASLEFTTOL1UP_ORIG");
/*  550:     */   }
/*  551:     */   
/*  552:     */   public String getASLEFTTOL1UPPER()
/*  553:     */   {
/*  554: 526 */     return getString("ASLEFTTOL1UPPER");
/*  555:     */   }
/*  556:     */   
/*  557:     */   public String getASLEFTTOL1UPPER_NP()
/*  558:     */   {
/*  559: 530 */     return getString("ASLEFTTOL1UPPER_NP");
/*  560:     */   }
/*  561:     */   
/*  562:     */   public String getASLEFTTOL2LOWER()
/*  563:     */   {
/*  564: 534 */     return getString("ASLEFTTOL2LOWER");
/*  565:     */   }
/*  566:     */   
/*  567:     */   public String getASLEFTTOL2LOWER_NP()
/*  568:     */   {
/*  569: 538 */     return getString("ASLEFTTOL2LOWER_NP");
/*  570:     */   }
/*  571:     */   
/*  572:     */   public String getASLEFTTOL2LW_ORIG()
/*  573:     */   {
/*  574: 542 */     return getString("ASLEFTTOL2LW_ORIG");
/*  575:     */   }
/*  576:     */   
/*  577:     */   public String getASLEFTTOL2UP_ORIG()
/*  578:     */   {
/*  579: 546 */     return getString("ASLEFTTOL2UP_ORIG");
/*  580:     */   }
/*  581:     */   
/*  582:     */   public String getASLEFTTOL2UPPER()
/*  583:     */   {
/*  584: 550 */     return getString("ASLEFTTOL2UPPER");
/*  585:     */   }
/*  586:     */   
/*  587:     */   public String getASLEFTTOL2UPPER_NP()
/*  588:     */   {
/*  589: 554 */     return getString("ASLEFTTOL2UPPER_NP");
/*  590:     */   }
/*  591:     */   
/*  592:     */   public String getASLEFTTOL3LOWER()
/*  593:     */   {
/*  594: 558 */     return getString("ASLEFTTOL3LOWER");
/*  595:     */   }
/*  596:     */   
/*  597:     */   public String getASLEFTTOL3LOWER_NP()
/*  598:     */   {
/*  599: 562 */     return getString("ASLEFTTOL3LOWER_NP");
/*  600:     */   }
/*  601:     */   
/*  602:     */   public String getASLEFTTOL3LW_ORIG()
/*  603:     */   {
/*  604: 566 */     return getString("ASLEFTTOL3LW_ORIG");
/*  605:     */   }
/*  606:     */   
/*  607:     */   public String getASLEFTTOL3UP_ORIG()
/*  608:     */   {
/*  609: 570 */     return getString("ASLEFTTOL3UP_ORIG");
/*  610:     */   }
/*  611:     */   
/*  612:     */   public String getASLEFTTOL3UPPER()
/*  613:     */   {
/*  614: 574 */     return getString("ASLEFTTOL3UPPER");
/*  615:     */   }
/*  616:     */   
/*  617:     */   public String getASLEFTTOL3UPPER_NP()
/*  618:     */   {
/*  619: 578 */     return getString("ASLEFTTOL3UPPER_NP");
/*  620:     */   }
/*  621:     */   
/*  622:     */   public String getASLEFTTOL4LOWER()
/*  623:     */   {
/*  624: 582 */     return getString("ASLEFTTOL4LOWER");
/*  625:     */   }
/*  626:     */   
/*  627:     */   public String getASLEFTTOL4LOWER_NP()
/*  628:     */   {
/*  629: 586 */     return getString("ASLEFTTOL4LOWER_NP");
/*  630:     */   }
/*  631:     */   
/*  632:     */   public String getASLEFTTOL4LW_ORIG()
/*  633:     */   {
/*  634: 590 */     return getString("ASLEFTTOL4LW_ORIG");
/*  635:     */   }
/*  636:     */   
/*  637:     */   public String getASLEFTTOL4UP_ORIG()
/*  638:     */   {
/*  639: 594 */     return getString("ASLEFTTOL4UP_ORIG");
/*  640:     */   }
/*  641:     */   
/*  642:     */   public String getASLEFTTOL4UPPER()
/*  643:     */   {
/*  644: 598 */     return getString("ASLEFTTOL4UPPER");
/*  645:     */   }
/*  646:     */   
/*  647:     */   public String getASLEFTTOL4UPPER_NP()
/*  648:     */   {
/*  649: 602 */     return getString("ASLEFTTOL4UPPER_NP");
/*  650:     */   }
/*  651:     */   
/*  652:     */   public String getDESIREDOUT()
/*  653:     */   {
/*  654: 606 */     return getString("DESIREDOUT");
/*  655:     */   }
/*  656:     */   
/*  657:     */   public String getDIRECTION()
/*  658:     */   {
/*  659: 610 */     return getString("DIRECTION");
/*  660:     */   }
/*  661:     */   
/*  662:     */   public String getDSPLANNUM()
/*  663:     */   {
/*  664: 614 */     return getString("DSPLANNUM");
/*  665:     */   }
/*  666:     */   
/*  667:     */   public String getINPUTPERCENT()
/*  668:     */   {
/*  669: 618 */     return getString("INPUTPERCENT");
/*  670:     */   }
/*  671:     */   
/*  672:     */   public String getINPUTVALUE()
/*  673:     */   {
/*  674: 622 */     return getString("INPUTVALUE");
/*  675:     */   }
/*  676:     */   
/*  677:     */   public String getINPUTVALUE_NP()
/*  678:     */   {
/*  679: 626 */     return getString("INPUTVALUE_NP");
/*  680:     */   }
/*  681:     */   
/*  682:     */   public String getINSTRASSETEU()
/*  683:     */   {
/*  684: 630 */     return getString("INSTRASSETEU");
/*  685:     */   }
/*  686:     */   
/*  687:     */   public String getINSTRCALRANGEEUA()
/*  688:     */   {
/*  689: 634 */     return getString("INSTRCALRANGEEUA");
/*  690:     */   }
/*  691:     */   
/*  692:     */   public String getINSTRCALRANGEEUD()
/*  693:     */   {
/*  694: 638 */     return getString("INSTRCALRANGEEUD");
/*  695:     */   }
/*  696:     */   
/*  697:     */   public String getINSTROUTRANGEEU()
/*  698:     */   {
/*  699: 642 */     return getString("INSTROUTRANGEEU");
/*  700:     */   }
/*  701:     */   
/*  702:     */   public Integer getINSTRSEQ()
/*  703:     */   {
/*  704: 646 */     return getInt("INSTRSEQ");
/*  705:     */   }
/*  706:     */   
/*  707:     */   public String getINSTRUMENTDESC()
/*  708:     */   {
/*  709: 650 */     return getString("INSTRUMENTDESC");
/*  710:     */   }
/*  711:     */   
/*  712:     */   public Integer getINSTRUMENTFUNCTION()
/*  713:     */   {
/*  714: 654 */     return getInt("INSTRUMENTFUNCTION");
/*  715:     */   }
/*  716:     */   
/*  717:     */   public Boolean getISADDED()
/*  718:     */   {
/*  719: 658 */     return getBoolean("ISADDED");
/*  720:     */   }
/*  721:     */   
/*  722:     */   public Integer getLDKEY()
/*  723:     */   {
/*  724: 662 */     return getInt("LDKEY");
/*  725:     */   }
/*  726:     */   
/*  727:     */   public String getNOMINALIN()
/*  728:     */   {
/*  729: 666 */     return getString("NOMINALIN");
/*  730:     */   }
/*  731:     */   
/*  732:     */   public String getORGID()
/*  733:     */   {
/*  734: 670 */     return getString("ORGID");
/*  735:     */   }
/*  736:     */   
/*  737:     */   public String getOUTPUTVALUE()
/*  738:     */   {
/*  739: 674 */     return getString("OUTPUTVALUE");
/*  740:     */   }
/*  741:     */   
/*  742:     */   public String getOUTPUTVALUE_NP()
/*  743:     */   {
/*  744: 678 */     return getString("OUTPUTVALUE_NP");
/*  745:     */   }
/*  746:     */   
/*  747:     */   public String getPLANTYPE()
/*  748:     */   {
/*  749: 682 */     return getString("PLANTYPE");
/*  750:     */   }
/*  751:     */   
/*  752:     */   public Integer getPLUSCWODSPOINTID()
/*  753:     */   {
/*  754: 686 */     return getInt("PLUSCWODSPOINTID");
/*  755:     */   }
/*  756:     */   
/*  757:     */   public Integer getPOINT()
/*  758:     */   {
/*  759: 690 */     return getInt("POINT");
/*  760:     */   }
/*  761:     */   
/*  762:     */   public String getPOINTDESCRIPTION()
/*  763:     */   {
/*  764: 694 */     return getString("POINTDESCRIPTION");
/*  765:     */   }
/*  766:     */   
/*  767:     */   public String getPROCESSEU()
/*  768:     */   {
/*  769: 698 */     return getString("PROCESSEU");
/*  770:     */   }
/*  771:     */   
/*  772:     */   public String getPROCESSEUFACTOR()
/*  773:     */   {
/*  774: 702 */     return getString("PROCESSEUFACTOR");
/*  775:     */   }
/*  776:     */   
/*  777:     */   public Integer getREVISIONNUM()
/*  778:     */   {
/*  779: 706 */     return getInt("REVISIONNUM");
/*  780:     */   }
/*  781:     */   
/*  782:     */   public String getRON1LOWER()
/*  783:     */   {
/*  784: 710 */     return getString("RON1LOWER");
/*  785:     */   }
/*  786:     */   
/*  787:     */   public String getRON1LOWER_NP()
/*  788:     */   {
/*  789: 714 */     return getString("RON1LOWER_NP");
/*  790:     */   }
/*  791:     */   
/*  792:     */   public String getRON1TYPE()
/*  793:     */   {
/*  794: 718 */     return getString("RON1TYPE");
/*  795:     */   }
/*  796:     */   
/*  797:     */   public String getRON1UPPER()
/*  798:     */   {
/*  799: 722 */     return getString("RON1UPPER");
/*  800:     */   }
/*  801:     */   
/*  802:     */   public String getRON1UPPER_NP()
/*  803:     */   {
/*  804: 726 */     return getString("RON1UPPER_NP");
/*  805:     */   }
/*  806:     */   
/*  807:     */   public String getSETPOINTACTION()
/*  808:     */   {
/*  809: 730 */     return getString("SETPOINTACTION");
/*  810:     */   }
/*  811:     */   
/*  812:     */   public String getSETPOINTVALUE()
/*  813:     */   {
/*  814: 734 */     return getString("SETPOINTVALUE");
/*  815:     */   }
/*  816:     */   
/*  817:     */   public String getSETPOINTVALUE_NP()
/*  818:     */   {
/*  819: 738 */     return getString("SETPOINTVALUE_NP");
/*  820:     */   }
/*  821:     */   
/*  822:     */   public String getSITEID()
/*  823:     */   {
/*  824: 742 */     return getString("SITEID");
/*  825:     */   }
/*  826:     */   
/*  827:     */   public String getTOLERANCEEU()
/*  828:     */   {
/*  829: 746 */     return getString("TOLERANCEEU");
/*  830:     */   }
/*  831:     */   
/*  832:     */   public String getWONUM()
/*  833:     */   {
/*  834: 750 */     return getString("WONUM");
/*  835:     */   }
/*  836:     */   
/*  837:     */   public String getASFINPUTSTDDEV()
/*  838:     */   {
/*  839: 754 */     return getString("ASFINPUTSTDDEV");
/*  840:     */   }
/*  841:     */   
/*  842:     */   public Boolean getASFOUNDERROR()
/*  843:     */   {
/*  844: 759 */     return getBoolean("ASFOUNDERROR");
/*  845:     */   }
/*  846:     */   
/*  847:     */   public Boolean getASFOUNDFAIL()
/*  848:     */   {
/*  849: 764 */     return getBoolean("ASFOUNDFAIL");
/*  850:     */   }
/*  851:     */   
/*  852:     */   public Boolean getASFOUNDPASS()
/*  853:     */   {
/*  854: 769 */     return getBoolean("ASFOUNDPASS");
/*  855:     */   }
/*  856:     */   
/*  857:     */   public String getASFOUNDUNIT()
/*  858:     */   {
/*  859: 774 */     return getString("ASFOUNDUNIT");
/*  860:     */   }
/*  861:     */   
/*  862:     */   public String getASFOUTPUTSTDDEV()
/*  863:     */   {
/*  864: 779 */     return getString("ASFOUTPUTSTDDEV");
/*  865:     */   }
/*  866:     */   
/*  867:     */   public String getASFSETPTSTDDEV()
/*  868:     */   {
/*  869: 784 */     return getString("ASFSETPTSTDDEV");
/*  870:     */   }
/*  871:     */   
/*  872:     */   public Boolean getASLEFTERROR()
/*  873:     */   {
/*  874: 789 */     return getBoolean("ASLEFTERROR");
/*  875:     */   }
/*  876:     */   
/*  877:     */   public Boolean getASLEFTFAIL()
/*  878:     */   {
/*  879: 794 */     return getBoolean("ASLEFTFAIL");
/*  880:     */   }
/*  881:     */   
/*  882:     */   public Boolean getASLEFTPASS()
/*  883:     */   {
/*  884: 799 */     return getBoolean("ASLEFTPASS");
/*  885:     */   }
/*  886:     */   
/*  887:     */   public String getASLEFTUNIT()
/*  888:     */   {
/*  889: 804 */     return getString("ASLEFTUNIT");
/*  890:     */   }
/*  891:     */   
/*  892:     */   public String getASLINPUTSTDDEV()
/*  893:     */   {
/*  894: 809 */     return getString("ASLINPUTSTDDEV");
/*  895:     */   }
/*  896:     */   
/*  897:     */   public String getASLOUTPUTSTDDEV()
/*  898:     */   {
/*  899: 814 */     return getString("ASLOUTPUTSTDDEV");
/*  900:     */   }
/*  901:     */   
/*  902:     */   public String getASLSETPTSTDDEV()
/*  903:     */   {
/*  904: 819 */     return getString("ASLSETPTSTDDEV");
/*  905:     */   }
/*  906:     */   
/*  907:     */   public String getCOMMENTS()
/*  908:     */   {
/*  909: 824 */     return getString("COMMENTS");
/*  910:     */   }
/*  911:     */   
/*  912:     */   public String getPVASLTINPUT()
/*  913:     */   {
/*  914: 829 */     return getString("PVASLTINPUT");
/*  915:     */   }
/*  916:     */   
/*  917:     */   public String getPVASLTOUTPUT()
/*  918:     */   {
/*  919: 834 */     return getString("PVASLTOUTPUT");
/*  920:     */   }
/*  921:     */   
/*  922:     */   public String getPVASLTSETPNT()
/*  923:     */   {
/*  924: 839 */     return getString("PVASLTSETPNT");
/*  925:     */   }
/*  926:     */   
/*  927:     */   public Boolean getSETPOINTADJ()
/*  928:     */   {
/*  929: 844 */     return getBoolean("SETPOINTADJ");
/*  930:     */   }
/*  931:     */   
/*  932:     */   public void setASFOUNDERROR1(String asfounderror1)
/*  933:     */   {
/*  934: 849 */     setValue("ASFOUNDERROR1", asfounderror1, false);
/*  935:     */   }
/*  936:     */   
/*  937:     */   public void setASFOUNDERROR2(String asfounderror2)
/*  938:     */   {
/*  939: 853 */     setValue("ASFOUNDERROR2", asfounderror2, false);
/*  940:     */   }
/*  941:     */   
/*  942:     */   public void setASFOUNDERROR3(String asfounderror3)
/*  943:     */   {
/*  944: 857 */     setValue("ASFOUNDERROR3", asfounderror3, false);
/*  945:     */   }
/*  946:     */   
/*  947:     */   public void setASFOUNDERROR4(String asfounderror4)
/*  948:     */   {
/*  949: 861 */     setValue("ASFOUNDERROR4", asfounderror4, false);
/*  950:     */   }
/*  951:     */   
/*  952:     */   public void setASFOUNDIN(String asfoundin)
/*  953:     */   {
/*  954: 865 */     setValue("ASFOUNDIN", asfoundin, false);
/*  955:     */   }
/*  956:     */   
/*  957:     */   public void setASFOUNDINPUT(String asfoundinput)
/*  958:     */   {
/*  959: 869 */     setValue("ASFOUNDINPUT", asfoundinput, false);
/*  960:     */   }
/*  961:     */   
/*  962:     */   public void setASFOUNDINPUT_NP(String asfoundinput_np)
/*  963:     */   {
/*  964: 873 */     setValue("ASFOUNDINPUT_NP", asfoundinput_np, false);
/*  965:     */   }
/*  966:     */   
/*  967:     */   public void setASFOUNDOUT(String asfoundout)
/*  968:     */   {
/*  969: 877 */     setValue("ASFOUNDOUT", asfoundout, false);
/*  970:     */   }
/*  971:     */   
/*  972:     */   public void setASFOUNDOUTERROR(String asfoundouterror)
/*  973:     */   {
/*  974: 881 */     setValue("ASFOUNDOUTERROR", asfoundouterror, false);
/*  975:     */   }
/*  976:     */   
/*  977:     */   public void setASFOUNDOUTPUT(String asfoundoutput)
/*  978:     */   {
/*  979: 885 */     setValue("ASFOUNDOUTPUT", asfoundoutput, false);
/*  980:     */   }
/*  981:     */   
/*  982:     */   public void setASFOUNDOUTPUT_NP(String asfoundoutput_np)
/*  983:     */   {
/*  984: 889 */     setValue("ASFOUNDOUTPUT_NP", asfoundoutput_np, false);
/*  985:     */   }
/*  986:     */   
/*  987:     */   public void setASFOUNDPROERROR(String asfoundproerror)
/*  988:     */   {
/*  989: 893 */     setValue("ASFOUNDPROERROR", asfoundproerror, false);
/*  990:     */   }
/*  991:     */   
/*  992:     */   public void setASFOUNDPTERROR(Boolean asfoundpterror)
/*  993:     */   {
/*  994: 897 */     setValue("ASFOUNDPTERROR", asfoundpterror, false);
/*  995:     */   }
/*  996:     */   
/*  997:     */   public void setASFOUNDRESPONSE(String asfoundresponse)
/*  998:     */   {
/*  999: 901 */     setValue("ASFOUNDRESPONSE", asfoundresponse, false);
/* 1000:     */   }
/* 1001:     */   
/* 1002:     */   public void setASFOUNDRESPONSEEU(String asfoundresponseeu)
/* 1003:     */   {
/* 1004: 905 */     setValue("ASFOUNDRESPONSEEU", asfoundresponseeu, false);
/* 1005:     */   }
/* 1006:     */   
/* 1007:     */   public void setASFOUNDSETPOINT(String asfoundsetpoint)
/* 1008:     */   {
/* 1009: 909 */     setValue("ASFOUNDSETPOINT", asfoundsetpoint, false);
/* 1010:     */   }
/* 1011:     */   
/* 1012:     */   public void setASFOUNDSETPOINT_NP(String asfoundsetpoint_np)
/* 1013:     */   {
/* 1014: 913 */     setValue("ASFOUNDSETPOINT_NP", asfoundsetpoint_np, false);
/* 1015:     */   }
/* 1016:     */   
/* 1017:     */   public void setASFOUNDTOL1LOWER(String asfoundtol1lower)
/* 1018:     */   {
/* 1019: 917 */     setValue("ASFOUNDTOL1LOWER", asfoundtol1lower, false);
/* 1020:     */   }
/* 1021:     */   
/* 1022:     */   public void setASFOUNDTOL1LOWER_NP(String asfoundtol1lower_np)
/* 1023:     */   {
/* 1024: 921 */     setValue("ASFOUNDTOL1LOWER_NP", asfoundtol1lower_np, false);
/* 1025:     */   }
/* 1026:     */   
/* 1027:     */   public void setASFOUNDTOL1LW_ORIG(String asfoundtol1lw_orig)
/* 1028:     */   {
/* 1029: 925 */     setValue("ASFOUNDTOL1LW_ORIG", asfoundtol1lw_orig, false);
/* 1030:     */   }
/* 1031:     */   
/* 1032:     */   public void setASFOUNDTOL1UP_ORIG(String asfoundtol1up_orig)
/* 1033:     */   {
/* 1034: 929 */     setValue("ASFOUNDTOL1UP_ORIG", asfoundtol1up_orig, false);
/* 1035:     */   }
/* 1036:     */   
/* 1037:     */   public void setASFOUNDTOL1UPPER(String asfoundtol1upper)
/* 1038:     */   {
/* 1039: 933 */     setValue("ASFOUNDTOL1UPPER", asfoundtol1upper, false);
/* 1040:     */   }
/* 1041:     */   
/* 1042:     */   public void setASFOUNDTOL1UPPER_NP(String asfoundtol1upper_np)
/* 1043:     */   {
/* 1044: 937 */     setValue("ASFOUNDTOL1UPPER_NP", asfoundtol1upper_np, false);
/* 1045:     */   }
/* 1046:     */   
/* 1047:     */   public void setASFOUNDTOL2LOWER(String asfoundtol2lower)
/* 1048:     */   {
/* 1049: 941 */     setValue("ASFOUNDTOL2LOWER", asfoundtol2lower, false);
/* 1050:     */   }
/* 1051:     */   
/* 1052:     */   public void setASFOUNDTOL2LOWER_NP(String asfoundtol2lower_np)
/* 1053:     */   {
/* 1054: 945 */     setValue("ASFOUNDTOL2LOWER_NP", asfoundtol2lower_np, false);
/* 1055:     */   }
/* 1056:     */   
/* 1057:     */   public void setASFOUNDTOL2LW_ORIG(String asfoundtol2lw_orig)
/* 1058:     */   {
/* 1059: 949 */     setValue("ASFOUNDTOL2LW_ORIG", asfoundtol2lw_orig, false);
/* 1060:     */   }
/* 1061:     */   
/* 1062:     */   public void setASFOUNDTOL2UP_ORIG(String asfoundtol2up_orig)
/* 1063:     */   {
/* 1064: 953 */     setValue("ASFOUNDTOL2UP_ORIG", asfoundtol2up_orig, false);
/* 1065:     */   }
/* 1066:     */   
/* 1067:     */   public void setASFOUNDTOL2UPPER(String asfoundtol2upper)
/* 1068:     */   {
/* 1069: 957 */     setValue("ASFOUNDTOL2UPPER", asfoundtol2upper, false);
/* 1070:     */   }
/* 1071:     */   
/* 1072:     */   public void setASFOUNDTOL2UPPER_NP(String asfoundtol2upper_np)
/* 1073:     */   {
/* 1074: 961 */     setValue("ASFOUNDTOL2UPPER_NP", asfoundtol2upper_np, false);
/* 1075:     */   }
/* 1076:     */   
/* 1077:     */   public void setASFOUNDTOL3LOWER(String asfoundtol3lower)
/* 1078:     */   {
/* 1079: 965 */     setValue("ASFOUNDTOL3LOWER", asfoundtol3lower, false);
/* 1080:     */   }
/* 1081:     */   
/* 1082:     */   public void setASFOUNDTOL3LOWER_NP(String asfoundtol3lower_np)
/* 1083:     */   {
/* 1084: 969 */     setValue("ASFOUNDTOL3LOWER_NP", asfoundtol3lower_np, false);
/* 1085:     */   }
/* 1086:     */   
/* 1087:     */   public void setASFOUNDTOL3LW_ORIG(String asfoundtol3lw_orig)
/* 1088:     */   {
/* 1089: 973 */     setValue("ASFOUNDTOL3LW_ORIG", asfoundtol3lw_orig, false);
/* 1090:     */   }
/* 1091:     */   
/* 1092:     */   public void setASFOUNDTOL3UP_ORIG(String asfoundtol3up_orig)
/* 1093:     */   {
/* 1094: 977 */     setValue("ASFOUNDTOL3UP_ORIG", asfoundtol3up_orig, false);
/* 1095:     */   }
/* 1096:     */   
/* 1097:     */   public void setASFOUNDTOL3UPPER(String asfoundtol3upper)
/* 1098:     */   {
/* 1099: 981 */     setValue("ASFOUNDTOL3UPPER", asfoundtol3upper, false);
/* 1100:     */   }
/* 1101:     */   
/* 1102:     */   public void setASFOUNDTOL3UPPER_NP(String asfoundtol3upper_np)
/* 1103:     */   {
/* 1104: 985 */     setValue("ASFOUNDTOL3UPPER_NP", asfoundtol3upper_np, false);
/* 1105:     */   }
/* 1106:     */   
/* 1107:     */   public void setASFOUNDTOL4LOWER(String asfoundtol4lower)
/* 1108:     */   {
/* 1109: 989 */     setValue("ASFOUNDTOL4LOWER", asfoundtol4lower, false);
/* 1110:     */   }
/* 1111:     */   
/* 1112:     */   public void setASFOUNDTOL4LOWER_NP(String asfoundtol4lower_np)
/* 1113:     */   {
/* 1114: 993 */     setValue("ASFOUNDTOL4LOWER_NP", asfoundtol4lower_np, false);
/* 1115:     */   }
/* 1116:     */   
/* 1117:     */   public void setASFOUNDTOL4LW_ORIG(String asfoundtol4lw_orig)
/* 1118:     */   {
/* 1119: 997 */     setValue("ASFOUNDTOL4LW_ORIG", asfoundtol4lw_orig, false);
/* 1120:     */   }
/* 1121:     */   
/* 1122:     */   public void setASFOUNDTOL4UP_ORIG(String asfoundtol4up_orig)
/* 1123:     */   {
/* 1124:1001 */     setValue("ASFOUNDTOL4UP_ORIG", asfoundtol4up_orig, false);
/* 1125:     */   }
/* 1126:     */   
/* 1127:     */   public void setASFOUNDTOL4UPPER(String asfoundtol4upper)
/* 1128:     */   {
/* 1129:1005 */     setValue("ASFOUNDTOL4UPPER", asfoundtol4upper, false);
/* 1130:     */   }
/* 1131:     */   
/* 1132:     */   public void setASFOUNDTOL4UPPER_NP(String asfoundtol4upper_np)
/* 1133:     */   {
/* 1134:1009 */     setValue("ASFOUNDTOL4UPPER_NP", asfoundtol4upper_np, false);
/* 1135:     */   }
/* 1136:     */   
/* 1137:     */   public void setASLEFTERROR1(String aslefterror1)
/* 1138:     */   {
/* 1139:1013 */     setValue("ASLEFTERROR1", aslefterror1, false);
/* 1140:     */   }
/* 1141:     */   
/* 1142:     */   public void setASLEFTERROR2(String aslefterror2)
/* 1143:     */   {
/* 1144:1017 */     setValue("ASLEFTERROR2", aslefterror2, false);
/* 1145:     */   }
/* 1146:     */   
/* 1147:     */   public void setASLEFTERROR3(String aslefterror3)
/* 1148:     */   {
/* 1149:1021 */     setValue("ASLEFTERROR3", aslefterror3, false);
/* 1150:     */   }
/* 1151:     */   
/* 1152:     */   public void setASLEFTERROR4(String aslefterror4)
/* 1153:     */   {
/* 1154:1025 */     setValue("ASLEFTERROR4", aslefterror4, false);
/* 1155:     */   }
/* 1156:     */   
/* 1157:     */   public void setASLEFTIN(String asleftin)
/* 1158:     */   {
/* 1159:1029 */     setValue("ASLEFTIN", asleftin, false);
/* 1160:     */   }
/* 1161:     */   
/* 1162:     */   public void setASLEFTINPUT(String asleftinput)
/* 1163:     */   {
/* 1164:1033 */     setValue("ASLEFTINPUT", asleftinput, false);
/* 1165:     */   }
/* 1166:     */   
/* 1167:     */   public void setASLEFTINPUT_NP(String asleftinput_np)
/* 1168:     */   {
/* 1169:1037 */     setValue("ASLEFTINPUT_NP", asleftinput_np, false);
/* 1170:     */   }
/* 1171:     */   
/* 1172:     */   public void setASLEFTOUT(String asleftout)
/* 1173:     */   {
/* 1174:1041 */     setValue("ASLEFTOUT", asleftout, false);
/* 1175:     */   }
/* 1176:     */   
/* 1177:     */   public void setASLEFTOUTERROR(String asleftouterror)
/* 1178:     */   {
/* 1179:1045 */     setValue("ASLEFTOUTERROR", asleftouterror, false);
/* 1180:     */   }
/* 1181:     */   
/* 1182:     */   public void setASLEFTOUTPUT(String asleftoutput)
/* 1183:     */   {
/* 1184:1049 */     setValue("ASLEFTOUTPUT", asleftoutput, false);
/* 1185:     */   }
/* 1186:     */   
/* 1187:     */   public void setASLEFTOUTPUT_NP(String asleftoutput_np)
/* 1188:     */   {
/* 1189:1053 */     setValue("ASLEFTOUTPUT_NP", asleftoutput_np, false);
/* 1190:     */   }
/* 1191:     */   
/* 1192:     */   public void setASLEFTPROERROR(String asleftproerror)
/* 1193:     */   {
/* 1194:1057 */     setValue("ASLEFTPROERROR", asleftproerror, false);
/* 1195:     */   }
/* 1196:     */   
/* 1197:     */   public void setASLEFTPTERROR(Boolean asleftpterror)
/* 1198:     */   {
/* 1199:1061 */     setValue("ASLEFTPTERROR", asleftpterror, false);
/* 1200:     */   }
/* 1201:     */   
/* 1202:     */   public void setASLEFTRESPONSE(String asleftresponse)
/* 1203:     */   {
/* 1204:1065 */     setValue("ASLEFTRESPONSE", asleftresponse, false);
/* 1205:     */   }
/* 1206:     */   
/* 1207:     */   public void setASLEFTRESPONSEEU(String asleftresponseeu)
/* 1208:     */   {
/* 1209:1069 */     setValue("ASLEFTRESPONSEEU", asleftresponseeu, false);
/* 1210:     */   }
/* 1211:     */   
/* 1212:     */   public void setASLEFTSETPOINT(String asleftsetpoint)
/* 1213:     */   {
/* 1214:1073 */     setValue("ASLEFTSETPOINT", asleftsetpoint, false);
/* 1215:     */   }
/* 1216:     */   
/* 1217:     */   public void setASLEFTSETPOINT_NP(String asleftsetpoint_np)
/* 1218:     */   {
/* 1219:1077 */     setValue("ASLEFTSETPOINT_NP", asleftsetpoint_np, false);
/* 1220:     */   }
/* 1221:     */   
/* 1222:     */   public void setASLEFTTOL1LOWER(String aslefttol1lower)
/* 1223:     */   {
/* 1224:1081 */     setValue("ASLEFTTOL1LOWER", aslefttol1lower, false);
/* 1225:     */   }
/* 1226:     */   
/* 1227:     */   public void setASLEFTTOL1LOWER_NP(String aslefttol1lower_np)
/* 1228:     */   {
/* 1229:1085 */     setValue("ASLEFTTOL1LOWER_NP", aslefttol1lower_np, false);
/* 1230:     */   }
/* 1231:     */   
/* 1232:     */   public void setASLEFTTOL1LW_ORIG(String aslefttol1lw_orig)
/* 1233:     */   {
/* 1234:1089 */     setValue("ASLEFTTOL1LW_ORIG", aslefttol1lw_orig, false);
/* 1235:     */   }
/* 1236:     */   
/* 1237:     */   public void setASLEFTTOL1UP_ORIG(String aslefttol1up_orig)
/* 1238:     */   {
/* 1239:1093 */     setValue("ASLEFTTOL1UP_ORIG", aslefttol1up_orig, false);
/* 1240:     */   }
/* 1241:     */   
/* 1242:     */   public void setASLEFTTOL1UPPER(String aslefttol1upper)
/* 1243:     */   {
/* 1244:1097 */     setValue("ASLEFTTOL1UPPER", aslefttol1upper, false);
/* 1245:     */   }
/* 1246:     */   
/* 1247:     */   public void setASLEFTTOL1UPPER_NP(String aslefttol1upper_np)
/* 1248:     */   {
/* 1249:1101 */     setValue("ASLEFTTOL1UPPER_NP", aslefttol1upper_np, false);
/* 1250:     */   }
/* 1251:     */   
/* 1252:     */   public void setASLEFTTOL2LOWER(String aslefttol2lower)
/* 1253:     */   {
/* 1254:1105 */     setValue("ASLEFTTOL2LOWER", aslefttol2lower, false);
/* 1255:     */   }
/* 1256:     */   
/* 1257:     */   public void setASLEFTTOL2LOWER_NP(String aslefttol2lower_np)
/* 1258:     */   {
/* 1259:1109 */     setValue("ASLEFTTOL2LOWER_NP", aslefttol2lower_np, false);
/* 1260:     */   }
/* 1261:     */   
/* 1262:     */   public void setASLEFTTOL2LW_ORIG(String aslefttol2lw_orig)
/* 1263:     */   {
/* 1264:1113 */     setValue("ASLEFTTOL2LW_ORIG", aslefttol2lw_orig, false);
/* 1265:     */   }
/* 1266:     */   
/* 1267:     */   public void setASLEFTTOL2UP_ORIG(String aslefttol2up_orig)
/* 1268:     */   {
/* 1269:1117 */     setValue("ASLEFTTOL2UP_ORIG", aslefttol2up_orig, false);
/* 1270:     */   }
/* 1271:     */   
/* 1272:     */   public void setASLEFTTOL2UPPER(String aslefttol2upper)
/* 1273:     */   {
/* 1274:1121 */     setValue("ASLEFTTOL2UPPER", aslefttol2upper, false);
/* 1275:     */   }
/* 1276:     */   
/* 1277:     */   public void setASLEFTTOL2UPPER_NP(String aslefttol2upper_np)
/* 1278:     */   {
/* 1279:1125 */     setValue("ASLEFTTOL2UPPER_NP", aslefttol2upper_np, false);
/* 1280:     */   }
/* 1281:     */   
/* 1282:     */   public void setASLEFTTOL3LOWER(String aslefttol3lower)
/* 1283:     */   {
/* 1284:1129 */     setValue("ASLEFTTOL3LOWER", aslefttol3lower, false);
/* 1285:     */   }
/* 1286:     */   
/* 1287:     */   public void setASLEFTTOL3LOWER_NP(String aslefttol3lower_np)
/* 1288:     */   {
/* 1289:1133 */     setValue("ASLEFTTOL3LOWER_NP", aslefttol3lower_np, false);
/* 1290:     */   }
/* 1291:     */   
/* 1292:     */   public void setASLEFTTOL3LW_ORIG(String aslefttol3lw_orig)
/* 1293:     */   {
/* 1294:1137 */     setValue("ASLEFTTOL3LW_ORIG", aslefttol3lw_orig, false);
/* 1295:     */   }
/* 1296:     */   
/* 1297:     */   public void setASLEFTTOL3UP_ORIG(String aslefttol3up_orig)
/* 1298:     */   {
/* 1299:1141 */     setValue("ASLEFTTOL3UP_ORIG", aslefttol3up_orig, false);
/* 1300:     */   }
/* 1301:     */   
/* 1302:     */   public void setASLEFTTOL3UPPER(String aslefttol3upper)
/* 1303:     */   {
/* 1304:1145 */     setValue("ASLEFTTOL3UPPER", aslefttol3upper, false);
/* 1305:     */   }
/* 1306:     */   
/* 1307:     */   public void setASLEFTTOL3UPPER_NP(String aslefttol3upper_np)
/* 1308:     */   {
/* 1309:1149 */     setValue("ASLEFTTOL3UPPER_NP", aslefttol3upper_np, false);
/* 1310:     */   }
/* 1311:     */   
/* 1312:     */   public void setASLEFTTOL4LOWER(String aslefttol4lower)
/* 1313:     */   {
/* 1314:1153 */     setValue("ASLEFTTOL4LOWER", aslefttol4lower, false);
/* 1315:     */   }
/* 1316:     */   
/* 1317:     */   public void setASLEFTTOL4LOWER_NP(String aslefttol4lower_np)
/* 1318:     */   {
/* 1319:1157 */     setValue("ASLEFTTOL4LOWER_NP", aslefttol4lower_np, false);
/* 1320:     */   }
/* 1321:     */   
/* 1322:     */   public void setASLEFTTOL4LW_ORIG(String aslefttol4lw_orig)
/* 1323:     */   {
/* 1324:1161 */     setValue("ASLEFTTOL4LW_ORIG", aslefttol4lw_orig, false);
/* 1325:     */   }
/* 1326:     */   
/* 1327:     */   public void setASLEFTTOL4UP_ORIG(String aslefttol4up_orig)
/* 1328:     */   {
/* 1329:1165 */     setValue("ASLEFTTOL4UP_ORIG", aslefttol4up_orig, false);
/* 1330:     */   }
/* 1331:     */   
/* 1332:     */   public void setASLEFTTOL4UPPER(String aslefttol4upper)
/* 1333:     */   {
/* 1334:1169 */     setValue("ASLEFTTOL4UPPER", aslefttol4upper, false);
/* 1335:     */   }
/* 1336:     */   
/* 1337:     */   public void setASLEFTTOL4UPPER_NP(String aslefttol4upper_np)
/* 1338:     */   {
/* 1339:1173 */     setValue("ASLEFTTOL4UPPER_NP", aslefttol4upper_np, false);
/* 1340:     */   }
/* 1341:     */   
/* 1342:     */   public void setDESIREDOUT(String desiredout)
/* 1343:     */   {
/* 1344:1177 */     setValue("DESIREDOUT", desiredout, false);
/* 1345:     */   }
/* 1346:     */   
/* 1347:     */   public void setDIRECTION(String direction)
/* 1348:     */   {
/* 1349:1181 */     setValue("DIRECTION", direction, false);
/* 1350:     */   }
/* 1351:     */   
/* 1352:     */   public void setDSPLANNUM(String dsplannum)
/* 1353:     */   {
/* 1354:1185 */     setValue("DSPLANNUM", dsplannum, false);
/* 1355:     */   }
/* 1356:     */   
/* 1357:     */   public void setINPUTPERCENT(String inputpercent)
/* 1358:     */   {
/* 1359:1189 */     setValue("INPUTPERCENT", inputpercent, false);
/* 1360:     */   }
/* 1361:     */   
/* 1362:     */   public void setINPUTVALUE(String inputvalue)
/* 1363:     */   {
/* 1364:1193 */     setValue("INPUTVALUE", inputvalue, false);
/* 1365:     */   }
/* 1366:     */   
/* 1367:     */   public void setINPUTVALUE_NP(String inputvalue_np)
/* 1368:     */   {
/* 1369:1197 */     setValue("INPUTVALUE_NP", inputvalue_np, false);
/* 1370:     */   }
/* 1371:     */   
/* 1372:     */   public void setINSTRASSETEU(String instrasseteu)
/* 1373:     */   {
/* 1374:1201 */     setValue("INSTRASSETEU", instrasseteu, false);
/* 1375:     */   }
/* 1376:     */   
/* 1377:     */   public void setINSTRCALRANGEEUA(String instrcalrangeeua)
/* 1378:     */   {
/* 1379:1205 */     setValue("INSTRCALRANGEEUA", instrcalrangeeua, false);
/* 1380:     */   }
/* 1381:     */   
/* 1382:     */   public void setINSTRCALRANGEEUD(String instrcalrangeeud)
/* 1383:     */   {
/* 1384:1209 */     setValue("INSTRCALRANGEEUD", instrcalrangeeud, false);
/* 1385:     */   }
/* 1386:     */   
/* 1387:     */   public void setINSTROUTRANGEEU(String instroutrangeeu)
/* 1388:     */   {
/* 1389:1213 */     setValue("INSTROUTRANGEEU", instroutrangeeu, false);
/* 1390:     */   }
/* 1391:     */   
/* 1392:     */   public void setINSTRSEQ(Integer instrseq)
/* 1393:     */   {
/* 1394:1217 */     setValue("INSTRSEQ", instrseq, false);
/* 1395:     */   }
/* 1396:     */   
/* 1397:     */   public void setINSTRUMENTDESC(String instrumentdesc)
/* 1398:     */   {
/* 1399:1221 */     setValue("INSTRUMENTDESC", instrumentdesc, false);
/* 1400:     */   }
/* 1401:     */   
/* 1402:     */   public void setINSTRUMENTFUNCTION(Integer instrumentfunction)
/* 1403:     */   {
/* 1404:1225 */     setValue("INSTRUMENTFUNCTION", instrumentfunction, false);
/* 1405:     */   }
/* 1406:     */   
/* 1407:     */   public void setISADDED(Boolean isadded)
/* 1408:     */   {
/* 1409:1229 */     setValue("ISADDED", isadded, false);
/* 1410:     */   }
/* 1411:     */   
/* 1412:     */   public void setLDKEY(Integer ldkey)
/* 1413:     */   {
/* 1414:1233 */     setValue("LDKEY", ldkey, false);
/* 1415:     */   }
/* 1416:     */   
/* 1417:     */   public void setNOMINALIN(String nominalin)
/* 1418:     */   {
/* 1419:1237 */     setValue("NOMINALIN", nominalin, false);
/* 1420:     */   }
/* 1421:     */   
/* 1422:     */   public void setORGID(String orgid)
/* 1423:     */   {
/* 1424:1241 */     setValue("ORGID", orgid, false);
/* 1425:     */   }
/* 1426:     */   
/* 1427:     */   public void setOUTPUTVALUE(String outputvalue)
/* 1428:     */   {
/* 1429:1245 */     setValue("OUTPUTVALUE", outputvalue, false);
/* 1430:     */   }
/* 1431:     */   
/* 1432:     */   public void setOUTPUTVALUE_NP(String outputvalue_np)
/* 1433:     */   {
/* 1434:1249 */     setValue("OUTPUTVALUE_NP", outputvalue_np, false);
/* 1435:     */   }
/* 1436:     */   
/* 1437:     */   public void setPLANTYPE(String plantype)
/* 1438:     */   {
/* 1439:1253 */     setValue("PLANTYPE", plantype, false);
/* 1440:     */   }
/* 1441:     */   
/* 1442:     */   public void setPLUSCWODSPOINTID(Integer pluscwodspointid)
/* 1443:     */   {
/* 1444:1257 */     setValue("PLUSCWODSPOINTID", pluscwodspointid, false);
/* 1445:     */   }
/* 1446:     */   
/* 1447:     */   public void setPOINT(Integer point)
/* 1448:     */   {
/* 1449:1261 */     setValue("POINT", point, false);
/* 1450:     */   }
/* 1451:     */   
/* 1452:     */   public void setPOINTDESCRIPTION(String pointdescription)
/* 1453:     */   {
/* 1454:1265 */     setValue("POINTDESCRIPTION", pointdescription, false);
/* 1455:     */   }
/* 1456:     */   
/* 1457:     */   public void setPROCESSEU(String processeu)
/* 1458:     */   {
/* 1459:1269 */     setValue("PROCESSEU", processeu, false);
/* 1460:     */   }
/* 1461:     */   
/* 1462:     */   public void setPROCESSEUFACTOR(String processeufactor)
/* 1463:     */   {
/* 1464:1273 */     setValue("PROCESSEUFACTOR", processeufactor, false);
/* 1465:     */   }
/* 1466:     */   
/* 1467:     */   public void setREVISIONNUM(Integer revisionnum)
/* 1468:     */   {
/* 1469:1277 */     setValue("REVISIONNUM", revisionnum, false);
/* 1470:     */   }
/* 1471:     */   
/* 1472:     */   public void setRON1LOWER(String ron1lower)
/* 1473:     */   {
/* 1474:1281 */     setValue("RON1LOWER", ron1lower, false);
/* 1475:     */   }
/* 1476:     */   
/* 1477:     */   public void setRON1LOWER_NP(String ron1lower_np)
/* 1478:     */   {
/* 1479:1285 */     setValue("RON1LOWER_NP", ron1lower_np, false);
/* 1480:     */   }
/* 1481:     */   
/* 1482:     */   public void setRON1TYPE(String ron1type)
/* 1483:     */   {
/* 1484:1289 */     setValue("RON1TYPE", ron1type, false);
/* 1485:     */   }
/* 1486:     */   
/* 1487:     */   public void setRON1UPPER(String ron1upper)
/* 1488:     */   {
/* 1489:1293 */     setValue("RON1UPPER", ron1upper, false);
/* 1490:     */   }
/* 1491:     */   
/* 1492:     */   public void setRON1UPPER_NP(String ron1upper_np)
/* 1493:     */   {
/* 1494:1297 */     setValue("RON1UPPER_NP", ron1upper_np, false);
/* 1495:     */   }
/* 1496:     */   
/* 1497:     */   public void setSETPOINTACTION(String setpointaction)
/* 1498:     */   {
/* 1499:1301 */     setValue("SETPOINTACTION", setpointaction, false);
/* 1500:     */   }
/* 1501:     */   
/* 1502:     */   public void setSETPOINTVALUE(String setpointvalue)
/* 1503:     */   {
/* 1504:1305 */     setValue("SETPOINTVALUE", setpointvalue, false);
/* 1505:     */   }
/* 1506:     */   
/* 1507:     */   public void setSETPOINTVALUE_NP(String setpointvalue_np)
/* 1508:     */   {
/* 1509:1309 */     setValue("SETPOINTVALUE_NP", setpointvalue_np, false);
/* 1510:     */   }
/* 1511:     */   
/* 1512:     */   public void setSITEID(String siteid)
/* 1513:     */   {
/* 1514:1313 */     setValue("SITEID", siteid, false);
/* 1515:     */   }
/* 1516:     */   
/* 1517:     */   public void setTOLERANCEEU(String toleranceeu)
/* 1518:     */   {
/* 1519:1317 */     setValue("TOLERANCEEU", toleranceeu, false);
/* 1520:     */   }
/* 1521:     */   
/* 1522:     */   public void setWONUM(String wonum)
/* 1523:     */   {
/* 1524:1321 */     setValue("WONUM", wonum, false);
/* 1525:     */   }
/* 1526:     */   
/* 1527:     */   public void setASFINPUTSTDDEV(String asfinputstddev)
/* 1528:     */   {
/* 1529:1325 */     setValue("ASFINPUTSTDDEV", asfinputstddev, false);
/* 1530:     */   }
/* 1531:     */   
/* 1532:     */   public void setASFOUNDERROR(Boolean asfounderror)
/* 1533:     */   {
/* 1534:1329 */     setValue("ASFOUNDERROR", asfounderror, false);
/* 1535:     */   }
/* 1536:     */   
/* 1537:     */   public void setASFOUNDFAIL(Boolean asfoundfail)
/* 1538:     */   {
/* 1539:1333 */     setValue("ASFOUNDFAIL", asfoundfail, false);
/* 1540:     */   }
/* 1541:     */   
/* 1542:     */   public void setASFOUNDPASS(Boolean asfoundpass)
/* 1543:     */   {
/* 1544:1337 */     setValue("ASFOUNDPASS", asfoundpass, false);
/* 1545:     */   }
/* 1546:     */   
/* 1547:     */   public void setASFOUNDUNIT(String asfoundunit)
/* 1548:     */   {
/* 1549:1341 */     setValue("ASFOUNDUNIT", asfoundunit, false);
/* 1550:     */   }
/* 1551:     */   
/* 1552:     */   public void setASFOUTPUTSTDDEV(String asfoutputstddev)
/* 1553:     */   {
/* 1554:1345 */     setValue("ASFOUTPUTSTDDEV", asfoutputstddev, false);
/* 1555:     */   }
/* 1556:     */   
/* 1557:     */   public void setASFSETPTSTDDEV(String asfsetptstddev)
/* 1558:     */   {
/* 1559:1349 */     setValue("ASFSETPTSTDDEV", asfsetptstddev, false);
/* 1560:     */   }
/* 1561:     */   
/* 1562:     */   public void setASLEFTERROR(Boolean aslefterror)
/* 1563:     */   {
/* 1564:1353 */     setValue("ASLEFTERROR", aslefterror, false);
/* 1565:     */   }
/* 1566:     */   
/* 1567:     */   public void setASLEFTFAIL(Boolean asleftfail)
/* 1568:     */   {
/* 1569:1357 */     setValue("ASLEFTFAIL", asleftfail, false);
/* 1570:     */   }
/* 1571:     */   
/* 1572:     */   public void setASLEFTPASS(Boolean asleftpass)
/* 1573:     */   {
/* 1574:1361 */     setValue("ASLEFTPASS", asleftpass, false);
/* 1575:     */   }
/* 1576:     */   
/* 1577:     */   public void setASLEFTUNIT(String asleftunit)
/* 1578:     */   {
/* 1579:1365 */     setValue("ASLEFTUNIT", asleftunit, false);
/* 1580:     */   }
/* 1581:     */   
/* 1582:     */   public void setASLINPUTSTDDEV(String aslinputstddev)
/* 1583:     */   {
/* 1584:1369 */     setValue("ASLINPUTSTDDEV", aslinputstddev, false);
/* 1585:     */   }
/* 1586:     */   
/* 1587:     */   public void setASLOUTPUTSTDDEV(String asloutputstddev)
/* 1588:     */   {
/* 1589:1373 */     setValue("ASLOUTPUTSTDDEV", asloutputstddev, false);
/* 1590:     */   }
/* 1591:     */   
/* 1592:     */   public void setASLSETPTSTDDEV(String aslsetptstddev)
/* 1593:     */   {
/* 1594:1377 */     setValue("ASLSETPTSTDDEV", aslsetptstddev, false);
/* 1595:     */   }
/* 1596:     */   
/* 1597:     */   public void setCOMMENTS(String comments)
/* 1598:     */   {
/* 1599:1381 */     setValue("COMMENTS", comments, false);
/* 1600:     */   }
/* 1601:     */   
/* 1602:     */   public void setPVASLTINPUT(String pvasltinput)
/* 1603:     */   {
/* 1604:1385 */     setValue("PVASLTINPUT", pvasltinput, false);
/* 1605:     */   }
/* 1606:     */   
/* 1607:     */   public void setPVASLTOUTPUT(String pvasltoutput)
/* 1608:     */   {
/* 1609:1389 */     setValue("PVASLTOUTPUT", pvasltoutput, false);
/* 1610:     */   }
/* 1611:     */   
/* 1612:     */   public void setPVASLTSETPNT(String pvasltsetpnt)
/* 1613:     */   {
/* 1614:1393 */     setValue("PVASLTSETPNT", pvasltsetpnt, false);
/* 1615:     */   }
/* 1616:     */   
/* 1617:     */   public void setSETPOINTADJ(Boolean setpointadj)
/* 1618:     */   {
/* 1619:1397 */     setValue("SETPOINTADJ", setpointadj, false);
/* 1620:     */   }
/* 1621:     */   
/* 1622:     */   public void setValue(String key, Object object, long validationFlag)
/* 1623:     */   {
/* 1624:1401 */     setValue(key, object, validationFlag, true);
/* 1625:     */   }
/* 1626:     */   
/* 1627:     */   public void setValue(String key, Object object, long validationFlag, boolean markAsChanged)
/* 1628:     */   {
/* 1629:1406 */     if (containsAttribute(key))
/* 1630:     */     {
/* 1631:1407 */       if (markAsChanged)
/* 1632:     */       {
/* 1633:1408 */         this.changedFields.add(key.toUpperCase());
/* 1634:1409 */         this.validationFlags.put(key.toUpperCase(), new Long(validationFlag));
/* 1635:     */       }
/* 1636:     */       else
/* 1637:     */       {
/* 1638:1411 */         this.validationFlags.remove(key.toUpperCase());
/* 1639:     */       }
/* 1640:1413 */       this.mboData.put(key.toUpperCase(), object);
/* 1641:     */     }
/* 1642:1415 */     else if ((this.plusCWODSInstrTO != null) && (getPlusCWODSInstrTO().containsAttribute(key)))
/* 1643:     */     {
/* 1644:1416 */       getPlusCWODSInstrTO().setValue(key, object, validationFlag, markAsChanged);
/* 1645:     */     }
/* 1646:1417 */     else if ((this.plusCWODSTO != null) && (getPlusCWODSTO().containsAttribute(key)))
/* 1647:     */     {
/* 1648:1418 */       getPlusCWODSTO().setValue(key, object, validationFlag, markAsChanged);
/* 1649:     */     }
/* 1650:     */     else
/* 1651:     */     {
/* 1652:1420 */       throw new RuntimeException("No suitable class to set " + key + " attribute");
/* 1653:     */     }
/* 1654:     */   }
/* 1655:     */   
/* 1656:     */   public long getValidationFlag(String key)
/* 1657:     */   {
/* 1658:1427 */     String keyUpper = key.toUpperCase();
/* 1659:1428 */     PlusCMboRemote suitable = getObjectOwner(keyUpper);
/* 1660:1429 */     long value = 0L;
/* 1661:1430 */     if (suitable == this)
/* 1662:     */     {
/* 1663:1431 */       Object o = this.validationFlags.get(keyUpper);
/* 1664:1432 */       value = o != null ? new Long(o.toString()).longValue() : 11L;
/* 1665:     */     }
/* 1666:     */     else
/* 1667:     */     {
/* 1668:1434 */       suitable.getValidationFlag(key);
/* 1669:     */     }
/* 1670:1436 */     return value;
/* 1671:     */   }
/* 1672:     */   
/* 1673:     */   public Set getNonPersistentFieldsName()
/* 1674:     */   {
/* 1675:1440 */     return getNonPersistentFields();
/* 1676:     */   }
/* 1677:     */   
/* 1678:     */   private Set getNonPersistentFields()
/* 1679:     */   {
/* 1680:     */     Iterator iter;
/* 1681:1444 */     if (this.nonPersistentFields == null)
/* 1682:     */     {
/* 1683:1445 */       this.nonPersistentFields = new HashSet();
/* 1684:1446 */       for (iter = this.mboData.keySet().iterator(); iter.hasNext();)
/* 1685:     */       {
/* 1686:1447 */         String element = (String)iter.next();
/* 1687:1448 */         if (element.indexOf("_NP") >= 0) {
/* 1688:1449 */           this.nonPersistentFields.add(element.toUpperCase());
/* 1689:     */         }
/* 1690:     */       }
/* 1691:     */     }
/* 1692:1453 */     return this.nonPersistentFields;
/* 1693:     */   }
/* 1694:     */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     psdi.plusc.app.pluscds.pluscmobilecommon.PlusCWODSPointTO
 * JD-Core Version:    0.7.0.1
 */