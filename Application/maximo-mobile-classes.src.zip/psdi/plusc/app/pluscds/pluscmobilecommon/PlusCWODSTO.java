/*   1:    */ package psdi.plusc.app.pluscds.pluscmobilecommon;
/*   2:    */ 
/*   3:    */ import java.lang.reflect.Method;
/*   4:    */ import java.util.Date;
/*   5:    */ import java.util.HashMap;
/*   6:    */ import java.util.HashSet;
/*   7:    */ import java.util.Iterator;
/*   8:    */ import java.util.LinkedList;
/*   9:    */ import java.util.List;
/*  10:    */ import java.util.Locale;
/*  11:    */ import java.util.Map;
/*  12:    */ import java.util.Set;
/*  13:    */ 
/*  14:    */ public class PlusCWODSTO
/*  15:    */   implements PlusCMboRemote
/*  16:    */ {
/*  17:    */   private static final long serialVersionUID = 1L;
/*  18: 38 */   private Set changedFields = new HashSet();
/*  19:    */   private String fieldName;
/*  20:    */   private Locale locale;
/*  21: 44 */   private Map mboData = new HashMap();
/*  22: 46 */   private Map validationFlags = new HashMap();
/*  23:    */   private PlusCWODSPointTO plusCWODSPointTO;
/*  24:    */   private PlusCWODSInstrTO plusCWODSInstrTO;
/*  25:    */   private Set nonPersistentFields;
/*  26:    */   
/*  27:    */   public PlusCWODSTO()
/*  28:    */   {
/*  29: 56 */     for (Iterator iter = getAttributeNames().iterator(); iter.hasNext();)
/*  30:    */     {
/*  31: 57 */       String element = (String)iter.next();
/*  32: 58 */       this.mboData.put(element, null);
/*  33:    */     }
/*  34:    */   }
/*  35:    */   
/*  36:    */   public String getASFOUNDCALSTATUS()
/*  37:    */   {
/*  38: 63 */     return getString("ASFOUNDCALSTATUS");
/*  39:    */   }
/*  40:    */   
/*  41:    */   public String getASFOUNDCOMMENTS()
/*  42:    */   {
/*  43: 67 */     return getString("ASFOUNDCOMMENTS");
/*  44:    */   }
/*  45:    */   
/*  46:    */   public String getASLEFTCALSTATUS()
/*  47:    */   {
/*  48: 71 */     return getString("ASLEFTCALSTATUS");
/*  49:    */   }
/*  50:    */   
/*  51:    */   public String getASLEFTCOMMENTS()
/*  52:    */   {
/*  53: 75 */     return getString("ASLEFTCOMMENTS");
/*  54:    */   }
/*  55:    */   
/*  56:    */   public String getDS1()
/*  57:    */   {
/*  58: 79 */     return getString("DS1");
/*  59:    */   }
/*  60:    */   
/*  61:    */   public String getDS10()
/*  62:    */   {
/*  63: 83 */     return getString("DS10");
/*  64:    */   }
/*  65:    */   
/*  66:    */   public String getDS2()
/*  67:    */   {
/*  68: 87 */     return getString("DS2");
/*  69:    */   }
/*  70:    */   
/*  71:    */   public String getDS3()
/*  72:    */   {
/*  73: 91 */     return getString("DS3");
/*  74:    */   }
/*  75:    */   
/*  76:    */   public String getDS4()
/*  77:    */   {
/*  78: 95 */     return getString("DS4");
/*  79:    */   }
/*  80:    */   
/*  81:    */   public String getDS5()
/*  82:    */   {
/*  83: 99 */     return getString("DS5");
/*  84:    */   }
/*  85:    */   
/*  86:    */   public String getDS6()
/*  87:    */   {
/*  88:103 */     return getString("DS6");
/*  89:    */   }
/*  90:    */   
/*  91:    */   public String getDS7()
/*  92:    */   {
/*  93:107 */     return getString("DS7");
/*  94:    */   }
/*  95:    */   
/*  96:    */   public String getDS8()
/*  97:    */   {
/*  98:111 */     return getString("DS8");
/*  99:    */   }
/* 100:    */   
/* 101:    */   public String getDS9()
/* 102:    */   {
/* 103:115 */     return getString("DS9");
/* 104:    */   }
/* 105:    */   
/* 106:    */   public String getDSAL1()
/* 107:    */   {
/* 108:119 */     return getString("DSAL1");
/* 109:    */   }
/* 110:    */   
/* 111:    */   public String getDSAL10()
/* 112:    */   {
/* 113:123 */     return getString("DSAL10");
/* 114:    */   }
/* 115:    */   
/* 116:    */   public String getDSAL2()
/* 117:    */   {
/* 118:127 */     return getString("DSAL2");
/* 119:    */   }
/* 120:    */   
/* 121:    */   public String getDSAL3()
/* 122:    */   {
/* 123:131 */     return getString("DSAL3");
/* 124:    */   }
/* 125:    */   
/* 126:    */   public String getDSAL4()
/* 127:    */   {
/* 128:135 */     return getString("DSAL4");
/* 129:    */   }
/* 130:    */   
/* 131:    */   public String getDSAL5()
/* 132:    */   {
/* 133:139 */     return getString("DSAL5");
/* 134:    */   }
/* 135:    */   
/* 136:    */   public String getDSAL6()
/* 137:    */   {
/* 138:143 */     return getString("DSAL6");
/* 139:    */   }
/* 140:    */   
/* 141:    */   public String getDSAL7()
/* 142:    */   {
/* 143:147 */     return getString("DSAL7");
/* 144:    */   }
/* 145:    */   
/* 146:    */   public String getDSAL8()
/* 147:    */   {
/* 148:151 */     return getString("DSAL8");
/* 149:    */   }
/* 150:    */   
/* 151:    */   public String getDSAL9()
/* 152:    */   {
/* 153:155 */     return getString("DSAL9");
/* 154:    */   }
/* 155:    */   
/* 156:    */   public String getDSPLANNUM()
/* 157:    */   {
/* 158:159 */     return getString("DSPLANNUM");
/* 159:    */   }
/* 160:    */   
/* 161:    */   public Integer getLDKEY()
/* 162:    */   {
/* 163:163 */     return getInt("LDKEY");
/* 164:    */   }
/* 165:    */   
/* 166:    */   public String getORGID()
/* 167:    */   {
/* 168:167 */     return getString("ORGID");
/* 169:    */   }
/* 170:    */   
/* 171:    */   public Integer getPLUSCWODSID()
/* 172:    */   {
/* 173:171 */     return getInt("PLUSCWODSID");
/* 174:    */   }
/* 175:    */   
/* 176:    */   public String getSITEID()
/* 177:    */   {
/* 178:175 */     return getString("SITEID");
/* 179:    */   }
/* 180:    */   
/* 181:    */   public String getWONUM()
/* 182:    */   {
/* 183:179 */     return getString("WONUM");
/* 184:    */   }
/* 185:    */   
/* 186:    */   public String getCERTIFICATENUM()
/* 187:    */   {
/* 188:183 */     return getString("CERTIFICATENUM");
/* 189:    */   }
/* 190:    */   
/* 191:    */   public String getLOCATION()
/* 192:    */   {
/* 193:187 */     return getString("LOCATION");
/* 194:    */   }
/* 195:    */   
/* 196:    */   public Boolean getREQUIRED()
/* 197:    */   {
/* 198:191 */     return getBoolean("REQUIRED");
/* 199:    */   }
/* 200:    */   
/* 201:    */   public void setASFOUNDCALSTATUS(String asfoundcalstatus)
/* 202:    */   {
/* 203:195 */     setValue("ASFOUNDCALSTATUS", asfoundcalstatus, false);
/* 204:    */   }
/* 205:    */   
/* 206:    */   public void setASFOUNDCOMMENTS(String asfoundcomments)
/* 207:    */   {
/* 208:199 */     setValue("ASFOUNDCOMMENTS", asfoundcomments, false);
/* 209:    */   }
/* 210:    */   
/* 211:    */   public void setASLEFTCALSTATUS(String asleftcalstatus)
/* 212:    */   {
/* 213:203 */     setValue("ASLEFTCALSTATUS", asleftcalstatus, false);
/* 214:    */   }
/* 215:    */   
/* 216:    */   public void setASLEFTCOMMENTS(String asleftcomments)
/* 217:    */   {
/* 218:207 */     setValue("ASLEFTCOMMENTS", asleftcomments, false);
/* 219:    */   }
/* 220:    */   
/* 221:    */   public void setDS1(String ds1)
/* 222:    */   {
/* 223:211 */     setValue("DS1", ds1, false);
/* 224:    */   }
/* 225:    */   
/* 226:    */   public void setDS10(String ds10)
/* 227:    */   {
/* 228:215 */     setValue("DS10", ds10, false);
/* 229:    */   }
/* 230:    */   
/* 231:    */   public void setDS2(String ds2)
/* 232:    */   {
/* 233:219 */     setValue("DS2", ds2, false);
/* 234:    */   }
/* 235:    */   
/* 236:    */   public void setDS3(String ds3)
/* 237:    */   {
/* 238:223 */     setValue("DS3", ds3, false);
/* 239:    */   }
/* 240:    */   
/* 241:    */   public void setDS4(String ds4)
/* 242:    */   {
/* 243:227 */     setValue("DS4", ds4, false);
/* 244:    */   }
/* 245:    */   
/* 246:    */   public void setDS5(String ds5)
/* 247:    */   {
/* 248:231 */     setValue("DS5", ds5, false);
/* 249:    */   }
/* 250:    */   
/* 251:    */   public void setDS6(String ds6)
/* 252:    */   {
/* 253:235 */     setValue("DS6", ds6, false);
/* 254:    */   }
/* 255:    */   
/* 256:    */   public void setDS7(String ds7)
/* 257:    */   {
/* 258:239 */     setValue("DS7", ds7, false);
/* 259:    */   }
/* 260:    */   
/* 261:    */   public void setDS8(String ds8)
/* 262:    */   {
/* 263:243 */     setValue("DS8", ds8, false);
/* 264:    */   }
/* 265:    */   
/* 266:    */   public void setDS9(String ds9)
/* 267:    */   {
/* 268:247 */     setValue("DS9", ds9, false);
/* 269:    */   }
/* 270:    */   
/* 271:    */   public void setDSAL1(String dsal1)
/* 272:    */   {
/* 273:251 */     setValue("DSAL1", dsal1, false);
/* 274:    */   }
/* 275:    */   
/* 276:    */   public void setDSAL10(String dsal10)
/* 277:    */   {
/* 278:255 */     setValue("DSAL10", dsal10, false);
/* 279:    */   }
/* 280:    */   
/* 281:    */   public void setDSAL2(String dsal2)
/* 282:    */   {
/* 283:259 */     setValue("DSAL2", dsal2, false);
/* 284:    */   }
/* 285:    */   
/* 286:    */   public void setDSAL3(String dsal3)
/* 287:    */   {
/* 288:263 */     setValue("DSAL3", dsal3, false);
/* 289:    */   }
/* 290:    */   
/* 291:    */   public void setDSAL4(String dsal4)
/* 292:    */   {
/* 293:267 */     setValue("DSAL4", dsal4, false);
/* 294:    */   }
/* 295:    */   
/* 296:    */   public void setDSAL5(String dsal5)
/* 297:    */   {
/* 298:271 */     setValue("DSAL5", dsal5, false);
/* 299:    */   }
/* 300:    */   
/* 301:    */   public void setDSAL6(String dsal6)
/* 302:    */   {
/* 303:275 */     setValue("DSAL6", dsal6, false);
/* 304:    */   }
/* 305:    */   
/* 306:    */   public void setDSAL7(String dsal7)
/* 307:    */   {
/* 308:279 */     setValue("DSAL7", dsal7, false);
/* 309:    */   }
/* 310:    */   
/* 311:    */   public void setDSAL8(String dsal8)
/* 312:    */   {
/* 313:283 */     setValue("DSAL8", dsal8, false);
/* 314:    */   }
/* 315:    */   
/* 316:    */   public void setDSAL9(String dsal9)
/* 317:    */   {
/* 318:287 */     setValue("DSAL9", dsal9, false);
/* 319:    */   }
/* 320:    */   
/* 321:    */   public void setDSPLANNUM(String dsplannum)
/* 322:    */   {
/* 323:291 */     setValue("DSPLANNUM", dsplannum, false);
/* 324:    */   }
/* 325:    */   
/* 326:    */   public void setLDKEY(Integer ldkey)
/* 327:    */   {
/* 328:295 */     setValue("LDKEY", ldkey, false);
/* 329:    */   }
/* 330:    */   
/* 331:    */   public void setORGID(String orgid)
/* 332:    */   {
/* 333:299 */     setValue("ORGID", orgid, false);
/* 334:    */   }
/* 335:    */   
/* 336:    */   public void setPLUSCWODSID(Integer pluscwodsid)
/* 337:    */   {
/* 338:303 */     setValue("PLUSCWODSID", pluscwodsid, false);
/* 339:    */   }
/* 340:    */   
/* 341:    */   public void setSITEID(String siteid)
/* 342:    */   {
/* 343:307 */     setValue("SITEID", siteid, false);
/* 344:    */   }
/* 345:    */   
/* 346:    */   public void setWONUM(String wonum)
/* 347:    */   {
/* 348:311 */     setValue("WONUM", wonum, false);
/* 349:    */   }
/* 350:    */   
/* 351:    */   public void setCERTIFICATENUM(String certificatenum)
/* 352:    */   {
/* 353:315 */     setValue("CERTIFICATENUM", certificatenum, false);
/* 354:    */   }
/* 355:    */   
/* 356:    */   public void setLOCATION(String location)
/* 357:    */   {
/* 358:319 */     setValue("LOCATION", location, false);
/* 359:    */   }
/* 360:    */   
/* 361:    */   public void setREQUIRED(Boolean required)
/* 362:    */   {
/* 363:323 */     setValue("REQUIRED", required, false);
/* 364:    */   }
/* 365:    */   
/* 366:    */   public void setFieldName(String name)
/* 367:    */   {
/* 368:327 */     this.fieldName = name;
/* 369:    */   }
/* 370:    */   
/* 371:    */   public boolean isRoundUpField()
/* 372:    */   {
/* 373:331 */     String fieldName = this.fieldName;
/* 374:332 */     return (fieldName != null) && (!fieldName.equalsIgnoreCase("INSTRCALRANGEFROM")) && (!fieldName.equalsIgnoreCase("INSTRCALRANGETO")) && (!fieldName.equalsIgnoreCase("INSTROUTRANGEFROM")) && (!fieldName.equalsIgnoreCase("INSTROUTRANGETO")) && (!fieldName.equalsIgnoreCase("RON1LOWERVALUE")) && (!fieldName.equalsIgnoreCase("RON1UPPERVALUE")) && (!fieldName.equalsIgnoreCase("TOL1LOWERVALUE")) && (!fieldName.equalsIgnoreCase("TOL1UPPERVALUE")) && (!fieldName.equalsIgnoreCase("TOL2LOWERVALUE")) && (!fieldName.equalsIgnoreCase("TOL2UPPERVALUE")) && (!fieldName.equalsIgnoreCase("TOL3LOWERVALUE")) && (!fieldName.equalsIgnoreCase("TOL3UPPERVALUE")) && (!fieldName.equalsIgnoreCase("TOL4LOWERVALUE")) && (!fieldName.equalsIgnoreCase("TOL4UPPERVALUE")) && (!fieldName.equalsIgnoreCase("TOL1SUMEU")) && (!fieldName.equalsIgnoreCase("TOL1SUMREAD")) && (!fieldName.equalsIgnoreCase("TOL1SUMSPAN")) && (!fieldName.equalsIgnoreCase("TOL1SUMURV")) && (!fieldName.equalsIgnoreCase("TOL2SUMEU")) && (!fieldName.equalsIgnoreCase("TOL2SUMREAD")) && (!fieldName.equalsIgnoreCase("TOL2SUMSPAN")) && (!fieldName.equalsIgnoreCase("TOL2SUMURV")) && (!fieldName.equalsIgnoreCase("TOL3SUMEU")) && (!fieldName.equalsIgnoreCase("TOL3SUMREAD")) && (!fieldName.equalsIgnoreCase("TOL3SUMSPAN")) && (!fieldName.equalsIgnoreCase("TOL3SUMURV")) && (!fieldName.equalsIgnoreCase("TOL4SUMEU")) && (!fieldName.equalsIgnoreCase("TOL4SUMREAD")) && (!fieldName.equalsIgnoreCase("TOL4SUMSPAN")) && (!fieldName.equalsIgnoreCase("TOL4SUMURV"));
/* 375:    */   }
/* 376:    */   
/* 377:    */   public String getString(String key)
/* 378:    */   {
/* 379:365 */     PlusCMboRemote suitable = getObjectOwner(key);
/* 380:366 */     Object value = suitable.getObject(key);
/* 381:367 */     return value == null ? "" : value.toString();
/* 382:    */   }
/* 383:    */   
/* 384:    */   public Integer getInt(String key)
/* 385:    */   {
/* 386:371 */     PlusCMboRemote suitable = getObjectOwner(key);
/* 387:372 */     Object value = suitable.getObject(key);
/* 388:373 */     return value == null ? new Integer(0) : (Integer)value;
/* 389:    */   }
/* 390:    */   
/* 391:    */   public Long getLong(String key)
/* 392:    */   {
/* 393:377 */     PlusCMboRemote suitable = getObjectOwner(key);
/* 394:378 */     Object value = suitable.getObject(key);
/* 395:379 */     return value == null ? new Long(0L) : (Long)value;
/* 396:    */   }
/* 397:    */   
/* 398:    */   public Boolean getBoolean(String key)
/* 399:    */   {
/* 400:383 */     PlusCMboRemote suitable = getObjectOwner(key);
/* 401:384 */     Object value = suitable.getObject(key);
/* 402:385 */     return value == null ? new Boolean(false) : (Boolean)value;
/* 403:    */   }
/* 404:    */   
/* 405:    */   public Object getObject(String key)
/* 406:    */   {
/* 407:389 */     return this.mboData.get(key.toUpperCase());
/* 408:    */   }
/* 409:    */   
/* 410:    */   public Date getDate(String key)
/* 411:    */   {
/* 412:393 */     PlusCMboRemote suitable = getObjectOwner(key);
/* 413:394 */     return (Date)suitable.getObject(key);
/* 414:    */   }
/* 415:    */   
/* 416:    */   public PlusCDSTO getPlusCDSTO()
/* 417:    */   {
/* 418:398 */     throw new UnsupportedOperationException("In this class this method is not implemented.");
/* 419:    */   }
/* 420:    */   
/* 421:    */   public void setPlusCDSTO(PlusCDSTO plusCDSTO)
/* 422:    */   {
/* 423:403 */     throw new UnsupportedOperationException("In this class this method is not implemented.");
/* 424:    */   }
/* 425:    */   
/* 426:    */   public PlusCDSInstrTO getPlusCDSInstrTO()
/* 427:    */   {
/* 428:408 */     throw new UnsupportedOperationException("In this class this method is not implemented.");
/* 429:    */   }
/* 430:    */   
/* 431:    */   public void setPlusCDSInstTO(PlusCDSInstrTO plusCDSInstrTO)
/* 432:    */   {
/* 433:413 */     throw new UnsupportedOperationException("In this class this method is not implemented.");
/* 434:    */   }
/* 435:    */   
/* 436:    */   public PlusCDSPointTO getPlusCDSPointTO()
/* 437:    */   {
/* 438:419 */     throw new UnsupportedOperationException("In this class this method is not implemented.");
/* 439:    */   }
/* 440:    */   
/* 441:    */   public void setPlusCDSPointTO(PlusCDSPointTO plusCDSPointTO)
/* 442:    */   {
/* 443:424 */     throw new UnsupportedOperationException("In this class this method is not implemented.");
/* 444:    */   }
/* 445:    */   
/* 446:    */   public void setPlusCWODSTO(PlusCWODSTO plusCWODSTO)
/* 447:    */   {
/* 448:430 */     throw new UnsupportedOperationException("In this class this method is not implemented.");
/* 449:    */   }
/* 450:    */   
/* 451:    */   public PlusCWODSTO getPlusCWODSTO()
/* 452:    */   {
/* 453:434 */     return this;
/* 454:    */   }
/* 455:    */   
/* 456:    */   public void setPlusCWODSInstrTO(PlusCWODSInstrTO plusCWODSInstrTO)
/* 457:    */   {
/* 458:438 */     this.plusCWODSInstrTO = plusCWODSInstrTO;
/* 459:439 */     if (plusCWODSInstrTO.getPlusCWODSTO() != this) {
/* 460:440 */       plusCWODSInstrTO.setPlusCWODSTO(this);
/* 461:    */     }
/* 462:    */   }
/* 463:    */   
/* 464:    */   public PlusCWODSInstrTO getPlusCWODSInstrTO()
/* 465:    */   {
/* 466:445 */     return this.plusCWODSInstrTO;
/* 467:    */   }
/* 468:    */   
/* 469:    */   public void setPlusCWODSPointTO(PlusCWODSPointTO plusCWODSPointTO)
/* 470:    */   {
/* 471:449 */     this.plusCWODSPointTO = plusCWODSPointTO;
/* 472:450 */     if (plusCWODSPointTO.getPlusCWODSTO() != this) {
/* 473:451 */       plusCWODSPointTO.setPlusCWODSTO(this);
/* 474:    */     }
/* 475:    */   }
/* 476:    */   
/* 477:    */   public PlusCWODSPointTO getPlusCWODSPointTO()
/* 478:    */   {
/* 479:456 */     return this.plusCWODSPointTO;
/* 480:    */   }
/* 481:    */   
/* 482:    */   public void setValue(String key, Object object)
/* 483:    */   {
/* 484:460 */     setValue(key, object, true);
/* 485:    */   }
/* 486:    */   
/* 487:    */   public void setValue(String key, Object object, boolean markAsChanged)
/* 488:    */   {
/* 489:464 */     setValue(key, object, 0L, markAsChanged);
/* 490:    */   }
/* 491:    */   
/* 492:    */   public Locale getLocale()
/* 493:    */   {
/* 494:469 */     return this.locale;
/* 495:    */   }
/* 496:    */   
/* 497:    */   public void setLocale(Locale locale)
/* 498:    */   {
/* 499:473 */     this.locale = locale;
/* 500:    */   }
/* 501:    */   
/* 502:    */   public boolean isNull(String key)
/* 503:    */   {
/* 504:477 */     Object value = null;
/* 505:478 */     if ((getPlusCWODSInstrTO() != null) && (getPlusCWODSInstrTO().containsAttribute(key)))
/* 506:    */     {
/* 507:479 */       value = getPlusCWODSInstrTO().getObject(key);
/* 508:480 */       return (value == null) || (value.toString().trim().equals(""));
/* 509:    */     }
/* 510:482 */     if ((getPlusCWODSPointTO() != null) && (getPlusCWODSPointTO().containsAttribute(key)))
/* 511:    */     {
/* 512:483 */       value = getPlusCWODSPointTO().getObject(key);
/* 513:484 */       return (value == null) || (value.toString().trim().equals(""));
/* 514:    */     }
/* 515:486 */     if ((getPlusCWODSTO() != null) && (getPlusCWODSTO().containsAttribute(key)))
/* 516:    */     {
/* 517:487 */       value = getPlusCWODSTO().getObject(key);
/* 518:488 */       return (value == null) || (value.toString().trim().equals(""));
/* 519:    */     }
/* 520:490 */     return true;
/* 521:    */   }
/* 522:    */   
/* 523:    */   public Set getChangedFields()
/* 524:    */   {
/* 525:494 */     return this.changedFields;
/* 526:    */   }
/* 527:    */   
/* 528:    */   public void clearAllChangedFieldsSets()
/* 529:    */   {
/* 530:498 */     if (getPlusCWODSInstrTO() != null) {
/* 531:499 */       getPlusCWODSInstrTO().getChangedFields().clear();
/* 532:    */     }
/* 533:501 */     if (getPlusCWODSTO() != null) {
/* 534:502 */       getPlusCWODSTO().getChangedFields().clear();
/* 535:    */     }
/* 536:504 */     if (getPlusCWODSPointTO() != null) {
/* 537:505 */       getPlusCWODSPointTO().getChangedFields().clear();
/* 538:    */     }
/* 539:    */   }
/* 540:    */   
/* 541:    */   private static List getAttributeNames()
/* 542:    */   {
/* 543:510 */     List list = new LinkedList();
/* 544:511 */     Method[] methods = PlusCWODSTO.class.getMethods();
/* 545:512 */     for (int i = 0; i < methods.length; i++) {
/* 546:513 */       if (methods[i].getName().indexOf("set") == 0) {
/* 547:514 */         list.add(methods[i].getName().substring(3).toUpperCase());
/* 548:    */       }
/* 549:    */     }
/* 550:517 */     return list;
/* 551:    */   }
/* 552:    */   
/* 553:    */   protected boolean containsAttribute(String attributeName)
/* 554:    */   {
/* 555:521 */     return this.mboData.containsKey(attributeName.toUpperCase());
/* 556:    */   }
/* 557:    */   
/* 558:    */   private PlusCMboRemote getObjectOwner(String attributeName)
/* 559:    */   {
/* 560:525 */     if ((getPlusCWODSInstrTO() != null) && (getPlusCWODSInstrTO().containsAttribute(attributeName))) {
/* 561:526 */       return getPlusCWODSInstrTO();
/* 562:    */     }
/* 563:529 */     if (getPlusCWODSPointTO().containsAttribute(attributeName)) {
/* 564:530 */       return getPlusCWODSPointTO();
/* 565:    */     }
/* 566:533 */     if ((getPlusCWODSTO() != null) && (getPlusCWODSTO().containsAttribute(attributeName))) {
/* 567:534 */       return getPlusCWODSTO();
/* 568:    */     }
/* 569:537 */     throw new RuntimeException("Neither of suitable classes have the attribute " + attributeName);
/* 570:    */   }
/* 571:    */   
/* 572:    */   public void setValue(String key, Object object, long validationFlag)
/* 573:    */   {
/* 574:541 */     setValue(key, object, validationFlag, true);
/* 575:    */   }
/* 576:    */   
/* 577:    */   public void setValue(String key, Object object, long validationFlag, boolean markAsChanged)
/* 578:    */   {
/* 579:546 */     if (containsAttribute(key))
/* 580:    */     {
/* 581:547 */       if (markAsChanged)
/* 582:    */       {
/* 583:548 */         this.changedFields.add(key.toUpperCase());
/* 584:549 */         this.validationFlags.put(key.toUpperCase(), new Long(validationFlag));
/* 585:    */       }
/* 586:    */       else
/* 587:    */       {
/* 588:551 */         this.validationFlags.remove(key.toUpperCase());
/* 589:    */       }
/* 590:553 */       this.mboData.put(key.toUpperCase(), object);
/* 591:    */     }
/* 592:555 */     else if ((this.plusCWODSPointTO != null) && (getPlusCWODSPointTO().containsAttribute(key)))
/* 593:    */     {
/* 594:556 */       getPlusCWODSPointTO().setValue(key, object, validationFlag, markAsChanged);
/* 595:    */     }
/* 596:557 */     else if ((this.plusCWODSInstrTO != null) && (getPlusCWODSInstrTO().containsAttribute(key)))
/* 597:    */     {
/* 598:558 */       getPlusCWODSInstrTO().setValue(key, object, validationFlag, markAsChanged);
/* 599:    */     }
/* 600:    */     else
/* 601:    */     {
/* 602:560 */       throw new RuntimeException("No suitable class to set " + key + " attribute");
/* 603:    */     }
/* 604:    */   }
/* 605:    */   
/* 606:    */   public long getValidationFlag(String key)
/* 607:    */   {
/* 608:566 */     String keyUpper = key.toUpperCase();
/* 609:567 */     PlusCMboRemote suitable = getObjectOwner(keyUpper);
/* 610:568 */     long value = 0L;
/* 611:569 */     if (suitable == this)
/* 612:    */     {
/* 613:570 */       Object o = this.validationFlags.get(keyUpper);
/* 614:571 */       value = o != null ? new Long(o.toString()).longValue() : 11L;
/* 615:    */     }
/* 616:    */     else
/* 617:    */     {
/* 618:573 */       suitable.getValidationFlag(key);
/* 619:    */     }
/* 620:575 */     return value;
/* 621:    */   }
/* 622:    */   
/* 623:    */   public Set getNonPersistentFieldsName()
/* 624:    */   {
/* 625:579 */     return getNonPersistentFields();
/* 626:    */   }
/* 627:    */   
/* 628:    */   private Set getNonPersistentFields()
/* 629:    */   {
/* 630:    */     Iterator iter;
/* 631:583 */     if (this.nonPersistentFields == null)
/* 632:    */     {
/* 633:584 */       this.nonPersistentFields = new HashSet();
/* 634:585 */       for (iter = this.mboData.keySet().iterator(); iter.hasNext();)
/* 635:    */       {
/* 636:586 */         String element = (String)iter.next();
/* 637:587 */         if (element.indexOf("_NP") >= 0) {
/* 638:588 */           this.nonPersistentFields.add(element.toUpperCase());
/* 639:    */         }
/* 640:    */       }
/* 641:    */     }
/* 642:592 */     return this.nonPersistentFields;
/* 643:    */   }
/* 644:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     psdi.plusc.app.pluscds.pluscmobilecommon.PlusCWODSTO
 * JD-Core Version:    0.7.0.1
 */