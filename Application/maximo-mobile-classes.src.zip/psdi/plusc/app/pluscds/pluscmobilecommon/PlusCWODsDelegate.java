/*   1:    */ package psdi.plusc.app.pluscds.pluscmobilecommon;
/*   2:    */ 
/*   3:    */ import com.ibm.tivoli.maximo.util.mboadapter.MboAdapter;
/*   4:    */ import com.ibm.tivoli.maximo.util.mboadapter.MboAdapterConstants;
/*   5:    */ import com.ibm.tivoli.maximo.util.mboadapter.MboSetAdapter;
/*   6:    */ import java.util.Iterator;
/*   7:    */ 
/*   8:    */ public abstract class PlusCWODsDelegate
/*   9:    */   implements MboAdapterConstants
/*  10:    */ {
/*  11:    */   protected MboAdapter thisMbo;
/*  12:    */   
/*  13:    */   public PlusCWODsDelegate(MboAdapter mbo)
/*  14:    */   {
/*  15: 36 */     this.thisMbo = mbo;
/*  16:    */   }
/*  17:    */   
/*  18:    */   protected abstract MboSetAdapter getWODsInstrSet()
/*  19:    */     throws Exception;
/*  20:    */   
/*  21:    */   protected abstract MboSetAdapter getWODsLocationSet()
/*  22:    */     throws Exception;
/*  23:    */   
/*  24:    */   protected abstract PlusCWODsInstrDelegate getWoDsInstrDelegate(MboAdapter paramMboAdapter);
/*  25:    */   
/*  26:    */   protected abstract String getTranslatedAsLeftStatus()
/*  27:    */     throws Exception;
/*  28:    */   
/*  29:    */   protected abstract String getTranslatedAsFoundStatus()
/*  30:    */     throws Exception;
/*  31:    */   
/*  32:    */   public MboAdapter getThisMbo()
/*  33:    */   {
/*  34: 50 */     return this.thisMbo;
/*  35:    */   }
/*  36:    */   
/*  37:    */   public boolean isAllEntered()
/*  38:    */     throws Exception
/*  39:    */   {
/*  40: 58 */     if ((this.thisMbo.isNull("ASSETNUM")) && (this.thisMbo.isNull("LOCATION"))) {
/*  41: 59 */       return false;
/*  42:    */     }
/*  43: 62 */     String asfoundcalstatus = getTranslatedAsFoundStatus();
/*  44: 63 */     String asleftcalstatus = getTranslatedAsLeftStatus();
/*  45: 64 */     boolean required = this.thisMbo.getBoolean("REQUIRED");
/*  46: 66 */     if ((!required) || ((asfoundcalstatus != null) && ((asfoundcalstatus.equalsIgnoreCase("BROKEN")) || (asfoundcalstatus.equalsIgnoreCase("MISSING")))) || ((asleftcalstatus != null) && ((asleftcalstatus.equalsIgnoreCase("BROKEN")) || (asleftcalstatus.equalsIgnoreCase("MISSING"))))) {
/*  47: 75 */       return true;
/*  48:    */     }
/*  49: 78 */     MboAdapter instrMbo = null;
/*  50: 79 */     MboSetAdapter instrs = this.thisMbo.getMboSet("PLUSCWODSINSTR");
/*  51: 80 */     int i = 0;
/*  52: 82 */     while ((instrMbo = instrs.getMbo(i++)) != null)
/*  53:    */     {
/*  54: 84 */       PlusCWODsInstrDelegate woDsInstr = getWoDsInstrDelegate(instrMbo);
/*  55: 86 */       if (!woDsInstr.isAllEntered()) {
/*  56: 87 */         return false;
/*  57:    */       }
/*  58:    */     }
/*  59: 91 */     return true;
/*  60:    */   }
/*  61:    */   
/*  62:    */   public boolean isAllEntered(String prefix)
/*  63:    */     throws Exception
/*  64:    */   {
/*  65:103 */     MboAdapter instrMbo = null;
/*  66:104 */     MboSetAdapter instrs = this.thisMbo.getMboSet("PLUSCWODSINSTR");
/*  67:105 */     int i = 0;
/*  68:106 */     boolean valueStatus = true;
/*  69:107 */     while ((instrMbo = instrs.getMbo(i++)) != null)
/*  70:    */     {
/*  71:109 */       PlusCWODsInstrDelegate woDsInstr = getWoDsInstrDelegate(instrMbo);
/*  72:111 */       if (!woDsInstr.isAllEntered(prefix)) {
/*  73:112 */         valueStatus = false;
/*  74:    */       }
/*  75:    */     }
/*  76:116 */     return valueStatus;
/*  77:    */   }
/*  78:    */   
/*  79:    */   public void setDSRequiredStatus(boolean cleared)
/*  80:    */     throws Exception
/*  81:    */   {
/*  82:131 */     boolean isRequired = this.thisMbo.getBoolean("REQUIRED");
/*  83:132 */     boolean isRequiredReadOnly = this.thisMbo.isReadOnly("REQUIRED");
/*  84:134 */     if ((isRequiredReadOnly) || ((!cleared) && ((!isRequired) || (!isRequiredReadOnly)))) {
/*  85:135 */       if ((cleared) && (allPointsAreCleared()))
/*  86:    */       {
/*  87:136 */         isRequiredReadOnly = false;
/*  88:    */       }
/*  89:    */       else
/*  90:    */       {
/*  91:138 */         isRequired = true;
/*  92:139 */         isRequiredReadOnly = true;
/*  93:    */       }
/*  94:    */     }
/*  95:143 */     this.thisMbo.setValueIfDifferent("REQUIRED", isRequired, 3L);
/*  96:144 */     this.thisMbo.setReadOnly("REQUIRED", isRequiredReadOnly);
/*  97:    */   }
/*  98:    */   
/*  99:    */   public boolean allPointsAreCleared()
/* 100:    */     throws Exception
/* 101:    */   {
/* 102:156 */     MboSetAdapter instrs = getWODsInstrSet();
/* 103:    */     
/* 104:158 */     Iterator it = instrs.iterator();
/* 105:159 */     while (it.hasNext())
/* 106:    */     {
/* 107:160 */       PlusCWODsInstrDelegate woDsInstr = getWoDsInstrDelegate((MboAdapter)it.next());
/* 108:162 */       if (!woDsInstr.isAllClear()) {
/* 109:163 */         return false;
/* 110:    */       }
/* 111:    */     }
/* 112:167 */     return true;
/* 113:    */   }
/* 114:    */   
/* 115:    */   public boolean isLoop()
/* 116:    */     throws Exception
/* 117:    */   {
/* 118:177 */     if (!this.thisMbo.isNull("ASSETNUM")) {
/* 119:178 */       return false;
/* 120:    */     }
/* 121:181 */     MboSetAdapter locationSet = getWODsLocationSet();
/* 122:183 */     if (!locationSet.isEmpty())
/* 123:    */     {
/* 124:184 */       MboAdapter location = locationSet.getMbo(0);
/* 125:185 */       if (location.getBoolean("PLUSCLOOP")) {
/* 126:186 */         return true;
/* 127:    */       }
/* 128:    */     }
/* 129:190 */     return false;
/* 130:    */   }
/* 131:    */   
/* 132:    */   public boolean hasCalPoints()
/* 133:    */     throws Exception
/* 134:    */   {
/* 135:195 */     MboSetAdapter instrs = getWODsInstrSet();
/* 136:    */     
/* 137:197 */     Iterator it = instrs.iterator();
/* 138:198 */     while (it.hasNext())
/* 139:    */     {
/* 140:199 */       PlusCWODsInstrDelegate woDsInstr = getWoDsInstrDelegate((MboAdapter)it.next());
/* 141:201 */       if (woDsInstr.hasCalPoints()) {
/* 142:202 */         return true;
/* 143:    */       }
/* 144:    */     }
/* 145:206 */     return false;
/* 146:    */   }
/* 147:    */   
/* 148:    */   public boolean hasFunctionChecks()
/* 149:    */     throws Exception
/* 150:    */   {
/* 151:211 */     MboSetAdapter instrs = getWODsInstrSet();
/* 152:    */     
/* 153:213 */     Iterator it = instrs.iterator();
/* 154:214 */     while (it.hasNext())
/* 155:    */     {
/* 156:215 */       PlusCWODsInstrDelegate woDsInstr = getWoDsInstrDelegate((MboAdapter)it.next());
/* 157:217 */       if (woDsInstr.hasFunctionChecks()) {
/* 158:218 */         return true;
/* 159:    */       }
/* 160:    */     }
/* 161:222 */     return false;
/* 162:    */   }
/* 163:    */   
/* 164:    */   public boolean hasDynamicChecks()
/* 165:    */     throws Exception
/* 166:    */   {
/* 167:227 */     MboSetAdapter instrs = getWODsInstrSet();
/* 168:    */     
/* 169:229 */     Iterator it = instrs.iterator();
/* 170:230 */     while (it.hasNext())
/* 171:    */     {
/* 172:231 */       PlusCWODsInstrDelegate woDsInstr = getWoDsInstrDelegate((MboAdapter)it.next());
/* 173:233 */       if (woDsInstr.hasDynamicChecks()) {
/* 174:234 */         return true;
/* 175:    */       }
/* 176:    */     }
/* 177:238 */     return false;
/* 178:    */   }
/* 179:    */   
/* 180:    */   public void setValueInOptionalLoopPartDSs(String attributeName, String value, long accessModifier)
/* 181:    */     throws Exception
/* 182:    */   {
/* 183:253 */     if (isLoop())
/* 184:    */     {
/* 185:255 */       Iterator it = this.thisMbo.getThisMboSet().iterator();
/* 186:256 */       while (it.hasNext())
/* 187:    */       {
/* 188:257 */         MboAdapter woDs = (MboAdapter)it.next();
/* 189:259 */         if ((!woDs.getString("DSPLANNUM").equalsIgnoreCase(this.thisMbo.getString("DSPLANNUM"))) && (woDs.getString("LOCATION").equalsIgnoreCase(this.thisMbo.getString("LOCATION"))) && (!woDs.getBoolean("REQUIRED"))) {
/* 190:263 */           woDs.setValue(attributeName, value, accessModifier);
/* 191:    */         }
/* 192:    */       }
/* 193:    */     }
/* 194:    */   }
/* 195:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     psdi.plusc.app.pluscds.pluscmobilecommon.PlusCWODsDelegate
 * JD-Core Version:    0.7.0.1
 */