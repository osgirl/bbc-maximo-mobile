/*   1:    */ package psdi.plusc.app.pluscds.pluscmobilecommon;
/*   2:    */ 
/*   3:    */ import com.ibm.tivoli.maximo.util.mboadapter.MboAdapter;
/*   4:    */ import com.ibm.tivoli.maximo.util.mboadapter.MboSetAdapter;
/*   5:    */ import java.util.Iterator;
/*   6:    */ 
/*   7:    */ public abstract class PlusCWODsInstrDelegate
/*   8:    */ {
/*   9:    */   protected MboAdapter thisMbo;
/*  10:    */   
/*  11:    */   public PlusCWODsInstrDelegate(MboAdapter mbo)
/*  12:    */   {
/*  13: 38 */     if (mbo == null) {
/*  14: 39 */       throw new IllegalArgumentException("mbo=" + mbo);
/*  15:    */     }
/*  16: 41 */     this.thisMbo = mbo;
/*  17:    */   }
/*  18:    */   
/*  19:    */   protected abstract PlusCWODsPointDelegate getWoDsPointDelegate(MboAdapter paramMboAdapter)
/*  20:    */     throws Exception;
/*  21:    */   
/*  22:    */   public abstract MboSetAdapter getWODsPointSet(boolean paramBoolean)
/*  23:    */     throws Exception;
/*  24:    */   
/*  25:    */   protected abstract PlusCWODsDelegate findParentDsDelegate()
/*  26:    */     throws Exception;
/*  27:    */   
/*  28:    */   public PlusCWODsDelegate getDsDelegate()
/*  29:    */     throws Exception
/*  30:    */   {
/*  31: 54 */     return findParentDsDelegate();
/*  32:    */   }
/*  33:    */   
/*  34:    */   public MboAdapter getThisMbo()
/*  35:    */   {
/*  36: 59 */     return this.thisMbo;
/*  37:    */   }
/*  38:    */   
/*  39:    */   public String getType()
/*  40:    */     throws Exception
/*  41:    */   {
/*  42: 63 */     return this.thisMbo.getString("PLANTYPE");
/*  43:    */   }
/*  44:    */   
/*  45:    */   public boolean isRepeatable()
/*  46:    */     throws Exception
/*  47:    */   {
/*  48: 67 */     return this.thisMbo.getBoolean("REPEATABLE");
/*  49:    */   }
/*  50:    */   
/*  51:    */   public boolean isAllEntered()
/*  52:    */     throws Exception
/*  53:    */   {
/*  54: 77 */     MboAdapter pointMbo = null;
/*  55: 78 */     MboSetAdapter points = getWODsPointSet(false);
/*  56: 79 */     int i = 0;
/*  57: 81 */     while ((pointMbo = points.getMbo(i++)) != null)
/*  58:    */     {
/*  59: 83 */       PlusCWODsPointDelegate point = getWoDsPointDelegate(pointMbo);
/*  60: 85 */       if (!point.isAllEntered()) {
/*  61: 86 */         return false;
/*  62:    */       }
/*  63:    */     }
/*  64: 89 */     return true;
/*  65:    */   }
/*  66:    */   
/*  67:    */   public boolean isAllEntered(String prefix)
/*  68:    */     throws Exception
/*  69:    */   {
/*  70:103 */     MboAdapter pointMbo = null;
/*  71:104 */     MboSetAdapter points = getWODsPointSet(false);
/*  72:105 */     int i = 0;
/*  73:106 */     boolean statusValue = true;
/*  74:108 */     while ((pointMbo = points.getMbo(i++)) != null)
/*  75:    */     {
/*  76:110 */       PlusCWODsPointDelegate point = getWoDsPointDelegate(pointMbo);
/*  77:112 */       if (!point.isAllEntered(prefix)) {
/*  78:113 */         statusValue = false;
/*  79:    */       }
/*  80:    */     }
/*  81:116 */     return statusValue;
/*  82:    */   }
/*  83:    */   
/*  84:    */   public boolean isAllClear()
/*  85:    */     throws Exception
/*  86:    */   {
/*  87:123 */     MboSetAdapter points = getWODsPointSet(false);
/*  88:    */     
/*  89:125 */     Iterator it = points.iterator();
/*  90:126 */     while (it.hasNext())
/*  91:    */     {
/*  92:127 */       MboAdapter pointMbo = (MboAdapter)it.next();
/*  93:129 */       if (!pointMbo.getBoolean("ISAVERAGE"))
/*  94:    */       {
/*  95:136 */         PlusCWODsPointDelegate woDsPoint = getWoDsPointDelegate(pointMbo);
/*  96:138 */         if (!woDsPoint.isAllClear()) {
/*  97:139 */           return false;
/*  98:    */         }
/*  99:    */       }
/* 100:    */     }
/* 101:143 */     return true;
/* 102:    */   }
/* 103:    */   
/* 104:    */   public boolean hasCalPoints()
/* 105:    */     throws Exception
/* 106:    */   {
/* 107:148 */     return this.thisMbo.getBoolean("CALPOINT");
/* 108:    */   }
/* 109:    */   
/* 110:    */   public boolean hasFunctionChecks()
/* 111:    */     throws Exception
/* 112:    */   {
/* 113:152 */     return this.thisMbo.getBoolean("CALFUNCTION");
/* 114:    */   }
/* 115:    */   
/* 116:    */   public boolean hasDynamicChecks()
/* 117:    */     throws Exception
/* 118:    */   {
/* 119:156 */     return this.thisMbo.getBoolean("CALDYNAMIC");
/* 120:    */   }
/* 121:    */   
/* 122:    */   public boolean meetsNoAdjustmentConditions()
/* 123:    */     throws Exception
/* 124:    */   {
/* 125:161 */     String instrseq = this.thisMbo.getString("INSTRSEQ");
/* 126:    */     
/* 127:163 */     MboSetAdapter points = getWODsPointSet(false);
/* 128:    */     
/* 129:165 */     Iterator it = points.iterator();
/* 130:166 */     while (it.hasNext())
/* 131:    */     {
/* 132:167 */       MboAdapter pointMbo = (MboAdapter)it.next();
/* 133:168 */       PlusCWODsPointDelegate woDsPoint = getWoDsPointDelegate(pointMbo);
/* 134:171 */       if ((instrseq.equals(pointMbo.getString("INSTRSEQ"))) && (
/* 135:    */       
/* 136:    */ 
/* 137:    */ 
/* 138:175 */         (!isRepeatable()) || (pointMbo.getBoolean("ISAVERAGE"))))
/* 139:    */       {
/* 140:180 */         String adjchoice = getNoAdjChoice();
/* 141:182 */         if (!woDsPoint.meetsNoAdjustmentConditions(adjchoice)) {
/* 142:183 */           return false;
/* 143:    */         }
/* 144:    */       }
/* 145:    */     }
/* 146:187 */     return true;
/* 147:    */   }
/* 148:    */   
/* 149:    */   public String getNoAdjChoice()
/* 150:    */     throws Exception
/* 151:    */   {
/* 152:195 */     String adjchoice = "";
/* 153:196 */     if (this.thisMbo.getBoolean("NOADJMADECHOICE1")) {
/* 154:197 */       adjchoice = "ASFOUNDERROR1";
/* 155:198 */     } else if (this.thisMbo.getBoolean("NOADJMADECHOICE2")) {
/* 156:199 */       adjchoice = "ASFOUNDERROR2";
/* 157:200 */     } else if (this.thisMbo.getBoolean("NOADJMADECHOICE3")) {
/* 158:201 */       adjchoice = "ASFOUNDERROR3";
/* 159:202 */     } else if (this.thisMbo.getBoolean("NOADJMADECHOICE4")) {
/* 160:203 */       adjchoice = "ASFOUNDERROR4";
/* 161:    */     } else {
/* 162:210 */       throw this.thisMbo.newApplicationException("plusdsplan", "NoAdjMadeChoiceExists");
/* 163:    */     }
/* 164:212 */     return adjchoice;
/* 165:    */   }
/* 166:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     psdi.plusc.app.pluscds.pluscmobilecommon.PlusCWODsInstrDelegate
 * JD-Core Version:    0.7.0.1
 */