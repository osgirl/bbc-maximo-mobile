/*   1:    */ package psdi.plusc.app.pluscds.pluscmobilecommon;
/*   2:    */ 
/*   3:    */ import java.lang.reflect.Method;
/*   4:    */ import java.util.Date;
/*   5:    */ import java.util.HashMap;
/*   6:    */ import java.util.HashSet;
/*   7:    */ import java.util.Iterator;
/*   8:    */ import java.util.LinkedList;
/*   9:    */ import java.util.List;
/*  10:    */ import java.util.Locale;
/*  11:    */ import java.util.Map;
/*  12:    */ import java.util.Set;
/*  13:    */ 
/*  14:    */ public class PlusCDSPointTO
/*  15:    */   implements PlusCMboRemote
/*  16:    */ {
/*  17:    */   private static final long serialVersionUID = 1L;
/*  18: 42 */   private Set changedFields = new HashSet();
/*  19:    */   private String fieldName;
/*  20:    */   private Locale locale;
/*  21: 48 */   private Map mboData = new HashMap();
/*  22: 50 */   private Map validationFlags = new HashMap();
/*  23:    */   private PlusCDSTO plusCDSTO;
/*  24:    */   private PlusCDSInstrTO plusCDSInstrTO;
/*  25:    */   
/*  26:    */   public PlusCDSPointTO()
/*  27:    */   {
/*  28: 59 */     for (Iterator iter = getAttributeNames().iterator(); iter.hasNext();)
/*  29:    */     {
/*  30: 60 */       String element = (String)iter.next();
/*  31: 61 */       this.mboData.put(element, null);
/*  32:    */     }
/*  33:    */   }
/*  34:    */   
/*  35:    */   public Boolean getCALPOINT()
/*  36:    */   {
/*  37: 66 */     return getBoolean("CALPOINT");
/*  38:    */   }
/*  39:    */   
/*  40:    */   public void setCALPOINT(Boolean calpoint)
/*  41:    */   {
/*  42: 70 */     setValue("CALPOINT", calpoint, false);
/*  43:    */   }
/*  44:    */   
/*  45:    */   public Boolean getCALDYNAMIC()
/*  46:    */   {
/*  47: 74 */     return getBoolean("CALDYNAMIC");
/*  48:    */   }
/*  49:    */   
/*  50:    */   public void setCALDYNAMIC(Boolean calpoint)
/*  51:    */   {
/*  52: 78 */     setValue("CALDYNAMIC", calpoint, false);
/*  53:    */   }
/*  54:    */   
/*  55:    */   public Boolean getCALFUNCTION()
/*  56:    */   {
/*  57: 82 */     return getBoolean("CALFUNCTION");
/*  58:    */   }
/*  59:    */   
/*  60:    */   public void setCALFUNCTION(Boolean calpoint)
/*  61:    */   {
/*  62: 86 */     setValue("CALFUNCTION", calpoint, false);
/*  63:    */   }
/*  64:    */   
/*  65:    */   public void setValue(String key, Object object)
/*  66:    */   {
/*  67: 89 */     setValue(key, object, true);
/*  68:    */   }
/*  69:    */   
/*  70:    */   public void setValue(String keyName, Object object, boolean markField)
/*  71:    */   {
/*  72: 93 */     setValue(keyName, object, 0L, markField);
/*  73:    */   }
/*  74:    */   
/*  75:    */   public Boolean getBoolean(String key)
/*  76:    */   {
/*  77: 97 */     PlusCMboRemote suitable = getObjectOwner(key);
/*  78: 98 */     Object value = suitable.getObject(key);
/*  79: 99 */     return value == null ? new Boolean(false) : (Boolean)value;
/*  80:    */   }
/*  81:    */   
/*  82:    */   public Set getChangedFields()
/*  83:    */   {
/*  84:103 */     return this.changedFields;
/*  85:    */   }
/*  86:    */   
/*  87:    */   public Date getDate(String key)
/*  88:    */   {
/*  89:107 */     PlusCMboRemote suitable = getObjectOwner(key);
/*  90:108 */     return (Date)suitable.getObject(key);
/*  91:    */   }
/*  92:    */   
/*  93:    */   public String getDIRECTION()
/*  94:    */   {
/*  95:112 */     return getString("DIRECTION");
/*  96:    */   }
/*  97:    */   
/*  98:    */   public String getDSPLANNUM()
/*  99:    */   {
/* 100:116 */     return getString("DSPLANNUM");
/* 101:    */   }
/* 102:    */   
/* 103:    */   public Boolean getHASLD()
/* 104:    */   {
/* 105:120 */     return getBoolean("HASLD");
/* 106:    */   }
/* 107:    */   
/* 108:    */   public String getINPUTPERCENT()
/* 109:    */   {
/* 110:124 */     return getString("INPUTPERCENT");
/* 111:    */   }
/* 112:    */   
/* 113:    */   public String getINPUTVALUE()
/* 114:    */   {
/* 115:128 */     return getString("INPUTVALUE");
/* 116:    */   }
/* 117:    */   
/* 118:    */   public String getINPUTVALUE_NP()
/* 119:    */   {
/* 120:133 */     return getString("INPUTVALUE_NP");
/* 121:    */   }
/* 122:    */   
/* 123:    */   public String getINSTRCALRANGEEUA()
/* 124:    */   {
/* 125:138 */     return getString("INSTRCALRANGEEUA");
/* 126:    */   }
/* 127:    */   
/* 128:    */   public String getINSTRCALRANGEEUD()
/* 129:    */   {
/* 130:142 */     return getString("INSTRCALRANGEEUD");
/* 131:    */   }
/* 132:    */   
/* 133:    */   public String getINSTROUTRANGEEU()
/* 134:    */   {
/* 135:146 */     return getString("INSTROUTRANGEEU");
/* 136:    */   }
/* 137:    */   
/* 138:    */   public Integer getINSTRSEQ()
/* 139:    */   {
/* 140:150 */     return getInt("INSTRSEQ");
/* 141:    */   }
/* 142:    */   
/* 143:    */   public String getINSTRUMENTDESC()
/* 144:    */   {
/* 145:154 */     return getString("INSTRUMENTDESC");
/* 146:    */   }
/* 147:    */   
/* 148:    */   public Integer getINSTRUMENTFUNCTION()
/* 149:    */   {
/* 150:158 */     return getInt("INSTRUMENTFUNCTION");
/* 151:    */   }
/* 152:    */   
/* 153:    */   public Integer getInt(String key)
/* 154:    */   {
/* 155:162 */     PlusCMboRemote suitable = getObjectOwner(key);
/* 156:163 */     Object value = suitable.getObject(key);
/* 157:164 */     return value == null ? new Integer(0) : (Integer)value;
/* 158:    */   }
/* 159:    */   
/* 160:    */   public String getLANGCODE()
/* 161:    */   {
/* 162:168 */     return getString("LANGCODE");
/* 163:    */   }
/* 164:    */   
/* 165:    */   public Locale getLocale()
/* 166:    */   {
/* 167:172 */     return this.locale;
/* 168:    */   }
/* 169:    */   
/* 170:    */   public Long getLong(String key)
/* 171:    */   {
/* 172:176 */     PlusCMboRemote suitable = getObjectOwner(key);
/* 173:177 */     Object value = suitable.getObject(key);
/* 174:178 */     return value == null ? new Long(0L) : (Long)value;
/* 175:    */   }
/* 176:    */   
/* 177:    */   public Object getObject(String key)
/* 178:    */   {
/* 179:182 */     return this.mboData.get(key.toUpperCase());
/* 180:    */   }
/* 181:    */   
/* 182:    */   public String getORGID()
/* 183:    */   {
/* 184:186 */     return getString("ORGID");
/* 185:    */   }
/* 186:    */   
/* 187:    */   public String getOUTPUTVALUE()
/* 188:    */   {
/* 189:190 */     return getString("OUTPUTVALUE");
/* 190:    */   }
/* 191:    */   
/* 192:    */   public String getOUTPUTVALUE_NP()
/* 193:    */   {
/* 194:194 */     return getString("OUTPUTVALUE_NP");
/* 195:    */   }
/* 196:    */   
/* 197:    */   public String getOUTPUTVALUE_ROUNDING()
/* 198:    */   {
/* 199:198 */     return getString("OUTPUTVALUE_ROUNDING");
/* 200:    */   }
/* 201:    */   
/* 202:    */   public String getPLANTYPE()
/* 203:    */   {
/* 204:202 */     return getString("PLANTYPE");
/* 205:    */   }
/* 206:    */   
/* 207:    */   public PlusCDSInstrTO getPlusCDSInstrTO()
/* 208:    */   {
/* 209:206 */     return this.plusCDSInstrTO;
/* 210:    */   }
/* 211:    */   
/* 212:    */   public Integer getPLUSCDSPOINTID()
/* 213:    */   {
/* 214:210 */     return getInt("PLUSCDSPOINTID");
/* 215:    */   }
/* 216:    */   
/* 217:    */   public PlusCDSPointTO getPlusCDSPointTO()
/* 218:    */   {
/* 219:214 */     return this;
/* 220:    */   }
/* 221:    */   
/* 222:    */   public PlusCDSTO getPlusCDSTO()
/* 223:    */   {
/* 224:218 */     return this.plusCDSTO;
/* 225:    */   }
/* 226:    */   
/* 227:    */   public Integer getPOINT()
/* 228:    */   {
/* 229:222 */     return getInt("POINT");
/* 230:    */   }
/* 231:    */   
/* 232:    */   public String getPOINTDESCRIPTION()
/* 233:    */   {
/* 234:226 */     return getString("POINTDESCRIPTION");
/* 235:    */   }
/* 236:    */   
/* 237:    */   public String getPOINTDESCRIPTION_LONGDESCRIPTION()
/* 238:    */   {
/* 239:230 */     return getString("POINTDESCRIPTION_LONGDESCRIPTION");
/* 240:    */   }
/* 241:    */   
/* 242:    */   public Integer getREVISIONNUM()
/* 243:    */   {
/* 244:234 */     return getInt("REVISIONNUM");
/* 245:    */   }
/* 246:    */   
/* 247:    */   public String getRON1LOWER()
/* 248:    */   {
/* 249:238 */     return getString("RON1LOWER");
/* 250:    */   }
/* 251:    */   
/* 252:    */   public String getRON1LOWER_NP()
/* 253:    */   {
/* 254:242 */     return getString("RON1LOWER_NP");
/* 255:    */   }
/* 256:    */   
/* 257:    */   public String getRON1TYPE()
/* 258:    */   {
/* 259:246 */     return getString("RON1TYPE");
/* 260:    */   }
/* 261:    */   
/* 262:    */   public String getRON1UPPER()
/* 263:    */   {
/* 264:250 */     return getString("RON1UPPER");
/* 265:    */   }
/* 266:    */   
/* 267:    */   public String getRON1UPPER_NP()
/* 268:    */   {
/* 269:254 */     return getString("RON1UPPER_NP");
/* 270:    */   }
/* 271:    */   
/* 272:    */   public String getSETPOINTACTION()
/* 273:    */   {
/* 274:258 */     return getString("SETPOINTACTION");
/* 275:    */   }
/* 276:    */   
/* 277:    */   public String getSETPOINTVALUE()
/* 278:    */   {
/* 279:262 */     return getString("SETPOINTVALUE");
/* 280:    */   }
/* 281:    */   
/* 282:    */   public String getSITEID()
/* 283:    */   {
/* 284:266 */     return getString("SITEID");
/* 285:    */   }
/* 286:    */   
/* 287:    */   public String getString(String key)
/* 288:    */   {
/* 289:270 */     PlusCMboRemote suitable = getObjectOwner(key);
/* 290:271 */     Object value = suitable.getObject(key);
/* 291:272 */     return value == null ? "" : value.toString();
/* 292:    */   }
/* 293:    */   
/* 294:    */   public String getTOL1LOWER()
/* 295:    */   {
/* 296:276 */     return getString("TOL1LOWER");
/* 297:    */   }
/* 298:    */   
/* 299:    */   public String getTOL1LOWER_NP()
/* 300:    */   {
/* 301:280 */     return getString("TOL1LOWER_NP");
/* 302:    */   }
/* 303:    */   
/* 304:    */   public String getTOL1UPPER()
/* 305:    */   {
/* 306:284 */     return getString("TOL1UPPER");
/* 307:    */   }
/* 308:    */   
/* 309:    */   public String getTOL1UPPER_NP()
/* 310:    */   {
/* 311:288 */     return getString("TOL1UPPER_NP");
/* 312:    */   }
/* 313:    */   
/* 314:    */   public String getTOL2LOWER()
/* 315:    */   {
/* 316:292 */     return getString("TOL2LOWER");
/* 317:    */   }
/* 318:    */   
/* 319:    */   public String getTOL2LOWER_NP()
/* 320:    */   {
/* 321:296 */     return getString("TOL2LOWER_NP");
/* 322:    */   }
/* 323:    */   
/* 324:    */   public String getTOL2UPPER()
/* 325:    */   {
/* 326:300 */     return getString("TOL2UPPER");
/* 327:    */   }
/* 328:    */   
/* 329:    */   public String getTOL2UPPER_NP()
/* 330:    */   {
/* 331:304 */     return getString("TOL2UPPER_NP");
/* 332:    */   }
/* 333:    */   
/* 334:    */   public String getTOL3LOWER()
/* 335:    */   {
/* 336:308 */     return getString("TOL3LOWER");
/* 337:    */   }
/* 338:    */   
/* 339:    */   public String getTOL3LOWER_NP()
/* 340:    */   {
/* 341:312 */     return getString("TOL3LOWER_NP");
/* 342:    */   }
/* 343:    */   
/* 344:    */   public String getTOL3UPPER()
/* 345:    */   {
/* 346:316 */     return getString("TOL3UPPER");
/* 347:    */   }
/* 348:    */   
/* 349:    */   public String getTOL3UPPER_NP()
/* 350:    */   {
/* 351:320 */     return getString("TOL3UPPER_NP");
/* 352:    */   }
/* 353:    */   
/* 354:    */   public String getTOL4LOWER()
/* 355:    */   {
/* 356:324 */     return getString("TOL4LOWER");
/* 357:    */   }
/* 358:    */   
/* 359:    */   public String getTOL4LOWER_NP()
/* 360:    */   {
/* 361:328 */     return getString("TOL4LOWER_NP");
/* 362:    */   }
/* 363:    */   
/* 364:    */   public String getTOL4UPPER()
/* 365:    */   {
/* 366:332 */     return getString("TOL4UPPER");
/* 367:    */   }
/* 368:    */   
/* 369:    */   public String getTOL4UPPER_NP()
/* 370:    */   {
/* 371:336 */     return getString("TOL4UPPER_NP");
/* 372:    */   }
/* 373:    */   
/* 374:    */   public String getTOLERANCEEU()
/* 375:    */   {
/* 376:340 */     return getString("TOLERANCEEU");
/* 377:    */   }
/* 378:    */   
/* 379:    */   public boolean isNull(String key)
/* 380:    */   {
/* 381:344 */     Object value = null;
/* 382:345 */     if ((getPlusCDSInstrTO() != null) && (getPlusCDSInstrTO().containsAttribute(key)))
/* 383:    */     {
/* 384:346 */       value = getPlusCDSInstrTO().getObject(key);
/* 385:347 */       return (value == null) || (value.toString().trim().equals(""));
/* 386:    */     }
/* 387:349 */     if ((getPlusCDSPointTO() != null) && (getPlusCDSPointTO().containsAttribute(key)))
/* 388:    */     {
/* 389:350 */       value = getPlusCDSPointTO().getObject(key);
/* 390:351 */       return (value == null) || (value.toString().trim().equals(""));
/* 391:    */     }
/* 392:353 */     if ((getPlusCDSTO() != null) && (getPlusCDSTO().containsAttribute(key)))
/* 393:    */     {
/* 394:354 */       value = getPlusCDSTO().getObject(key);
/* 395:355 */       return (value == null) || (value.toString().trim().equals(""));
/* 396:    */     }
/* 397:357 */     return true;
/* 398:    */   }
/* 399:    */   
/* 400:    */   public boolean isRoundUpField()
/* 401:    */   {
/* 402:361 */     String fieldName = this.fieldName;
/* 403:362 */     return (fieldName != null) && (!fieldName.equalsIgnoreCase("INSTRCALRANGEFROM")) && (!fieldName.equalsIgnoreCase("INSTRCALRANGETO")) && (!fieldName.equalsIgnoreCase("INSTROUTRANGEFROM")) && (!fieldName.equalsIgnoreCase("INSTROUTRANGETO")) && (!fieldName.equalsIgnoreCase("RON1LOWERVALUE")) && (!fieldName.equalsIgnoreCase("RON1UPPERVALUE")) && (!fieldName.equalsIgnoreCase("TOL1LOWERVALUE")) && (!fieldName.equalsIgnoreCase("TOL1UPPERVALUE")) && (!fieldName.equalsIgnoreCase("TOL2LOWERVALUE")) && (!fieldName.equalsIgnoreCase("TOL2UPPERVALUE")) && (!fieldName.equalsIgnoreCase("TOL3LOWERVALUE")) && (!fieldName.equalsIgnoreCase("TOL3UPPERVALUE")) && (!fieldName.equalsIgnoreCase("TOL4LOWERVALUE")) && (!fieldName.equalsIgnoreCase("TOL4UPPERVALUE")) && (!fieldName.equalsIgnoreCase("TOL1SUMEU")) && (!fieldName.equalsIgnoreCase("TOL1SUMREAD")) && (!fieldName.equalsIgnoreCase("TOL1SUMSPAN")) && (!fieldName.equalsIgnoreCase("TOL1SUMURV")) && (!fieldName.equalsIgnoreCase("TOL2SUMEU")) && (!fieldName.equalsIgnoreCase("TOL2SUMREAD")) && (!fieldName.equalsIgnoreCase("TOL2SUMSPAN")) && (!fieldName.equalsIgnoreCase("TOL2SUMURV")) && (!fieldName.equalsIgnoreCase("TOL3SUMEU")) && (!fieldName.equalsIgnoreCase("TOL3SUMREAD")) && (!fieldName.equalsIgnoreCase("TOL3SUMSPAN")) && (!fieldName.equalsIgnoreCase("TOL3SUMURV")) && (!fieldName.equalsIgnoreCase("TOL4SUMEU")) && (!fieldName.equalsIgnoreCase("TOL4SUMREAD")) && (!fieldName.equalsIgnoreCase("TOL4SUMSPAN")) && (!fieldName.equalsIgnoreCase("TOL4SUMURV"));
/* 404:    */   }
/* 405:    */   
/* 406:    */   public void setDIRECTION(String direction)
/* 407:    */   {
/* 408:395 */     setValue("DIRECTION", direction, false);
/* 409:    */   }
/* 410:    */   
/* 411:    */   public void setDSPLANNUM(String dsplannum)
/* 412:    */   {
/* 413:399 */     setValue("DSPLANNUM", dsplannum, false);
/* 414:    */   }
/* 415:    */   
/* 416:    */   public void setFieldName(String name)
/* 417:    */   {
/* 418:403 */     this.fieldName = name;
/* 419:    */   }
/* 420:    */   
/* 421:    */   public void setHASLD(Boolean hasld)
/* 422:    */   {
/* 423:407 */     setValue("HASLD", hasld, false);
/* 424:    */   }
/* 425:    */   
/* 426:    */   public void setINPUTPERCENT(String inputpercent)
/* 427:    */   {
/* 428:411 */     setValue("INPUTPERCENT", inputpercent, false);
/* 429:    */   }
/* 430:    */   
/* 431:    */   public void setINPUTVALUE(String inputvalue)
/* 432:    */   {
/* 433:415 */     setValue("INPUTVALUE", inputvalue, false);
/* 434:    */   }
/* 435:    */   
/* 436:    */   public void setINPUTVALUE_NP(String inputvalue_np)
/* 437:    */   {
/* 438:419 */     setValue("INPUTVALUE_NP", inputvalue_np, false);
/* 439:    */   }
/* 440:    */   
/* 441:    */   public void setINSTRCALRANGEEUA(String instrcalrangeeua)
/* 442:    */   {
/* 443:423 */     setValue("INSTRCALRANGEEUA", instrcalrangeeua, false);
/* 444:    */   }
/* 445:    */   
/* 446:    */   public void setINSTRCALRANGEEUD(String instrcalrangeeud)
/* 447:    */   {
/* 448:427 */     setValue("INSTRCALRANGEEUD", instrcalrangeeud, false);
/* 449:    */   }
/* 450:    */   
/* 451:    */   public void setINSTROUTRANGEEU(String instroutrangeeu)
/* 452:    */   {
/* 453:431 */     setValue("INSTROUTRANGEEU", instroutrangeeu, false);
/* 454:    */   }
/* 455:    */   
/* 456:    */   public void setINSTRSEQ(Integer instrseq)
/* 457:    */   {
/* 458:435 */     setValue("INSTRSEQ", instrseq, false);
/* 459:    */   }
/* 460:    */   
/* 461:    */   public void setINSTRUMENTDESC(String instrumentdesc)
/* 462:    */   {
/* 463:439 */     setValue("INSTRUMENTDESC", instrumentdesc, false);
/* 464:    */   }
/* 465:    */   
/* 466:    */   public void setINSTRUMENTFUNCTION(Integer instrumentfunction)
/* 467:    */   {
/* 468:443 */     setValue("INSTRUMENTFUNCTION", instrumentfunction, false);
/* 469:    */   }
/* 470:    */   
/* 471:    */   public void setLANGCODE(String langcode)
/* 472:    */   {
/* 473:447 */     setValue("LANGCODE", langcode, false);
/* 474:    */   }
/* 475:    */   
/* 476:    */   public void setLocale(Locale locale)
/* 477:    */   {
/* 478:451 */     this.locale = locale;
/* 479:    */   }
/* 480:    */   
/* 481:    */   public void setORGID(String orgid)
/* 482:    */   {
/* 483:455 */     setValue("ORGID", orgid, false);
/* 484:    */   }
/* 485:    */   
/* 486:    */   public void setOUTPUTVALUE(String outputvalue)
/* 487:    */   {
/* 488:459 */     setValue("OUTPUTVALUE", outputvalue, false);
/* 489:    */   }
/* 490:    */   
/* 491:    */   public void setOUTPUTVALUE_NP(String outputvalue_np)
/* 492:    */   {
/* 493:463 */     setValue("OUTPUTVALUE_NP", outputvalue_np, false);
/* 494:    */   }
/* 495:    */   
/* 496:    */   public void setOUTPUTVALUE_ROUNDING(String outputvalue_rounding)
/* 497:    */   {
/* 498:467 */     setValue("OUTPUTVALUE_ROUNDING", outputvalue_rounding, false);
/* 499:    */   }
/* 500:    */   
/* 501:    */   public void setPLANTYPE(String plantype)
/* 502:    */   {
/* 503:471 */     setValue("PLANTYPE", plantype, false);
/* 504:    */   }
/* 505:    */   
/* 506:    */   public void setPLUSCDSPOINTID(Integer pluscdspointid)
/* 507:    */   {
/* 508:475 */     setValue("PLUSCDSPOINTID", pluscdspointid, false);
/* 509:    */   }
/* 510:    */   
/* 511:    */   public void setPOINT(Integer point)
/* 512:    */   {
/* 513:479 */     setValue("POINT", point, false);
/* 514:    */   }
/* 515:    */   
/* 516:    */   public void setPOINTDESCRIPTION(String pointdescription)
/* 517:    */   {
/* 518:483 */     setValue("POINTDESCRIPTION", pointdescription, false);
/* 519:    */   }
/* 520:    */   
/* 521:    */   public void setPOINTDESCRIPTION_LONGDESCRIPTION(String pointdescription_longdescription)
/* 522:    */   {
/* 523:488 */     setValue("POINTDESCRIPTION_LONGDESCRIPTION", pointdescription_longdescription, false);
/* 524:    */   }
/* 525:    */   
/* 526:    */   public void setREVISIONNUM(Integer revisionnum)
/* 527:    */   {
/* 528:493 */     setValue("REVISIONNUM", revisionnum, false);
/* 529:    */   }
/* 530:    */   
/* 531:    */   public void setRON1LOWER(String ron1lower)
/* 532:    */   {
/* 533:497 */     setValue("RON1LOWER", ron1lower, false);
/* 534:    */   }
/* 535:    */   
/* 536:    */   public void setRON1LOWER_NP(String ron1lower_np)
/* 537:    */   {
/* 538:501 */     setValue("RON1LOWER_NP", ron1lower_np, false);
/* 539:    */   }
/* 540:    */   
/* 541:    */   public void setRON1TYPE(String ron1type)
/* 542:    */   {
/* 543:505 */     setValue("RON1TYPE", ron1type, false);
/* 544:    */   }
/* 545:    */   
/* 546:    */   public void setRON1UPPER(String ron1upper)
/* 547:    */   {
/* 548:509 */     setValue("RON1UPPER", ron1upper, false);
/* 549:    */   }
/* 550:    */   
/* 551:    */   public void setRON1UPPER_NP(String ron1upper_np)
/* 552:    */   {
/* 553:513 */     setValue("RON1UPPER_NP", ron1upper_np, false);
/* 554:    */   }
/* 555:    */   
/* 556:    */   public void setSETPOINTACTION(String setpointaction)
/* 557:    */   {
/* 558:517 */     setValue("SETPOINTACTION", setpointaction, false);
/* 559:    */   }
/* 560:    */   
/* 561:    */   public void setSETPOINTVALUE(String setpointvalue)
/* 562:    */   {
/* 563:521 */     setValue("SETPOINTVALUE", setpointvalue, false);
/* 564:    */   }
/* 565:    */   
/* 566:    */   public void setSITEID(String siteid)
/* 567:    */   {
/* 568:525 */     setValue("SITEID", siteid, false);
/* 569:    */   }
/* 570:    */   
/* 571:    */   public void setTOL1LOWER(String tol1lower)
/* 572:    */   {
/* 573:529 */     setValue("TOL1LOWER", tol1lower, false);
/* 574:    */   }
/* 575:    */   
/* 576:    */   public void setTOL1LOWER_NP(String tol1lower_np)
/* 577:    */   {
/* 578:533 */     setValue("TOL1LOWER_NP", tol1lower_np, false);
/* 579:    */   }
/* 580:    */   
/* 581:    */   public void setTOL1UPPER(String tol1upper)
/* 582:    */   {
/* 583:537 */     setValue("TOL1UPPER", tol1upper, false);
/* 584:    */   }
/* 585:    */   
/* 586:    */   public void setTOL1UPPER_NP(String tol1upper_np)
/* 587:    */   {
/* 588:541 */     setValue("TOL1UPPER_NP", tol1upper_np, false);
/* 589:    */   }
/* 590:    */   
/* 591:    */   public void setTOL2LOWER(String tol2lower)
/* 592:    */   {
/* 593:545 */     setValue("TOL2LOWER", tol2lower, false);
/* 594:    */   }
/* 595:    */   
/* 596:    */   public void setTOL2LOWER_NP(String tol2lower_np)
/* 597:    */   {
/* 598:549 */     setValue("TOL2LOWER_NP", tol2lower_np, false);
/* 599:    */   }
/* 600:    */   
/* 601:    */   public void setTOL2UPPER(String tol2upper)
/* 602:    */   {
/* 603:553 */     setValue("TOL2UPPER", tol2upper, false);
/* 604:    */   }
/* 605:    */   
/* 606:    */   public void setTOL2UPPER_NP(String tol2upper_np)
/* 607:    */   {
/* 608:557 */     setValue("TOL2UPPER_NP", tol2upper_np, false);
/* 609:    */   }
/* 610:    */   
/* 611:    */   public void setTOL3LOWER(String tol3lower)
/* 612:    */   {
/* 613:561 */     setValue("TOL3LOWER", tol3lower, false);
/* 614:    */   }
/* 615:    */   
/* 616:    */   public void setTOL3LOWER_NP(String tol3lower_np)
/* 617:    */   {
/* 618:565 */     setValue("TOL3LOWER_NP", tol3lower_np, false);
/* 619:    */   }
/* 620:    */   
/* 621:    */   public void setTOL3UPPER(String tol3upper)
/* 622:    */   {
/* 623:569 */     setValue("TOL3UPPER", tol3upper, false);
/* 624:    */   }
/* 625:    */   
/* 626:    */   public void setTOL3UPPER_NP(String tol3upper_np)
/* 627:    */   {
/* 628:573 */     setValue("TOL3UPPER_NP", tol3upper_np, false);
/* 629:    */   }
/* 630:    */   
/* 631:    */   public void setTOL4LOWER(String tol4lower)
/* 632:    */   {
/* 633:577 */     setValue("TOL4LOWER", tol4lower, false);
/* 634:    */   }
/* 635:    */   
/* 636:    */   public void setTOL4LOWER_NP(String tol4lower_np)
/* 637:    */   {
/* 638:581 */     setValue("TOL4LOWER_NP", tol4lower_np, false);
/* 639:    */   }
/* 640:    */   
/* 641:    */   public void setTOL4UPPER(String tol4upper)
/* 642:    */   {
/* 643:585 */     setValue("TOL4UPPER", tol4upper, false);
/* 644:    */   }
/* 645:    */   
/* 646:    */   public void setTOL4UPPER_NP(String tol4upper_np)
/* 647:    */   {
/* 648:589 */     setValue("TOL4UPPER_NP", tol4upper_np, false);
/* 649:    */   }
/* 650:    */   
/* 651:    */   public void setTOLERANCEEU(String toleranceeu)
/* 652:    */   {
/* 653:593 */     setValue("TOLERANCEEU", toleranceeu, false);
/* 654:    */   }
/* 655:    */   
/* 656:    */   public void setPlusCDSTO(PlusCDSTO plusCDSTO)
/* 657:    */   {
/* 658:597 */     this.plusCDSTO = plusCDSTO;
/* 659:598 */     if (plusCDSTO.getPlusCDSPointTO() != this) {
/* 660:599 */       plusCDSTO.setPlusCDSPointTO(this);
/* 661:    */     }
/* 662:    */   }
/* 663:    */   
/* 664:    */   public void setPlusCDSInstTO(PlusCDSInstrTO plusCDSInstrTO)
/* 665:    */   {
/* 666:603 */     this.plusCDSInstrTO = plusCDSInstrTO;
/* 667:604 */     if (plusCDSInstrTO.getPlusCDSPointTO() != this) {
/* 668:605 */       plusCDSInstrTO.setPlusCDSPointTO(this);
/* 669:    */     }
/* 670:    */   }
/* 671:    */   
/* 672:    */   public void setPlusCDSPointTO(PlusCDSPointTO plusCDSPointTO)
/* 673:    */   {
/* 674:609 */     throw new UnsupportedOperationException("In this class this method is not implemented.");
/* 675:    */   }
/* 676:    */   
/* 677:    */   protected boolean containsAttribute(String attributeName)
/* 678:    */   {
/* 679:614 */     return this.mboData.containsKey(attributeName.toUpperCase());
/* 680:    */   }
/* 681:    */   
/* 682:    */   private PlusCMboRemote getObjectOwner(String attributeName)
/* 683:    */   {
/* 684:618 */     if (getPlusCDSInstrTO().containsAttribute(attributeName)) {
/* 685:619 */       return getPlusCDSInstrTO();
/* 686:    */     }
/* 687:622 */     if (getPlusCDSPointTO().containsAttribute(attributeName)) {
/* 688:623 */       return getPlusCDSPointTO();
/* 689:    */     }
/* 690:626 */     if (getPlusCDSTO().containsAttribute(attributeName)) {
/* 691:627 */       return getPlusCDSTO();
/* 692:    */     }
/* 693:630 */     throw new RuntimeException("Neither of suitable classes have the attribute " + attributeName);
/* 694:    */   }
/* 695:    */   
/* 696:    */   private static List getAttributeNames()
/* 697:    */   {
/* 698:634 */     List list = new LinkedList();
/* 699:635 */     Method[] methods = PlusCDSPointTO.class.getMethods();
/* 700:636 */     for (int i = 0; i < methods.length; i++) {
/* 701:637 */       if (methods[i].getName().indexOf("set") == 0) {
/* 702:638 */         list.add(methods[i].getName().substring(3).toUpperCase());
/* 703:    */       }
/* 704:    */     }
/* 705:641 */     return list;
/* 706:    */   }
/* 707:    */   
/* 708:    */   public void clearAllChangedFieldsSets()
/* 709:    */   {
/* 710:645 */     if (getPlusCDSInstrTO() != null) {
/* 711:646 */       getPlusCDSInstrTO().getChangedFields().clear();
/* 712:    */     }
/* 713:648 */     if (getPlusCDSTO() != null) {
/* 714:649 */       getPlusCDSTO().getChangedFields().clear();
/* 715:    */     }
/* 716:651 */     if (getPlusCDSPointTO() != null) {
/* 717:652 */       getPlusCDSPointTO().getChangedFields().clear();
/* 718:    */     }
/* 719:    */   }
/* 720:    */   
/* 721:    */   public void setPlusCWODSTO(PlusCWODSTO plusCWODSTO)
/* 722:    */   {
/* 723:657 */     throw new UnsupportedOperationException("In this class this method is not implemented.");
/* 724:    */   }
/* 725:    */   
/* 726:    */   public PlusCWODSTO getPlusCWODSTO()
/* 727:    */   {
/* 728:661 */     throw new UnsupportedOperationException("In this class this method is not implemented.");
/* 729:    */   }
/* 730:    */   
/* 731:    */   public void setPlusCWODSInstrTO(PlusCWODSInstrTO plusCWODSInstrTO)
/* 732:    */   {
/* 733:664 */     throw new UnsupportedOperationException("In this class this method is not implemented.");
/* 734:    */   }
/* 735:    */   
/* 736:    */   public PlusCWODSInstrTO getPlusCWODSInstrTO()
/* 737:    */   {
/* 738:668 */     throw new UnsupportedOperationException("In this class this method is not implemented.");
/* 739:    */   }
/* 740:    */   
/* 741:    */   public void setPlusCWODSPointTO(PlusCWODSPointTO plusCWODSPointTO)
/* 742:    */   {
/* 743:671 */     throw new UnsupportedOperationException("In this class this method is not implemented.");
/* 744:    */   }
/* 745:    */   
/* 746:    */   public PlusCWODSPointTO getPlusCWODSPointTO()
/* 747:    */   {
/* 748:675 */     throw new UnsupportedOperationException("In this class this method is not implemented.");
/* 749:    */   }
/* 750:    */   
/* 751:    */   public void setValue(String key, Object object, long validationFlag)
/* 752:    */   {
/* 753:679 */     setValue(key, object, validationFlag, true);
/* 754:    */   }
/* 755:    */   
/* 756:    */   public void setValue(String keyName, Object object, long validationFlag, boolean markField)
/* 757:    */   {
/* 758:684 */     if (containsAttribute(keyName))
/* 759:    */     {
/* 760:685 */       if (markField)
/* 761:    */       {
/* 762:686 */         this.changedFields.add(keyName.toUpperCase());
/* 763:687 */         this.validationFlags.put(keyName.toUpperCase(), new Long(validationFlag));
/* 764:    */       }
/* 765:    */       else
/* 766:    */       {
/* 767:689 */         this.validationFlags.remove(keyName.toUpperCase());
/* 768:    */       }
/* 769:691 */       this.mboData.put(keyName.toUpperCase(), object);
/* 770:    */     }
/* 771:693 */     else if ((this.plusCDSInstrTO != null) && (getPlusCDSInstrTO().containsAttribute(keyName)))
/* 772:    */     {
/* 773:694 */       getPlusCDSInstrTO().setValue(keyName, object, validationFlag, markField);
/* 774:    */     }
/* 775:695 */     else if ((this.plusCDSTO != null) && (getPlusCDSTO().containsAttribute(keyName)))
/* 776:    */     {
/* 777:696 */       getPlusCDSTO().setValue(keyName, object, validationFlag, markField);
/* 778:    */     }
/* 779:    */     else
/* 780:    */     {
/* 781:698 */       throw new RuntimeException("No suitable class to set " + keyName + " attribute");
/* 782:    */     }
/* 783:    */   }
/* 784:    */   
/* 785:    */   public long getValidationFlag(String key)
/* 786:    */   {
/* 787:704 */     String keyUpper = key.toUpperCase();
/* 788:705 */     PlusCMboRemote suitable = getObjectOwner(keyUpper);
/* 789:706 */     long value = 0L;
/* 790:707 */     if (suitable == this)
/* 791:    */     {
/* 792:708 */       Object o = this.validationFlags.get(keyUpper);
/* 793:709 */       value = o != null ? new Long(o.toString()).longValue() : 11L;
/* 794:    */     }
/* 795:    */     else
/* 796:    */     {
/* 797:711 */       suitable.getValidationFlag(key);
/* 798:    */     }
/* 799:713 */     return value;
/* 800:    */   }
/* 801:    */   
/* 802:    */   public Set getNonPersistentFieldsName()
/* 803:    */   {
/* 804:720 */     throw new UnsupportedOperationException("In this class this method is not implemented.");
/* 805:    */   }
/* 806:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     psdi.plusc.app.pluscds.pluscmobilecommon.PlusCDSPointTO
 * JD-Core Version:    0.7.0.1
 */