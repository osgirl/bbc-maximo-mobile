/*    1:     */ package psdi.plusc.app.pluscds.pluscmobilecommon;
/*    2:     */ 
/*    3:     */ import java.lang.reflect.Method;
/*    4:     */ import java.util.Date;
/*    5:     */ import java.util.HashMap;
/*    6:     */ import java.util.HashSet;
/*    7:     */ import java.util.Iterator;
/*    8:     */ import java.util.LinkedList;
/*    9:     */ import java.util.List;
/*   10:     */ import java.util.Locale;
/*   11:     */ import java.util.Map;
/*   12:     */ import java.util.Set;
/*   13:     */ 
/*   14:     */ public class PlusCDSInstrTO
/*   15:     */   implements PlusCMboRemote
/*   16:     */ {
/*   17:     */   private static final long serialVersionUID = 1L;
/*   18:     */   private Locale locale;
/*   19:     */   private String fieldName;
/*   20:  48 */   private Set changedFields = new HashSet();
/*   21:  50 */   private Map validationFlags = new HashMap();
/*   22:  52 */   private Map mboData = new HashMap();
/*   23:     */   private PlusCDSPointTO plusCDSPointTO;
/*   24:     */   private PlusCDSTO plusCDSTO;
/*   25:     */   
/*   26:     */   public PlusCDSInstrTO()
/*   27:     */   {
/*   28:  60 */     for (Iterator iter = getAttributeNames().iterator(); iter.hasNext();)
/*   29:     */     {
/*   30:  61 */       String element = (String)iter.next();
/*   31:  62 */       this.mboData.put(element, null);
/*   32:     */     }
/*   33:     */   }
/*   34:     */   
/*   35:     */   public Boolean getCALPOINT()
/*   36:     */   {
/*   37:  67 */     return getBoolean("CALPOINT");
/*   38:     */   }
/*   39:     */   
/*   40:     */   public void setCALPOINT(Boolean calpoint)
/*   41:     */   {
/*   42:  71 */     setValue("CALPOINT", calpoint, false);
/*   43:     */   }
/*   44:     */   
/*   45:     */   public Boolean getCALDYNAMIC()
/*   46:     */   {
/*   47:  75 */     return getBoolean("CALDYNAMIC");
/*   48:     */   }
/*   49:     */   
/*   50:     */   public void setCALDYNAMIC(Boolean calpoint)
/*   51:     */   {
/*   52:  79 */     setValue("CALDYNAMIC", calpoint, false);
/*   53:     */   }
/*   54:     */   
/*   55:     */   public Boolean getCALFUNCTION()
/*   56:     */   {
/*   57:  83 */     return getBoolean("CALFUNCTION");
/*   58:     */   }
/*   59:     */   
/*   60:     */   public void setCALFUNCTION(Boolean calpoint)
/*   61:     */   {
/*   62:  87 */     setValue("CALFUNCTION", calpoint, false);
/*   63:     */   }
/*   64:     */   
/*   65:     */   public Boolean getMANUAL()
/*   66:     */   {
/*   67:  91 */     return getBoolean("MANUAL");
/*   68:     */   }
/*   69:     */   
/*   70:     */   public void setMANUAL(Boolean calpoint)
/*   71:     */   {
/*   72:  95 */     setValue("MANUAL", calpoint, false);
/*   73:     */   }
/*   74:     */   
/*   75:     */   public Boolean getNONLINEAR()
/*   76:     */   {
/*   77:  99 */     return getBoolean("NONLINEAR");
/*   78:     */   }
/*   79:     */   
/*   80:     */   public void setNONLINEAR(Boolean calpoint)
/*   81:     */   {
/*   82: 103 */     setValue("NONLINEAR", calpoint, false);
/*   83:     */   }
/*   84:     */   
/*   85:     */   public Boolean getREPEATABLE()
/*   86:     */   {
/*   87: 107 */     return getBoolean("REPEATABLE");
/*   88:     */   }
/*   89:     */   
/*   90:     */   public void setREPEATABLE(Boolean calpoint)
/*   91:     */   {
/*   92: 111 */     setValue("REPEATABLE", calpoint, false);
/*   93:     */   }
/*   94:     */   
/*   95:     */   public Boolean getCLIPLIMITSIN()
/*   96:     */   {
/*   97: 115 */     return getBoolean("CLIPLIMITSIN");
/*   98:     */   }
/*   99:     */   
/*  100:     */   public void setCLIPLIMITSIN(Boolean calpoint)
/*  101:     */   {
/*  102: 119 */     setValue("CLIPLIMITSIN", calpoint, false);
/*  103:     */   }
/*  104:     */   
/*  105:     */   public void setFieldName(String name)
/*  106:     */   {
/*  107: 125 */     this.fieldName = name;
/*  108:     */   }
/*  109:     */   
/*  110:     */   public void setValue(String key, Object object)
/*  111:     */   {
/*  112: 129 */     setValue(key, object, true);
/*  113:     */   }
/*  114:     */   
/*  115:     */   public Boolean getALLOWPOINTINSERTS()
/*  116:     */   {
/*  117: 133 */     return getBoolean("ALLOWPOINTINSERTS");
/*  118:     */   }
/*  119:     */   
/*  120:     */   public Integer getASSETFUNCTION()
/*  121:     */   {
/*  122: 137 */     return getInt("ASSETFUNCTION");
/*  123:     */   }
/*  124:     */   
/*  125:     */   public Boolean getBoolean(String key)
/*  126:     */   {
/*  127: 141 */     PlusCMboRemote suitable = getObjectOwner(key);
/*  128: 142 */     Object value = suitable.getObject(key);
/*  129: 143 */     return value == null ? new Boolean(false) : (Boolean)value;
/*  130:     */   }
/*  131:     */   
/*  132:     */   public Boolean getCLIPLIMITS()
/*  133:     */   {
/*  134: 147 */     return getBoolean("CLIPLIMITS");
/*  135:     */   }
/*  136:     */   
/*  137:     */   public Date getDate(String key)
/*  138:     */   {
/*  139: 151 */     PlusCMboRemote suitable = getObjectOwner(key);
/*  140: 152 */     return (Date)suitable.getObject(key);
/*  141:     */   }
/*  142:     */   
/*  143:     */   public String getDESCRIPTION()
/*  144:     */   {
/*  145: 156 */     return getString("DESCRIPTION");
/*  146:     */   }
/*  147:     */   
/*  148:     */   public String getDESCRIPTION_LONGDESCRIPTION()
/*  149:     */   {
/*  150: 160 */     return getString("DESCRIPTION_LONGDESCRIPTION");
/*  151:     */   }
/*  152:     */   
/*  153:     */   public String getDSPLANNUM()
/*  154:     */   {
/*  155: 164 */     return getString("DSPLANNUM");
/*  156:     */   }
/*  157:     */   
/*  158:     */   public Boolean getHASLD()
/*  159:     */   {
/*  160: 168 */     return getBoolean("HASLD");
/*  161:     */   }
/*  162:     */   
/*  163:     */   public Boolean getINPUTRANGE()
/*  164:     */   {
/*  165: 172 */     return getBoolean("INPUTRANGE");
/*  166:     */   }
/*  167:     */   
/*  168:     */   public String getINSTRCALRANGEEU()
/*  169:     */   {
/*  170: 176 */     return getString("INSTRCALRANGEEU");
/*  171:     */   }
/*  172:     */   
/*  173:     */   public String getINSTRCALRANGEFROM()
/*  174:     */   {
/*  175: 180 */     return getString("INSTRCALRANGEFROM");
/*  176:     */   }
/*  177:     */   
/*  178:     */   public String getINSTRCALRANGEFROM_NP()
/*  179:     */   {
/*  180: 184 */     return getString("INSTRCALRANGEFROM_NP");
/*  181:     */   }
/*  182:     */   
/*  183:     */   public String getINSTRCALRANGETO()
/*  184:     */   {
/*  185: 188 */     return getString("INSTRCALRANGETO");
/*  186:     */   }
/*  187:     */   
/*  188:     */   public String getINSTRCALRANGETO_NP()
/*  189:     */   {
/*  190: 192 */     return getString("INSTRCALRANGETO_NP");
/*  191:     */   }
/*  192:     */   
/*  193:     */   public String getINSTROUTRANGEEU()
/*  194:     */   {
/*  195: 196 */     return getString("INSTROUTRANGEEU");
/*  196:     */   }
/*  197:     */   
/*  198:     */   public String getINSTROUTRANGEFROM()
/*  199:     */   {
/*  200: 200 */     return getString("INSTROUTRANGEFROM");
/*  201:     */   }
/*  202:     */   
/*  203:     */   public String getINSTROUTRANGEFROM_NP()
/*  204:     */   {
/*  205: 204 */     return getString("INSTROUTRANGEFROM_NP");
/*  206:     */   }
/*  207:     */   
/*  208:     */   public String getINSTROUTRANGETO()
/*  209:     */   {
/*  210: 208 */     return getString("INSTROUTRANGETO");
/*  211:     */   }
/*  212:     */   
/*  213:     */   public String getINSTROUTRANGETO_NP()
/*  214:     */   {
/*  215: 212 */     return getString("INSTROUTRANGETO_NP");
/*  216:     */   }
/*  217:     */   
/*  218:     */   public Integer getINSTRSEQ()
/*  219:     */   {
/*  220: 216 */     return getInt("INSTRSEQ");
/*  221:     */   }
/*  222:     */   
/*  223:     */   public Integer getINPUTPRECISION()
/*  224:     */   {
/*  225: 220 */     return getInt("INPUTPRECISION");
/*  226:     */   }
/*  227:     */   
/*  228:     */   public Integer getOUTPUTPRECISION()
/*  229:     */   {
/*  230: 224 */     return getInt("OUTPUTPRECISION");
/*  231:     */   }
/*  232:     */   
/*  233:     */   public Integer getInt(String key)
/*  234:     */   {
/*  235: 229 */     PlusCMboRemote suitable = getObjectOwner(key);
/*  236: 230 */     Object value = suitable.getObject(key);
/*  237: 231 */     return value == null ? new Integer(0) : (Integer)value;
/*  238:     */   }
/*  239:     */   
/*  240:     */   public String getLANGCODE()
/*  241:     */   {
/*  242: 235 */     return getString("LANGCODE");
/*  243:     */   }
/*  244:     */   
/*  245:     */   public Locale getLocale()
/*  246:     */   {
/*  247: 239 */     return this.locale;
/*  248:     */   }
/*  249:     */   
/*  250:     */   public Long getLong(String key)
/*  251:     */   {
/*  252: 243 */     PlusCMboRemote suitable = getObjectOwner(key);
/*  253: 244 */     Object value = suitable.getObject(key);
/*  254: 245 */     return value == null ? new Long(0L) : (Long)value;
/*  255:     */   }
/*  256:     */   
/*  257:     */   public Boolean getNOADJMADECHOICE()
/*  258:     */   {
/*  259: 249 */     return getBoolean("NOADJMADECHOICE");
/*  260:     */   }
/*  261:     */   
/*  262:     */   public Boolean getNOADJMADECHOICE1()
/*  263:     */   {
/*  264: 253 */     return getBoolean("NOADJMADECHOICE1");
/*  265:     */   }
/*  266:     */   
/*  267:     */   public Boolean getNOADJMADECHOICE2()
/*  268:     */   {
/*  269: 257 */     return getBoolean("NOADJMADECHOICE2");
/*  270:     */   }
/*  271:     */   
/*  272:     */   public Boolean getNOADJMADECHOICE3()
/*  273:     */   {
/*  274: 261 */     return getBoolean("NOADJMADECHOICE3");
/*  275:     */   }
/*  276:     */   
/*  277:     */   public Boolean getNOADJMADECHOICE4()
/*  278:     */   {
/*  279: 265 */     return getBoolean("NOADJMADECHOICE4");
/*  280:     */   }
/*  281:     */   
/*  282:     */   public Object getObject(String key)
/*  283:     */   {
/*  284: 269 */     return this.mboData.get(key.toUpperCase());
/*  285:     */   }
/*  286:     */   
/*  287:     */   public String getORGID()
/*  288:     */   {
/*  289: 273 */     return getString("ORGID");
/*  290:     */   }
/*  291:     */   
/*  292:     */   public Boolean getOUTPUTRANGE()
/*  293:     */   {
/*  294: 277 */     return getBoolean("OUTPUTRANGE");
/*  295:     */   }
/*  296:     */   
/*  297:     */   public String getPLANTYPE()
/*  298:     */   {
/*  299: 281 */     return getString("PLANTYPE");
/*  300:     */   }
/*  301:     */   
/*  302:     */   public Integer getPLUSCDSINSTRID()
/*  303:     */   {
/*  304: 285 */     return getInt("PLUSCDSINSTRID");
/*  305:     */   }
/*  306:     */   
/*  307:     */   public PlusCDSInstrTO getPlusCDSInstrTO()
/*  308:     */   {
/*  309: 289 */     return this;
/*  310:     */   }
/*  311:     */   
/*  312:     */   public PlusCDSPointTO getPlusCDSPointTO()
/*  313:     */   {
/*  314: 293 */     return this.plusCDSPointTO;
/*  315:     */   }
/*  316:     */   
/*  317:     */   public PlusCDSTO getPlusCDSTO()
/*  318:     */   {
/*  319: 297 */     return this.plusCDSTO;
/*  320:     */   }
/*  321:     */   
/*  322:     */   public String getPROCESSEU()
/*  323:     */   {
/*  324: 301 */     return getString("PROCESSEU");
/*  325:     */   }
/*  326:     */   
/*  327:     */   public String getPROCESSEUFACTOR()
/*  328:     */   {
/*  329: 305 */     return getString("PROCESSEUFACTOR");
/*  330:     */   }
/*  331:     */   
/*  332:     */   public String getPROCESSEUFACTOR_NP()
/*  333:     */   {
/*  334: 309 */     return getString("PROCESSEUFACTOR_NP");
/*  335:     */   }
/*  336:     */   
/*  337:     */   public Integer getREVISIONNUM()
/*  338:     */   {
/*  339: 313 */     return getInt("REVISIONNUM");
/*  340:     */   }
/*  341:     */   
/*  342:     */   public String getRON1LOWERVALUE()
/*  343:     */   {
/*  344: 317 */     return getString("RON1LOWERVALUE");
/*  345:     */   }
/*  346:     */   
/*  347:     */   public String getRON1LOWERVALUE_NP()
/*  348:     */   {
/*  349: 321 */     return getString("RON1LOWERVALUE_NP");
/*  350:     */   }
/*  351:     */   
/*  352:     */   public String getRON1TYPE()
/*  353:     */   {
/*  354: 325 */     return getString("RON1TYPE");
/*  355:     */   }
/*  356:     */   
/*  357:     */   public String getRON1UPPERVALUE()
/*  358:     */   {
/*  359: 329 */     return getString("RON1UPPERVALUE");
/*  360:     */   }
/*  361:     */   
/*  362:     */   public String getRON1UPPERVALUE_NP()
/*  363:     */   {
/*  364: 333 */     return getString("RON1UPPERVALUE_NP");
/*  365:     */   }
/*  366:     */   
/*  367:     */   public String getSITEID()
/*  368:     */   {
/*  369: 337 */     return getString("SITEID");
/*  370:     */   }
/*  371:     */   
/*  372:     */   public Boolean getSQUAREROOT()
/*  373:     */   {
/*  374: 341 */     return getBoolean("SQUAREROOT");
/*  375:     */   }
/*  376:     */   
/*  377:     */   public Boolean getSQUARED()
/*  378:     */   {
/*  379: 345 */     return getBoolean("SQUARED");
/*  380:     */   }
/*  381:     */   
/*  382:     */   public String getString(String key)
/*  383:     */   {
/*  384: 349 */     PlusCMboRemote suitable = getObjectOwner(key);
/*  385: 350 */     Object value = suitable.getObject(key);
/*  386: 351 */     return value == null ? "" : value.toString();
/*  387:     */   }
/*  388:     */   
/*  389:     */   public String getTOL1DESCRIPTION()
/*  390:     */   {
/*  391: 355 */     return getString("TOL1DESCRIPTION");
/*  392:     */   }
/*  393:     */   
/*  394:     */   public String getTOL1LOWERVALUE()
/*  395:     */   {
/*  396: 359 */     return getString("TOL1LOWERVALUE");
/*  397:     */   }
/*  398:     */   
/*  399:     */   public String getTOL1LOWERVALUE_NP()
/*  400:     */   {
/*  401: 363 */     return getString("TOL1LOWERVALUE_NP");
/*  402:     */   }
/*  403:     */   
/*  404:     */   public Boolean getTOL1NOADJLIMIT()
/*  405:     */   {
/*  406: 367 */     return getBoolean("TOL1NOADJLIMIT");
/*  407:     */   }
/*  408:     */   
/*  409:     */   public String getTOL1STATUS()
/*  410:     */   {
/*  411: 371 */     return getString("TOL1STATUS");
/*  412:     */   }
/*  413:     */   
/*  414:     */   public String getTOL1SUMDIRECTION()
/*  415:     */   {
/*  416: 375 */     return getString("TOL1SUMDIRECTION");
/*  417:     */   }
/*  418:     */   
/*  419:     */   public String getTOL1SUMEU()
/*  420:     */   {
/*  421: 379 */     return getString("TOL1SUMEU");
/*  422:     */   }
/*  423:     */   
/*  424:     */   public String getTOL1SUMEU_NP()
/*  425:     */   {
/*  426: 383 */     return getString("TOL1SUMEU_NP");
/*  427:     */   }
/*  428:     */   
/*  429:     */   public String getTOL1SUMREAD()
/*  430:     */   {
/*  431: 387 */     return getString("TOL1SUMREAD");
/*  432:     */   }
/*  433:     */   
/*  434:     */   public String getTOL1SUMREAD_NP()
/*  435:     */   {
/*  436: 391 */     return getString("TOL1SUMREAD_NP");
/*  437:     */   }
/*  438:     */   
/*  439:     */   public String getTOL1SUMSPAN()
/*  440:     */   {
/*  441: 395 */     return getString("TOL1SUMSPAN");
/*  442:     */   }
/*  443:     */   
/*  444:     */   public String getTOL1SUMSPAN_NP()
/*  445:     */   {
/*  446: 399 */     return getString("TOL1SUMSPAN_NP");
/*  447:     */   }
/*  448:     */   
/*  449:     */   public String getTOL1SUMURV()
/*  450:     */   {
/*  451: 403 */     return getString("TOL1SUMURV");
/*  452:     */   }
/*  453:     */   
/*  454:     */   public String getTOL1SUMURV_NP()
/*  455:     */   {
/*  456: 407 */     return getString("TOL1SUMURV_NP");
/*  457:     */   }
/*  458:     */   
/*  459:     */   public String getTOL1TYPE()
/*  460:     */   {
/*  461: 411 */     return getString("TOL1TYPE");
/*  462:     */   }
/*  463:     */   
/*  464:     */   public String getTOL1UPPERVALUE()
/*  465:     */   {
/*  466: 415 */     return getString("TOL1UPPERVALUE");
/*  467:     */   }
/*  468:     */   
/*  469:     */   public String getTOL1UPPERVALUE_NP()
/*  470:     */   {
/*  471: 419 */     return getString("TOL1UPPERVALUE_NP");
/*  472:     */   }
/*  473:     */   
/*  474:     */   public String getTOL2DESCRIPTION()
/*  475:     */   {
/*  476: 423 */     return getString("TOL2DESCRIPTION");
/*  477:     */   }
/*  478:     */   
/*  479:     */   public String getTOL2LOWERVALUE()
/*  480:     */   {
/*  481: 427 */     return getString("TOL2LOWERVALUE");
/*  482:     */   }
/*  483:     */   
/*  484:     */   public String getTOL2LOWERVALUE_NP()
/*  485:     */   {
/*  486: 431 */     return getString("TOL2LOWERVALUE_NP");
/*  487:     */   }
/*  488:     */   
/*  489:     */   public Boolean getTOL2NOADJLIMIT()
/*  490:     */   {
/*  491: 435 */     return getBoolean("TOL2NOADJLIMIT");
/*  492:     */   }
/*  493:     */   
/*  494:     */   public String getTOL2STATUS()
/*  495:     */   {
/*  496: 439 */     return getString("TOL2STATUS");
/*  497:     */   }
/*  498:     */   
/*  499:     */   public String getTOL2SUMDIRECTION()
/*  500:     */   {
/*  501: 443 */     return getString("TOL2SUMDIRECTION");
/*  502:     */   }
/*  503:     */   
/*  504:     */   public String getTOL2SUMEU()
/*  505:     */   {
/*  506: 447 */     return getString("TOL2SUMEU");
/*  507:     */   }
/*  508:     */   
/*  509:     */   public String getTOL2SUMEU_NP()
/*  510:     */   {
/*  511: 451 */     return getString("TOL2SUMEU_NP");
/*  512:     */   }
/*  513:     */   
/*  514:     */   public String getTOL2SUMREAD()
/*  515:     */   {
/*  516: 455 */     return getString("TOL2SUMREAD");
/*  517:     */   }
/*  518:     */   
/*  519:     */   public String getTOL2SUMREAD_NP()
/*  520:     */   {
/*  521: 459 */     return getString("TOL2SUMREAD_NP");
/*  522:     */   }
/*  523:     */   
/*  524:     */   public String getTOL2SUMSPAN()
/*  525:     */   {
/*  526: 463 */     return getString("TOL2SUMSPAN");
/*  527:     */   }
/*  528:     */   
/*  529:     */   public String getTOL2SUMSPAN_NP()
/*  530:     */   {
/*  531: 467 */     return getString("TOL2SUMSPAN_NP");
/*  532:     */   }
/*  533:     */   
/*  534:     */   public String getTOL2SUMURV()
/*  535:     */   {
/*  536: 471 */     return getString("TOL2SUMURV");
/*  537:     */   }
/*  538:     */   
/*  539:     */   public String getTOL2SUMURV_NP()
/*  540:     */   {
/*  541: 475 */     return getString("TOL2SUMURV_NP");
/*  542:     */   }
/*  543:     */   
/*  544:     */   public String getTOL2TYPE()
/*  545:     */   {
/*  546: 479 */     return getString("TOL2TYPE");
/*  547:     */   }
/*  548:     */   
/*  549:     */   public String getTOL2UPPERVALUE()
/*  550:     */   {
/*  551: 483 */     return getString("TOL2UPPERVALUE");
/*  552:     */   }
/*  553:     */   
/*  554:     */   public String getTOL2UPPERVALUE_NP()
/*  555:     */   {
/*  556: 487 */     return getString("TOL2UPPERVALUE_NP");
/*  557:     */   }
/*  558:     */   
/*  559:     */   public String getTOL3DESCRIPTION()
/*  560:     */   {
/*  561: 491 */     return getString("TOL3DESCRIPTION");
/*  562:     */   }
/*  563:     */   
/*  564:     */   public String getTOL3LOWERVALUE()
/*  565:     */   {
/*  566: 495 */     return getString("TOL3LOWERVALUE");
/*  567:     */   }
/*  568:     */   
/*  569:     */   public String getTOL3LOWERVALUE_NP()
/*  570:     */   {
/*  571: 499 */     return getString("TOL3LOWERVALUE_NP");
/*  572:     */   }
/*  573:     */   
/*  574:     */   public Boolean getTOL3NOADJLIMIT()
/*  575:     */   {
/*  576: 503 */     return getBoolean("TOL3NOADJLIMIT");
/*  577:     */   }
/*  578:     */   
/*  579:     */   public String getTOL3STATUS()
/*  580:     */   {
/*  581: 507 */     return getString("TOL3STATUS");
/*  582:     */   }
/*  583:     */   
/*  584:     */   public String getTOL3SUMDIRECTION()
/*  585:     */   {
/*  586: 511 */     return getString("TOL3SUMDIRECTION");
/*  587:     */   }
/*  588:     */   
/*  589:     */   public String getTOL3SUMEU()
/*  590:     */   {
/*  591: 515 */     return getString("TOL3SUMEU");
/*  592:     */   }
/*  593:     */   
/*  594:     */   public String getTOL3SUMEU_NP()
/*  595:     */   {
/*  596: 519 */     return getString("TOL3SUMEU_NP");
/*  597:     */   }
/*  598:     */   
/*  599:     */   public String getTOL3SUMREAD()
/*  600:     */   {
/*  601: 523 */     return getString("TOL3SUMREAD");
/*  602:     */   }
/*  603:     */   
/*  604:     */   public String getTOL3SUMREAD_NP()
/*  605:     */   {
/*  606: 527 */     return getString("TOL3SUMREAD_NP");
/*  607:     */   }
/*  608:     */   
/*  609:     */   public String getTOL3SUMSPAN()
/*  610:     */   {
/*  611: 531 */     return getString("TOL3SUMSPAN");
/*  612:     */   }
/*  613:     */   
/*  614:     */   public String getTOL3SUMSPAN_NP()
/*  615:     */   {
/*  616: 535 */     return getString("TOL3SUMSPAN_NP");
/*  617:     */   }
/*  618:     */   
/*  619:     */   public String getTOL3SUMURV()
/*  620:     */   {
/*  621: 539 */     return getString("TOL3SUMURV");
/*  622:     */   }
/*  623:     */   
/*  624:     */   public String getTOL3SUMURV_NP()
/*  625:     */   {
/*  626: 543 */     return getString("TOL3SUMURV_NP");
/*  627:     */   }
/*  628:     */   
/*  629:     */   public String getTOL3TYPE()
/*  630:     */   {
/*  631: 547 */     return getString("TOL3TYPE");
/*  632:     */   }
/*  633:     */   
/*  634:     */   public String getTOL3UPPERVALUE()
/*  635:     */   {
/*  636: 551 */     return getString("TOL3UPPERVALUE");
/*  637:     */   }
/*  638:     */   
/*  639:     */   public String getTOL3UPPERVALUE_NP()
/*  640:     */   {
/*  641: 555 */     return getString("TOL3UPPERVALUE_NP");
/*  642:     */   }
/*  643:     */   
/*  644:     */   public String getTOL4DESCRIPTION()
/*  645:     */   {
/*  646: 559 */     return getString("TOL4DESCRIPTION");
/*  647:     */   }
/*  648:     */   
/*  649:     */   public String getTOL4LOWERVALUE()
/*  650:     */   {
/*  651: 563 */     return getString("TOL4LOWERVALUE");
/*  652:     */   }
/*  653:     */   
/*  654:     */   public String getTOL4LOWERVALUE_NP()
/*  655:     */   {
/*  656: 567 */     return getString("TOL4LOWERVALUE_NP");
/*  657:     */   }
/*  658:     */   
/*  659:     */   public Boolean getTOL4NOADJLIMIT()
/*  660:     */   {
/*  661: 571 */     return getBoolean("TOL4NOADJLIMIT");
/*  662:     */   }
/*  663:     */   
/*  664:     */   public String getTOL4STATUS()
/*  665:     */   {
/*  666: 575 */     return getString("TOL4STATUS");
/*  667:     */   }
/*  668:     */   
/*  669:     */   public String getTOL4SUMDIRECTION()
/*  670:     */   {
/*  671: 579 */     return getString("TOL4SUMDIRECTION");
/*  672:     */   }
/*  673:     */   
/*  674:     */   public String getTOL4SUMEU()
/*  675:     */   {
/*  676: 583 */     return getString("TOL4SUMEU");
/*  677:     */   }
/*  678:     */   
/*  679:     */   public String getTOL4SUMEU_NP()
/*  680:     */   {
/*  681: 587 */     return getString("TOL4SUMEU_NP");
/*  682:     */   }
/*  683:     */   
/*  684:     */   public String getTOL4SUMREAD()
/*  685:     */   {
/*  686: 591 */     return getString("TOL4SUMREAD");
/*  687:     */   }
/*  688:     */   
/*  689:     */   public String getTOL4SUMREAD_NP()
/*  690:     */   {
/*  691: 595 */     return getString("TOL4SUMREAD_NP");
/*  692:     */   }
/*  693:     */   
/*  694:     */   public String getTOL4SUMSPAN()
/*  695:     */   {
/*  696: 599 */     return getString("TOL4SUMSPAN");
/*  697:     */   }
/*  698:     */   
/*  699:     */   public String getTOL4SUMSPAN_NP()
/*  700:     */   {
/*  701: 603 */     return getString("TOL4SUMSPAN_NP");
/*  702:     */   }
/*  703:     */   
/*  704:     */   public String getTOL4SUMURV()
/*  705:     */   {
/*  706: 607 */     return getString("TOL4SUMURV");
/*  707:     */   }
/*  708:     */   
/*  709:     */   public String getTOL4SUMURV_NP()
/*  710:     */   {
/*  711: 611 */     return getString("TOL4SUMURV_NP");
/*  712:     */   }
/*  713:     */   
/*  714:     */   public String getTOL4TYPE()
/*  715:     */   {
/*  716: 615 */     return getString("TOL4TYPE");
/*  717:     */   }
/*  718:     */   
/*  719:     */   public String getTOL4UPPERVALUE()
/*  720:     */   {
/*  721: 619 */     return getString("TOL4UPPERVALUE");
/*  722:     */   }
/*  723:     */   
/*  724:     */   public String getTOL4UPPERVALUE_NP()
/*  725:     */   {
/*  726: 623 */     return getString("TOL4UPPERVALUE_NP");
/*  727:     */   }
/*  728:     */   
/*  729:     */   public void setALLOWPOINTINSERTS(Boolean allowpointinserts)
/*  730:     */   {
/*  731: 627 */     setValue("ALLOWPOINTINSERTS", allowpointinserts, false);
/*  732:     */   }
/*  733:     */   
/*  734:     */   public void setASSETFUNCTION(Integer assetfunction)
/*  735:     */   {
/*  736: 631 */     setValue("ASSETFUNCTION", assetfunction, false);
/*  737:     */   }
/*  738:     */   
/*  739:     */   public void setCLIPLIMITS(Boolean cliplimits)
/*  740:     */   {
/*  741: 635 */     setValue("CLIPLIMITS", cliplimits, false);
/*  742:     */   }
/*  743:     */   
/*  744:     */   public void setDESCRIPTION(String description)
/*  745:     */   {
/*  746: 639 */     setValue("DESCRIPTION", description, false);
/*  747:     */   }
/*  748:     */   
/*  749:     */   public void setDESCRIPTION_LONGDESCRIPTION(String description_longdescription)
/*  750:     */   {
/*  751: 644 */     setValue("DESCRIPTION_LONGDESCRIPTION", description_longdescription, false);
/*  752:     */   }
/*  753:     */   
/*  754:     */   public void setDSPLANNUM(String dsplannum)
/*  755:     */   {
/*  756: 649 */     setValue("DSPLANNUM", dsplannum, false);
/*  757:     */   }
/*  758:     */   
/*  759:     */   public void setHASLD(Boolean hasld)
/*  760:     */   {
/*  761: 653 */     setValue("HASLD", hasld, false);
/*  762:     */   }
/*  763:     */   
/*  764:     */   public void setINPUTRANGE(Boolean inputrange)
/*  765:     */   {
/*  766: 657 */     setValue("INPUTRANGE", inputrange, false);
/*  767:     */   }
/*  768:     */   
/*  769:     */   public void setINSTRCALRANGEEU(String instrcalrangeeu)
/*  770:     */   {
/*  771: 661 */     setValue("INSTRCALRANGEEU", instrcalrangeeu, false);
/*  772:     */   }
/*  773:     */   
/*  774:     */   public void setINSTRCALRANGEFROM(String instrcalrangefrom)
/*  775:     */   {
/*  776: 665 */     setValue("INSTRCALRANGEFROM", instrcalrangefrom, false);
/*  777:     */   }
/*  778:     */   
/*  779:     */   public void setINSTRCALRANGEFROM_NP(String instrcalrangefrom_np)
/*  780:     */   {
/*  781: 669 */     setValue("INSTRCALRANGEFROM_NP", instrcalrangefrom_np, false);
/*  782:     */   }
/*  783:     */   
/*  784:     */   public void setINSTRCALRANGETO(String instrcalrangeto)
/*  785:     */   {
/*  786: 673 */     setValue("INSTRCALRANGETO", instrcalrangeto, false);
/*  787:     */   }
/*  788:     */   
/*  789:     */   public void setINSTRCALRANGETO_NP(String instrcalrangeto_np)
/*  790:     */   {
/*  791: 677 */     setValue("INSTRCALRANGETO_NP", instrcalrangeto_np, false);
/*  792:     */   }
/*  793:     */   
/*  794:     */   public void setINSTROUTRANGEEU(String instroutrangeeu)
/*  795:     */   {
/*  796: 681 */     setValue("INSTROUTRANGEEU", instroutrangeeu, false);
/*  797:     */   }
/*  798:     */   
/*  799:     */   public void setINSTROUTRANGEFROM(String instroutrangefrom)
/*  800:     */   {
/*  801: 685 */     setValue("INSTROUTRANGEFROM", instroutrangefrom, false);
/*  802:     */   }
/*  803:     */   
/*  804:     */   public void setINSTROUTRANGEFROM_NP(String instroutrangefrom_np)
/*  805:     */   {
/*  806: 689 */     setValue("INSTROUTRANGEFROM_NP", instroutrangefrom_np, false);
/*  807:     */   }
/*  808:     */   
/*  809:     */   public void setINSTROUTRANGETO(String instroutrangeto)
/*  810:     */   {
/*  811: 693 */     setValue("INSTROUTRANGETO", instroutrangeto, false);
/*  812:     */   }
/*  813:     */   
/*  814:     */   public void setINSTROUTRANGETO_NP(String instroutrangeto_np)
/*  815:     */   {
/*  816: 697 */     setValue("INSTROUTRANGETO_NP", instroutrangeto_np, false);
/*  817:     */   }
/*  818:     */   
/*  819:     */   public void setINSTRSEQ(Integer instrseq)
/*  820:     */   {
/*  821: 701 */     setValue("INSTRSEQ", instrseq, false);
/*  822:     */   }
/*  823:     */   
/*  824:     */   public void setINPUTPRECISION(Integer inputprecision)
/*  825:     */   {
/*  826: 705 */     setValue("INPUTPRECISION", inputprecision, false);
/*  827:     */   }
/*  828:     */   
/*  829:     */   public void setOUTPUTPRECISION(Integer outputprecision)
/*  830:     */   {
/*  831: 709 */     setValue("OUTPUTPRECISION", outputprecision, false);
/*  832:     */   }
/*  833:     */   
/*  834:     */   public void setLANGCODE(String langcode)
/*  835:     */   {
/*  836: 714 */     setValue("LANGCODE", langcode, false);
/*  837:     */   }
/*  838:     */   
/*  839:     */   public void setLocale(Locale locale)
/*  840:     */   {
/*  841: 718 */     this.locale = locale;
/*  842:     */   }
/*  843:     */   
/*  844:     */   public void setNOADJMADECHOICE(Boolean noadjmadechoice)
/*  845:     */   {
/*  846: 722 */     setValue("NOADJMADECHOICE", noadjmadechoice, false);
/*  847:     */   }
/*  848:     */   
/*  849:     */   public void setNOADJMADECHOICE1(Boolean noadjmadechoice1)
/*  850:     */   {
/*  851: 726 */     setValue("NOADJMADECHOICE1", noadjmadechoice1, false);
/*  852:     */   }
/*  853:     */   
/*  854:     */   public void setNOADJMADECHOICE2(Boolean noadjmadechoice2)
/*  855:     */   {
/*  856: 730 */     setValue("NOADJMADECHOICE2", noadjmadechoice2, false);
/*  857:     */   }
/*  858:     */   
/*  859:     */   public void setNOADJMADECHOICE3(Boolean noadjmadechoice3)
/*  860:     */   {
/*  861: 734 */     setValue("NOADJMADECHOICE3", noadjmadechoice3, false);
/*  862:     */   }
/*  863:     */   
/*  864:     */   public void setNOADJMADECHOICE4(Boolean noadjmadechoice4)
/*  865:     */   {
/*  866: 738 */     setValue("NOADJMADECHOICE4", noadjmadechoice4, false);
/*  867:     */   }
/*  868:     */   
/*  869:     */   public void setORGID(String orgid)
/*  870:     */   {
/*  871: 742 */     setValue("ORGID", orgid, false);
/*  872:     */   }
/*  873:     */   
/*  874:     */   public void setOUTPUTRANGE(Boolean outputrange)
/*  875:     */   {
/*  876: 746 */     setValue("OUTPUTRANGE", outputrange, false);
/*  877:     */   }
/*  878:     */   
/*  879:     */   public void setPLANTYPE(String plantype)
/*  880:     */   {
/*  881: 750 */     setValue("PLANTYPE", plantype, false);
/*  882:     */   }
/*  883:     */   
/*  884:     */   public void setPLUSCDSINSTRID(Integer pluscdsinstrid)
/*  885:     */   {
/*  886: 754 */     setValue("PLUSCDSINSTRID", pluscdsinstrid, false);
/*  887:     */   }
/*  888:     */   
/*  889:     */   public void setPROCESSEU(String processeu)
/*  890:     */   {
/*  891: 758 */     setValue("PROCESSEU", processeu, false);
/*  892:     */   }
/*  893:     */   
/*  894:     */   public void setPROCESSEUFACTOR(String processeufactor)
/*  895:     */   {
/*  896: 762 */     setValue("PROCESSEUFACTOR", processeufactor, false);
/*  897:     */   }
/*  898:     */   
/*  899:     */   public void setPROCESSEUFACTOR_NP(String processeufactor_np)
/*  900:     */   {
/*  901: 766 */     setValue("PROCESSEUFACTOR_NP", processeufactor_np, false);
/*  902:     */   }
/*  903:     */   
/*  904:     */   public void setREVISIONNUM(Integer revisionnum)
/*  905:     */   {
/*  906: 770 */     setValue("REVISIONNUM", revisionnum, false);
/*  907:     */   }
/*  908:     */   
/*  909:     */   public void setRON1LOWERVALUE(String ron1lowervalue)
/*  910:     */   {
/*  911: 774 */     setValue("RON1LOWERVALUE", ron1lowervalue, false);
/*  912:     */   }
/*  913:     */   
/*  914:     */   public void setRON1LOWERVALUE_NP(String ron1lowervalue_np)
/*  915:     */   {
/*  916: 778 */     setValue("RON1LOWERVALUE_NP", ron1lowervalue_np, false);
/*  917:     */   }
/*  918:     */   
/*  919:     */   public void setRON1TYPE(String ron1type)
/*  920:     */   {
/*  921: 782 */     setValue("RON1TYPE", ron1type, false);
/*  922:     */   }
/*  923:     */   
/*  924:     */   public void setRON1UPPERVALUE(String ron1uppervalue)
/*  925:     */   {
/*  926: 786 */     setValue("RON1UPPERVALUE", ron1uppervalue, false);
/*  927:     */   }
/*  928:     */   
/*  929:     */   public void setRON1UPPERVALUE_NP(String ron1uppervalue_np)
/*  930:     */   {
/*  931: 790 */     setValue("RON1UPPERVALUE_NP", ron1uppervalue_np, false);
/*  932:     */   }
/*  933:     */   
/*  934:     */   public void setSITEID(String siteid)
/*  935:     */   {
/*  936: 794 */     setValue("SITEID", siteid, false);
/*  937:     */   }
/*  938:     */   
/*  939:     */   public void setSQUAREROOT(Boolean squareroot)
/*  940:     */   {
/*  941: 798 */     setValue("SQUAREROOT", squareroot, false);
/*  942:     */   }
/*  943:     */   
/*  944:     */   public void setSQUARED(Boolean squared)
/*  945:     */   {
/*  946: 802 */     setValue("SQUARED", squared, false);
/*  947:     */   }
/*  948:     */   
/*  949:     */   public void setTOL1DESCRIPTION(String tol1description)
/*  950:     */   {
/*  951: 806 */     setValue("TOL1DESCRIPTION", tol1description, false);
/*  952:     */   }
/*  953:     */   
/*  954:     */   public void setTOL1LOWERVALUE(String tol1lowervalue)
/*  955:     */   {
/*  956: 810 */     setValue("TOL1LOWERVALUE", tol1lowervalue, false);
/*  957:     */   }
/*  958:     */   
/*  959:     */   public void setTOL1LOWERVALUE_NP(String tol1lowervalue_np)
/*  960:     */   {
/*  961: 814 */     setValue("TOL1LOWERVALUE_NP", tol1lowervalue_np, false);
/*  962:     */   }
/*  963:     */   
/*  964:     */   public void setTOL1NOADJLIMIT(Boolean tol1noadjlimit)
/*  965:     */   {
/*  966: 818 */     setValue("TOL1NOADJLIMIT", tol1noadjlimit, false);
/*  967:     */   }
/*  968:     */   
/*  969:     */   public void setTOL1STATUS(String tol1status)
/*  970:     */   {
/*  971: 822 */     setValue("TOL1STATUS", tol1status, false);
/*  972:     */   }
/*  973:     */   
/*  974:     */   public void setTOL1SUMDIRECTION(String tol1sumdirection)
/*  975:     */   {
/*  976: 826 */     setValue("TOL1SUMDIRECTION", tol1sumdirection, false);
/*  977:     */   }
/*  978:     */   
/*  979:     */   public void setTOL1SUMEU(String tol1sumeu)
/*  980:     */   {
/*  981: 830 */     setValue("TOL1SUMEU", tol1sumeu, false);
/*  982:     */   }
/*  983:     */   
/*  984:     */   public void setTOL1SUMEU_NP(String tol1sumeu_np)
/*  985:     */   {
/*  986: 834 */     setValue("TOL1SUMEU_NP", tol1sumeu_np, false);
/*  987:     */   }
/*  988:     */   
/*  989:     */   public void setTOL1SUMREAD(String tol1sumread)
/*  990:     */   {
/*  991: 838 */     setValue("TOL1SUMREAD", tol1sumread, false);
/*  992:     */   }
/*  993:     */   
/*  994:     */   public void setTOL1SUMREAD_NP(String tol1sumread_np)
/*  995:     */   {
/*  996: 842 */     setValue("TOL1SUMREAD_NP", tol1sumread_np, false);
/*  997:     */   }
/*  998:     */   
/*  999:     */   public void setTOL1SUMSPAN(String tol1sumspan)
/* 1000:     */   {
/* 1001: 846 */     setValue("TOL1SUMSPAN", tol1sumspan, false);
/* 1002:     */   }
/* 1003:     */   
/* 1004:     */   public void setTOL1SUMSPAN_NP(String tol1sumspan_np)
/* 1005:     */   {
/* 1006: 850 */     setValue("TOL1SUMSPAN_NP", tol1sumspan_np, false);
/* 1007:     */   }
/* 1008:     */   
/* 1009:     */   public void setTOL1SUMURV(String tol1sumurv)
/* 1010:     */   {
/* 1011: 854 */     setValue("TOL1SUMURV", tol1sumurv, false);
/* 1012:     */   }
/* 1013:     */   
/* 1014:     */   public void setTOL1SUMURV_NP(String tol1sumurv_np)
/* 1015:     */   {
/* 1016: 858 */     setValue("TOL1SUMURV_NP", tol1sumurv_np, false);
/* 1017:     */   }
/* 1018:     */   
/* 1019:     */   public void setTOL1TYPE(String tol1type)
/* 1020:     */   {
/* 1021: 862 */     setValue("TOL1TYPE", tol1type, false);
/* 1022:     */   }
/* 1023:     */   
/* 1024:     */   public void setTOL1UPPERVALUE(String tol1uppervalue)
/* 1025:     */   {
/* 1026: 866 */     setValue("TOL1UPPERVALUE", tol1uppervalue, false);
/* 1027:     */   }
/* 1028:     */   
/* 1029:     */   public void setTOL1UPPERVALUE_NP(String tol1uppervalue_np)
/* 1030:     */   {
/* 1031: 870 */     setValue("TOL1UPPERVALUE_NP", tol1uppervalue_np, false);
/* 1032:     */   }
/* 1033:     */   
/* 1034:     */   public void setTOL2DESCRIPTION(String tol2description)
/* 1035:     */   {
/* 1036: 874 */     setValue("TOL2DESCRIPTION", tol2description, false);
/* 1037:     */   }
/* 1038:     */   
/* 1039:     */   public void setTOL2LOWERVALUE(String tol2lowervalue)
/* 1040:     */   {
/* 1041: 878 */     setValue("TOL2LOWERVALUE", tol2lowervalue, false);
/* 1042:     */   }
/* 1043:     */   
/* 1044:     */   public void setTOL2LOWERVALUE_NP(String tol2lowervalue_np)
/* 1045:     */   {
/* 1046: 882 */     setValue("TOL2LOWERVALUE_NP", tol2lowervalue_np, false);
/* 1047:     */   }
/* 1048:     */   
/* 1049:     */   public void setTOL2NOADJLIMIT(Boolean tol2noadjlimit)
/* 1050:     */   {
/* 1051: 886 */     setValue("TOL2NOADJLIMIT", tol2noadjlimit, false);
/* 1052:     */   }
/* 1053:     */   
/* 1054:     */   public void setTOL2STATUS(String tol2status)
/* 1055:     */   {
/* 1056: 890 */     setValue("TOL2STATUS", tol2status, false);
/* 1057:     */   }
/* 1058:     */   
/* 1059:     */   public void setTOL2SUMDIRECTION(String tol2sumdirection)
/* 1060:     */   {
/* 1061: 894 */     setValue("TOL2SUMDIRECTION", tol2sumdirection, false);
/* 1062:     */   }
/* 1063:     */   
/* 1064:     */   public void setTOL2SUMEU(String tol2sumeu)
/* 1065:     */   {
/* 1066: 898 */     setValue("TOL2SUMEU", tol2sumeu, false);
/* 1067:     */   }
/* 1068:     */   
/* 1069:     */   public void setTOL2SUMEU_NP(String tol2sumeu_np)
/* 1070:     */   {
/* 1071: 902 */     setValue("TOL2SUMEU_NP", tol2sumeu_np, false);
/* 1072:     */   }
/* 1073:     */   
/* 1074:     */   public void setTOL2SUMREAD(String tol2sumread)
/* 1075:     */   {
/* 1076: 906 */     setValue("TOL2SUMREAD", tol2sumread, false);
/* 1077:     */   }
/* 1078:     */   
/* 1079:     */   public void setTOL2SUMREAD_NP(String tol2sumread_np)
/* 1080:     */   {
/* 1081: 910 */     setValue("TOL2SUMREAD_NP", tol2sumread_np, false);
/* 1082:     */   }
/* 1083:     */   
/* 1084:     */   public void setTOL2SUMSPAN(String tol2sumspan)
/* 1085:     */   {
/* 1086: 914 */     setValue("TOL2SUMSPAN", tol2sumspan, false);
/* 1087:     */   }
/* 1088:     */   
/* 1089:     */   public void setTOL2SUMSPAN_NP(String tol2sumspan_np)
/* 1090:     */   {
/* 1091: 918 */     setValue("TOL2SUMSPAN_NP", tol2sumspan_np, false);
/* 1092:     */   }
/* 1093:     */   
/* 1094:     */   public void setTOL2SUMURV(String tol2sumurv)
/* 1095:     */   {
/* 1096: 922 */     setValue("TOL2SUMURV", tol2sumurv, false);
/* 1097:     */   }
/* 1098:     */   
/* 1099:     */   public void setTOL2SUMURV_NP(String tol2sumurv_np)
/* 1100:     */   {
/* 1101: 926 */     setValue("TOL2SUMURV_NP", tol2sumurv_np, false);
/* 1102:     */   }
/* 1103:     */   
/* 1104:     */   public void setTOL2TYPE(String tol2type)
/* 1105:     */   {
/* 1106: 930 */     setValue("TOL2TYPE", tol2type, false);
/* 1107:     */   }
/* 1108:     */   
/* 1109:     */   public void setTOL2UPPERVALUE(String tol2uppervalue)
/* 1110:     */   {
/* 1111: 934 */     setValue("TOL2UPPERVALUE", tol2uppervalue, false);
/* 1112:     */   }
/* 1113:     */   
/* 1114:     */   public void setTOL2UPPERVALUE_NP(String tol2uppervalue_np)
/* 1115:     */   {
/* 1116: 938 */     setValue("TOL2UPPERVALUE_NP", tol2uppervalue_np, false);
/* 1117:     */   }
/* 1118:     */   
/* 1119:     */   public void setTOL3DESCRIPTION(String tol3description)
/* 1120:     */   {
/* 1121: 942 */     setValue("TOL3DESCRIPTION", tol3description, false);
/* 1122:     */   }
/* 1123:     */   
/* 1124:     */   public void setTOL3LOWERVALUE(String tol3lowervalue)
/* 1125:     */   {
/* 1126: 946 */     setValue("TOL3LOWERVALUE", tol3lowervalue, false);
/* 1127:     */   }
/* 1128:     */   
/* 1129:     */   public void setTOL3LOWERVALUE_NP(String tol3lowervalue_np)
/* 1130:     */   {
/* 1131: 950 */     setValue("TOL3LOWERVALUE_NP", tol3lowervalue_np, false);
/* 1132:     */   }
/* 1133:     */   
/* 1134:     */   public void setTOL3NOADJLIMIT(Boolean tol3noadjlimit)
/* 1135:     */   {
/* 1136: 954 */     setValue("TOL3NOADJLIMIT", tol3noadjlimit, false);
/* 1137:     */   }
/* 1138:     */   
/* 1139:     */   public void setTOL3STATUS(String tol3status)
/* 1140:     */   {
/* 1141: 958 */     setValue("TOL3STATUS", tol3status, false);
/* 1142:     */   }
/* 1143:     */   
/* 1144:     */   public void setTOL3SUMDIRECTION(String tol3sumdirection)
/* 1145:     */   {
/* 1146: 962 */     setValue("TOL3SUMDIRECTION", tol3sumdirection, false);
/* 1147:     */   }
/* 1148:     */   
/* 1149:     */   public void setTOL3SUMEU(String tol3sumeu)
/* 1150:     */   {
/* 1151: 966 */     setValue("TOL3SUMEU", tol3sumeu, false);
/* 1152:     */   }
/* 1153:     */   
/* 1154:     */   public void setTOL3SUMEU_NP(String tol3sumeu_np)
/* 1155:     */   {
/* 1156: 970 */     setValue("TOL3SUMEU_NP", tol3sumeu_np, false);
/* 1157:     */   }
/* 1158:     */   
/* 1159:     */   public void setTOL3SUMREAD(String tol3sumread)
/* 1160:     */   {
/* 1161: 974 */     setValue("TOL3SUMREAD", tol3sumread, false);
/* 1162:     */   }
/* 1163:     */   
/* 1164:     */   public void setTOL3SUMREAD_NP(String tol3sumread_np)
/* 1165:     */   {
/* 1166: 978 */     setValue("TOL3SUMREAD_NP", tol3sumread_np, false);
/* 1167:     */   }
/* 1168:     */   
/* 1169:     */   public void setTOL3SUMSPAN(String tol3sumspan)
/* 1170:     */   {
/* 1171: 982 */     setValue("TOL3SUMSPAN", tol3sumspan, false);
/* 1172:     */   }
/* 1173:     */   
/* 1174:     */   public void setTOL3SUMSPAN_NP(String tol3sumspan_np)
/* 1175:     */   {
/* 1176: 986 */     setValue("TOL3SUMSPAN_NP", tol3sumspan_np, false);
/* 1177:     */   }
/* 1178:     */   
/* 1179:     */   public void setTOL3SUMURV(String tol3sumurv)
/* 1180:     */   {
/* 1181: 990 */     setValue("TOL3SUMURV", tol3sumurv, false);
/* 1182:     */   }
/* 1183:     */   
/* 1184:     */   public void setTOL3SUMURV_NP(String tol3sumurv_np)
/* 1185:     */   {
/* 1186: 994 */     setValue("TOL3SUMURV_NP", tol3sumurv_np, false);
/* 1187:     */   }
/* 1188:     */   
/* 1189:     */   public void setTOL3TYPE(String tol3type)
/* 1190:     */   {
/* 1191: 998 */     setValue("TOL3TYPE", tol3type, false);
/* 1192:     */   }
/* 1193:     */   
/* 1194:     */   public void setTOL3UPPERVALUE(String tol3uppervalue)
/* 1195:     */   {
/* 1196:1002 */     setValue("TOL3UPPERVALUE", tol3uppervalue, false);
/* 1197:     */   }
/* 1198:     */   
/* 1199:     */   public void setTOL3UPPERVALUE_NP(String tol3uppervalue_np)
/* 1200:     */   {
/* 1201:1006 */     setValue("TOL3UPPERVALUE_NP", tol3uppervalue_np, false);
/* 1202:     */   }
/* 1203:     */   
/* 1204:     */   public void setTOL4DESCRIPTION(String tol4description)
/* 1205:     */   {
/* 1206:1010 */     setValue("TOL4DESCRIPTION", tol4description, false);
/* 1207:     */   }
/* 1208:     */   
/* 1209:     */   public void setTOL4LOWERVALUE(String tol4lowervalue)
/* 1210:     */   {
/* 1211:1014 */     setValue("TOL4LOWERVALUE", tol4lowervalue, false);
/* 1212:     */   }
/* 1213:     */   
/* 1214:     */   public void setTOL4LOWERVALUE_NP(String tol4lowervalue_np)
/* 1215:     */   {
/* 1216:1018 */     setValue("TOL4LOWERVALUE_NP", tol4lowervalue_np, false);
/* 1217:     */   }
/* 1218:     */   
/* 1219:     */   public void setTOL4NOADJLIMIT(Boolean tol4noadjlimit)
/* 1220:     */   {
/* 1221:1022 */     setValue("TOL4NOADJLIMIT", tol4noadjlimit, false);
/* 1222:     */   }
/* 1223:     */   
/* 1224:     */   public void setTOL4STATUS(String tol4status)
/* 1225:     */   {
/* 1226:1026 */     setValue("TOL4STATUS", tol4status, false);
/* 1227:     */   }
/* 1228:     */   
/* 1229:     */   public void setTOL4SUMDIRECTION(String tol4sumdirection)
/* 1230:     */   {
/* 1231:1030 */     setValue("TOL4SUMDIRECTION", tol4sumdirection, false);
/* 1232:     */   }
/* 1233:     */   
/* 1234:     */   public void setTOL4SUMEU(String tol4sumeu)
/* 1235:     */   {
/* 1236:1034 */     setValue("TOL4SUMEU", tol4sumeu, false);
/* 1237:     */   }
/* 1238:     */   
/* 1239:     */   public void setTOL4SUMEU_NP(String tol4sumeu_np)
/* 1240:     */   {
/* 1241:1038 */     setValue("TOL4SUMEU_NP", tol4sumeu_np, false);
/* 1242:     */   }
/* 1243:     */   
/* 1244:     */   public void setTOL4SUMREAD(String tol4sumread)
/* 1245:     */   {
/* 1246:1042 */     setValue("TOL4SUMREAD", tol4sumread, false);
/* 1247:     */   }
/* 1248:     */   
/* 1249:     */   public void setTOL4SUMREAD_NP(String tol4sumread_np)
/* 1250:     */   {
/* 1251:1046 */     setValue("TOL4SUMREAD_NP", tol4sumread_np, false);
/* 1252:     */   }
/* 1253:     */   
/* 1254:     */   public void setTOL4SUMSPAN(String tol4sumspan)
/* 1255:     */   {
/* 1256:1050 */     setValue("TOL4SUMSPAN", tol4sumspan, false);
/* 1257:     */   }
/* 1258:     */   
/* 1259:     */   public void setTOL4SUMSPAN_NP(String tol4sumspan_np)
/* 1260:     */   {
/* 1261:1054 */     setValue("TOL4SUMSPAN_NP", tol4sumspan_np, false);
/* 1262:     */   }
/* 1263:     */   
/* 1264:     */   public void setTOL4SUMURV(String tol4sumurv)
/* 1265:     */   {
/* 1266:1058 */     setValue("TOL4SUMURV", tol4sumurv, false);
/* 1267:     */   }
/* 1268:     */   
/* 1269:     */   public void setTOL4SUMURV_NP(String tol4sumurv_np)
/* 1270:     */   {
/* 1271:1062 */     setValue("TOL4SUMURV_NP", tol4sumurv_np, false);
/* 1272:     */   }
/* 1273:     */   
/* 1274:     */   public void setTOL4TYPE(String tol4type)
/* 1275:     */   {
/* 1276:1066 */     setValue("TOL4TYPE", tol4type, false);
/* 1277:     */   }
/* 1278:     */   
/* 1279:     */   public void setTOL4UPPERVALUE(String tol4uppervalue)
/* 1280:     */   {
/* 1281:1070 */     setValue("TOL4UPPERVALUE", tol4uppervalue, false);
/* 1282:     */   }
/* 1283:     */   
/* 1284:     */   public void setTOL4UPPERVALUE_NP(String tol4uppervalue_np)
/* 1285:     */   {
/* 1286:1074 */     setValue("TOL4UPPERVALUE_NP", tol4uppervalue_np, false);
/* 1287:     */   }
/* 1288:     */   
/* 1289:     */   public boolean isNull(String key)
/* 1290:     */   {
/* 1291:1078 */     Object value = null;
/* 1292:1079 */     if ((getPlusCDSInstrTO() != null) && (getPlusCDSInstrTO().containsAttribute(key)))
/* 1293:     */     {
/* 1294:1080 */       value = getPlusCDSInstrTO().getObject(key);
/* 1295:1081 */       return (value == null) || (value.toString().trim().equals(""));
/* 1296:     */     }
/* 1297:1083 */     if ((getPlusCDSPointTO() != null) && (getPlusCDSPointTO().containsAttribute(key)))
/* 1298:     */     {
/* 1299:1084 */       value = getPlusCDSPointTO().getObject(key);
/* 1300:1085 */       return (value == null) || (value.toString().trim().equals(""));
/* 1301:     */     }
/* 1302:1087 */     if ((getPlusCDSTO() != null) && (getPlusCDSTO().containsAttribute(key)))
/* 1303:     */     {
/* 1304:1088 */       value = getPlusCDSTO().getObject(key);
/* 1305:1089 */       return (value == null) || (value.toString().trim().equals(""));
/* 1306:     */     }
/* 1307:1091 */     return true;
/* 1308:     */   }
/* 1309:     */   
/* 1310:     */   public boolean isRoundUpField()
/* 1311:     */   {
/* 1312:1095 */     String fieldName = this.fieldName;
/* 1313:1096 */     return (fieldName != null) && (!fieldName.equalsIgnoreCase("INSTRCALRANGEFROM")) && (!fieldName.equalsIgnoreCase("INSTRCALRANGETO")) && (!fieldName.equalsIgnoreCase("INSTROUTRANGEFROM")) && (!fieldName.equalsIgnoreCase("INSTROUTRANGETO")) && (!fieldName.equalsIgnoreCase("RON1LOWERVALUE")) && (!fieldName.equalsIgnoreCase("RON1UPPERVALUE")) && (!fieldName.equalsIgnoreCase("TOL1LOWERVALUE")) && (!fieldName.equalsIgnoreCase("TOL1UPPERVALUE")) && (!fieldName.equalsIgnoreCase("TOL2LOWERVALUE")) && (!fieldName.equalsIgnoreCase("TOL2UPPERVALUE")) && (!fieldName.equalsIgnoreCase("TOL3LOWERVALUE")) && (!fieldName.equalsIgnoreCase("TOL3UPPERVALUE")) && (!fieldName.equalsIgnoreCase("TOL4LOWERVALUE")) && (!fieldName.equalsIgnoreCase("TOL4UPPERVALUE")) && (!fieldName.equalsIgnoreCase("TOL1SUMEU")) && (!fieldName.equalsIgnoreCase("TOL1SUMREAD")) && (!fieldName.equalsIgnoreCase("TOL1SUMSPAN")) && (!fieldName.equalsIgnoreCase("TOL1SUMURV")) && (!fieldName.equalsIgnoreCase("TOL2SUMEU")) && (!fieldName.equalsIgnoreCase("TOL2SUMREAD")) && (!fieldName.equalsIgnoreCase("TOL2SUMSPAN")) && (!fieldName.equalsIgnoreCase("TOL2SUMURV")) && (!fieldName.equalsIgnoreCase("TOL3SUMEU")) && (!fieldName.equalsIgnoreCase("TOL3SUMREAD")) && (!fieldName.equalsIgnoreCase("TOL3SUMSPAN")) && (!fieldName.equalsIgnoreCase("TOL3SUMURV")) && (!fieldName.equalsIgnoreCase("TOL4SUMEU")) && (!fieldName.equalsIgnoreCase("TOL4SUMREAD")) && (!fieldName.equalsIgnoreCase("TOL4SUMSPAN")) && (!fieldName.equalsIgnoreCase("TOL4SUMURV"));
/* 1314:     */   }
/* 1315:     */   
/* 1316:     */   public Set getChangedFields()
/* 1317:     */   {
/* 1318:1129 */     return this.changedFields;
/* 1319:     */   }
/* 1320:     */   
/* 1321:     */   public void setValue(String keyName, Object object, boolean markField)
/* 1322:     */   {
/* 1323:1133 */     setValue(keyName, object, 0L, markField);
/* 1324:     */   }
/* 1325:     */   
/* 1326:     */   public void setPlusCDSTO(PlusCDSTO plusCDSTO)
/* 1327:     */   {
/* 1328:1137 */     this.plusCDSTO = plusCDSTO;
/* 1329:1138 */     if (plusCDSTO.getPlusCDSInstrTO() != this) {
/* 1330:1139 */       plusCDSTO.setPlusCDSInstTO(this);
/* 1331:     */     }
/* 1332:     */   }
/* 1333:     */   
/* 1334:     */   public void setPlusCDSInstTO(PlusCDSInstrTO plusCDSInstrTO)
/* 1335:     */   {
/* 1336:1143 */     throw new UnsupportedOperationException("In this class this method is not implemented.");
/* 1337:     */   }
/* 1338:     */   
/* 1339:     */   public void setPlusCDSPointTO(PlusCDSPointTO plusCDSPointTO)
/* 1340:     */   {
/* 1341:1148 */     this.plusCDSPointTO = plusCDSPointTO;
/* 1342:1149 */     if (plusCDSPointTO.getPlusCDSInstrTO() != this) {
/* 1343:1150 */       plusCDSPointTO.setPlusCDSInstTO(this);
/* 1344:     */     }
/* 1345:     */   }
/* 1346:     */   
/* 1347:     */   protected boolean containsAttribute(String attributeName)
/* 1348:     */   {
/* 1349:1154 */     return this.mboData.containsKey(attributeName.toUpperCase());
/* 1350:     */   }
/* 1351:     */   
/* 1352:     */   private PlusCMboRemote getObjectOwner(String attributeName)
/* 1353:     */   {
/* 1354:1158 */     if (getPlusCDSInstrTO().containsAttribute(attributeName)) {
/* 1355:1159 */       return getPlusCDSInstrTO();
/* 1356:     */     }
/* 1357:1162 */     if (getPlusCDSPointTO().containsAttribute(attributeName)) {
/* 1358:1163 */       return getPlusCDSPointTO();
/* 1359:     */     }
/* 1360:1166 */     if (getPlusCDSTO().containsAttribute(attributeName)) {
/* 1361:1167 */       return getPlusCDSTO();
/* 1362:     */     }
/* 1363:1170 */     throw new RuntimeException("Neither of suitable classes have the attribute " + attributeName);
/* 1364:     */   }
/* 1365:     */   
/* 1366:     */   private static List getAttributeNames()
/* 1367:     */   {
/* 1368:1174 */     List list = new LinkedList();
/* 1369:1175 */     Method[] methods = PlusCDSInstrTO.class.getMethods();
/* 1370:1176 */     for (int i = 0; i < methods.length; i++) {
/* 1371:1177 */       if (methods[i].getName().indexOf("set") == 0) {
/* 1372:1178 */         list.add(methods[i].getName().substring(3).toUpperCase());
/* 1373:     */       }
/* 1374:     */     }
/* 1375:1181 */     return list;
/* 1376:     */   }
/* 1377:     */   
/* 1378:     */   public void clearAllChangedFieldsSets()
/* 1379:     */   {
/* 1380:1185 */     if (getPlusCDSInstrTO() != null) {
/* 1381:1186 */       getPlusCDSInstrTO().getChangedFields().clear();
/* 1382:     */     }
/* 1383:1188 */     if (getPlusCDSTO() != null) {
/* 1384:1189 */       getPlusCDSTO().getChangedFields().clear();
/* 1385:     */     }
/* 1386:1191 */     if (getPlusCDSPointTO() != null) {
/* 1387:1192 */       getPlusCDSPointTO().getChangedFields().clear();
/* 1388:     */     }
/* 1389:     */   }
/* 1390:     */   
/* 1391:     */   public void setPlusCWODSTO(PlusCWODSTO plusCWODSTO)
/* 1392:     */   {
/* 1393:1197 */     throw new UnsupportedOperationException("In this class this method is not implemented.");
/* 1394:     */   }
/* 1395:     */   
/* 1396:     */   public PlusCWODSTO getPlusCWODSTO()
/* 1397:     */   {
/* 1398:1201 */     throw new UnsupportedOperationException("In this class this method is not implemented.");
/* 1399:     */   }
/* 1400:     */   
/* 1401:     */   public void setPlusCWODSInstrTO(PlusCWODSInstrTO plusCWODSInstrTO)
/* 1402:     */   {
/* 1403:1204 */     throw new UnsupportedOperationException("In this class this method is not implemented.");
/* 1404:     */   }
/* 1405:     */   
/* 1406:     */   public PlusCWODSInstrTO getPlusCWODSInstrTO()
/* 1407:     */   {
/* 1408:1208 */     throw new UnsupportedOperationException("In this class this method is not implemented.");
/* 1409:     */   }
/* 1410:     */   
/* 1411:     */   public void setPlusCWODSPointTO(PlusCWODSPointTO plusCWODSPointTO)
/* 1412:     */   {
/* 1413:1211 */     throw new UnsupportedOperationException("In this class this method is not implemented.");
/* 1414:     */   }
/* 1415:     */   
/* 1416:     */   public PlusCWODSPointTO getPlusCWODSPointTO()
/* 1417:     */   {
/* 1418:1215 */     throw new UnsupportedOperationException("In this class this method is not implemented.");
/* 1419:     */   }
/* 1420:     */   
/* 1421:     */   public void setValue(String key, Object object, long validationFlag)
/* 1422:     */   {
/* 1423:1219 */     setValue(key, object, validationFlag, true);
/* 1424:     */   }
/* 1425:     */   
/* 1426:     */   public void setValue(String keyName, Object object, long validationFlag, boolean markField)
/* 1427:     */   {
/* 1428:1224 */     if (containsAttribute(keyName))
/* 1429:     */     {
/* 1430:1225 */       if (markField)
/* 1431:     */       {
/* 1432:1226 */         this.changedFields.add(keyName.toUpperCase());
/* 1433:1227 */         this.validationFlags.put(keyName.toUpperCase(), new Long(validationFlag));
/* 1434:     */       }
/* 1435:     */       else
/* 1436:     */       {
/* 1437:1229 */         this.validationFlags.remove(keyName.toUpperCase());
/* 1438:     */       }
/* 1439:1231 */       this.mboData.put(keyName.toUpperCase(), object);
/* 1440:     */     }
/* 1441:1233 */     else if ((this.plusCDSPointTO != null) && (getPlusCDSPointTO().containsAttribute(keyName)))
/* 1442:     */     {
/* 1443:1234 */       getPlusCDSPointTO().setValue(keyName, object, validationFlag, markField);
/* 1444:     */     }
/* 1445:1235 */     else if ((this.plusCDSTO != null) && (getPlusCDSTO().containsAttribute(keyName)))
/* 1446:     */     {
/* 1447:1236 */       getPlusCDSTO().setValue(keyName, object, validationFlag, markField);
/* 1448:     */     }
/* 1449:     */     else
/* 1450:     */     {
/* 1451:1238 */       throw new RuntimeException("No suitable class to set " + keyName + " attribute");
/* 1452:     */     }
/* 1453:     */   }
/* 1454:     */   
/* 1455:     */   public long getValidationFlag(String key)
/* 1456:     */   {
/* 1457:1245 */     String keyUpper = key.toUpperCase();
/* 1458:1246 */     PlusCMboRemote suitable = getObjectOwner(keyUpper);
/* 1459:1247 */     long value = 0L;
/* 1460:1248 */     if (suitable == this)
/* 1461:     */     {
/* 1462:1249 */       Object o = this.validationFlags.get(keyUpper);
/* 1463:1250 */       value = o != null ? new Long(o.toString()).longValue() : 11L;
/* 1464:     */     }
/* 1465:     */     else
/* 1466:     */     {
/* 1467:1252 */       suitable.getValidationFlag(key);
/* 1468:     */     }
/* 1469:1254 */     return value;
/* 1470:     */   }
/* 1471:     */   
/* 1472:     */   public Set getNonPersistentFieldsName()
/* 1473:     */   {
/* 1474:1261 */     throw new UnsupportedOperationException("In this class this method is not implemented.");
/* 1475:     */   }
/* 1476:     */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     psdi.plusc.app.pluscds.pluscmobilecommon.PlusCDSInstrTO
 * JD-Core Version:    0.7.0.1
 */