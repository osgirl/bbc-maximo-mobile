/*    1:     */ package psdi.plusc.app.pluscds.pluscmobilecommon;
/*    2:     */ 
/*    3:     */ import java.lang.reflect.Method;
/*    4:     */ import java.util.Date;
/*    5:     */ import java.util.HashMap;
/*    6:     */ import java.util.HashSet;
/*    7:     */ import java.util.Iterator;
/*    8:     */ import java.util.LinkedList;
/*    9:     */ import java.util.List;
/*   10:     */ import java.util.Locale;
/*   11:     */ import java.util.Map;
/*   12:     */ import java.util.Set;
/*   13:     */ 
/*   14:     */ public class PlusCWODSInstrTO
/*   15:     */   implements PlusCMboRemote
/*   16:     */ {
/*   17:     */   private static final long serialVersionUID = 1L;
/*   18:  38 */   private Set changedFields = new HashSet();
/*   19:     */   private Set nonPersistentFields;
/*   20:     */   private String fieldName;
/*   21:     */   private Locale locale;
/*   22:  46 */   private Map mboData = new HashMap();
/*   23:  48 */   private Map validationFlags = new HashMap();
/*   24:     */   private PlusCWODSPointTO plusCWODSPointTO;
/*   25:     */   private PlusCWODSTO plusCWODSTO;
/*   26:     */   
/*   27:     */   public PlusCWODSInstrTO()
/*   28:     */   {
/*   29:  56 */     for (Iterator iter = getAttributeNames().iterator(); iter.hasNext();)
/*   30:     */     {
/*   31:  57 */       String element = (String)iter.next();
/*   32:  58 */       this.mboData.put(element, null);
/*   33:     */     }
/*   34:     */   }
/*   35:     */   
/*   36:     */   public Boolean getALLOWPOINTINSERTS()
/*   37:     */   {
/*   38:  64 */     return getBoolean("ALLOWPOINTINSERTS");
/*   39:     */   }
/*   40:     */   
/*   41:     */   public String getASFOUNDCALSTATUS()
/*   42:     */   {
/*   43:  69 */     return getString("ASFOUNDCALSTATUS");
/*   44:     */   }
/*   45:     */   
/*   46:     */   public String getASFOUNDCOMMENTS()
/*   47:     */   {
/*   48:  74 */     return getString("ASFOUNDCOMMENTS");
/*   49:     */   }
/*   50:     */   
/*   51:     */   public String getASLEFTCALSTATUS()
/*   52:     */   {
/*   53:  79 */     return getString("ASLEFTCALSTATUS");
/*   54:     */   }
/*   55:     */   
/*   56:     */   public String getASLEFTCOMMENTS()
/*   57:     */   {
/*   58:  84 */     return getString("ASLEFTCOMMENTS");
/*   59:     */   }
/*   60:     */   
/*   61:     */   public Integer getASSETFUNCTION()
/*   62:     */   {
/*   63:  89 */     return getInt("ASSETFUNCTION");
/*   64:     */   }
/*   65:     */   
/*   66:     */   public String getASSETNUM()
/*   67:     */   {
/*   68:  94 */     return getString("ASSETNUM");
/*   69:     */   }
/*   70:     */   
/*   71:     */   public String getBAROPRESSURE()
/*   72:     */   {
/*   73:  99 */     return getString("BAROPRESSURE");
/*   74:     */   }
/*   75:     */   
/*   76:     */   public String getBAROPRESSUREEU()
/*   77:     */   {
/*   78: 104 */     return getString("BAROPRESSUREEU");
/*   79:     */   }
/*   80:     */   
/*   81:     */   public Boolean getCLIPLIMITS()
/*   82:     */   {
/*   83: 109 */     return getBoolean("CLIPLIMITS");
/*   84:     */   }
/*   85:     */   
/*   86:     */   public String getDESCRIPTION()
/*   87:     */   {
/*   88: 114 */     return getString("DESCRIPTION");
/*   89:     */   }
/*   90:     */   
/*   91:     */   public String getDSPLANNUM()
/*   92:     */   {
/*   93: 119 */     return getString("DSPLANNUM");
/*   94:     */   }
/*   95:     */   
/*   96:     */   public String getFieldName()
/*   97:     */   {
/*   98: 124 */     return getString("fieldName");
/*   99:     */   }
/*  100:     */   
/*  101:     */   public Boolean getHASLD()
/*  102:     */   {
/*  103: 129 */     return getBoolean("HASLD");
/*  104:     */   }
/*  105:     */   
/*  106:     */   public String getHUMIDITY()
/*  107:     */   {
/*  108: 134 */     return getString("HUMIDITY");
/*  109:     */   }
/*  110:     */   
/*  111:     */   public String getHUMIDITYEU()
/*  112:     */   {
/*  113: 139 */     return getString("HUMIDITYEU");
/*  114:     */   }
/*  115:     */   
/*  116:     */   public Integer getINPUTPRECISION()
/*  117:     */   {
/*  118: 144 */     return getInt("INPUTPRECISION");
/*  119:     */   }
/*  120:     */   
/*  121:     */   public Boolean getINPUTRANGE()
/*  122:     */   {
/*  123: 149 */     return getBoolean("INPUTRANGE");
/*  124:     */   }
/*  125:     */   
/*  126:     */   public String getINSTRCALRANGEEU()
/*  127:     */   {
/*  128: 154 */     return getString("INSTRCALRANGEEU");
/*  129:     */   }
/*  130:     */   
/*  131:     */   public String getINSTRCALRANGEFROM()
/*  132:     */   {
/*  133: 159 */     return getString("INSTRCALRANGEFROM");
/*  134:     */   }
/*  135:     */   
/*  136:     */   public String getINSTRCALRANGEFROM_NP()
/*  137:     */   {
/*  138: 164 */     return getString("INSTRCALRANGEFROM_NP");
/*  139:     */   }
/*  140:     */   
/*  141:     */   public String getINSTRCALRANGETO()
/*  142:     */   {
/*  143: 169 */     return getString("INSTRCALRANGETO");
/*  144:     */   }
/*  145:     */   
/*  146:     */   public String getINSTRCALRANGETO_NP()
/*  147:     */   {
/*  148: 174 */     return getString("INSTRCALRANGETO_NP");
/*  149:     */   }
/*  150:     */   
/*  151:     */   public String getINSTROUTRANGEEU()
/*  152:     */   {
/*  153: 179 */     return getString("INSTROUTRANGEEU");
/*  154:     */   }
/*  155:     */   
/*  156:     */   public String getINSTROUTRANGEFROM()
/*  157:     */   {
/*  158: 184 */     return getString("INSTROUTRANGEFROM");
/*  159:     */   }
/*  160:     */   
/*  161:     */   public String getINSTROUTRANGEFROM_NP()
/*  162:     */   {
/*  163: 189 */     return getString("INSTROUTRANGEFROM_NP");
/*  164:     */   }
/*  165:     */   
/*  166:     */   public String getINSTROUTRANGETO()
/*  167:     */   {
/*  168: 194 */     return getString("INSTROUTRANGETO");
/*  169:     */   }
/*  170:     */   
/*  171:     */   public String getINSTROUTRANGETO_NP()
/*  172:     */   {
/*  173: 199 */     return getString("INSTROUTRANGETO_NP");
/*  174:     */   }
/*  175:     */   
/*  176:     */   public Integer getINSTRSEQ()
/*  177:     */   {
/*  178: 204 */     return getInt("INSTRSEQ");
/*  179:     */   }
/*  180:     */   
/*  181:     */   public String getLANGCODE()
/*  182:     */   {
/*  183: 209 */     return getString("LANGCODE");
/*  184:     */   }
/*  185:     */   
/*  186:     */   public Integer getLDKEY()
/*  187:     */   {
/*  188: 214 */     return getInt("LDKEY");
/*  189:     */   }
/*  190:     */   
/*  191:     */   public Date getNEXTDATE()
/*  192:     */   {
/*  193: 219 */     return getDate("NEXTDATE");
/*  194:     */   }
/*  195:     */   
/*  196:     */   public Boolean getNOADJMADE()
/*  197:     */   {
/*  198: 224 */     return getBoolean("NOADJMADE");
/*  199:     */   }
/*  200:     */   
/*  201:     */   public String getNOADJMADECHOICE()
/*  202:     */   {
/*  203: 229 */     return getString("NOADJMADECHOICE");
/*  204:     */   }
/*  205:     */   
/*  206:     */   public Boolean getNOADJMADECHOICE1()
/*  207:     */   {
/*  208: 234 */     return getBoolean("NOADJMADECHOICE1");
/*  209:     */   }
/*  210:     */   
/*  211:     */   public Boolean getNOADJMADECHOICE2()
/*  212:     */   {
/*  213: 239 */     return getBoolean("NOADJMADECHOICE2");
/*  214:     */   }
/*  215:     */   
/*  216:     */   public Boolean getNOADJMADECHOICE3()
/*  217:     */   {
/*  218: 244 */     return getBoolean("NOADJMADECHOICE3");
/*  219:     */   }
/*  220:     */   
/*  221:     */   public Boolean getNOADJMADECHOICE4()
/*  222:     */   {
/*  223: 249 */     return getBoolean("NOADJMADECHOICE4");
/*  224:     */   }
/*  225:     */   
/*  226:     */   public String getORGID()
/*  227:     */   {
/*  228: 254 */     return getString("ORGID");
/*  229:     */   }
/*  230:     */   
/*  231:     */   public Integer getOUTPUTPRECISION()
/*  232:     */   {
/*  233: 259 */     return getInt("OUTPUTPRECISION");
/*  234:     */   }
/*  235:     */   
/*  236:     */   public Boolean getOUTPUTRANGE()
/*  237:     */   {
/*  238: 264 */     return getBoolean("OUTPUTRANGE");
/*  239:     */   }
/*  240:     */   
/*  241:     */   public String getPLANTYPE()
/*  242:     */   {
/*  243: 269 */     return getString("PLANTYPE");
/*  244:     */   }
/*  245:     */   
/*  246:     */   public Integer getPLUSCWODSINSTRID()
/*  247:     */   {
/*  248: 274 */     return getInt("PLUSCWODSINSTRID");
/*  249:     */   }
/*  250:     */   
/*  251:     */   public String getPROCESSEU()
/*  252:     */   {
/*  253: 279 */     return getString("PROCESSEU");
/*  254:     */   }
/*  255:     */   
/*  256:     */   public String getPROCESSEUFACTOR()
/*  257:     */   {
/*  258: 284 */     return getString("PROCESSEUFACTOR");
/*  259:     */   }
/*  260:     */   
/*  261:     */   public String getPROCESSEUFACTOR_NP()
/*  262:     */   {
/*  263: 289 */     return getString("PROCESSEUFACTOR_NP");
/*  264:     */   }
/*  265:     */   
/*  266:     */   public Integer getREVISIONNUM()
/*  267:     */   {
/*  268: 294 */     return getInt("REVISIONNUM");
/*  269:     */   }
/*  270:     */   
/*  271:     */   public String getRON1LOWERVALUE()
/*  272:     */   {
/*  273: 299 */     return getString("RON1LOWERVALUE");
/*  274:     */   }
/*  275:     */   
/*  276:     */   public String getRON1LOWERVALUE_NP()
/*  277:     */   {
/*  278: 304 */     return getString("RON1LOWERVALUE_NP");
/*  279:     */   }
/*  280:     */   
/*  281:     */   public String getRON1TYPE()
/*  282:     */   {
/*  283: 309 */     return getString("RON1TYPE");
/*  284:     */   }
/*  285:     */   
/*  286:     */   public String getRON1UPPERVALUE()
/*  287:     */   {
/*  288: 314 */     return getString("RON1UPPERVALUE");
/*  289:     */   }
/*  290:     */   
/*  291:     */   public String getRON1UPPERVALUE_NP()
/*  292:     */   {
/*  293: 319 */     return getString("RON1UPPERVALUE_NP");
/*  294:     */   }
/*  295:     */   
/*  296:     */   public String getSITEID()
/*  297:     */   {
/*  298: 324 */     return getString("SITEID");
/*  299:     */   }
/*  300:     */   
/*  301:     */   public Boolean getSQUAREROOT()
/*  302:     */   {
/*  303: 329 */     return getBoolean("SQUAREROOT");
/*  304:     */   }
/*  305:     */   
/*  306:     */   public String getTEMPERATURE()
/*  307:     */   {
/*  308: 334 */     return getString("TEMPERATURE");
/*  309:     */   }
/*  310:     */   
/*  311:     */   public String getTEMPERATUREEU()
/*  312:     */   {
/*  313: 339 */     return getString("TEMPERATUREEU");
/*  314:     */   }
/*  315:     */   
/*  316:     */   public String getTOL1DESCRIPTION()
/*  317:     */   {
/*  318: 344 */     return getString("TOL1DESCRIPTION");
/*  319:     */   }
/*  320:     */   
/*  321:     */   public String getTOL1LOWERVALUE()
/*  322:     */   {
/*  323: 349 */     return getString("TOL1LOWERVALUE");
/*  324:     */   }
/*  325:     */   
/*  326:     */   public String getTOL1LOWERVALUE_NP()
/*  327:     */   {
/*  328: 354 */     return getString("TOL1LOWERVALUE_NP");
/*  329:     */   }
/*  330:     */   
/*  331:     */   public Boolean getTOL1NOADJLIMIT()
/*  332:     */   {
/*  333: 359 */     return getBoolean("TOL1NOADJLIMIT");
/*  334:     */   }
/*  335:     */   
/*  336:     */   public String getTOL1STATUS()
/*  337:     */   {
/*  338: 364 */     return getString("TOL1STATUS");
/*  339:     */   }
/*  340:     */   
/*  341:     */   public String getTOL1SUMDIRECTION()
/*  342:     */   {
/*  343: 369 */     return getString("TOL1SUMDIRECTION");
/*  344:     */   }
/*  345:     */   
/*  346:     */   public String getTOL1SUMEU()
/*  347:     */   {
/*  348: 374 */     return getString("TOL1SUMEU");
/*  349:     */   }
/*  350:     */   
/*  351:     */   public String getTOL1SUMEU_NP()
/*  352:     */   {
/*  353: 379 */     return getString("TOL1SUMEU_NP");
/*  354:     */   }
/*  355:     */   
/*  356:     */   public String getTOL1SUMREAD()
/*  357:     */   {
/*  358: 384 */     return getString("TOL1SUMREAD");
/*  359:     */   }
/*  360:     */   
/*  361:     */   public String getTOL1SUMREAD_NP()
/*  362:     */   {
/*  363: 389 */     return getString("TOL1SUMREAD_NP");
/*  364:     */   }
/*  365:     */   
/*  366:     */   public String getTOL1SUMSPAN()
/*  367:     */   {
/*  368: 394 */     return getString("TOL1SUMSPAN");
/*  369:     */   }
/*  370:     */   
/*  371:     */   public String getTOL1SUMSPAN_NP()
/*  372:     */   {
/*  373: 399 */     return getString("TOL1SUMSPAN_NP");
/*  374:     */   }
/*  375:     */   
/*  376:     */   public String getTOL1SUMURV()
/*  377:     */   {
/*  378: 404 */     return getString("TOL1SUMURV");
/*  379:     */   }
/*  380:     */   
/*  381:     */   public String getTOL1SUMURV_NP()
/*  382:     */   {
/*  383: 409 */     return getString("TOL1SUMURV_NP");
/*  384:     */   }
/*  385:     */   
/*  386:     */   public String getTOL1TYPE()
/*  387:     */   {
/*  388: 414 */     return getString("TOL1TYPE");
/*  389:     */   }
/*  390:     */   
/*  391:     */   public String getTOL1UPPERVALUE()
/*  392:     */   {
/*  393: 419 */     return getString("TOL1UPPERVALUE");
/*  394:     */   }
/*  395:     */   
/*  396:     */   public String getTOL1UPPERVALUE_NP()
/*  397:     */   {
/*  398: 424 */     return getString("TOL1UPPERVALUE_NP");
/*  399:     */   }
/*  400:     */   
/*  401:     */   public String getTOL2DESCRIPTION()
/*  402:     */   {
/*  403: 429 */     return getString("TOL2DESCRIPTION");
/*  404:     */   }
/*  405:     */   
/*  406:     */   public String getTOL2LOWERVALUE()
/*  407:     */   {
/*  408: 434 */     return getString("TOL2LOWERVALUE");
/*  409:     */   }
/*  410:     */   
/*  411:     */   public String getTOL2LOWERVALUE_NP()
/*  412:     */   {
/*  413: 439 */     return getString("TOL2LOWERVALUE_NP");
/*  414:     */   }
/*  415:     */   
/*  416:     */   public Boolean getTOL2NOADJLIMIT()
/*  417:     */   {
/*  418: 444 */     return getBoolean("TOL2NOADJLIMIT");
/*  419:     */   }
/*  420:     */   
/*  421:     */   public String getTOL2STATUS()
/*  422:     */   {
/*  423: 449 */     return getString("TOL2STATUS");
/*  424:     */   }
/*  425:     */   
/*  426:     */   public String getTOL2SUMDIRECTION()
/*  427:     */   {
/*  428: 454 */     return getString("TOL2SUMDIRECTION");
/*  429:     */   }
/*  430:     */   
/*  431:     */   public String getTOL2SUMEU()
/*  432:     */   {
/*  433: 459 */     return getString("TOL2SUMEU");
/*  434:     */   }
/*  435:     */   
/*  436:     */   public String getTOL2SUMEU_NP()
/*  437:     */   {
/*  438: 464 */     return getString("TOL2SUMEU_NP");
/*  439:     */   }
/*  440:     */   
/*  441:     */   public String getTOL2SUMREAD()
/*  442:     */   {
/*  443: 469 */     return getString("TOL2SUMREAD");
/*  444:     */   }
/*  445:     */   
/*  446:     */   public String getTOL2SUMREAD_NP()
/*  447:     */   {
/*  448: 474 */     return getString("TOL2SUMREAD_NP");
/*  449:     */   }
/*  450:     */   
/*  451:     */   public String getTOL2SUMSPAN()
/*  452:     */   {
/*  453: 479 */     return getString("TOL2SUMSPAN");
/*  454:     */   }
/*  455:     */   
/*  456:     */   public String getTOL2SUMSPAN_NP()
/*  457:     */   {
/*  458: 484 */     return getString("TOL2SUMSPAN_NP");
/*  459:     */   }
/*  460:     */   
/*  461:     */   public String getTOL2SUMURV()
/*  462:     */   {
/*  463: 489 */     return getString("TOL2SUMURV");
/*  464:     */   }
/*  465:     */   
/*  466:     */   public String getTOL2SUMURV_NP()
/*  467:     */   {
/*  468: 494 */     return getString("TOL2SUMURV_NP");
/*  469:     */   }
/*  470:     */   
/*  471:     */   public String getTOL2TYPE()
/*  472:     */   {
/*  473: 499 */     return getString("TOL2TYPE");
/*  474:     */   }
/*  475:     */   
/*  476:     */   public String getTOL2UPPERVALUE()
/*  477:     */   {
/*  478: 504 */     return getString("TOL2UPPERVALUE");
/*  479:     */   }
/*  480:     */   
/*  481:     */   public String getTOL2UPPERVALUE_NP()
/*  482:     */   {
/*  483: 509 */     return getString("TOL2UPPERVALUE_NP");
/*  484:     */   }
/*  485:     */   
/*  486:     */   public String getTOL3DESCRIPTION()
/*  487:     */   {
/*  488: 514 */     return getString("TOL3DESCRIPTION");
/*  489:     */   }
/*  490:     */   
/*  491:     */   public String getTOL3LOWERVALUE()
/*  492:     */   {
/*  493: 519 */     return getString("TOL3LOWERVALUE");
/*  494:     */   }
/*  495:     */   
/*  496:     */   public String getTOL3LOWERVALUE_NP()
/*  497:     */   {
/*  498: 524 */     return getString("TOL3LOWERVALUE_NP");
/*  499:     */   }
/*  500:     */   
/*  501:     */   public Boolean getTOL3NOADJLIMIT()
/*  502:     */   {
/*  503: 529 */     return getBoolean("TOL3NOADJLIMIT");
/*  504:     */   }
/*  505:     */   
/*  506:     */   public String getTOL3STATUS()
/*  507:     */   {
/*  508: 534 */     return getString("TOL3STATUS");
/*  509:     */   }
/*  510:     */   
/*  511:     */   public String getTOL3SUMDIRECTION()
/*  512:     */   {
/*  513: 539 */     return getString("TOL3SUMDIRECTION");
/*  514:     */   }
/*  515:     */   
/*  516:     */   public String getTOL3SUMEU()
/*  517:     */   {
/*  518: 544 */     return getString("TOL3SUMEU");
/*  519:     */   }
/*  520:     */   
/*  521:     */   public String getTOL3SUMEU_NP()
/*  522:     */   {
/*  523: 549 */     return getString("TOL3SUMEU_NP");
/*  524:     */   }
/*  525:     */   
/*  526:     */   public String getTOL3SUMREAD()
/*  527:     */   {
/*  528: 554 */     return getString("TOL3SUMREAD");
/*  529:     */   }
/*  530:     */   
/*  531:     */   public String getTOL3SUMREAD_NP()
/*  532:     */   {
/*  533: 559 */     return getString("TOL3SUMREAD_NP");
/*  534:     */   }
/*  535:     */   
/*  536:     */   public String getTOL3SUMSPAN()
/*  537:     */   {
/*  538: 564 */     return getString("TOL3SUMSPAN");
/*  539:     */   }
/*  540:     */   
/*  541:     */   public String getTOL3SUMSPAN_NP()
/*  542:     */   {
/*  543: 569 */     return getString("TOL3SUMSPAN_NP");
/*  544:     */   }
/*  545:     */   
/*  546:     */   public String getTOL3SUMURV()
/*  547:     */   {
/*  548: 574 */     return getString("TOL3SUMURV");
/*  549:     */   }
/*  550:     */   
/*  551:     */   public String getTOL3SUMURV_NP()
/*  552:     */   {
/*  553: 579 */     return getString("TOL3SUMURV_NP");
/*  554:     */   }
/*  555:     */   
/*  556:     */   public String getTOL3TYPE()
/*  557:     */   {
/*  558: 584 */     return getString("TOL3TYPE");
/*  559:     */   }
/*  560:     */   
/*  561:     */   public String getTOL3UPPERVALUE()
/*  562:     */   {
/*  563: 589 */     return getString("TOL3UPPERVALUE");
/*  564:     */   }
/*  565:     */   
/*  566:     */   public String getTOL3UPPERVALUE_NP()
/*  567:     */   {
/*  568: 594 */     return getString("TOL3UPPERVALUE_NP");
/*  569:     */   }
/*  570:     */   
/*  571:     */   public String getTOL4DESCRIPTION()
/*  572:     */   {
/*  573: 599 */     return getString("TOL4DESCRIPTION");
/*  574:     */   }
/*  575:     */   
/*  576:     */   public String getTOL4LOWERVALUE()
/*  577:     */   {
/*  578: 604 */     return getString("TOL4LOWERVALUE");
/*  579:     */   }
/*  580:     */   
/*  581:     */   public String getTOL4LOWERVALUE_NP()
/*  582:     */   {
/*  583: 609 */     return getString("TOL4LOWERVALUE_NP");
/*  584:     */   }
/*  585:     */   
/*  586:     */   public Boolean getTOL4NOADJLIMIT()
/*  587:     */   {
/*  588: 614 */     return getBoolean("TOL4NOADJLIMIT");
/*  589:     */   }
/*  590:     */   
/*  591:     */   public String getTOL4STATUS()
/*  592:     */   {
/*  593: 619 */     return getString("TOL4STATUS");
/*  594:     */   }
/*  595:     */   
/*  596:     */   public String getTOL4SUMDIRECTION()
/*  597:     */   {
/*  598: 624 */     return getString("TOL4SUMDIRECTION");
/*  599:     */   }
/*  600:     */   
/*  601:     */   public String getTOL4SUMEU()
/*  602:     */   {
/*  603: 629 */     return getString("TOL4SUMEU");
/*  604:     */   }
/*  605:     */   
/*  606:     */   public String getTOL4SUMEU_NP()
/*  607:     */   {
/*  608: 634 */     return getString("TOL4SUMEU_NP");
/*  609:     */   }
/*  610:     */   
/*  611:     */   public String getTOL4SUMREAD()
/*  612:     */   {
/*  613: 639 */     return getString("TOL4SUMREAD");
/*  614:     */   }
/*  615:     */   
/*  616:     */   public String getTOL4SUMREAD_NP()
/*  617:     */   {
/*  618: 644 */     return getString("TOL4SUMREAD_NP");
/*  619:     */   }
/*  620:     */   
/*  621:     */   public String getTOL4SUMSPAN()
/*  622:     */   {
/*  623: 649 */     return getString("TOL4SUMSPAN");
/*  624:     */   }
/*  625:     */   
/*  626:     */   public String getTOL4SUMSPAN_NP()
/*  627:     */   {
/*  628: 654 */     return getString("TOL4SUMSPAN_NP");
/*  629:     */   }
/*  630:     */   
/*  631:     */   public String getTOL4SUMURV()
/*  632:     */   {
/*  633: 659 */     return getString("TOL4SUMURV");
/*  634:     */   }
/*  635:     */   
/*  636:     */   public String getTOL4SUMURV_NP()
/*  637:     */   {
/*  638: 664 */     return getString("TOL4SUMURV_NP");
/*  639:     */   }
/*  640:     */   
/*  641:     */   public String getTOL4TYPE()
/*  642:     */   {
/*  643: 669 */     return getString("TOL4TYPE");
/*  644:     */   }
/*  645:     */   
/*  646:     */   public String getTOL4UPPERVALUE()
/*  647:     */   {
/*  648: 674 */     return getString("TOL4UPPERVALUE");
/*  649:     */   }
/*  650:     */   
/*  651:     */   public String getTOL4UPPERVALUE_NP()
/*  652:     */   {
/*  653: 679 */     return getString("TOL4UPPERVALUE_NP");
/*  654:     */   }
/*  655:     */   
/*  656:     */   public String getWONUM()
/*  657:     */   {
/*  658: 684 */     return getString("WONUM");
/*  659:     */   }
/*  660:     */   
/*  661:     */   public Boolean getMANUAL()
/*  662:     */   {
/*  663: 689 */     return getBoolean("MANUAL");
/*  664:     */   }
/*  665:     */   
/*  666:     */   public Boolean getCALPOINT()
/*  667:     */   {
/*  668: 694 */     return getBoolean("CALPOINT");
/*  669:     */   }
/*  670:     */   
/*  671:     */   public Boolean getCALFUNCTION()
/*  672:     */   {
/*  673: 699 */     return getBoolean("CALFUNCTION");
/*  674:     */   }
/*  675:     */   
/*  676:     */   public Boolean getCALDYNAMIC()
/*  677:     */   {
/*  678: 704 */     return getBoolean("CALDYNAMIC");
/*  679:     */   }
/*  680:     */   
/*  681:     */   public Boolean getNONLINEAR()
/*  682:     */   {
/*  683: 709 */     return getBoolean("NONLINEAR");
/*  684:     */   }
/*  685:     */   
/*  686:     */   public Boolean getREPEATABLE()
/*  687:     */   {
/*  688: 714 */     return getBoolean("REPEATABLE");
/*  689:     */   }
/*  690:     */   
/*  691:     */   public Boolean getSQUARED()
/*  692:     */   {
/*  693: 719 */     return getBoolean("SQUARED");
/*  694:     */   }
/*  695:     */   
/*  696:     */   public Boolean getCLIPLIMITSIN()
/*  697:     */   {
/*  698: 724 */     return getBoolean("CLIPLIMITSIN");
/*  699:     */   }
/*  700:     */   
/*  701:     */   public Integer getASFOUNDERROR()
/*  702:     */   {
/*  703: 729 */     return getInt("ASFOUNDERROR");
/*  704:     */   }
/*  705:     */   
/*  706:     */   public Integer getASLEFTERROR()
/*  707:     */   {
/*  708: 733 */     return getInt("ASFOUNDERROR");
/*  709:     */   }
/*  710:     */   
/*  711:     */   public void setALLOWPOINTINSERTS(Boolean allowpointinserts)
/*  712:     */   {
/*  713: 737 */     setValue("ALLOWPOINTINSERTS", allowpointinserts, false);
/*  714:     */   }
/*  715:     */   
/*  716:     */   public void setASFOUNDCALSTATUS(String asfoundcalstatus)
/*  717:     */   {
/*  718: 742 */     setValue("ASFOUNDCALSTATUS", asfoundcalstatus, false);
/*  719:     */   }
/*  720:     */   
/*  721:     */   public void setASFOUNDCOMMENTS(String asfoundcomments)
/*  722:     */   {
/*  723: 747 */     setValue("ASFOUNDCOMMENTS", asfoundcomments, false);
/*  724:     */   }
/*  725:     */   
/*  726:     */   public void setASLEFTCALSTATUS(String asleftcalstatus)
/*  727:     */   {
/*  728: 752 */     setValue("ASLEFTCALSTATUS", asleftcalstatus, false);
/*  729:     */   }
/*  730:     */   
/*  731:     */   public void setASLEFTCOMMENTS(String asleftcomments)
/*  732:     */   {
/*  733: 757 */     setValue("ASLEFTCOMMENTS", asleftcomments, false);
/*  734:     */   }
/*  735:     */   
/*  736:     */   public void setASSETFUNCTION(Integer assetfunction)
/*  737:     */   {
/*  738: 762 */     setValue("ASSETFUNCTION", assetfunction, false);
/*  739:     */   }
/*  740:     */   
/*  741:     */   public void setASSETNUM(String assetnum)
/*  742:     */   {
/*  743: 767 */     setValue("ASSETNUM", assetnum, false);
/*  744:     */   }
/*  745:     */   
/*  746:     */   public void setBAROPRESSURE(String baropressure)
/*  747:     */   {
/*  748: 772 */     setValue("BAROPRESSURE", baropressure, false);
/*  749:     */   }
/*  750:     */   
/*  751:     */   public void setBAROPRESSUREEU(String baropressureeu)
/*  752:     */   {
/*  753: 777 */     setValue("BAROPRESSUREEU", baropressureeu, false);
/*  754:     */   }
/*  755:     */   
/*  756:     */   public void setCLIPLIMITS(Boolean cliplimits)
/*  757:     */   {
/*  758: 782 */     setValue("CLIPLIMITS", cliplimits, false);
/*  759:     */   }
/*  760:     */   
/*  761:     */   public void setDESCRIPTION(String description)
/*  762:     */   {
/*  763: 787 */     setValue("DESCRIPTION", description, false);
/*  764:     */   }
/*  765:     */   
/*  766:     */   public void setDSPLANNUM(String dsplannum)
/*  767:     */   {
/*  768: 792 */     setValue("DSPLANNUM", dsplannum, false);
/*  769:     */   }
/*  770:     */   
/*  771:     */   public void setHASLD(Boolean hasld)
/*  772:     */   {
/*  773: 797 */     setValue("HASLD", hasld, false);
/*  774:     */   }
/*  775:     */   
/*  776:     */   public void setHUMIDITY(String humidity)
/*  777:     */   {
/*  778: 802 */     setValue("HUMIDITY", humidity, false);
/*  779:     */   }
/*  780:     */   
/*  781:     */   public void setHUMIDITYEU(String humidityeu)
/*  782:     */   {
/*  783: 807 */     setValue("HUMIDITYEU", humidityeu, false);
/*  784:     */   }
/*  785:     */   
/*  786:     */   public void setINPUTPRECISION(Integer inputprecision)
/*  787:     */   {
/*  788: 812 */     setValue("INPUTPRECISION", inputprecision, false);
/*  789:     */   }
/*  790:     */   
/*  791:     */   public void setINPUTRANGE(Boolean inputrange)
/*  792:     */   {
/*  793: 817 */     setValue("INPUTRANGE", inputrange, false);
/*  794:     */   }
/*  795:     */   
/*  796:     */   public void setINSTRCALRANGEEU(String instrcalrangeeu)
/*  797:     */   {
/*  798: 822 */     setValue("INSTRCALRANGEEU", instrcalrangeeu, false);
/*  799:     */   }
/*  800:     */   
/*  801:     */   public void setINSTRCALRANGEFROM(String instrcalrangefrom)
/*  802:     */   {
/*  803: 827 */     setValue("INSTRCALRANGEFROM", instrcalrangefrom, false);
/*  804:     */   }
/*  805:     */   
/*  806:     */   public void setINSTRCALRANGEFROM_NP(String instrcalrangefrom_np)
/*  807:     */   {
/*  808: 832 */     setValue("INSTRCALRANGEFROM_NP", instrcalrangefrom_np, false);
/*  809:     */   }
/*  810:     */   
/*  811:     */   public void setINSTRCALRANGETO(String instrcalrangeto)
/*  812:     */   {
/*  813: 837 */     setValue("INSTRCALRANGETO", instrcalrangeto, false);
/*  814:     */   }
/*  815:     */   
/*  816:     */   public void setINSTRCALRANGETO_NP(String instrcalrangeto_np)
/*  817:     */   {
/*  818: 842 */     setValue("INSTRCALRANGETO_NP", instrcalrangeto_np, false);
/*  819:     */   }
/*  820:     */   
/*  821:     */   public void setINSTROUTRANGEEU(String instroutrangeeu)
/*  822:     */   {
/*  823: 847 */     setValue("INSTROUTRANGEEU", instroutrangeeu, false);
/*  824:     */   }
/*  825:     */   
/*  826:     */   public void setINSTROUTRANGEFROM(String instroutrangefrom)
/*  827:     */   {
/*  828: 852 */     setValue("INSTROUTRANGEFROM", instroutrangefrom, false);
/*  829:     */   }
/*  830:     */   
/*  831:     */   public void setINSTROUTRANGEFROM_NP(String instroutrangefrom_np)
/*  832:     */   {
/*  833: 857 */     setValue("INSTROUTRANGEFROM_NP", instroutrangefrom_np, false);
/*  834:     */   }
/*  835:     */   
/*  836:     */   public void setINSTROUTRANGETO(String instroutrangeto)
/*  837:     */   {
/*  838: 862 */     setValue("INSTROUTRANGETO", instroutrangeto, false);
/*  839:     */   }
/*  840:     */   
/*  841:     */   public void setINSTROUTRANGETO_NP(String instroutrangeto_np)
/*  842:     */   {
/*  843: 867 */     setValue("INSTROUTRANGETO_NP", instroutrangeto_np, false);
/*  844:     */   }
/*  845:     */   
/*  846:     */   public void setINSTRSEQ(Integer instrseq)
/*  847:     */   {
/*  848: 872 */     setValue("INSTRSEQ", instrseq, false);
/*  849:     */   }
/*  850:     */   
/*  851:     */   public void setLANGCODE(String langcode)
/*  852:     */   {
/*  853: 877 */     setValue("LANGCODE", langcode, false);
/*  854:     */   }
/*  855:     */   
/*  856:     */   public void setLDKEY(Integer ldkey)
/*  857:     */   {
/*  858: 882 */     setValue("LDKEY", ldkey, false);
/*  859:     */   }
/*  860:     */   
/*  861:     */   public void setNEXTDATE(Date nextdate)
/*  862:     */   {
/*  863: 887 */     setValue("NEXTDATE", nextdate, false);
/*  864:     */   }
/*  865:     */   
/*  866:     */   public void setNOADJMADE(Boolean noadjmade)
/*  867:     */   {
/*  868: 892 */     setValue("NOADJMADE", noadjmade, false);
/*  869:     */   }
/*  870:     */   
/*  871:     */   public void setNOADJMADECHOICE(String noadjmadechoice)
/*  872:     */   {
/*  873: 897 */     setValue("NOADJMADECHOICE", noadjmadechoice, false);
/*  874:     */   }
/*  875:     */   
/*  876:     */   public void setNOADJMADECHOICE1(Boolean noadjmadechoice1)
/*  877:     */   {
/*  878: 902 */     setValue("NOADJMADECHOICE1", noadjmadechoice1, false);
/*  879:     */   }
/*  880:     */   
/*  881:     */   public void setNOADJMADECHOICE2(Boolean noadjmadechoice2)
/*  882:     */   {
/*  883: 907 */     setValue("NOADJMADECHOICE2", noadjmadechoice2, false);
/*  884:     */   }
/*  885:     */   
/*  886:     */   public void setNOADJMADECHOICE3(Boolean noadjmadechoice3)
/*  887:     */   {
/*  888: 912 */     setValue("NOADJMADECHOICE3", noadjmadechoice3, false);
/*  889:     */   }
/*  890:     */   
/*  891:     */   public void setNOADJMADECHOICE4(Boolean noadjmadechoice4)
/*  892:     */   {
/*  893: 917 */     setValue("NOADJMADECHOICE4", noadjmadechoice4, false);
/*  894:     */   }
/*  895:     */   
/*  896:     */   public void setORGID(String orgid)
/*  897:     */   {
/*  898: 922 */     setValue("ORGID", orgid, false);
/*  899:     */   }
/*  900:     */   
/*  901:     */   public void setOUTPUTPRECISION(Integer outputprecision)
/*  902:     */   {
/*  903: 927 */     setValue("OUTPUTPRECISION", outputprecision, false);
/*  904:     */   }
/*  905:     */   
/*  906:     */   public void setOUTPUTRANGE(Boolean outputrange)
/*  907:     */   {
/*  908: 932 */     setValue("OUTPUTRANGE", outputrange, false);
/*  909:     */   }
/*  910:     */   
/*  911:     */   public void setPLANTYPE(String plantype)
/*  912:     */   {
/*  913: 937 */     setValue("PLANTYPE", plantype, false);
/*  914:     */   }
/*  915:     */   
/*  916:     */   public void setPLUSCWODSINSTRID(Integer pluscwodsinstrid)
/*  917:     */   {
/*  918: 942 */     setValue("PLUSCWODSINSTRID", pluscwodsinstrid, false);
/*  919:     */   }
/*  920:     */   
/*  921:     */   public void setPROCESSEU(String processeu)
/*  922:     */   {
/*  923: 947 */     setValue("PROCESSEU", processeu, false);
/*  924:     */   }
/*  925:     */   
/*  926:     */   public void setPROCESSEUFACTOR(String processeufactor)
/*  927:     */   {
/*  928: 952 */     setValue("PROCESSEUFACTOR", processeufactor, false);
/*  929:     */   }
/*  930:     */   
/*  931:     */   public void setPROCESSEUFACTOR_NP(String processeufactor_np)
/*  932:     */   {
/*  933: 957 */     setValue("PROCESSEUFACTOR_NP", processeufactor_np, false);
/*  934:     */   }
/*  935:     */   
/*  936:     */   public void setREVISIONNUM(Integer revisionnum)
/*  937:     */   {
/*  938: 962 */     setValue("REVISIONNUM", revisionnum, false);
/*  939:     */   }
/*  940:     */   
/*  941:     */   public void setRON1LOWERVALUE(String ron1lowervalue)
/*  942:     */   {
/*  943: 967 */     setValue("RON1LOWERVALUE", ron1lowervalue, false);
/*  944:     */   }
/*  945:     */   
/*  946:     */   public void setRON1LOWERVALUE_NP(String ron1lowervalue_np)
/*  947:     */   {
/*  948: 972 */     setValue("RON1LOWERVALUE_NP", ron1lowervalue_np, false);
/*  949:     */   }
/*  950:     */   
/*  951:     */   public void setRON1TYPE(String ron1type)
/*  952:     */   {
/*  953: 977 */     setValue("RON1TYPE", ron1type, false);
/*  954:     */   }
/*  955:     */   
/*  956:     */   public void setRON1UPPERVALUE(String ron1uppervalue)
/*  957:     */   {
/*  958: 982 */     setValue("RON1UPPERVALUE", ron1uppervalue, false);
/*  959:     */   }
/*  960:     */   
/*  961:     */   public void setRON1UPPERVALUE_NP(String ron1uppervalue_np)
/*  962:     */   {
/*  963: 987 */     setValue("RON1UPPERVALUE_NP", ron1uppervalue_np, false);
/*  964:     */   }
/*  965:     */   
/*  966:     */   public void setSITEID(String siteid)
/*  967:     */   {
/*  968: 992 */     setValue("SITEID", siteid, false);
/*  969:     */   }
/*  970:     */   
/*  971:     */   public void setSQUAREROOT(Boolean squareroot)
/*  972:     */   {
/*  973: 997 */     setValue("SQUAREROOT", squareroot, false);
/*  974:     */   }
/*  975:     */   
/*  976:     */   public void setTEMPERATURE(String temperature)
/*  977:     */   {
/*  978:1002 */     setValue("TEMPERATURE", temperature, false);
/*  979:     */   }
/*  980:     */   
/*  981:     */   public void setTEMPERATUREEU(String temperatureeu)
/*  982:     */   {
/*  983:1007 */     setValue("TEMPERATUREEU", temperatureeu, false);
/*  984:     */   }
/*  985:     */   
/*  986:     */   public void setTOL1DESCRIPTION(String tol1description)
/*  987:     */   {
/*  988:1012 */     setValue("TOL1DESCRIPTION", tol1description, false);
/*  989:     */   }
/*  990:     */   
/*  991:     */   public void setTOL1LOWERVALUE(String tol1lowervalue)
/*  992:     */   {
/*  993:1017 */     setValue("TOL1LOWERVALUE", tol1lowervalue, false);
/*  994:     */   }
/*  995:     */   
/*  996:     */   public void setTOL1LOWERVALUE_NP(String tol1lowervalue_np)
/*  997:     */   {
/*  998:1022 */     setValue("TOL1LOWERVALUE_NP", tol1lowervalue_np, false);
/*  999:     */   }
/* 1000:     */   
/* 1001:     */   public void setTOL1NOADJLIMIT(Boolean tol1noadjlimit)
/* 1002:     */   {
/* 1003:1027 */     setValue("TOL1NOADJLIMIT", tol1noadjlimit, false);
/* 1004:     */   }
/* 1005:     */   
/* 1006:     */   public void setTOL1STATUS(String tol1status)
/* 1007:     */   {
/* 1008:1032 */     setValue("TOL1STATUS", tol1status, false);
/* 1009:     */   }
/* 1010:     */   
/* 1011:     */   public void setTOL1SUMDIRECTION(String tol1sumdirection)
/* 1012:     */   {
/* 1013:1037 */     setValue("TOL1SUMDIRECTION", tol1sumdirection, false);
/* 1014:     */   }
/* 1015:     */   
/* 1016:     */   public void setTOL1SUMEU(String tol1sumeu)
/* 1017:     */   {
/* 1018:1042 */     setValue("TOL1SUMEU", tol1sumeu, false);
/* 1019:     */   }
/* 1020:     */   
/* 1021:     */   public void setTOL1SUMEU_NP(String tol1sumeu_np)
/* 1022:     */   {
/* 1023:1047 */     setValue("TOL1SUMEU_NP", tol1sumeu_np, false);
/* 1024:     */   }
/* 1025:     */   
/* 1026:     */   public void setTOL1SUMREAD(String tol1sumread)
/* 1027:     */   {
/* 1028:1052 */     setValue("TOL1SUMREAD", tol1sumread, false);
/* 1029:     */   }
/* 1030:     */   
/* 1031:     */   public void setTOL1SUMREAD_NP(String tol1sumread_np)
/* 1032:     */   {
/* 1033:1057 */     setValue("TOL1SUMREAD_NP", tol1sumread_np, false);
/* 1034:     */   }
/* 1035:     */   
/* 1036:     */   public void setTOL1SUMSPAN(String tol1sumspan)
/* 1037:     */   {
/* 1038:1062 */     setValue("TOL1SUMSPAN", tol1sumspan, false);
/* 1039:     */   }
/* 1040:     */   
/* 1041:     */   public void setTOL1SUMSPAN_NP(String tol1sumspan_np)
/* 1042:     */   {
/* 1043:1067 */     setValue("TOL1SUMSPAN_NP", tol1sumspan_np, false);
/* 1044:     */   }
/* 1045:     */   
/* 1046:     */   public void setTOL1SUMURV(String tol1sumurv)
/* 1047:     */   {
/* 1048:1072 */     setValue("TOL1SUMURV", tol1sumurv, false);
/* 1049:     */   }
/* 1050:     */   
/* 1051:     */   public void setTOL1SUMURV_NP(String tol1sumurv_np)
/* 1052:     */   {
/* 1053:1077 */     setValue("TOL1SUMURV_NP", tol1sumurv_np, false);
/* 1054:     */   }
/* 1055:     */   
/* 1056:     */   public void setTOL1TYPE(String tol1type)
/* 1057:     */   {
/* 1058:1082 */     setValue("TOL1TYPE", tol1type, false);
/* 1059:     */   }
/* 1060:     */   
/* 1061:     */   public void setTOL1UPPERVALUE(String tol1uppervalue)
/* 1062:     */   {
/* 1063:1087 */     setValue("TOL1UPPERVALUE", tol1uppervalue, false);
/* 1064:     */   }
/* 1065:     */   
/* 1066:     */   public void setTOL1UPPERVALUE_NP(String tol1uppervalue_np)
/* 1067:     */   {
/* 1068:1092 */     setValue("TOL1UPPERVALUE_NP", tol1uppervalue_np, false);
/* 1069:     */   }
/* 1070:     */   
/* 1071:     */   public void setTOL2DESCRIPTION(String tol2description)
/* 1072:     */   {
/* 1073:1097 */     setValue("TOL2DESCRIPTION", tol2description, false);
/* 1074:     */   }
/* 1075:     */   
/* 1076:     */   public void setTOL2LOWERVALUE(String tol2lowervalue)
/* 1077:     */   {
/* 1078:1102 */     setValue("TOL2LOWERVALUE", tol2lowervalue, false);
/* 1079:     */   }
/* 1080:     */   
/* 1081:     */   public void setTOL2LOWERVALUE_NP(String tol2lowervalue_np)
/* 1082:     */   {
/* 1083:1107 */     setValue("TOL2LOWERVALUE_NP", tol2lowervalue_np, false);
/* 1084:     */   }
/* 1085:     */   
/* 1086:     */   public void setTOL2NOADJLIMIT(Boolean tol2noadjlimit)
/* 1087:     */   {
/* 1088:1112 */     setValue("TOL2NOADJLIMIT", tol2noadjlimit, false);
/* 1089:     */   }
/* 1090:     */   
/* 1091:     */   public void setTOL2STATUS(String tol2status)
/* 1092:     */   {
/* 1093:1117 */     setValue("TOL2STATUS", tol2status, false);
/* 1094:     */   }
/* 1095:     */   
/* 1096:     */   public void setTOL2SUMDIRECTION(String tol2sumdirection)
/* 1097:     */   {
/* 1098:1122 */     setValue("TOL2SUMDIRECTION", tol2sumdirection, false);
/* 1099:     */   }
/* 1100:     */   
/* 1101:     */   public void setTOL2SUMEU(String tol2sumeu)
/* 1102:     */   {
/* 1103:1127 */     setValue("TOL2SUMEU", tol2sumeu, false);
/* 1104:     */   }
/* 1105:     */   
/* 1106:     */   public void setTOL2SUMEU_NP(String tol2sumeu_np)
/* 1107:     */   {
/* 1108:1132 */     setValue("TOL2SUMEU_NP", tol2sumeu_np, false);
/* 1109:     */   }
/* 1110:     */   
/* 1111:     */   public void setTOL2SUMREAD(String tol2sumread)
/* 1112:     */   {
/* 1113:1137 */     setValue("TOL2SUMREAD", tol2sumread, false);
/* 1114:     */   }
/* 1115:     */   
/* 1116:     */   public void setTOL2SUMREAD_NP(String tol2sumread_np)
/* 1117:     */   {
/* 1118:1142 */     setValue("TOL2SUMREAD_NP", tol2sumread_np, false);
/* 1119:     */   }
/* 1120:     */   
/* 1121:     */   public void setTOL2SUMSPAN(String tol2sumspan)
/* 1122:     */   {
/* 1123:1147 */     setValue("TOL2SUMSPAN", tol2sumspan, false);
/* 1124:     */   }
/* 1125:     */   
/* 1126:     */   public void setTOL2SUMSPAN_NP(String tol2sumspan_np)
/* 1127:     */   {
/* 1128:1152 */     setValue("TOL2SUMSPAN_NP", tol2sumspan_np, false);
/* 1129:     */   }
/* 1130:     */   
/* 1131:     */   public void setTOL2SUMURV(String tol2sumurv)
/* 1132:     */   {
/* 1133:1157 */     setValue("TOL2SUMURV", tol2sumurv, false);
/* 1134:     */   }
/* 1135:     */   
/* 1136:     */   public void setTOL2SUMURV_NP(String tol2sumurv_np)
/* 1137:     */   {
/* 1138:1162 */     setValue("TOL2SUMURV_NP", tol2sumurv_np, false);
/* 1139:     */   }
/* 1140:     */   
/* 1141:     */   public void setTOL2TYPE(String tol2type)
/* 1142:     */   {
/* 1143:1167 */     setValue("TOL2TYPE", tol2type, false);
/* 1144:     */   }
/* 1145:     */   
/* 1146:     */   public void setTOL2UPPERVALUE(String tol2uppervalue)
/* 1147:     */   {
/* 1148:1172 */     setValue("TOL2UPPERVALUE", tol2uppervalue, false);
/* 1149:     */   }
/* 1150:     */   
/* 1151:     */   public void setTOL2UPPERVALUE_NP(String tol2uppervalue_np)
/* 1152:     */   {
/* 1153:1177 */     setValue("TOL2UPPERVALUE_NP", tol2uppervalue_np, false);
/* 1154:     */   }
/* 1155:     */   
/* 1156:     */   public void setTOL3DESCRIPTION(String tol3description)
/* 1157:     */   {
/* 1158:1182 */     setValue("TOL3DESCRIPTION", tol3description, false);
/* 1159:     */   }
/* 1160:     */   
/* 1161:     */   public void setTOL3LOWERVALUE(String tol3lowervalue)
/* 1162:     */   {
/* 1163:1187 */     setValue("TOL3LOWERVALUE", tol3lowervalue, false);
/* 1164:     */   }
/* 1165:     */   
/* 1166:     */   public void setTOL3LOWERVALUE_NP(String tol3lowervalue_np)
/* 1167:     */   {
/* 1168:1192 */     setValue("TOL3LOWERVALUE_NP", tol3lowervalue_np, false);
/* 1169:     */   }
/* 1170:     */   
/* 1171:     */   public void setTOL3NOADJLIMIT(Boolean tol3noadjlimit)
/* 1172:     */   {
/* 1173:1197 */     setValue("TOL3NOADJLIMIT", tol3noadjlimit, false);
/* 1174:     */   }
/* 1175:     */   
/* 1176:     */   public void setTOL3STATUS(String tol3status)
/* 1177:     */   {
/* 1178:1202 */     setValue("TOL3STATUS", tol3status, false);
/* 1179:     */   }
/* 1180:     */   
/* 1181:     */   public void setTOL3SUMDIRECTION(String tol3sumdirection)
/* 1182:     */   {
/* 1183:1207 */     setValue("TOL3SUMDIRECTION", tol3sumdirection, false);
/* 1184:     */   }
/* 1185:     */   
/* 1186:     */   public void setTOL3SUMEU(String tol3sumeu)
/* 1187:     */   {
/* 1188:1212 */     setValue("TOL3SUMEU", tol3sumeu, false);
/* 1189:     */   }
/* 1190:     */   
/* 1191:     */   public void setTOL3SUMEU_NP(String tol3sumeu_np)
/* 1192:     */   {
/* 1193:1217 */     setValue("TOL3SUMEU_NP", tol3sumeu_np, false);
/* 1194:     */   }
/* 1195:     */   
/* 1196:     */   public void setTOL3SUMREAD(String tol3sumread)
/* 1197:     */   {
/* 1198:1222 */     setValue("TOL3SUMREAD", tol3sumread, false);
/* 1199:     */   }
/* 1200:     */   
/* 1201:     */   public void setTOL3SUMREAD_NP(String tol3sumread_np)
/* 1202:     */   {
/* 1203:1227 */     setValue("TOL3SUMREAD_NP", tol3sumread_np, false);
/* 1204:     */   }
/* 1205:     */   
/* 1206:     */   public void setTOL3SUMSPAN(String tol3sumspan)
/* 1207:     */   {
/* 1208:1232 */     setValue("TOL3SUMSPAN", tol3sumspan, false);
/* 1209:     */   }
/* 1210:     */   
/* 1211:     */   public void setTOL3SUMSPAN_NP(String tol3sumspan_np)
/* 1212:     */   {
/* 1213:1237 */     setValue("TOL3SUMSPAN_NP", tol3sumspan_np, false);
/* 1214:     */   }
/* 1215:     */   
/* 1216:     */   public void setTOL3SUMURV(String tol3sumurv)
/* 1217:     */   {
/* 1218:1242 */     setValue("TOL3SUMURV", tol3sumurv, false);
/* 1219:     */   }
/* 1220:     */   
/* 1221:     */   public void setTOL3SUMURV_NP(String tol3sumurv_np)
/* 1222:     */   {
/* 1223:1247 */     setValue("TOL3SUMURV_NP", tol3sumurv_np, false);
/* 1224:     */   }
/* 1225:     */   
/* 1226:     */   public void setTOL3TYPE(String tol3type)
/* 1227:     */   {
/* 1228:1252 */     setValue("TOL3TYPE", tol3type, false);
/* 1229:     */   }
/* 1230:     */   
/* 1231:     */   public void setTOL3UPPERVALUE(String tol3uppervalue)
/* 1232:     */   {
/* 1233:1257 */     setValue("TOL3UPPERVALUE", tol3uppervalue, false);
/* 1234:     */   }
/* 1235:     */   
/* 1236:     */   public void setTOL3UPPERVALUE_NP(String tol3uppervalue_np)
/* 1237:     */   {
/* 1238:1262 */     setValue("TOL3UPPERVALUE_NP", tol3uppervalue_np, false);
/* 1239:     */   }
/* 1240:     */   
/* 1241:     */   public void setTOL4DESCRIPTION(String tol4description)
/* 1242:     */   {
/* 1243:1267 */     setValue("TOL4DESCRIPTION", tol4description, false);
/* 1244:     */   }
/* 1245:     */   
/* 1246:     */   public void setTOL4LOWERVALUE(String tol4lowervalue)
/* 1247:     */   {
/* 1248:1272 */     setValue("TOL4LOWERVALUE", tol4lowervalue, false);
/* 1249:     */   }
/* 1250:     */   
/* 1251:     */   public void setTOL4LOWERVALUE_NP(String tol4lowervalue_np)
/* 1252:     */   {
/* 1253:1277 */     setValue("TOL4LOWERVALUE_NP", tol4lowervalue_np, false);
/* 1254:     */   }
/* 1255:     */   
/* 1256:     */   public void setTOL4NOADJLIMIT(Boolean tol4noadjlimit)
/* 1257:     */   {
/* 1258:1282 */     setValue("TOL4NOADJLIMIT", tol4noadjlimit, false);
/* 1259:     */   }
/* 1260:     */   
/* 1261:     */   public void setTOL4STATUS(String tol4status)
/* 1262:     */   {
/* 1263:1287 */     setValue("TOL4STATUS", tol4status, false);
/* 1264:     */   }
/* 1265:     */   
/* 1266:     */   public void setTOL4SUMDIRECTION(String tol4sumdirection)
/* 1267:     */   {
/* 1268:1292 */     setValue("TOL4SUMDIRECTION", tol4sumdirection, false);
/* 1269:     */   }
/* 1270:     */   
/* 1271:     */   public void setTOL4SUMEU(String tol4sumeu)
/* 1272:     */   {
/* 1273:1297 */     setValue("TOL4SUMEU", tol4sumeu, false);
/* 1274:     */   }
/* 1275:     */   
/* 1276:     */   public void setTOL4SUMEU_NP(String tol4sumeu_np)
/* 1277:     */   {
/* 1278:1302 */     setValue("TOL4SUMEU_NP", tol4sumeu_np, false);
/* 1279:     */   }
/* 1280:     */   
/* 1281:     */   public void setTOL4SUMREAD(String tol4sumread)
/* 1282:     */   {
/* 1283:1307 */     setValue("TOL4SUMREAD", tol4sumread, false);
/* 1284:     */   }
/* 1285:     */   
/* 1286:     */   public void setTOL4SUMREAD_NP(String tol4sumread_np)
/* 1287:     */   {
/* 1288:1312 */     setValue("TOL4SUMREAD_NP", tol4sumread_np, false);
/* 1289:     */   }
/* 1290:     */   
/* 1291:     */   public void setTOL4SUMSPAN(String tol4sumspan)
/* 1292:     */   {
/* 1293:1317 */     setValue("TOL4SUMSPAN", tol4sumspan, false);
/* 1294:     */   }
/* 1295:     */   
/* 1296:     */   public void setTOL4SUMSPAN_NP(String tol4sumspan_np)
/* 1297:     */   {
/* 1298:1322 */     setValue("TOL4SUMSPAN_NP", tol4sumspan_np, false);
/* 1299:     */   }
/* 1300:     */   
/* 1301:     */   public void setTOL4SUMURV(String tol4sumurv)
/* 1302:     */   {
/* 1303:1327 */     setValue("TOL4SUMURV", tol4sumurv, false);
/* 1304:     */   }
/* 1305:     */   
/* 1306:     */   public void setTOL4SUMURV_NP(String tol4sumurv_np)
/* 1307:     */   {
/* 1308:1332 */     setValue("TOL4SUMURV_NP", tol4sumurv_np, false);
/* 1309:     */   }
/* 1310:     */   
/* 1311:     */   public void setTOL4TYPE(String tol4type)
/* 1312:     */   {
/* 1313:1337 */     setValue("TOL4TYPE", tol4type, false);
/* 1314:     */   }
/* 1315:     */   
/* 1316:     */   public void setTOL4UPPERVALUE(String tol4uppervalue)
/* 1317:     */   {
/* 1318:1342 */     setValue("TOL4UPPERVALUE", tol4uppervalue, false);
/* 1319:     */   }
/* 1320:     */   
/* 1321:     */   public void setTOL4UPPERVALUE_NP(String tol4uppervalue_np)
/* 1322:     */   {
/* 1323:1347 */     setValue("TOL4UPPERVALUE_NP", tol4uppervalue_np, false);
/* 1324:     */   }
/* 1325:     */   
/* 1326:     */   public void setWONUM(String wonum)
/* 1327:     */   {
/* 1328:1352 */     setValue("WONUM", wonum, false);
/* 1329:     */   }
/* 1330:     */   
/* 1331:     */   public void setCALPOINT(Boolean calpoint)
/* 1332:     */   {
/* 1333:1357 */     setValue("CALPOINT", calpoint, false);
/* 1334:     */   }
/* 1335:     */   
/* 1336:     */   public void setCALFUNCTION(Boolean calfunction)
/* 1337:     */   {
/* 1338:1362 */     setValue("CALFUNCTION", calfunction, false);
/* 1339:     */   }
/* 1340:     */   
/* 1341:     */   public void setCALDYNAMIC(Boolean caldynamic)
/* 1342:     */   {
/* 1343:1367 */     setValue("CALDYNAMIC", caldynamic, false);
/* 1344:     */   }
/* 1345:     */   
/* 1346:     */   public void setNONLINEAR(Boolean nonlinear)
/* 1347:     */   {
/* 1348:1372 */     setValue("NONLINEAR", nonlinear, false);
/* 1349:     */   }
/* 1350:     */   
/* 1351:     */   public void setREPEATABLE(Boolean repeatable)
/* 1352:     */   {
/* 1353:1377 */     setValue("REPEATABLE", repeatable, false);
/* 1354:     */   }
/* 1355:     */   
/* 1356:     */   public void setMANUAL(Boolean manual)
/* 1357:     */   {
/* 1358:1382 */     setValue("MANUAL", manual, false);
/* 1359:     */   }
/* 1360:     */   
/* 1361:     */   public void setSQUARED(Boolean squared)
/* 1362:     */   {
/* 1363:1387 */     setValue("SQUARED", squared, false);
/* 1364:     */   }
/* 1365:     */   
/* 1366:     */   public void setCLIPLIMITSIN(Boolean cliplimitsin)
/* 1367:     */   {
/* 1368:1392 */     setValue("CLIPLIMITSIN", cliplimitsin, false);
/* 1369:     */   }
/* 1370:     */   
/* 1371:     */   public void setASFOUNDERROR(Integer asfounderror)
/* 1372:     */   {
/* 1373:1397 */     setValue("ASFOUNDERROR", asfounderror, false);
/* 1374:     */   }
/* 1375:     */   
/* 1376:     */   public void setASLEFTERROR(Integer aslefterror)
/* 1377:     */   {
/* 1378:1402 */     setValue("ASLEFTERROR", aslefterror, false);
/* 1379:     */   }
/* 1380:     */   
/* 1381:     */   public String getGBFROM1()
/* 1382:     */   {
/* 1383:1408 */     return getString("GBFROM1");
/* 1384:     */   }
/* 1385:     */   
/* 1386:     */   public String getGBFROM2()
/* 1387:     */   {
/* 1388:1412 */     return getString("GBFROM2");
/* 1389:     */   }
/* 1390:     */   
/* 1391:     */   public String getGBFROM3()
/* 1392:     */   {
/* 1393:1416 */     return getString("GBFROM3");
/* 1394:     */   }
/* 1395:     */   
/* 1396:     */   public String getGBFROM4()
/* 1397:     */   {
/* 1398:1420 */     return getString("GBFROM4");
/* 1399:     */   }
/* 1400:     */   
/* 1401:     */   public String getGBTO1()
/* 1402:     */   {
/* 1403:1424 */     return getString("GBTO1");
/* 1404:     */   }
/* 1405:     */   
/* 1406:     */   public String getGBTO2()
/* 1407:     */   {
/* 1408:1428 */     return getString("GBTO2");
/* 1409:     */   }
/* 1410:     */   
/* 1411:     */   public String getGBTO3()
/* 1412:     */   {
/* 1413:1432 */     return getString("GBTO3");
/* 1414:     */   }
/* 1415:     */   
/* 1416:     */   public String getGBTO4()
/* 1417:     */   {
/* 1418:1436 */     return getString("GBTO4");
/* 1419:     */   }
/* 1420:     */   
/* 1421:     */   public String getGBSUMDIRECTION1()
/* 1422:     */   {
/* 1423:1440 */     return getString("GBSUMDIRECTION1");
/* 1424:     */   }
/* 1425:     */   
/* 1426:     */   public String getGBSUMDIRECTION2()
/* 1427:     */   {
/* 1428:1444 */     return getString("GBSUMDIRECTION2");
/* 1429:     */   }
/* 1430:     */   
/* 1431:     */   public String getGBSUMDIRECTION3()
/* 1432:     */   {
/* 1433:1448 */     return getString("GBSUMDIRECTION3");
/* 1434:     */   }
/* 1435:     */   
/* 1436:     */   public String getGBSUMDIRECTION4()
/* 1437:     */   {
/* 1438:1452 */     return getString("GBSUMDIRECTION4");
/* 1439:     */   }
/* 1440:     */   
/* 1441:     */   public void setGBFROM1(String gbfrom1)
/* 1442:     */   {
/* 1443:1456 */     setValue("GBFROM1", gbfrom1, false);
/* 1444:     */   }
/* 1445:     */   
/* 1446:     */   public void setGBFROM2(String gbfrom2)
/* 1447:     */   {
/* 1448:1460 */     setValue("GBFROM2", gbfrom2, false);
/* 1449:     */   }
/* 1450:     */   
/* 1451:     */   public void setGBFROM3(String gbfrom3)
/* 1452:     */   {
/* 1453:1464 */     setValue("GBFROM3", gbfrom3, false);
/* 1454:     */   }
/* 1455:     */   
/* 1456:     */   public void setGBFROM4(String gbfrom4)
/* 1457:     */   {
/* 1458:1468 */     setValue("GBFROM4", gbfrom4, false);
/* 1459:     */   }
/* 1460:     */   
/* 1461:     */   public void setGBTO1(String gbto1)
/* 1462:     */   {
/* 1463:1472 */     setValue("GBTO1", gbto1, false);
/* 1464:     */   }
/* 1465:     */   
/* 1466:     */   public void setGBTO2(String gbto2)
/* 1467:     */   {
/* 1468:1476 */     setValue("GBTO2", gbto2, false);
/* 1469:     */   }
/* 1470:     */   
/* 1471:     */   public void setGBTO3(String gbto3)
/* 1472:     */   {
/* 1473:1480 */     setValue("GBTO3", gbto3, false);
/* 1474:     */   }
/* 1475:     */   
/* 1476:     */   public void setGBTO4(String gbto4)
/* 1477:     */   {
/* 1478:1484 */     setValue("GBTO4", gbto4, false);
/* 1479:     */   }
/* 1480:     */   
/* 1481:     */   public void setGBSUMDIRECTION1(String gbsumdirection1)
/* 1482:     */   {
/* 1483:1488 */     setValue("GBSUMDIRECTION1", gbsumdirection1, false);
/* 1484:     */   }
/* 1485:     */   
/* 1486:     */   public void setGBSUMDIRECTION2(String gbsumdirection2)
/* 1487:     */   {
/* 1488:1492 */     setValue("GBSUMDIRECTION2", gbsumdirection2, false);
/* 1489:     */   }
/* 1490:     */   
/* 1491:     */   public void setGBSUMDIRECTION3(String gbsumdirection3)
/* 1492:     */   {
/* 1493:1496 */     setValue("GBSUMDIRECTION3", gbsumdirection3, false);
/* 1494:     */   }
/* 1495:     */   
/* 1496:     */   public void setGBSUMDIRECTION4(String gbsumdirection4)
/* 1497:     */   {
/* 1498:1500 */     setValue("GBSUMDIRECTION4", gbsumdirection4, false);
/* 1499:     */   }
/* 1500:     */   
/* 1501:     */   public void setFieldName(String name)
/* 1502:     */   {
/* 1503:1505 */     this.fieldName = name;
/* 1504:     */   }
/* 1505:     */   
/* 1506:     */   public boolean isRoundUpField()
/* 1507:     */   {
/* 1508:1509 */     String fieldName = this.fieldName;
/* 1509:1510 */     return (fieldName != null) && (!fieldName.equalsIgnoreCase("INSTRCALRANGEFROM")) && (!fieldName.equalsIgnoreCase("INSTRCALRANGETO")) && (!fieldName.equalsIgnoreCase("INSTROUTRANGEFROM")) && (!fieldName.equalsIgnoreCase("INSTROUTRANGETO")) && (!fieldName.equalsIgnoreCase("RON1LOWERVALUE")) && (!fieldName.equalsIgnoreCase("RON1UPPERVALUE")) && (!fieldName.equalsIgnoreCase("TOL1LOWERVALUE")) && (!fieldName.equalsIgnoreCase("TOL1UPPERVALUE")) && (!fieldName.equalsIgnoreCase("TOL2LOWERVALUE")) && (!fieldName.equalsIgnoreCase("TOL2UPPERVALUE")) && (!fieldName.equalsIgnoreCase("TOL3LOWERVALUE")) && (!fieldName.equalsIgnoreCase("TOL3UPPERVALUE")) && (!fieldName.equalsIgnoreCase("TOL4LOWERVALUE")) && (!fieldName.equalsIgnoreCase("TOL4UPPERVALUE")) && (!fieldName.equalsIgnoreCase("TOL1SUMEU")) && (!fieldName.equalsIgnoreCase("TOL1SUMREAD")) && (!fieldName.equalsIgnoreCase("TOL1SUMSPAN")) && (!fieldName.equalsIgnoreCase("TOL1SUMURV")) && (!fieldName.equalsIgnoreCase("TOL2SUMEU")) && (!fieldName.equalsIgnoreCase("TOL2SUMREAD")) && (!fieldName.equalsIgnoreCase("TOL2SUMSPAN")) && (!fieldName.equalsIgnoreCase("TOL2SUMURV")) && (!fieldName.equalsIgnoreCase("TOL3SUMEU")) && (!fieldName.equalsIgnoreCase("TOL3SUMREAD")) && (!fieldName.equalsIgnoreCase("TOL3SUMSPAN")) && (!fieldName.equalsIgnoreCase("TOL3SUMURV")) && (!fieldName.equalsIgnoreCase("TOL4SUMEU")) && (!fieldName.equalsIgnoreCase("TOL4SUMREAD")) && (!fieldName.equalsIgnoreCase("TOL4SUMSPAN")) && (!fieldName.equalsIgnoreCase("TOL4SUMURV"));
/* 1510:     */   }
/* 1511:     */   
/* 1512:     */   public String getString(String key)
/* 1513:     */   {
/* 1514:1544 */     PlusCMboRemote suitable = getObjectOwner(key);
/* 1515:1545 */     Object value = suitable.getObject(key);
/* 1516:1546 */     return value == null ? "" : value.toString();
/* 1517:     */   }
/* 1518:     */   
/* 1519:     */   public Integer getInt(String key)
/* 1520:     */   {
/* 1521:1550 */     PlusCMboRemote suitable = getObjectOwner(key);
/* 1522:1551 */     Object value = suitable.getObject(key);
/* 1523:1552 */     return value == null ? new Integer(0) : (Integer)value;
/* 1524:     */   }
/* 1525:     */   
/* 1526:     */   public Long getLong(String key)
/* 1527:     */   {
/* 1528:1556 */     PlusCMboRemote suitable = getObjectOwner(key);
/* 1529:1557 */     Object value = suitable.getObject(key);
/* 1530:1558 */     return value == null ? new Long(0L) : (Long)value;
/* 1531:     */   }
/* 1532:     */   
/* 1533:     */   public Boolean getBoolean(String key)
/* 1534:     */   {
/* 1535:1562 */     PlusCMboRemote suitable = getObjectOwner(key);
/* 1536:1563 */     Object value = suitable.getObject(key);
/* 1537:1564 */     return value == null ? new Boolean(false) : (Boolean)value;
/* 1538:     */   }
/* 1539:     */   
/* 1540:     */   public Object getObject(String key)
/* 1541:     */   {
/* 1542:1568 */     return this.mboData.get(key.toUpperCase());
/* 1543:     */   }
/* 1544:     */   
/* 1545:     */   public Date getDate(String key)
/* 1546:     */   {
/* 1547:1572 */     PlusCMboRemote suitable = getObjectOwner(key);
/* 1548:1573 */     return (Date)suitable.getObject(key);
/* 1549:     */   }
/* 1550:     */   
/* 1551:     */   public PlusCDSTO getPlusCDSTO()
/* 1552:     */   {
/* 1553:1577 */     throw new UnsupportedOperationException("In this class this method is not implemented.");
/* 1554:     */   }
/* 1555:     */   
/* 1556:     */   public void setPlusCDSTO(PlusCDSTO plusCDSTO)
/* 1557:     */   {
/* 1558:1582 */     throw new UnsupportedOperationException("In this class this method is not implemented.");
/* 1559:     */   }
/* 1560:     */   
/* 1561:     */   public PlusCDSInstrTO getPlusCDSInstrTO()
/* 1562:     */   {
/* 1563:1587 */     throw new UnsupportedOperationException("In this class this method is not implemented.");
/* 1564:     */   }
/* 1565:     */   
/* 1566:     */   public void setPlusCDSInstTO(PlusCDSInstrTO plusCDSInstrTO)
/* 1567:     */   {
/* 1568:1592 */     throw new UnsupportedOperationException("In this class this method is not implemented.");
/* 1569:     */   }
/* 1570:     */   
/* 1571:     */   public PlusCDSPointTO getPlusCDSPointTO()
/* 1572:     */   {
/* 1573:1597 */     throw new UnsupportedOperationException("In this class this method is not implemented.");
/* 1574:     */   }
/* 1575:     */   
/* 1576:     */   public void setPlusCDSPointTO(PlusCDSPointTO plusCDSPointTO)
/* 1577:     */   {
/* 1578:1602 */     throw new UnsupportedOperationException("In this class this method is not implemented.");
/* 1579:     */   }
/* 1580:     */   
/* 1581:     */   public void setPlusCWODSTO(PlusCWODSTO plusCWODSTO)
/* 1582:     */   {
/* 1583:1607 */     this.plusCWODSTO = plusCWODSTO;
/* 1584:1608 */     if (plusCWODSTO.getPlusCWODSInstrTO() != this) {
/* 1585:1609 */       plusCWODSTO.setPlusCWODSInstrTO(this);
/* 1586:     */     }
/* 1587:     */   }
/* 1588:     */   
/* 1589:     */   public PlusCWODSTO getPlusCWODSTO()
/* 1590:     */   {
/* 1591:1614 */     return this.plusCWODSTO;
/* 1592:     */   }
/* 1593:     */   
/* 1594:     */   public void setPlusCWODSInstrTO(PlusCWODSInstrTO plusCWODSInstrTO)
/* 1595:     */   {
/* 1596:1618 */     throw new UnsupportedOperationException("In this class this method is not implemented.");
/* 1597:     */   }
/* 1598:     */   
/* 1599:     */   public PlusCWODSInstrTO getPlusCWODSInstrTO()
/* 1600:     */   {
/* 1601:1623 */     return this;
/* 1602:     */   }
/* 1603:     */   
/* 1604:     */   public void setPlusCWODSPointTO(PlusCWODSPointTO plusCWODSPointTO)
/* 1605:     */   {
/* 1606:1627 */     this.plusCWODSPointTO = plusCWODSPointTO;
/* 1607:1628 */     if (plusCWODSPointTO.getPlusCWODSInstrTO() != this) {
/* 1608:1629 */       plusCWODSPointTO.setPlusCWODSInstrTO(this);
/* 1609:     */     }
/* 1610:     */   }
/* 1611:     */   
/* 1612:     */   public PlusCWODSPointTO getPlusCWODSPointTO()
/* 1613:     */   {
/* 1614:1633 */     return this.plusCWODSPointTO;
/* 1615:     */   }
/* 1616:     */   
/* 1617:     */   public void setValue(String key, Object object)
/* 1618:     */   {
/* 1619:1637 */     setValue(key, object, true);
/* 1620:     */   }
/* 1621:     */   
/* 1622:     */   public void setValue(String key, Object object, boolean markAsChanged)
/* 1623:     */   {
/* 1624:1642 */     setValue(key, object, 0L, markAsChanged);
/* 1625:     */   }
/* 1626:     */   
/* 1627:     */   public Locale getLocale()
/* 1628:     */   {
/* 1629:1647 */     return this.locale;
/* 1630:     */   }
/* 1631:     */   
/* 1632:     */   public void setLocale(Locale locale)
/* 1633:     */   {
/* 1634:1651 */     this.locale = locale;
/* 1635:     */   }
/* 1636:     */   
/* 1637:     */   public boolean isNull(String key)
/* 1638:     */   {
/* 1639:1655 */     Object value = null;
/* 1640:1656 */     if ((getPlusCWODSInstrTO() != null) && (getPlusCWODSInstrTO().containsAttribute(key)))
/* 1641:     */     {
/* 1642:1657 */       value = getPlusCWODSInstrTO().getObject(key);
/* 1643:1658 */       return (value == null) || (value.toString().trim().equals(""));
/* 1644:     */     }
/* 1645:1660 */     if ((getPlusCWODSPointTO() != null) && (getPlusCWODSPointTO().containsAttribute(key)))
/* 1646:     */     {
/* 1647:1661 */       value = getPlusCWODSPointTO().getObject(key);
/* 1648:1662 */       return (value == null) || (value.toString().trim().equals(""));
/* 1649:     */     }
/* 1650:1664 */     if ((getPlusCWODSTO() != null) && (getPlusCWODSTO().containsAttribute(key)))
/* 1651:     */     {
/* 1652:1665 */       value = getPlusCWODSTO().getObject(key);
/* 1653:1666 */       return (value == null) || (value.toString().trim().equals(""));
/* 1654:     */     }
/* 1655:1668 */     return true;
/* 1656:     */   }
/* 1657:     */   
/* 1658:     */   public Set getChangedFields()
/* 1659:     */   {
/* 1660:1672 */     return this.changedFields;
/* 1661:     */   }
/* 1662:     */   
/* 1663:     */   public void clearAllChangedFieldsSets()
/* 1664:     */   {
/* 1665:1676 */     if (getPlusCWODSInstrTO() != null) {
/* 1666:1677 */       getPlusCWODSInstrTO().getChangedFields().clear();
/* 1667:     */     }
/* 1668:1679 */     if (getPlusCWODSTO() != null) {
/* 1669:1680 */       getPlusCWODSTO().getChangedFields().clear();
/* 1670:     */     }
/* 1671:1682 */     if (getPlusCWODSPointTO() != null) {
/* 1672:1683 */       getPlusCWODSPointTO().getChangedFields().clear();
/* 1673:     */     }
/* 1674:     */   }
/* 1675:     */   
/* 1676:     */   protected boolean containsAttribute(String attributeName)
/* 1677:     */   {
/* 1678:1689 */     return this.mboData.containsKey(attributeName.toUpperCase());
/* 1679:     */   }
/* 1680:     */   
/* 1681:     */   private static List getAttributeNames()
/* 1682:     */   {
/* 1683:1693 */     List list = new LinkedList();
/* 1684:1694 */     Method[] methods = PlusCWODSInstrTO.class.getMethods();
/* 1685:1695 */     for (int i = 0; i < methods.length; i++) {
/* 1686:1696 */       if (methods[i].getName().indexOf("set") == 0) {
/* 1687:1697 */         list.add(methods[i].getName().substring(3).toUpperCase());
/* 1688:     */       }
/* 1689:     */     }
/* 1690:1700 */     return list;
/* 1691:     */   }
/* 1692:     */   
/* 1693:     */   private PlusCMboRemote getObjectOwner(String attributeName)
/* 1694:     */   {
/* 1695:1704 */     if ((getPlusCWODSInstrTO() != null) && (getPlusCWODSInstrTO().containsAttribute(attributeName))) {
/* 1696:1705 */       return getPlusCWODSInstrTO();
/* 1697:     */     }
/* 1698:1708 */     if (getPlusCWODSPointTO().containsAttribute(attributeName)) {
/* 1699:1709 */       return getPlusCWODSPointTO();
/* 1700:     */     }
/* 1701:1712 */     if ((getPlusCWODSTO() != null) && (getPlusCWODSTO().containsAttribute(attributeName))) {
/* 1702:1713 */       return getPlusCWODSTO();
/* 1703:     */     }
/* 1704:1716 */     throw new RuntimeException("Neither of suitable classes have the attribute " + attributeName);
/* 1705:     */   }
/* 1706:     */   
/* 1707:     */   public void setValue(String key, Object object, long validationFlag)
/* 1708:     */   {
/* 1709:1721 */     setValue(key, object, validationFlag, true);
/* 1710:     */   }
/* 1711:     */   
/* 1712:     */   public void setValue(String key, Object object, long validationFlag, boolean markAsChanged)
/* 1713:     */   {
/* 1714:1727 */     if (containsAttribute(key))
/* 1715:     */     {
/* 1716:1728 */       if (markAsChanged)
/* 1717:     */       {
/* 1718:1729 */         this.changedFields.add(key.toUpperCase());
/* 1719:1730 */         this.validationFlags.put(key.toUpperCase(), new Long(validationFlag));
/* 1720:     */       }
/* 1721:     */       else
/* 1722:     */       {
/* 1723:1732 */         this.validationFlags.remove(key.toUpperCase());
/* 1724:     */       }
/* 1725:1734 */       this.mboData.put(key.toUpperCase(), object);
/* 1726:     */     }
/* 1727:1736 */     else if ((this.plusCWODSPointTO != null) && (getPlusCWODSPointTO().containsAttribute(key)))
/* 1728:     */     {
/* 1729:1737 */       getPlusCWODSPointTO().setValue(key, object, validationFlag, markAsChanged);
/* 1730:     */     }
/* 1731:1738 */     else if ((this.plusCWODSTO != null) && (getPlusCWODSTO().containsAttribute(key)))
/* 1732:     */     {
/* 1733:1739 */       getPlusCWODSTO().setValue(key, object, validationFlag, markAsChanged);
/* 1734:     */     }
/* 1735:     */     else
/* 1736:     */     {
/* 1737:1741 */       throw new RuntimeException("No suitable class to set " + key + " attribute");
/* 1738:     */     }
/* 1739:     */   }
/* 1740:     */   
/* 1741:     */   public long getValidationFlag(String key)
/* 1742:     */   {
/* 1743:1749 */     String keyUpper = key.toUpperCase();
/* 1744:1750 */     PlusCMboRemote suitable = getObjectOwner(keyUpper);
/* 1745:1751 */     long value = 0L;
/* 1746:1752 */     if (suitable == this)
/* 1747:     */     {
/* 1748:1753 */       Object o = this.validationFlags.get(keyUpper);
/* 1749:1754 */       value = o != null ? new Long(o.toString()).longValue() : 11L;
/* 1750:     */     }
/* 1751:     */     else
/* 1752:     */     {
/* 1753:1756 */       suitable.getValidationFlag(key);
/* 1754:     */     }
/* 1755:1758 */     return value;
/* 1756:     */   }
/* 1757:     */   
/* 1758:     */   public Set getNonPersistentFieldsName()
/* 1759:     */   {
/* 1760:1762 */     return getNonPersistentFields();
/* 1761:     */   }
/* 1762:     */   
/* 1763:     */   private Set getNonPersistentFields()
/* 1764:     */   {
/* 1765:     */     Iterator iter;
/* 1766:1766 */     if (this.nonPersistentFields == null)
/* 1767:     */     {
/* 1768:1767 */       this.nonPersistentFields = new HashSet();
/* 1769:1768 */       for (iter = this.mboData.keySet().iterator(); iter.hasNext();)
/* 1770:     */       {
/* 1771:1769 */         String element = (String)iter.next();
/* 1772:1770 */         if (element.indexOf("_NP") >= 0) {
/* 1773:1771 */           this.nonPersistentFields.add(element.toUpperCase());
/* 1774:     */         }
/* 1775:     */       }
/* 1776:     */     }
/* 1777:1775 */     return this.nonPersistentFields;
/* 1778:     */   }
/* 1779:     */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     psdi.plusc.app.pluscds.pluscmobilecommon.PlusCWODSInstrTO
 * JD-Core Version:    0.7.0.1
 */