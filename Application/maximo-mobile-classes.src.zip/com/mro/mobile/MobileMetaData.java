/*   1:    */ package com.mro.mobile;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.mbo.MobileMboInfo;
/*   4:    */ import com.mro.mobile.persist.RDO;
/*   5:    */ import com.mro.mobile.persist.RDOSerializer;
/*   6:    */ import com.mro.mobile.type.Serializer;
/*   7:    */ import com.mro.mobile.type.TypeRegistry;
/*   8:    */ import com.mro.mobile.ui.MobileUIControlInfo;
/*   9:    */ import java.io.DataInput;
/*  10:    */ import java.io.DataOutput;
/*  11:    */ import java.io.IOException;
/*  12:    */ import java.util.Enumeration;
/*  13:    */ import java.util.Hashtable;
/*  14:    */ 
/*  15:    */ public class MobileMetaData
/*  16:    */   implements Serializer
/*  17:    */ {
/*  18: 38 */   private String appName = null;
/*  19: 43 */   private String appDescription = null;
/*  20: 48 */   private String version = null;
/*  21: 53 */   private long timestamp = 0L;
/*  22: 59 */   private Hashtable mobileMboInfoMap = new Hashtable();
/*  23: 64 */   private Hashtable uiComponentInfoMap = new Hashtable();
/*  24: 69 */   private Hashtable messageInfoMap = new Hashtable();
/*  25: 74 */   private Hashtable actionMap = new Hashtable();
/*  26:    */   
/*  27:    */   public MobileMboInfo[] getAllMobileMboInfo()
/*  28:    */   {
/*  29: 87 */     int size = this.mobileMboInfoMap.size();
/*  30: 88 */     MobileMboInfo[] mobileMboInfoArray = new MobileMboInfo[size];
/*  31:    */     
/*  32: 90 */     Enumeration infoEnum = this.mobileMboInfoMap.elements();
/*  33: 91 */     for (int i = 0; i < size; i++)
/*  34:    */     {
/*  35: 93 */       MobileMboInfo mobileMboInfo = (MobileMboInfo)infoEnum.nextElement();
/*  36: 94 */       mobileMboInfoArray[i] = mobileMboInfo;
/*  37:    */     }
/*  38: 97 */     return mobileMboInfoArray;
/*  39:    */   }
/*  40:    */   
/*  41:    */   public void setAllMobileMboInfo(MobileMboInfo[] allMobileMboInfo)
/*  42:    */   {
/*  43:107 */     int size = allMobileMboInfo.length;
/*  44:108 */     for (int i = 0; i < size; i++) {
/*  45:110 */       this.mobileMboInfoMap.put(allMobileMboInfo[i].getName(), allMobileMboInfo[i]);
/*  46:    */     }
/*  47:    */   }
/*  48:    */   
/*  49:    */   public MobileUIControlInfo[] getAllMobileUIComponentInfo()
/*  50:    */   {
/*  51:121 */     int size = this.uiComponentInfoMap.size();
/*  52:122 */     MobileUIControlInfo[] uiComponentInfoArray = new MobileUIControlInfo[size];
/*  53:    */     
/*  54:124 */     Enumeration infoEnum = this.uiComponentInfoMap.elements();
/*  55:125 */     for (int i = 0; i < size; i++)
/*  56:    */     {
/*  57:127 */       MobileUIControlInfo uiComponentInfo = (MobileUIControlInfo)infoEnum.nextElement();
/*  58:128 */       uiComponentInfoArray[i] = uiComponentInfo;
/*  59:    */     }
/*  60:131 */     return uiComponentInfoArray;
/*  61:    */   }
/*  62:    */   
/*  63:    */   public void setAllMobileUIControlInfo(MobileUIControlInfo[] allMobileUIComponentInfo)
/*  64:    */   {
/*  65:141 */     int size = allMobileUIComponentInfo.length;
/*  66:142 */     for (int i = 0; i < size; i++) {
/*  67:144 */       this.uiComponentInfoMap.put(allMobileUIComponentInfo[i].getComponentName(), allMobileUIComponentInfo[i]);
/*  68:    */     }
/*  69:    */   }
/*  70:    */   
/*  71:    */   public MobileMessageInfo[] getAllMobileMessageInfo()
/*  72:    */   {
/*  73:155 */     int size = this.messageInfoMap.size();
/*  74:156 */     MobileMessageInfo[] messageInfoArray = new MobileMessageInfo[size];
/*  75:    */     
/*  76:158 */     Enumeration infoEnum = this.messageInfoMap.elements();
/*  77:159 */     for (int i = 0; i < size; i++)
/*  78:    */     {
/*  79:161 */       MobileMessageInfo messageInfo = (MobileMessageInfo)infoEnum.nextElement();
/*  80:162 */       messageInfoArray[i] = messageInfo;
/*  81:    */     }
/*  82:165 */     return messageInfoArray;
/*  83:    */   }
/*  84:    */   
/*  85:    */   public void setAllMobileMessageInfo(MobileMessageInfo[] allMobileMessageInfo)
/*  86:    */   {
/*  87:175 */     int size = allMobileMessageInfo.length;
/*  88:176 */     for (int i = 0; i < size; i++) {
/*  89:178 */       this.messageInfoMap.put(allMobileMessageInfo[i].getMessageKey(), allMobileMessageInfo[i]);
/*  90:    */     }
/*  91:    */   }
/*  92:    */   
/*  93:    */   public String getVersion()
/*  94:    */   {
/*  95:237 */     return this.version;
/*  96:    */   }
/*  97:    */   
/*  98:    */   public void setVersion(String version)
/*  99:    */   {
/* 100:247 */     this.version = version;
/* 101:    */   }
/* 102:    */   
/* 103:    */   public long getTimestamp()
/* 104:    */   {
/* 105:256 */     return this.timestamp;
/* 106:    */   }
/* 107:    */   
/* 108:    */   public void setTimestamp(long timestamp)
/* 109:    */   {
/* 110:265 */     this.timestamp = timestamp;
/* 111:    */   }
/* 112:    */   
/* 113:    */   public String getAppName()
/* 114:    */   {
/* 115:275 */     return this.appName;
/* 116:    */   }
/* 117:    */   
/* 118:    */   public void setAppName(String appName)
/* 119:    */   {
/* 120:285 */     this.appName = appName;
/* 121:    */   }
/* 122:    */   
/* 123:    */   public String getAppDescription()
/* 124:    */   {
/* 125:295 */     return this.appDescription;
/* 126:    */   }
/* 127:    */   
/* 128:    */   public void setAppDescription(String description)
/* 129:    */   {
/* 130:305 */     this.appDescription = description;
/* 131:    */   }
/* 132:    */   
/* 133:    */   public MobileMboInfo getMobileMboInfo(String name)
/* 134:    */   {
/* 135:317 */     return (MobileMboInfo)this.mobileMboInfoMap.get(name);
/* 136:    */   }
/* 137:    */   
/* 138:    */   public MobileUIControlInfo getMobileUIComponentInfo(String componentName)
/* 139:    */   {
/* 140:328 */     return (MobileUIControlInfo)this.uiComponentInfoMap.get(componentName);
/* 141:    */   }
/* 142:    */   
/* 143:    */   public MobileMessageInfo getMobileMessageInfo(String messageKey)
/* 144:    */   {
/* 145:339 */     return (MobileMessageInfo)this.messageInfoMap.get(messageKey);
/* 146:    */   }
/* 147:    */   
/* 148:    */   public static void initSerializer()
/* 149:    */   {
/* 150:347 */     MobileMetaData i = new MobileMetaData();
/* 151:348 */     TypeRegistry.getTypeRegistry().addType("MobileMetaData", i.getClass(), i);
/* 152:    */   }
/* 153:    */   
/* 154:    */   public Object readInstance(DataInput input, String name)
/* 155:    */     throws IOException
/* 156:    */   {
/* 157:358 */     if (name.equals("MobileMetaData"))
/* 158:    */     {
/* 159:360 */       String metaDataAppName = input.readUTF();
/* 160:361 */       String metaDataAppDescription = input.readUTF();
/* 161:362 */       String metaDataVersion = input.readUTF();
/* 162:363 */       long timeStamp = input.readLong();
/* 163:    */       
/* 164:365 */       int noOfMobileMboInfos = input.readInt();
/* 165:366 */       MobileMboInfo[] allMboInfo = new MobileMboInfo[noOfMobileMboInfos];
/* 166:    */       
/* 167:368 */       RDOSerializer rdoSerializer = new RDOSerializer();
/* 168:369 */       for (int i = 0; i < noOfMobileMboInfos; i++)
/* 169:    */       {
/* 170:371 */         RDO rdo = (RDO)rdoSerializer.readInstance(input);
/* 171:    */         try
/* 172:    */         {
/* 173:374 */           allMboInfo[i] = new MobileMboInfo(rdo);
/* 174:    */         }
/* 175:    */         catch (MobileApplicationException e)
/* 176:    */         {
/* 177:378 */           throw new IOException(e.getMessage());
/* 178:    */         }
/* 179:    */       }
/* 180:382 */       int noOfUIComponents = input.readInt();
/* 181:383 */       MobileUIControlInfo[] allUIComponentInfo = new MobileUIControlInfo[noOfUIComponents];
/* 182:384 */       for (int i = 0; i < noOfUIComponents; i++)
/* 183:    */       {
/* 184:386 */         RDO rdo = (RDO)rdoSerializer.readInstance(input);
/* 185:    */         try
/* 186:    */         {
/* 187:389 */           allUIComponentInfo[i] = new MobileUIControlInfo(rdo);
/* 188:    */         }
/* 189:    */         catch (MobileApplicationException e)
/* 190:    */         {
/* 191:393 */           throw new IOException(e.getMessage());
/* 192:    */         }
/* 193:    */       }
/* 194:397 */       MobileMessageInfo reader = new MobileMessageInfo();
/* 195:398 */       int noOfMessages = input.readInt();
/* 196:399 */       MobileMessageInfo[] allMessageInfo = new MobileMessageInfo[noOfMessages];
/* 197:400 */       for (int i = 0; i < noOfMessages; i++) {
/* 198:402 */         allMessageInfo[i] = ((MobileMessageInfo)reader.readInstance(input, "MobileMessageInfo"));
/* 199:    */       }
/* 200:406 */       MobileMetaData x = new MobileMetaData();
/* 201:407 */       x.setAppName(metaDataAppName);
/* 202:408 */       x.setAppDescription(metaDataAppDescription);
/* 203:409 */       x.setVersion(metaDataVersion);
/* 204:410 */       x.setTimestamp(timeStamp);
/* 205:411 */       x.setAllMobileMboInfo(allMboInfo);
/* 206:412 */       x.setAllMobileUIControlInfo(allUIComponentInfo);
/* 207:413 */       x.setAllMobileMessageInfo(allMessageInfo);
/* 208:    */       
/* 209:415 */       return x;
/* 210:    */     }
/* 211:418 */     throw new RuntimeException("The type " + name + " not supported.");
/* 212:    */   }
/* 213:    */   
/* 214:    */   public void writeInstance(DataOutput output, Object obj)
/* 215:    */     throws IOException
/* 216:    */   {
/* 217:427 */     if ((obj instanceof MobileMetaData))
/* 218:    */     {
/* 219:429 */       MobileMetaData x = (MobileMetaData)obj;
/* 220:    */       
/* 221:431 */       output.writeUTF(x.getAppName());
/* 222:432 */       output.writeUTF(x.getAppDescription());
/* 223:433 */       output.writeUTF(x.getVersion());
/* 224:434 */       output.writeLong(System.currentTimeMillis());
/* 225:    */       
/* 226:436 */       MobileMboInfo[] allMboInfo = x.getAllMobileMboInfo();
/* 227:    */       
/* 228:438 */       int noOfMobileMboInfos = allMboInfo.length;
/* 229:439 */       output.writeInt(noOfMobileMboInfos);
/* 230:    */       
/* 231:441 */       RDOSerializer rdoSerializer = new RDOSerializer();
/* 232:442 */       for (int i = 0; i < allMboInfo.length; i++)
/* 233:    */       {
/* 234:444 */         MobileMboInfo info = allMboInfo[i];
/* 235:    */         try
/* 236:    */         {
/* 237:447 */           rdoSerializer.writeInstance(output, info.getRDO());
/* 238:    */         }
/* 239:    */         catch (MobileApplicationException e)
/* 240:    */         {
/* 241:451 */           throw new IOException(e.getMessage());
/* 242:    */         }
/* 243:    */       }
/* 244:455 */       MobileUIControlInfo[] allUIComponentInfo = x.getAllMobileUIComponentInfo();
/* 245:456 */       int noOfUIComponents = allUIComponentInfo.length;
/* 246:457 */       output.writeInt(noOfUIComponents);
/* 247:459 */       for (int i = 0; i < noOfUIComponents; i++)
/* 248:    */       {
/* 249:461 */         MobileUIControlInfo uiComponentInfo = allUIComponentInfo[i];
/* 250:    */         try
/* 251:    */         {
/* 252:465 */           rdoSerializer.writeInstance(output, uiComponentInfo.getRDO());
/* 253:    */         }
/* 254:    */         catch (MobileApplicationException e)
/* 255:    */         {
/* 256:469 */           throw new IOException(e.getMessage());
/* 257:    */         }
/* 258:    */       }
/* 259:474 */       MobileMessageInfo[] allMessageInfo = x.getAllMobileMessageInfo();
/* 260:475 */       int noOfMessages = allMessageInfo.length;
/* 261:476 */       output.writeInt(noOfMessages);
/* 262:    */       
/* 263:478 */       MobileMessageInfo writer = new MobileMessageInfo();
/* 264:479 */       for (int i = 0; i < noOfMessages; i++) {
/* 265:481 */         writer.writeInstance(output, allMessageInfo[i]);
/* 266:    */       }
/* 267:    */     }
/* 268:    */   }
/* 269:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.MobileMetaData
 * JD-Core Version:    0.7.0.1
 */