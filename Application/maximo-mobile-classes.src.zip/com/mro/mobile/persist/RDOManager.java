package com.mro.mobile.persist;

import com.mro.mobile.persist.sql.MobileWhereClause;

public abstract interface RDOManager
{
  public abstract RDOEnumeration getAll(String paramString)
    throws RDOException;
  
  public abstract RDOEnumeration getAll(String paramString, QBE paramQBE, Order paramOrder)
    throws RDOException;
  
  public abstract RDOEnumeration getAll(String paramString, QBE paramQBE, MobileWhereClause paramMobileWhereClause, Order paramOrder)
    throws RDOException;
  
  public abstract void insert(String paramString, RDO paramRDO)
    throws RDOException;
  
  public abstract void remove(String paramString, RDO paramRDO)
    throws RDOException;
  
  public abstract void remove(String paramString, long paramLong)
    throws RDOException;
  
  public abstract void removeDependent(String paramString, long paramLong1, long paramLong2)
    throws RDOException;
  
  public abstract void removeAll(String paramString)
    throws RDOException;
  
  public abstract void update(String paramString, RDO paramRDO)
    throws RDOException;
  
  public abstract boolean exists(String paramString, RDOKey paramRDOKey)
    throws RDOException;
  
  public abstract boolean existsDependent(String paramString, long paramLong1, long paramLong2)
    throws RDOException;
  
  public abstract boolean exists(String paramString, long paramLong)
    throws RDOException;
  
  public abstract RDO get(String paramString, RDOKey paramRDOKey)
    throws RDOException;
  
  public abstract RDO get(String paramString, long paramLong)
    throws RDOException;
  
  public abstract int size(String paramString)
    throws RDOException;
  
  public abstract int size(String paramString, QBE paramQBE)
    throws RDOException;
  
  public abstract int size(String paramString, QBE paramQBE, MobileWhereClause paramMobileWhereClause)
    throws RDOException;
  
  public abstract boolean exists(String paramString)
    throws RDOException;
  
  public abstract void removeAll()
    throws RDOException;
  
  public abstract RDOEnumeration getDependents(String paramString, RDO paramRDO)
    throws RDOException;
  
  public abstract RDOEnumeration getDependents(String paramString, QBE paramQBE, Order paramOrder, RDO paramRDO)
    throws RDOException;
  
  public abstract RDOEnumeration getDependents(String paramString, QBE paramQBE, MobileWhereClause paramMobileWhereClause, Order paramOrder, RDO paramRDO)
    throws RDOException;
  
  public abstract int getDependentsSize(String paramString, RDO paramRDO)
    throws RDOException;
  
  public abstract int getDependentsSize(String paramString, QBE paramQBE, RDO paramRDO)
    throws RDOException;
  
  public abstract void release()
    throws RDOException;
  
  public abstract int getDependentsSize(String paramString, QBE paramQBE, MobileWhereClause paramMobileWhereClause, RDO paramRDO)
    throws RDOException;
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.persist.RDOManager
 * JD-Core Version:    0.7.0.1
 */