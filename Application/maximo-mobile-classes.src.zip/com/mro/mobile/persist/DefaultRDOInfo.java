/*   1:    */ package com.mro.mobile.persist;
/*   2:    */ 
/*   3:    */ import java.util.Vector;
/*   4:    */ 
/*   5:    */ public class DefaultRDOInfo
/*   6:    */   implements RDOInfo
/*   7:    */ {
/*   8: 20 */   private String name = null;
/*   9: 21 */   private Vector attributes = new Vector();
/*  10: 22 */   private String parent = null;
/*  11: 23 */   private Vector dependents = new Vector();
/*  12: 24 */   private boolean hierarchical = false;
/*  13: 25 */   private RDODependentRelation dependentRelation = null;
/*  14:    */   
/*  15:    */   public String getName()
/*  16:    */   {
/*  17: 29 */     return this.name;
/*  18:    */   }
/*  19:    */   
/*  20:    */   public void setName(String name)
/*  21:    */   {
/*  22: 34 */     this.name = name;
/*  23:    */   }
/*  24:    */   
/*  25:    */   public void addAttributeInfo(DefaultRDOAttributeInfo info)
/*  26:    */   {
/*  27: 39 */     this.attributes.addElement(info);
/*  28:    */   }
/*  29:    */   
/*  30:    */   public void setAttributes(Vector attributes)
/*  31:    */   {
/*  32: 44 */     this.attributes = attributes;
/*  33:    */   }
/*  34:    */   
/*  35:    */   public RDOAttributeInfo getAttributeInfo(int index)
/*  36:    */   {
/*  37: 49 */     return (DefaultRDOAttributeInfo)this.attributes.elementAt(index);
/*  38:    */   }
/*  39:    */   
/*  40:    */   public int getAttributeIndex(String attributeName)
/*  41:    */   {
/*  42: 54 */     int size = this.attributes.size();
/*  43: 55 */     for (int i = 0; i < size; i++)
/*  44:    */     {
/*  45: 57 */       RDOAttributeInfo da = (RDOAttributeInfo)this.attributes.elementAt(i);
/*  46: 59 */       if (da.getName().equals(attributeName)) {
/*  47: 61 */         return i;
/*  48:    */       }
/*  49:    */     }
/*  50: 64 */     return -1;
/*  51:    */   }
/*  52:    */   
/*  53:    */   public String[] getAttributeNames()
/*  54:    */   {
/*  55: 69 */     String[] attrs = new String[this.attributes.size()];
/*  56: 71 */     for (int i = 0; i < attrs.length; i++)
/*  57:    */     {
/*  58: 73 */       RDOAttributeInfo da = (RDOAttributeInfo)this.attributes.elementAt(i);
/*  59:    */       
/*  60: 75 */       attrs[i] = da.getName();
/*  61:    */     }
/*  62: 78 */     return attrs;
/*  63:    */   }
/*  64:    */   
/*  65:    */   public int getAttributeCount()
/*  66:    */   {
/*  67: 83 */     return this.attributes.size();
/*  68:    */   }
/*  69:    */   
/*  70:    */   public RDOAttributeInfo getAttributeInfo(String name)
/*  71:    */   {
/*  72: 88 */     int size = this.attributes.size();
/*  73: 89 */     for (int i = 0; i < size; i++)
/*  74:    */     {
/*  75: 91 */       RDOAttributeInfo da = (RDOAttributeInfo)this.attributes.elementAt(i);
/*  76: 93 */       if (da.getName().equals(name)) {
/*  77: 95 */         return da;
/*  78:    */       }
/*  79:    */     }
/*  80: 98 */     return null;
/*  81:    */   }
/*  82:    */   
/*  83:    */   public String[] getKeyAttributeNames()
/*  84:    */   {
/*  85:103 */     int keySize = getkeySize();
/*  86:104 */     String[] keyAttrs = new String[keySize];
/*  87:    */     
/*  88:106 */     int size = this.attributes.size();
/*  89:107 */     int keyIndex = 0;
/*  90:108 */     for (int i = 0; i < size; i++)
/*  91:    */     {
/*  92:110 */       RDOAttributeInfo da = (RDOAttributeInfo)this.attributes.elementAt(i);
/*  93:112 */       if (da.isKey())
/*  94:    */       {
/*  95:114 */         keyAttrs[keyIndex] = da.getName();
/*  96:115 */         keyIndex++;
/*  97:    */       }
/*  98:    */     }
/*  99:119 */     return keyAttrs;
/* 100:    */   }
/* 101:    */   
/* 102:    */   public int getkeySize()
/* 103:    */   {
/* 104:124 */     int size = this.attributes.size();
/* 105:125 */     int keySize = 0;
/* 106:127 */     for (int i = 0; i < size; i++)
/* 107:    */     {
/* 108:129 */       RDOAttributeInfo da = (RDOAttributeInfo)this.attributes.elementAt(i);
/* 109:130 */       if (da.isKey()) {
/* 110:132 */         keySize += 1;
/* 111:    */       }
/* 112:    */     }
/* 113:136 */     return keySize;
/* 114:    */   }
/* 115:    */   
/* 116:    */   public boolean isHierarchical()
/* 117:    */   {
/* 118:141 */     return this.hierarchical;
/* 119:    */   }
/* 120:    */   
/* 121:    */   public void setHierarchical(boolean hierarchical)
/* 122:    */   {
/* 123:146 */     this.hierarchical = hierarchical;
/* 124:    */   }
/* 125:    */   
/* 126:    */   public boolean isDependent()
/* 127:    */   {
/* 128:151 */     if (this.parent == null) {
/* 129:153 */       return false;
/* 130:    */     }
/* 131:156 */     return true;
/* 132:    */   }
/* 133:    */   
/* 134:    */   public boolean hasDependents()
/* 135:    */   {
/* 136:161 */     int count = this.dependents.size();
/* 137:162 */     if (count == 0) {
/* 138:164 */       return false;
/* 139:    */     }
/* 140:167 */     return true;
/* 141:    */   }
/* 142:    */   
/* 143:    */   public int getDependentCount()
/* 144:    */   {
/* 145:172 */     return this.dependents.size();
/* 146:    */   }
/* 147:    */   
/* 148:    */   public String[] getDependentNames()
/* 149:    */   {
/* 150:177 */     int count = this.dependents.size();
/* 151:178 */     String[] names = new String[count];
/* 152:179 */     for (int i = 0; i < count; i++) {
/* 153:181 */       names[i] = ((String)this.dependents.elementAt(i));
/* 154:    */     }
/* 155:184 */     return names;
/* 156:    */   }
/* 157:    */   
/* 158:    */   public void addDependent(String dependentName)
/* 159:    */   {
/* 160:190 */     this.dependents.addElement(dependentName);
/* 161:    */   }
/* 162:    */   
/* 163:    */   public String getParent()
/* 164:    */   {
/* 165:195 */     return this.parent;
/* 166:    */   }
/* 167:    */   
/* 168:    */   public void setParent(String parent)
/* 169:    */   {
/* 170:200 */     this.parent = parent;
/* 171:    */   }
/* 172:    */   
/* 173:    */   public String getAttributeName(int attributeIndex)
/* 174:    */   {
/* 175:205 */     RDOAttributeInfo da = (RDOAttributeInfo)this.attributes.elementAt(attributeIndex);
/* 176:206 */     return da.getName();
/* 177:    */   }
/* 178:    */   
/* 179:    */   public RDODependentRelation getDependentRelation()
/* 180:    */   {
/* 181:211 */     return this.dependentRelation;
/* 182:    */   }
/* 183:    */   
/* 184:    */   public void setDependentRelation(RDODependentRelation dependentRelation)
/* 185:    */   {
/* 186:216 */     this.dependentRelation = dependentRelation;
/* 187:    */   }
/* 188:    */   
/* 189:    */   public boolean hasAttribute(String name)
/* 190:    */   {
/* 191:220 */     return getAttributeInfo(name) != null;
/* 192:    */   }
/* 193:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.persist.DefaultRDOInfo
 * JD-Core Version:    0.7.0.1
 */