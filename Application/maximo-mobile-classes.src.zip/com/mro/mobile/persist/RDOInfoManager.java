package com.mro.mobile.persist;

import java.util.Enumeration;
import java.util.Vector;

public abstract interface RDOInfoManager
{
  public abstract void registerInfo(String paramString, RDOInfo paramRDOInfo)
    throws RDOException;
  
  public abstract RDOInfo getInfo(String paramString);
  
  public abstract boolean infoExists(String paramString);
  
  public abstract Enumeration getAllInfo();
  
  public abstract Enumeration getAllNames();
  
  public abstract void removeInfo(String paramString)
    throws RDOException;
  
  public abstract void removeAll()
    throws RDOException;
  
  public abstract void release()
    throws RDOException;
  
  public abstract void createIndex(String paramString1, String paramString2, String[] paramArrayOfString)
    throws RDOException;
  
  public abstract Vector getIndexNames()
    throws RDOException;
  
  public abstract void dropIndex(String paramString)
    throws RDOException;
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.persist.RDOInfoManager
 * JD-Core Version:    0.7.0.1
 */