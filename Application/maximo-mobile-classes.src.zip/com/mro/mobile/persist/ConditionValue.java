/*  1:   */ package com.mro.mobile.persist;
/*  2:   */ 
/*  3:   */ public class ConditionValue
/*  4:   */ {
/*  5: 5 */   private Object[] values = null;
/*  6:   */   
/*  7:   */   public ConditionValue(Object[] values)
/*  8:   */   {
/*  9: 8 */     this.values = values;
/* 10:   */   }
/* 11:   */   
/* 12:   */   public Object[] getValues()
/* 13:   */   {
/* 14:12 */     return this.values;
/* 15:   */   }
/* 16:   */   
/* 17:   */   public boolean equals(Object obj)
/* 18:   */   {
/* 19:16 */     if (!(obj instanceof ConditionValue)) {
/* 20:17 */       return false;
/* 21:   */     }
/* 22:20 */     ConditionValue v1 = (ConditionValue)obj;
/* 23:21 */     Object[] v1Values = v1.values;
/* 24:22 */     if ((this.values == null) && (v1Values == null)) {
/* 25:23 */       return true;
/* 26:   */     }
/* 27:26 */     if ((this.values == null) && (v1Values != null)) {
/* 28:27 */       return false;
/* 29:   */     }
/* 30:30 */     if ((this.values != null) && (v1Values == null)) {
/* 31:31 */       return false;
/* 32:   */     }
/* 33:34 */     if (this.values.length != v1Values.length) {
/* 34:35 */       return false;
/* 35:   */     }
/* 36:38 */     for (int i = 0; i < v1Values.length; i++)
/* 37:   */     {
/* 38:39 */       Object vObj = this.values[i];
/* 39:40 */       Object v1Obj = v1Values[i];
/* 40:42 */       if ((vObj == null) && (v1Obj != null)) {
/* 41:43 */         return false;
/* 42:   */       }
/* 43:46 */       if ((vObj != null) && (v1Obj == null)) {
/* 44:47 */         return false;
/* 45:   */       }
/* 46:50 */       if ((vObj != null) && (!vObj.equals(v1Obj))) {
/* 47:51 */         return false;
/* 48:   */       }
/* 49:   */     }
/* 50:55 */     return true;
/* 51:   */   }
/* 52:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.persist.ConditionValue
 * JD-Core Version:    0.7.0.1
 */