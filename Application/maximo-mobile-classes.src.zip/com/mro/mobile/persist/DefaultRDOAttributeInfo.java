/*   1:    */ package com.mro.mobile.persist;
/*   2:    */ 
/*   3:    */ public class DefaultRDOAttributeInfo
/*   4:    */   implements RDOAttributeInfo
/*   5:    */ {
/*   6: 18 */   private String name = null;
/*   7: 19 */   private boolean key = false;
/*   8: 20 */   private int dataType = 1;
/*   9: 21 */   private int length = 100;
/*  10: 22 */   private int scale = 0;
/*  11: 23 */   private boolean persistent = true;
/*  12:    */   
/*  13:    */   public String getName()
/*  14:    */   {
/*  15: 27 */     return this.name;
/*  16:    */   }
/*  17:    */   
/*  18:    */   public void setName(String name)
/*  19:    */   {
/*  20: 32 */     this.name = name;
/*  21:    */   }
/*  22:    */   
/*  23:    */   public boolean isKey()
/*  24:    */   {
/*  25: 37 */     return this.key;
/*  26:    */   }
/*  27:    */   
/*  28:    */   public void setKey(boolean key)
/*  29:    */   {
/*  30: 42 */     this.key = key;
/*  31:    */   }
/*  32:    */   
/*  33:    */   public int getDataType()
/*  34:    */   {
/*  35: 47 */     return this.dataType;
/*  36:    */   }
/*  37:    */   
/*  38:    */   public void setDataType(int dataType)
/*  39:    */   {
/*  40: 52 */     this.dataType = dataType;
/*  41:    */   }
/*  42:    */   
/*  43:    */   public int getLength()
/*  44:    */   {
/*  45: 58 */     return this.length;
/*  46:    */   }
/*  47:    */   
/*  48:    */   public void setLength(int length)
/*  49:    */   {
/*  50: 63 */     this.length = length;
/*  51:    */   }
/*  52:    */   
/*  53:    */   public int getScale()
/*  54:    */   {
/*  55: 68 */     return this.scale;
/*  56:    */   }
/*  57:    */   
/*  58:    */   public void setScale(int scale)
/*  59:    */   {
/*  60: 73 */     this.scale = scale;
/*  61:    */   }
/*  62:    */   
/*  63:    */   public boolean isPersistent()
/*  64:    */   {
/*  65: 78 */     return this.persistent;
/*  66:    */   }
/*  67:    */   
/*  68:    */   public void setPersistent(boolean persistent)
/*  69:    */   {
/*  70: 83 */     this.persistent = persistent;
/*  71:    */   }
/*  72:    */   
/*  73:    */   public boolean equals(Object obj)
/*  74:    */   {
/*  75: 87 */     if (this == obj) {
/*  76: 88 */       return true;
/*  77:    */     }
/*  78: 89 */     if (obj == null) {
/*  79: 90 */       return false;
/*  80:    */     }
/*  81: 91 */     if (getClass() != obj.getClass()) {
/*  82: 92 */       return false;
/*  83:    */     }
/*  84: 93 */     DefaultRDOAttributeInfo other = (DefaultRDOAttributeInfo)obj;
/*  85: 94 */     if (this.dataType != other.dataType) {
/*  86: 95 */       return false;
/*  87:    */     }
/*  88: 96 */     if (this.key != other.key) {
/*  89: 97 */       return false;
/*  90:    */     }
/*  91: 98 */     if (this.length != other.length) {
/*  92: 99 */       return false;
/*  93:    */     }
/*  94:100 */     if (this.name == null)
/*  95:    */     {
/*  96:101 */       if (other.name != null) {
/*  97:102 */         return false;
/*  98:    */       }
/*  99:    */     }
/* 100:103 */     else if (!this.name.equals(other.name)) {
/* 101:104 */       return false;
/* 102:    */     }
/* 103:105 */     if (this.persistent != other.persistent) {
/* 104:106 */       return false;
/* 105:    */     }
/* 106:107 */     if (this.scale != other.scale) {
/* 107:108 */       return false;
/* 108:    */     }
/* 109:109 */     return true;
/* 110:    */   }
/* 111:    */   
/* 112:    */   public boolean isAlphaNumeric()
/* 113:    */   {
/* 114:113 */     return (this.dataType == 1) || (this.dataType == 2) || (this.dataType == 3);
/* 115:    */   }
/* 116:    */   
/* 117:    */   public boolean isNumeric()
/* 118:    */   {
/* 119:119 */     return (isInteger()) || (isDecimal());
/* 120:    */   }
/* 121:    */   
/* 122:    */   public boolean isDecimal()
/* 123:    */   {
/* 124:125 */     return (this.dataType == 7) || (this.dataType == 6);
/* 125:    */   }
/* 126:    */   
/* 127:    */   public boolean isInteger()
/* 128:    */   {
/* 129:129 */     return (this.dataType == 4) || (this.dataType == 5);
/* 130:    */   }
/* 131:    */   
/* 132:    */   public boolean isBinary()
/* 133:    */   {
/* 134:133 */     return this.dataType == 12;
/* 135:    */   }
/* 136:    */   
/* 137:    */   public boolean isBoolean()
/* 138:    */   {
/* 139:138 */     return this.dataType == 8;
/* 140:    */   }
/* 141:    */   
/* 142:    */   public boolean isDateTime()
/* 143:    */   {
/* 144:142 */     return this.dataType == 11;
/* 145:    */   }
/* 146:    */   
/* 147:    */   public boolean isDate()
/* 148:    */   {
/* 149:146 */     return this.dataType == 9;
/* 150:    */   }
/* 151:    */   
/* 152:    */   public boolean isTime()
/* 153:    */   {
/* 154:150 */     return this.dataType == 10;
/* 155:    */   }
/* 156:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.persist.DefaultRDOAttributeInfo
 * JD-Core Version:    0.7.0.1
 */