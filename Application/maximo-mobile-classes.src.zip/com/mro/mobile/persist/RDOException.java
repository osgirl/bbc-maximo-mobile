/*  1:   */ package com.mro.mobile.persist;
/*  2:   */ 
/*  3:   */ import com.mro.mobile.MobileApplicationException;
/*  4:   */ 
/*  5:   */ public class RDOException
/*  6:   */   extends MobileApplicationException
/*  7:   */ {
/*  8:   */   public RDOException(String message)
/*  9:   */   {
/* 10:22 */     super(message);
/* 11:   */   }
/* 12:   */   
/* 13:   */   public RDOException(String message, Throwable nestedException)
/* 14:   */   {
/* 15:27 */     super(message, nestedException);
/* 16:   */   }
/* 17:   */   
/* 18:   */   public RDOException(String message, Object[] params)
/* 19:   */   {
/* 20:32 */     super(message, params);
/* 21:   */   }
/* 22:   */   
/* 23:   */   public RDOException(String message, Object[] params, Throwable nestedException)
/* 24:   */   {
/* 25:37 */     super(message, params, nestedException);
/* 26:   */   }
/* 27:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.persist.RDOException
 * JD-Core Version:    0.7.0.1
 */