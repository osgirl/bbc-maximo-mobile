/*   1:    */ package com.mro.mobile.persist;
/*   2:    */ 
/*   3:    */ import java.util.Hashtable;
/*   4:    */ import java.util.Vector;
/*   5:    */ 
/*   6:    */ public class RDOUtil
/*   7:    */ {
/*   8:    */   public static RDOInfo getRDOInfo(String appName, String name)
/*   9:    */   {
/*  10: 23 */     RDOInfo rdoInfo = null;
/*  11:    */     
/*  12: 25 */     RDORuntime rdoRuntime = RDORuntime.getInstance(appName);
/*  13: 26 */     if (rdoRuntime != null)
/*  14:    */     {
/*  15: 28 */       RDOInfoManager infoManager = rdoRuntime.getRDOInfoManager();
/*  16: 29 */       if (infoManager != null) {
/*  17: 31 */         rdoInfo = infoManager.getInfo(name);
/*  18:    */       }
/*  19:    */     }
/*  20: 37 */     if (rdoInfo == null)
/*  21:    */     {
/*  22: 39 */       rdoRuntime = RDORuntime.getSystemInstance();
/*  23: 40 */       if (rdoRuntime != null)
/*  24:    */       {
/*  25: 42 */         RDOInfoManager infoManager = rdoRuntime.getRDOInfoManager();
/*  26: 43 */         if (infoManager != null) {
/*  27: 45 */           rdoInfo = infoManager.getInfo(name);
/*  28:    */         }
/*  29:    */       }
/*  30:    */     }
/*  31: 50 */     return rdoInfo;
/*  32:    */   }
/*  33:    */   
/*  34: 57 */   private static short rdoInfoId = -1;
/*  35: 59 */   private static Hashtable rdoNameMap = new Hashtable();
/*  36: 60 */   private static Vector rdoList = new Vector(30, 5);
/*  37:    */   
/*  38:    */   public static short registerRDOInfoName(String rdoName)
/*  39:    */   {
/*  40: 64 */     Object obj = rdoNameMap.get(rdoName);
/*  41: 65 */     if (obj != null)
/*  42:    */     {
/*  43: 67 */       Short s = (Short)obj;
/*  44: 68 */       return s.shortValue();
/*  45:    */     }
/*  46: 71 */     short newId = 0;
/*  47: 72 */     synchronized (rdoNameMap)
/*  48:    */     {
/*  49: 74 */       rdoInfoId = (short)(rdoInfoId + 1);
/*  50: 75 */       newId = rdoInfoId;
/*  51:    */     }
/*  52: 78 */     rdoNameMap.put(rdoName, new Short(newId));
/*  53: 79 */     rdoList.setSize(newId + 1);
/*  54: 80 */     rdoList.setElementAt(rdoName, newId);
/*  55:    */     
/*  56: 82 */     return newId;
/*  57:    */   }
/*  58:    */   
/*  59:    */   public static String getRDOInfoName(short id)
/*  60:    */   {
/*  61: 87 */     int currentSize = rdoList.size();
/*  62: 88 */     if ((id < 0) || (id >= currentSize)) {
/*  63: 90 */       return null;
/*  64:    */     }
/*  65: 93 */     return (String)rdoList.elementAt(id);
/*  66:    */   }
/*  67:    */   
/*  68:    */   public static short getRDOInfoId(String rdoName)
/*  69:    */   {
/*  70: 98 */     Object obj = rdoNameMap.get(rdoName);
/*  71: 99 */     if (obj == null) {
/*  72:101 */       return -1;
/*  73:    */     }
/*  74:104 */     Short s = (Short)obj;
/*  75:105 */     return s.shortValue();
/*  76:    */   }
/*  77:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.persist.RDOUtil
 * JD-Core Version:    0.7.0.1
 */