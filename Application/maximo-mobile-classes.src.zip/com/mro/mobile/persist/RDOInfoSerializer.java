/*   1:    */ package com.mro.mobile.persist;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.util.MobileLogger;
/*   4:    */ import com.mro.mobile.util.MobileLoggerFactory;
/*   5:    */ import java.io.DataInput;
/*   6:    */ import java.io.DataOutput;
/*   7:    */ import java.io.IOException;
/*   8:    */ 
/*   9:    */ public class RDOInfoSerializer
/*  10:    */ {
/*  11: 26 */   private static MobileLogger SERIALIZATION_LOGGER = MobileLoggerFactory.getLogger("maximo.mobile.serialization");
/*  12:    */   
/*  13:    */   public Object readInstance(DataInput input)
/*  14:    */     throws IOException
/*  15:    */   {
/*  16: 33 */     return readRDOInfoInstance(input);
/*  17:    */   }
/*  18:    */   
/*  19:    */   public void writeInstance(DataOutput output, Object instance)
/*  20:    */     throws IOException
/*  21:    */   {
/*  22: 41 */     if ((instance instanceof RDOInfo)) {
/*  23: 43 */       writeRDOInfoInstance(output, (RDOInfo)instance);
/*  24:    */     }
/*  25:    */   }
/*  26:    */   
/*  27:    */   private Object readRDOInfoInstance(DataInput input)
/*  28:    */     throws IOException
/*  29:    */   {
/*  30: 49 */     DefaultRDOInfo rdoInfo = new DefaultRDOInfo();
/*  31:    */     
/*  32: 51 */     boolean infoEnabled = SERIALIZATION_LOGGER.isInfoEnabled();
/*  33:    */     
/*  34:    */ 
/*  35: 54 */     String name = input.readUTF();
/*  36: 55 */     rdoInfo.setName(name);
/*  37: 56 */     if (infoEnabled) {
/*  38: 58 */       SERIALIZATION_LOGGER.info("RDOInfoSerializer read name = " + name);
/*  39:    */     }
/*  40: 61 */     boolean hierarchical = input.readBoolean();
/*  41: 62 */     rdoInfo.setHierarchical(hierarchical);
/*  42:    */     
/*  43: 64 */     String parent = input.readUTF();
/*  44: 65 */     if (parent.equals("")) {
/*  45: 67 */       rdoInfo.setParent(null);
/*  46:    */     } else {
/*  47: 71 */       rdoInfo.setParent(parent);
/*  48:    */     }
/*  49: 74 */     int relationSize = input.readInt();
/*  50: 75 */     if (relationSize > 0)
/*  51:    */     {
/*  52: 77 */       byte[] relationData = new byte[relationSize];
/*  53: 78 */       input.readFully(relationData);
/*  54: 79 */       rdoInfo.setDependentRelation(new RDODependentRelation(relationData));
/*  55:    */     }
/*  56: 83 */     int attrCount = input.readInt();
/*  57: 84 */     for (int i = 0; i < attrCount; i++)
/*  58:    */     {
/*  59: 86 */       String attrName = input.readUTF();
/*  60: 87 */       int dataType = input.readInt();
/*  61: 88 */       int length = input.readInt();
/*  62: 89 */       int scale = input.readInt();
/*  63: 90 */       boolean isKey = input.readBoolean();
/*  64: 91 */       boolean persistent = input.readBoolean();
/*  65: 93 */       if (infoEnabled)
/*  66:    */       {
/*  67: 95 */         SERIALIZATION_LOGGER.info("    RDOInfoSerializer read attrName = " + attrName);
/*  68: 96 */         SERIALIZATION_LOGGER.info("    RDOInfoSerializer read length = " + length);
/*  69: 97 */         SERIALIZATION_LOGGER.info("    RDOInfoSerializer read isKey = " + isKey);
/*  70: 98 */         SERIALIZATION_LOGGER.info("    RDOInfoSerializer read persistent = " + persistent);
/*  71: 99 */         SERIALIZATION_LOGGER.info("RDOInfoSerializer read attribute = " + attrName + ", type = " + dataType + ", isKey = " + isKey);
/*  72:    */       }
/*  73:102 */       DefaultRDOAttributeInfo attrInfo = new DefaultRDOAttributeInfo();
/*  74:103 */       attrInfo.setName(attrName);
/*  75:104 */       attrInfo.setDataType(dataType);
/*  76:105 */       attrInfo.setLength(length);
/*  77:106 */       attrInfo.setScale(scale);
/*  78:107 */       attrInfo.setKey(isKey);
/*  79:108 */       attrInfo.setPersistent(persistent);
/*  80:    */       
/*  81:110 */       rdoInfo.addAttributeInfo(attrInfo);
/*  82:    */     }
/*  83:114 */     int dependents = input.readInt();
/*  84:115 */     if (infoEnabled) {
/*  85:117 */       SERIALIZATION_LOGGER.info("RDOInfoSerializer read dependent count = " + dependents);
/*  86:    */     }
/*  87:120 */     for (int i = 0; i < dependents; i++)
/*  88:    */     {
/*  89:122 */       String dependentName = input.readUTF();
/*  90:123 */       if (infoEnabled) {
/*  91:125 */         SERIALIZATION_LOGGER.info("RDOInfoSerializer read dependentName = " + dependentName);
/*  92:    */       }
/*  93:127 */       rdoInfo.addDependent(dependentName);
/*  94:    */     }
/*  95:130 */     return rdoInfo;
/*  96:    */   }
/*  97:    */   
/*  98:    */   private void writeRDOInfoInstance(DataOutput output, RDOInfo rdoInfo)
/*  99:    */     throws IOException
/* 100:    */   {
/* 101:135 */     boolean infoEnabled = SERIALIZATION_LOGGER.isInfoEnabled();
/* 102:    */     
/* 103:    */ 
/* 104:138 */     output.writeUTF(rdoInfo.getName());
/* 105:139 */     if (infoEnabled) {
/* 106:141 */       SERIALIZATION_LOGGER.info("RDOInfoSerializer wrote name = " + rdoInfo.getName());
/* 107:    */     }
/* 108:144 */     output.writeBoolean(rdoInfo.isHierarchical());
/* 109:145 */     String parent = rdoInfo.getParent();
/* 110:146 */     if (parent == null) {
/* 111:148 */       parent = "";
/* 112:    */     }
/* 113:150 */     output.writeUTF(parent);
/* 114:    */     
/* 115:152 */     RDODependentRelation depRelation = rdoInfo.getDependentRelation();
/* 116:153 */     if (depRelation == null)
/* 117:    */     {
/* 118:155 */       output.writeInt(0);
/* 119:    */     }
/* 120:    */     else
/* 121:    */     {
/* 122:159 */       byte[] relationData = depRelation.getBinaryValue();
/* 123:160 */       output.writeInt(relationData.length);
/* 124:161 */       output.write(relationData);
/* 125:    */     }
/* 126:164 */     int attrCount = rdoInfo.getAttributeCount();
/* 127:165 */     output.writeInt(attrCount);
/* 128:166 */     if (infoEnabled) {
/* 129:168 */       SERIALIZATION_LOGGER.info("RDOInfoSerializer wrote attrCount = " + attrCount);
/* 130:    */     }
/* 131:171 */     String[] attrNames = rdoInfo.getAttributeNames();
/* 132:172 */     for (int i = 0; i < attrCount; i++)
/* 133:    */     {
/* 134:174 */       RDOAttributeInfo attrInfo = rdoInfo.getAttributeInfo(attrNames[i]);
/* 135:    */       
/* 136:176 */       String attrName = attrInfo.getName();
/* 137:177 */       int dataType = attrInfo.getDataType();
/* 138:178 */       int length = attrInfo.getLength();
/* 139:    */       
/* 140:180 */       int scale = attrInfo.getScale();
/* 141:181 */       boolean isKey = attrInfo.isKey();
/* 142:182 */       boolean persistent = attrInfo.isPersistent();
/* 143:183 */       if (infoEnabled)
/* 144:    */       {
/* 145:185 */         SERIALIZATION_LOGGER.info("    RDOInfoSerializer wrote attrName = " + attrName);
/* 146:186 */         SERIALIZATION_LOGGER.info("    RDOInfoSerializer wrote length = " + length);
/* 147:187 */         SERIALIZATION_LOGGER.info("    RDOInfoSerializer wrote isKey = " + isKey);
/* 148:188 */         SERIALIZATION_LOGGER.info("    RDOInfoSerializer wrote persistent = " + persistent);
/* 149:189 */         SERIALIZATION_LOGGER.info("RDOInfoSerializer wrote attribute = " + attrName + ", type = " + dataType + ", isKey = " + isKey);
/* 150:    */       }
/* 151:192 */       output.writeUTF(attrName);
/* 152:193 */       output.writeInt(dataType);
/* 153:194 */       output.writeInt(length);
/* 154:195 */       output.writeInt(scale);
/* 155:196 */       output.writeBoolean(isKey);
/* 156:197 */       output.writeBoolean(persistent);
/* 157:    */     }
/* 158:201 */     int dependentCount = rdoInfo.getDependentCount();
/* 159:202 */     output.writeInt(dependentCount);
/* 160:204 */     if (infoEnabled) {
/* 161:206 */       SERIALIZATION_LOGGER.info("RDOInfoSerializer wrote dependent count = " + dependentCount);
/* 162:    */     }
/* 163:209 */     String[] dependentNames = rdoInfo.getDependentNames();
/* 164:210 */     for (int i = 0; i < dependentCount; i++)
/* 165:    */     {
/* 166:212 */       output.writeUTF(dependentNames[i]);
/* 167:214 */       if (infoEnabled) {
/* 168:216 */         SERIALIZATION_LOGGER.info("RDOInfoSerializer wrote dependent name = " + dependentNames[i]);
/* 169:    */       }
/* 170:    */     }
/* 171:    */   }
/* 172:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.persist.RDOInfoSerializer
 * JD-Core Version:    0.7.0.1
 */