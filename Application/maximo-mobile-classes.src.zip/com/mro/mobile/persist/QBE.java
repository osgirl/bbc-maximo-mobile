/*  1:   */ package com.mro.mobile.persist;
/*  2:   */ 
/*  3:   */ import java.util.Date;
/*  4:   */ import java.util.Enumeration;
/*  5:   */ 
/*  6:   */ public abstract interface QBE
/*  7:   */ {
/*  8:22 */   public static final String[] EXPRLIST = { "!=", "<=", ">=", "<", ">", "=" };
/*  9:   */   
/* 10:   */   public abstract void setQBE(String paramString1, String paramString2)
/* 11:   */     throws RDOException;
/* 12:   */   
/* 13:   */   public abstract String getQBE(String paramString)
/* 14:   */     throws RDOException;
/* 15:   */   
/* 16:   */   public abstract QBEData getQBEData(String paramString)
/* 17:   */     throws RDOException;
/* 18:   */   
/* 19:   */   public abstract void setDateQBE(String paramString1, String paramString2, Date paramDate, String paramString3)
/* 20:   */     throws RDOException;
/* 21:   */   
/* 22:   */   public abstract Enumeration getQBEAttributes()
/* 23:   */     throws RDOException;
/* 24:   */   
/* 25:   */   public abstract void setQbeExactMatch(boolean paramBoolean)
/* 26:   */     throws RDOException;
/* 27:   */   
/* 28:   */   public abstract boolean isQbeExactMatch()
/* 29:   */     throws RDOException;
/* 30:   */   
/* 31:   */   public abstract void reset()
/* 32:   */     throws RDOException;
/* 33:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.persist.QBE
 * JD-Core Version:    0.7.0.1
 */