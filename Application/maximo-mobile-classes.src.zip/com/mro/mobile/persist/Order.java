package com.mro.mobile.persist;

import java.util.Enumeration;

public abstract interface Order
{
  public abstract void setOrder(String paramString, boolean paramBoolean);
  
  public abstract void setOrderFirst(String paramString, boolean paramBoolean);
  
  public abstract boolean getOrder(String paramString)
    throws RDOException;
  
  public abstract void resetOrder(String paramString);
  
  public abstract Enumeration getOrderedAttributes();
  
  public abstract void reset();
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.persist.Order
 * JD-Core Version:    0.7.0.1
 */