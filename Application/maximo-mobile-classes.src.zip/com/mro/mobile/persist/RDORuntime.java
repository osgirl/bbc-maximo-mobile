/*   1:    */ package com.mro.mobile.persist;
/*   2:    */ 
/*   3:    */ import java.util.Hashtable;
/*   4:    */ 
/*   5:    */ public class RDORuntime
/*   6:    */ {
/*   7: 23 */   RDOManager rdoManager = null;
/*   8: 24 */   RDOInfoManager rdoInfoManager = null;
/*   9: 25 */   RDOTransactionManager rdoTransactionManager = null;
/*  10:    */   private String version;
/*  11:    */   
/*  12:    */   public boolean isInfoDataUpdated(String currentVersion)
/*  13:    */   {
/*  14: 33 */     if (this.version == null) {
/*  15: 33 */       return false;
/*  16:    */     }
/*  17: 35 */     return this.version.compareTo(currentVersion) == 0;
/*  18:    */   }
/*  19:    */   
/*  20:    */   public void resetIfInfoDataNotUpdated(String currentVersion)
/*  21:    */     throws RDOException
/*  22:    */   {
/*  23: 40 */     if ((!isInfoDataUpdated(currentVersion)) && 
/*  24: 41 */       (this.rdoInfoManager != null)) {
/*  25: 41 */       this.rdoInfoManager.removeAll();
/*  26:    */     }
/*  27: 43 */     this.version = currentVersion;
/*  28:    */   }
/*  29:    */   
/*  30:    */   public void registerRDOInfoManager(RDOInfoManager rdoInfoManager)
/*  31:    */   {
/*  32: 48 */     this.rdoInfoManager = rdoInfoManager;
/*  33:    */   }
/*  34:    */   
/*  35:    */   public RDOInfoManager getRDOInfoManager()
/*  36:    */   {
/*  37: 53 */     return this.rdoInfoManager;
/*  38:    */   }
/*  39:    */   
/*  40:    */   public void registerRDOManager(RDOManager rdoManager)
/*  41:    */   {
/*  42: 70 */     this.rdoManager = rdoManager;
/*  43:    */   }
/*  44:    */   
/*  45:    */   public RDOManager getRDOManager()
/*  46:    */   {
/*  47: 75 */     return this.rdoManager;
/*  48:    */   }
/*  49:    */   
/*  50:    */   public void registerRDOTransactionManager(RDOTransactionManager rdoTransactionManager)
/*  51:    */   {
/*  52: 80 */     this.rdoTransactionManager = rdoTransactionManager;
/*  53:    */   }
/*  54:    */   
/*  55:    */   public RDOTransactionManager getRDOTransactionManager()
/*  56:    */   {
/*  57: 85 */     return this.rdoTransactionManager;
/*  58:    */   }
/*  59:    */   
/*  60: 89 */   private static RDORuntime rdoRuntime = new RDORuntime();
/*  61:    */   
/*  62:    */   public static RDORuntime getSystemInstance()
/*  63:    */   {
/*  64: 93 */     if (rdoRuntime == null) {
/*  65: 95 */       rdoRuntime = new RDORuntime();
/*  66:    */     }
/*  67: 98 */     return rdoRuntime;
/*  68:    */   }
/*  69:    */   
/*  70:101 */   static Object lock = new Object();
/*  71:    */   
/*  72:    */   public static void resetSystemInstance()
/*  73:    */   {
/*  74:105 */     synchronized (lock)
/*  75:    */     {
/*  76:    */       try
/*  77:    */       {
/*  78:110 */         if (rdoRuntime != null)
/*  79:    */         {
/*  80:112 */           rdoRuntime.getRDOInfoManager().release();
/*  81:113 */           rdoRuntime.getRDOManager().release();
/*  82:    */         }
/*  83:    */       }
/*  84:    */       catch (Exception ex) {}
/*  85:121 */       rdoRuntime = new RDORuntime();
/*  86:    */     }
/*  87:    */   }
/*  88:    */   
/*  89:    */   public static RDORuntime getNewInstance()
/*  90:    */   {
/*  91:127 */     return new RDORuntime();
/*  92:    */   }
/*  93:    */   
/*  94:132 */   private static Hashtable rdoRuntimes = new Hashtable();
/*  95:    */   
/*  96:    */   public static void registerInstance(String appName, RDORuntime rdoRuntime)
/*  97:    */   {
/*  98:136 */     rdoRuntimes.put(appName, rdoRuntime);
/*  99:    */   }
/* 100:    */   
/* 101:    */   public static void unregisterInstance(String appName)
/* 102:    */   {
/* 103:142 */     RDORuntime appRdoRuntime = getInstance(appName);
/* 104:143 */     if (appRdoRuntime == null) {
/* 105:145 */       return;
/* 106:    */     }
/* 107:    */     try
/* 108:    */     {
/* 109:151 */       appRdoRuntime.getRDOInfoManager().release();
/* 110:152 */       appRdoRuntime.getRDOManager().release();
/* 111:    */     }
/* 112:    */     catch (Exception ex) {}
/* 113:160 */     rdoRuntimes.remove(appName);
/* 114:    */   }
/* 115:    */   
/* 116:    */   public static RDORuntime getInstance(String appName)
/* 117:    */   {
/* 118:165 */     RDORuntime appRDORuntime = (RDORuntime)rdoRuntimes.get(appName);
/* 119:166 */     if (appRDORuntime == null) {
/* 120:168 */       return getSystemInstance();
/* 121:    */     }
/* 122:171 */     return appRDORuntime;
/* 123:    */   }
/* 124:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.persist.RDORuntime
 * JD-Core Version:    0.7.0.1
 */