/*  1:   */ package com.mro.mobile.persist;
/*  2:   */ 
/*  3:   */ import java.io.ByteArrayInputStream;
/*  4:   */ import java.io.ByteArrayOutputStream;
/*  5:   */ import java.io.DataInputStream;
/*  6:   */ import java.io.DataOutputStream;
/*  7:   */ import java.io.IOException;
/*  8:   */ import java.util.Vector;
/*  9:   */ 
/* 10:   */ public class RDODependentRelation
/* 11:   */ {
/* 12:25 */   private Vector relationConditions = new Vector();
/* 13:   */   
/* 14:   */   public RDODependentRelation() {}
/* 15:   */   
/* 16:   */   public RDODependentRelation(byte[] data)
/* 17:   */     throws IOException
/* 18:   */   {
/* 19:34 */     ByteArrayInputStream bis = new ByteArrayInputStream(data);
/* 20:35 */     DataInputStream dis = new DataInputStream(bis);
/* 21:   */     
/* 22:37 */     int size = dis.readInt();
/* 23:39 */     for (int i = 0; i < size; i++)
/* 24:   */     {
/* 25:41 */       String parentAttr = dis.readUTF();
/* 26:42 */       String childAttr = dis.readUTF();
/* 27:   */       
/* 28:44 */       addCondition(parentAttr, childAttr);
/* 29:   */     }
/* 30:   */   }
/* 31:   */   
/* 32:   */   public int size()
/* 33:   */   {
/* 34:51 */     return this.relationConditions.size();
/* 35:   */   }
/* 36:   */   
/* 37:   */   public String[] getCondition(int index)
/* 38:   */   {
/* 39:56 */     return (String[])this.relationConditions.elementAt(index);
/* 40:   */   }
/* 41:   */   
/* 42:   */   public void addCondition(String parentAttribute, String childAttribute)
/* 43:   */   {
/* 44:61 */     String[] match = { parentAttribute, childAttribute };
/* 45:62 */     this.relationConditions.addElement(match);
/* 46:   */   }
/* 47:   */   
/* 48:   */   public byte[] getBinaryValue()
/* 49:   */     throws IOException
/* 50:   */   {
/* 51:67 */     ByteArrayOutputStream bos = new ByteArrayOutputStream();
/* 52:68 */     DataOutputStream dout = new DataOutputStream(bos);
/* 53:   */     
/* 54:70 */     int size = size();
/* 55:71 */     dout.writeInt(size);
/* 56:73 */     for (int i = 0; i < size; i++)
/* 57:   */     {
/* 58:75 */       String[] conditionArray = getCondition(i);
/* 59:76 */       dout.writeUTF(conditionArray[0]);
/* 60:77 */       dout.writeUTF(conditionArray[1]);
/* 61:   */     }
/* 62:80 */     dout.flush();
/* 63:   */     
/* 64:82 */     return bos.toByteArray();
/* 65:   */   }
/* 66:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.persist.RDODependentRelation
 * JD-Core Version:    0.7.0.1
 */