package com.mro.mobile.persist;

import com.mro.mobile.persist.sql.MobileWhereClause;
import java.util.Date;

public abstract interface RDO
{
  public abstract String getAppName();
  
  public abstract String getName();
  
  public abstract RDOInfo getInfo();
  
  public abstract long getId()
    throws RDOException;
  
  public abstract void setId(long paramLong)
    throws RDOException;
  
  public abstract RDOKey getKey()
    throws RDOException;
  
  public abstract void setStringValue(String paramString1, String paramString2)
    throws RDOException;
  
  public abstract void setBooleanValue(String paramString, boolean paramBoolean)
    throws RDOException;
  
  public abstract void setLongValue(String paramString, long paramLong)
    throws RDOException;
  
  public abstract void setIntValue(String paramString, int paramInt)
    throws RDOException;
  
  public abstract void setBinaryValue(String paramString, byte[] paramArrayOfByte)
    throws RDOException;
  
  public abstract void setDateValue(String paramString, Date paramDate)
    throws RDOException;
  
  public abstract String getStringValue(String paramString)
    throws RDOException;
  
  public abstract boolean getBooleanValue(String paramString)
    throws RDOException;
  
  public abstract long getLongValue(String paramString)
    throws RDOException;
  
  public abstract int getIntValue(String paramString)
    throws RDOException;
  
  public abstract byte[] getBinaryValue(String paramString)
    throws RDOException;
  
  public abstract Date getDateValue(String paramString)
    throws RDOException;
  
  public abstract boolean isNull(String paramString)
    throws RDOException;
  
  public abstract void setFlag(int paramInt, boolean paramBoolean);
  
  public abstract boolean isFlagSet(int paramInt);
  
  public abstract boolean isReadOnly();
  
  public abstract void setFlag(String paramString, int paramInt, boolean paramBoolean);
  
  public abstract boolean isFlagSet(String paramString, int paramInt);
  
  public abstract boolean isReadOnly(String paramString);
  
  public abstract RDO createDependent(String paramString)
    throws RDOException;
  
  public abstract void removeDependent(String paramString, RDO paramRDO)
    throws RDOException;
  
  public abstract RDOEnumeration getDependents(String paramString)
    throws RDOException;
  
  public abstract RDOEnumeration getDependents(String paramString, QBE paramQBE, Order paramOrder)
    throws RDOException;
  
  public abstract RDOEnumeration getDependents(String paramString, QBE paramQBE, MobileWhereClause paramMobileWhereClause, Order paramOrder)
    throws RDOException;
  
  public abstract int getDependentSize(String paramString)
    throws RDOException;
  
  public abstract int getDependentSize(String paramString, QBE paramQBE)
    throws RDOException;
  
  public abstract int getDependentSize(String paramString, QBE paramQBE, MobileWhereClause paramMobileWhereClause);
  
  public abstract void resetDependent(String paramString)
    throws RDOException;
  
  public abstract void resetDependents()
    throws RDOException;
  
  public abstract RDO getOwner();
  
  public abstract void setDoubleValue(String paramString, double paramDouble)
    throws RDOException;
  
  public abstract double getDoubleValue(String paramString)
    throws RDOException;
  
  public abstract void setFloatValue(String paramString, float paramFloat)
    throws RDOException;
  
  public abstract float getFloatValue(String paramString)
    throws RDOException;
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.persist.RDO
 * JD-Core Version:    0.7.0.1
 */