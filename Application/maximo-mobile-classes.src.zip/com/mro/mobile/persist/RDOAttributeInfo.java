package com.mro.mobile.persist;

public abstract interface RDOAttributeInfo
{
  public static final int ALN = 1;
  public static final int UPPER = 2;
  public static final int LOWER = 3;
  public static final int INTEGER = 4;
  public static final int LONG = 5;
  public static final int FLOAT = 6;
  public static final int DOUBLE = 7;
  public static final int BOOLEAN = 8;
  public static final int DATE = 9;
  public static final int TIME = 10;
  public static final int DATETIME = 11;
  public static final int BINARY = 12;
  
  public abstract String getName();
  
  public abstract boolean isKey();
  
  public abstract int getDataType();
  
  public abstract int getLength();
  
  public abstract int getScale();
  
  public abstract boolean isPersistent();
  
  public abstract boolean isAlphaNumeric();
  
  public abstract boolean isNumeric();
  
  public abstract boolean isDecimal();
  
  public abstract boolean isInteger();
  
  public abstract boolean isBinary();
  
  public abstract boolean isDateTime();
  
  public abstract boolean isDate();
  
  public abstract boolean isTime();
  
  public abstract boolean isBoolean();
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.persist.RDOAttributeInfo
 * JD-Core Version:    0.7.0.1
 */