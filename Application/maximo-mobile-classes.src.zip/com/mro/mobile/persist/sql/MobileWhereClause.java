/*   1:    */ package com.mro.mobile.persist.sql;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.type.Serializer;
/*   4:    */ import com.mro.mobile.type.TypeRegistry;
/*   5:    */ import java.io.DataInput;
/*   6:    */ import java.io.DataOutput;
/*   7:    */ import java.io.IOException;
/*   8:    */ import java.sql.SQLException;
/*   9:    */ import java.util.Date;
/*  10:    */ import java.util.HashMap;
/*  11:    */ 
/*  12:    */ public class MobileWhereClause
/*  13:    */   implements Serializer
/*  14:    */ {
/*  15:    */   public static final byte BYTE = 0;
/*  16:    */   public static final byte CHAR = 1;
/*  17:    */   public static final byte STRING = 2;
/*  18:    */   public static final byte SHORT = 3;
/*  19:    */   public static final byte INT = 4;
/*  20:    */   public static final byte LONG = 5;
/*  21:    */   public static final byte FLOAT = 6;
/*  22:    */   public static final byte DOUBLE = 7;
/*  23:    */   public static final byte DATE = 8;
/*  24:    */   private static final int YES_LEN = 3;
/*  25:    */   private static final int NO_LEN = 2;
/*  26:    */   private static final int DATE_LEN = 4;
/*  27:    */   private static final int DATETIME_LEN = 8;
/*  28: 50 */   private static HashMap cache = new HashMap();
/*  29: 52 */   String originalWhere = null;
/*  30: 53 */   String convertedWhere = null;
/*  31: 54 */   Object[] parameters = null;
/*  32:    */   
/*  33:    */   private MobileWhereClause(String whereClause, Object[] parameters)
/*  34:    */   {
/*  35: 58 */     this.originalWhere = whereClause;
/*  36: 59 */     this.parameters = parameters;
/*  37:    */   }
/*  38:    */   
/*  39:    */   private MobileWhereClause() {}
/*  40:    */   
/*  41:    */   public static void initSerializer()
/*  42:    */   {
/*  43: 69 */     MobileWhereClause i = new MobileWhereClause();
/*  44:    */     
/*  45: 71 */     TypeRegistry.getTypeRegistry().addType("MobileWhereClause", i.getClass(), i);
/*  46:    */   }
/*  47:    */   
/*  48:    */   public static MobileWhereClause createWhereClause(String whereClause, Object[] parameters)
/*  49:    */   {
/*  50: 76 */     MobileWhereClause result = (MobileWhereClause)cache.get(whereClause);
/*  51: 77 */     if (result == null)
/*  52:    */     {
/*  53: 79 */       result = new MobileWhereClause(whereClause, parameters);
/*  54: 80 */       cache.put(whereClause, result);
/*  55:    */     }
/*  56:    */     else
/*  57:    */     {
/*  58: 84 */       result.setParameters(parameters);
/*  59:    */     }
/*  60: 87 */     return result;
/*  61:    */   }
/*  62:    */   
/*  63:    */   public Object readInstance(DataInput dis, String name)
/*  64:    */     throws IOException
/*  65:    */   {
/*  66: 92 */     String originalWhere = dis.readUTF();
/*  67:    */     
/*  68: 94 */     int nValues = dis.readInt();
/*  69: 95 */     Object[] params = new Object[nValues];
/*  70: 96 */     if (nValues > 0) {
/*  71: 98 */       for (int i = 0; i < nValues; i++)
/*  72:    */       {
/*  73:100 */         byte type = dis.readByte();
/*  74:101 */         switch (type)
/*  75:    */         {
/*  76:    */         case 0: 
/*  77:105 */           byte value = dis.readByte();
/*  78:106 */           params[i] = new Byte(value);
/*  79:107 */           break;
/*  80:    */         case 1: 
/*  81:111 */           char value = dis.readChar();
/*  82:112 */           params[i] = new Character(value);
/*  83:113 */           break;
/*  84:    */         case 2: 
/*  85:117 */           String value = dis.readUTF();
/*  86:118 */           params[i] = value;
/*  87:119 */           break;
/*  88:    */         case 3: 
/*  89:123 */           short value = dis.readShort();
/*  90:124 */           params[i] = new Short(value);
/*  91:125 */           break;
/*  92:    */         case 4: 
/*  93:129 */           int value = dis.readInt();
/*  94:130 */           params[i] = new Integer(value);
/*  95:131 */           break;
/*  96:    */         case 5: 
/*  97:135 */           long value = dis.readLong();
/*  98:136 */           params[i] = new Long(value);
/*  99:137 */           break;
/* 100:    */         case 6: 
/* 101:141 */           float value = dis.readFloat();
/* 102:142 */           params[i] = new Float(value);
/* 103:143 */           break;
/* 104:    */         case 7: 
/* 105:147 */           double value = dis.readDouble();
/* 106:148 */           params[i] = new Double(value);
/* 107:149 */           break;
/* 108:    */         case 8: 
/* 109:153 */           long value = dis.readLong();
/* 110:154 */           Date date = new Date(value);
/* 111:155 */           params[i] = date;
/* 112:    */         }
/* 113:    */       }
/* 114:    */     }
/* 115:162 */     MobileWhereClause newWhere = new MobileWhereClause();
/* 116:163 */     newWhere.originalWhere = originalWhere;
/* 117:164 */     newWhere.parameters = params;
/* 118:    */     
/* 119:166 */     return newWhere;
/* 120:    */   }
/* 121:    */   
/* 122:    */   public void writeInstance(DataOutput dos, Object obj)
/* 123:    */     throws IOException
/* 124:    */   {
/* 125:172 */     if ((obj instanceof MobileWhereClause))
/* 126:    */     {
/* 127:174 */       MobileWhereClause whereClause = (MobileWhereClause)obj;
/* 128:175 */       if (whereClause.originalWhere == null) {
/* 129:177 */         dos.writeUTF("");
/* 130:    */       } else {
/* 131:181 */         dos.writeUTF(whereClause.originalWhere);
/* 132:    */       }
/* 133:184 */       if (whereClause.parameters == null)
/* 134:    */       {
/* 135:186 */         dos.writeInt(0);
/* 136:    */       }
/* 137:    */       else
/* 138:    */       {
/* 139:190 */         dos.writeInt(whereClause.parameters.length);
/* 140:    */         
/* 141:192 */         SerializationValueProcessorCommand cmd = new SerializationValueProcessorCommand(dos);
/* 142:193 */         ValueListProcessor.processValueList(whereClause.parameters, cmd);
/* 143:    */       }
/* 144:    */     }
/* 145:    */   }
/* 146:    */   
/* 147:    */   public static MobileWhereClause createWhereClause(String whereClause)
/* 148:    */   {
/* 149:201 */     return createWhereClause(whereClause, null);
/* 150:    */   }
/* 151:    */   
/* 152:    */   public Object[] getParameters()
/* 153:    */   {
/* 154:207 */     return this.parameters;
/* 155:    */   }
/* 156:    */   
/* 157:    */   void setParameters(Object[] parameters)
/* 158:    */   {
/* 159:212 */     this.parameters = parameters;
/* 160:    */   }
/* 161:    */   
/* 162:    */   public String getOriginalWhere()
/* 163:    */   {
/* 164:217 */     return this.originalWhere;
/* 165:    */   }
/* 166:    */   
/* 167:    */   public String getConvertedWhere()
/* 168:    */   {
/* 169:222 */     return getConvertedWhere(new DefaultMobileWhereClauseVariableResolver());
/* 170:    */   }
/* 171:    */   
/* 172:    */   public String getConvertedWhere(MobileWhereClauseVariableResolver resolver)
/* 173:    */   {
/* 174:227 */     if (this.convertedWhere == null) {
/* 175:229 */       convertWhere(resolver);
/* 176:    */     }
/* 177:231 */     return this.convertedWhere;
/* 178:    */   }
/* 179:    */   
/* 180:    */   public void applyParameters(ApplyParametersValueProcessor processor)
/* 181:    */     throws SQLException
/* 182:    */   {
/* 183:236 */     if ((this.parameters != null) && (this.parameters.length > 0)) {
/* 184:238 */       ValueListProcessor.processValueList(this.parameters, processor);
/* 185:    */     }
/* 186:    */   }
/* 187:    */   
/* 188:    */   private void convertWhere(MobileWhereClauseVariableResolver resolver)
/* 189:    */   {
/* 190:244 */     int pos = this.originalWhere.indexOf(':');
/* 191:245 */     int lastPos = 0;
/* 192:246 */     String trailingText = this.originalWhere;
/* 193:    */     
/* 194:248 */     StringBuffer result = new StringBuffer();
/* 195:249 */     while (pos > -1)
/* 196:    */     {
/* 197:251 */       String leadingText = this.originalWhere.substring(lastPos, pos);
/* 198:252 */       result.append(leadingText);
/* 199:    */       
/* 200:254 */       pos++;
/* 201:255 */       trailingText = this.originalWhere.substring(pos);
/* 202:257 */       if (trailingText.toLowerCase().startsWith("yes"))
/* 203:    */       {
/* 204:259 */         result.append(resolver.getValueForYes());
/* 205:260 */         lastPos = pos + 3;
/* 206:    */       }
/* 207:262 */       else if (trailingText.toLowerCase().startsWith("no"))
/* 208:    */       {
/* 209:264 */         result.append(resolver.getValueForNo());
/* 210:265 */         lastPos = pos + 2;
/* 211:    */       }
/* 212:267 */       else if (trailingText.toLowerCase().startsWith("datetime"))
/* 213:    */       {
/* 214:269 */         result.append(resolver.getValueForDateTime());
/* 215:270 */         lastPos = pos + 8;
/* 216:    */       }
/* 217:272 */       else if (trailingText.toLowerCase().startsWith("date"))
/* 218:    */       {
/* 219:274 */         result.append(resolver.getValueForDate());
/* 220:275 */         lastPos = pos + 4;
/* 221:    */       }
/* 222:    */       else
/* 223:    */       {
/* 224:279 */         result.append(trailingText);
/* 225:280 */         trailingText = this.originalWhere.substring(pos);
/* 226:281 */         lastPos = pos;
/* 227:    */       }
/* 228:284 */       trailingText = this.originalWhere.substring(lastPos);
/* 229:285 */       pos = this.originalWhere.indexOf(':', lastPos);
/* 230:    */     }
/* 231:288 */     result.append(trailingText);
/* 232:    */     
/* 233:290 */     this.convertedWhere = result.toString();
/* 234:    */   }
/* 235:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.persist.sql.MobileWhereClause
 * JD-Core Version:    0.7.0.1
 */