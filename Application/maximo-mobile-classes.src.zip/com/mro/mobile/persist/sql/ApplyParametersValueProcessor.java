/*  1:   */ package com.mro.mobile.persist.sql;
/*  2:   */ 
/*  3:   */ import com.mro.mobile.util.MobileLogger;
/*  4:   */ import com.mro.mobile.util.MobileLoggerFactory;
/*  5:   */ 
/*  6:   */ public abstract class ApplyParametersValueProcessor
/*  7:   */   implements IValueProcessorCommand
/*  8:   */ {
/*  9:   */   protected int currentPos;
/* 10:   */   protected Object originalStatement;
/* 11:   */   protected MobileLogger DBLOGGER;
/* 12:   */   
/* 13:   */   public ApplyParametersValueProcessor(Object statement, int startPosition)
/* 14:   */   {
/* 15:13 */     this(statement, startPosition, MobileLoggerFactory.getLogger("maximo.mobile.persistence"));
/* 16:   */   }
/* 17:   */   
/* 18:   */   public ApplyParametersValueProcessor(Object statement, int startPosition, MobileLogger logger)
/* 19:   */   {
/* 20:17 */     if (statement == null) {
/* 21:17 */       throw new IllegalArgumentException("statement cannot be null");
/* 22:   */     }
/* 23:18 */     if (startPosition < 0) {
/* 24:18 */       throw new IllegalArgumentException("start position must be >= 0");
/* 25:   */     }
/* 26:19 */     if (logger == null) {
/* 27:19 */       throw new IllegalArgumentException("logger cannot be null");
/* 28:   */     }
/* 29:21 */     this.originalStatement = statement;
/* 30:22 */     this.currentPos = startPosition;
/* 31:23 */     this.DBLOGGER = logger;
/* 32:   */   }
/* 33:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.persist.sql.ApplyParametersValueProcessor
 * JD-Core Version:    0.7.0.1
 */