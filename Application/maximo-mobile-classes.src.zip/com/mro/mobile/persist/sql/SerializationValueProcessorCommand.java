/*  1:   */ package com.mro.mobile.persist.sql;
/*  2:   */ 
/*  3:   */ import java.io.DataOutput;
/*  4:   */ import java.io.IOException;
/*  5:   */ import java.util.Date;
/*  6:   */ 
/*  7:   */ public class SerializationValueProcessorCommand
/*  8:   */   implements IValueProcessorCommand
/*  9:   */ {
/* 10:10 */   private DataOutput dos = null;
/* 11:   */   
/* 12:   */   public SerializationValueProcessorCommand(DataOutput dos)
/* 13:   */   {
/* 14:13 */     this.dos = dos;
/* 15:   */   }
/* 16:   */   
/* 17:   */   public void processByte(byte value)
/* 18:   */   {
/* 19:   */     try
/* 20:   */     {
/* 21:18 */       this.dos.writeByte(0);
/* 22:19 */       this.dos.writeByte(value);
/* 23:   */     }
/* 24:   */     catch (IOException e)
/* 25:   */     {
/* 26:21 */       throw new RuntimeException(e);
/* 27:   */     }
/* 28:   */   }
/* 29:   */   
/* 30:   */   public void processChar(char value)
/* 31:   */   {
/* 32:   */     try
/* 33:   */     {
/* 34:27 */       this.dos.writeByte(1);
/* 35:28 */       this.dos.writeChar(value);
/* 36:   */     }
/* 37:   */     catch (IOException e)
/* 38:   */     {
/* 39:30 */       throw new RuntimeException(e);
/* 40:   */     }
/* 41:   */   }
/* 42:   */   
/* 43:   */   public void processString(String value)
/* 44:   */   {
/* 45:   */     try
/* 46:   */     {
/* 47:36 */       this.dos.writeByte(2);
/* 48:37 */       this.dos.writeUTF(value);
/* 49:   */     }
/* 50:   */     catch (IOException e)
/* 51:   */     {
/* 52:39 */       throw new RuntimeException(e);
/* 53:   */     }
/* 54:   */   }
/* 55:   */   
/* 56:   */   public void processShort(short value)
/* 57:   */   {
/* 58:   */     try
/* 59:   */     {
/* 60:45 */       this.dos.writeByte(3);
/* 61:46 */       this.dos.writeShort(value);
/* 62:   */     }
/* 63:   */     catch (IOException e)
/* 64:   */     {
/* 65:48 */       throw new RuntimeException(e);
/* 66:   */     }
/* 67:   */   }
/* 68:   */   
/* 69:   */   public void processInt(int value)
/* 70:   */   {
/* 71:   */     try
/* 72:   */     {
/* 73:54 */       this.dos.writeByte(4);
/* 74:55 */       this.dos.writeInt(value);
/* 75:   */     }
/* 76:   */     catch (IOException e)
/* 77:   */     {
/* 78:57 */       throw new RuntimeException(e);
/* 79:   */     }
/* 80:   */   }
/* 81:   */   
/* 82:   */   public void processLong(long value)
/* 83:   */   {
/* 84:   */     try
/* 85:   */     {
/* 86:63 */       this.dos.writeByte(5);
/* 87:64 */       this.dos.writeLong(value);
/* 88:   */     }
/* 89:   */     catch (IOException e)
/* 90:   */     {
/* 91:66 */       throw new RuntimeException(e);
/* 92:   */     }
/* 93:   */   }
/* 94:   */   
/* 95:   */   public void processFloat(float value)
/* 96:   */   {
/* 97:   */     try
/* 98:   */     {
/* 99:72 */       this.dos.writeByte(6);
/* :0:73 */       this.dos.writeFloat(value);
/* :1:   */     }
/* :2:   */     catch (IOException e)
/* :3:   */     {
/* :4:75 */       throw new RuntimeException(e);
/* :5:   */     }
/* :6:   */   }
/* :7:   */   
/* :8:   */   public void processDouble(double value)
/* :9:   */   {
/* ;0:   */     try
/* ;1:   */     {
/* ;2:81 */       this.dos.writeByte(7);
/* ;3:82 */       this.dos.writeDouble(value);
/* ;4:   */     }
/* ;5:   */     catch (IOException e)
/* ;6:   */     {
/* ;7:84 */       throw new RuntimeException(e);
/* ;8:   */     }
/* ;9:   */   }
/* <0:   */   
/* <1:   */   public void processDate(Date value)
/* <2:   */   {
/* <3:   */     try
/* <4:   */     {
/* <5:90 */       this.dos.writeByte(8);
/* <6:91 */       long dateAsLong = value.getTime();
/* <7:92 */       this.dos.writeLong(dateAsLong);
/* <8:   */     }
/* <9:   */     catch (IOException e)
/* =0:   */     {
/* =1:94 */       throw new RuntimeException(e);
/* =2:   */     }
/* =3:   */   }
/* =4:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.persist.sql.SerializationValueProcessorCommand
 * JD-Core Version:    0.7.0.1
 */