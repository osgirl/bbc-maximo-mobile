package com.mro.mobile.persist.sql;

import java.util.Date;

abstract interface IValueProcessorCommand
{
  public abstract void processByte(byte paramByte);
  
  public abstract void processChar(char paramChar);
  
  public abstract void processString(String paramString);
  
  public abstract void processShort(short paramShort);
  
  public abstract void processInt(int paramInt);
  
  public abstract void processLong(long paramLong);
  
  public abstract void processFloat(float paramFloat);
  
  public abstract void processDouble(double paramDouble);
  
  public abstract void processDate(Date paramDate);
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.persist.sql.IValueProcessorCommand
 * JD-Core Version:    0.7.0.1
 */