/*  1:   */ package com.mro.mobile.persist.sql;
/*  2:   */ 
/*  3:   */ import java.util.Date;
/*  4:   */ 
/*  5:   */ class ValueListProcessor
/*  6:   */ {
/*  7:   */   public static void processValueList(Object[] values, IValueProcessorCommand command)
/*  8:   */   {
/*  9:22 */     int nValues = values.length;
/* 10:23 */     for (int i = 0; i < nValues; i++)
/* 11:   */     {
/* 12:25 */       Object value = values[i];
/* 13:27 */       if ((value instanceof String)) {
/* 14:29 */         command.processString((String)value);
/* 15:31 */       } else if ((value instanceof Character)) {
/* 16:33 */         command.processChar(((Character)value).charValue());
/* 17:35 */       } else if ((value instanceof Byte)) {
/* 18:37 */         command.processByte(((Byte)value).byteValue());
/* 19:39 */       } else if ((value instanceof Integer)) {
/* 20:41 */         command.processInt(((Integer)value).intValue());
/* 21:43 */       } else if ((value instanceof Long)) {
/* 22:45 */         command.processLong(((Long)value).longValue());
/* 23:47 */       } else if ((value instanceof Short)) {
/* 24:49 */         command.processShort(((Short)value).shortValue());
/* 25:51 */       } else if ((value instanceof Float)) {
/* 26:53 */         command.processFloat(((Float)value).floatValue());
/* 27:55 */       } else if ((value instanceof Double)) {
/* 28:57 */         command.processDouble(((Double)value).doubleValue());
/* 29:59 */       } else if ((value instanceof Date)) {
/* 30:61 */         command.processDate((Date)value);
/* 31:   */       }
/* 32:   */     }
/* 33:   */   }
/* 34:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.persist.sql.ValueListProcessor
 * JD-Core Version:    0.7.0.1
 */