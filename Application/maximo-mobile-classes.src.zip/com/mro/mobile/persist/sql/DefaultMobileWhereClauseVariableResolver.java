/*  1:   */ package com.mro.mobile.persist.sql;
/*  2:   */ 
/*  3:   */ public class DefaultMobileWhereClauseVariableResolver
/*  4:   */   implements MobileWhereClauseVariableResolver
/*  5:   */ {
/*  6:   */   public String getValueForYes()
/*  7:   */   {
/*  8: 6 */     return "1";
/*  9:   */   }
/* 10:   */   
/* 11:   */   public String getValueForNo()
/* 12:   */   {
/* 13:10 */     return "0";
/* 14:   */   }
/* 15:   */   
/* 16:   */   public String getValueForDate()
/* 17:   */   {
/* 18:14 */     return "current date";
/* 19:   */   }
/* 20:   */   
/* 21:   */   public String getValueForDateTime()
/* 22:   */   {
/* 23:18 */     return "current timestamp";
/* 24:   */   }
/* 25:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.persist.sql.DefaultMobileWhereClauseVariableResolver
 * JD-Core Version:    0.7.0.1
 */