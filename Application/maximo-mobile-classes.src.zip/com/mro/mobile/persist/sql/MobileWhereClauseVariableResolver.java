package com.mro.mobile.persist.sql;

public abstract interface MobileWhereClauseVariableResolver
{
  public abstract String getValueForYes();
  
  public abstract String getValueForNo();
  
  public abstract String getValueForDate();
  
  public abstract String getValueForDateTime();
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.persist.sql.MobileWhereClauseVariableResolver
 * JD-Core Version:    0.7.0.1
 */