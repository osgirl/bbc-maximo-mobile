/*   1:    */ package com.mro.mobile.persist;
/*   2:    */ 
/*   3:    */ import java.util.Date;
/*   4:    */ import java.util.Enumeration;
/*   5:    */ import java.util.HashMap;
/*   6:    */ import java.util.Hashtable;
/*   7:    */ import java.util.Map;
/*   8:    */ 
/*   9:    */ public class DefaultQBE
/*  10:    */   implements QBE
/*  11:    */ {
/*  12:    */   public static final String mobileParamPrefix = "$MOBILE_";
/*  13:    */   public static final String mobileParamOBJECT = "OBJECT";
/*  14:    */   public static final String mobileParamFIELD = "FIELD";
/*  15:    */   
/*  16:    */   private static final class LookupParametersEnumeration
/*  17:    */     implements Enumeration
/*  18:    */   {
/*  19:    */     private final Enumeration originalEnum;
/*  20: 29 */     private Object next = null;
/*  21:    */     
/*  22:    */     private LookupParametersEnumeration(Enumeration originalEnum)
/*  23:    */     {
/*  24: 32 */       this.originalEnum = originalEnum;
/*  25:    */     }
/*  26:    */     
/*  27:    */     public boolean hasMoreElements()
/*  28:    */     {
/*  29: 37 */       while (this.originalEnum.hasMoreElements())
/*  30:    */       {
/*  31: 39 */         String key = (String)this.originalEnum.nextElement();
/*  32: 40 */         if (key.startsWith("$MOBILE_"))
/*  33:    */         {
/*  34: 42 */           int beginObjNamePos = key.indexOf('_') + 1;
/*  35: 43 */           int endObjNamePos = key.indexOf('.', beginObjNamePos);
/*  36: 44 */           String objectName = key.substring(beginObjNamePos, endObjNamePos);
/*  37: 45 */           String fieldName = key.substring(endObjNamePos + 1);
/*  38:    */           
/*  39: 47 */           Map m = new HashMap();
/*  40: 48 */           m.put("OBJECT", objectName);
/*  41: 49 */           m.put("FIELD", fieldName);
/*  42: 50 */           this.next = m;
/*  43: 51 */           return true;
/*  44:    */         }
/*  45:    */       }
/*  46: 54 */       this.next = null;
/*  47: 55 */       return false;
/*  48:    */     }
/*  49:    */     
/*  50:    */     public Object nextElement()
/*  51:    */     {
/*  52: 60 */       return this.next;
/*  53:    */     }
/*  54:    */   }
/*  55:    */   
/*  56:    */   private static final class QBEAttributesEnumeration
/*  57:    */     implements Enumeration
/*  58:    */   {
/*  59:    */     private final Enumeration originalEnum;
/*  60: 68 */     private Object next = null;
/*  61:    */     
/*  62:    */     private QBEAttributesEnumeration(Enumeration originalEnum)
/*  63:    */     {
/*  64: 71 */       this.originalEnum = originalEnum;
/*  65:    */     }
/*  66:    */     
/*  67:    */     public boolean hasMoreElements()
/*  68:    */     {
/*  69: 76 */       while (this.originalEnum.hasMoreElements())
/*  70:    */       {
/*  71: 78 */         String key = (String)this.originalEnum.nextElement();
/*  72: 79 */         if (!key.startsWith("$MOBILE_"))
/*  73:    */         {
/*  74: 81 */           this.next = key;
/*  75: 82 */           return true;
/*  76:    */         }
/*  77:    */       }
/*  78: 85 */       this.next = null;
/*  79: 86 */       return false;
/*  80:    */     }
/*  81:    */     
/*  82:    */     public Object nextElement()
/*  83:    */     {
/*  84: 91 */       return this.next;
/*  85:    */     }
/*  86:    */   }
/*  87:    */   
/*  88:103 */   private Hashtable qbeValues = new Hashtable();
/*  89:104 */   private boolean exactMatch = false;
/*  90:107 */   private Hashtable backupQbeValues = new Hashtable();
/*  91:108 */   private boolean backupExactMatch = false;
/*  92:    */   
/*  93:    */   public void saveState()
/*  94:    */   {
/*  95:114 */     this.backupQbeValues = ((Hashtable)this.qbeValues.clone());
/*  96:115 */     this.backupExactMatch = this.exactMatch;
/*  97:116 */     saveSpecificState();
/*  98:    */   }
/*  99:    */   
/* 100:    */   public void restoreState()
/* 101:    */   {
/* 102:121 */     this.qbeValues = this.backupQbeValues;
/* 103:122 */     this.exactMatch = this.backupExactMatch;
/* 104:    */     
/* 105:124 */     this.backupQbeValues = null;
/* 106:125 */     this.backupExactMatch = false;
/* 107:126 */     restoreSpecificState();
/* 108:    */   }
/* 109:    */   
/* 110:    */   protected void saveSpecificState() {}
/* 111:    */   
/* 112:    */   protected void restoreSpecificState() {}
/* 113:    */   
/* 114:    */   public void setQBE(String attributeName, String value)
/* 115:    */     throws RDOException
/* 116:    */   {
/* 117:141 */     if ((value == null) || (value.trim().length() == 0))
/* 118:    */     {
/* 119:143 */       this.qbeValues.remove(attributeName);
/* 120:    */     }
/* 121:    */     else
/* 122:    */     {
/* 123:147 */       value = value.trim();
/* 124:    */       
/* 125:149 */       int type = 0;
/* 126:150 */       if (value.equals("~NULL~")) {
/* 127:152 */         type = 1;
/* 128:154 */       } else if (value.equals("!=~NULL~")) {
/* 129:156 */         type = 2;
/* 130:    */       }
/* 131:159 */       String valueWithoutCondition = value;
/* 132:160 */       String condition = getConditionExpression(value);
/* 133:161 */       if (condition.length() > 0) {
/* 134:163 */         valueWithoutCondition = value.substring(condition.length());
/* 135:    */       }
/* 136:165 */       QBEData data = new QBEData(value, getConditionExpression(value), valueWithoutCondition, type);
/* 137:    */       
/* 138:167 */       this.qbeValues.put(attributeName, data);
/* 139:    */     }
/* 140:    */   }
/* 141:    */   
/* 142:    */   public void setDateQBE(String attributeName, String value, Date dateValue, String conditionExpression)
/* 143:    */     throws RDOException
/* 144:    */   {
/* 145:175 */     if (dateValue == null)
/* 146:    */     {
/* 147:177 */       this.qbeValues.remove(attributeName);
/* 148:    */     }
/* 149:    */     else
/* 150:    */     {
/* 151:181 */       QBEData data = new QBEData(value, conditionExpression, dateValue, 0);
/* 152:    */       
/* 153:183 */       this.qbeValues.put(attributeName, data);
/* 154:    */     }
/* 155:    */   }
/* 156:    */   
/* 157:    */   public String getQBE(String attributeName)
/* 158:    */     throws RDOException
/* 159:    */   {
/* 160:189 */     QBEData data = (QBEData)this.qbeValues.get(attributeName);
/* 161:190 */     if (data == null) {
/* 162:192 */       return null;
/* 163:    */     }
/* 164:195 */     return data.getValue();
/* 165:    */   }
/* 166:    */   
/* 167:    */   public QBEData getQBEData(String attributeName)
/* 168:    */     throws RDOException
/* 169:    */   {
/* 170:200 */     QBEData data = (QBEData)this.qbeValues.get(attributeName);
/* 171:201 */     return data;
/* 172:    */   }
/* 173:    */   
/* 174:    */   public Enumeration getQBEAttributes()
/* 175:    */     throws RDOException
/* 176:    */   {
/* 177:210 */     Enumeration originalEnum = this.qbeValues.keys();
/* 178:    */     
/* 179:212 */     Enumeration en = new QBEAttributesEnumeration(originalEnum, null);
/* 180:    */     
/* 181:214 */     return en;
/* 182:    */   }
/* 183:    */   
/* 184:    */   public String getLookupParameter(String sourceObject, String parameterName)
/* 185:    */     throws RDOException
/* 186:    */   {
/* 187:227 */     StringBuffer key = new StringBuffer();
/* 188:228 */     key.append("$MOBILE_").append(sourceObject).append(".").append(parameterName);
/* 189:229 */     QBEData data = (QBEData)this.qbeValues.get(key.toString());
/* 190:230 */     if (data == null) {
/* 191:232 */       return null;
/* 192:    */     }
/* 193:235 */     return data.getValue();
/* 194:    */   }
/* 195:    */   
/* 196:    */   public String getRawLookupParameterKey(String sourceObject, String parameterName)
/* 197:    */     throws RDOException
/* 198:    */   {
/* 199:246 */     StringBuffer key = new StringBuffer();
/* 200:247 */     key.append("$MOBILE_").append(sourceObject).append(".").append(parameterName);
/* 201:248 */     String realKey = key.toString();
/* 202:    */     
/* 203:250 */     QBEData data = (QBEData)this.qbeValues.get(realKey);
/* 204:251 */     if (data == null) {
/* 205:254 */       return null;
/* 206:    */     }
/* 207:257 */     return realKey;
/* 208:    */   }
/* 209:    */   
/* 210:    */   public void setLookupParameter(String sourceObject, String parameterName, String value)
/* 211:    */     throws RDOException
/* 212:    */   {
/* 213:274 */     String valueFormatted = "'" + value + "'";
/* 214:275 */     setLookupParam(sourceObject, parameterName, valueFormatted);
/* 215:    */   }
/* 216:    */   
/* 217:    */   public void setLookupParameter(String sourceObject, String parameterName, Number value)
/* 218:    */     throws RDOException
/* 219:    */   {
/* 220:289 */     setLookupParam(sourceObject, parameterName, value.toString());
/* 221:    */   }
/* 222:    */   
/* 223:    */   public void setLookupParameter(String sourceObject, String parameterName, long value)
/* 224:    */     throws RDOException
/* 225:    */   {
/* 226:302 */     setLookupParameter(sourceObject, parameterName, new Long(value));
/* 227:    */   }
/* 228:    */   
/* 229:    */   public void setLookupParameter(String sourceObject, String parameterName, int value)
/* 230:    */     throws RDOException
/* 231:    */   {
/* 232:315 */     setLookupParameter(sourceObject, parameterName, new Integer(value));
/* 233:    */   }
/* 234:    */   
/* 235:    */   public void setLookupParameter(String sourceObject, String parameterName, double value)
/* 236:    */     throws RDOException
/* 237:    */   {
/* 238:328 */     setLookupParameter(sourceObject, parameterName, new Double(value));
/* 239:    */   }
/* 240:    */   
/* 241:    */   public void setLookupParameter(String sourceObject, String parameterName, float value)
/* 242:    */     throws RDOException
/* 243:    */   {
/* 244:341 */     setLookupParameter(sourceObject, parameterName, new Float(value));
/* 245:    */   }
/* 246:    */   
/* 247:    */   public void setLookupParameter(String sourceObject, String parameterName, Boolean value)
/* 248:    */     throws RDOException
/* 249:    */   {
/* 250:354 */     setLookupParameter(sourceObject, parameterName, value.booleanValue());
/* 251:    */   }
/* 252:    */   
/* 253:    */   public void setLookupParameter(String sourceObject, String parameterName, boolean value)
/* 254:    */     throws RDOException
/* 255:    */   {
/* 256:367 */     String v = value == true ? "1" : "0";
/* 257:368 */     setLookupParameter(sourceObject, parameterName, v);
/* 258:    */   }
/* 259:    */   
/* 260:    */   public void setLookupParameter(String sourceObject, String parameterName, Date value)
/* 261:    */     throws RDOException
/* 262:    */   {
/* 263:383 */     setLookupParam(sourceObject, parameterName, "$MOBILE_" + Long.toString(value.getTime()));
/* 264:    */   }
/* 265:    */   
/* 266:    */   private void setLookupParam(String sourceObject, String parameterName, String value)
/* 267:    */     throws RDOException
/* 268:    */   {
/* 269:397 */     if (sourceObject == null) {
/* 270:399 */       throw new RDOException("Invalid argument: sourceObject", new IllegalArgumentException("sourceObject"));
/* 271:    */     }
/* 272:401 */     if (parameterName == null) {
/* 273:403 */       throw new RDOException("Invalid argument: parameterName", new IllegalArgumentException("parameterName"));
/* 274:    */     }
/* 275:405 */     StringBuffer key = new StringBuffer();
/* 276:    */     
/* 277:407 */     key.append("$MOBILE_").append(sourceObject).append(".").append(parameterName);
/* 278:408 */     String realKey = key.toString();
/* 279:409 */     if (value == null) {
/* 280:411 */       this.qbeValues.remove(realKey);
/* 281:    */     } else {
/* 282:413 */       this.qbeValues.put(realKey, new QBEData(value, "", value, 0));
/* 283:    */     }
/* 284:    */   }
/* 285:    */   
/* 286:    */   public Enumeration getLookupParameters()
/* 287:    */     throws RDOException
/* 288:    */   {
/* 289:429 */     Enumeration originalEnum = this.qbeValues.keys();
/* 290:    */     
/* 291:431 */     Enumeration en = new LookupParametersEnumeration(originalEnum, null);
/* 292:    */     
/* 293:433 */     return en;
/* 294:    */   }
/* 295:    */   
/* 296:    */   public void setQbeExactMatch(boolean exactMatch)
/* 297:    */     throws RDOException
/* 298:    */   {
/* 299:439 */     this.exactMatch = exactMatch;
/* 300:    */   }
/* 301:    */   
/* 302:    */   public boolean isQbeExactMatch()
/* 303:    */     throws RDOException
/* 304:    */   {
/* 305:445 */     return this.exactMatch;
/* 306:    */   }
/* 307:    */   
/* 308:    */   public void reset()
/* 309:    */     throws RDOException
/* 310:    */   {
/* 311:451 */     this.qbeValues = new Hashtable();
/* 312:    */   }
/* 313:    */   
/* 314:    */   public int size()
/* 315:    */   {
/* 316:456 */     return this.qbeValues.size();
/* 317:    */   }
/* 318:    */   
/* 319:    */   private String getConditionExpression(String qbeValue)
/* 320:    */   {
/* 321:461 */     for (int i = 0; i < QBE.EXPRLIST.length; i++)
/* 322:    */     {
/* 323:463 */       String condition = QBE.EXPRLIST[i];
/* 324:464 */       if (qbeValue.length() >= condition.length()) {
/* 325:466 */         if (qbeValue.startsWith(condition)) {
/* 326:468 */           return condition;
/* 327:    */         }
/* 328:    */       }
/* 329:    */     }
/* 330:473 */     return "";
/* 331:    */   }
/* 332:    */   
/* 333:    */   protected void copyLookupParameters(DefaultQBE target)
/* 334:    */     throws RDOException
/* 335:    */   {
/* 336:486 */     Enumeration paramEnum = getLookupParameters();
/* 337:487 */     while (paramEnum.hasMoreElements())
/* 338:    */     {
/* 339:489 */       Map key = (Map)paramEnum.nextElement();
/* 340:490 */       String objectName = (String)key.get("OBJECT");
/* 341:491 */       String attributeName = (String)key.get("FIELD");
/* 342:    */       
/* 343:493 */       target.setLookupParam(objectName, attributeName, getLookupParameter(objectName, attributeName));
/* 344:    */     }
/* 345:    */   }
/* 346:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.persist.DefaultQBE
 * JD-Core Version:    0.7.0.1
 */