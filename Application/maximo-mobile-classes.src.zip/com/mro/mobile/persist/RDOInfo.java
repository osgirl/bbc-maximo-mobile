package com.mro.mobile.persist;

public abstract interface RDOInfo
{
  public abstract String getName();
  
  public abstract boolean hasAttribute(String paramString);
  
  public abstract String[] getAttributeNames();
  
  public abstract int getAttributeCount();
  
  public abstract int getAttributeIndex(String paramString);
  
  public abstract String[] getKeyAttributeNames();
  
  public abstract int getkeySize();
  
  public abstract RDOAttributeInfo getAttributeInfo(String paramString);
  
  public abstract RDOAttributeInfo getAttributeInfo(int paramInt);
  
  public abstract String getAttributeName(int paramInt);
  
  public abstract boolean isDependent();
  
  public abstract boolean hasDependents();
  
  public abstract int getDependentCount();
  
  public abstract String[] getDependentNames();
  
  public abstract String getParent();
  
  public abstract boolean isHierarchical();
  
  public abstract RDODependentRelation getDependentRelation();
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.persist.RDOInfo
 * JD-Core Version:    0.7.0.1
 */