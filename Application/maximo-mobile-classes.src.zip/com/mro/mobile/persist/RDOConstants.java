package com.mro.mobile.persist;

public abstract interface RDOConstants
{
  public static final int READONLY = 1;
  public static final int REQUIRED = 2;
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.persist.RDOConstants
 * JD-Core Version:    0.7.0.1
 */