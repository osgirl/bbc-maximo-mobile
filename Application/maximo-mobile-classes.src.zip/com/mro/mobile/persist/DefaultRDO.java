/*    1:     */ package com.mro.mobile.persist;
/*    2:     */ 
/*    3:     */ import com.mro.mobile.persist.sql.MobileWhereClause;
/*    4:     */ import com.mro.mobile.util.BitFlags;
/*    5:     */ import com.mro.mobile.util.MobileLogger;
/*    6:     */ import com.mro.mobile.util.MobileLoggerFactory;
/*    7:     */ import java.util.Calendar;
/*    8:     */ import java.util.Date;
/*    9:     */ import java.util.Enumeration;
/*   10:     */ import java.util.Hashtable;
/*   11:     */ import java.util.Vector;
/*   12:     */ 
/*   13:     */ public class DefaultRDO
/*   14:     */   implements RDO
/*   15:     */ {
/*   16:     */   private static final int MAX_FLAGS = 32;
/*   17:  32 */   private static final Vector dummy = new Vector();
/*   18:  33 */   private String appName = null;
/*   19:  34 */   private RDO owner = null;
/*   20:  35 */   private Hashtable dependents = new Hashtable();
/*   21:  36 */   private Hashtable dependentsFetched = new Hashtable();
/*   22:  37 */   private Hashtable attributeValues = new Hashtable();
/*   23:  38 */   private Hashtable attributeFlags = new Hashtable();
/*   24:  39 */   private String name = null;
/*   25:  40 */   private boolean persistedData = false;
/*   26:  42 */   BitFlags flags = new BitFlags(32);
/*   27:     */   
/*   28:     */   public DefaultRDO(String appName)
/*   29:     */   {
/*   30:  46 */     this.appName = appName;
/*   31:     */   }
/*   32:     */   
/*   33:     */   public DefaultRDO(String appName, boolean persistedData)
/*   34:     */   {
/*   35:  51 */     this.appName = appName;
/*   36:  52 */     this.persistedData = persistedData;
/*   37:     */   }
/*   38:     */   
/*   39:     */   public void setPersistedData(boolean persistedData)
/*   40:     */   {
/*   41:  57 */     this.persistedData = persistedData;
/*   42:     */   }
/*   43:     */   
/*   44:     */   public boolean isPersistentData()
/*   45:     */   {
/*   46:  61 */     return this.persistedData;
/*   47:     */   }
/*   48:     */   
/*   49:     */   public String getAppName()
/*   50:     */   {
/*   51:  66 */     return this.appName;
/*   52:     */   }
/*   53:     */   
/*   54:     */   public void setName(String name)
/*   55:     */   {
/*   56:  71 */     this.name = name;
/*   57:     */   }
/*   58:     */   
/*   59:     */   public String getName()
/*   60:     */   {
/*   61:  76 */     return this.name;
/*   62:     */   }
/*   63:     */   
/*   64:     */   public RDOInfo getInfo()
/*   65:     */   {
/*   66:  81 */     return RDOUtil.getRDOInfo(this.appName, this.name);
/*   67:     */   }
/*   68:     */   
/*   69:     */   public void setId(long id)
/*   70:     */     throws RDOException
/*   71:     */   {
/*   72:  86 */     setLongValue("_ID", id);
/*   73:     */   }
/*   74:     */   
/*   75:     */   public long getId()
/*   76:     */     throws RDOException
/*   77:     */   {
/*   78:  91 */     return getLongValue("_ID");
/*   79:     */   }
/*   80:     */   
/*   81:     */   public Enumeration getAttributeNames()
/*   82:     */   {
/*   83:  96 */     return this.attributeValues.keys();
/*   84:     */   }
/*   85:     */   
/*   86:     */   public RDOKey getKey()
/*   87:     */     throws RDOException
/*   88:     */   {
/*   89: 102 */     RDOInfo rdoInfo = RDOUtil.getRDOInfo(this.appName, getName());
/*   90: 103 */     if (rdoInfo == null) {
/*   91: 105 */       throw new RuntimeException("Info about " + getName() + " not known");
/*   92:     */     }
/*   93: 108 */     if (rdoInfo.getkeySize() == 0) {
/*   94: 110 */       return null;
/*   95:     */     }
/*   96: 113 */     return new DefaultRDOKey(rdoInfo, this);
/*   97:     */   }
/*   98:     */   
/*   99:     */   public boolean isNull(String attributeName)
/*  100:     */     throws RDOException
/*  101:     */   {
/*  102: 118 */     Object obj = this.attributeValues.get(attributeName);
/*  103: 119 */     if (obj == null) {
/*  104: 121 */       return true;
/*  105:     */     }
/*  106: 124 */     return false;
/*  107:     */   }
/*  108:     */   
/*  109:     */   public RDO getOwner()
/*  110:     */   {
/*  111: 129 */     return this.owner;
/*  112:     */   }
/*  113:     */   
/*  114:     */   public void setOwner(RDO owner)
/*  115:     */   {
/*  116: 134 */     this.owner = owner;
/*  117:     */   }
/*  118:     */   
/*  119:     */   public String getStringValue(String attributeName)
/*  120:     */     throws RDOException
/*  121:     */   {
/*  122: 149 */     Object obj = this.attributeValues.get(attributeName);
/*  123: 150 */     if (obj == null) {
/*  124: 152 */       return "";
/*  125:     */     }
/*  126: 155 */     MobileLogger log = MobileLoggerFactory.getLogger("maximo.mobile.persistence");
/*  127: 156 */     RDOAttributeInfo attrInfo = null;
/*  128: 157 */     attrInfo = getInfo().getAttributeInfo(attributeName);
/*  129: 158 */     switch (attrInfo.getDataType())
/*  130:     */     {
/*  131:     */     case 8: 
/*  132: 162 */       if ((obj instanceof Boolean))
/*  133:     */       {
/*  134: 164 */         Boolean val = (Boolean)obj;
/*  135: 165 */         if (val.booleanValue()) {
/*  136: 167 */           return "1";
/*  137:     */         }
/*  138: 171 */         return "0";
/*  139:     */       }
/*  140:     */       break;
/*  141:     */     case 7: 
/*  142: 178 */       if ((log != null) && (log.isWarnEnabled()))
/*  143:     */       {
/*  144: 180 */         Throwable t = null;
/*  145: 181 */         if (log.isDebugEnabled()) {
/*  146: 183 */           t = new Exception("Simple stack trace");
/*  147:     */         }
/*  148: 185 */         log.warn("\"" + getName() + "." + attributeName + "\" is a double attribute being read as String. Prefer to use getDoubleValue().", t);
/*  149:     */       }
/*  150: 188 */       String v = obj.toString();
/*  151: 189 */       return v;
/*  152:     */     case 6: 
/*  153: 193 */       if ((log != null) && (log.isWarnEnabled()))
/*  154:     */       {
/*  155: 195 */         Throwable t = null;
/*  156: 196 */         if (log.isDebugEnabled()) {
/*  157: 198 */           t = new Exception("Simple stack trace");
/*  158:     */         }
/*  159: 200 */         log.warn("\"" + getName() + "." + attributeName + "\" is a float attribute being read as String. Prefer to use getFloatValue().", t);
/*  160:     */       }
/*  161: 203 */       String v = obj.toString();
/*  162: 204 */       return v;
/*  163:     */     case 12: 
/*  164: 207 */       throw new RDOException("Cannot get string value for " + attributeName);
/*  165:     */     case 9: 
/*  166:     */     case 10: 
/*  167:     */     case 11: 
/*  168: 211 */       if ((log != null) && (log.isWarnEnabled()))
/*  169:     */       {
/*  170: 213 */         Throwable t = null;
/*  171: 214 */         if (log.isDebugEnabled()) {
/*  172: 216 */           t = new Exception("Simple stack trace");
/*  173:     */         }
/*  174: 218 */         log.warn("\"" + getName() + "." + attributeName + "\" is a date/time attribute being read as String. Prefer to use getDateValue().", t);
/*  175:     */       }
/*  176:     */       break;
/*  177:     */     }
/*  178: 223 */     return obj.toString();
/*  179:     */   }
/*  180:     */   
/*  181:     */   public void setStringValue(String attributeName, String value)
/*  182:     */     throws RDOException
/*  183:     */   {
/*  184: 239 */     if ((value == null) || (value.trim().length() == 0))
/*  185:     */     {
/*  186: 241 */       this.attributeValues.remove(attributeName);
/*  187: 242 */       return;
/*  188:     */     }
/*  189: 245 */     Object attrValue = value;
/*  190:     */     
/*  191:     */ 
/*  192:     */ 
/*  193:     */ 
/*  194:     */ 
/*  195: 251 */     RDOAttributeInfo attrInfo = null;
/*  196: 252 */     if (getInfo() == null) {
/*  197: 255 */       throw new IllegalArgumentException("App: " + getAppName() + " unknown RDO: " + getName());
/*  198:     */     }
/*  199: 258 */     attrInfo = getInfo().getAttributeInfo(attributeName);
/*  200: 260 */     if (attrInfo == null) {
/*  201: 262 */       throw new IllegalArgumentException("App: " + getAppName() + " RDO: " + getName() + " unknown attribute: " + attributeName);
/*  202:     */     }
/*  203: 266 */     MobileLogger log = MobileLoggerFactory.getLogger("maximo.mobile.persistence");
/*  204: 267 */     switch (attrInfo.getDataType())
/*  205:     */     {
/*  206:     */     case 1: 
/*  207: 271 */       attrValue = value;
/*  208:     */       
/*  209: 273 */       break;
/*  210:     */     case 2: 
/*  211: 276 */       attrValue = value.toUpperCase();
/*  212:     */       
/*  213: 278 */       break;
/*  214:     */     case 3: 
/*  215: 281 */       attrValue = value.toLowerCase();
/*  216:     */       
/*  217: 283 */       break;
/*  218:     */     case 4: 
/*  219: 286 */       attrValue = Integer.valueOf(value);
/*  220: 287 */       break;
/*  221:     */     case 5: 
/*  222: 291 */       attrValue = Long.valueOf(value);
/*  223:     */       
/*  224: 293 */       break;
/*  225:     */     case 6: 
/*  226: 297 */       if ((log != null) && (log.isWarnEnabled()))
/*  227:     */       {
/*  228: 299 */         Throwable t = null;
/*  229: 300 */         if (log.isDebugEnabled()) {
/*  230: 302 */           t = new Exception("Simple stack trace");
/*  231:     */         }
/*  232: 304 */         log.warn("\"" + getName() + "." + attributeName + "\" is a float attribute being set as String. Prefer to use setFloatValue().", t);
/*  233:     */       }
/*  234: 307 */       attrValue = Float.valueOf(value);
/*  235:     */       
/*  236: 309 */       break;
/*  237:     */     case 7: 
/*  238: 313 */       if ((log != null) && (log.isWarnEnabled()))
/*  239:     */       {
/*  240: 315 */         Throwable t = null;
/*  241: 316 */         if (log.isDebugEnabled()) {
/*  242: 318 */           t = new Exception("Simple stack trace");
/*  243:     */         }
/*  244: 321 */         log.warn("\"" + getName() + "." + attributeName + "\" is a double attribute being set as String. Prefer to use setDoubleValue().", t);
/*  245:     */       }
/*  246: 324 */       attrValue = Double.valueOf(value);
/*  247:     */       
/*  248: 326 */       break;
/*  249:     */     case 8: 
/*  250: 329 */       int boolValue = Integer.parseInt(value);
/*  251: 330 */       if (boolValue == 1) {
/*  252: 333 */         attrValue = Boolean.TRUE;
/*  253:     */       } else {
/*  254: 337 */         attrValue = Boolean.FALSE;
/*  255:     */       }
/*  256: 340 */       break;
/*  257:     */     case 9: 
/*  258: 343 */       if ((log != null) && (log.isWarnEnabled()))
/*  259:     */       {
/*  260: 345 */         Throwable t = null;
/*  261: 346 */         if (log.isDebugEnabled()) {
/*  262: 348 */           t = new Exception("Simple stack trace");
/*  263:     */         }
/*  264: 351 */         log.warn("\"" + getName() + "." + attributeName + "\" is a date/time attribute being set as String. Prefer to use setDateValue().", t);
/*  265:     */       }
/*  266: 355 */       long longV = Long.parseLong(value);
/*  267:     */       
/*  268:     */ 
/*  269:     */ 
/*  270:     */ 
/*  271: 360 */       long lValue = longV;
/*  272: 361 */       Calendar c = Calendar.getInstance();
/*  273: 362 */       Date x = new Date(lValue);
/*  274: 363 */       c.setTime(x);
/*  275: 364 */       c.set(10, 0);
/*  276: 365 */       c.set(12, 0);
/*  277:     */       
/*  278:     */ 
/*  279: 368 */       c.set(14, 0);
/*  280: 369 */       long lNewValue = c.getTime().getTime();
/*  281: 370 */       attrValue = new Long(lNewValue);
/*  282:     */       
/*  283:     */ 
/*  284: 373 */       break;
/*  285:     */     case 11: 
/*  286: 376 */       if ((log != null) && (log.isWarnEnabled()))
/*  287:     */       {
/*  288: 378 */         Throwable t = null;
/*  289: 379 */         if (log.isDebugEnabled()) {
/*  290: 381 */           t = new Exception("Simple stack trace");
/*  291:     */         }
/*  292: 384 */         log.warn("\"" + getName() + "." + attributeName + "\" is a date/time attribute being set as String. Prefer to use setDateValue().", t);
/*  293:     */       }
/*  294: 387 */       long longV = Long.parseLong(value);
/*  295:     */       
/*  296:     */ 
/*  297:     */ 
/*  298:     */ 
/*  299: 392 */       long lValue = longV;
/*  300: 393 */       Calendar c = Calendar.getInstance();
/*  301: 394 */       Date x = new Date(lValue);
/*  302: 395 */       c.setTime(x);
/*  303:     */       
/*  304:     */ 
/*  305: 398 */       c.set(14, 0);
/*  306: 399 */       long lNewValue = c.getTime().getTime();
/*  307: 400 */       attrValue = new Long(lNewValue);
/*  308:     */       
/*  309:     */ 
/*  310: 403 */       break;
/*  311:     */     case 10: 
/*  312: 406 */       if ((log != null) && (log.isWarnEnabled()))
/*  313:     */       {
/*  314: 408 */         Throwable t = null;
/*  315: 409 */         if (log.isDebugEnabled()) {
/*  316: 411 */           t = new Exception("Simple stack trace");
/*  317:     */         }
/*  318: 414 */         log.warn("\"" + getName() + "." + attributeName + "\" is a date/time attribute being set as String. Prefer to use setDateValue().", t);
/*  319:     */       }
/*  320: 417 */       long longV = Long.parseLong(value);
/*  321:     */       
/*  322:     */ 
/*  323:     */ 
/*  324:     */ 
/*  325: 422 */       long lValue = longV;
/*  326: 423 */       Calendar c = Calendar.getInstance();
/*  327: 424 */       Date x = new Date(lValue);
/*  328: 425 */       c.setTime(x);
/*  329: 426 */       c.set(13, 0);
/*  330: 427 */       c.set(14, 0);
/*  331: 428 */       long lNewValue = c.getTime().getTime();
/*  332: 429 */       attrValue = new Long(lNewValue);
/*  333:     */       
/*  334:     */ 
/*  335: 432 */       break;
/*  336:     */     default: 
/*  337: 434 */       throw new RDOException("Cannot set string value for " + attributeName);
/*  338:     */     }
/*  339: 437 */     this.attributeValues.put(attributeName, attrValue);
/*  340:     */   }
/*  341:     */   
/*  342:     */   public boolean getBooleanValue(String attributeName)
/*  343:     */     throws RDOException
/*  344:     */   {
/*  345: 442 */     Object obj = this.attributeValues.get(attributeName);
/*  346: 444 */     if (obj == null) {
/*  347: 446 */       return false;
/*  348:     */     }
/*  349: 449 */     if ((obj instanceof Boolean)) {
/*  350: 451 */       return ((Boolean)obj).booleanValue();
/*  351:     */     }
/*  352: 454 */     throw new RDOException("Cannot obtain boolean value for " + attributeName);
/*  353:     */   }
/*  354:     */   
/*  355:     */   public void setBooleanValue(String attributeName, boolean value)
/*  356:     */     throws RDOException
/*  357:     */   {
/*  358: 460 */     this.attributeValues.put(attributeName, Boolean.valueOf(value));
/*  359:     */   }
/*  360:     */   
/*  361:     */   public long getLongValue(String attributeName)
/*  362:     */     throws RDOException
/*  363:     */   {
/*  364: 465 */     Object obj = this.attributeValues.get(attributeName);
/*  365: 467 */     if (obj == null) {
/*  366: 469 */       return 0L;
/*  367:     */     }
/*  368: 472 */     if ((obj instanceof Long)) {
/*  369: 474 */       return ((Long)obj).longValue();
/*  370:     */     }
/*  371: 476 */     if ((obj instanceof String)) {
/*  372: 478 */       return Long.parseLong((String)obj);
/*  373:     */     }
/*  374: 480 */     if ((obj instanceof Integer)) {
/*  375: 482 */       return ((Integer)obj).intValue();
/*  376:     */     }
/*  377: 485 */     throw new RDOException("Cannot obtain long value for " + attributeName);
/*  378:     */   }
/*  379:     */   
/*  380:     */   public void setLongValue(String attributeName, long value)
/*  381:     */     throws RDOException
/*  382:     */   {
/*  383: 490 */     this.attributeValues.put(attributeName, new Long(value));
/*  384:     */   }
/*  385:     */   
/*  386:     */   public int getIntValue(String attributeName)
/*  387:     */     throws RDOException
/*  388:     */   {
/*  389: 495 */     Object obj = this.attributeValues.get(attributeName);
/*  390: 497 */     if (obj == null) {
/*  391: 499 */       return 0;
/*  392:     */     }
/*  393: 502 */     if ((obj instanceof Integer)) {
/*  394: 504 */       return ((Integer)obj).intValue();
/*  395:     */     }
/*  396: 506 */     if ((obj instanceof String)) {
/*  397: 508 */       return Integer.parseInt((String)obj);
/*  398:     */     }
/*  399: 511 */     throw new RDOException("Cannot obtain int value for " + attributeName);
/*  400:     */   }
/*  401:     */   
/*  402:     */   public void setIntValue(String attributeName, int value)
/*  403:     */     throws RDOException
/*  404:     */   {
/*  405: 516 */     this.attributeValues.put(attributeName, new Integer(value));
/*  406:     */   }
/*  407:     */   
/*  408:     */   public byte[] getBinaryValue(String attributeName)
/*  409:     */     throws RDOException
/*  410:     */   {
/*  411: 521 */     Object obj = this.attributeValues.get(attributeName);
/*  412: 523 */     if (obj == null) {
/*  413: 525 */       return null;
/*  414:     */     }
/*  415: 528 */     if ((obj instanceof byte[])) {
/*  416: 530 */       return (byte[])obj;
/*  417:     */     }
/*  418: 533 */     throw new RDOException("Cannot obtain binary value for " + attributeName);
/*  419:     */   }
/*  420:     */   
/*  421:     */   public void setBinaryValue(String attributeName, byte[] value)
/*  422:     */     throws RDOException
/*  423:     */   {
/*  424: 538 */     if (value == null) {
/*  425: 540 */       this.attributeValues.remove(attributeName);
/*  426:     */     } else {
/*  427: 544 */       this.attributeValues.put(attributeName, value);
/*  428:     */     }
/*  429:     */   }
/*  430:     */   
/*  431:     */   public Date getDateValue(String attributeName)
/*  432:     */     throws RDOException
/*  433:     */   {
/*  434: 550 */     Object obj = this.attributeValues.get(attributeName);
/*  435: 551 */     if (obj == null) {
/*  436: 553 */       return null;
/*  437:     */     }
/*  438: 556 */     if ((obj instanceof Long)) {
/*  439: 558 */       return new Date(((Long)obj).longValue());
/*  440:     */     }
/*  441: 561 */     throw new RDOException("Cannot obtain date value for " + attributeName);
/*  442:     */   }
/*  443:     */   
/*  444:     */   public void setDateValue(String attributeName, Date value)
/*  445:     */     throws RDOException
/*  446:     */   {
/*  447: 566 */     if (value == null)
/*  448:     */     {
/*  449: 568 */       this.attributeValues.remove(attributeName);
/*  450:     */     }
/*  451:     */     else
/*  452:     */     {
/*  453: 572 */       RDOAttributeInfo attrInfo = null;
/*  454: 573 */       attrInfo = getInfo().getAttributeInfo(attributeName);
/*  455: 575 */       if (attrInfo.getDataType() == 9)
/*  456:     */       {
/*  457: 578 */         long lValue = value.getTime();
/*  458: 579 */         Calendar c = Calendar.getInstance();
/*  459: 580 */         Date x = new Date(lValue);
/*  460: 581 */         c.setTime(x);
/*  461: 582 */         c.set(10, 0);
/*  462: 583 */         c.set(12, 0);
/*  463: 584 */         c.set(13, 0);
/*  464: 585 */         c.set(14, 0);
/*  465: 586 */         long lNewValue = c.getTime().getTime();
/*  466:     */         
/*  467: 588 */         this.attributeValues.put(attributeName, new Long(lNewValue));
/*  468:     */       }
/*  469: 590 */       else if (attrInfo.getDataType() == 11)
/*  470:     */       {
/*  471: 593 */         long lValue = value.getTime();
/*  472: 594 */         Calendar c = Calendar.getInstance();
/*  473: 595 */         Date x = new Date(lValue);
/*  474: 596 */         c.setTime(x);
/*  475:     */         
/*  476:     */ 
/*  477: 599 */         c.set(14, 0);
/*  478: 600 */         long lNewValue = c.getTime().getTime();
/*  479:     */         
/*  480: 602 */         this.attributeValues.put(attributeName, new Long(lNewValue));
/*  481:     */       }
/*  482: 604 */       else if (attrInfo.getDataType() == 10)
/*  483:     */       {
/*  484: 607 */         long lValue = value.getTime();
/*  485: 608 */         Calendar c = Calendar.getInstance();
/*  486: 609 */         Date x = new Date(lValue);
/*  487: 610 */         c.setTime(x);
/*  488: 611 */         c.set(14, 0);
/*  489: 612 */         long lNewValue = c.getTime().getTime();
/*  490:     */         
/*  491: 614 */         this.attributeValues.put(attributeName, new Long(lNewValue));
/*  492:     */       }
/*  493:     */     }
/*  494:     */   }
/*  495:     */   
/*  496:     */   public RDO createDependent(String name)
/*  497:     */     throws RDOException
/*  498:     */   {
/*  499: 623 */     if (isReadOnly()) {
/*  500: 625 */       throw new RDOException("RDO: " + getName() + " is read only");
/*  501:     */     }
/*  502: 628 */     Vector vec = null;
/*  503:     */     
/*  504: 630 */     Object obj = this.dependents.get(name);
/*  505: 631 */     if (obj == null)
/*  506:     */     {
/*  507: 633 */       vec = new Vector();
/*  508: 634 */       this.dependents.put(name, vec);
/*  509:     */     }
/*  510:     */     else
/*  511:     */     {
/*  512: 638 */       vec = (Vector)obj;
/*  513:     */     }
/*  514: 641 */     DefaultRDO rdo = new DefaultRDO(this.appName);
/*  515: 642 */     rdo.setName(name);
/*  516: 643 */     rdo.setOwner(this);
/*  517: 644 */     rdo.setLongValue("_PARENTID", getId());
/*  518:     */     
/*  519:     */ 
/*  520: 647 */     vec.addElement(rdo);
/*  521: 648 */     return rdo;
/*  522:     */   }
/*  523:     */   
/*  524:     */   public void replaceDependent(String name, RDO curDependentRDO, RDO newDependentRDO)
/*  525:     */     throws RDOException
/*  526:     */   {
/*  527: 653 */     Vector vec = null;
/*  528:     */     
/*  529: 655 */     Object obj = this.dependents.get(name);
/*  530: 656 */     if (obj == null) {
/*  531: 658 */       return;
/*  532:     */     }
/*  533: 662 */     vec = (Vector)obj;
/*  534:     */     
/*  535:     */ 
/*  536: 665 */     int index = vec.indexOf(curDependentRDO);
/*  537: 666 */     vec.setElementAt(newDependentRDO, index);
/*  538:     */   }
/*  539:     */   
/*  540:     */   public void addDependent(String name, RDO rdo)
/*  541:     */     throws RDOException
/*  542:     */   {
/*  543: 671 */     if (isReadOnly()) {
/*  544: 673 */       throw new RDOException("RDO: " + getName() + " is read only");
/*  545:     */     }
/*  546: 676 */     Vector vec = null;
/*  547:     */     
/*  548: 678 */     Object obj = this.dependents.get(name);
/*  549: 679 */     if (obj == null)
/*  550:     */     {
/*  551: 681 */       vec = new Vector();
/*  552: 682 */       this.dependents.put(name, vec);
/*  553:     */     }
/*  554:     */     else
/*  555:     */     {
/*  556: 686 */       vec = (Vector)obj;
/*  557:     */     }
/*  558: 689 */     vec.addElement(rdo);
/*  559:     */   }
/*  560:     */   
/*  561:     */   public void removeDependent(String name, RDO rdo)
/*  562:     */     throws RDOException
/*  563:     */   {
/*  564: 694 */     if (isReadOnly()) {
/*  565: 696 */       throw new RDOException("RDO: " + getName() + " is read only");
/*  566:     */     }
/*  567: 699 */     Vector vec = null;
/*  568:     */     
/*  569: 701 */     Object obj = this.dependents.get(name);
/*  570: 702 */     if (obj == null) {
/*  571: 704 */       return;
/*  572:     */     }
/*  573: 707 */     vec = (Vector)obj;
/*  574: 708 */     vec.removeElement(rdo);
/*  575:     */   }
/*  576:     */   
/*  577:     */   public RDOEnumeration getDependents(String name)
/*  578:     */   {
/*  579: 713 */     return getDependents(name, null, null);
/*  580:     */   }
/*  581:     */   
/*  582:     */   public RDOEnumeration getDependents(String name, QBE filter, Order order)
/*  583:     */   {
/*  584: 718 */     return getDependents(name, filter, null, order);
/*  585:     */   }
/*  586:     */   
/*  587:     */   public RDOEnumeration getDependents(String name, QBE filter, MobileWhereClause whereClause, Order order)
/*  588:     */   {
/*  589: 723 */     fetchDependents(name, filter, whereClause, order);
/*  590: 724 */     Vector vec = null;
/*  591: 725 */     Object obj = this.dependents.get(name);
/*  592: 727 */     if (obj == null) {
/*  593: 729 */       return new DefaultRDOEnumeration(dummy.elements());
/*  594:     */     }
/*  595: 732 */     vec = (Vector)obj;
/*  596:     */     
/*  597: 734 */     return new DefaultRDOEnumeration(vec.elements());
/*  598:     */   }
/*  599:     */   
/*  600:     */   static class DefaultRDOEnumeration
/*  601:     */     implements RDOEnumeration
/*  602:     */   {
/*  603: 740 */     Enumeration rdoEnum = null;
/*  604:     */     
/*  605:     */     public DefaultRDOEnumeration(Enumeration rdoEnum)
/*  606:     */     {
/*  607: 744 */       this.rdoEnum = rdoEnum;
/*  608:     */     }
/*  609:     */     
/*  610:     */     public void release() {}
/*  611:     */     
/*  612:     */     public boolean hasMoreElements()
/*  613:     */     {
/*  614: 753 */       return this.rdoEnum.hasMoreElements();
/*  615:     */     }
/*  616:     */     
/*  617:     */     public Object nextElement()
/*  618:     */     {
/*  619: 758 */       return this.rdoEnum.nextElement();
/*  620:     */     }
/*  621:     */   }
/*  622:     */   
/*  623:     */   private boolean isDependentDataFetched(String name)
/*  624:     */   {
/*  625: 766 */     if (!this.persistedData) {
/*  626: 768 */       return true;
/*  627:     */     }
/*  628: 771 */     Object obj = this.dependentsFetched.get(name);
/*  629: 772 */     if (obj != null) {
/*  630: 774 */       return true;
/*  631:     */     }
/*  632: 777 */     return false;
/*  633:     */   }
/*  634:     */   
/*  635:     */   public void setDependentDataFetched(String name)
/*  636:     */   {
/*  637: 782 */     this.dependentsFetched.put(name, name);
/*  638:     */   }
/*  639:     */   
/*  640:     */   private void fetchDependents(String name, QBE filter, Order order)
/*  641:     */   {
/*  642: 787 */     fetchDependents(name, filter, null, order);
/*  643:     */   }
/*  644:     */   
/*  645:     */   private void fetchDependents(String name, QBE filter, MobileWhereClause whereClause, Order order)
/*  646:     */   {
/*  647: 792 */     if ((this.persistedData) && (!isDependentDataFetched(name)))
/*  648:     */     {
/*  649: 794 */       Vector vec = null;
/*  650: 795 */       Object obj = this.dependents.get(name);
/*  651:     */       try
/*  652:     */       {
/*  653: 799 */         if (obj == null)
/*  654:     */         {
/*  655: 801 */           vec = new Vector();
/*  656: 802 */           this.dependents.put(name, vec);
/*  657:     */         }
/*  658:     */         else
/*  659:     */         {
/*  660: 806 */           vec = (Vector)obj;
/*  661:     */         }
/*  662: 809 */         RDORuntime rdoRuntime = RDORuntime.getInstance(this.appName);
/*  663: 810 */         RDOManager rdoManager = rdoRuntime.getRDOManager();
/*  664: 812 */         if (rdoManager != null)
/*  665:     */         {
/*  666: 814 */           Enumeration depRdoEnum = rdoManager.getDependents(name, filter, whereClause, order, this);
/*  667: 815 */           if (depRdoEnum != null)
/*  668:     */           {
/*  669: 817 */             while (depRdoEnum.hasMoreElements())
/*  670:     */             {
/*  671: 819 */               DefaultRDO depRDO = (DefaultRDO)depRdoEnum.nextElement();
/*  672: 820 */               if (depRDO != null)
/*  673:     */               {
/*  674: 821 */                 vec.addElement(depRDO);
/*  675: 822 */                 depRDO.setOwner(this);
/*  676:     */               }
/*  677:     */             }
/*  678: 826 */             setDependentDataFetched(name);
/*  679:     */           }
/*  680:     */         }
/*  681:     */       }
/*  682:     */       catch (RDOException e)
/*  683:     */       {
/*  684: 832 */         MobileLoggerFactory.getDefaultLogger().warn("Failed to fetch dependents", e);
/*  685:     */       }
/*  686:     */     }
/*  687:     */   }
/*  688:     */   
/*  689:     */   public void resetDependents()
/*  690:     */   {
/*  691: 840 */     this.dependents = new Hashtable();
/*  692: 841 */     this.dependentsFetched = new Hashtable();
/*  693:     */   }
/*  694:     */   
/*  695:     */   public void resetDependent(String dependentName)
/*  696:     */   {
/*  697: 846 */     this.dependents.remove(dependentName);
/*  698: 847 */     this.dependentsFetched.remove(dependentName);
/*  699:     */   }
/*  700:     */   
/*  701:     */   public int getDependentSize(String name)
/*  702:     */   {
/*  703: 853 */     return getDependentSize(name, null);
/*  704:     */   }
/*  705:     */   
/*  706:     */   public int getDependentSize(String name, QBE qbe)
/*  707:     */   {
/*  708: 858 */     return getDependentSize(name, qbe, null);
/*  709:     */   }
/*  710:     */   
/*  711:     */   public int getDependentSize(String name, QBE qbe, MobileWhereClause whereClause)
/*  712:     */   {
/*  713: 863 */     int sizeInStore = 0;
/*  714: 867 */     if ((this.persistedData) && (!isDependentDataFetched(name)))
/*  715:     */     {
/*  716: 869 */       RDORuntime rdoRuntime = RDORuntime.getInstance(this.appName);
/*  717: 870 */       RDOManager rdoManager = rdoRuntime.getRDOManager();
/*  718: 872 */       if (rdoManager != null) {
/*  719:     */         try
/*  720:     */         {
/*  721: 876 */           int size = rdoManager.getDependentsSize(name, qbe, whereClause, this);
/*  722: 877 */           sizeInStore = size;
/*  723:     */         }
/*  724:     */         catch (RDOException e)
/*  725:     */         {
/*  726: 881 */           MobileLoggerFactory.getDefaultLogger().warn("Failed to determine dependents size", e);
/*  727:     */         }
/*  728:     */       }
/*  729:     */     }
/*  730: 886 */     Vector vec = null;
/*  731:     */     
/*  732: 888 */     Object obj = this.dependents.get(name);
/*  733: 889 */     if (obj == null) {
/*  734: 891 */       return 0 + sizeInStore;
/*  735:     */     }
/*  736: 893 */     vec = (Vector)obj;
/*  737:     */     
/*  738: 895 */     return vec.size() + sizeInStore;
/*  739:     */   }
/*  740:     */   
/*  741:     */   public void setFlag(int flagIndex, boolean state)
/*  742:     */   {
/*  743: 900 */     if (state) {
/*  744: 902 */       this.flags.set(flagIndex);
/*  745:     */     } else {
/*  746: 906 */       this.flags.clear(flagIndex);
/*  747:     */     }
/*  748:     */   }
/*  749:     */   
/*  750:     */   public boolean isFlagSet(int flagIndex)
/*  751:     */   {
/*  752: 912 */     return this.flags.isSet(flagIndex);
/*  753:     */   }
/*  754:     */   
/*  755:     */   public boolean isReadOnly()
/*  756:     */   {
/*  757: 917 */     return this.flags.isSet(1);
/*  758:     */   }
/*  759:     */   
/*  760:     */   public void setFlag(String attributeName, int flagIndex, boolean state)
/*  761:     */   {
/*  762: 922 */     Object obj = this.attributeFlags.get(attributeName);
/*  763: 923 */     if (obj == null)
/*  764:     */     {
/*  765: 925 */       BitFlags attrFlags = new BitFlags(32);
/*  766: 926 */       attrFlags.set(flagIndex, state);
/*  767: 927 */       this.attributeFlags.put(attributeName, attrFlags);
/*  768:     */     }
/*  769:     */     else
/*  770:     */     {
/*  771: 931 */       BitFlags attrFlags = (BitFlags)obj;
/*  772: 932 */       attrFlags.set(flagIndex, state);
/*  773:     */     }
/*  774:     */   }
/*  775:     */   
/*  776:     */   public boolean isFlagSet(String attributeName, int flagIndex)
/*  777:     */   {
/*  778: 938 */     Object obj = this.attributeFlags.get(attributeName);
/*  779: 939 */     if (obj == null) {
/*  780: 941 */       return false;
/*  781:     */     }
/*  782: 944 */     BitFlags attrFlags = (BitFlags)obj;
/*  783:     */     
/*  784: 946 */     return attrFlags.isSet(flagIndex);
/*  785:     */   }
/*  786:     */   
/*  787:     */   public boolean isReadOnly(String attributeName)
/*  788:     */   {
/*  789: 951 */     if (isReadOnly()) {
/*  790: 953 */       return true;
/*  791:     */     }
/*  792: 956 */     return isFlagSet(attributeName, 1);
/*  793:     */   }
/*  794:     */   
/*  795:     */   public DefaultRDO simpleClone()
/*  796:     */   {
/*  797: 961 */     DefaultRDO clone = null;
/*  798:     */     
/*  799: 963 */     clone = createNewDefaultRDOWithSameAppAndPersistent();
/*  800: 964 */     clone.setName(this.name);
/*  801: 965 */     clone.setOwner(this.owner);
/*  802:     */     
/*  803: 967 */     Enumeration attrEnum = this.attributeValues.keys();
/*  804: 968 */     while (attrEnum.hasMoreElements())
/*  805:     */     {
/*  806: 970 */       String attribute = (String)attrEnum.nextElement();
/*  807: 971 */       clone.attributeValues.put(attribute, this.attributeValues.get(attribute));
/*  808:     */     }
/*  809: 975 */     return clone;
/*  810:     */   }
/*  811:     */   
/*  812:     */   protected DefaultRDO createNewDefaultRDOWithSameAppAndPersistent()
/*  813:     */   {
/*  814: 980 */     return new DefaultRDO(this.appName, this.persistedData);
/*  815:     */   }
/*  816:     */   
/*  817:     */   public void copyAttributeValue(DefaultRDO destRDO, String attributeName)
/*  818:     */   {
/*  819: 985 */     Object value = this.attributeValues.get(attributeName);
/*  820: 986 */     if (value != null) {
/*  821: 988 */       destRDO.attributeValues.put(attributeName, value);
/*  822:     */     }
/*  823:     */   }
/*  824:     */   
/*  825:     */   public double getDoubleValue(String attributeName)
/*  826:     */     throws RDOException
/*  827:     */   {
/*  828: 994 */     Object obj = this.attributeValues.get(attributeName);
/*  829: 996 */     if (obj == null) {
/*  830: 998 */       return 0.0D;
/*  831:     */     }
/*  832:1001 */     if ((obj instanceof Double)) {
/*  833:1003 */       return ((Double)obj).doubleValue();
/*  834:     */     }
/*  835:1005 */     if ((obj instanceof String)) {
/*  836:1007 */       return Double.parseDouble((String)obj);
/*  837:     */     }
/*  838:1008 */     if ((obj instanceof Float)) {
/*  839:1009 */       return ((Float)obj).floatValue();
/*  840:     */     }
/*  841:1012 */     throw new RDOException("Cannot obtain double value for " + attributeName);
/*  842:     */   }
/*  843:     */   
/*  844:     */   public float getFloatValue(String attributeName)
/*  845:     */     throws RDOException
/*  846:     */   {
/*  847:1018 */     Object obj = this.attributeValues.get(attributeName);
/*  848:1020 */     if (obj == null) {
/*  849:1021 */       return 0.0F;
/*  850:     */     }
/*  851:1023 */     if ((obj instanceof String)) {
/*  852:1024 */       return Float.parseFloat((String)obj);
/*  853:     */     }
/*  854:1026 */     if ((obj instanceof Float)) {
/*  855:1027 */       return ((Float)obj).floatValue();
/*  856:     */     }
/*  857:1029 */     if ((obj instanceof Double)) {
/*  858:1030 */       return ((Double)obj).floatValue();
/*  859:     */     }
/*  860:1033 */     throw new RDOException("Cannot obtain float value for " + attributeName);
/*  861:     */   }
/*  862:     */   
/*  863:     */   public void setDoubleValue(String attributeName, double value)
/*  864:     */     throws RDOException
/*  865:     */   {
/*  866:1040 */     this.attributeValues.put(attributeName, new Double(value));
/*  867:     */   }
/*  868:     */   
/*  869:     */   public void setFloatValue(String attributeName, float value)
/*  870:     */     throws RDOException
/*  871:     */   {
/*  872:1046 */     this.attributeValues.put(attributeName, new Float(value));
/*  873:     */   }
/*  874:     */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.persist.DefaultRDO
 * JD-Core Version:    0.7.0.1
 */