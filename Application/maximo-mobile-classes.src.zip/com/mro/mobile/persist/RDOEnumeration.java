package com.mro.mobile.persist;

import java.util.Enumeration;

public abstract interface RDOEnumeration
  extends Enumeration
{
  public abstract void release();
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.persist.RDOEnumeration
 * JD-Core Version:    0.7.0.1
 */