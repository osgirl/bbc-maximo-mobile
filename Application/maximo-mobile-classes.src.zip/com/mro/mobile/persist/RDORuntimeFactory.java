/*  1:   */ package com.mro.mobile.persist;
/*  2:   */ 
/*  3:   */ import com.mro.mobile.MobileApplicationException;
/*  4:   */ import com.mro.mobile.ProgressObserver;
/*  5:   */ 
/*  6:   */ public abstract class RDORuntimeFactory
/*  7:   */ {
/*  8:   */   private String databaseHome;
/*  9:   */   private String databaseName;
/* 10:   */   
/* 11:   */   public RDORuntimeFactory(String databaseHome, String databaseName)
/* 12:   */   {
/* 13:14 */     if (databaseHome == null) {
/* 14:14 */       throw new IllegalArgumentException("database.home cannot be null");
/* 15:   */     }
/* 16:15 */     if (databaseName == null) {
/* 17:15 */       throw new IllegalArgumentException("database.name cannot be null");
/* 18:   */     }
/* 19:16 */     this.databaseHome = databaseHome;
/* 20:17 */     this.databaseName = databaseName.toLowerCase();
/* 21:   */   }
/* 22:   */   
/* 23:   */   public abstract RDORuntime createRDORuntime(String paramString1, String paramString2)
/* 24:   */     throws MobileApplicationException;
/* 25:   */   
/* 26:   */   public abstract RDORuntime createRDORuntime(String paramString1, String paramString2, ProgressObserver paramProgressObserver)
/* 27:   */     throws MobileApplicationException;
/* 28:   */   
/* 29:   */   public String getDatabaseHome()
/* 30:   */   {
/* 31:25 */     return this.databaseHome;
/* 32:   */   }
/* 33:   */   
/* 34:   */   public String getDatabaseName()
/* 35:   */   {
/* 36:29 */     return this.databaseName;
/* 37:   */   }
/* 38:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.persist.RDORuntimeFactory
 * JD-Core Version:    0.7.0.1
 */