/*   1:    */ package com.mro.mobile.persist;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.util.BitFlags;
/*   5:    */ import com.mro.mobile.util.MobileLogger;
/*   6:    */ import com.mro.mobile.util.MobileLoggerFactory;
/*   7:    */ import java.io.ByteArrayInputStream;
/*   8:    */ import java.io.ByteArrayOutputStream;
/*   9:    */ import java.io.DataInput;
/*  10:    */ import java.io.DataOutput;
/*  11:    */ import java.io.IOException;
/*  12:    */ import java.io.ObjectInputStream;
/*  13:    */ import java.io.ObjectOutputStream;
/*  14:    */ import java.io.OptionalDataException;
/*  15:    */ import java.io.StreamCorruptedException;
/*  16:    */ import java.util.ArrayList;
/*  17:    */ import java.util.Calendar;
/*  18:    */ import java.util.Enumeration;
/*  19:    */ import java.util.Iterator;
/*  20:    */ import java.util.List;
/*  21:    */ import java.util.zip.GZIPInputStream;
/*  22:    */ import java.util.zip.GZIPOutputStream;
/*  23:    */ 
/*  24:    */ public class RDOSerializer
/*  25:    */ {
/*  26: 41 */   private static MobileLogger SERIALIZATION_LOGGER = MobileLoggerFactory.getLogger("maximo.mobile.serialization");
/*  27: 44 */   private static final int secureDSTYear = Calendar.getInstance().get(1);
/*  28:    */   
/*  29:    */   public Object readInstance(DataInput input)
/*  30:    */     throws IOException
/*  31:    */   {
/*  32:    */     try
/*  33:    */     {
/*  34: 53 */       return readRDOInstance(input);
/*  35:    */     }
/*  36:    */     catch (Exception e)
/*  37:    */     {
/*  38: 57 */       SERIALIZATION_LOGGER.error(e.getMessage(), e);
/*  39: 58 */       throw new IOException(e.getMessage());
/*  40:    */     }
/*  41:    */   }
/*  42:    */   
/*  43:    */   public void writeInstance(DataOutput output, Object instance)
/*  44:    */     throws IOException
/*  45:    */   {
/*  46: 67 */     if ((instance instanceof RDO)) {
/*  47:    */       try
/*  48:    */       {
/*  49: 71 */         writeRDOInstance(output, (RDO)instance, false);
/*  50:    */       }
/*  51:    */       catch (Exception e)
/*  52:    */       {
/*  53: 75 */         SERIALIZATION_LOGGER.error(e.getMessage(), e);
/*  54: 76 */         throw new IOException(e.getMessage());
/*  55:    */       }
/*  56:    */     }
/*  57:    */   }
/*  58:    */   
/*  59:    */   public void writeInstance(DataOutput output, Object instance, boolean ignoreDependents)
/*  60:    */     throws IOException
/*  61:    */   {
/*  62: 85 */     if ((instance instanceof RDO)) {
/*  63:    */       try
/*  64:    */       {
/*  65: 89 */         writeRDOInstance(output, (RDO)instance, ignoreDependents);
/*  66:    */       }
/*  67:    */       catch (MobileApplicationException e)
/*  68:    */       {
/*  69: 93 */         throw new IOException(e.getMessage());
/*  70:    */       }
/*  71:    */     }
/*  72:    */   }
/*  73:    */   
/*  74:    */   private Object readRDOInstance(DataInput input)
/*  75:    */     throws IOException, MobileApplicationException
/*  76:    */   {
/*  77:133 */     boolean infoEnabled = SERIALIZATION_LOGGER.isInfoEnabled();
/*  78:    */     
/*  79:    */ 
/*  80:136 */     String appName = input.readUTF();
/*  81:138 */     if (infoEnabled) {
/*  82:140 */       SERIALIZATION_LOGGER.info("RDOSerializer read app name = " + appName);
/*  83:    */     }
/*  84:151 */     String name = input.readUTF();
/*  85:153 */     if (infoEnabled) {
/*  86:155 */       SERIALIZATION_LOGGER.info("RDOSerializer read name = " + name);
/*  87:    */     }
/*  88:159 */     DefaultRDO rdo = newRDO(appName);
/*  89:160 */     rdo.setName(name);
/*  90:    */     
/*  91:162 */     RDOInfo rdoInfo = getRDOInfo(appName, name);
/*  92:163 */     if (rdoInfo == null) {
/*  93:166 */       throw new IOException("RDOSerializer RDO Information does not exist for " + name);
/*  94:    */     }
/*  95:177 */     int byteCount = input.readInt();
/*  96:178 */     if (infoEnabled) {
/*  97:180 */       SERIALIZATION_LOGGER.info("RDOSerializer read to read attribute bytes count = " + byteCount);
/*  98:    */     }
/*  99:182 */     List attributesToRead = getAttributesToRead(input, byteCount);
/* 100:183 */     for (Iterator it = attributesToRead.iterator(); it.hasNext();)
/* 101:    */     {
/* 102:185 */       String attrName = it.next().toString();
/* 103:    */       
/* 104:    */ 
/* 105:    */ 
/* 106:    */ 
/* 107:    */ 
/* 108:    */ 
/* 109:    */ 
/* 110:193 */       RDOAttributeInfo attrInfo = rdoInfo.getAttributeInfo(attrName);
/* 111:194 */       if (attrInfo == null)
/* 112:    */       {
/* 113:195 */         SERIALIZATION_LOGGER.error("RDOSerializer read " + attrName + " but it is was not found in the current RDOInfo. Cannot continue reading.");
/* 114:    */         
/* 115:197 */         throw new IOException("RDOSerializer RDO Attribute Info does not exist for " + name + "." + attrName);
/* 116:    */       }
/* 117:199 */       int dataType = attrInfo.getDataType();
/* 118:200 */       switch (dataType)
/* 119:    */       {
/* 120:    */       case 1: 
/* 121:    */       case 2: 
/* 122:    */       case 3: 
/* 123:205 */         rdo.setStringValue(attrName, input.readUTF());
/* 124:206 */         if (infoEnabled) {
/* 125:208 */           SERIALIZATION_LOGGER.info("RDOSerializer read " + attrName + ", type ALN, value = " + rdo.getStringValue(attrName));
/* 126:    */         }
/* 127:    */         break;
/* 128:    */       case 8: 
/* 129:212 */         rdo.setBooleanValue(attrName, input.readBoolean());
/* 130:213 */         if (infoEnabled) {
/* 131:215 */           SERIALIZATION_LOGGER.info("RDOSerializer read " + attrName + ", type BOOLEAN, value = " + rdo.getBooleanValue(attrName));
/* 132:    */         }
/* 133:    */         break;
/* 134:    */       case 4: 
/* 135:219 */         rdo.setIntValue(attrName, input.readInt());
/* 136:220 */         if (infoEnabled) {
/* 137:222 */           SERIALIZATION_LOGGER.info("RDOSerializer read " + attrName + ", type INTEGER, value = " + rdo.getIntValue(attrName));
/* 138:    */         }
/* 139:    */         break;
/* 140:    */       case 5: 
/* 141:226 */         rdo.setLongValue(attrName, input.readLong());
/* 142:227 */         if (infoEnabled) {
/* 143:229 */           SERIALIZATION_LOGGER.info("RDOSerializer read " + attrName + ", type LONG, value = " + rdo.getLongValue(attrName));
/* 144:    */         }
/* 145:    */         break;
/* 146:    */       case 6: 
/* 147:234 */         rdo.setFloatValue(attrName, input.readFloat());
/* 148:235 */         if (infoEnabled) {
/* 149:237 */           SERIALIZATION_LOGGER.info("RDOSerializer read " + attrName + ", type FLOAT, value = " + rdo.getFloatValue(attrName));
/* 150:    */         }
/* 151:    */         break;
/* 152:    */       case 7: 
/* 153:242 */         rdo.setDoubleValue(attrName, input.readDouble());
/* 154:243 */         if (infoEnabled) {
/* 155:245 */           SERIALIZATION_LOGGER.info("RDOSerializer read " + attrName + ", type DOUBLE, value = " + rdo.getDoubleValue(attrName));
/* 156:    */         }
/* 157:    */         break;
/* 158:    */       case 9: 
/* 159:251 */         String date = Integer.toString(input.readInt());
/* 160:252 */         String year = date.substring(0, 4);
/* 161:253 */         String month = date.substring(4, 6);
/* 162:254 */         String day = date.substring(6, 8);
/* 163:255 */         Calendar calDate = Calendar.getInstance();
/* 164:256 */         calDate.clear();
/* 165:257 */         calDate.set(Integer.parseInt(year), Integer.parseInt(month), Integer.parseInt(day));
/* 166:    */         
/* 167:    */ 
/* 168:    */ 
/* 169:261 */         rdo.setLongValue(attrName, calDate.getTimeInMillis());
/* 170:262 */         if (infoEnabled) {
/* 171:264 */           SERIALIZATION_LOGGER.info("RDOSerializer read " + attrName + ", type DATE, value = " + rdo.getLongValue(attrName));
/* 172:    */         }
/* 173:    */         break;
/* 174:    */       case 10: 
/* 175:269 */         String time = Integer.toString(input.readInt());
/* 176:270 */         String hour = time.substring(1, 3);
/* 177:271 */         String minute = time.substring(3, 5);
/* 178:272 */         String second = time.substring(5, 7);
/* 179:273 */         Calendar calTime = Calendar.getInstance();
/* 180:274 */         calTime.clear();
/* 181:275 */         calTime.set(11, Integer.parseInt(hour));
/* 182:276 */         calTime.set(12, Integer.parseInt(minute));
/* 183:277 */         calTime.set(13, Integer.parseInt(second));
/* 184:    */         
/* 185:279 */         rdo.setLongValue(attrName, calTime.getTimeInMillis());
/* 186:280 */         if (infoEnabled) {
/* 187:282 */           SERIALIZATION_LOGGER.info("RDOSerializer read " + attrName + ", type TIME, value = " + rdo.getLongValue(attrName));
/* 188:    */         }
/* 189:    */         break;
/* 190:    */       case 11: 
/* 191:286 */         rdo.setLongValue(attrName, input.readLong());
/* 192:287 */         if (infoEnabled) {
/* 193:289 */           SERIALIZATION_LOGGER.info("RDOSerializer read " + attrName + ", type DATETIME, value = " + rdo.getLongValue(attrName));
/* 194:    */         }
/* 195:    */         break;
/* 196:    */       case 12: 
/* 197:293 */         int noOfBytes = input.readInt();
/* 198:294 */         byte[] bytes = new byte[noOfBytes];
/* 199:295 */         input.readFully(bytes);
/* 200:296 */         if (attrName.equalsIgnoreCase("_ATTRMODIFIED")) {
/* 201:297 */           bytes = convertAttributeNamesToIndexes(bytes, rdoInfo);
/* 202:    */         }
/* 203:299 */         rdo.setBinaryValue(attrName, bytes);
/* 204:300 */         if (infoEnabled) {
/* 205:302 */           SERIALIZATION_LOGGER.info("RDOSerializer read " + attrName + ", type BYTES, value = " + rdo.getBinaryValue(attrName));
/* 206:    */         }
/* 207:    */         break;
/* 208:    */       }
/* 209:    */     }
/* 210:311 */     int dependentCount = input.readInt();
/* 211:313 */     if (infoEnabled) {
/* 212:315 */       SERIALIZATION_LOGGER.info("RDOSerializer read dependent count = " + dependentCount);
/* 213:    */     }
/* 214:318 */     String[] dependentNames = rdoInfo.getDependentNames();
/* 215:319 */     for (int i = 0; i < dependentCount; i++)
/* 216:    */     {
/* 217:321 */       int dependentRDOCount = input.readInt();
/* 218:322 */       if (infoEnabled) {
/* 219:324 */         SERIALIZATION_LOGGER.info("RDOSerializer read dependents = " + dependentRDOCount);
/* 220:    */       }
/* 221:326 */       for (int j = 0; j < dependentRDOCount; j++)
/* 222:    */       {
/* 223:328 */         DefaultRDO dependentRDO = (DefaultRDO)readRDOInstance(input);
/* 224:329 */         rdo.addDependent(dependentNames[i], dependentRDO);
/* 225:    */       }
/* 226:    */     }
/* 227:334 */     int childrenCount = input.readInt();
/* 228:335 */     if (infoEnabled) {
/* 229:337 */       SERIALIZATION_LOGGER.info("RDOSerializer read children count = " + childrenCount);
/* 230:    */     }
/* 231:340 */     for (int j = 0; j < childrenCount; j++)
/* 232:    */     {
/* 233:342 */       DefaultRDO dependentRDO = (DefaultRDO)readRDOInstance(input);
/* 234:343 */       rdo.addDependent("CHILDREN", dependentRDO);
/* 235:    */     }
/* 236:348 */     return rdo;
/* 237:    */   }
/* 238:    */   
/* 239:    */   protected DefaultRDO newRDO(String appName)
/* 240:    */   {
/* 241:353 */     return new DefaultRDO(appName);
/* 242:    */   }
/* 243:    */   
/* 244:    */   private byte[] convertAttributeNamesToIndexes(byte[] bytes, RDOInfo rdoInfo)
/* 245:    */     throws IOException
/* 246:    */   {
/* 247:357 */     List attributes = unzipAttributeList(bytes);
/* 248:358 */     BitFlags flags = new BitFlags(rdoInfo.getAttributeCount());
/* 249:359 */     for (Iterator it = attributes.iterator(); it.hasNext();)
/* 250:    */     {
/* 251:360 */       String attrName = it.next().toString();
/* 252:361 */       int index = rdoInfo.getAttributeIndex(attrName);
/* 253:362 */       if (index < 0)
/* 254:    */       {
/* 255:363 */         SERIALIZATION_LOGGER.warn("RDOSerializer read modified " + attrName + " but it is was not found in the current RDOInfo. Ignoring attribute.");
/* 256:    */       }
/* 257:    */       else
/* 258:    */       {
/* 259:365 */         if (SERIALIZATION_LOGGER.isInfoEnabled()) {
/* 260:366 */           SERIALIZATION_LOGGER.info("RDOSerializer read updated " + attrName + " as modified, index " + index);
/* 261:    */         }
/* 262:368 */         flags.set(index);
/* 263:    */       }
/* 264:    */     }
/* 265:371 */     return flags.getFlags();
/* 266:    */   }
/* 267:    */   
/* 268:    */   private List getAttributesToRead(DataInput input, int byteCount)
/* 269:    */     throws IOException
/* 270:    */   {
/* 271:376 */     byte[] data = new byte[byteCount];
/* 272:377 */     input.readFully(data);
/* 273:378 */     if (SERIALIZATION_LOGGER.isInfoEnabled()) {
/* 274:379 */       SERIALIZATION_LOGGER.info("RDOSerializer read to read attribute bytes = " + data);
/* 275:    */     }
/* 276:381 */     return unzipAttributeList(data);
/* 277:    */   }
/* 278:    */   
/* 279:    */   private List unzipAttributeList(byte[] data)
/* 280:    */     throws IOException, StreamCorruptedException, OptionalDataException
/* 281:    */   {
/* 282:387 */     ByteArrayInputStream bais = new ByteArrayInputStream(data);
/* 283:388 */     GZIPInputStream gzipis = new GZIPInputStream(bais);
/* 284:389 */     ObjectInputStream ois = new ObjectInputStream(gzipis);
/* 285:    */     List list;
/* 286:    */     try
/* 287:    */     {
/* 288:392 */       list = (List)ois.readObject();
/* 289:    */     }
/* 290:    */     catch (ClassNotFoundException e)
/* 291:    */     {
/* 292:394 */       SERIALIZATION_LOGGER.error("Error reading the list of attributes. ", e);
/* 293:395 */       throw new IOException(e.getMessage());
/* 294:    */     }
/* 295:    */     finally
/* 296:    */     {
/* 297:397 */       bais.close();
/* 298:398 */       gzipis.close();
/* 299:399 */       ois.close();
/* 300:    */     }
/* 301:401 */     return list;
/* 302:    */   }
/* 303:    */   
/* 304:    */   private void writeRDOInstance(DataOutput output, RDO rdo, boolean ignoreDependents)
/* 305:    */     throws IOException, MobileApplicationException
/* 306:    */   {
/* 307:408 */     RDOInfo rdoInfo = getRDOInfo(rdo.getAppName(), rdo.getName());
/* 308:409 */     if (rdoInfo == null) {
/* 309:412 */       throw new IOException("RDOSerializer RDO Information does not exist for " + rdo.getName());
/* 310:    */     }
/* 311:415 */     boolean infoEnabled = SERIALIZATION_LOGGER.isInfoEnabled();
/* 312:    */     
/* 313:    */ 
/* 314:    */ 
/* 315:    */ 
/* 316:    */ 
/* 317:    */ 
/* 318:    */ 
/* 319:    */ 
/* 320:    */ 
/* 321:    */ 
/* 322:426 */     output.writeUTF(rdo.getAppName());
/* 323:427 */     if (infoEnabled) {
/* 324:429 */       SERIALIZATION_LOGGER.info("RDOSerializer wrote app name = " + rdo.getAppName());
/* 325:    */     }
/* 326:433 */     output.writeUTF(rdo.getName());
/* 327:434 */     if (infoEnabled) {
/* 328:436 */       SERIALIZATION_LOGGER.info("RDOSerializer wrote name = " + rdo.getName());
/* 329:    */     }
/* 330:439 */     int attrCount = rdoInfo.getAttributeCount();
/* 331:440 */     String[] attrNames = rdoInfo.getAttributeNames();
/* 332:    */     
/* 333:    */ 
/* 334:    */ 
/* 335:    */ 
/* 336:    */ 
/* 337:    */ 
/* 338:    */ 
/* 339:    */ 
/* 340:    */ 
/* 341:    */ 
/* 342:    */ 
/* 343:    */ 
/* 344:    */ 
/* 345:    */ 
/* 346:    */ 
/* 347:456 */     byte[] attributesToRead = getCompactedAttributeList(rdo, attrNames);
/* 348:457 */     if (infoEnabled) {
/* 349:459 */       SERIALIZATION_LOGGER.info("RDOSerializer wrote to read attribute bytes count = " + attributesToRead.length);
/* 350:    */     }
/* 351:461 */     output.writeInt(attributesToRead.length);
/* 352:462 */     if (infoEnabled) {
/* 353:464 */       SERIALIZATION_LOGGER.info("RDOSerializer wrote to read attribute bytes = " + attributesToRead);
/* 354:    */     }
/* 355:466 */     output.write(attributesToRead);
/* 356:467 */     for (int i = 0; i < attrCount; i++)
/* 357:    */     {
/* 358:469 */       String attrName = attrNames[i];
/* 359:472 */       if (!rdo.isNull(attrName))
/* 360:    */       {
/* 361:477 */         RDOAttributeInfo attrInfo = rdoInfo.getAttributeInfo(attrName);
/* 362:478 */         int dataType = attrInfo.getDataType();
/* 363:479 */         switch (dataType)
/* 364:    */         {
/* 365:    */         case 1: 
/* 366:    */         case 2: 
/* 367:    */         case 3: 
/* 368:484 */           output.writeUTF(rdo.getStringValue(attrName));
/* 369:485 */           if (infoEnabled) {
/* 370:487 */             SERIALIZATION_LOGGER.info("RDOSerializer wrote " + attrName + ", type ALN, value = " + rdo.getStringValue(attrName));
/* 371:    */           }
/* 372:    */           break;
/* 373:    */         case 8: 
/* 374:491 */           output.writeBoolean(rdo.getBooleanValue(attrName));
/* 375:492 */           if (infoEnabled) {
/* 376:494 */             SERIALIZATION_LOGGER.info("RDOSerializer wrote " + attrName + ", type BOOLEAN, value = " + rdo.getBooleanValue(attrName));
/* 377:    */           }
/* 378:    */           break;
/* 379:    */         case 4: 
/* 380:498 */           output.writeInt(rdo.getIntValue(attrName));
/* 381:499 */           if (infoEnabled) {
/* 382:501 */             SERIALIZATION_LOGGER.info("RDOSerializer wrote " + attrName + ", type INTEGER, value = " + rdo.getIntValue(attrName));
/* 383:    */           }
/* 384:    */           break;
/* 385:    */         case 5: 
/* 386:505 */           output.writeLong(rdo.getLongValue(attrName));
/* 387:506 */           if (infoEnabled) {
/* 388:508 */             SERIALIZATION_LOGGER.info("RDOSerializer wrote " + attrName + ", type LONG, value = " + rdo.getLongValue(attrName));
/* 389:    */           }
/* 390:    */           break;
/* 391:    */         case 6: 
/* 392:513 */           output.writeFloat(rdo.getFloatValue(attrName));
/* 393:514 */           if (infoEnabled) {
/* 394:516 */             SERIALIZATION_LOGGER.info("RDOSerializer wrote " + attrName + ", type FLOAT, value = " + rdo.getFloatValue(attrName));
/* 395:    */           }
/* 396:    */           break;
/* 397:    */         case 7: 
/* 398:521 */           output.writeDouble(rdo.getDoubleValue(attrName));
/* 399:522 */           if (infoEnabled) {
/* 400:524 */             SERIALIZATION_LOGGER.info("RDOSerializer wrote " + attrName + ", type DOUBLE, value = " + rdo.getDoubleValue(attrName));
/* 401:    */           }
/* 402:    */           break;
/* 403:    */         case 9: 
/* 404:529 */           Calendar calDate = Calendar.getInstance();
/* 405:530 */           calDate.setTimeInMillis(rdo.getLongValue(attrName));
/* 406:    */           
/* 407:532 */           String year = "" + calDate.get(1);
/* 408:    */           
/* 409:534 */           int nMonth = calDate.get(2);
/* 410:535 */           String month = (nMonth < 10 ? "0" : "") + nMonth;
/* 411:    */           
/* 412:537 */           int nDay = calDate.get(5);
/* 413:538 */           String day = (nDay < 10 ? "0" : "") + nDay;
/* 414:    */           
/* 415:540 */           String cDate = year + month + day;
/* 416:541 */           int date = Integer.parseInt(cDate);
/* 417:542 */           output.writeInt(date);
/* 418:543 */           if (infoEnabled) {
/* 419:545 */             SERIALIZATION_LOGGER.info("RDOSerializer wrote " + attrName + ", type DATE, value = " + rdo.getLongValue(attrName));
/* 420:    */           }
/* 421:    */           break;
/* 422:    */         case 10: 
/* 423:550 */           Calendar calTime = Calendar.getInstance();
/* 424:551 */           calTime.setTimeInMillis(rdo.getLongValue(attrName));
/* 425:    */           
/* 426:553 */           int nHour = calTime.get(11);
/* 427:554 */           String hour = "9" + (nHour < 10 ? "0" : "") + nHour;
/* 428:    */           
/* 429:556 */           int nMinute = calTime.get(12);
/* 430:557 */           String minute = (nMinute < 10 ? "0" : "") + nMinute;
/* 431:    */           
/* 432:559 */           int nSecond = calTime.get(13);
/* 433:560 */           String second = (nSecond < 10 ? "0" : "") + nSecond;
/* 434:    */           
/* 435:562 */           String cTime = hour + minute + second;
/* 436:563 */           int time = Integer.parseInt(cTime);
/* 437:564 */           output.writeInt(time);
/* 438:566 */           if (infoEnabled) {
/* 439:568 */             SERIALIZATION_LOGGER.info("RDOSerializer wrote " + attrName + ", type TIME, value = " + rdo.getLongValue(attrName));
/* 440:    */           }
/* 441:    */           break;
/* 442:    */         case 11: 
/* 443:572 */           output.writeLong(rdo.getLongValue(attrName));
/* 444:573 */           if (infoEnabled) {
/* 445:575 */             SERIALIZATION_LOGGER.info("RDOSerializer wrote " + attrName + ", type DATETIME, value = " + rdo.getLongValue(attrName));
/* 446:    */           }
/* 447:    */           break;
/* 448:    */         case 12: 
/* 449:580 */           byte[] bytes = rdo.getBinaryValue(attrName);
/* 450:581 */           if (bytes == null)
/* 451:    */           {
/* 452:583 */             output.writeInt(0);
/* 453:    */           }
/* 454:    */           else
/* 455:    */           {
/* 456:587 */             if (attrName.equalsIgnoreCase("_ATTRMODIFIED")) {
/* 457:588 */               bytes = convertAttributeIndexesToNames(bytes, rdoInfo);
/* 458:    */             }
/* 459:590 */             output.writeInt(bytes.length);
/* 460:591 */             output.write(bytes);
/* 461:    */           }
/* 462:594 */           if (infoEnabled) {
/* 463:596 */             SERIALIZATION_LOGGER.info("RDOSerializer wrote " + attrName + ", type BYTES, value = " + rdo.getBinaryValue(attrName));
/* 464:    */           }
/* 465:    */           break;
/* 466:    */         }
/* 467:    */       }
/* 468:    */     }
/* 469:604 */     if (ignoreDependents)
/* 470:    */     {
/* 471:607 */       output.writeInt(0);
/* 472:    */       
/* 473:    */ 
/* 474:610 */       output.writeInt(0);
/* 475:    */     }
/* 476:    */     else
/* 477:    */     {
/* 478:615 */       int dependentCount = rdoInfo.getDependentCount();
/* 479:616 */       String[] dependentNames = rdoInfo.getDependentNames();
/* 480:    */       
/* 481:618 */       output.writeInt(dependentCount);
/* 482:619 */       if (infoEnabled) {
/* 483:621 */         SERIALIZATION_LOGGER.info("RDOSerializer wrote dependent count = " + dependentCount);
/* 484:    */       }
/* 485:624 */       for (int i = 0; i < dependentCount; i++)
/* 486:    */       {
/* 487:626 */         int dependentRDOCount = rdo.getDependentSize(dependentNames[i]);
/* 488:627 */         output.writeInt(dependentRDOCount);
/* 489:628 */         if (infoEnabled) {
/* 490:630 */           SERIALIZATION_LOGGER.info("RDOSerializer wrote dependents = " + dependentRDOCount);
/* 491:    */         }
/* 492:633 */         Enumeration depRDOEnum = rdo.getDependents(dependentNames[i]);
/* 493:634 */         while (depRDOEnum.hasMoreElements())
/* 494:    */         {
/* 495:636 */           DefaultRDO dependentRDO = (DefaultRDO)depRDOEnum.nextElement();
/* 496:637 */           writeRDOInstance(output, dependentRDO, false);
/* 497:    */         }
/* 498:    */       }
/* 499:642 */       int childrenCount = rdo.getDependentSize("CHILDREN");
/* 500:643 */       output.writeInt(childrenCount);
/* 501:644 */       if (infoEnabled) {
/* 502:646 */         SERIALIZATION_LOGGER.info("RDOSerializer wrote children count = " + childrenCount);
/* 503:    */       }
/* 504:649 */       if (childrenCount > 0)
/* 505:    */       {
/* 506:651 */         Enumeration depRDOEnum = rdo.getDependents("CHILDREN");
/* 507:652 */         while (depRDOEnum.hasMoreElements())
/* 508:    */         {
/* 509:654 */           DefaultRDO dependentRDO = (DefaultRDO)depRDOEnum.nextElement();
/* 510:655 */           writeRDOInstance(output, dependentRDO, false);
/* 511:    */         }
/* 512:    */       }
/* 513:    */     }
/* 514:    */   }
/* 515:    */   
/* 516:    */   public RDOInfo getRDOInfo(String appName, String rdoName)
/* 517:    */   {
/* 518:663 */     return RDOUtil.getRDOInfo(appName, rdoName);
/* 519:    */   }
/* 520:    */   
/* 521:    */   private byte[] convertAttributeIndexesToNames(byte[] bytes, RDOInfo rdoInfo)
/* 522:    */     throws RDOException, IOException
/* 523:    */   {
/* 524:668 */     int attrCount = rdoInfo.getAttributeCount();
/* 525:669 */     BitFlags modifiedFlags = new BitFlags(attrCount, bytes);
/* 526:670 */     List modifiedAttributes = new ArrayList(attrCount);
/* 527:671 */     for (int i = 0; i < attrCount; i++)
/* 528:    */     {
/* 529:672 */       String attrName = rdoInfo.getAttributeName(i);
/* 530:674 */       if (modifiedFlags.isSet(i))
/* 531:    */       {
/* 532:675 */         if (SERIALIZATION_LOGGER.isInfoEnabled()) {
/* 533:676 */           SERIALIZATION_LOGGER.info("RDOSerializer wrote adding " + attrName + " as modified, index " + i);
/* 534:    */         }
/* 535:678 */         modifiedAttributes.add(attrName);
/* 536:    */       }
/* 537:    */     }
/* 538:681 */     return compactList(modifiedAttributes);
/* 539:    */   }
/* 540:    */   
/* 541:    */   private byte[] getCompactedAttributeList(RDO rdo, String[] attrNames)
/* 542:    */     throws RDOException, IOException
/* 543:    */   {
/* 544:687 */     int attrCount = attrNames.length;
/* 545:688 */     List notNullAttributes = new ArrayList(attrCount);
/* 546:689 */     for (int i = 0; i < attrCount; i++)
/* 547:    */     {
/* 548:690 */       String attrName = attrNames[i];
/* 549:691 */       if (!rdo.isNull(attrName)) {
/* 550:692 */         notNullAttributes.add(attrName);
/* 551:    */       }
/* 552:    */     }
/* 553:695 */     return compactList(notNullAttributes);
/* 554:    */   }
/* 555:    */   
/* 556:    */   private byte[] compactList(List notNullAttributes)
/* 557:    */     throws IOException
/* 558:    */   {
/* 559:700 */     ByteArrayOutputStream baos = new ByteArrayOutputStream();
/* 560:701 */     GZIPOutputStream zipoos = new GZIPOutputStream(baos);
/* 561:702 */     ObjectOutputStream oos = new ObjectOutputStream(zipoos);
/* 562:703 */     oos.writeObject(notNullAttributes);
/* 563:704 */     oos.flush();
/* 564:705 */     zipoos.flush();
/* 565:706 */     baos.flush();
/* 566:707 */     oos.close();
/* 567:708 */     zipoos.close();
/* 568:709 */     baos.close();
/* 569:710 */     return baos.toByteArray();
/* 570:    */   }
/* 571:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.persist.RDOSerializer
 * JD-Core Version:    0.7.0.1
 */