package com.mro.mobile.persist;

public abstract interface RDOTransactionManager
{
  public abstract void begin()
    throws RDOException;
  
  public abstract void commit()
    throws RDOException;
  
  public abstract void rollback()
    throws RDOException;
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.persist.RDOTransactionManager
 * JD-Core Version:    0.7.0.1
 */