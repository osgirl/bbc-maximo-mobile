/*  1:   */ package com.mro.mobile.persist;
/*  2:   */ 
/*  3:   */ public class DefaultRDOKey
/*  4:   */   implements RDOKey
/*  5:   */ {
/*  6:19 */   String[] keyValues = null;
/*  7:   */   
/*  8:   */   public DefaultRDOKey(RDOInfo rdoInfo, RDO rdo)
/*  9:   */     throws RDOException
/* 10:   */   {
/* 11:23 */     this.keyValues = new String[rdoInfo.getkeySize()];
/* 12:   */     
/* 13:25 */     String[] attrNames = rdoInfo.getKeyAttributeNames();
/* 14:26 */     for (int i = 0; i < attrNames.length; i++)
/* 15:   */     {
/* 16:28 */       RDOAttributeInfo attrInfo = rdoInfo.getAttributeInfo(attrNames[i]);
/* 17:30 */       if (!rdo.isNull(attrNames[i]))
/* 18:   */       {
/* 19:32 */         String attrValue = rdo.getStringValue(attrNames[i]);
/* 20:   */         
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:   */ 
/* 25:38 */         this.keyValues[i] = attrValue;
/* 26:   */       }
/* 27:   */     }
/* 28:   */   }
/* 29:   */   
/* 30:   */   public String[] getKeyValues()
/* 31:   */   {
/* 32:48 */     return this.keyValues;
/* 33:   */   }
/* 34:   */   
/* 35:   */   public boolean equals(Object obj)
/* 36:   */   {
/* 37:53 */     if (!(obj instanceof RDOKey)) {
/* 38:55 */       return false;
/* 39:   */     }
/* 40:58 */     RDOKey otherKey = (RDOKey)obj;
/* 41:59 */     if (getKeyValues().equals(otherKey.getKeyValues())) {
/* 42:61 */       return true;
/* 43:   */     }
/* 44:64 */     return false;
/* 45:   */   }
/* 46:   */   
/* 47:   */   public int hashCode()
/* 48:   */   {
/* 49:69 */     return getKeyValues().hashCode();
/* 50:   */   }
/* 51:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.persist.DefaultRDOKey
 * JD-Core Version:    0.7.0.1
 */