/*   1:    */ package com.mro.mobile.persist;
/*   2:    */ 
/*   3:    */ import java.util.Date;
/*   4:    */ import java.util.Vector;
/*   5:    */ 
/*   6:    */ public class QBEData
/*   7:    */ {
/*   8:    */   public static final int QBE_DEFAULT_VALUE = 0;
/*   9:    */   public static final int QBE_NULL_VALUE = 1;
/*  10:    */   public static final int QBE_NOT_NULL_VALUE = 2;
/*  11: 26 */   private String value = null;
/*  12: 27 */   private Object internalValue = null;
/*  13: 28 */   private Date internalDateValue = null;
/*  14: 29 */   private String condition = null;
/*  15: 30 */   private int type = 0;
/*  16: 31 */   private boolean multipleValues = false;
/*  17:    */   
/*  18:    */   public QBEData(String value, String condition, Object internalValue, int type)
/*  19:    */   {
/*  20: 35 */     this.value = value;
/*  21: 36 */     this.condition = condition;
/*  22: 37 */     this.internalValue = value;
/*  23: 38 */     this.type = type;
/*  24: 39 */     if ((internalValue instanceof Date)) {
/*  25: 41 */       this.internalDateValue = ((Date)internalValue);
/*  26:    */     }
/*  27: 43 */     if (((internalValue instanceof String)) || ((internalValue instanceof Number)))
/*  28:    */     {
/*  29: 45 */       String internalStrValue = (String)internalValue;
/*  30: 46 */       String[] values = getStringValues(internalStrValue);
/*  31: 47 */       if (values.length > 1)
/*  32:    */       {
/*  33: 49 */         this.multipleValues = true;
/*  34: 50 */         this.internalValue = values;
/*  35:    */       }
/*  36: 52 */       else if (values.length == 0)
/*  37:    */       {
/*  38: 54 */         this.internalValue = "";
/*  39:    */       }
/*  40: 56 */       else if (values.length == 1)
/*  41:    */       {
/*  42: 58 */         this.internalValue = internalStrValue;
/*  43:    */       }
/*  44:    */     }
/*  45:    */   }
/*  46:    */   
/*  47:    */   public String getValue()
/*  48:    */   {
/*  49: 65 */     return this.value;
/*  50:    */   }
/*  51:    */   
/*  52:    */   public String getCondition()
/*  53:    */   {
/*  54: 70 */     return this.condition;
/*  55:    */   }
/*  56:    */   
/*  57:    */   public Object getInternalValue()
/*  58:    */   {
/*  59: 75 */     return this.internalValue;
/*  60:    */   }
/*  61:    */   
/*  62:    */   public Date getInternalDateValue()
/*  63:    */   {
/*  64: 80 */     return this.internalDateValue;
/*  65:    */   }
/*  66:    */   
/*  67:    */   public int getType()
/*  68:    */   {
/*  69: 85 */     return this.type;
/*  70:    */   }
/*  71:    */   
/*  72:    */   public boolean isNullValueCheck()
/*  73:    */   {
/*  74: 90 */     if ((this.type == 1) || (this.type == 2)) {
/*  75: 92 */       return true;
/*  76:    */     }
/*  77: 95 */     return false;
/*  78:    */   }
/*  79:    */   
/*  80:    */   public boolean hasMultipleValues()
/*  81:    */   {
/*  82:100 */     return this.multipleValues;
/*  83:    */   }
/*  84:    */   
/*  85:    */   private static String[] getStringValues(String value)
/*  86:    */   {
/*  87:105 */     String[] values = new String[0];
/*  88:107 */     if (value == null) {
/*  89:109 */       return values;
/*  90:    */     }
/*  91:112 */     if (value.trim().length() == 0) {
/*  92:114 */       return values;
/*  93:    */     }
/*  94:117 */     value = value.trim();
/*  95:    */     
/*  96:    */ 
/*  97:    */ 
/*  98:121 */     int index = value.indexOf(",");
/*  99:122 */     if (index < 0) {
/* 100:124 */       return new String[] { value };
/* 101:    */     }
/* 102:127 */     String newValue = value;
/* 103:128 */     Vector commaValues = new Vector();
/* 104:131 */     while (newValue.length() != 0)
/* 105:    */     {
/* 106:136 */       String v = newValue.substring(0, index);
/* 107:137 */       if (v.trim().length() > 0) {
/* 108:139 */         commaValues.addElement(v.trim());
/* 109:    */       }
/* 110:142 */       if (newValue.length() == 0) {
/* 111:    */         break;
/* 112:    */       }
/* 113:147 */       newValue = newValue.substring(index + 1);
/* 114:149 */       if (newValue.length() == 0) {
/* 115:    */         break;
/* 116:    */       }
/* 117:154 */       index = newValue.indexOf(",");
/* 118:155 */       if (index < 0)
/* 119:    */       {
/* 120:157 */         if (newValue.trim().length() <= 0) {
/* 121:    */           break;
/* 122:    */         }
/* 123:159 */         newValue = newValue.trim();
/* 124:160 */         commaValues.addElement(newValue); break;
/* 125:    */       }
/* 126:    */     }
/* 127:166 */     values = new String[commaValues.size()];
/* 128:167 */     for (int i = 0; i < commaValues.size(); i++) {
/* 129:169 */       values[i] = ((String)commaValues.elementAt(i));
/* 130:    */     }
/* 131:172 */     return values;
/* 132:    */   }
/* 133:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.persist.QBEData
 * JD-Core Version:    0.7.0.1
 */