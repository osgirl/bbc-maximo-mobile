package com.mro.mobile.persist;

public abstract interface RDOKey
{
  public abstract String[] getKeyValues();
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.persist.RDOKey
 * JD-Core Version:    0.7.0.1
 */