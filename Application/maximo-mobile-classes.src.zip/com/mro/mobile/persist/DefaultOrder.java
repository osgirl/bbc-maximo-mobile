/*  1:   */ package com.mro.mobile.persist;
/*  2:   */ 
/*  3:   */ import java.util.Enumeration;
/*  4:   */ import java.util.Hashtable;
/*  5:   */ import java.util.Vector;
/*  6:   */ 
/*  7:   */ public class DefaultOrder
/*  8:   */   implements Order
/*  9:   */ {
/* 10:22 */   private Hashtable attributeOrder = new Hashtable();
/* 11:23 */   private Vector attributes = new Vector();
/* 12:   */   
/* 13:   */   public void setOrder(String attributeName, boolean ascending)
/* 14:   */   {
/* 15:27 */     Object obj = this.attributeOrder.get(attributeName);
/* 16:   */     
/* 17:29 */     this.attributeOrder.put(attributeName, Boolean.valueOf(ascending));
/* 18:30 */     if (obj == null) {
/* 19:32 */       this.attributes.addElement(attributeName);
/* 20:   */     }
/* 21:   */   }
/* 22:   */   
/* 23:   */   public void setOrderFirst(String attributeName, boolean ascending)
/* 24:   */   {
/* 25:38 */     Object obj = this.attributeOrder.get(attributeName);
/* 26:   */     
/* 27:40 */     this.attributeOrder.put(attributeName, Boolean.valueOf(ascending));
/* 28:41 */     if (obj == null) {
/* 29:43 */       this.attributes.insertElementAt(attributeName, 0);
/* 30:   */     }
/* 31:   */   }
/* 32:   */   
/* 33:   */   public boolean getOrder(String attributeName)
/* 34:   */     throws RDOException
/* 35:   */   {
/* 36:50 */     Object obj = this.attributeOrder.get(attributeName);
/* 37:51 */     if (obj == null) {
/* 38:53 */       throw new RDOException("noattributeorder");
/* 39:   */     }
/* 40:56 */     Boolean order = (Boolean)obj;
/* 41:57 */     return order.booleanValue();
/* 42:   */   }
/* 43:   */   
/* 44:   */   public void resetOrder(String attributeName)
/* 45:   */   {
/* 46:62 */     this.attributeOrder.remove(attributeName);
/* 47:63 */     int size = this.attributes.size();
/* 48:64 */     for (int i = 0; i < size; i++)
/* 49:   */     {
/* 50:66 */       String attr = (String)this.attributes.elementAt(i);
/* 51:67 */       if (attr.equals(attributeName))
/* 52:   */       {
/* 53:69 */         this.attributes.removeElementAt(i);
/* 54:70 */         break;
/* 55:   */       }
/* 56:   */     }
/* 57:   */   }
/* 58:   */   
/* 59:   */   public Enumeration getOrderedAttributes()
/* 60:   */   {
/* 61:77 */     return this.attributes.elements();
/* 62:   */   }
/* 63:   */   
/* 64:   */   public void reset()
/* 65:   */   {
/* 66:82 */     this.attributeOrder = new Hashtable();
/* 67:83 */     this.attributes = new Vector();
/* 68:   */   }
/* 69:   */   
/* 70:   */   public int size()
/* 71:   */   {
/* 72:88 */     return this.attributeOrder.size();
/* 73:   */   }
/* 74:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.persist.DefaultOrder
 * JD-Core Version:    0.7.0.1
 */