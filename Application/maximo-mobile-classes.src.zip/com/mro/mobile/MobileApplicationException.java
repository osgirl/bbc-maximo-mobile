/*   1:    */ package com.mro.mobile;
/*   2:    */ 
/*   3:    */ import java.io.PrintStream;
/*   4:    */ 
/*   5:    */ public class MobileApplicationException
/*   6:    */   extends Exception
/*   7:    */ {
/*   8: 18 */   private Throwable nestedException = null;
/*   9: 19 */   private String key = null;
/*  10: 20 */   private Object[] params = null;
/*  11:    */   
/*  12:    */   public MobileApplicationException(String key)
/*  13:    */   {
/*  14: 24 */     this(key, null, null);
/*  15:    */   }
/*  16:    */   
/*  17:    */   public MobileApplicationException(Throwable t)
/*  18:    */   {
/*  19: 29 */     this(t.getMessage(), null, t);
/*  20:    */   }
/*  21:    */   
/*  22:    */   public MobileApplicationException(String key, Throwable t)
/*  23:    */   {
/*  24: 34 */     this(key, null, t);
/*  25:    */   }
/*  26:    */   
/*  27:    */   public MobileApplicationException(String key, Object[] params)
/*  28:    */   {
/*  29: 39 */     this(key, params, null);
/*  30:    */   }
/*  31:    */   
/*  32:    */   public MobileApplicationException(String key, Object[] params, Throwable t)
/*  33:    */   {
/*  34: 44 */     super(key);
/*  35:    */     
/*  36: 46 */     this.key = key;
/*  37: 47 */     this.params = params;
/*  38: 48 */     this.nestedException = t;
/*  39:    */   }
/*  40:    */   
/*  41:    */   public String getKey()
/*  42:    */   {
/*  43: 53 */     return this.key;
/*  44:    */   }
/*  45:    */   
/*  46:    */   public Object[] getParams()
/*  47:    */   {
/*  48: 58 */     return this.params;
/*  49:    */   }
/*  50:    */   
/*  51:    */   public Throwable getNestedException()
/*  52:    */   {
/*  53: 63 */     return this.nestedException;
/*  54:    */   }
/*  55:    */   
/*  56:    */   public String getMessage()
/*  57:    */   {
/*  58: 68 */     return this.key;
/*  59:    */   }
/*  60:    */   
/*  61:    */   public String getCompleteMessage()
/*  62:    */   {
/*  63: 73 */     if (this.key != null) {
/*  64: 75 */       return MobileMessageGenerator.generate(this.key, this.params);
/*  65:    */     }
/*  66: 77 */     if (this.nestedException != null)
/*  67:    */     {
/*  68: 79 */       String exMessage = this.nestedException.getMessage();
/*  69: 80 */       if ((exMessage == null) || (exMessage.trim().length() == 0)) {
/*  70: 82 */         return this.nestedException.getClass().getName();
/*  71:    */       }
/*  72: 86 */       return exMessage;
/*  73:    */     }
/*  74: 91 */     String exMessage = super.getMessage();
/*  75: 92 */     if ((exMessage == null) || (exMessage.trim().length() == 0)) {
/*  76: 94 */       return getClass().getName();
/*  77:    */     }
/*  78: 98 */     return exMessage;
/*  79:    */   }
/*  80:    */   
/*  81:    */   public void printStackTrace()
/*  82:    */   {
/*  83:106 */     super.printStackTrace();
/*  84:107 */     if (this.nestedException != null)
/*  85:    */     {
/*  86:109 */       System.err.print(" - nested exception: ");
/*  87:110 */       this.nestedException.printStackTrace();
/*  88:    */     }
/*  89:    */   }
/*  90:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.MobileApplicationException
 * JD-Core Version:    0.7.0.1
 */