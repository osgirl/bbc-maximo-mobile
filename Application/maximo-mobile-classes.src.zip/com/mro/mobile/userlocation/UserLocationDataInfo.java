/*   1:    */ package com.mro.mobile.userlocation;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.util.MobileLogger;
/*   4:    */ import com.mro.mobile.util.MobileLoggerFactory;
/*   5:    */ import java.io.ByteArrayInputStream;
/*   6:    */ import java.io.ByteArrayOutputStream;
/*   7:    */ import java.io.IOException;
/*   8:    */ import java.io.ObjectInputStream;
/*   9:    */ import java.io.ObjectOutputStream;
/*  10:    */ import java.util.Date;
/*  11:    */ 
/*  12:    */ public class UserLocationDataInfo
/*  13:    */ {
/*  14: 32 */   private static MobileLogger SERIALIZATION_LOGGER = MobileLoggerFactory.getLogger("maximo.mobile.serialization");
/*  15:    */   private long collectedWhen;
/*  16:    */   private double speed;
/*  17:    */   private double heading;
/*  18:    */   private double latitudeY;
/*  19:    */   private double longitudeX;
/*  20:    */   private double locationAccuracy;
/*  21:    */   private double altitudeAccuracy;
/*  22:    */   private double altitude;
/*  23:    */   
/*  24:    */   public UserLocationDataInfo(double latitudeY, double longitudeX, double locationAccuracy, double altitude, double altitudeAccuracy, double heading, double speed, long collectedWhen)
/*  25:    */   {
/*  26: 50 */     this.longitudeX = longitudeX;
/*  27: 51 */     this.latitudeY = latitudeY;
/*  28: 52 */     this.altitude = altitude;
/*  29: 53 */     this.altitudeAccuracy = altitudeAccuracy;
/*  30: 54 */     this.locationAccuracy = locationAccuracy;
/*  31: 55 */     this.heading = heading;
/*  32: 56 */     this.speed = speed;
/*  33: 57 */     this.collectedWhen = collectedWhen;
/*  34:    */   }
/*  35:    */   
/*  36:    */   public double getLatitudeY()
/*  37:    */   {
/*  38: 61 */     return this.latitudeY;
/*  39:    */   }
/*  40:    */   
/*  41:    */   public double getLongitudeX()
/*  42:    */   {
/*  43: 65 */     return this.longitudeX;
/*  44:    */   }
/*  45:    */   
/*  46:    */   public double getLocationAccuracy()
/*  47:    */   {
/*  48: 69 */     return this.locationAccuracy;
/*  49:    */   }
/*  50:    */   
/*  51:    */   public double getAltitudeAccuracy()
/*  52:    */   {
/*  53: 73 */     return this.altitudeAccuracy;
/*  54:    */   }
/*  55:    */   
/*  56:    */   public double getAltitude()
/*  57:    */   {
/*  58: 77 */     return this.altitude;
/*  59:    */   }
/*  60:    */   
/*  61:    */   public double getHeading()
/*  62:    */   {
/*  63: 81 */     return this.heading;
/*  64:    */   }
/*  65:    */   
/*  66:    */   public double getSpeed()
/*  67:    */   {
/*  68: 85 */     return this.speed;
/*  69:    */   }
/*  70:    */   
/*  71:    */   public long getCollectedWhen()
/*  72:    */   {
/*  73: 89 */     return this.collectedWhen;
/*  74:    */   }
/*  75:    */   
/*  76:    */   public Date getCollectedWhenAsDate()
/*  77:    */   {
/*  78: 93 */     return new Date(this.collectedWhen);
/*  79:    */   }
/*  80:    */   
/*  81:    */   public static UserLocationDataInfo fromBytes(byte[] encodedInfo)
/*  82:    */   {
/*  83:102 */     boolean infoEnabled = SERIALIZATION_LOGGER.isInfoEnabled();
/*  84:103 */     if (infoEnabled) {
/*  85:104 */       SERIALIZATION_LOGGER.info("Decoding GPSUSerLocationDataInfo");
/*  86:    */     }
/*  87:106 */     if (encodedInfo == null)
/*  88:    */     {
/*  89:107 */       SERIALIZATION_LOGGER.info("encodedInfo is null");
/*  90:108 */       return null;
/*  91:    */     }
/*  92:110 */     ByteArrayInputStream bais = null;
/*  93:111 */     ObjectInputStream ois = null;
/*  94:    */     try
/*  95:    */     {
/*  96:113 */       bais = new ByteArrayInputStream(encodedInfo);
/*  97:114 */       ois = new ObjectInputStream(bais);
/*  98:115 */       double latitudeY = ois.readDouble();
/*  99:116 */       if (infoEnabled) {
/* 100:117 */         SERIALIZATION_LOGGER.info("GPSUSerLocationDataInfo read latitudeY, type DOUBLE, value = " + latitudeY);
/* 101:    */       }
/* 102:119 */       double longitudeX = ois.readDouble();
/* 103:120 */       if (infoEnabled) {
/* 104:121 */         SERIALIZATION_LOGGER.info("GPSUSerLocationDataInfo read longitudeX, type DOUBLE, value = " + longitudeX);
/* 105:    */       }
/* 106:123 */       double locationAccuracy = ois.readDouble();
/* 107:124 */       if (infoEnabled) {
/* 108:125 */         SERIALIZATION_LOGGER.info("GPSUSerLocationDataInfo read locationAccuracy, type DOUBLE, value = " + locationAccuracy);
/* 109:    */       }
/* 110:127 */       double altitude = ois.readDouble();
/* 111:128 */       if (infoEnabled) {
/* 112:129 */         SERIALIZATION_LOGGER.info("GPSUSerLocationDataInfo read altitude, type DOUBLE, value = " + altitude);
/* 113:    */       }
/* 114:131 */       double altitudeAccuracy = ois.readDouble();
/* 115:132 */       if (infoEnabled) {
/* 116:133 */         SERIALIZATION_LOGGER.info("GPSUSerLocationDataInfo read altitudeAccuracy, type DOUBLE, value = " + altitudeAccuracy);
/* 117:    */       }
/* 118:135 */       double heading = ois.readDouble();
/* 119:136 */       if (infoEnabled) {
/* 120:137 */         SERIALIZATION_LOGGER.info("GPSUSerLocationDataInfo read heading, type DOUBLE, value = " + heading);
/* 121:    */       }
/* 122:139 */       double speed = ois.readDouble();
/* 123:140 */       if (infoEnabled) {
/* 124:141 */         SERIALIZATION_LOGGER.info("GPSUSerLocationDataInfo read speed, type DOUBLE, value = " + speed);
/* 125:    */       }
/* 126:143 */       long date = ois.readLong();
/* 127:144 */       if (infoEnabled) {
/* 128:145 */         SERIALIZATION_LOGGER.info("GPSUSerLocationDataInfo read collectedWhen, type DATETIME, value = " + date);
/* 129:    */       }
/* 130:147 */       return new UserLocationDataInfo(latitudeY, longitudeX, locationAccuracy, altitude, altitudeAccuracy, heading, speed, date);
/* 131:    */     }
/* 132:    */     catch (Exception e)
/* 133:    */     {
/* 134:149 */       SERIALIZATION_LOGGER.error("Error decoding GPSUserLocationDataInfo: " + e.getMessage(), e);
/* 135:    */     }
/* 136:    */     finally
/* 137:    */     {
/* 138:151 */       if (bais != null) {
/* 139:    */         try
/* 140:    */         {
/* 141:153 */           bais.close();
/* 142:    */         }
/* 143:    */         catch (IOException e) {}
/* 144:    */       }
/* 145:156 */       if (ois != null) {
/* 146:    */         try
/* 147:    */         {
/* 148:158 */           ois.close();
/* 149:    */         }
/* 150:    */         catch (IOException e) {}
/* 151:    */       }
/* 152:    */     }
/* 153:162 */     return null;
/* 154:    */   }
/* 155:    */   
/* 156:    */   public static byte[] toBytes(UserLocationDataInfo locationInfo)
/* 157:    */   {
/* 158:171 */     boolean infoEnabled = SERIALIZATION_LOGGER.isInfoEnabled();
/* 159:172 */     if (infoEnabled) {
/* 160:173 */       SERIALIZATION_LOGGER.info("Encoding GPSUSerLocationDataInfo");
/* 161:    */     }
/* 162:175 */     if (locationInfo == null)
/* 163:    */     {
/* 164:176 */       SERIALIZATION_LOGGER.info("locationInfo is null");
/* 165:177 */       return null;
/* 166:    */     }
/* 167:179 */     ByteArrayOutputStream baos = null;
/* 168:180 */     ObjectOutputStream oos = null;
/* 169:    */     try
/* 170:    */     {
/* 171:182 */       baos = new ByteArrayOutputStream();
/* 172:183 */       oos = new ObjectOutputStream(baos);
/* 173:184 */       double latitudeY = locationInfo.latitudeY;
/* 174:185 */       oos.writeDouble(latitudeY);
/* 175:186 */       if (infoEnabled) {
/* 176:187 */         SERIALIZATION_LOGGER.info("GPSUSerLocationDataInfo wrote latitudeY, type DOUBLE, value = " + latitudeY);
/* 177:    */       }
/* 178:189 */       double longitudeX = locationInfo.longitudeX;
/* 179:190 */       oos.writeDouble(longitudeX);
/* 180:191 */       if (infoEnabled) {
/* 181:192 */         SERIALIZATION_LOGGER.info("GPSUSerLocationDataInfo wrote longitudeX, type DOUBLE, value = " + longitudeX);
/* 182:    */       }
/* 183:194 */       double locationAccuracy = locationInfo.locationAccuracy;
/* 184:195 */       oos.writeDouble(locationAccuracy);
/* 185:196 */       if (infoEnabled) {
/* 186:197 */         SERIALIZATION_LOGGER.info("GPSUSerLocationDataInfo wrote locationAccuracy, type DOUBLE, value = " + locationAccuracy);
/* 187:    */       }
/* 188:199 */       double altitude = locationInfo.altitude;
/* 189:200 */       oos.writeDouble(altitude);
/* 190:201 */       if (infoEnabled) {
/* 191:202 */         SERIALIZATION_LOGGER.info("GPSUSerLocationDataInfo wrote altitude, type DOUBLE, value = " + altitude);
/* 192:    */       }
/* 193:204 */       double altitudeAccuracy = locationInfo.altitudeAccuracy;
/* 194:205 */       oos.writeDouble(altitudeAccuracy);
/* 195:206 */       if (infoEnabled) {
/* 196:207 */         SERIALIZATION_LOGGER.info("GPSUSerLocationDataInfo wrote altitudeAccuracy, type DOUBLE, value = " + altitudeAccuracy);
/* 197:    */       }
/* 198:209 */       double heading = locationInfo.heading;
/* 199:210 */       oos.writeDouble(heading);
/* 200:211 */       if (infoEnabled) {
/* 201:212 */         SERIALIZATION_LOGGER.info("GPSUSerLocationDataInfo wrote heading, type DOUBLE, value = " + heading);
/* 202:    */       }
/* 203:214 */       double speed = locationInfo.speed;
/* 204:215 */       oos.writeDouble(speed);
/* 205:216 */       if (infoEnabled) {
/* 206:217 */         SERIALIZATION_LOGGER.info("GPSUSerLocationDataInfo wrote speed, type DOUBLE, value = " + speed);
/* 207:    */       }
/* 208:219 */       long date = locationInfo.collectedWhen;
/* 209:220 */       oos.writeLong(date);
/* 210:221 */       if (infoEnabled) {
/* 211:222 */         SERIALIZATION_LOGGER.info("GPSUSerLocationDataInfo wrote collectedWhen, type DATETIME, value = " + date);
/* 212:    */       }
/* 213:224 */       oos.flush();
/* 214:225 */       baos.flush();
/* 215:226 */       return baos.toByteArray();
/* 216:    */     }
/* 217:    */     catch (Exception e)
/* 218:    */     {
/* 219:228 */       SERIALIZATION_LOGGER.error("Error encoding GPSUserLocationDataInfo: " + e.getMessage(), e);
/* 220:    */     }
/* 221:    */     finally
/* 222:    */     {
/* 223:230 */       if (baos != null) {
/* 224:    */         try
/* 225:    */         {
/* 226:232 */           baos.close();
/* 227:    */         }
/* 228:    */         catch (IOException e) {}
/* 229:    */       }
/* 230:235 */       if (oos != null) {
/* 231:    */         try
/* 232:    */         {
/* 233:237 */           oos.close();
/* 234:    */         }
/* 235:    */         catch (IOException e) {}
/* 236:    */       }
/* 237:    */     }
/* 238:241 */     return null;
/* 239:    */   }
/* 240:    */   
/* 241:    */   public String toString()
/* 242:    */   {
/* 243:246 */     StringBuffer builder = new StringBuffer();
/* 244:247 */     builder.append("longitude: ");
/* 245:248 */     builder.append(this.longitudeX);
/* 246:249 */     builder.append(", latitude: ");
/* 247:250 */     builder.append(this.latitudeY);
/* 248:251 */     builder.append(", location accuracy: ");
/* 249:252 */     builder.append(this.locationAccuracy);
/* 250:253 */     builder.append(", altitude: ");
/* 251:254 */     builder.append(this.altitude);
/* 252:255 */     builder.append(", altitude accuracy: ");
/* 253:256 */     builder.append(this.altitudeAccuracy);
/* 254:257 */     builder.append(", speed: ");
/* 255:258 */     builder.append(this.speed);
/* 256:259 */     builder.append(", heading: ");
/* 257:260 */     builder.append(this.heading);
/* 258:261 */     builder.append(", collectedWhen: ");
/* 259:262 */     builder.append(this.collectedWhen);
/* 260:263 */     builder.append(" [" + new Date(this.collectedWhen) + "]");
/* 261:264 */     return builder.toString();
/* 262:    */   }
/* 263:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.userlocation.UserLocationDataInfo
 * JD-Core Version:    0.7.0.1
 */