/*   1:    */ package com.mro.mobile;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.app.AbstractMobileDeviceApplication;
/*   4:    */ import com.mro.mobile.app.MobileDeviceAppSession;
/*   5:    */ import java.util.ArrayList;
/*   6:    */ import java.util.Iterator;
/*   7:    */ import java.util.List;
/*   8:    */ 
/*   9:    */ public class DefaultMobileDeviceMessageGenerator
/*  10:    */   extends MobileMessageGenerator
/*  11:    */ {
/*  12:    */   public String generateMessage(String key, Object[] params)
/*  13:    */   {
/*  14: 37 */     MobileMessageInfo messageInfo = getMessageInfo(key);
/*  15: 39 */     if (messageInfo == null) {
/*  16: 41 */       return MobileMessageGenerator.generateSimpleMessage(key, params);
/*  17:    */     }
/*  18: 44 */     String message = messageInfo.getMessage();
/*  19: 46 */     if ((params == null) || (params.length == 0)) {
/*  20: 48 */       return message;
/*  21:    */     }
/*  22: 51 */     return substituteParams(message, params);
/*  23:    */   }
/*  24:    */   
/*  25:    */   private MobileMessageInfo getMessageInfo(String key)
/*  26:    */   {
/*  27: 63 */     MobileDeviceAppSession deviceAppSession = MobileDeviceAppSession.getSession();
/*  28: 64 */     MobileMetaData metaData = deviceAppSession.getMobileMetadata();
/*  29:    */     
/*  30: 66 */     AbstractMobileDeviceApplication app = null;
/*  31:    */     
/*  32: 68 */     app = deviceAppSession.getApplicationAsUIApplication();
/*  33:    */     
/*  34: 70 */     String language = app.getProperty("maximo.mobile.packagelanguage");
/*  35:    */     
/*  36: 72 */     MobileMessageInfo messageInfo = null;
/*  37: 74 */     if ((language == null) || (language.equals("")) || (language.equalsIgnoreCase("en")))
/*  38:    */     {
/*  39: 79 */       messageInfo = metaData.getMobileMessageInfo(key);
/*  40: 80 */       if (messageInfo == null) {
/*  41: 82 */         return null;
/*  42:    */       }
/*  43:    */     }
/*  44:    */     else
/*  45:    */     {
/*  46: 87 */       StringBuffer sb = new StringBuffer();
/*  47: 88 */       String localeKey = key + "_" + language.toLowerCase();
/*  48:    */       
/*  49: 90 */       messageInfo = metaData.getMobileMessageInfo(localeKey);
/*  50: 91 */       if (messageInfo == null)
/*  51:    */       {
/*  52: 93 */         messageInfo = metaData.getMobileMessageInfo(key);
/*  53: 94 */         if (messageInfo == null) {
/*  54: 96 */           return null;
/*  55:    */         }
/*  56:    */       }
/*  57:    */     }
/*  58:100 */     return messageInfo;
/*  59:    */   }
/*  60:    */   
/*  61:    */   public String substituteParams(String message, Object[] params)
/*  62:    */   {
/*  63:113 */     int paramIndex = 0;
/*  64:115 */     while (paramIndex < params.length)
/*  65:    */     {
/*  66:117 */       String substituteParam = "{" + paramIndex + "}";
/*  67:118 */       int index = message.indexOf(substituteParam);
/*  68:119 */       while (index > -1)
/*  69:    */       {
/*  70:121 */         StringBuffer tempMessage = new StringBuffer();
/*  71:122 */         tempMessage.append(message.substring(0, index));
/*  72:123 */         tempMessage.append(params[paramIndex]);
/*  73:124 */         tempMessage.append(message.substring(index + substituteParam.length()));
/*  74:125 */         message = tempMessage.toString();
/*  75:126 */         index = message.indexOf(substituteParam);
/*  76:    */       }
/*  77:128 */       paramIndex++;
/*  78:    */     }
/*  79:131 */     return message;
/*  80:    */   }
/*  81:    */   
/*  82:    */   public boolean isStringPattern(String message, String key)
/*  83:    */   {
/*  84:136 */     MobileMessageInfo messageInfo = getMessageInfo(key);
/*  85:137 */     if (messageInfo == null) {
/*  86:139 */       return false;
/*  87:    */     }
/*  88:141 */     String pattern = messageInfo.getMessage();
/*  89:    */     
/*  90:143 */     int paramIndex = 0;
/*  91:144 */     String substituteParam = "{" + paramIndex + "}";
/*  92:145 */     int strIndex = 0;int occrPosition = 0;
/*  93:146 */     List patterns = new ArrayList();
/*  94:147 */     while ((occrPosition = pattern.indexOf(substituteParam, strIndex)) >= 0)
/*  95:    */     {
/*  96:148 */       if (occrPosition > strIndex) {
/*  97:149 */         patterns.add(pattern.substring(strIndex, occrPosition));
/*  98:    */       }
/*  99:151 */       strIndex = occrPosition + substituteParam.length();
/* 100:    */     }
/* 101:154 */     if (strIndex < pattern.length()) {
/* 102:155 */       patterns.add(pattern.substring(strIndex));
/* 103:    */     }
/* 104:158 */     Iterator it = patterns.iterator();
/* 105:159 */     String strResult = message;
/* 106:160 */     int indexOccurence = 0;
/* 107:161 */     while (it.hasNext())
/* 108:    */     {
/* 109:162 */       String strOccurence = (String)it.next();
/* 110:163 */       if ((indexOccurence = strResult.indexOf(strOccurence, indexOccurence)) < 0) {
/* 111:164 */         return false;
/* 112:    */       }
/* 113:    */     }
/* 114:167 */     return true;
/* 115:    */   }
/* 116:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.DefaultMobileDeviceMessageGenerator
 * JD-Core Version:    0.7.0.1
 */