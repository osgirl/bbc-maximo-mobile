package com.mro.mobile;

public abstract interface ProgressObserver
{
  public abstract boolean isWorkStopped();
  
  public abstract void updateWorkProgress();
  
  public abstract void setWorkProgressMessage(String paramString);
  
  public abstract ProgressWindow getProgressWindow();
  
  public abstract void setBackgroundThread(Thread paramThread);
  
  public abstract Thread getBackgroundThread();
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ProgressObserver
 * JD-Core Version:    0.7.0.1
 */