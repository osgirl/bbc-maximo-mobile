/*   1:    */ package com.mro.mobile.type;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.util.MobileLogger;
/*   4:    */ import com.mro.mobile.util.MobileLoggerFactory;
/*   5:    */ import java.io.DataInput;
/*   6:    */ import java.io.DataOutput;
/*   7:    */ import java.io.IOException;
/*   8:    */ import java.util.Date;
/*   9:    */ import java.util.Hashtable;
/*  10:    */ 
/*  11:    */ public class TypeRegistry
/*  12:    */ {
/*  13: 28 */   private static MobileLogger SERIALIZATION_LOGGER = MobileLoggerFactory.getLogger("maximo.mobile.serialization");
/*  14: 30 */   private Hashtable nameToClassMap = new Hashtable();
/*  15: 31 */   private Hashtable classToNameMap = new Hashtable();
/*  16: 33 */   private static final TypeRegistry typeRegistry = new TypeRegistry();
/*  17:    */   
/*  18:    */   private TypeRegistry()
/*  19:    */   {
/*  20: 38 */     BasicTypesSerializer basicSerializer = new BasicTypesSerializer();
/*  21: 39 */     addType("int", Integer.class, basicSerializer);
/*  22: 40 */     addType("long", Long.class, basicSerializer);
/*  23: 41 */     addType("boolean", Boolean.class, basicSerializer);
/*  24:    */     
/*  25: 43 */     addType("Integer", Integer.class, basicSerializer);
/*  26: 44 */     addType("Long", Long.class, basicSerializer);
/*  27: 45 */     addType("Boolean", Boolean.class, basicSerializer);
/*  28: 46 */     addType("String", String.class, basicSerializer);
/*  29: 47 */     addType("Date", Date.class, basicSerializer);
/*  30:    */     
/*  31: 49 */     addType("Object[]", [Ljava.lang.Object.class, basicSerializer);
/*  32: 50 */     addType("String[]", [Ljava.lang.String.class, basicSerializer);
/*  33: 51 */     addType("byte[]", [B.class, basicSerializer);
/*  34:    */   }
/*  35:    */   
/*  36:    */   public static TypeRegistry getTypeRegistry()
/*  37:    */   {
/*  38: 56 */     return typeRegistry;
/*  39:    */   }
/*  40:    */   
/*  41:    */   public void addType(String name, Class typeClass, Serializer serializer)
/*  42:    */   {
/*  43: 61 */     boolean infoEnabled = SERIALIZATION_LOGGER.isInfoEnabled();
/*  44: 63 */     if (infoEnabled) {
/*  45: 65 */       SERIALIZATION_LOGGER.info("TypeRegistry registering type " + name);
/*  46:    */     }
/*  47: 68 */     if (serializer == null) {
/*  48: 70 */       this.nameToClassMap.put(name, typeClass);
/*  49:    */     } else {
/*  50: 74 */       this.nameToClassMap.put(name, serializer);
/*  51:    */     }
/*  52: 77 */     this.classToNameMap.put(typeClass.getName(), new Object[] { name, serializer });
/*  53:    */   }
/*  54:    */   
/*  55:    */   public String getTypeInfo(Object object)
/*  56:    */   {
/*  57: 82 */     Object[] info = (Object[])this.classToNameMap.get(object.getClass().getName());
/*  58:    */     
/*  59: 84 */     String typeName = (String)info[0];
/*  60:    */     
/*  61: 86 */     return typeName;
/*  62:    */   }
/*  63:    */   
/*  64:    */   public Object readInstance(DataInput input, String name)
/*  65:    */     throws IOException
/*  66:    */   {
/*  67: 92 */     boolean infoEnabled = SERIALIZATION_LOGGER.isInfoEnabled();
/*  68: 94 */     if (name.equals("NULL"))
/*  69:    */     {
/*  70: 96 */       if (infoEnabled) {
/*  71: 98 */         SERIALIZATION_LOGGER.info("TypeRegistry Reading Type = NULL");
/*  72:    */       }
/*  73:101 */       return null;
/*  74:    */     }
/*  75:104 */     Object objectClass = this.nameToClassMap.get(name);
/*  76:107 */     if (objectClass == null)
/*  77:    */     {
/*  78:    */       try
/*  79:    */       {
/*  80:112 */         objectClass = Class.forName(name);
/*  81:    */       }
/*  82:    */       catch (ClassNotFoundException e) {}
/*  83:118 */       if (objectClass == null) {
/*  84:120 */         throw new RuntimeException("TypeRegistry cannot read state for type: " + name);
/*  85:    */       }
/*  86:    */     }
/*  87:124 */     if ((objectClass instanceof Serializer))
/*  88:    */     {
/*  89:126 */       if (infoEnabled) {
/*  90:128 */         SERIALIZATION_LOGGER.info("TypeRegistry using Serializer to Read Type = " + objectClass);
/*  91:    */       }
/*  92:131 */       return ((Serializer)objectClass).readInstance(input, name);
/*  93:    */     }
/*  94:135 */     Object obj = null;
/*  95:    */     try
/*  96:    */     {
/*  97:139 */       obj = ((Class)objectClass).newInstance();
/*  98:    */     }
/*  99:    */     catch (Exception e)
/* 100:    */     {
/* 101:143 */       throw new RuntimeException("TypeRegistry failed to instantiate..." + name);
/* 102:    */     }
/* 103:146 */     if ((obj instanceof MSerializable))
/* 104:    */     {
/* 105:148 */       if (infoEnabled) {
/* 106:150 */         SERIALIZATION_LOGGER.info("TypeRegistry using MSerializer to Read Type = " + objectClass);
/* 107:    */       }
/* 108:153 */       MSerializable mobj = (MSerializable)obj;
/* 109:154 */       mobj.readState(input);
/* 110:    */       
/* 111:156 */       return obj;
/* 112:    */     }
/* 113:160 */     throw new RuntimeException("TypeRegistry cannot read state for type: " + name);
/* 114:    */   }
/* 115:    */   
/* 116:    */   public void writeInstance(DataOutput output, Object instance)
/* 117:    */     throws IOException
/* 118:    */   {
/* 119:168 */     boolean infoEnabled = SERIALIZATION_LOGGER.isInfoEnabled();
/* 120:170 */     if (instance == null)
/* 121:    */     {
/* 122:172 */       if (infoEnabled) {
/* 123:174 */         SERIALIZATION_LOGGER.info("TypeRegistry Writing type NULL");
/* 124:    */       }
/* 125:177 */       output.writeUTF("NULL");
/* 126:178 */       return;
/* 127:    */     }
/* 128:181 */     Object[] info = (Object[])this.classToNameMap.get(instance.getClass().getName());
/* 129:182 */     if (info != null)
/* 130:    */     {
/* 131:184 */       String typeName = (String)info[0];
/* 132:185 */       Serializer serializer = (Serializer)info[1];
/* 133:187 */       if (infoEnabled) {
/* 134:189 */         SERIALIZATION_LOGGER.info("TypeRegistry Writing using Serializer for type = " + typeName);
/* 135:    */       }
/* 136:192 */       output.writeUTF(typeName);
/* 137:193 */       if (serializer != null) {
/* 138:195 */         serializer.writeInstance(output, instance);
/* 139:    */       } else {
/* 140:199 */         throw new RuntimeException("TypeRegistry cannot write state of " + typeName);
/* 141:    */       }
/* 142:    */     }
/* 143:202 */     else if ((instance instanceof MSerializable))
/* 144:    */     {
/* 145:204 */       String typeName = instance.getClass().getName();
/* 146:206 */       if (infoEnabled) {
/* 147:208 */         SERIALIZATION_LOGGER.info("TypeRegistry Writing using MSerializer for type = " + typeName);
/* 148:    */       }
/* 149:211 */       output.writeUTF(typeName);
/* 150:212 */       MSerializable mobj = (MSerializable)instance;
/* 151:213 */       mobj.writeState(output);
/* 152:    */     }
/* 153:    */     else
/* 154:    */     {
/* 155:217 */       throw new RuntimeException("TypeRegistry cannot write state of " + instance.getClass().getName());
/* 156:    */     }
/* 157:    */   }
/* 158:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.type.TypeRegistry
 * JD-Core Version:    0.7.0.1
 */