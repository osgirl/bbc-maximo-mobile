/*   1:    */ package com.mro.mobile.type;
/*   2:    */ 
/*   3:    */ import java.io.DataInput;
/*   4:    */ import java.io.DataOutput;
/*   5:    */ import java.io.IOException;
/*   6:    */ import java.util.Date;
/*   7:    */ 
/*   8:    */ public class BasicTypesSerializer
/*   9:    */   implements Serializer
/*  10:    */ {
/*  11:    */   public Object readInstance(DataInput input, String name)
/*  12:    */     throws IOException
/*  13:    */   {
/*  14: 26 */     if ((name.equals("int")) || (name.equals("Integer"))) {
/*  15: 28 */       return new Integer(input.readInt());
/*  16:    */     }
/*  17: 30 */     if ((name.equals("long")) || (name.equals("Long"))) {
/*  18: 32 */       return new Long(input.readLong());
/*  19:    */     }
/*  20: 34 */     if (name.equals("String")) {
/*  21: 36 */       return input.readUTF();
/*  22:    */     }
/*  23: 38 */     if ((name.equals("boolean")) || (name.equals("Boolean"))) {
/*  24: 41 */       return Boolean.valueOf(input.readBoolean());
/*  25:    */     }
/*  26: 43 */     if (name.equals("Date"))
/*  27:    */     {
/*  28: 45 */       long timeInMillis = input.readLong();
/*  29: 46 */       return new Date(timeInMillis);
/*  30:    */     }
/*  31: 48 */     if (name.equals("Object[]"))
/*  32:    */     {
/*  33: 50 */       int arraySize = input.readInt();
/*  34: 51 */       Object[] array = new Object[arraySize];
/*  35: 52 */       for (int i = 0; i < arraySize; i++)
/*  36:    */       {
/*  37: 54 */         String arrayElementType = input.readUTF();
/*  38: 55 */         if ((arrayElementType != null) && (arrayElementType.equals("NULL"))) {
/*  39: 57 */           array[i] = null;
/*  40:    */         } else {
/*  41: 62 */           array[i] = TypeRegistry.getTypeRegistry().readInstance(input, arrayElementType);
/*  42:    */         }
/*  43:    */       }
/*  44: 65 */       return array;
/*  45:    */     }
/*  46: 67 */     if (name.equals("String[]"))
/*  47:    */     {
/*  48: 69 */       int arraySize = input.readInt();
/*  49: 70 */       String[] array = new String[arraySize];
/*  50: 71 */       for (int i = 0; i < arraySize; i++)
/*  51:    */       {
/*  52: 73 */         String arrayElementType = input.readUTF();
/*  53: 74 */         if ((arrayElementType != null) && (arrayElementType.equals("NULL"))) {
/*  54: 76 */           array[i] = null;
/*  55:    */         } else {
/*  56: 80 */           array[i] = ((String)readInstance(input, arrayElementType));
/*  57:    */         }
/*  58:    */       }
/*  59: 83 */       return array;
/*  60:    */     }
/*  61: 85 */     if (name.equals("byte[]"))
/*  62:    */     {
/*  63: 87 */       int arraySize = input.readInt();
/*  64: 88 */       byte[] array = new byte[arraySize];
/*  65: 89 */       input.readFully(array);
/*  66: 90 */       return array;
/*  67:    */     }
/*  68: 94 */     throw new RuntimeException("The type " + name + " not supported.");
/*  69:    */   }
/*  70:    */   
/*  71:    */   public void writeInstance(DataOutput output, Object object)
/*  72:    */     throws IOException
/*  73:    */   {
/*  74:100 */     if ((object instanceof Integer))
/*  75:    */     {
/*  76:102 */       output.writeInt(((Integer)object).intValue());
/*  77:    */     }
/*  78:104 */     else if ((object instanceof Long))
/*  79:    */     {
/*  80:106 */       output.writeLong(((Long)object).longValue());
/*  81:    */     }
/*  82:108 */     else if ((object instanceof Boolean))
/*  83:    */     {
/*  84:110 */       output.writeBoolean(((Boolean)object).booleanValue());
/*  85:    */     }
/*  86:112 */     else if ((object instanceof String))
/*  87:    */     {
/*  88:114 */       output.writeUTF((String)object);
/*  89:    */     }
/*  90:116 */     else if ((object instanceof Date))
/*  91:    */     {
/*  92:118 */       output.writeLong(((Date)object).getTime());
/*  93:    */     }
/*  94:120 */     else if ((object instanceof byte[]))
/*  95:    */     {
/*  96:122 */       byte[] array = (byte[])object;
/*  97:    */       
/*  98:124 */       output.writeInt(array.length);
/*  99:125 */       output.write(array);
/* 100:    */     }
/* 101:127 */     else if (object.getClass().isArray())
/* 102:    */     {
/* 103:129 */       Object[] array = (Object[])object;
/* 104:    */       
/* 105:131 */       output.writeInt(array.length);
/* 106:132 */       for (int i = 0; i < array.length; i++) {
/* 107:136 */         TypeRegistry.getTypeRegistry().writeInstance(output, array[i]);
/* 108:    */       }
/* 109:    */     }
/* 110:    */     else
/* 111:    */     {
/* 112:141 */       output.writeUTF(object.toString());
/* 113:    */     }
/* 114:    */   }
/* 115:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.type.BasicTypesSerializer
 * JD-Core Version:    0.7.0.1
 */