package com.mro.mobile.type;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

public abstract interface MSerializable
{
  public abstract void readState(DataInput paramDataInput)
    throws IOException;
  
  public abstract void writeState(DataOutput paramDataOutput)
    throws IOException;
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.type.MSerializable
 * JD-Core Version:    0.7.0.1
 */