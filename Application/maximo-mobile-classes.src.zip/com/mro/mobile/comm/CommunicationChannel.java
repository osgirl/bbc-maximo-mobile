package com.mro.mobile.comm;

import com.mro.mobile.MobileApplicationException;

public abstract interface CommunicationChannel
{
  public static final String APPNAME_PROPERTY = "APPNAME";
  public static final String USERNAME_PROPERTY = "USERNAME";
  public static final String PASSWORD_PROPERTY = "PASSWORD";
  public static final String HOSTNAME_PROPERTY = "maximo.mobile.hostname";
  public static final String PORT_PROPERTY = "maximo.mobile.port";
  public static final String CONTEXTNAME_PROPERTY = "maximo.mobile.contextname";
  public static final String SECURE_PROPERTY = "maximo.mobile.ssl";
  public static final String COUNTRY_PROPERTY = "COUNTRY";
  public static final String LANGUAGE_PROPERTY = "LANGUAGE";
  public static final String VARIANT_PROPERTY = "VARIANT";
  public static final String TIMEZONE_PROPERTY = "TIMEZONE";
  
  public abstract void setProperty(String paramString1, String paramString2)
    throws MobileApplicationException;
  
  public abstract ResponsePacket send(RequestPacket paramRequestPacket)
    throws MobileApplicationException;
  
  public abstract void reset();
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.comm.CommunicationChannel
 * JD-Core Version:    0.7.0.1
 */