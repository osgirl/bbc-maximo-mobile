/*  1:   */ package com.mro.mobile.comm;
/*  2:   */ 
/*  3:   */ import com.mro.mobile.MobileApplicationException;
/*  4:   */ 
/*  5:   */ public class InvocationException
/*  6:   */   extends MobileApplicationException
/*  7:   */ {
/*  8:   */   public InvocationException(String key)
/*  9:   */   {
/* 10:22 */     super(key);
/* 11:   */   }
/* 12:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.comm.InvocationException
 * JD-Core Version:    0.7.0.1
 */