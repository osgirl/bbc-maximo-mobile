/*   1:    */ package com.mro.mobile.comm;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.app.MobileDeviceAppSession;
/*   5:    */ import com.mro.mobile.type.TypeRegistry;
/*   6:    */ import com.mro.mobile.ui.MobileSafeRemoteInvoker;
/*   7:    */ import com.mro.mobile.util.Base64;
/*   8:    */ import com.mro.mobile.util.MobileLogger;
/*   9:    */ import com.mro.mobile.util.MobileLoggerFactory;
/*  10:    */ import com.mro.mobile.util.PlatformIndicator;
/*  11:    */ import java.io.BufferedInputStream;
/*  12:    */ import java.io.BufferedOutputStream;
/*  13:    */ import java.io.DataInputStream;
/*  14:    */ import java.io.DataOutputStream;
/*  15:    */ import java.io.IOException;
/*  16:    */ import java.io.InputStream;
/*  17:    */ import java.io.OutputStream;
/*  18:    */ import java.net.ConnectException;
/*  19:    */ import java.util.Enumeration;
/*  20:    */ import java.util.Hashtable;
/*  21:    */ 
/*  22:    */ public abstract class AbstractHTTPCommunicationChannel
/*  23:    */   implements CommunicationChannel
/*  24:    */ {
/*  25: 39 */   private static MobileLogger COMMLOGGER = MobileLoggerFactory.getLogger("maximo.mobile.communication");
/*  26: 41 */   private Hashtable properties = new Hashtable();
/*  27:    */   
/*  28:    */   public void setProperty(String propertyName, String value)
/*  29:    */     throws MobileApplicationException
/*  30:    */   {
/*  31: 46 */     this.properties.put(propertyName, value);
/*  32:    */   }
/*  33:    */   
/*  34:    */   public String getProperty(String propertyName)
/*  35:    */   {
/*  36: 51 */     return (String)this.properties.get(propertyName);
/*  37:    */   }
/*  38:    */   
/*  39:    */   public Enumeration getPropertyNames()
/*  40:    */   {
/*  41: 56 */     return this.properties.keys();
/*  42:    */   }
/*  43:    */   
/*  44:    */   protected String getURLString()
/*  45:    */   {
/*  46: 61 */     String hostName = getProperty("maximo.mobile.hostname");
/*  47: 62 */     String port = getProperty("maximo.mobile.port");
/*  48: 63 */     String contextName = getProperty("maximo.mobile.contextname");
/*  49: 64 */     String secure = getProperty("maximo.mobile.ssl");
/*  50: 65 */     String protocol = "http";
/*  51: 67 */     if (hostName == null) {
/*  52: 69 */       hostName = "localhost";
/*  53:    */     }
/*  54: 71 */     if (port == null) {
/*  55: 73 */       port = "7001";
/*  56:    */     }
/*  57: 75 */     if (contextName == null) {
/*  58: 77 */       contextName = "/maximomobile/mobileservice";
/*  59:    */     }
/*  60: 79 */     if (secure != null) {
/*  61: 81 */       if (secure.equals("true")) {
/*  62: 83 */         protocol = "https";
/*  63:    */       }
/*  64:    */     }
/*  65: 87 */     String appName = getProperty("APPNAME");
/*  66:    */     
/*  67: 89 */     String urlString = protocol + "://" + hostName + ":" + port + contextName + "/" + appName;
/*  68:    */     
/*  69: 91 */     boolean infoEnabled = COMMLOGGER.isInfoEnabled();
/*  70: 93 */     if (infoEnabled) {
/*  71: 95 */       COMMLOGGER.info("URL: " + urlString);
/*  72:    */     }
/*  73: 97 */     return urlString;
/*  74:    */   }
/*  75:    */   
/*  76:    */   protected abstract void openConnection()
/*  77:    */     throws IOException;
/*  78:    */   
/*  79:    */   protected abstract void openConnection(boolean paramBoolean)
/*  80:    */     throws IOException;
/*  81:    */   
/*  82:    */   protected abstract void closeConnection()
/*  83:    */     throws IOException;
/*  84:    */   
/*  85:    */   protected abstract OutputStream openOutputStream()
/*  86:    */     throws IOException;
/*  87:    */   
/*  88:    */   protected abstract InputStream openInputStream()
/*  89:    */     throws IOException;
/*  90:    */   
/*  91:    */   protected abstract int getResponseCode()
/*  92:    */     throws IOException;
/*  93:    */   
/*  94:    */   protected abstract long getContentLength();
/*  95:    */   
/*  96:    */   protected abstract String getHeaderField(String paramString)
/*  97:    */     throws IOException;
/*  98:    */   
/*  99:    */   protected abstract void setRequestProperty(String paramString1, String paramString2)
/* 100:    */     throws IOException;
/* 101:    */   
/* 102:    */   protected abstract boolean isCookieSet();
/* 103:    */   
/* 104:    */   protected abstract boolean isHTTPUnauthorized(int paramInt);
/* 105:    */   
/* 106:    */   protected abstract boolean isHTTPOK(int paramInt);
/* 107:    */   
/* 108:    */   private void closeStreams(OutputStream outputStream, InputStream inputStream)
/* 109:    */   {
/* 110:120 */     if (outputStream != null) {
/* 111:    */       try
/* 112:    */       {
/* 113:122 */         outputStream.close();
/* 114:    */       }
/* 115:    */       catch (IOException ioe) {}
/* 116:    */     }
/* 117:126 */     if (inputStream != null) {
/* 118:    */       try
/* 119:    */       {
/* 120:128 */         inputStream.close();
/* 121:    */       }
/* 122:    */       catch (IOException ioe) {}
/* 123:    */     }
/* 124:    */   }
/* 125:    */   
/* 126:    */   public ResponsePacket send(RequestPacket packet)
/* 127:    */     throws MobileApplicationException
/* 128:    */   {
/* 129:136 */     if (needSafeMode()) {
/* 130:137 */       return sendInSafeMode(packet);
/* 131:    */     }
/* 132:139 */     return sendInRegualrMode(packet);
/* 133:    */   }
/* 134:    */   
/* 135:    */   private boolean needSafeMode()
/* 136:    */   {
/* 137:143 */     if (PlatformIndicator.isWINDOWS()) {
/* 138:144 */       return false;
/* 139:    */     }
/* 140:146 */     if (PlatformIndicator.isANDROID())
/* 141:    */     {
/* 142:147 */       if (MobileDeviceAppSession.getSession().isBackgroudThread()) {
/* 143:148 */         return false;
/* 144:    */       }
/* 145:150 */       return true;
/* 146:    */     }
/* 147:152 */     return false;
/* 148:    */   }
/* 149:    */   
/* 150:    */   private ResponsePacket sendInRegualrMode(RequestPacket packet)
/* 151:    */     throws MobileApplicationException
/* 152:    */   {
/* 153:156 */     return realSend(packet);
/* 154:    */   }
/* 155:    */   
/* 156:    */   private ResponsePacket sendInSafeMode(final RequestPacket packet)
/* 157:    */     throws MobileApplicationException
/* 158:    */   {
/* 159:160 */     MobileSafeRemoteInvoker invoker = new MobileSafeRemoteInvoker()
/* 160:    */     {
/* 161:    */       public void remoteCall()
/* 162:    */         throws MobileApplicationException
/* 163:    */       {
/* 164:162 */         ResponsePacket response = AbstractHTTPCommunicationChannel.this.realSend(packet);
/* 165:163 */         setResult(response);
/* 166:    */       }
/* 167:165 */     };
/* 168:166 */     invoker.execute();
/* 169:167 */     if (invoker.isFailed()) {
/* 170:168 */       throw invoker.getMobileApplicationException();
/* 171:    */     }
/* 172:170 */     if (!invoker.isCompleted()) {
/* 173:171 */       throw new MobileApplicationException("commfailure");
/* 174:    */     }
/* 175:173 */     return (ResponsePacket)invoker.getResult();
/* 176:    */   }
/* 177:    */   
/* 178:    */   private ResponsePacket realSend(RequestPacket packet)
/* 179:    */     throws MobileApplicationException
/* 180:    */   {
/* 181:178 */     respPacket = null;
/* 182:    */     
/* 183:180 */     boolean infoEnabled = COMMLOGGER.isInfoEnabled();
/* 184:181 */     boolean sentAuthenticationDetails = false;
/* 185:    */     
/* 186:    */ 
/* 187:184 */     setRequestPacketHeaders(packet, false);
/* 188:185 */     int responseCode = -1;
/* 189:    */     try
/* 190:    */     {
/* 191:188 */       openConnection();
/* 192:190 */       if (!isCookieSet())
/* 193:    */       {
/* 194:192 */         setRequestPacketHeaders(packet, true);
/* 195:193 */         sentAuthenticationDetails = true;
/* 196:    */       }
/* 197:196 */       responseCode = writeRequestPacket(packet);
/* 198:197 */       if (isHTTPUnauthorized(responseCode)) {
/* 199:199 */         responseCode = handleHTTPBasicAuthentication(packet);
/* 200:    */       }
/* 201:201 */       if (infoEnabled) {
/* 202:203 */         COMMLOGGER.info("Response Code from server: " + responseCode);
/* 203:    */       }
/* 204:205 */       if (isHTTPOK(responseCode))
/* 205:    */       {
/* 206:207 */         respPacket = readResponsePacket();
/* 207:208 */         if (respPacket != null)
/* 208:    */         {
/* 209:210 */           if (infoEnabled) {
/* 210:212 */             COMMLOGGER.info("Response status from server: " + respPacket.getResponseStatus());
/* 211:    */           }
/* 212:215 */           if ((sentAuthenticationDetails) && (respPacket.getResponseStatus() == 1)) {
/* 213:218 */             throw new MobileApplicationException("authenticationfailure");
/* 214:    */           }
/* 215:222 */           if ((!sentAuthenticationDetails) && (respPacket.getResponseStatus() == 1))
/* 216:    */           {
/* 217:225 */             setRequestPacketHeaders(packet, true);
/* 218:    */             
/* 219:227 */             reopenConnection();
/* 220:229 */             if (infoEnabled) {
/* 221:231 */               COMMLOGGER.info("**** SENDING REQUEST WITH AUTH DETAILS....");
/* 222:    */             }
/* 223:233 */             responseCode = writeRequestPacket(packet);
/* 224:236 */             if (isHTTPUnauthorized(responseCode)) {
/* 225:238 */               responseCode = handleHTTPBasicAuthentication(packet);
/* 226:    */             }
/* 227:241 */             if (infoEnabled) {
/* 228:243 */               COMMLOGGER.info(" responseCode after MAXIMO Authorization = " + responseCode);
/* 229:    */             }
/* 230:245 */             if (!isHTTPOK(responseCode)) {
/* 231:247 */               throw new MobileApplicationException("authenticationfailure");
/* 232:    */             }
/* 233:250 */             respPacket = readResponsePacket();
/* 234:251 */             if (respPacket != null)
/* 235:    */             {
/* 236:253 */               if (infoEnabled) {
/* 237:255 */                 COMMLOGGER.info("**** Response status After authentication server: " + respPacket.getResponseStatus());
/* 238:    */               }
/* 239:258 */               if (respPacket.getResponseStatus() == 1) {
/* 240:260 */                 throw new MobileApplicationException("authenticationfailure");
/* 241:    */               }
/* 242:    */             }
/* 243:    */           }
/* 244:    */         }
/* 245:    */       }
/* 246:    */       else
/* 247:    */       {
/* 248:267 */         throw new MobileApplicationException("httpoperationfailed", new Object[] { new Integer(responseCode) });
/* 249:    */       }
/* 250:289 */       return respPacket;
/* 251:    */     }
/* 252:    */     catch (Exception ex)
/* 253:    */     {
/* 254:273 */       if (infoEnabled) {
/* 255:275 */         COMMLOGGER.error("Communication Failed ", ex);
/* 256:    */       }
/* 257:278 */       if ((ex instanceof MobileApplicationException)) {
/* 258:279 */         throw ((MobileApplicationException)ex);
/* 259:    */       }
/* 260:281 */       throw new MobileApplicationException("commfailure", new ConnectException());
/* 261:    */     }
/* 262:    */     finally
/* 263:    */     {
/* 264:    */       try
/* 265:    */       {
/* 266:286 */         closeConnection();
/* 267:    */       }
/* 268:    */       catch (Exception ex) {}
/* 269:    */     }
/* 270:    */   }
/* 271:    */   
/* 272:    */   protected void setRequestPacketHeaders(RequestPacket packet, boolean includeAuthDetails)
/* 273:    */   {
/* 274:294 */     String mobileId = getProperty("MOBILEID");
/* 275:295 */     String userName = getProperty("USERNAME");
/* 276:296 */     String password = getProperty("PASSWORD");
/* 277:297 */     String country = getProperty("COUNTRY");
/* 278:298 */     String language = getProperty("LANGUAGE");
/* 279:299 */     String variant = getProperty("VARIANT");
/* 280:300 */     String timeZone = getProperty("TIMEZONE");
/* 281:    */     
/* 282:302 */     Enumeration enumPropertyNames = getPropertyNames();
/* 283:303 */     if (includeAuthDetails) {
/* 284:305 */       while (enumPropertyNames.hasMoreElements())
/* 285:    */       {
/* 286:307 */         String propertyName = (String)enumPropertyNames.nextElement();
/* 287:308 */         packet.setHeaderField(propertyName, getProperty(propertyName));
/* 288:    */       }
/* 289:    */     }
/* 290:313 */     while (enumPropertyNames.hasMoreElements())
/* 291:    */     {
/* 292:315 */       String propertyName = (String)enumPropertyNames.nextElement();
/* 293:316 */       if (!propertyName.equals("PASSWORD")) {
/* 294:320 */         packet.setHeaderField(propertyName, getProperty(propertyName));
/* 295:    */       }
/* 296:    */     }
/* 297:    */   }
/* 298:    */   
/* 299:    */   private int handleHTTPBasicAuthentication(RequestPacket packet)
/* 300:    */     throws IOException, MobileApplicationException
/* 301:    */   {
/* 302:328 */     int responseCode = 0;
/* 303:    */     
/* 304:330 */     boolean infoEnabled = COMMLOGGER.isInfoEnabled();
/* 305:    */     
/* 306:332 */     String authenticationHeader = getHeaderField("WWW-Authenticate");
/* 307:334 */     if (infoEnabled)
/* 308:    */     {
/* 309:336 */       COMMLOGGER.info(" authenticationHeader = " + authenticationHeader);
/* 310:337 */       if (authenticationHeader == null) {
/* 311:339 */         COMMLOGGER.info(" Trying to see whether Basic authentication works anyway.");
/* 312:    */       }
/* 313:    */     }
/* 314:343 */     if ((authenticationHeader == null) || ((authenticationHeader != null) && (authenticationHeader.startsWith("Basic"))))
/* 315:    */     {
/* 316:347 */       reopenConnection();
/* 317:    */       
/* 318:    */ 
/* 319:350 */       String userName = getProperty("USERNAME");
/* 320:351 */       String password = getProperty("PASSWORD");
/* 321:    */       
/* 322:353 */       String userNameAndPassword = userName + ":" + password;
/* 323:354 */       String base64EncodedUserNameAndPassword = Base64.encode(userNameAndPassword.getBytes());
/* 324:    */       
/* 325:356 */       setRequestProperty("Authorization", "Basic " + base64EncodedUserNameAndPassword);
/* 326:    */       
/* 327:358 */       responseCode = writeRequestPacket(packet);
/* 328:360 */       if (infoEnabled) {
/* 329:362 */         COMMLOGGER.info(" responseCode after base64 Authorization = " + responseCode);
/* 330:    */       }
/* 331:366 */       if (isHTTPUnauthorized(responseCode)) {
/* 332:368 */         throw new MobileApplicationException("authenticationfailure");
/* 333:    */       }
/* 334:371 */       return responseCode;
/* 335:    */     }
/* 336:375 */     throw new MobileApplicationException("authenticationfailure");
/* 337:    */   }
/* 338:    */   
/* 339:    */   private DataOutputStream openDataOutputStream()
/* 340:    */     throws IOException
/* 341:    */   {
/* 342:382 */     OutputStream os = openOutputStream();
/* 343:    */     
/* 344:384 */     return new DataOutputStream(new BufferedOutputStream(os));
/* 345:    */   }
/* 346:    */   
/* 347:    */   private DataInputStream openDataInputStream()
/* 348:    */     throws IOException
/* 349:    */   {
/* 350:389 */     InputStream is = openInputStream();
/* 351:    */     
/* 352:391 */     return new DataInputStream(new BufferedInputStream(is));
/* 353:    */   }
/* 354:    */   
/* 355:    */   private int writeRequestPacket(RequestPacket packet)
/* 356:    */     throws IOException
/* 357:    */   {
/* 358:396 */     DataOutputStream dos = openDataOutputStream();
/* 359:    */     try
/* 360:    */     {
/* 361:400 */       TypeRegistry.getTypeRegistry().writeInstance(dos, packet);
/* 362:    */       
/* 363:    */ 
/* 364:    */ 
/* 365:    */ 
/* 366:    */ 
/* 367:    */ 
/* 368:    */ 
/* 369:    */ 
/* 370:    */ 
/* 371:    */ 
/* 372:    */ 
/* 373:    */ 
/* 374:413 */       return getResponseCode();
/* 375:    */     }
/* 376:    */     finally
/* 377:    */     {
/* 378:404 */       if (dos != null) {
/* 379:    */         try
/* 380:    */         {
/* 381:407 */           dos.flush();
/* 382:408 */           dos.close();
/* 383:    */         }
/* 384:    */         catch (Exception ex) {}
/* 385:    */       }
/* 386:    */     }
/* 387:    */   }
/* 388:    */   
/* 389:    */   private ResponsePacket readResponsePacket()
/* 390:    */     throws IOException
/* 391:    */   {
/* 392:418 */     boolean infoEnabled = COMMLOGGER.isInfoEnabled();
/* 393:    */     
/* 394:420 */     DataInputStream dis = openDataInputStream();
/* 395:    */     try
/* 396:    */     {
/* 397:424 */       long contentLength = getContentLength();
/* 398:426 */       if (infoEnabled) {
/* 399:428 */         COMMLOGGER.info("Response Content Length = " + contentLength);
/* 400:    */       }
/* 401:431 */       if (contentLength > 0L)
/* 402:    */       {
/* 403:433 */         String typeName = dis.readUTF();
/* 404:434 */         return (ResponsePacket)TypeRegistry.getTypeRegistry().readInstance(dis, typeName);
/* 405:    */       }
/* 406:447 */       return null;
/* 407:    */     }
/* 408:    */     finally
/* 409:    */     {
/* 410:439 */       if (dis != null) {
/* 411:    */         try
/* 412:    */         {
/* 413:442 */           dis.close();
/* 414:    */         }
/* 415:    */         catch (Exception ex) {}
/* 416:    */       }
/* 417:    */     }
/* 418:    */   }
/* 419:    */   
/* 420:    */   private void reopenConnection()
/* 421:    */     throws IOException
/* 422:    */   {
/* 423:452 */     closeConnection();
/* 424:    */     
/* 425:454 */     openConnection(true);
/* 426:    */   }
/* 427:    */   
/* 428:    */   public void reset()
/* 429:    */   {
/* 430:459 */     this.properties = new Hashtable();
/* 431:    */   }
/* 432:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.comm.AbstractHTTPCommunicationChannel
 * JD-Core Version:    0.7.0.1
 */