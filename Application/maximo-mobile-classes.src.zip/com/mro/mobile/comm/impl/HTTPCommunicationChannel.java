/*   1:    */ package com.mro.mobile.comm.impl;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.app.AbstractMobileDeviceApplication;
/*   4:    */ import com.mro.mobile.app.MobileDeviceAppSession;
/*   5:    */ import com.mro.mobile.comm.AbstractHTTPCommunicationChannel;
/*   6:    */ import com.mro.mobile.util.MobileLogger;
/*   7:    */ import com.mro.mobile.util.MobileLoggerFactory;
/*   8:    */ import java.io.IOException;
/*   9:    */ import java.io.InputStream;
/*  10:    */ import java.io.OutputStream;
/*  11:    */ import java.net.HttpURLConnection;
/*  12:    */ import java.net.URL;
/*  13:    */ import java.security.Provider;
/*  14:    */ import java.security.Security;
/*  15:    */ import java.util.Enumeration;
/*  16:    */ import java.util.HashSet;
/*  17:    */ import java.util.Properties;
/*  18:    */ import java.util.Vector;
/*  19:    */ 
/*  20:    */ public class HTTPCommunicationChannel
/*  21:    */   extends AbstractHTTPCommunicationChannel
/*  22:    */ {
/*  23: 36 */   private static MobileLogger COMMLOGGER = MobileLoggerFactory.getLogger("maximo.mobile.communication");
/*  24: 37 */   private HttpURLConnection connection = null;
/*  25: 39 */   boolean alreadyCleared = false;
/*  26: 40 */   private Vector cookies = new Vector();
/*  27: 43 */   private HashSet setOfCookies = new HashSet();
/*  28:    */   
/*  29:    */   protected void openConnection()
/*  30:    */     throws IOException
/*  31:    */   {
/*  32: 47 */     boolean infoEnabled = COMMLOGGER.isInfoEnabled();
/*  33:    */     try
/*  34:    */     {
/*  35: 50 */       configureSSL();
/*  36: 51 */       String serverurl = getURLString();
/*  37:    */       
/*  38: 53 */       URL url = new URL(serverurl);
/*  39:    */       
/*  40: 55 */       this.connection = ((HttpURLConnection)url.openConnection());
/*  41: 56 */       this.connection.setDoOutput(true);
/*  42: 57 */       this.connection.setRequestProperty("Content-Type", "application/octet-stream");
/*  43: 58 */       this.connection.setRequestMethod("POST");
/*  44:    */       
/*  45: 60 */       MobileDeviceAppSession.getSession().getApplication().setupConnectionTimeoutSetttings(this.connection);
/*  46:    */       
/*  47: 62 */       Enumeration enm = this.cookies.elements();
/*  48: 63 */       while (enm.hasMoreElements())
/*  49:    */       {
/*  50: 65 */         String value = (String)enm.nextElement();
/*  51: 66 */         this.connection.addRequestProperty("Cookie", value);
/*  52: 68 */         if (infoEnabled) {
/*  53: 70 */           COMMLOGGER.info("Setting request property Cookie: " + value);
/*  54:    */         }
/*  55:    */       }
/*  56:    */     }
/*  57:    */     catch (IOException ex)
/*  58:    */     {
/*  59: 76 */       throw ex;
/*  60:    */     }
/*  61:    */   }
/*  62:    */   
/*  63:    */   protected void closeConnection()
/*  64:    */     throws IOException
/*  65:    */   {
/*  66: 82 */     if (this.connection != null) {}
/*  67: 87 */     this.connection = null;
/*  68:    */   }
/*  69:    */   
/*  70:    */   protected OutputStream openOutputStream()
/*  71:    */     throws IOException
/*  72:    */   {
/*  73: 92 */     return this.connection.getOutputStream();
/*  74:    */   }
/*  75:    */   
/*  76:    */   protected InputStream openInputStream()
/*  77:    */     throws IOException
/*  78:    */   {
/*  79: 97 */     int responseCode = this.connection.getResponseCode();
/*  80: 98 */     int nLoop = 0;
/*  81:    */     
/*  82:100 */     String key = null;
/*  83:101 */     boolean infoEnabled = COMMLOGGER.isInfoEnabled();
/*  84:103 */     if (this.connection.getHeaderFieldKey(nLoop) == null) {
/*  85:105 */       nLoop++;
/*  86:    */     }
/*  87:107 */     while ((key = this.connection.getHeaderFieldKey(nLoop)) != null)
/*  88:    */     {
/*  89:109 */       if (key.equalsIgnoreCase("set-cookie"))
/*  90:    */       {
/*  91:111 */         if (!this.alreadyCleared)
/*  92:    */         {
/*  93:113 */           this.cookies.clear();
/*  94:    */           
/*  95:115 */           this.setOfCookies.clear();
/*  96:116 */           this.alreadyCleared = true;
/*  97:    */         }
/*  98:118 */         String headervalue = this.connection.getHeaderField(nLoop);
/*  99:120 */         if (!this.setOfCookies.contains(headervalue))
/* 100:    */         {
/* 101:121 */           this.setOfCookies.add(headervalue);
/* 102:122 */           this.cookies.add(headervalue);
/* 103:123 */           if (infoEnabled) {
/* 104:125 */             COMMLOGGER.info("set-cookie header received: " + headervalue);
/* 105:    */           }
/* 106:    */         }
/* 107:    */       }
/* 108:130 */       nLoop++;
/* 109:    */     }
/* 110:133 */     if ((responseCode == 200) || (responseCode == 201))
/* 111:    */     {
/* 112:136 */       InputStream inputStream = this.connection.getInputStream();
/* 113:137 */       return inputStream;
/* 114:    */     }
/* 115:140 */     throw new IOException("Failed to open....");
/* 116:    */   }
/* 117:    */   
/* 118:    */   protected int getResponseCode()
/* 119:    */     throws IOException
/* 120:    */   {
/* 121:145 */     return this.connection.getResponseCode();
/* 122:    */   }
/* 123:    */   
/* 124:    */   protected long getContentLength()
/* 125:    */   {
/* 126:150 */     return this.connection.getContentLength();
/* 127:    */   }
/* 128:    */   
/* 129:    */   protected String getHeaderField(String name)
/* 130:    */     throws IOException
/* 131:    */   {
/* 132:155 */     return this.connection.getHeaderField(name);
/* 133:    */   }
/* 134:    */   
/* 135:    */   protected void setRequestProperty(String name, String value)
/* 136:    */     throws IOException
/* 137:    */   {
/* 138:160 */     this.connection.setRequestProperty(name, value);
/* 139:    */   }
/* 140:    */   
/* 141:    */   protected boolean isCookieSet()
/* 142:    */   {
/* 143:165 */     if (this.connection.getRequestProperty("Cookie") == null) {
/* 144:167 */       return false;
/* 145:    */     }
/* 146:170 */     return true;
/* 147:    */   }
/* 148:    */   
/* 149:    */   public void reset()
/* 150:    */   {
/* 151:175 */     super.reset();
/* 152:    */     
/* 153:177 */     this.cookies = new Vector();
/* 154:    */     
/* 155:179 */     this.setOfCookies = new HashSet();
/* 156:    */     
/* 157:    */ 
/* 158:182 */     this.alreadyCleared = true;
/* 159:    */   }
/* 160:    */   
/* 161:    */   protected boolean isHTTPUnauthorized(int responseCode)
/* 162:    */   {
/* 163:187 */     if (responseCode == 401) {
/* 164:189 */       return true;
/* 165:    */     }
/* 166:192 */     return false;
/* 167:    */   }
/* 168:    */   
/* 169:    */   protected boolean isHTTPOK(int responseCode)
/* 170:    */   {
/* 171:197 */     if (responseCode == 200) {
/* 172:199 */       return true;
/* 173:    */     }
/* 174:202 */     return false;
/* 175:    */   }
/* 176:    */   
/* 177:205 */   private static boolean configuredSSL = false;
/* 178:    */   
/* 179:    */   public void configureSSL()
/* 180:    */   {
/* 181:209 */     if (!configuredSSL)
/* 182:    */     {
/* 183:211 */       boolean usingSSL = false;
/* 184:212 */       String secure = getProperty("maximo.mobile.ssl");
/* 185:213 */       if (secure != null) {
/* 186:215 */         if (secure.equals("true")) {
/* 187:217 */           usingSSL = true;
/* 188:    */         }
/* 189:    */       }
/* 190:221 */       if (!usingSSL)
/* 191:    */       {
/* 192:223 */         configuredSSL = true;
/* 193:224 */         return;
/* 194:    */       }
/* 195:    */       try
/* 196:    */       {
/* 197:233 */         Class c = Class.forName("com.sun.net.ssl.internal.ssl.Provider");
/* 198:234 */         Provider provider = (Provider)c.newInstance();
/* 199:235 */         if (Security.getProvider(provider.getName()) == null) {
/* 200:237 */           Security.addProvider(provider);
/* 201:    */         }
/* 202:    */       }
/* 203:    */       catch (Throwable ex) {}
/* 204:248 */       Properties properties = System.getProperties();
/* 205:249 */       String handlers = System.getProperty("java.protocol.handler.pkgs");
/* 206:250 */       if (handlers == null) {
/* 207:253 */         properties.put("java.protocol.handler.pkgs", "com.sun.net.ssl.internal.www.protocol");
/* 208:    */       }
/* 209:256 */       configuredSSL = true;
/* 210:    */     }
/* 211:    */   }
/* 212:    */   
/* 213:    */   protected void openConnection(boolean reopen)
/* 214:    */     throws IOException
/* 215:    */   {
/* 216:262 */     if (reopen)
/* 217:    */     {
/* 218:263 */       this.cookies.clear();
/* 219:    */       
/* 220:265 */       this.setOfCookies.clear();
/* 221:    */     }
/* 222:267 */     openConnection();
/* 223:    */   }
/* 224:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.comm.impl.HTTPCommunicationChannel
 * JD-Core Version:    0.7.0.1
 */