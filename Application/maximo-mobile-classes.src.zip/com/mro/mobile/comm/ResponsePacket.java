/*   1:    */ package com.mro.mobile.comm;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.persist.DefaultRDO;
/*   5:    */ import com.mro.mobile.persist.DefaultRDOAttributeInfo;
/*   6:    */ import com.mro.mobile.persist.DefaultRDOInfo;
/*   7:    */ import com.mro.mobile.persist.RDO;
/*   8:    */ import com.mro.mobile.persist.RDOException;
/*   9:    */ import com.mro.mobile.persist.RDOInfo;
/*  10:    */ import com.mro.mobile.persist.RDOInfoManager;
/*  11:    */ import com.mro.mobile.persist.RDORuntime;
/*  12:    */ import com.mro.mobile.persist.RDOSerializer;
/*  13:    */ import com.mro.mobile.type.Serializer;
/*  14:    */ import com.mro.mobile.type.TypeRegistry;
/*  15:    */ import java.io.ByteArrayInputStream;
/*  16:    */ import java.io.DataInput;
/*  17:    */ import java.io.DataInputStream;
/*  18:    */ import java.io.DataOutput;
/*  19:    */ import java.io.IOException;
/*  20:    */ import java.util.Enumeration;
/*  21:    */ import java.util.Hashtable;
/*  22:    */ 
/*  23:    */ public class ResponsePacket
/*  24:    */   implements Serializer
/*  25:    */ {
/*  26:    */   public static final int STATUS_UNAUTHORIZED = 1;
/*  27:    */   public static final int STATUS_OK = 2;
/*  28:    */   public static final int STATUS_EXCEPTION = 3;
/*  29:    */   public static final String RESPONSESTATUS = "RESPONSESTATUS";
/*  30:    */   public static final String RESPONSEDATA = "RESPONSEDATA";
/*  31:    */   private static final String RESPONSEPACKET_STORE = "RESPONSE";
/*  32:    */   public static final String RESPONSEHEADER_SERVERTIME = "SERVERTIME";
/*  33:    */   public static final String RESPONSEHEADER_REQPROCESSTIME = "REQPROCESSTIME";
/*  34:    */   public static final String RESPONSEHEADER_AUTHTYPE = "AUTHTYPE";
/*  35:    */   public static final String RESPONSEHEADER_AUTHTYPE_SERVER = "SERVER";
/*  36:    */   public static final String RESPONSEHEADER_AUTHTYPE_SIMPLE = "SIMPLE";
/*  37:    */   
/*  38:    */   public static ResponsePacket getNewInstance(String appName)
/*  39:    */   {
/*  40: 59 */     DefaultRDO defRdo = new DefaultRDO(appName);
/*  41: 60 */     defRdo.setName("RESPONSE");
/*  42: 61 */     return new ResponsePacket(defRdo);
/*  43:    */   }
/*  44:    */   
/*  45: 89 */   RDO rdo = null;
/*  46: 90 */   Hashtable headers = new Hashtable();
/*  47:    */   
/*  48:    */   private ResponsePacket() {}
/*  49:    */   
/*  50:    */   public ResponsePacket(RDO rdo)
/*  51:    */   {
/*  52: 99 */     this.rdo = rdo;
/*  53:    */   }
/*  54:    */   
/*  55:    */   public RDO getRDO()
/*  56:    */   {
/*  57:104 */     return this.rdo;
/*  58:    */   }
/*  59:    */   
/*  60:    */   public int getResponseStatus()
/*  61:    */     throws MobileApplicationException
/*  62:    */   {
/*  63:109 */     return this.rdo.getIntValue("RESPONSESTATUS");
/*  64:    */   }
/*  65:    */   
/*  66:    */   public void setResponseStatus(int status)
/*  67:    */     throws MobileApplicationException
/*  68:    */   {
/*  69:114 */     this.rdo.setIntValue("RESPONSESTATUS", status);
/*  70:    */   }
/*  71:    */   
/*  72:    */   public byte[] getResponseData()
/*  73:    */     throws MobileApplicationException
/*  74:    */   {
/*  75:119 */     return this.rdo.getBinaryValue("RESPONSEDATA");
/*  76:    */   }
/*  77:    */   
/*  78:    */   public void setResponseData(byte[] addlData)
/*  79:    */     throws MobileApplicationException
/*  80:    */   {
/*  81:124 */     this.rdo.setBinaryValue("RESPONSEDATA", addlData);
/*  82:    */   }
/*  83:    */   
/*  84:    */   public Object getResponseObject()
/*  85:    */     throws IOException
/*  86:    */   {
/*  87:    */     try
/*  88:    */     {
/*  89:133 */       ByteArrayInputStream bis = new ByteArrayInputStream(getResponseData());
/*  90:134 */       DataInputStream dis = new DataInputStream(bis);
/*  91:    */       
/*  92:136 */       String typeName = dis.readUTF();
/*  93:137 */       return TypeRegistry.getTypeRegistry().readInstance(dis, typeName);
/*  94:    */     }
/*  95:    */     catch (MobileApplicationException e)
/*  96:    */     {
/*  97:142 */       throw new IOException(e.getMessage());
/*  98:    */     }
/*  99:    */   }
/* 100:    */   
/* 101:    */   public void setId(long id)
/* 102:    */     throws MobileApplicationException
/* 103:    */   {
/* 104:148 */     this.rdo.setLongValue("_ID", id);
/* 105:149 */     this.rdo.setId(id);
/* 106:    */   }
/* 107:    */   
/* 108:    */   public void setHeaderField(String name, String value)
/* 109:    */   {
/* 110:154 */     if (value == null) {
/* 111:156 */       return;
/* 112:    */     }
/* 113:159 */     this.headers.put(name, value);
/* 114:    */   }
/* 115:    */   
/* 116:    */   public String getHeaderField(String name)
/* 117:    */   {
/* 118:164 */     return (String)this.headers.get(name);
/* 119:    */   }
/* 120:    */   
/* 121:    */   public Enumeration getHeaderNames()
/* 122:    */   {
/* 123:169 */     return this.headers.keys();
/* 124:    */   }
/* 125:    */   
/* 126:    */   public static void initSerializer()
/* 127:    */   {
/* 128:174 */     ResponsePacket i = new ResponsePacket();
/* 129:    */     
/* 130:176 */     TypeRegistry.getTypeRegistry().addType("ResponsePacket", i.getClass(), i);
/* 131:    */   }
/* 132:    */   
/* 133:    */   public Object readInstance(DataInput input, String name)
/* 134:    */     throws IOException
/* 135:    */   {
/* 136:184 */     if (name.equals("ResponsePacket"))
/* 137:    */     {
/* 138:186 */       RDOSerializer rdoSerializer = new RDOSerializer();
/* 139:187 */       RDO rdo = (RDO)rdoSerializer.readInstance(input);
/* 140:    */       
/* 141:189 */       ResponsePacket respPacket = new ResponsePacket(rdo);
/* 142:    */       
/* 143:    */ 
/* 144:192 */       int noOfHeaderFields = input.readInt();
/* 145:193 */       for (int i = 0; i < noOfHeaderFields; i++)
/* 146:    */       {
/* 147:195 */         String headerField = input.readUTF();
/* 148:196 */         String headerFieldValue = input.readUTF();
/* 149:197 */         respPacket.setHeaderField(headerField, headerFieldValue);
/* 150:    */       }
/* 151:200 */       return respPacket;
/* 152:    */     }
/* 153:203 */     throw new RuntimeException("The type " + name + " not supported.");
/* 154:    */   }
/* 155:    */   
/* 156:    */   public void writeInstance(DataOutput output, Object obj)
/* 157:    */     throws IOException
/* 158:    */   {
/* 159:211 */     if ((obj instanceof ResponsePacket))
/* 160:    */     {
/* 161:213 */       RDOSerializer rdoSerializer = new RDOSerializer();
/* 162:214 */       ResponsePacket respPacket = (ResponsePacket)obj;
/* 163:215 */       rdoSerializer.writeInstance(output, respPacket.getRDO());
/* 164:    */       
/* 165:    */ 
/* 166:218 */       int noOfHeaderFields = respPacket.headers.size();
/* 167:219 */       output.writeInt(noOfHeaderFields);
/* 168:220 */       Enumeration keyEnum = respPacket.headers.keys();
/* 169:221 */       while (keyEnum.hasMoreElements())
/* 170:    */       {
/* 171:223 */         String headerField = (String)keyEnum.nextElement();
/* 172:224 */         String headerFieldValue = (String)respPacket.headers.get(headerField);
/* 173:225 */         output.writeUTF(headerField);
/* 174:226 */         output.writeUTF(headerFieldValue);
/* 175:    */       }
/* 176:    */     }
/* 177:    */   }
/* 178:    */   
/* 179:    */   public static RDOInfo getResponsePacketInfo()
/* 180:    */   {
/* 181:234 */     DefaultRDOInfo respPacketInfo = new DefaultRDOInfo();
/* 182:235 */     respPacketInfo.setName("RESPONSE");
/* 183:    */     
/* 184:237 */     DefaultRDOAttributeInfo attr1 = new DefaultRDOAttributeInfo();
/* 185:238 */     attr1.setName("RESPONSESTATUS");
/* 186:239 */     attr1.setDataType(4);
/* 187:    */     
/* 188:241 */     DefaultRDOAttributeInfo attr2 = new DefaultRDOAttributeInfo();
/* 189:242 */     attr2.setName("RESPONSEDATA");
/* 190:243 */     attr2.setDataType(12);
/* 191:    */     
/* 192:245 */     respPacketInfo.addAttributeInfo(attr1);
/* 193:246 */     respPacketInfo.addAttributeInfo(attr2);
/* 194:    */     
/* 195:248 */     return respPacketInfo;
/* 196:    */   }
/* 197:    */   
/* 198:    */   public static void registerResponsePacketInfo(String appName)
/* 199:    */     throws RDOException
/* 200:    */   {
/* 201:254 */     DefaultRDOInfo respPacketInfo = new DefaultRDOInfo();
/* 202:255 */     respPacketInfo.setName("RESPONSE");
/* 203:    */     
/* 204:257 */     DefaultRDOAttributeInfo attr1 = new DefaultRDOAttributeInfo();
/* 205:258 */     attr1.setName("RESPONSESTATUS");
/* 206:259 */     attr1.setDataType(4);
/* 207:    */     
/* 208:261 */     DefaultRDOAttributeInfo attr2 = new DefaultRDOAttributeInfo();
/* 209:262 */     attr2.setName("RESPONSEDATA");
/* 210:263 */     attr2.setDataType(12);
/* 211:    */     
/* 212:265 */     respPacketInfo.addAttributeInfo(attr1);
/* 213:266 */     respPacketInfo.addAttributeInfo(attr2);
/* 214:    */     
/* 215:268 */     RDORuntime rdoRuntime = RDORuntime.getInstance(appName);
/* 216:269 */     rdoRuntime.getRDOInfoManager().registerInfo("RESPONSE", respPacketInfo);
/* 217:    */   }
/* 218:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.comm.ResponsePacket
 * JD-Core Version:    0.7.0.1
 */