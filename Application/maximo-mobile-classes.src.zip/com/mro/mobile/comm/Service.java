/*   1:    */ package com.mro.mobile.comm;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.app.AbstractMobileDeviceApplication;
/*   5:    */ import com.mro.mobile.app.MobileDeviceAppSession;
/*   6:    */ import com.mro.mobile.persist.DefaultOrder;
/*   7:    */ import com.mro.mobile.persist.RDO;
/*   8:    */ import com.mro.mobile.persist.RDOException;
/*   9:    */ import com.mro.mobile.persist.RDOManager;
/*  10:    */ import com.mro.mobile.persist.RDORuntime;
/*  11:    */ import com.mro.mobile.persist.RDOTransactionManager;
/*  12:    */ import com.mro.mobile.userlocation.UserLocationDataInfo;
/*  13:    */ import com.mro.mobile.util.MobileLogger;
/*  14:    */ import com.mro.mobile.util.MobileLoggerFactory;
/*  15:    */ import java.util.Enumeration;
/*  16:    */ import java.util.Hashtable;
/*  17:    */ 
/*  18:    */ public class Service
/*  19:    */ {
/*  20: 34 */   private static MobileLogger COMMLOGGER = MobileLoggerFactory.getLogger("maximo.mobile.communication");
/*  21: 37 */   private String appName = null;
/*  22: 38 */   private Hashtable properties = new Hashtable();
/*  23: 39 */   private CommunicationChannel communicationChannel = null;
/*  24: 40 */   private boolean initializedChannel = false;
/*  25: 41 */   private boolean channelPropertiesChanged = false;
/*  26: 42 */   private boolean batchAsyncMode = false;
/*  27: 43 */   private boolean suspendProcessPendingRequests = false;
/*  28: 44 */   private boolean suspendUpdateLastCommunication = false;
/*  29:    */   
/*  30:    */   public Service(String appName)
/*  31:    */   {
/*  32: 47 */     this.appName = appName;
/*  33:    */   }
/*  34:    */   
/*  35:    */   public void setCommunicationChannel(CommunicationChannel communicationChannel)
/*  36:    */   {
/*  37: 52 */     this.communicationChannel = communicationChannel;
/*  38:    */   }
/*  39:    */   
/*  40:    */   public CommunicationChannel getCommunicationChannel()
/*  41:    */   {
/*  42: 56 */     return this.communicationChannel;
/*  43:    */   }
/*  44:    */   
/*  45:    */   public void setProperty(String propertyName, String value)
/*  46:    */     throws MobileApplicationException
/*  47:    */   {
/*  48: 62 */     this.channelPropertiesChanged = true;
/*  49: 64 */     if (value == null)
/*  50:    */     {
/*  51: 65 */       this.properties.remove(propertyName);
/*  52: 66 */       return;
/*  53:    */     }
/*  54: 68 */     this.properties.put(propertyName, value);
/*  55:    */   }
/*  56:    */   
/*  57:    */   public String getProperty(String propertyName)
/*  58:    */   {
/*  59: 72 */     return (String)this.properties.get(propertyName);
/*  60:    */   }
/*  61:    */   
/*  62:    */   public Enumeration getPropertyNames()
/*  63:    */   {
/*  64: 76 */     return this.properties.keys();
/*  65:    */   }
/*  66:    */   
/*  67:    */   public boolean isBatchAsyncMode()
/*  68:    */   {
/*  69: 80 */     return this.batchAsyncMode;
/*  70:    */   }
/*  71:    */   
/*  72:    */   public void setBatchAsyncMode(boolean enable)
/*  73:    */   {
/*  74: 84 */     this.batchAsyncMode = enable;
/*  75:    */   }
/*  76:    */   
/*  77:    */   public void suspendProcessPendingRequests()
/*  78:    */   {
/*  79: 88 */     this.suspendProcessPendingRequests = true;
/*  80:    */   }
/*  81:    */   
/*  82:    */   public void resumeProcessPendingRequests()
/*  83:    */   {
/*  84: 92 */     this.suspendProcessPendingRequests = false;
/*  85:    */   }
/*  86:    */   
/*  87:    */   public void suspendUpdateLastCommunication()
/*  88:    */   {
/*  89: 96 */     this.suspendUpdateLastCommunication = true;
/*  90:    */   }
/*  91:    */   
/*  92:    */   public void resumeUpdateLastCommunication()
/*  93:    */   {
/*  94:100 */     this.suspendUpdateLastCommunication = false;
/*  95:    */   }
/*  96:    */   
/*  97:    */   public Object invoke(String operationName, Object[] params)
/*  98:    */     throws MobileApplicationException
/*  99:    */   {
/* 100:118 */     long beginTime = System.currentTimeMillis();
/* 101:    */     
/* 102:120 */     String userName = getProperty("USERNAME");
/* 103:    */     
/* 104:122 */     MobileLogger mobileLogger = MobileLoggerFactory.getLogger("maximo.mobile.servicecall");
/* 105:123 */     if (mobileLogger.isInfoEnabled()) {
/* 106:125 */       mobileLogger.info("Service Call BEGIN [user]:" + userName + " [operation]:" + operationName);
/* 107:    */     }
/* 108:    */     try
/* 109:    */     {
/* 110:130 */       RequestPacket reqPacket = RequestPacket.getNewInstance(this.appName);
/* 111:    */       
/* 112:    */ 
/* 113:133 */       reqPacket.setInvocationType(1);
/* 114:134 */       reqPacket.setOperationName(operationName);
/* 115:135 */       reqPacket.setParameters(params);
/* 116:    */       
/* 117:137 */       ResponsePacket respPacket = sendRequestPacket(reqPacket);
/* 118:141 */       if (respPacket.getResponseStatus() == 3)
/* 119:    */       {
/* 120:142 */         Object respObject = respPacket.getResponseObject();
/* 121:143 */         if ((respObject instanceof String))
/* 122:    */         {
/* 123:144 */           String exceptionMessage = (String)respObject;
/* 124:145 */           throw new MobileApplicationException(exceptionMessage);
/* 125:    */         }
/* 126:146 */         if ((respObject instanceof String[]))
/* 127:    */         {
/* 128:147 */           String[] exceptionMessages = (String[])respObject;
/* 129:148 */           if (exceptionMessages.length == 1) {
/* 130:149 */             throw new MobileApplicationException(exceptionMessages[0]);
/* 131:    */           }
/* 132:151 */           if (exceptionMessages.length > 1) {
/* 133:152 */             throw new MobileApplicationException(exceptionMessages[0], new Object[] { exceptionMessages[1] });
/* 134:    */           }
/* 135:156 */           throw new MobileApplicationException("unknownerror");
/* 136:    */         }
/* 137:159 */         throw new MobileApplicationException("unknownerror");
/* 138:    */       }
/* 139:    */       Object respObject;
/* 140:161 */       if (respPacket.getResponseStatus() == 1)
/* 141:    */       {
/* 142:162 */         respObject = respPacket.getResponseObject();
/* 143:163 */         if ((respObject instanceof String))
/* 144:    */         {
/* 145:164 */           String exceptionMessage = (String)respObject;
/* 146:165 */           throw new MobileApplicationException(exceptionMessage);
/* 147:    */         }
/* 148:166 */         if ((respObject instanceof String[]))
/* 149:    */         {
/* 150:167 */           String[] exceptionMessages = (String[])respObject;
/* 151:168 */           if (exceptionMessages.length == 1) {
/* 152:169 */             throw new MobileApplicationException(exceptionMessages[0]);
/* 153:    */           }
/* 154:171 */           if (exceptionMessages.length > 1) {
/* 155:172 */             throw new MobileApplicationException(exceptionMessages[0], new Object[] { exceptionMessages[1] });
/* 156:    */           }
/* 157:176 */           throw new MobileApplicationException("serverauthfailed");
/* 158:    */         }
/* 159:179 */         throw new MobileApplicationException("serverauthfailed");
/* 160:    */       }
/* 161:    */       long endTime;
/* 162:183 */       return respPacket.getResponseObject();
/* 163:    */     }
/* 164:    */     catch (MobileApplicationException e)
/* 165:    */     {
/* 166:185 */       if ((e.getKey() != null) && ((e.getKey().equals("noappauth")) || (e.getKey().equals("noappauthparam"))))
/* 167:    */       {
/* 168:188 */         MobileDeviceAppSession deviceAppSession = MobileDeviceAppSession.getSession();
/* 169:    */         
/* 170:190 */         AbstractMobileDeviceApplication app = deviceAppSession.getApplication();
/* 171:191 */         app.setAppSetting("_ACCESS", "false");
/* 172:193 */         if (this.communicationChannel != null) {
/* 173:194 */           this.communicationChannel.reset();
/* 174:    */         }
/* 175:    */       }
/* 176:197 */       throw e;
/* 177:    */     }
/* 178:    */     catch (Exception e)
/* 179:    */     {
/* 180:199 */       MobileLoggerFactory.getDefaultLogger().warn("Failed to perform operation: " + operationName, e);
/* 181:200 */       throw new InvocationException("operationfailed");
/* 182:    */     }
/* 183:    */     finally
/* 184:    */     {
/* 185:204 */       long endTime = System.currentTimeMillis();
/* 186:205 */       if (mobileLogger.isInfoEnabled()) {
/* 187:207 */         mobileLogger.info("Service Call END [user]:" + userName + " [operation]:" + operationName + " [TotalTime]:" + (endTime - beginTime) + " ms");
/* 188:    */       }
/* 189:    */     }
/* 190:    */   }
/* 191:    */   
/* 192:    */   private void initializeCommunicationChannel()
/* 193:    */     throws MobileApplicationException
/* 194:    */   {
/* 195:214 */     CommunicationChannel channel = getCommunicationChannel();
/* 196:215 */     if (channel == null) {
/* 197:216 */       throw new MobileApplicationException("nocommchannel");
/* 198:    */     }
/* 199:219 */     if ((this.initializedChannel) && (!this.channelPropertiesChanged)) {
/* 200:221 */       return;
/* 201:    */     }
/* 202:224 */     if (!this.initializedChannel) {
/* 203:226 */       this.communicationChannel.reset();
/* 204:    */     }
/* 205:230 */     Enumeration enumPropertyNames = getPropertyNames();
/* 206:231 */     while (enumPropertyNames.hasMoreElements())
/* 207:    */     {
/* 208:232 */       String propertyName = (String)enumPropertyNames.nextElement();
/* 209:233 */       channel.setProperty(propertyName, getProperty(propertyName));
/* 210:    */     }
/* 211:236 */     this.initializedChannel = true;
/* 212:237 */     this.channelPropertiesChanged = false;
/* 213:    */   }
/* 214:    */   
/* 215:    */   private ResponsePacket sendRequestPacket(RequestPacket reqPacket)
/* 216:    */     throws MobileApplicationException
/* 217:    */   {
/* 218:243 */     AbstractMobileDeviceApplication application = MobileDeviceAppSession.getSession().getApplication();
/* 219:244 */     if (application.sendsUserLocationWhenConnected()) {
/* 220:245 */       reqPacket.setAdditionalGPSLocationData(UserLocationDataInfo.toBytes(application.getCurrentUserLocation()));
/* 221:    */     }
/* 222:248 */     if (!this.suspendProcessPendingRequests) {
/* 223:250 */       processPendingRequests();
/* 224:    */     }
/* 225:253 */     initializeCommunicationChannel();
/* 226:    */     
/* 227:255 */     ResponsePacket respPacket = getCommunicationChannel().send(reqPacket);
/* 228:257 */     if (!this.suspendUpdateLastCommunication) {
/* 229:258 */       updateLastCommunicationTime();
/* 230:    */     }
/* 231:261 */     return respPacket;
/* 232:    */   }
/* 233:    */   
/* 234:    */   public void invokeAsyncWithAck(String operationName, Object[] params, String correlationId)
/* 235:    */     throws MobileApplicationException
/* 236:    */   {
/* 237:272 */     RequestPacket reqPacket = RequestPacket.getNewInstance(this.appName);
/* 238:273 */     reqPacket.setId(getNextTransactionId());
/* 239:274 */     reqPacket.setInvocationType(3);
/* 240:275 */     reqPacket.setOperationName(operationName);
/* 241:276 */     reqPacket.setParameters(params);
/* 242:277 */     if (correlationId != null) {
/* 243:278 */       reqPacket.setCorrelationId(correlationId);
/* 244:    */     }
/* 245:281 */     sendRequestPacket(reqPacket);
/* 246:    */   }
/* 247:    */   
/* 248:    */   public void invokeAsyncWithAck(String operationName, Object[] params)
/* 249:    */     throws MobileApplicationException
/* 250:    */   {
/* 251:286 */     invokeAsyncWithAck(operationName, params, null);
/* 252:    */   }
/* 253:    */   
/* 254:    */   public void invokeAsyncWithNoAck(String operationName, Object[] params, String correlationId)
/* 255:    */     throws MobileApplicationException
/* 256:    */   {
/* 257:294 */     RequestPacket reqPacket = RequestPacket.getNewInstance(this.appName);
/* 258:295 */     reqPacket.setId(getNextTransactionId());
/* 259:296 */     reqPacket.setInvocationType(2);
/* 260:297 */     reqPacket.setOperationName(operationName);
/* 261:298 */     reqPacket.setParameters(params);
/* 262:299 */     if (correlationId != null) {
/* 263:300 */       reqPacket.setCorrelationId(correlationId);
/* 264:    */     }
/* 265:    */     try
/* 266:    */     {
/* 267:306 */       if (isBatchAsyncMode())
/* 268:    */       {
/* 269:307 */         queueRequestPacket(reqPacket);
/* 270:    */       }
/* 271:    */       else
/* 272:    */       {
/* 273:309 */         ResponsePacket respPacket = sendRequestPacket(reqPacket);
/* 274:310 */         if (respPacket.getResponseStatus() == 3) {
/* 275:311 */           queueRequestPacket(reqPacket);
/* 276:    */         }
/* 277:    */       }
/* 278:    */     }
/* 279:    */     catch (Exception ex)
/* 280:    */     {
/* 281:315 */       queueRequestPacket(reqPacket);
/* 282:    */     }
/* 283:    */   }
/* 284:    */   
/* 285:    */   public void invokeAsyncWithNoAck(String operationName, Object[] params)
/* 286:    */     throws MobileApplicationException
/* 287:    */   {
/* 288:321 */     invokeAsyncWithNoAck(operationName, params, null);
/* 289:    */   }
/* 290:    */   
/* 291:    */   public void invokeAsync(String operationName, Object[] params, String correlationId)
/* 292:    */     throws MobileApplicationException
/* 293:    */   {
/* 294:326 */     RequestPacket reqPacket = RequestPacket.getNewInstance(this.appName);
/* 295:327 */     reqPacket.setId(getNextTransactionId());
/* 296:328 */     reqPacket.setInvocationType(4);
/* 297:329 */     reqPacket.setOperationName(operationName);
/* 298:330 */     reqPacket.setParameters(params);
/* 299:331 */     if (correlationId != null) {
/* 300:332 */       reqPacket.setCorrelationId(correlationId);
/* 301:    */     }
/* 302:    */     try
/* 303:    */     {
/* 304:338 */       if (isBatchAsyncMode())
/* 305:    */       {
/* 306:339 */         queueRequestPacket(reqPacket);
/* 307:    */       }
/* 308:    */       else
/* 309:    */       {
/* 310:341 */         ResponsePacket respPacket = sendRequestPacket(reqPacket);
/* 311:342 */         if (respPacket.getResponseStatus() == 3) {
/* 312:343 */           queueRequestPacket(reqPacket);
/* 313:    */         }
/* 314:    */       }
/* 315:    */     }
/* 316:    */     catch (Exception ex)
/* 317:    */     {
/* 318:347 */       queueRequestPacket(reqPacket);
/* 319:    */     }
/* 320:    */   }
/* 321:    */   
/* 322:    */   public void invokeAsync(String operationName, Object[] params)
/* 323:    */     throws MobileApplicationException
/* 324:    */   {
/* 325:353 */     invokeAsync(operationName, params, null);
/* 326:    */   }
/* 327:    */   
/* 328:    */   private void queueRequestPacket(RequestPacket reqPacket)
/* 329:    */     throws MobileApplicationException
/* 330:    */   {
/* 331:358 */     RDORuntime rdoRuntime = RDORuntime.getInstance(this.appName);
/* 332:359 */     RDOManager rdoManager = rdoRuntime.getRDOManager();
/* 333:    */     
/* 334:361 */     RDOTransactionManager rdoTxnManager = rdoRuntime.getRDOTransactionManager();
/* 335:    */     try
/* 336:    */     {
/* 337:364 */       if (COMMLOGGER.isInfoEnabled()) {
/* 338:365 */         COMMLOGGER.info("Queueing a new request");
/* 339:    */       }
/* 340:367 */       rdoTxnManager.begin();
/* 341:368 */       rdoManager.insert("REQUEST", reqPacket.getRDO());
/* 342:369 */       rdoTxnManager.commit();
/* 343:    */     }
/* 344:    */     catch (RDOException e)
/* 345:    */     {
/* 346:371 */       MobileLoggerFactory.getDefaultLogger().warn("Failed to insert and queue request package", e);
/* 347:    */       try
/* 348:    */       {
/* 349:373 */         rdoTxnManager.rollback();
/* 350:    */       }
/* 351:    */       catch (Exception ex1) {}
/* 352:376 */       throw new MobileApplicationException("failedtoqueuereq");
/* 353:    */     }
/* 354:    */   }
/* 355:    */   
/* 356:    */   public void processPendingRequests()
/* 357:    */     throws MobileApplicationException
/* 358:    */   {
/* 359:382 */     RDORuntime rdoRuntime = RDORuntime.getInstance(this.appName);
/* 360:383 */     RDOManager rdoManager = rdoRuntime.getRDOManager();
/* 361:    */     
/* 362:385 */     RDOTransactionManager rdoTxnManager = rdoRuntime.getRDOTransactionManager();
/* 363:    */     try
/* 364:    */     {
/* 365:389 */       int noOfPendingRequests = 0;
/* 366:    */       
/* 367:    */ 
/* 368:392 */       DefaultOrder order = new DefaultOrder();
/* 369:393 */       order.setOrder("ID", true);
/* 370:395 */       if (COMMLOGGER.isInfoEnabled()) {
/* 371:396 */         COMMLOGGER.info("Sending queued requests");
/* 372:    */       }
/* 373:399 */       Enumeration reqPackEnum = rdoManager.getAll("REQUEST", null, order);
/* 374:401 */       while (reqPackEnum.hasMoreElements())
/* 375:    */       {
/* 376:402 */         RDO rdo = (RDO)reqPackEnum.nextElement();
/* 377:403 */         RequestPacket r = new RequestPacket(rdo);
/* 378:    */         
/* 379:405 */         initializeCommunicationChannel();
/* 380:406 */         ResponsePacket respPacket = getCommunicationChannel().send(r);
/* 381:407 */         if (respPacket.getResponseStatus() == 3) {
/* 382:408 */           throw new MobileApplicationException("failedtoupload");
/* 383:    */         }
/* 384:410 */         noOfPendingRequests++;
/* 385:    */       }
/* 386:413 */       if (noOfPendingRequests > 0)
/* 387:    */       {
/* 388:414 */         rdoTxnManager.begin();
/* 389:415 */         rdoManager.removeAll("REQUEST");
/* 390:416 */         if (COMMLOGGER.isInfoEnabled()) {
/* 391:417 */           COMMLOGGER.info("Removed queued requests");
/* 392:    */         }
/* 393:419 */         rdoTxnManager.commit();
/* 394:    */       }
/* 395:    */     }
/* 396:    */     catch (Exception ex)
/* 397:    */     {
/* 398:422 */       MobileLoggerFactory.getDefaultLogger().warn("Failed to process pending requests", ex);
/* 399:    */       try
/* 400:    */       {
/* 401:424 */         rdoTxnManager.rollback();
/* 402:    */       }
/* 403:    */       catch (Exception ex1) {}
/* 404:428 */       if ((ex instanceof MobileApplicationException)) {
/* 405:429 */         throw ((MobileApplicationException)ex);
/* 406:    */       }
/* 407:431 */       throw new MobileApplicationException("failedtoupload");
/* 408:    */     }
/* 409:    */   }
/* 410:    */   
/* 411:    */   private long getNextTransactionId()
/* 412:    */     throws MobileApplicationException
/* 413:    */   {
/* 414:438 */     return MobileDeviceAppSession.getSession().getApplication().getNextTransactionId();
/* 415:    */   }
/* 416:    */   
/* 417:    */   private void updateLastCommunicationTime()
/* 418:    */     throws MobileApplicationException
/* 419:    */   {
/* 420:442 */     MobileDeviceAppSession.getSession().getApplication().updateLastCommunicationTime();
/* 421:    */   }
/* 422:    */   
/* 423:    */   public long getTimeDifference()
/* 424:    */     throws MobileApplicationException
/* 425:    */   {
/* 426:446 */     RequestPacket reqPacket = RequestPacket.getNewInstance(this.appName);
/* 427:447 */     reqPacket.setId(getNextTransactionId());
/* 428:448 */     reqPacket.setInvocationType(1);
/* 429:449 */     reqPacket.setOperationName("doNothing");
/* 430:450 */     reqPacket.setParameters(new Object[0]);
/* 431:451 */     reqPacket.setHeaderField("maximo.mobile.timeinfo", "true");
/* 432:    */     
/* 433:453 */     long before = System.currentTimeMillis();
/* 434:454 */     ResponsePacket respPacket = getCommunicationChannel().send(reqPacket);
/* 435:455 */     long after = System.currentTimeMillis();
/* 436:    */     
/* 437:457 */     String serverTime = respPacket.getHeaderField("SERVERTIME");
/* 438:459 */     if (serverTime == null) {
/* 439:460 */       return 0L;
/* 440:    */     }
/* 441:473 */     String requestProcessTime = respPacket.getHeaderField("REQPROCESSTIME");
/* 442:    */     
/* 443:475 */     long reqProcessTime = Long.parseLong(requestProcessTime);
/* 444:    */     
/* 445:    */ 
/* 446:    */ 
/* 447:    */ 
/* 448:    */ 
/* 449:    */ 
/* 450:    */ 
/* 451:483 */     long networkDelay = after - before - reqProcessTime;
/* 452:    */     
/* 453:    */ 
/* 454:    */ 
/* 455:487 */     long deviceCurrentTime = after;
/* 456:    */     
/* 457:489 */     long currentTimeDiff = Long.parseLong(serverTime) + networkDelay / 2L - (deviceCurrentTime - reqProcessTime);
/* 458:    */     
/* 459:    */ 
/* 460:    */ 
/* 461:    */ 
/* 462:    */ 
/* 463:    */ 
/* 464:    */ 
/* 465:    */ 
/* 466:    */ 
/* 467:499 */     return currentTimeDiff;
/* 468:    */   }
/* 469:    */   
/* 470:    */   public boolean getAuthType()
/* 471:    */     throws MobileApplicationException
/* 472:    */   {
/* 473:505 */     RequestPacket reqPacket = RequestPacket.getNewInstance(this.appName);
/* 474:506 */     reqPacket.setId(getNextTransactionId());
/* 475:507 */     reqPacket.setInvocationType(1);
/* 476:508 */     reqPacket.setOperationName("doNothing");
/* 477:509 */     reqPacket.setParameters(new Object[0]);
/* 478:510 */     reqPacket.setHeaderField("maximo.mobile.authinfo", "true");
/* 479:    */     
/* 480:512 */     ResponsePacket respPacket = getCommunicationChannel().send(reqPacket);
/* 481:    */     
/* 482:514 */     String requestAuthType = respPacket.getHeaderField("AUTHTYPE");
/* 483:    */     
/* 484:    */ 
/* 485:517 */     return requestAuthType.equals("SERVER");
/* 486:    */   }
/* 487:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.comm.Service
 * JD-Core Version:    0.7.0.1
 */