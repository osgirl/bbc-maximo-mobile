package com.mro.mobile.comm;

import java.net.HttpURLConnection;

public abstract interface ConnectionTimeoutConfigurator
{
  public abstract void setupConnectionTimeoutSetttings(HttpURLConnection paramHttpURLConnection);
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.comm.ConnectionTimeoutConfigurator
 * JD-Core Version:    0.7.0.1
 */