/*   1:    */ package com.mro.mobile.comm;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.persist.DefaultRDO;
/*   5:    */ import com.mro.mobile.persist.DefaultRDOAttributeInfo;
/*   6:    */ import com.mro.mobile.persist.DefaultRDOInfo;
/*   7:    */ import com.mro.mobile.persist.RDO;
/*   8:    */ import com.mro.mobile.persist.RDOInfo;
/*   9:    */ import com.mro.mobile.persist.RDOSerializer;
/*  10:    */ import com.mro.mobile.type.Serializer;
/*  11:    */ import com.mro.mobile.type.TypeRegistry;
/*  12:    */ import com.mro.mobile.util.MobileLogger;
/*  13:    */ import com.mro.mobile.util.MobileLoggerFactory;
/*  14:    */ import java.io.ByteArrayInputStream;
/*  15:    */ import java.io.ByteArrayOutputStream;
/*  16:    */ import java.io.DataInput;
/*  17:    */ import java.io.DataInputStream;
/*  18:    */ import java.io.DataOutput;
/*  19:    */ import java.io.DataOutputStream;
/*  20:    */ import java.io.IOException;
/*  21:    */ import java.util.Enumeration;
/*  22:    */ import java.util.Hashtable;
/*  23:    */ 
/*  24:    */ public class RequestPacket
/*  25:    */   implements Serializer
/*  26:    */ {
/*  27: 40 */   public static Object idObject = new Object();
/*  28:    */   public static final String ID = "ID";
/*  29:    */   public static final String APPNAME = "APPNAME";
/*  30:    */   public static final String OPERATION = "OPERATION";
/*  31:    */   public static final String PARAMETERS = "PARAMETERS";
/*  32:    */   public static final String INVOCATIONTYPE = "INVOCATIONTYPE";
/*  33:    */   public static final String ADDLDATA = "ADDLDATA";
/*  34:    */   public static final String CORRELATIONID = "CORRELATIONID";
/*  35:    */   public static final String REQUESTPACKET = "REQUEST";
/*  36:    */   public static final int INVOCATIONTYPE_SYNC = 1;
/*  37:    */   public static final int INVOCATIONTYPE_ASYNC_NOACK = 2;
/*  38:    */   public static final int INVOCATIONTYPE_ASYNC_ACK = 3;
/*  39:    */   public static final int INVOCATIONTYPE_ASYNC_RESP = 4;
/*  40:    */   
/*  41:    */   public static RequestPacket getNewInstance(String appName)
/*  42:    */     throws MobileApplicationException
/*  43:    */   {
/*  44: 57 */     DefaultRDO defRdo = new DefaultRDO(appName);
/*  45: 58 */     defRdo.setName("REQUEST");
/*  46: 59 */     defRdo.setStringValue("APPNAME", appName);
/*  47:    */     
/*  48: 61 */     RequestPacket packet = new RequestPacket(defRdo);
/*  49:    */     
/*  50: 63 */     return packet;
/*  51:    */   }
/*  52:    */   
/*  53: 66 */   RDO rdo = null;
/*  54: 67 */   boolean queueable = false;
/*  55: 68 */   Hashtable headers = new Hashtable();
/*  56:    */   
/*  57:    */   private RequestPacket() {}
/*  58:    */   
/*  59:    */   public RequestPacket(RDO rdo)
/*  60:    */   {
/*  61: 78 */     this.rdo = rdo;
/*  62:    */   }
/*  63:    */   
/*  64:    */   public RDO getRDO()
/*  65:    */   {
/*  66: 83 */     return this.rdo;
/*  67:    */   }
/*  68:    */   
/*  69:    */   public String getAppName()
/*  70:    */     throws MobileApplicationException
/*  71:    */   {
/*  72: 88 */     return this.rdo.getStringValue("APPNAME");
/*  73:    */   }
/*  74:    */   
/*  75:    */   public void setAppName(String appName)
/*  76:    */     throws MobileApplicationException
/*  77:    */   {
/*  78: 93 */     this.rdo.setStringValue("APPNAME", appName);
/*  79:    */   }
/*  80:    */   
/*  81:    */   public String getOperationName()
/*  82:    */     throws MobileApplicationException
/*  83:    */   {
/*  84: 98 */     return this.rdo.getStringValue("OPERATION");
/*  85:    */   }
/*  86:    */   
/*  87:    */   public void setOperationName(String oper)
/*  88:    */     throws MobileApplicationException
/*  89:    */   {
/*  90:103 */     this.rdo.setStringValue("OPERATION", oper);
/*  91:    */   }
/*  92:    */   
/*  93:    */   public Object[] getParameters()
/*  94:    */     throws MobileApplicationException
/*  95:    */   {
/*  96:108 */     byte[] parameterData = this.rdo.getBinaryValue("PARAMETERS");
/*  97:    */     
/*  98:    */ 
/*  99:    */ 
/* 100:112 */     ByteArrayInputStream bis = new ByteArrayInputStream(parameterData);
/* 101:113 */     DataInputStream dis = new DataInputStream(bis);
/* 102:    */     try
/* 103:    */     {
/* 104:117 */       String typeName = dis.readUTF();
/* 105:118 */       return (Object[])TypeRegistry.getTypeRegistry().readInstance(dis, typeName);
/* 106:    */     }
/* 107:    */     catch (IOException e)
/* 108:    */     {
/* 109:123 */       MobileLoggerFactory.getDefaultLogger().warn("Failed to get parameters", e);
/* 110:    */     }
/* 111:126 */     return null;
/* 112:    */   }
/* 113:    */   
/* 114:    */   public void setParameters(Object[] params)
/* 115:    */     throws MobileApplicationException
/* 116:    */   {
/* 117:131 */     byte[] parameterData = null;
/* 118:    */     
/* 119:    */ 
/* 120:134 */     ByteArrayOutputStream bos = new ByteArrayOutputStream();
/* 121:135 */     DataOutputStream dout = new DataOutputStream(bos);
/* 122:    */     try
/* 123:    */     {
/* 124:139 */       TypeRegistry.getTypeRegistry().writeInstance(dout, params);
/* 125:140 */       dout.flush();
/* 126:141 */       parameterData = bos.toByteArray();
/* 127:142 */       this.rdo.setBinaryValue("PARAMETERS", parameterData);
/* 128:    */     }
/* 129:    */     catch (IOException e)
/* 130:    */     {
/* 131:146 */       MobileLoggerFactory.getDefaultLogger().warn("Failed to set parameters", e);
/* 132:    */     }
/* 133:    */   }
/* 134:    */   
/* 135:    */   public int getInvocationType()
/* 136:    */     throws MobileApplicationException
/* 137:    */   {
/* 138:152 */     return this.rdo.getIntValue("INVOCATIONTYPE");
/* 139:    */   }
/* 140:    */   
/* 141:    */   public void setInvocationType(int type)
/* 142:    */     throws MobileApplicationException
/* 143:    */   {
/* 144:157 */     this.rdo.setIntValue("INVOCATIONTYPE", type);
/* 145:    */   }
/* 146:    */   
/* 147:    */   public byte[] getAdditionalGPSLocationData()
/* 148:    */     throws MobileApplicationException
/* 149:    */   {
/* 150:163 */     return this.rdo.getBinaryValue("ADDLDATA");
/* 151:    */   }
/* 152:    */   
/* 153:    */   public void setAdditionalGPSLocationData(byte[] addlData)
/* 154:    */     throws MobileApplicationException
/* 155:    */   {
/* 156:168 */     this.rdo.setBinaryValue("ADDLDATA", addlData);
/* 157:    */   }
/* 158:    */   
/* 159:    */   public String getCorrelationId()
/* 160:    */     throws MobileApplicationException
/* 161:    */   {
/* 162:173 */     return this.rdo.getStringValue("CORRELATIONID");
/* 163:    */   }
/* 164:    */   
/* 165:    */   public void setCorrelationId(String id)
/* 166:    */     throws MobileApplicationException
/* 167:    */   {
/* 168:178 */     this.rdo.setStringValue("CORRELATIONID", id);
/* 169:    */   }
/* 170:    */   
/* 171:    */   public void setHeaderField(String name, String value)
/* 172:    */   {
/* 173:183 */     if (value == null) {
/* 174:185 */       return;
/* 175:    */     }
/* 176:188 */     this.headers.put(name, value);
/* 177:    */   }
/* 178:    */   
/* 179:    */   public String getHeaderField(String name)
/* 180:    */   {
/* 181:193 */     return (String)this.headers.get(name);
/* 182:    */   }
/* 183:    */   
/* 184:    */   public Enumeration getHeaderNames()
/* 185:    */   {
/* 186:198 */     return this.headers.keys();
/* 187:    */   }
/* 188:    */   
/* 189:    */   public long getId()
/* 190:    */     throws MobileApplicationException
/* 191:    */   {
/* 192:203 */     return this.rdo.getLongValue("ID");
/* 193:    */   }
/* 194:    */   
/* 195:    */   public void setId(long id)
/* 196:    */     throws MobileApplicationException
/* 197:    */   {
/* 198:208 */     this.rdo.setLongValue("ID", id);
/* 199:209 */     this.rdo.setId(id);
/* 200:    */   }
/* 201:    */   
/* 202:    */   public boolean isQueueable()
/* 203:    */   {
/* 204:214 */     return true;
/* 205:    */   }
/* 206:    */   
/* 207:    */   public void setQueueable(boolean queueable)
/* 208:    */   {
/* 209:220 */     this.queueable = queueable;
/* 210:    */   }
/* 211:    */   
/* 212:    */   public static void initSerializer()
/* 213:    */   {
/* 214:226 */     RequestPacket i = new RequestPacket();
/* 215:    */     
/* 216:228 */     TypeRegistry.getTypeRegistry().addType("RequestPacket", i.getClass(), i);
/* 217:    */   }
/* 218:    */   
/* 219:    */   public Object readInstance(DataInput input, String name)
/* 220:    */     throws IOException
/* 221:    */   {
/* 222:236 */     if (name.equals("RequestPacket"))
/* 223:    */     {
/* 224:238 */       RDOSerializer rdoSerializer = new RDOSerializer();
/* 225:239 */       RDO rdo = (RDO)rdoSerializer.readInstance(input);
/* 226:    */       
/* 227:241 */       RequestPacket reqPacket = new RequestPacket(rdo);
/* 228:    */       
/* 229:    */ 
/* 230:244 */       int noOfHeaderFields = input.readInt();
/* 231:245 */       for (int i = 0; i < noOfHeaderFields; i++)
/* 232:    */       {
/* 233:247 */         String headerField = input.readUTF();
/* 234:248 */         String headerFieldValue = input.readUTF();
/* 235:249 */         reqPacket.setHeaderField(headerField, headerFieldValue);
/* 236:    */       }
/* 237:255 */       return reqPacket;
/* 238:    */     }
/* 239:258 */     throw new RuntimeException("The type " + name + " not supported.");
/* 240:    */   }
/* 241:    */   
/* 242:    */   public void writeInstance(DataOutput output, Object obj)
/* 243:    */     throws IOException
/* 244:    */   {
/* 245:266 */     if ((obj instanceof RequestPacket))
/* 246:    */     {
/* 247:268 */       RDOSerializer rdoSerializer = new RDOSerializer();
/* 248:269 */       RequestPacket reqPacket = (RequestPacket)obj;
/* 249:270 */       rdoSerializer.writeInstance(output, reqPacket.getRDO());
/* 250:    */       
/* 251:    */ 
/* 252:273 */       int noOfHeaderFields = reqPacket.headers.size();
/* 253:274 */       output.writeInt(noOfHeaderFields);
/* 254:275 */       Enumeration keyEnum = reqPacket.headers.keys();
/* 255:276 */       while (keyEnum.hasMoreElements())
/* 256:    */       {
/* 257:278 */         String headerField = (String)keyEnum.nextElement();
/* 258:279 */         String headerFieldValue = (String)reqPacket.headers.get(headerField);
/* 259:280 */         output.writeUTF(headerField);
/* 260:281 */         output.writeUTF(headerFieldValue);
/* 261:    */       }
/* 262:    */     }
/* 263:    */   }
/* 264:    */   
/* 265:    */   public static RDOInfo getRequestPacketInfo()
/* 266:    */   {
/* 267:288 */     DefaultRDOInfo reqPacketInfo = new DefaultRDOInfo();
/* 268:289 */     reqPacketInfo.setName("REQUEST");
/* 269:    */     
/* 270:291 */     DefaultRDOAttributeInfo attr0 = new DefaultRDOAttributeInfo();
/* 271:292 */     attr0.setName("ID");
/* 272:293 */     attr0.setKey(true);
/* 273:    */     
/* 274:295 */     DefaultRDOAttributeInfo attr1 = new DefaultRDOAttributeInfo();
/* 275:296 */     attr1.setName("APPNAME");
/* 276:297 */     attr1.setKey(false);
/* 277:    */     
/* 278:299 */     DefaultRDOAttributeInfo attr2 = new DefaultRDOAttributeInfo();
/* 279:300 */     attr2.setName("OPERATION");
/* 280:    */     
/* 281:302 */     DefaultRDOAttributeInfo attr3 = new DefaultRDOAttributeInfo();
/* 282:303 */     attr3.setName("PARAMETERS");
/* 283:304 */     attr3.setDataType(12);
/* 284:    */     
/* 285:306 */     DefaultRDOAttributeInfo attr4 = new DefaultRDOAttributeInfo();
/* 286:307 */     attr4.setName("INVOCATIONTYPE");
/* 287:308 */     attr4.setDataType(4);
/* 288:    */     
/* 289:310 */     DefaultRDOAttributeInfo attr5 = new DefaultRDOAttributeInfo();
/* 290:311 */     attr5.setName("ADDLDATA");
/* 291:312 */     attr5.setDataType(12);
/* 292:    */     
/* 293:314 */     DefaultRDOAttributeInfo attr6 = new DefaultRDOAttributeInfo();
/* 294:315 */     attr6.setName("CORRELATIONID");
/* 295:316 */     attr6.setLength(100);
/* 296:    */     
/* 297:318 */     reqPacketInfo.addAttributeInfo(attr0);
/* 298:319 */     reqPacketInfo.addAttributeInfo(attr1);
/* 299:320 */     reqPacketInfo.addAttributeInfo(attr2);
/* 300:321 */     reqPacketInfo.addAttributeInfo(attr3);
/* 301:322 */     reqPacketInfo.addAttributeInfo(attr4);
/* 302:323 */     reqPacketInfo.addAttributeInfo(attr5);
/* 303:324 */     reqPacketInfo.addAttributeInfo(attr6);
/* 304:    */     
/* 305:326 */     return reqPacketInfo;
/* 306:    */   }
/* 307:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.comm.RequestPacket
 * JD-Core Version:    0.7.0.1
 */