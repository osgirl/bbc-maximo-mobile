/*   1:    */ package com.mro.mobile;
/*   2:    */ 
/*   3:    */ public abstract class MobileMessageGenerator
/*   4:    */ {
/*   5: 22 */   private static MobileMessageGenerator defaultGenerator = null;
/*   6:    */   
/*   7:    */   public abstract String generateMessage(String paramString, Object[] paramArrayOfObject);
/*   8:    */   
/*   9:    */   public abstract String substituteParams(String paramString, Object[] paramArrayOfObject);
/*  10:    */   
/*  11:    */   public abstract boolean isStringPattern(String paramString1, String paramString2);
/*  12:    */   
/*  13:    */   public static String generate(String key, Object[] params)
/*  14:    */   {
/*  15: 30 */     MobileMessageGenerator g = getMessageGenerator();
/*  16: 31 */     if (g != null) {
/*  17: 33 */       return removeDoubleApostrophe(g.generateMessage(key, params));
/*  18:    */     }
/*  19: 36 */     return removeDoubleApostrophe(generateSimpleMessage(key, params));
/*  20:    */   }
/*  21:    */   
/*  22:    */   public static String generateSimpleMessage(String key, Object[] params)
/*  23:    */   {
/*  24: 43 */     String message = key;
/*  25:    */     
/*  26:    */ 
/*  27: 46 */     String paramMessage = "";
/*  28: 47 */     if (params != null)
/*  29:    */     {
/*  30: 49 */       StringBuffer sbParamMessage = new StringBuffer();
/*  31: 50 */       for (int i = 0; i < params.length; i++) {
/*  32: 53 */         sbParamMessage.append("param[").append(i).append("] = ").append(params[i]).append("; ");
/*  33:    */       }
/*  34: 59 */       paramMessage = sbParamMessage.toString();
/*  35: 62 */       if (params.length > 0) {
/*  36: 64 */         message = key + " - " + paramMessage;
/*  37:    */       }
/*  38:    */     }
/*  39: 68 */     return message;
/*  40:    */   }
/*  41:    */   
/*  42:    */   public static String generateDirectMessage(String message, Object[] params)
/*  43:    */   {
/*  44: 73 */     MobileMessageGenerator g = getMessageGenerator();
/*  45: 74 */     if (g != null) {
/*  46: 76 */       return g.substituteParams(message, params);
/*  47:    */     }
/*  48: 78 */     return message;
/*  49:    */   }
/*  50:    */   
/*  51:    */   public static MobileMessageGenerator getMessageGenerator()
/*  52:    */   {
/*  53: 84 */     return defaultGenerator;
/*  54:    */   }
/*  55:    */   
/*  56:    */   public static void setMessageGenerator(MobileMessageGenerator generator)
/*  57:    */   {
/*  58: 89 */     defaultGenerator = generator;
/*  59:    */   }
/*  60:    */   
/*  61:    */   private static String removeDoubleApostrophe(String stringToProcess)
/*  62:    */   {
/*  63: 97 */     if (stringToProcess == null) {
/*  64: 99 */       return stringToProcess;
/*  65:    */     }
/*  66:101 */     int pos = stringToProcess.indexOf("''");
/*  67:102 */     int initPos = 0;
/*  68:107 */     if (pos == -1) {
/*  69:109 */       return stringToProcess;
/*  70:    */     }
/*  71:111 */     StringBuffer result = new StringBuffer();
/*  72:113 */     while (pos > -1)
/*  73:    */     {
/*  74:115 */       result.append(stringToProcess.substring(initPos, ++pos));
/*  75:116 */       pos++;
/*  76:117 */       initPos = pos;
/*  77:    */       
/*  78:119 */       pos = stringToProcess.indexOf("''", pos);
/*  79:    */     }
/*  80:121 */     result.append(stringToProcess.substring(initPos));
/*  81:122 */     return result.toString();
/*  82:    */   }
/*  83:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.MobileMessageGenerator
 * JD-Core Version:    0.7.0.1
 */