package com.mro.mobile;

public abstract interface MobileContext
{
  public abstract String getAppName()
    throws MobileApplicationException;
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.MobileContext
 * JD-Core Version:    0.7.0.1
 */