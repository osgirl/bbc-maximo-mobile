package com.mro.mobile;

import com.mro.mobile.mbo.MobileMbo;
import com.mro.mobile.mbo.MobileMboChange;
import com.mro.mobile.mbo.MobileMboData;
import com.mro.mobile.mbo.MobileMboOrder;
import com.mro.mobile.mbo.MobileMboQBE;

public abstract interface DefaultMobileWebService
{
  public abstract MobileMetaData getMobileMetaData()
    throws MobileApplicationException;
  
  public abstract MobileMboData getMobileMbos(String paramString, Integer paramInteger1, Integer paramInteger2)
    throws MobileApplicationException;
  
  public abstract MobileMboData getMobileMbos(String paramString, Integer paramInteger1, Integer paramInteger2, MobileMboQBE paramMobileMboQBE, MobileMboOrder paramMobileMboOrder)
    throws MobileApplicationException;
  
  public abstract int getMobileMboCount(String paramString)
    throws MobileApplicationException;
  
  public abstract int getMobileMboCount(String paramString, MobileMboQBE paramMobileMboQBE)
    throws MobileApplicationException;
  
  public abstract MobileMboData getAppOptionsAuth(Integer paramInteger1, Integer paramInteger2)
    throws MobileApplicationException;
  
  public abstract MobileMboData getIncrementalUpdateOfMobileMbos(String paramString, Integer paramInteger1, Integer paramInteger2)
    throws MobileApplicationException;
  
  public abstract MobileMboData getIncrementalUpdateOfMobileMbos(String paramString, String[] paramArrayOfString, Integer paramInteger1, Integer paramInteger2)
    throws MobileApplicationException;
  
  public abstract MobileMboData getIncrementalUpdateOfMobileMbos(String paramString, String[] paramArrayOfString, Integer paramInteger1, Integer paramInteger2, Boolean paramBoolean)
    throws MobileApplicationException;
  
  public abstract void acknowledgeIncrementalUpdate(String paramString)
    throws MobileApplicationException;
  
  public abstract void performDataTransaction(MobileMboChange paramMobileMboChange)
    throws MobileApplicationException;
  
  public abstract void performDataTransactionGivenUpOnError(MobileMboChange paramMobileMboChange)
    throws MobileApplicationException;
  
  public abstract MobileMboData getDataTransactionResult(Integer paramInteger1, Integer paramInteger2)
    throws MobileApplicationException;
  
  public abstract void acknowledgeDataTransactionResult()
    throws MobileApplicationException;
  
  public abstract void hello()
    throws MobileApplicationException;
  
  public abstract String getVersion()
    throws MobileApplicationException;
  
  public abstract boolean hasPendingTransactions()
    throws MobileApplicationException;
  
  public abstract boolean hasPendingErrorTransactions()
    throws MobileApplicationException;
  
  public abstract void logESigVerification(MobileMboChange paramMobileMboChange)
    throws MobileApplicationException;
  
  public abstract String[] getSmartSystemRefreshOrder()
    throws MobileApplicationException;
  
  public abstract String[] getSystemRefreshOrder()
    throws MobileApplicationException;
  
  public abstract String[] getSmartRefreshOrder(String[] paramArrayOfString)
    throws MobileApplicationException;
  
  public abstract String[] getRefreshOrder()
    throws MobileApplicationException;
  
  public abstract String[] getSmartWorkRefreshOrder(String[] paramArrayOfString)
    throws MobileApplicationException;
  
  public abstract String[] getWorkRefreshOrder()
    throws MobileApplicationException;
  
  public abstract void changePassword(String paramString1, String paramString2)
    throws MobileApplicationException;
  
  public abstract boolean isPasswordExpired()
    throws MobileApplicationException;
  
  public abstract void changeExpiredPassword(String paramString1, String paramString2)
    throws MobileApplicationException;
  
  public abstract String[] getAdHocRefreshOrder(String paramString)
    throws MobileApplicationException;
  
  public abstract MobileMboData getAdHocMobileMbo(String paramString1, String paramString2)
    throws MobileApplicationException;
  
  public abstract void createAdHocQuery(String paramString1, String paramString2)
    throws MobileApplicationException;
  
  public abstract void createAdHocQuery(String paramString1, String paramString2, String paramString3)
    throws MobileApplicationException;
  
  public abstract void removeAdHocQueryList()
    throws MobileApplicationException;
  
  public abstract void acknowledgeAdHocRecordData(String paramString1, String paramString2)
    throws MobileApplicationException;
  
  public abstract boolean hasAdHocData()
    throws MobileApplicationException;
  
  public abstract MobileMbo getLatestTransactionData(MobileMbo paramMobileMbo)
    throws MobileApplicationException;
  
  public abstract void cleanupErrTransactionData(MobileMbo paramMobileMbo)
    throws MobileApplicationException;
  
  public abstract void addSnapshotChunk(Integer paramInteger, byte[] paramArrayOfByte)
    throws MobileApplicationException;
  
  public abstract void storeSnapshotChunks(String paramString)
    throws MobileApplicationException;
  
  public abstract void storeSnapshot(byte[] paramArrayOfByte, String paramString)
    throws MobileApplicationException;
  
  public abstract byte[] retrieveSnapshot()
    throws MobileApplicationException;
  
  public abstract void removeSnapshot()
    throws MobileApplicationException;
  
  public abstract int getSnapshotChunks(int paramInt)
    throws MobileApplicationException;
  
  public abstract byte[] retrieveSnapshotChunk(int paramInt)
    throws MobileApplicationException;
  
  public abstract int checkForUpdate(String paramString1, String paramString2, String paramString3)
    throws MobileApplicationException;
  
  public abstract MobileMbo getUpdateJar(String paramString1, String paramString2)
    throws MobileApplicationException;
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.DefaultMobileWebService
 * JD-Core Version:    0.7.0.1
 */