/*  1:   */ package com.mro.mobile.sensor.rfid;
/*  2:   */ 
/*  3:   */ import com.mro.mobile.MobileApplicationException;
/*  4:   */ import com.mro.mobile.util.MobileLogger;
/*  5:   */ import com.mro.mobile.util.MobileLoggerFactory;
/*  6:   */ import java.util.ArrayList;
/*  7:   */ 
/*  8:   */ public abstract class AbstractRFIDReader
/*  9:   */   implements MobileRFIDReader
/* 10:   */ {
/* 11:22 */   private ArrayList listeners = new ArrayList();
/* 12:   */   
/* 13:   */   public void addRFIDReadListener(MobileRFIDReadListener listener)
/* 14:   */   {
/* 15:25 */     synchronized (this.listeners)
/* 16:   */     {
/* 17:26 */       if (this.listeners.contains(listener)) {
/* 18:27 */         return;
/* 19:   */       }
/* 20:29 */       this.listeners.add(listener);
/* 21:   */     }
/* 22:   */   }
/* 23:   */   
/* 24:   */   public void removeRFIDReadListener(MobileRFIDReadListener listener)
/* 25:   */   {
/* 26:34 */     this.listeners.remove(listener);
/* 27:   */   }
/* 28:   */   
/* 29:   */   public void fireRFIDReadSuccessEvent(MobileRFIDEvent event)
/* 30:   */   {
/* 31:38 */     synchronized (this.listeners)
/* 32:   */     {
/* 33:39 */       int size = this.listeners.size();
/* 34:40 */       for (int i = 0; i < size; i++)
/* 35:   */       {
/* 36:41 */         MobileRFIDReadListener listener = (MobileRFIDReadListener)this.listeners.get(i);
/* 37:   */         
/* 38:43 */         listener.RFIDReadSuccess(event);
/* 39:   */       }
/* 40:   */     }
/* 41:   */   }
/* 42:   */   
/* 43:   */   public void fireRFIDReadErrorEvent(MobileRFIDEvent event)
/* 44:   */   {
/* 45:   */     try
/* 46:   */     {
/* 47:50 */       synchronized (this.listeners)
/* 48:   */       {
/* 49:51 */         int size = this.listeners.size();
/* 50:52 */         for (int i = 0; i < size; i++)
/* 51:   */         {
/* 52:53 */           MobileRFIDReadListener listener = (MobileRFIDReadListener)this.listeners.get(i);
/* 53:   */           
/* 54:55 */           listener.RFIDReadFailure(event);
/* 55:   */         }
/* 56:   */       }
/* 57:   */     }
/* 58:   */     catch (RuntimeException e)
/* 59:   */     {
/* 60:59 */       MobileLoggerFactory.getDefaultLogger().warn("Error encountered during RFID read error event", e);
/* 61:   */     }
/* 62:   */   }
/* 63:   */   
/* 64:   */   public abstract void initialize()
/* 65:   */     throws MobileApplicationException;
/* 66:   */   
/* 67:   */   public void startScan()
/* 68:   */     throws MobileApplicationException
/* 69:   */   {}
/* 70:   */   
/* 71:   */   public void stopScan()
/* 72:   */     throws MobileApplicationException
/* 73:   */   {}
/* 74:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.sensor.rfid.AbstractRFIDReader
 * JD-Core Version:    0.7.0.1
 */