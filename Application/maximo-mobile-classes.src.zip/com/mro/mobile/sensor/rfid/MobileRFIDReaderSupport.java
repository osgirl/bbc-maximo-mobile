package com.mro.mobile.sensor.rfid;

public abstract interface MobileRFIDReaderSupport
{
  public abstract boolean isRFIDEnabled();
  
  public abstract MobileRFIDReaderWrapper getRFIDReaderSupport();
  
  public abstract void releaseRFIDReader();
  
  public abstract void activateRFIDReader(MobileRFIDReadListener paramMobileRFIDReadListener);
  
  public abstract void removeRFIDListener(MobileRFIDReadListener paramMobileRFIDReadListener);
  
  public abstract void deactivateRFIDReader(MobileRFIDReadListener paramMobileRFIDReadListener);
  
  public abstract void plugRFIDReaderSupport(MobileRFIDReaderWrapper paramMobileRFIDReaderWrapper);
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.sensor.rfid.MobileRFIDReaderSupport
 * JD-Core Version:    0.7.0.1
 */