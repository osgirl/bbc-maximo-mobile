/*  1:   */ package com.mro.mobile.sensor.rfid;
/*  2:   */ 
/*  3:   */ import java.util.ArrayList;
/*  4:   */ import java.util.List;
/*  5:   */ 
/*  6:   */ public class MobileRFIDEvent
/*  7:   */ {
/*  8:23 */   private Object nativeEvent = null;
/*  9:24 */   private List data = null;
/* 10:25 */   private Exception exception = null;
/* 11:   */   
/* 12:   */   public MobileRFIDEvent(Object nativeEvent, List data)
/* 13:   */   {
/* 14:29 */     this.nativeEvent = nativeEvent;
/* 15:30 */     this.data = data;
/* 16:   */   }
/* 17:   */   
/* 18:   */   public MobileRFIDEvent(Object nativeEvent, String data)
/* 19:   */   {
/* 20:35 */     this.nativeEvent = nativeEvent;
/* 21:36 */     this.data = new ArrayList();
/* 22:37 */     this.data.add(data);
/* 23:   */   }
/* 24:   */   
/* 25:   */   public MobileRFIDEvent(Exception ex)
/* 26:   */   {
/* 27:42 */     this.exception = ex;
/* 28:   */   }
/* 29:   */   
/* 30:   */   public Object getNativeEvent()
/* 31:   */   {
/* 32:47 */     return this.nativeEvent;
/* 33:   */   }
/* 34:   */   
/* 35:   */   public String getData()
/* 36:   */   {
/* 37:52 */     return (this.data != null) && (!this.data.isEmpty()) ? this.data.get(0).toString() : null;
/* 38:   */   }
/* 39:   */   
/* 40:   */   public List getListData()
/* 41:   */   {
/* 42:56 */     return this.data;
/* 43:   */   }
/* 44:   */   
/* 45:   */   public Exception getError()
/* 46:   */   {
/* 47:61 */     return this.exception;
/* 48:   */   }
/* 49:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.sensor.rfid.MobileRFIDEvent
 * JD-Core Version:    0.7.0.1
 */