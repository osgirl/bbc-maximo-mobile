package com.mro.mobile.sensor.rfid;

public abstract interface MobileRFIDReadListener
{
  public abstract void RFIDReadSuccess(MobileRFIDEvent paramMobileRFIDEvent);
  
  public abstract void RFIDReadFailure(MobileRFIDEvent paramMobileRFIDEvent);
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.sensor.rfid.MobileRFIDReadListener
 * JD-Core Version:    0.7.0.1
 */