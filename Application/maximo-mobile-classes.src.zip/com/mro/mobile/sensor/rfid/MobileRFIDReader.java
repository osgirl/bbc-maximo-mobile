package com.mro.mobile.sensor.rfid;

import com.mro.mobile.MobileApplicationException;

public abstract interface MobileRFIDReader
{
  public abstract void initialize()
    throws MobileApplicationException;
  
  public abstract void release()
    throws MobileApplicationException;
  
  public abstract void startScan()
    throws MobileApplicationException;
  
  public abstract void stopScan()
    throws MobileApplicationException;
  
  public abstract void addRFIDReadListener(MobileRFIDReadListener paramMobileRFIDReadListener);
  
  public abstract void removeRFIDReadListener(MobileRFIDReadListener paramMobileRFIDReadListener);
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.sensor.rfid.MobileRFIDReader
 * JD-Core Version:    0.7.0.1
 */