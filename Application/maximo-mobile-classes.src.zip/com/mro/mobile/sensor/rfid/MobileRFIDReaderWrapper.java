/*   1:    */ package com.mro.mobile.sensor.rfid;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ 
/*   5:    */ public abstract class MobileRFIDReaderWrapper
/*   6:    */ {
/*   7:    */   private MobileRFIDReader reader;
/*   8: 16 */   private boolean started = false;
/*   9:    */   private String builtinAliasOrClassName;
/*  10: 20 */   private boolean initialized = false;
/*  11:    */   
/*  12:    */   public MobileRFIDReaderWrapper(String builtinAliasOrClassName)
/*  13:    */   {
/*  14: 34 */     this.builtinAliasOrClassName = builtinAliasOrClassName;
/*  15:    */   }
/*  16:    */   
/*  17:    */   protected abstract MobileRFIDReader createMobileRFIDReader(String paramString);
/*  18:    */   
/*  19:    */   public void initialize()
/*  20:    */   {
/*  21: 58 */     if (this.initialized) {
/*  22: 59 */       throw new IllegalStateException("RFID scanner is already initialized");
/*  23:    */     }
/*  24: 61 */     this.reader = createMobileRFIDReader(this.builtinAliasOrClassName);
/*  25: 62 */     this.initialized = true;
/*  26:    */   }
/*  27:    */   
/*  28:    */   public void addRFIDReadListener(MobileRFIDReadListener listener)
/*  29:    */   {
/*  30: 74 */     if (isEnabled()) {
/*  31: 75 */       this.reader.addRFIDReadListener(listener);
/*  32:    */     } else {
/*  33: 78 */       throw new IllegalStateException("RFID scanner not enabled");
/*  34:    */     }
/*  35:    */   }
/*  36:    */   
/*  37:    */   public void startScan()
/*  38:    */     throws MobileApplicationException
/*  39:    */   {
/*  40: 88 */     if ((isEnabled()) && (!isStarted()))
/*  41:    */     {
/*  42: 89 */       this.reader.startScan();
/*  43:    */     }
/*  44:    */     else
/*  45:    */     {
/*  46: 92 */       if (isStarted()) {
/*  47: 93 */         throw new IllegalStateException("RFID scanner already started");
/*  48:    */       }
/*  49: 95 */       throw new IllegalStateException("RFID scanner not enabled");
/*  50:    */     }
/*  51:    */   }
/*  52:    */   
/*  53:    */   public MobileRFIDReader getRFIDReader()
/*  54:    */   {
/*  55:103 */     return this.reader;
/*  56:    */   }
/*  57:    */   
/*  58:    */   public boolean isEnabled()
/*  59:    */   {
/*  60:110 */     return this.reader != null;
/*  61:    */   }
/*  62:    */   
/*  63:    */   public boolean isStarted()
/*  64:    */   {
/*  65:117 */     return this.started;
/*  66:    */   }
/*  67:    */   
/*  68:    */   public void release()
/*  69:    */     throws MobileApplicationException
/*  70:    */   {
/*  71:124 */     if (isEnabled())
/*  72:    */     {
/*  73:125 */       this.reader.release();
/*  74:126 */       this.reader = null;
/*  75:    */     }
/*  76:    */   }
/*  77:    */   
/*  78:    */   public void removeRFIDReadListener(MobileRFIDReadListener listener)
/*  79:    */   {
/*  80:134 */     if (isEnabled()) {
/*  81:135 */       this.reader.removeRFIDReadListener(listener);
/*  82:    */     }
/*  83:    */   }
/*  84:    */   
/*  85:    */   public void stopScan()
/*  86:    */     throws MobileApplicationException
/*  87:    */   {
/*  88:144 */     if (isEnabled())
/*  89:    */     {
/*  90:145 */       this.reader.stopScan();
/*  91:146 */       this.started = false;
/*  92:    */     }
/*  93:    */   }
/*  94:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.sensor.rfid.MobileRFIDReaderWrapper
 * JD-Core Version:    0.7.0.1
 */