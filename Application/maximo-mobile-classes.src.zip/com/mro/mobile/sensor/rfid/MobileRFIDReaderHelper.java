/*  1:   */ package com.mro.mobile.sensor.rfid;
/*  2:   */ 
/*  3:   */ import com.mro.mobile.MobileApplicationException;
/*  4:   */ import com.mro.mobile.ui.res.UIUtil;
/*  5:   */ import com.mro.mobile.util.MobileLogger;
/*  6:   */ import com.mro.mobile.util.MobileLoggerFactory;
/*  7:   */ 
/*  8:   */ public class MobileRFIDReaderHelper
/*  9:   */   implements MobileRFIDReaderSupport
/* 10:   */ {
/* 11:   */   private MobileRFIDReaderWrapper rfidReaderWapper;
/* 12:   */   
/* 13:   */   public MobileRFIDReaderHelper()
/* 14:   */   {
/* 15:13 */     this(null);
/* 16:   */   }
/* 17:   */   
/* 18:   */   public MobileRFIDReaderHelper(MobileRFIDReaderWrapper rfidReaderWrapper)
/* 19:   */   {
/* 20:17 */     this.rfidReaderWapper = rfidReaderWrapper;
/* 21:   */   }
/* 22:   */   
/* 23:   */   public boolean isRFIDEnabled()
/* 24:   */   {
/* 25:21 */     return (this.rfidReaderWapper != null) && (this.rfidReaderWapper.isEnabled());
/* 26:   */   }
/* 27:   */   
/* 28:   */   public MobileRFIDReaderWrapper getRFIDReaderSupport()
/* 29:   */   {
/* 30:25 */     return this.rfidReaderWapper;
/* 31:   */   }
/* 32:   */   
/* 33:   */   public void releaseRFIDReader()
/* 34:   */   {
/* 35:   */     try
/* 36:   */     {
/* 37:30 */       if (isRFIDEnabled())
/* 38:   */       {
/* 39:31 */         this.rfidReaderWapper.release();
/* 40:32 */         this.rfidReaderWapper = null;
/* 41:   */       }
/* 42:   */     }
/* 43:   */     catch (Exception e)
/* 44:   */     {
/* 45:35 */       MobileLoggerFactory.getDefaultLogger().warn("Failed to release RFID reader", e);
/* 46:   */     }
/* 47:   */   }
/* 48:   */   
/* 49:   */   public void activateRFIDReader(MobileRFIDReadListener listener)
/* 50:   */   {
/* 51:40 */     if (isRFIDEnabled()) {
/* 52:   */       try
/* 53:   */       {
/* 54:42 */         MobileRFIDReaderWrapper reader = getRFIDReaderSupport();
/* 55:43 */         reader.addRFIDReadListener(listener);
/* 56:44 */         reader.startScan();
/* 57:   */       }
/* 58:   */       catch (MobileApplicationException e)
/* 59:   */       {
/* 60:46 */         UIUtil.showFailureMessageBox(e.getCompleteMessage());
/* 61:47 */         MobileLoggerFactory.getDefaultLogger().warn("Failed to activate RFID reader", e);
/* 62:   */       }
/* 63:   */     }
/* 64:   */   }
/* 65:   */   
/* 66:   */   public void removeRFIDListener(MobileRFIDReadListener listener)
/* 67:   */   {
/* 68:53 */     if (isRFIDEnabled()) {
/* 69:54 */       getRFIDReaderSupport().removeRFIDReadListener(listener);
/* 70:   */     }
/* 71:   */   }
/* 72:   */   
/* 73:   */   public void deactivateRFIDReader(MobileRFIDReadListener listener)
/* 74:   */   {
/* 75:59 */     if (isRFIDEnabled()) {
/* 76:   */       try
/* 77:   */       {
/* 78:61 */         MobileRFIDReaderWrapper reader = getRFIDReaderSupport();
/* 79:62 */         reader.stopScan();
/* 80:63 */         if (listener != null) {
/* 81:64 */           reader.removeRFIDReadListener(listener);
/* 82:   */         }
/* 83:   */       }
/* 84:   */       catch (MobileApplicationException e)
/* 85:   */       {
/* 86:66 */         UIUtil.showFailureMessageBox(e.getCompleteMessage());
/* 87:67 */         MobileLoggerFactory.getDefaultLogger().warn("Failed to deactivate RFID reader", e);
/* 88:   */       }
/* 89:   */     }
/* 90:   */   }
/* 91:   */   
/* 92:   */   public void plugRFIDReaderSupport(MobileRFIDReaderWrapper rfidReaderSupport)
/* 93:   */   {
/* 94:73 */     if (!isRFIDEnabled()) {
/* 95:74 */       this.rfidReaderWapper = rfidReaderSupport;
/* 96:   */     }
/* 97:   */   }
/* 98:   */   
/* 99:   */   public void initialize()
/* :0:   */   {
/* :1:79 */     if (this.rfidReaderWapper != null) {
/* :2:80 */       this.rfidReaderWapper.initialize();
/* :3:   */     }
/* :4:   */   }
/* :5:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.sensor.rfid.MobileRFIDReaderHelper
 * JD-Core Version:    0.7.0.1
 */