/*  1:   */ package com.mro.mobile.sensor.barcode;
/*  2:   */ 
/*  3:   */ public class MobileBarcodeEvent
/*  4:   */ {
/*  5:18 */   private Object nativeEvent = null;
/*  6:19 */   private String data = null;
/*  7:20 */   private Exception exception = null;
/*  8:   */   
/*  9:   */   public MobileBarcodeEvent(Object nativeEvent, String data)
/* 10:   */   {
/* 11:24 */     this.nativeEvent = nativeEvent;
/* 12:25 */     this.data = data;
/* 13:   */   }
/* 14:   */   
/* 15:   */   public MobileBarcodeEvent(Exception ex)
/* 16:   */   {
/* 17:30 */     this.exception = ex;
/* 18:   */   }
/* 19:   */   
/* 20:   */   public Object getNativeEvent()
/* 21:   */   {
/* 22:35 */     return this.nativeEvent;
/* 23:   */   }
/* 24:   */   
/* 25:   */   public String getData()
/* 26:   */   {
/* 27:40 */     return this.data;
/* 28:   */   }
/* 29:   */   
/* 30:   */   public Exception getError()
/* 31:   */   {
/* 32:45 */     return this.exception;
/* 33:   */   }
/* 34:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.sensor.barcode.MobileBarcodeEvent
 * JD-Core Version:    0.7.0.1
 */