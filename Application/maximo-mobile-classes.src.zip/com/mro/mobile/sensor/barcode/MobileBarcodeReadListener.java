package com.mro.mobile.sensor.barcode;

public abstract interface MobileBarcodeReadListener
{
  public abstract void barcodeReadSuccess(MobileBarcodeEvent paramMobileBarcodeEvent);
  
  public abstract void barcodeReadError(MobileBarcodeEvent paramMobileBarcodeEvent);
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.sensor.barcode.MobileBarcodeReadListener
 * JD-Core Version:    0.7.0.1
 */