package com.mro.mobile.sensor.barcode;

public abstract interface MobileBarcodeReaderSupport
{
  public abstract boolean isBarcodeEnabled();
  
  public abstract MobileBarcodeReaderWrapper getBarcodeReaderSupport();
  
  public abstract void releaseBarcodeReader();
  
  public abstract void activateBarCodeReader(MobileBarcodeReadListener paramMobileBarcodeReadListener);
  
  public abstract void removeBarCodeListener(MobileBarcodeReadListener paramMobileBarcodeReadListener);
  
  public abstract void deactivateBarCodeReader(MobileBarcodeReadListener paramMobileBarcodeReadListener);
  
  public abstract void plugBarcodeReaderSupport(MobileBarcodeReaderWrapper paramMobileBarcodeReaderWrapper);
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.sensor.barcode.MobileBarcodeReaderSupport
 * JD-Core Version:    0.7.0.1
 */