package com.mro.mobile.sensor.barcode;

import com.mro.mobile.MobileApplicationException;

public abstract interface MobileBarcodeReader
{
  public abstract void initialize()
    throws MobileApplicationException;
  
  public abstract void release()
    throws MobileApplicationException;
  
  public abstract void startScan()
    throws MobileApplicationException;
  
  public abstract void stopScan()
    throws MobileApplicationException;
  
  public abstract void addBarcodeReadListener(MobileBarcodeReadListener paramMobileBarcodeReadListener);
  
  public abstract void removeBarcodeReadListener(MobileBarcodeReadListener paramMobileBarcodeReadListener);
  
  public abstract boolean isIntentBased();
  
  public abstract void launchIntent();
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.sensor.barcode.MobileBarcodeReader
 * JD-Core Version:    0.7.0.1
 */