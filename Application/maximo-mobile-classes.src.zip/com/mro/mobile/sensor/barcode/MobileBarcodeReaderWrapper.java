/*   1:    */ package com.mro.mobile.sensor.barcode;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ 
/*   5:    */ public abstract class MobileBarcodeReaderWrapper
/*   6:    */ {
/*   7:    */   private MobileBarcodeReader reader;
/*   8: 16 */   private boolean started = false;
/*   9:    */   private String builtinAliasOrClassName;
/*  10: 20 */   private boolean initialized = false;
/*  11:    */   
/*  12:    */   public MobileBarcodeReaderWrapper(String builtinAliasOrClassName)
/*  13:    */   {
/*  14: 37 */     this.builtinAliasOrClassName = builtinAliasOrClassName;
/*  15:    */   }
/*  16:    */   
/*  17:    */   protected abstract MobileBarcodeReader createMobileBarcodeReader(String paramString);
/*  18:    */   
/*  19:    */   public void initialize()
/*  20:    */   {
/*  21: 66 */     if (this.initialized) {
/*  22: 67 */       throw new IllegalStateException("Barcode scanner is already initialized");
/*  23:    */     }
/*  24: 69 */     this.reader = createMobileBarcodeReader(this.builtinAliasOrClassName);
/*  25: 70 */     this.initialized = true;
/*  26:    */   }
/*  27:    */   
/*  28:    */   public void addBarcodeReadListener(MobileBarcodeReadListener listener)
/*  29:    */   {
/*  30: 83 */     if (isEnabled()) {
/*  31: 84 */       this.reader.addBarcodeReadListener(listener);
/*  32:    */     } else {
/*  33: 86 */       throw new IllegalStateException("Barcode scanner not enabled");
/*  34:    */     }
/*  35:    */   }
/*  36:    */   
/*  37:    */   public void startScan()
/*  38:    */     throws MobileApplicationException
/*  39:    */   {
/*  40: 98 */     if ((isEnabled()) && (!isStarted()))
/*  41:    */     {
/*  42: 99 */       this.reader.startScan();
/*  43:100 */       this.started = true;
/*  44:    */     }
/*  45:    */     else
/*  46:    */     {
/*  47:102 */       if (isStarted()) {
/*  48:103 */         throw new IllegalStateException("Barcode scanner already started");
/*  49:    */       }
/*  50:105 */       throw new IllegalStateException("Barcode scanner not enabled");
/*  51:    */     }
/*  52:    */   }
/*  53:    */   
/*  54:    */   public MobileBarcodeReader getBarcodeReader()
/*  55:    */   {
/*  56:113 */     return this.reader;
/*  57:    */   }
/*  58:    */   
/*  59:    */   public boolean isEnabled()
/*  60:    */   {
/*  61:120 */     return this.reader != null;
/*  62:    */   }
/*  63:    */   
/*  64:    */   public boolean isStarted()
/*  65:    */   {
/*  66:127 */     return this.started;
/*  67:    */   }
/*  68:    */   
/*  69:    */   public void release()
/*  70:    */     throws MobileApplicationException
/*  71:    */   {
/*  72:135 */     if (isEnabled())
/*  73:    */     {
/*  74:136 */       this.reader.release();
/*  75:137 */       this.reader = null;
/*  76:    */     }
/*  77:    */   }
/*  78:    */   
/*  79:    */   public void removeBarcodeReadListener(MobileBarcodeReadListener listener)
/*  80:    */   {
/*  81:145 */     if (isEnabled()) {
/*  82:146 */       this.reader.removeBarcodeReadListener(listener);
/*  83:    */     }
/*  84:    */   }
/*  85:    */   
/*  86:    */   public void stopScan()
/*  87:    */     throws MobileApplicationException
/*  88:    */   {
/*  89:155 */     if (isEnabled())
/*  90:    */     {
/*  91:156 */       this.reader.stopScan();
/*  92:157 */       this.started = false;
/*  93:    */     }
/*  94:    */   }
/*  95:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.sensor.barcode.MobileBarcodeReaderWrapper
 * JD-Core Version:    0.7.0.1
 */