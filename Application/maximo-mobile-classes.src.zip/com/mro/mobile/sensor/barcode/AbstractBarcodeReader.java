/*  1:   */ package com.mro.mobile.sensor.barcode;
/*  2:   */ 
/*  3:   */ import com.mro.mobile.MobileApplicationException;
/*  4:   */ import java.util.ArrayList;
/*  5:   */ 
/*  6:   */ public abstract class AbstractBarcodeReader
/*  7:   */   implements MobileBarcodeReader
/*  8:   */ {
/*  9:22 */   private ArrayList listeners = new ArrayList();
/* 10:   */   
/* 11:   */   public void addBarcodeReadListener(MobileBarcodeReadListener listener)
/* 12:   */   {
/* 13:25 */     synchronized (this.listeners)
/* 14:   */     {
/* 15:26 */       if (this.listeners.contains(listener)) {
/* 16:27 */         return;
/* 17:   */       }
/* 18:29 */       this.listeners.add(listener);
/* 19:   */     }
/* 20:   */   }
/* 21:   */   
/* 22:   */   public void removeBarcodeReadListener(MobileBarcodeReadListener listener)
/* 23:   */   {
/* 24:34 */     this.listeners.remove(listener);
/* 25:   */   }
/* 26:   */   
/* 27:   */   public void fireBarcodeReadSuccessEvent(MobileBarcodeEvent event)
/* 28:   */   {
/* 29:38 */     synchronized (this.listeners)
/* 30:   */     {
/* 31:39 */       int size = this.listeners.size();
/* 32:40 */       for (int i = 0; i < size; i++)
/* 33:   */       {
/* 34:41 */         MobileBarcodeReadListener listener = (MobileBarcodeReadListener)this.listeners.get(i);
/* 35:42 */         listener.barcodeReadSuccess(event);
/* 36:   */       }
/* 37:   */     }
/* 38:   */   }
/* 39:   */   
/* 40:   */   public void fireBarcodeReadErrorEvent(MobileBarcodeEvent event)
/* 41:   */   {
/* 42:48 */     int size = this.listeners.size();
/* 43:49 */     synchronized (this.listeners)
/* 44:   */     {
/* 45:50 */       for (int i = 0; i < size; i++)
/* 46:   */       {
/* 47:51 */         MobileBarcodeReadListener listener = (MobileBarcodeReadListener)this.listeners.get(i);
/* 48:52 */         listener.barcodeReadError(event);
/* 49:   */       }
/* 50:   */     }
/* 51:   */   }
/* 52:   */   
/* 53:   */   public abstract void initialize()
/* 54:   */     throws MobileApplicationException;
/* 55:   */   
/* 56:   */   public void startScan()
/* 57:   */     throws MobileApplicationException
/* 58:   */   {}
/* 59:   */   
/* 60:   */   public void stopScan()
/* 61:   */     throws MobileApplicationException
/* 62:   */   {}
/* 63:   */   
/* 64:   */   public boolean isIntentBased()
/* 65:   */   {
/* 66:66 */     return false;
/* 67:   */   }
/* 68:   */   
/* 69:   */   public void launchIntent() {}
/* 70:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.sensor.barcode.AbstractBarcodeReader
 * JD-Core Version:    0.7.0.1
 */