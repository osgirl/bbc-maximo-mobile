/*  1:   */ package com.mro.mobile.sensor.barcode;
/*  2:   */ 
/*  3:   */ import com.mro.mobile.MobileApplicationException;
/*  4:   */ import com.mro.mobile.ui.res.UIUtil;
/*  5:   */ import com.mro.mobile.util.MobileLogger;
/*  6:   */ import com.mro.mobile.util.MobileLoggerFactory;
/*  7:   */ 
/*  8:   */ public class MobileBarcodeReaderHelper
/*  9:   */   implements MobileBarcodeReaderSupport
/* 10:   */ {
/* 11:   */   private MobileBarcodeReaderWrapper barcodeReaderWapper;
/* 12:   */   
/* 13:   */   public MobileBarcodeReaderHelper()
/* 14:   */   {
/* 15:12 */     this(null);
/* 16:   */   }
/* 17:   */   
/* 18:   */   public MobileBarcodeReaderHelper(MobileBarcodeReaderWrapper barcodeReaderWrapper)
/* 19:   */   {
/* 20:16 */     this.barcodeReaderWapper = barcodeReaderWrapper;
/* 21:   */   }
/* 22:   */   
/* 23:   */   public boolean isBarcodeEnabled()
/* 24:   */   {
/* 25:20 */     return (this.barcodeReaderWapper != null) && (this.barcodeReaderWapper.isEnabled());
/* 26:   */   }
/* 27:   */   
/* 28:   */   public MobileBarcodeReaderWrapper getBarcodeReaderSupport()
/* 29:   */   {
/* 30:24 */     return this.barcodeReaderWapper;
/* 31:   */   }
/* 32:   */   
/* 33:   */   public void releaseBarcodeReader()
/* 34:   */   {
/* 35:   */     try
/* 36:   */     {
/* 37:29 */       if (isBarcodeEnabled())
/* 38:   */       {
/* 39:30 */         this.barcodeReaderWapper.release();
/* 40:31 */         this.barcodeReaderWapper = null;
/* 41:   */       }
/* 42:   */     }
/* 43:   */     catch (Exception e)
/* 44:   */     {
/* 45:34 */       MobileLoggerFactory.getDefaultLogger().warn("Failed to release barcode reader", e);
/* 46:   */     }
/* 47:   */   }
/* 48:   */   
/* 49:   */   public void activateBarCodeReader(MobileBarcodeReadListener listener)
/* 50:   */   {
/* 51:39 */     if (isBarcodeEnabled()) {
/* 52:   */       try
/* 53:   */       {
/* 54:41 */         MobileBarcodeReaderWrapper reader = getBarcodeReaderSupport();
/* 55:42 */         reader.addBarcodeReadListener(listener);
/* 56:43 */         reader.startScan();
/* 57:   */       }
/* 58:   */       catch (MobileApplicationException e)
/* 59:   */       {
/* 60:45 */         UIUtil.showFailureMessageBox(e.getCompleteMessage());
/* 61:46 */         MobileLoggerFactory.getDefaultLogger().warn("Failed to activate barcode reader", e);
/* 62:   */       }
/* 63:   */     }
/* 64:   */   }
/* 65:   */   
/* 66:   */   public void removeBarCodeListener(MobileBarcodeReadListener listener)
/* 67:   */   {
/* 68:52 */     if (isBarcodeEnabled()) {
/* 69:53 */       getBarcodeReaderSupport().removeBarcodeReadListener(listener);
/* 70:   */     }
/* 71:   */   }
/* 72:   */   
/* 73:   */   public void deactivateBarCodeReader(MobileBarcodeReadListener listener)
/* 74:   */   {
/* 75:58 */     if (isBarcodeEnabled()) {
/* 76:   */       try
/* 77:   */       {
/* 78:60 */         MobileBarcodeReaderWrapper reader = getBarcodeReaderSupport();
/* 79:61 */         reader.stopScan();
/* 80:62 */         if (listener != null) {
/* 81:63 */           reader.removeBarcodeReadListener(listener);
/* 82:   */         }
/* 83:   */       }
/* 84:   */       catch (MobileApplicationException e)
/* 85:   */       {
/* 86:65 */         UIUtil.showFailureMessageBox(e.getCompleteMessage());
/* 87:66 */         MobileLoggerFactory.getDefaultLogger().warn("Failed to deactivate barcode reader", e);
/* 88:   */       }
/* 89:   */     }
/* 90:   */   }
/* 91:   */   
/* 92:   */   public void plugBarcodeReaderSupport(MobileBarcodeReaderWrapper barcodeReaderSupport)
/* 93:   */   {
/* 94:72 */     if (!isBarcodeEnabled()) {
/* 95:73 */       this.barcodeReaderWapper = barcodeReaderSupport;
/* 96:   */     }
/* 97:   */   }
/* 98:   */   
/* 99:   */   public void initialize()
/* :0:   */   {
/* :1:78 */     if (this.barcodeReaderWapper != null) {
/* :2:79 */       this.barcodeReaderWapper.initialize();
/* :3:   */     }
/* :4:   */   }
/* :5:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.sensor.barcode.MobileBarcodeReaderHelper
 * JD-Core Version:    0.7.0.1
 */