/*  1:   */ package com.mro.mobile.util;
/*  2:   */ 
/*  3:   */ public class PlatformIndicator
/*  4:   */ {
/*  5:24 */   public static final PlatformIndicator WINDOWS = new PlatformIndicator();
/*  6:26 */   public static final PlatformIndicator ANDROID = new PlatformIndicator();
/*  7:28 */   private static PlatformIndicator current = WINDOWS;
/*  8:   */   
/*  9:   */   public static void setPlatformIndicator(PlatformIndicator pi)
/* 10:   */   {
/* 11:38 */     current = pi;
/* 12:   */   }
/* 13:   */   
/* 14:   */   public static boolean isWINDOWS()
/* 15:   */   {
/* 16:42 */     return current == WINDOWS;
/* 17:   */   }
/* 18:   */   
/* 19:   */   public static boolean isANDROID()
/* 20:   */   {
/* 21:46 */     return current == ANDROID;
/* 22:   */   }
/* 23:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.util.PlatformIndicator
 * JD-Core Version:    0.7.0.1
 */