/*   1:    */ package com.mro.mobile.util;
/*   2:    */ 
/*   3:    */ public class Base64
/*   4:    */ {
/*   5:    */   static final int CHUNK_SIZE = 76;
/*   6: 60 */   static final byte[] CHUNK_SEPARATOR = "\r\n".getBytes();
/*   7:    */   static final int BASELENGTH = 255;
/*   8:    */   static final int LOOKUPLENGTH = 64;
/*   9:    */   static final int EIGHTBIT = 8;
/*  10:    */   static final int SIXTEENBIT = 16;
/*  11:    */   static final int TWENTYFOURBITGROUP = 24;
/*  12:    */   static final int FOURBYTE = 4;
/*  13:    */   static final int SIGN = -128;
/*  14:    */   static final byte PAD = 61;
/*  15:104 */   private static byte[] base64Alphabet = new byte['ÿ'];
/*  16:105 */   private static byte[] lookUpBase64Alphabet = new byte[64];
/*  17:    */   
/*  18:    */   static
/*  19:    */   {
/*  20:109 */     for (int i = 0; i < 255; i++) {
/*  21:110 */       base64Alphabet[i] = -1;
/*  22:    */     }
/*  23:112 */     for (int i = 90; i >= 65; i--) {
/*  24:113 */       base64Alphabet[i] = ((byte)(i - 65));
/*  25:    */     }
/*  26:115 */     for (int i = 122; i >= 97; i--) {
/*  27:116 */       base64Alphabet[i] = ((byte)(i - 97 + 26));
/*  28:    */     }
/*  29:118 */     for (int i = 57; i >= 48; i--) {
/*  30:119 */       base64Alphabet[i] = ((byte)(i - 48 + 52));
/*  31:    */     }
/*  32:122 */     base64Alphabet[43] = 62;
/*  33:123 */     base64Alphabet[47] = 63;
/*  34:125 */     for (int i = 0; i <= 25; i++) {
/*  35:126 */       lookUpBase64Alphabet[i] = ((byte)(65 + i));
/*  36:    */     }
/*  37:129 */     int i = 26;
/*  38:129 */     for (int j = 0; i <= 51; j++)
/*  39:    */     {
/*  40:130 */       lookUpBase64Alphabet[i] = ((byte)(97 + j));i++;
/*  41:    */     }
/*  42:133 */     int i = 52;
/*  43:133 */     for (int j = 0; i <= 61; j++)
/*  44:    */     {
/*  45:134 */       lookUpBase64Alphabet[i] = ((byte)(48 + j));i++;
/*  46:    */     }
/*  47:137 */     lookUpBase64Alphabet[62] = 43;
/*  48:138 */     lookUpBase64Alphabet[63] = 47;
/*  49:    */   }
/*  50:    */   
/*  51:    */   private static boolean isBase64(byte octect)
/*  52:    */   {
/*  53:142 */     if (octect == 61) {
/*  54:143 */       return true;
/*  55:    */     }
/*  56:144 */     if (base64Alphabet[octect] == -1) {
/*  57:145 */       return false;
/*  58:    */     }
/*  59:147 */     return true;
/*  60:    */   }
/*  61:    */   
/*  62:    */   public static boolean isArrayByteBase64(byte[] arrayOctect)
/*  63:    */   {
/*  64:161 */     arrayOctect = discardWhitespace(arrayOctect);
/*  65:    */     
/*  66:163 */     int length = arrayOctect.length;
/*  67:164 */     if (length == 0) {
/*  68:167 */       return true;
/*  69:    */     }
/*  70:169 */     for (int i = 0; i < length; i++) {
/*  71:170 */       if (!isBase64(arrayOctect[i])) {
/*  72:171 */         return false;
/*  73:    */       }
/*  74:    */     }
/*  75:174 */     return true;
/*  76:    */   }
/*  77:    */   
/*  78:    */   public static byte[] encodeBase64(byte[] binaryData)
/*  79:    */   {
/*  80:185 */     return encodeBase64(binaryData, false);
/*  81:    */   }
/*  82:    */   
/*  83:    */   public static byte[] encodeBase64Chunked(byte[] binaryData)
/*  84:    */   {
/*  85:196 */     return encodeBase64(binaryData, true);
/*  86:    */   }
/*  87:    */   
/*  88:    */   public Object decode(Object pObject)
/*  89:    */     throws RuntimeException
/*  90:    */   {
/*  91:214 */     if ((pObject instanceof String)) {
/*  92:215 */       return decode(((String)pObject).getBytes());
/*  93:    */     }
/*  94:217 */     if (!(pObject instanceof byte[])) {
/*  95:218 */       throw new RuntimeException("Parameter supplied to Base64 decode is not a byte[]");
/*  96:    */     }
/*  97:220 */     return decode((byte[])pObject);
/*  98:    */   }
/*  99:    */   
/* 100:    */   public static byte[] decode(byte[] pArray)
/* 101:    */   {
/* 102:231 */     return decodeBase64(pArray);
/* 103:    */   }
/* 104:    */   
/* 105:    */   public static byte[] decode(String pString)
/* 106:    */   {
/* 107:242 */     return decodeBase64(pString.getBytes());
/* 108:    */   }
/* 109:    */   
/* 110:    */   public static byte[] encodeBase64(byte[] binaryData, boolean isChunked)
/* 111:    */   {
/* 112:255 */     int lengthDataBits = binaryData.length * 8;
/* 113:256 */     int fewerThan24bits = lengthDataBits % 24;
/* 114:257 */     int numberTriplets = lengthDataBits / 24;
/* 115:258 */     byte[] encodedData = null;
/* 116:259 */     int encodedDataLength = 0;
/* 117:260 */     int nbrChunks = 0;
/* 118:262 */     if (fewerThan24bits != 0) {
/* 119:264 */       encodedDataLength = (numberTriplets + 1) * 4;
/* 120:    */     } else {
/* 121:267 */       encodedDataLength = numberTriplets * 4;
/* 122:    */     }
/* 123:273 */     if (isChunked)
/* 124:    */     {
/* 125:275 */       nbrChunks = CHUNK_SEPARATOR.length == 0 ? 0 : (int)Math.ceil(encodedDataLength / 76.0F);
/* 126:    */       
/* 127:277 */       encodedDataLength += nbrChunks * CHUNK_SEPARATOR.length;
/* 128:    */     }
/* 129:280 */     encodedData = new byte[encodedDataLength];
/* 130:    */     
/* 131:282 */     byte k = 0;byte l = 0;byte b1 = 0;byte b2 = 0;byte b3 = 0;
/* 132:    */     
/* 133:284 */     int encodedIndex = 0;
/* 134:285 */     int dataIndex = 0;
/* 135:286 */     int i = 0;
/* 136:287 */     int nextSeparatorIndex = 76;
/* 137:288 */     int chunksSoFar = 0;
/* 138:291 */     for (i = 0; i < numberTriplets; i++)
/* 139:    */     {
/* 140:292 */       dataIndex = i * 3;
/* 141:293 */       b1 = binaryData[dataIndex];
/* 142:294 */       b2 = binaryData[(dataIndex + 1)];
/* 143:295 */       b3 = binaryData[(dataIndex + 2)];
/* 144:    */       
/* 145:    */ 
/* 146:    */ 
/* 147:299 */       l = (byte)(b2 & 0xF);
/* 148:300 */       k = (byte)(b1 & 0x3);
/* 149:    */       
/* 150:302 */       byte val1 = (b1 & 0xFFFFFF80) == 0 ? (byte)(b1 >> 2) : (byte)(b1 >> 2 ^ 0xC0);
/* 151:    */       
/* 152:304 */       byte val2 = (b2 & 0xFFFFFF80) == 0 ? (byte)(b2 >> 4) : (byte)(b2 >> 4 ^ 0xF0);
/* 153:    */       
/* 154:306 */       byte val3 = (b3 & 0xFFFFFF80) == 0 ? (byte)(b3 >> 6) : (byte)(b3 >> 6 ^ 0xFC);
/* 155:    */       
/* 156:    */ 
/* 157:309 */       encodedData[encodedIndex] = lookUpBase64Alphabet[val1];
/* 158:    */       
/* 159:    */ 
/* 160:    */ 
/* 161:313 */       encodedData[(encodedIndex + 1)] = lookUpBase64Alphabet[(val2 | k << 4)];
/* 162:    */       
/* 163:315 */       encodedData[(encodedIndex + 2)] = lookUpBase64Alphabet[(l << 2 | val3)];
/* 164:    */       
/* 165:317 */       encodedData[(encodedIndex + 3)] = lookUpBase64Alphabet[(b3 & 0x3F)];
/* 166:    */       
/* 167:319 */       encodedIndex += 4;
/* 168:322 */       if (isChunked) {
/* 169:324 */         if (encodedIndex == nextSeparatorIndex)
/* 170:    */         {
/* 171:325 */           System.arraycopy(CHUNK_SEPARATOR, 0, encodedData, encodedIndex, CHUNK_SEPARATOR.length);
/* 172:    */           
/* 173:    */ 
/* 174:    */ 
/* 175:    */ 
/* 176:    */ 
/* 177:331 */           chunksSoFar++;
/* 178:332 */           nextSeparatorIndex = 76 * (chunksSoFar + 1) + chunksSoFar * CHUNK_SEPARATOR.length;
/* 179:    */           
/* 180:    */ 
/* 181:335 */           encodedIndex += CHUNK_SEPARATOR.length;
/* 182:    */         }
/* 183:    */       }
/* 184:    */     }
/* 185:341 */     dataIndex = i * 3;
/* 186:343 */     if (fewerThan24bits == 8)
/* 187:    */     {
/* 188:344 */       b1 = binaryData[dataIndex];
/* 189:345 */       k = (byte)(b1 & 0x3);
/* 190:    */       
/* 191:    */ 
/* 192:348 */       byte val1 = (b1 & 0xFFFFFF80) == 0 ? (byte)(b1 >> 2) : (byte)(b1 >> 2 ^ 0xC0);
/* 193:    */       
/* 194:350 */       encodedData[encodedIndex] = lookUpBase64Alphabet[val1];
/* 195:351 */       encodedData[(encodedIndex + 1)] = lookUpBase64Alphabet[(k << 4)];
/* 196:352 */       encodedData[(encodedIndex + 2)] = 61;
/* 197:353 */       encodedData[(encodedIndex + 3)] = 61;
/* 198:    */     }
/* 199:354 */     else if (fewerThan24bits == 16)
/* 200:    */     {
/* 201:356 */       b1 = binaryData[dataIndex];
/* 202:357 */       b2 = binaryData[(dataIndex + 1)];
/* 203:358 */       l = (byte)(b2 & 0xF);
/* 204:359 */       k = (byte)(b1 & 0x3);
/* 205:    */       
/* 206:361 */       byte val1 = (b1 & 0xFFFFFF80) == 0 ? (byte)(b1 >> 2) : (byte)(b1 >> 2 ^ 0xC0);
/* 207:    */       
/* 208:363 */       byte val2 = (b2 & 0xFFFFFF80) == 0 ? (byte)(b2 >> 4) : (byte)(b2 >> 4 ^ 0xF0);
/* 209:    */       
/* 210:    */ 
/* 211:366 */       encodedData[encodedIndex] = lookUpBase64Alphabet[val1];
/* 212:367 */       encodedData[(encodedIndex + 1)] = lookUpBase64Alphabet[(val2 | k << 4)];
/* 213:    */       
/* 214:369 */       encodedData[(encodedIndex + 2)] = lookUpBase64Alphabet[(l << 2)];
/* 215:370 */       encodedData[(encodedIndex + 3)] = 61;
/* 216:    */     }
/* 217:373 */     if (isChunked) {
/* 218:375 */       if (chunksSoFar < nbrChunks) {
/* 219:376 */         System.arraycopy(CHUNK_SEPARATOR, 0, encodedData, encodedDataLength - CHUNK_SEPARATOR.length, CHUNK_SEPARATOR.length);
/* 220:    */       }
/* 221:    */     }
/* 222:385 */     return encodedData;
/* 223:    */   }
/* 224:    */   
/* 225:    */   public static byte[] decodeBase64(byte[] base64Data)
/* 226:    */   {
/* 227:396 */     base64Data = discardNonBase64(base64Data);
/* 228:399 */     if (base64Data.length == 0) {
/* 229:400 */       return new byte[0];
/* 230:    */     }
/* 231:403 */     int numberQuadruple = base64Data.length / 4;
/* 232:404 */     byte[] decodedData = null;
/* 233:405 */     byte b1 = 0;byte b2 = 0;byte b3 = 0;byte b4 = 0;byte marker0 = 0;byte marker1 = 0;
/* 234:    */     
/* 235:    */ 
/* 236:    */ 
/* 237:409 */     int encodedIndex = 0;
/* 238:410 */     int dataIndex = 0;
/* 239:    */     
/* 240:    */ 
/* 241:413 */     int lastData = base64Data.length;
/* 242:415 */     while (base64Data[(lastData - 1)] == 61)
/* 243:    */     {
/* 244:416 */       lastData--;
/* 245:416 */       if (lastData == 0) {
/* 246:417 */         return new byte[0];
/* 247:    */       }
/* 248:    */     }
/* 249:420 */     decodedData = new byte[lastData - numberQuadruple];
/* 250:423 */     for (int i = 0; i < numberQuadruple; i++)
/* 251:    */     {
/* 252:424 */       dataIndex = i * 4;
/* 253:425 */       marker0 = base64Data[(dataIndex + 2)];
/* 254:426 */       marker1 = base64Data[(dataIndex + 3)];
/* 255:    */       
/* 256:428 */       b1 = base64Alphabet[base64Data[dataIndex]];
/* 257:429 */       b2 = base64Alphabet[base64Data[(dataIndex + 1)]];
/* 258:431 */       if ((marker0 != 61) && (marker1 != 61))
/* 259:    */       {
/* 260:433 */         b3 = base64Alphabet[marker0];
/* 261:434 */         b4 = base64Alphabet[marker1];
/* 262:    */         
/* 263:436 */         decodedData[encodedIndex] = ((byte)(b1 << 2 | b2 >> 4));
/* 264:437 */         decodedData[(encodedIndex + 1)] = ((byte)((b2 & 0xF) << 4 | b3 >> 2 & 0xF));
/* 265:    */         
/* 266:439 */         decodedData[(encodedIndex + 2)] = ((byte)(b3 << 6 | b4));
/* 267:    */       }
/* 268:440 */       else if (marker0 == 61)
/* 269:    */       {
/* 270:442 */         decodedData[encodedIndex] = ((byte)(b1 << 2 | b2 >> 4));
/* 271:    */       }
/* 272:443 */       else if (marker1 == 61)
/* 273:    */       {
/* 274:445 */         b3 = base64Alphabet[marker0];
/* 275:    */         
/* 276:447 */         decodedData[encodedIndex] = ((byte)(b1 << 2 | b2 >> 4));
/* 277:448 */         decodedData[(encodedIndex + 1)] = ((byte)((b2 & 0xF) << 4 | b3 >> 2 & 0xF));
/* 278:    */       }
/* 279:451 */       encodedIndex += 3;
/* 280:    */     }
/* 281:453 */     return decodedData;
/* 282:    */   }
/* 283:    */   
/* 284:    */   static byte[] discardWhitespace(byte[] data)
/* 285:    */   {
/* 286:464 */     byte[] groomedData = new byte[data.length];
/* 287:465 */     int bytesCopied = 0;
/* 288:467 */     for (int i = 0; i < data.length; i++) {
/* 289:468 */       switch (data[i])
/* 290:    */       {
/* 291:    */       case 9: 
/* 292:    */       case 10: 
/* 293:    */       case 13: 
/* 294:    */       case 32: 
/* 295:    */         break;
/* 296:    */       default: 
/* 297:475 */         groomedData[(bytesCopied++)] = data[i];
/* 298:    */       }
/* 299:    */     }
/* 300:479 */     byte[] packedData = new byte[bytesCopied];
/* 301:    */     
/* 302:481 */     System.arraycopy(groomedData, 0, packedData, 0, bytesCopied);
/* 303:    */     
/* 304:483 */     return packedData;
/* 305:    */   }
/* 306:    */   
/* 307:    */   static byte[] discardNonBase64(byte[] data)
/* 308:    */   {
/* 309:496 */     byte[] groomedData = new byte[data.length];
/* 310:497 */     int bytesCopied = 0;
/* 311:499 */     for (int i = 0; i < data.length; i++) {
/* 312:500 */       if (isBase64(data[i])) {
/* 313:501 */         groomedData[(bytesCopied++)] = data[i];
/* 314:    */       }
/* 315:    */     }
/* 316:505 */     byte[] packedData = new byte[bytesCopied];
/* 317:    */     
/* 318:507 */     System.arraycopy(groomedData, 0, packedData, 0, bytesCopied);
/* 319:    */     
/* 320:509 */     return packedData;
/* 321:    */   }
/* 322:    */   
/* 323:    */   public Object encode(Object pObject)
/* 324:    */     throws RuntimeException
/* 325:    */   {
/* 326:528 */     if (!(pObject instanceof byte[])) {
/* 327:529 */       throw new RuntimeException("Parameter supplied to Base64 encode is not a byte[]");
/* 328:    */     }
/* 329:532 */     return encode((byte[])pObject);
/* 330:    */   }
/* 331:    */   
/* 332:    */   public static String encode(byte[] pArray)
/* 333:    */   {
/* 334:543 */     return new String(encodeBase64(pArray, false));
/* 335:    */   }
/* 336:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.util.Base64
 * JD-Core Version:    0.7.0.1
 */