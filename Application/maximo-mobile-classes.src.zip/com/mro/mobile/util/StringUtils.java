/*  1:   */ package com.mro.mobile.util;
/*  2:   */ 
/*  3:   */ import java.io.ByteArrayOutputStream;
/*  4:   */ import java.io.PrintStream;
/*  5:   */ 
/*  6:   */ public class StringUtils
/*  7:   */ {
/*  8:   */   public static boolean isStringEmpty(String str)
/*  9:   */   {
/* 10:24 */     return (str == null) || (str.trim().length() == 0);
/* 11:   */   }
/* 12:   */   
/* 13:   */   public static String toString(Throwable t)
/* 14:   */   {
/* 15:28 */     ByteArrayOutputStream baos = new ByteArrayOutputStream();
/* 16:29 */     t.printStackTrace(new PrintStream(baos));
/* 17:30 */     return baos.toString();
/* 18:   */   }
/* 19:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.util.StringUtils
 * JD-Core Version:    0.7.0.1
 */