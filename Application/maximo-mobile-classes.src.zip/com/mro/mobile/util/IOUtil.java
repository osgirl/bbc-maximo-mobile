/*  1:   */ package com.mro.mobile.util;
/*  2:   */ 
/*  3:   */ import java.io.IOException;
/*  4:   */ import java.io.InputStream;
/*  5:   */ import java.io.OutputStream;
/*  6:   */ 
/*  7:   */ public class IOUtil
/*  8:   */ {
/*  9:   */   public static void closeInputStream(InputStream is)
/* 10:   */   {
/* 11:   */     try
/* 12:   */     {
/* 13:26 */       if (is != null) {
/* 14:28 */         is.close();
/* 15:   */       }
/* 16:   */     }
/* 17:   */     catch (IOException e) {}
/* 18:   */   }
/* 19:   */   
/* 20:   */   public static void closeOutputStream(OutputStream os)
/* 21:   */   {
/* 22:   */     try
/* 23:   */     {
/* 24:40 */       if (os != null) {
/* 25:42 */         os.close();
/* 26:   */       }
/* 27:   */     }
/* 28:   */     catch (IOException e) {}
/* 29:   */   }
/* 30:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.util.IOUtil
 * JD-Core Version:    0.7.0.1
 */