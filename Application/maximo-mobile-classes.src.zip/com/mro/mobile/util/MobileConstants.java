package com.mro.mobile.util;

public abstract interface MobileConstants
{
  public static final String APPNAME = "APPNAME";
  public static final String VERSION = "VERSION";
  public static final String USERNAME = "USERNAME";
  public static final String PASSWORD = "PASSWORD";
  public static final String PIN = "PIN";
  public static final String COUNTRY = "COUNTRY";
  public static final String LANGUAGE = "LANGUAGE";
  public static final String VARIANT = "VARIANT";
  public static final String TIMEZONE = "TIMEZONE";
  public static final String MOBILEID = "MOBILEID";
  public static final String HOSTNAME = "maximo.mobile.hostname";
  public static final String PORT = "maximo.mobile.port";
  public static final String CONTEXTNAME = "maximo.mobile.contextname";
  public static final String SECURE = "maximo.mobile.ssl";
  public static final String TIMEINFO = "maximo.mobile.timeinfo";
  public static final String AUTHINFO = "maximo.mobile.authinfo";
  public static final String PACKAGE_VERSION = "maximo.mobile.packageversion";
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.util.MobileConstants
 * JD-Core Version:    0.7.0.1
 */