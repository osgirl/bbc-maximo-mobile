/*  1:   */ package com.mro.mobile.util;
/*  2:   */ 
/*  3:   */ import java.io.File;
/*  4:   */ 
/*  5:   */ public abstract interface MaximoMobileConstants
/*  6:   */ {
/*  7:   */   public static final String ROOT_FILE_STORAGE_FOLDER = "maximo.mobile.root.storage.folder";
/*  8:   */   public static final String ATTACHDOCFOLDER = "MOBILEWO.DOCEXTRACTFOLDER";
/*  9:24 */   public static final String ATTACHDOCDEFAULTFOLDER = File.separator + "maximoattachments" + File.separator;
/* 10:   */   public static final String UPDATE_ATTRIBUTE = "_UPDATEAVAILABLE";
/* 11:   */   public static final String UPDATE_NEXTCHECK = "_NEXTUPDATECHECK";
/* 12:   */   public static final int UPDATE_NONE = 0;
/* 13:   */   public static final int UPDATE_AVAILABLE = 1;
/* 14:   */   public static final int UPDATE_REINSTALL = 2;
/* 15:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.util.MaximoMobileConstants
 * JD-Core Version:    0.7.0.1
 */