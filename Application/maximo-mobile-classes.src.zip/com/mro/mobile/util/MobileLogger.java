/*   1:    */ package com.mro.mobile.util;
/*   2:    */ 
/*   3:    */ public class MobileLogger
/*   4:    */ {
/*   5:    */   public static final String ERROR_STR = "ERROR";
/*   6:    */   public static final String WARNING_STR = "WARN";
/*   7:    */   public static final String INFO_STR = "INFO";
/*   8:    */   public static final String DEBUG_STR = "DEBUG";
/*   9:    */   public static final int ERROR = 1;
/*  10:    */   public static final int WARNING = 2;
/*  11:    */   public static final int INFO = 3;
/*  12:    */   public static final int DEBUG = 4;
/*  13: 29 */   private String name = null;
/*  14: 30 */   private int verbosity = 1;
/*  15:    */   
/*  16:    */   public MobileLogger(String name)
/*  17:    */   {
/*  18: 34 */     this.name = name;
/*  19:    */   }
/*  20:    */   
/*  21:    */   public String getName()
/*  22:    */   {
/*  23: 39 */     return this.name;
/*  24:    */   }
/*  25:    */   
/*  26:    */   public void setVerbosity(int verbosity)
/*  27:    */   {
/*  28: 44 */     this.verbosity = verbosity;
/*  29:    */   }
/*  30:    */   
/*  31:    */   public void setVerbosity(String verbosityStr)
/*  32:    */   {
/*  33: 49 */     if (verbosityStr.equals("ERROR")) {
/*  34: 51 */       this.verbosity = 1;
/*  35: 53 */     } else if (verbosityStr.equals("WARN")) {
/*  36: 55 */       this.verbosity = 2;
/*  37: 57 */     } else if (verbosityStr.equals("INFO")) {
/*  38: 59 */       this.verbosity = 3;
/*  39: 61 */     } else if (verbosityStr.equals("DEBUG")) {
/*  40: 63 */       this.verbosity = 4;
/*  41:    */     }
/*  42:    */   }
/*  43:    */   
/*  44:    */   public int getVerbosity()
/*  45:    */   {
/*  46: 69 */     return this.verbosity;
/*  47:    */   }
/*  48:    */   
/*  49:    */   public boolean isDebugEnabled()
/*  50:    */   {
/*  51: 74 */     return this.verbosity >= 4;
/*  52:    */   }
/*  53:    */   
/*  54:    */   public void debug(String message)
/*  55:    */   {
/*  56: 79 */     if (this.verbosity >= 4) {
/*  57: 81 */       output("DEBUG", message, null);
/*  58:    */     }
/*  59:    */   }
/*  60:    */   
/*  61:    */   public void debug(String message, Throwable t)
/*  62:    */   {
/*  63: 87 */     if (this.verbosity >= 4) {
/*  64: 89 */       output("DEBUG", message, t);
/*  65:    */     }
/*  66:    */   }
/*  67:    */   
/*  68:    */   public boolean isInfoEnabled()
/*  69:    */   {
/*  70: 95 */     return this.verbosity >= 3;
/*  71:    */   }
/*  72:    */   
/*  73:    */   public void info(String message)
/*  74:    */   {
/*  75:100 */     if (this.verbosity >= 3) {
/*  76:102 */       output("INFO", message, null);
/*  77:    */     }
/*  78:    */   }
/*  79:    */   
/*  80:    */   public void info(String message, Throwable t)
/*  81:    */   {
/*  82:108 */     if (this.verbosity >= 3) {
/*  83:110 */       output("INFO", message, t);
/*  84:    */     }
/*  85:    */   }
/*  86:    */   
/*  87:    */   public boolean isWarnEnabled()
/*  88:    */   {
/*  89:116 */     return this.verbosity >= 2;
/*  90:    */   }
/*  91:    */   
/*  92:    */   public void warn(String message)
/*  93:    */   {
/*  94:121 */     if (this.verbosity >= 2) {
/*  95:123 */       output("WARN", message, null);
/*  96:    */     }
/*  97:    */   }
/*  98:    */   
/*  99:    */   public void warn(String message, Throwable t)
/* 100:    */   {
/* 101:129 */     if (this.verbosity >= 2) {
/* 102:131 */       output("WARN", message, t);
/* 103:    */     }
/* 104:    */   }
/* 105:    */   
/* 106:    */   public void log(String message)
/* 107:    */   {
/* 108:137 */     if (this.verbosity >= 2) {
/* 109:139 */       output(getVerbosityString(), message, null);
/* 110:    */     }
/* 111:    */   }
/* 112:    */   
/* 113:    */   public void log(String message, Throwable t)
/* 114:    */   {
/* 115:145 */     if (this.verbosity >= 2) {
/* 116:147 */       output(getVerbosityString(), message, t);
/* 117:    */     }
/* 118:    */   }
/* 119:    */   
/* 120:    */   public boolean isErrorEnabled()
/* 121:    */   {
/* 122:153 */     return this.verbosity >= 1;
/* 123:    */   }
/* 124:    */   
/* 125:    */   public void error(String message)
/* 126:    */   {
/* 127:158 */     if (this.verbosity >= 1) {
/* 128:160 */       output("ERROR", message, null);
/* 129:    */     }
/* 130:    */   }
/* 131:    */   
/* 132:    */   public void error(String message, Throwable t)
/* 133:    */   {
/* 134:166 */     if (this.verbosity >= 1) {
/* 135:168 */       output("ERROR", message, t);
/* 136:    */     }
/* 137:    */   }
/* 138:    */   
/* 139:    */   protected String getVerbosityString()
/* 140:    */   {
/* 141:174 */     switch (this.verbosity)
/* 142:    */     {
/* 143:    */     case 3: 
/* 144:177 */       return "INFO";
/* 145:    */     case 2: 
/* 146:180 */       return "WARN";
/* 147:    */     case 1: 
/* 148:183 */       return "ERROR";
/* 149:    */     case 4: 
/* 150:186 */       return "DEBUG";
/* 151:    */     }
/* 152:192 */     return "";
/* 153:    */   }
/* 154:    */   
/* 155:    */   protected void output(String verbosityStr, String message, Throwable t)
/* 156:    */   {
/* 157:196 */     streamer.output(verbosityStr, message, t);
/* 158:    */   }
/* 159:    */   
/* 160:199 */   private static Streamer streamer = null;
/* 161:    */   
/* 162:    */   public static void registerStreamer(Streamer strmr)
/* 163:    */   {
/* 164:206 */     streamer = strmr;
/* 165:    */   }
/* 166:    */   
/* 167:    */   public static abstract interface Streamer
/* 168:    */   {
/* 169:    */     public abstract void output(String paramString1, String paramString2, Throwable paramThrowable);
/* 170:    */   }
/* 171:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.util.MobileLogger
 * JD-Core Version:    0.7.0.1
 */