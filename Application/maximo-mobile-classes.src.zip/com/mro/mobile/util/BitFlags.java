/*   1:    */ package com.mro.mobile.util;
/*   2:    */ 
/*   3:    */ public class BitFlags
/*   4:    */ {
/*   5: 21 */   private byte[] flags = null;
/*   6: 23 */   private int size = 0;
/*   7:    */   
/*   8:    */   public BitFlags(int size)
/*   9:    */   {
/*  10: 27 */     this.size = size;
/*  11: 28 */     this.flags = new byte[size / 8 + 1];
/*  12: 29 */     clearAll();
/*  13:    */   }
/*  14:    */   
/*  15:    */   public BitFlags(int size, byte[] flags)
/*  16:    */   {
/*  17: 34 */     this.size = size;
/*  18: 35 */     this.flags = flags;
/*  19:    */   }
/*  20:    */   
/*  21:    */   public BitFlags(int size, byte[] data, int offset, int length)
/*  22:    */   {
/*  23: 40 */     this(size);
/*  24: 41 */     System.arraycopy(data, offset, this.flags, 0, length);
/*  25:    */   }
/*  26:    */   
/*  27:    */   public boolean isSet()
/*  28:    */   {
/*  29: 46 */     for (int i = 0; i < this.flags.length; i++) {
/*  30: 48 */       if (this.flags[i] != 0) {
/*  31: 50 */         return true;
/*  32:    */       }
/*  33:    */     }
/*  34: 53 */     return false;
/*  35:    */   }
/*  36:    */   
/*  37:    */   public boolean isSet(int position)
/*  38:    */   {
/*  39: 58 */     int bytepos = position / 8;
/*  40: 59 */     int bitpos = position % 8;
/*  41: 60 */     return (byte)(this.flags[bytepos] & 128 >> bitpos) != 0;
/*  42:    */   }
/*  43:    */   
/*  44:    */   public void clearAll()
/*  45:    */   {
/*  46: 65 */     for (int i = 0; i < this.flags.length; i++) {
/*  47: 67 */       this.flags[i] = ((byte)(this.flags[i] & 0x0));
/*  48:    */     }
/*  49:    */   }
/*  50:    */   
/*  51:    */   public void setAll()
/*  52:    */   {
/*  53: 73 */     for (int i = 0; i < this.flags.length; i++) {
/*  54: 75 */       this.flags[i] = ((byte)(this.flags[i] | 0xFF));
/*  55:    */     }
/*  56:    */   }
/*  57:    */   
/*  58:    */   public void set(int position)
/*  59:    */   {
/*  60: 81 */     int bytepos = position / 8;
/*  61: 82 */     int bitpos = position % 8;
/*  62: 83 */     this.flags[bytepos] = ((byte)(this.flags[bytepos] | 128 >> bitpos));
/*  63:    */   }
/*  64:    */   
/*  65:    */   public void clear(int position)
/*  66:    */   {
/*  67: 88 */     int bytepos = position / 8;
/*  68: 89 */     int bitpos = position % 8;
/*  69: 90 */     this.flags[bytepos] = ((byte)(this.flags[bytepos] & (128 >> bitpos ^ 0xFFFFFFFF)));
/*  70:    */   }
/*  71:    */   
/*  72:    */   public void set(int position, boolean value)
/*  73:    */   {
/*  74: 95 */     if (value) {
/*  75: 97 */       set(position);
/*  76:    */     } else {
/*  77:101 */       clear(position);
/*  78:    */     }
/*  79:    */   }
/*  80:    */   
/*  81:    */   public byte[] getFlags()
/*  82:    */   {
/*  83:107 */     return this.flags;
/*  84:    */   }
/*  85:    */   
/*  86:    */   public void setFlags(byte[] flags)
/*  87:    */   {
/*  88:112 */     this.flags = flags;
/*  89:    */   }
/*  90:    */   
/*  91:    */   public String toString()
/*  92:    */   {
/*  93:117 */     StringBuffer sb = new StringBuffer();
/*  94:118 */     sb.append(super.toString());
/*  95:119 */     if (this.flags != null)
/*  96:    */     {
/*  97:121 */       sb.append(' ');
/*  98:122 */       for (int i = 0; i < this.flags.length; i++)
/*  99:    */       {
/* 100:124 */         String hex = Integer.toHexString(this.flags[i]);
/* 101:125 */         if (hex.length() == 1)
/* 102:    */         {
/* 103:127 */           sb.append('0');
/* 104:128 */           sb.append(hex.charAt(hex.length() - 1));
/* 105:    */         }
/* 106:    */         else
/* 107:    */         {
/* 108:132 */           sb.append(hex.charAt(hex.length() - 2));
/* 109:133 */           sb.append(hex.charAt(hex.length() - 1));
/* 110:    */         }
/* 111:    */       }
/* 112:    */     }
/* 113:137 */     return sb.toString();
/* 114:    */   }
/* 115:    */   
/* 116:    */   public int getSize()
/* 117:    */   {
/* 118:145 */     return this.size;
/* 119:    */   }
/* 120:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.util.BitFlags
 * JD-Core Version:    0.7.0.1
 */