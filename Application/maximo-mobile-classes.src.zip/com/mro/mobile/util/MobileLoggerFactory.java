/*  1:   */ package com.mro.mobile.util;
/*  2:   */ 
/*  3:   */ import java.util.Hashtable;
/*  4:   */ 
/*  5:   */ public class MobileLoggerFactory
/*  6:   */ {
/*  7:20 */   private static final Hashtable loggers = new Hashtable();
/*  8:35 */   private static MobileLogger defaultLogger = new MobileLogger("maximo.mobile");
/*  9:   */   public static final String LOGGERNAME_DEFAULT = "maximo.mobile";
/* 10:   */   public static final String LOGGERNAME_SERIALIZATION = "maximo.mobile.serialization";
/* 11:   */   public static final String LOGGERNAME_PERSISTENCE = "maximo.mobile.persistence";
/* 12:   */   public static final String LOGGERNAME_COMM = "maximo.mobile.communication";
/* 13:   */   public static final String LOGGERNAME_SENSOR = "maximo.mobile.sensor";
/* 14:   */   public static final String LOGGERNAME_SNAPSHOT = "maximo.mobile.snapshot";
/* 15:   */   public static final String LOGGERNAME_SERVICECALL = "maximo.mobile.servicecall";
/* 16:   */   
/* 17:   */   static
/* 18:   */   {
/* 19:36 */     defaultLogger.setVerbosity("WARN");
/* 20:   */   }
/* 21:   */   
/* 22:   */   public static MobileLogger getDefaultLogger()
/* 23:   */   {
/* 24:40 */     return defaultLogger;
/* 25:   */   }
/* 26:   */   
/* 27:   */   public static void registerLogger(String name, MobileLogger logger)
/* 28:   */   {
/* 29:52 */     loggers.put(name, logger);
/* 30:   */   }
/* 31:   */   
/* 32:   */   public static MobileLogger getLogger(String name)
/* 33:   */   {
/* 34:57 */     return (MobileLogger)loggers.get(name);
/* 35:   */   }
/* 36:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.util.MobileLoggerFactory
 * JD-Core Version:    0.7.0.1
 */