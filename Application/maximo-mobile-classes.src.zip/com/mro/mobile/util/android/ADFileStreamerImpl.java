/*   1:    */ package com.mro.mobile.util.android;
/*   2:    */ 
/*   3:    */ import android.os.Environment;
/*   4:    */ import android.util.Log;
/*   5:    */ import com.mro.mobile.util.MobileLogger.Streamer;
/*   6:    */ import com.mro.mobile.util.StringUtils;
/*   7:    */ import java.io.BufferedWriter;
/*   8:    */ import java.io.File;
/*   9:    */ import java.io.FileWriter;
/*  10:    */ import java.io.IOException;
/*  11:    */ import java.text.SimpleDateFormat;
/*  12:    */ import java.util.Date;
/*  13:    */ import java.util.LinkedList;
/*  14:    */ 
/*  15:    */ public class ADFileStreamerImpl
/*  16:    */   implements MobileLogger.Streamer
/*  17:    */ {
/*  18: 22 */   private File LOG_DIR = null;
/*  19:    */   private static final String LOG_FILE_SUFFIX_NAME = "_log.txt";
/*  20: 29 */   private static File LOG_FILE = null;
/*  21:    */   private static final int MAX_LOG_SIZE = 5242880;
/*  22: 40 */   private LinkedList<LogStruct> queue = new LinkedList();
/*  23:    */   private Thread logger;
/*  24: 48 */   private boolean active = true;
/*  25: 53 */   private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("MM-dd HH:mm:ss.SS");
/*  26: 55 */   private String applicationName = null;
/*  27:    */   
/*  28:    */   public ADFileStreamerImpl(String packageName)
/*  29:    */   {
/*  30: 67 */     this.applicationName = getApplicationName(packageName);
/*  31: 70 */     if (this.applicationName.equalsIgnoreCase("mobileinst")) {
/*  32: 71 */       this.LOG_DIR = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + File.separatorChar + "maximomobile-installer" + File.separator + "logs");
/*  33:    */     } else {
/*  34: 74 */       this.LOG_DIR = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + File.separatorChar + "maximomobile" + File.separator + "logs");
/*  35:    */     }
/*  36: 78 */     if (!this.LOG_DIR.exists()) {
/*  37: 79 */       this.LOG_DIR.mkdirs();
/*  38:    */     }
/*  39: 82 */     this.active = this.LOG_DIR.exists();
/*  40: 83 */     if (this.active)
/*  41:    */     {
/*  42: 85 */       LOG_FILE = new File(this.LOG_DIR, this.applicationName + "_log.txt");
/*  43:    */       
/*  44:    */ 
/*  45: 88 */       LOG_FILE.delete();
/*  46:    */       
/*  47:    */ 
/*  48:    */ 
/*  49:    */ 
/*  50:    */ 
/*  51: 94 */       this.logger = new LoggerThread(null);
/*  52: 95 */       this.logger.start();
/*  53:    */     }
/*  54:    */     else
/*  55:    */     {
/*  56: 97 */       Log.w("MAXIMO_MOBILE", "Could not make logs dir at " + this.LOG_DIR.getAbsolutePath());
/*  57:    */     }
/*  58:    */   }
/*  59:    */   
/*  60:    */   public void output(String verbosityStr, String message, Throwable t)
/*  61:    */   {
/*  62:103 */     if ((this.active) && (!this.logger.isInterrupted()))
/*  63:    */     {
/*  64:104 */       LogStruct toLog = new LogStruct();
/*  65:105 */       toLog.verbosityStr = verbosityStr;
/*  66:106 */       toLog.message = message;
/*  67:107 */       toLog.error = t;
/*  68:112 */       synchronized (this.queue)
/*  69:    */       {
/*  70:114 */         this.queue.add(toLog);
/*  71:    */         
/*  72:    */ 
/*  73:117 */         this.queue.notify();
/*  74:    */       }
/*  75:    */     }
/*  76:    */   }
/*  77:    */   
/*  78:    */   private BufferedWriter openLog()
/*  79:    */   {
/*  80:123 */     BufferedWriter logWriter = null;
/*  81:    */     try
/*  82:    */     {
/*  83:125 */       double kbSize = LOG_FILE.length() / 1024.0D;
/*  84:    */       
/*  85:    */ 
/*  86:128 */       boolean appendToFile = kbSize < 5242880.0D;
/*  87:    */       
/*  88:130 */       logWriter = new BufferedWriter(new FileWriter(LOG_FILE, appendToFile));
/*  89:    */     }
/*  90:    */     catch (Exception e)
/*  91:    */     {
/*  92:133 */       Log.w("MAXIMO_MOBILE", "Error encountered opening logfile", e);
/*  93:134 */       this.active = false;
/*  94:135 */       this.logger.interrupt();
/*  95:    */     }
/*  96:137 */     return logWriter;
/*  97:    */   }
/*  98:    */   
/*  99:    */   private void closeLog(BufferedWriter writer)
/* 100:    */   {
/* 101:    */     try
/* 102:    */     {
/* 103:142 */       if (writer != null)
/* 104:    */       {
/* 105:143 */         writer.flush();
/* 106:144 */         writer.close();
/* 107:    */       }
/* 108:    */     }
/* 109:    */     catch (Exception e)
/* 110:    */     {
/* 111:147 */       Log.w("MAXIMO_MOBILE", "Error encountered closing logfile", e);
/* 112:    */     }
/* 113:    */   }
/* 114:    */   
/* 115:    */   private class LoggerThread
/* 116:    */     extends Thread
/* 117:    */   {
/* 118:    */     private LoggerThread() {}
/* 119:    */     
/* 120:    */     public void run()
/* 121:    */     {
/* 122:160 */       LinkedList<ADFileStreamerImpl.LogStruct> linesToLog = new LinkedList();
/* 123:162 */       while (!isInterrupted()) {
/* 124:164 */         synchronized (ADFileStreamerImpl.this.queue)
/* 125:    */         {
/* 126:    */           try
/* 127:    */           {
/* 128:170 */             if (ADFileStreamerImpl.this.queue.isEmpty()) {
/* 129:171 */               ADFileStreamerImpl.this.queue.wait();
/* 130:    */             }
/* 131:174 */             linesToLog.clear();
/* 132:175 */             linesToLog.addAll(ADFileStreamerImpl.this.queue);
/* 133:176 */             ADFileStreamerImpl.this.queue.clear();
/* 134:    */           }
/* 135:    */           catch (InterruptedException e)
/* 136:    */           {
/* 137:    */             break;
/* 138:    */           }
/* 139:182 */           BufferedWriter logWriter = null;
/* 140:185 */           if (!linesToLog.isEmpty()) {
/* 141:186 */             logWriter = ADFileStreamerImpl.this.openLog();
/* 142:    */           }
/* 143:190 */           while ((!linesToLog.isEmpty()) && (logWriter != null))
/* 144:    */           {
/* 145:191 */             ADFileStreamerImpl.LogStruct logStruct = (ADFileStreamerImpl.LogStruct)linesToLog.removeFirst();
/* 146:    */             try
/* 147:    */             {
/* 148:193 */               String timestamp = ADFileStreamerImpl.DATE_FORMAT.format(new Date());
/* 149:194 */               logWriter.write(timestamp + " [" + logStruct.verbosityStr + "] " + logStruct.message);
/* 150:195 */               logWriter.newLine();
/* 151:197 */               if (logStruct.error != null) {
/* 152:198 */                 logWriter.write(timestamp + " [" + logStruct.verbosityStr + "] " + StringUtils.toString(logStruct.error));
/* 153:    */               }
/* 154:200 */               logWriter.newLine();
/* 155:    */             }
/* 156:    */             catch (IOException e)
/* 157:    */             {
/* 158:203 */               Log.w("MAXIMO_MOBILE", e.getMessage(), e);
/* 159:    */             }
/* 160:    */           }
/* 161:208 */           ADFileStreamerImpl.this.closeLog(logWriter);
/* 162:    */         }
/* 163:    */       }
/* 164:    */     }
/* 165:    */   }
/* 166:    */   
/* 167:    */   private String getApplicationName(String packageName)
/* 168:    */   {
/* 169:215 */     if (packageName == null) {
/* 170:216 */       return "anApplication";
/* 171:    */     }
/* 172:218 */     int point = packageName.lastIndexOf(".");
/* 173:219 */     return point >= 0 ? packageName.substring(point + 1) : packageName;
/* 174:    */   }
/* 175:    */   
/* 176:    */   protected class LogStruct
/* 177:    */   {
/* 178:    */     public String verbosityStr;
/* 179:    */     public String message;
/* 180:    */     public Throwable error;
/* 181:    */     
/* 182:    */     protected LogStruct() {}
/* 183:    */   }
/* 184:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.util.android.ADFileStreamerImpl
 * JD-Core Version:    0.7.0.1
 */