/*  1:   */ package com.mro.mobile.util.android;
/*  2:   */ 
/*  3:   */ import android.util.Log;
/*  4:   */ import com.mro.mobile.util.MobileLogger.Streamer;
/*  5:   */ import java.util.Date;
/*  6:   */ 
/*  7:   */ public class ADStreamerImpl
/*  8:   */   implements MobileLogger.Streamer
/*  9:   */ {
/* 10:25 */   public static String TAG = "MAXIMO_MOBILE";
/* 11:   */   
/* 12:   */   public void output(String verbosityStr, String message, Throwable t)
/* 13:   */   {
/* 14:28 */     String currentTime = new Date().toString();
/* 15:29 */     if ((message != null) && (t == null))
/* 16:   */     {
/* 17:30 */       if (verbosityStr.equals("DEBUG")) {
/* 18:31 */         Log.d(TAG, currentTime + " [" + verbosityStr + "] " + message);
/* 19:33 */       } else if (verbosityStr.equals("INFO")) {
/* 20:34 */         Log.i(TAG, currentTime + " [" + verbosityStr + "] " + message);
/* 21:36 */       } else if (verbosityStr.equals("WARN")) {
/* 22:37 */         Log.w(TAG, currentTime + " [" + verbosityStr + "] " + message);
/* 23:   */       } else {
/* 24:40 */         Log.e(TAG, currentTime + " [" + verbosityStr + "] " + message);
/* 25:   */       }
/* 26:   */     }
/* 27:43 */     else if ((t != null) && (message != null)) {
/* 28:44 */       if (verbosityStr.equals("DEBUG")) {
/* 29:45 */         Log.d(TAG, currentTime + " [" + verbosityStr + "] " + message, t);
/* 30:47 */       } else if (verbosityStr.equals("INFO")) {
/* 31:48 */         Log.i(TAG, currentTime + " [" + verbosityStr + "] " + message, t);
/* 32:50 */       } else if (verbosityStr.equals("WARN")) {
/* 33:51 */         Log.w(TAG, currentTime + " [" + verbosityStr + "] " + message, t);
/* 34:   */       } else {
/* 35:54 */         Log.e(TAG, currentTime + " [" + verbosityStr + "] " + message, t);
/* 36:   */       }
/* 37:   */     }
/* 38:   */   }
/* 39:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.util.android.ADStreamerImpl
 * JD-Core Version:    0.7.0.1
 */