/*   1:    */ package com.mro.mobile.util;
/*   2:    */ 
/*   3:    */ import java.io.File;
/*   4:    */ import java.io.FileOutputStream;
/*   5:    */ import java.io.OutputStream;
/*   6:    */ import java.io.PrintWriter;
/*   7:    */ import java.util.Date;
/*   8:    */ 
/*   9:    */ public class MobileFileLogger
/*  10:    */   extends MobileLogger
/*  11:    */ {
/*  12: 25 */   private static Object syncObject = new Object();
/*  13: 26 */   private static String outputFile = "mxmobile.log";
/*  14: 27 */   private static OutputStream logoutStream = null;
/*  15: 28 */   private static PrintWriter pw = null;
/*  16:    */   
/*  17:    */   public MobileFileLogger(String name)
/*  18:    */   {
/*  19: 32 */     super(name);
/*  20:    */   }
/*  21:    */   
/*  22:    */   protected void output(String verbosityStr, String message, Throwable t)
/*  23:    */   {
/*  24: 37 */     synchronized (syncObject)
/*  25:    */     {
/*  26: 39 */       if (pw == null) {
/*  27:    */         try
/*  28:    */         {
/*  29: 43 */           File f = null;
/*  30:    */           
/*  31: 45 */           String mobileLog = System.getProperty("mobilelog");
/*  32: 46 */           if (mobileLog != null)
/*  33:    */           {
/*  34: 48 */             outputFile = mobileLog;
/*  35: 49 */             f = new File(outputFile);
/*  36: 50 */             if (f.getParent() != null)
/*  37:    */             {
/*  38: 52 */               File pF = new File(f.getParent());
/*  39: 53 */               pF.mkdirs();
/*  40:    */             }
/*  41:    */           }
/*  42:    */           else
/*  43:    */           {
/*  44: 58 */             f = new File(outputFile);
/*  45:    */           }
/*  46: 61 */           logoutStream = new FileOutputStream(outputFile, true);
/*  47: 62 */           pw = new PrintWriter(logoutStream);
/*  48:    */         }
/*  49:    */         catch (Exception e)
/*  50:    */         {
/*  51: 66 */           e.printStackTrace();
/*  52:    */         }
/*  53:    */       }
/*  54:    */     }
/*  55: 71 */     if (message != null)
/*  56:    */     {
/*  57: 73 */       String currentTime = new Date().toString();
/*  58: 74 */       synchronized (syncObject)
/*  59:    */       {
/*  60: 76 */         if (pw != null)
/*  61:    */         {
/*  62: 78 */           pw.println(currentTime + " [" + verbosityStr + "] " + message);
/*  63: 79 */           pw.flush();
/*  64:    */         }
/*  65:    */         else
/*  66:    */         {
/*  67: 83 */           super.output(verbosityStr, message, t);
/*  68: 84 */           return;
/*  69:    */         }
/*  70:    */       }
/*  71:    */     }
/*  72: 90 */     if (t != null)
/*  73:    */     {
/*  74: 92 */       String currentTime = new Date().toString();
/*  75: 93 */       synchronized (syncObject)
/*  76:    */       {
/*  77: 95 */         if (pw != null)
/*  78:    */         {
/*  79: 97 */           pw.println(currentTime + " [" + verbosityStr + "] " + t.getMessage());
/*  80: 98 */           t.printStackTrace(pw);
/*  81: 99 */           pw.flush();
/*  82:    */         }
/*  83:    */         else
/*  84:    */         {
/*  85:103 */           super.output(verbosityStr, message, t);
/*  86:104 */           return;
/*  87:    */         }
/*  88:    */       }
/*  89:    */     }
/*  90:    */   }
/*  91:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.util.MobileFileLogger
 * JD-Core Version:    0.7.0.1
 */