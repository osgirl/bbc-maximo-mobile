/*  1:   */ package com.mro.mobile.util;
/*  2:   */ 
/*  3:   */ public class MultiStreamer
/*  4:   */   implements MobileLogger.Streamer
/*  5:   */ {
/*  6:   */   private MobileLogger.Streamer streamer1;
/*  7:   */   private MobileLogger.Streamer streamer2;
/*  8:   */   
/*  9:   */   public MultiStreamer(MobileLogger.Streamer streamer1, MobileLogger.Streamer streamer2)
/* 10:   */   {
/* 11:15 */     this.streamer1 = streamer1;
/* 12:16 */     this.streamer2 = streamer2;
/* 13:   */   }
/* 14:   */   
/* 15:   */   public void output(String verbosityStr, String message, Throwable t)
/* 16:   */   {
/* 17:20 */     this.streamer1.output(verbosityStr, message, t);
/* 18:21 */     this.streamer2.output(verbosityStr, message, t);
/* 19:   */   }
/* 20:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.util.MultiStreamer
 * JD-Core Version:    0.7.0.1
 */