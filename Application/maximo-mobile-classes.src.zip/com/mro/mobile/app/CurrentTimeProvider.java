/*  1:   */ package com.mro.mobile.app;
/*  2:   */ 
/*  3:   */ import java.util.Date;
/*  4:   */ 
/*  5:   */ public class CurrentTimeProvider
/*  6:   */ {
/*  7:20 */   private static CurrentTimeProvider currentTimeProvider = new CurrentTimeProvider();
/*  8:   */   
/*  9:   */   public static CurrentTimeProvider getInstance()
/* 10:   */   {
/* 11:29 */     return currentTimeProvider;
/* 12:   */   }
/* 13:   */   
/* 14:   */   public Date getCurrentTime()
/* 15:   */   {
/* 16:34 */     MobileDeviceAppSession deviceAppSession = MobileDeviceAppSession.getSession();
/* 17:35 */     AbstractMobileDeviceApplication app = deviceAppSession.getApplication();
/* 18:   */     
/* 19:   */ 
/* 20:   */ 
/* 21:   */ 
/* 22:   */ 
/* 23:   */ 
/* 24:42 */     return new Date(System.currentTimeMillis() + app.getTimeAdjustment());
/* 25:   */   }
/* 26:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.CurrentTimeProvider
 * JD-Core Version:    0.7.0.1
 */