/*  1:   */ package com.mro.mobile.app;
/*  2:   */ 
/*  3:   */ import com.mro.mobile.MobileApplicationException;
/*  4:   */ import com.mro.mobile.ui.event.UIEvent;
/*  5:   */ import java.io.ByteArrayInputStream;
/*  6:   */ import java.io.File;
/*  7:   */ import java.io.IOException;
/*  8:   */ 
/*  9:   */ public abstract class MobileSoftwareUpdateHelper
/* 10:   */ {
/* 11:   */   protected BasicMobileDeviceApplication application;
/* 12:   */   
/* 13:   */   public MobileSoftwareUpdateHelper(BasicMobileDeviceApplication application)
/* 14:   */   {
/* 15:32 */     this.application = application;
/* 16:33 */     this.application.setSoftwareUpdateHelper(this);
/* 17:   */   }
/* 18:   */   
/* 19:   */   public void downloadUpdateFile()
/* 20:   */     throws MobileApplicationException
/* 21:   */   {
/* 22:37 */     File file = getAppJarOrApkFileLocationToSaveDownloadedFile();
/* 23:38 */     if (file != null)
/* 24:   */     {
/* 25:39 */       String language = this.application.getProperty("maximo.mobile.packagelanguage");
/* 26:40 */       String profile = this.application.getProperty("maximo.mobile.profile");
/* 27:   */       
/* 28:42 */       String newFilePath = newFullNameForDownloadedFile(file);
/* 29:   */       
/* 30:44 */       File newFile = file;
/* 31:45 */       if (newFilePath != null)
/* 32:   */       {
/* 33:46 */         newFile = new File(newFilePath);
/* 34:47 */         if (newFile.exists()) {
/* 35:48 */           newFile.delete();
/* 36:   */         }
/* 37:   */       }
/* 38:   */       try
/* 39:   */       {
/* 40:54 */         int noOfChunks = this.application.getDefaultMobileWebServiceProxy().getUpdateJarNumberOfChunks(profile, language, 512000);
/* 41:55 */         byte[] updateJarDataChunk = null;
/* 42:56 */         for (int i = 0; i < noOfChunks; i++)
/* 43:   */         {
/* 44:57 */           updateJarDataChunk = this.application.getDefaultMobileWebServiceProxy().retrieveUpdateJarFile(profile, language, 512000, i);
/* 45:58 */           ByteArrayInputStream bis = new ByteArrayInputStream(updateJarDataChunk);
/* 46:59 */           if (i == 0) {
/* 47:60 */             this.application.createFileFromStream(newFile, bis);
/* 48:   */           } else {
/* 49:62 */             this.application.createFileFromStream(newFile, bis, true);
/* 50:   */           }
/* 51:   */         }
/* 52:65 */         postDownloadUpdateFile(newFile);
/* 53:   */       }
/* 54:   */       catch (IOException e)
/* 55:   */       {
/* 56:67 */         throw new MobileApplicationException("updatefailed", new Object[] { newFile.getAbsolutePath() }, e);
/* 57:   */       }
/* 58:   */     }
/* 59:   */     else
/* 60:   */     {
/* 61:70 */       throw new MobileApplicationException("updatedownloadfailed");
/* 62:   */     }
/* 63:   */   }
/* 64:   */   
/* 65:   */   public abstract File getAppJarOrApkFileLocationToSaveDownloadedFile()
/* 66:   */     throws MobileApplicationException;
/* 67:   */   
/* 68:   */   public abstract void postDownloadUpdateFile(File paramFile)
/* 69:   */     throws MobileApplicationException;
/* 70:   */   
/* 71:   */   public abstract void completeUpdateProcess(UIEvent paramUIEvent)
/* 72:   */     throws MobileApplicationException;
/* 73:   */   
/* 74:   */   public String newFullNameForDownloadedFile(File reference)
/* 75:   */   {
/* 76:81 */     return reference.getAbsolutePath() + "_upd";
/* 77:   */   }
/* 78:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.MobileSoftwareUpdateHelper
 * JD-Core Version:    0.7.0.1
 */