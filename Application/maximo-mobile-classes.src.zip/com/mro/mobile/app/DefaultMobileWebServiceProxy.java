/*   1:    */ package com.mro.mobile.app;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.DefaultMobileWebService;
/*   4:    */ import com.mro.mobile.MobileApplicationException;
/*   5:    */ import com.mro.mobile.MobileMetaData;
/*   6:    */ import com.mro.mobile.comm.CommunicationChannel;
/*   7:    */ import com.mro.mobile.mbo.MobileMbo;
/*   8:    */ import com.mro.mobile.mbo.MobileMboChange;
/*   9:    */ import com.mro.mobile.mbo.MobileMboData;
/*  10:    */ import com.mro.mobile.mbo.MobileMboOrder;
/*  11:    */ import com.mro.mobile.mbo.MobileMboQBE;
/*  12:    */ import com.mro.mobile.persist.sql.MobileWhereClause;
/*  13:    */ 
/*  14:    */ public class DefaultMobileWebServiceProxy
/*  15:    */   implements DefaultMobileWebService
/*  16:    */ {
/*  17:    */   public static final String APPNAME_PROPERTY = "APPNAME";
/*  18:    */   public static final String USERNAME_PROPERTY = "USERNAME";
/*  19:    */   public static final String PASSWORD_PROPERTY = "PASSWORD";
/*  20:    */   public static final String HOSTNAME_PROPERTY = "maximo.mobile.hostname";
/*  21:    */   public static final String PORT_PROPERTY = "maximo.mobile.port";
/*  22:    */   public static final String CONTEXTNAME_PROPERTY = "maximo.mobile.contextname";
/*  23:    */   public static final String SECURE_PROPERTY = "maximo.mobile.ssl";
/*  24:    */   public static final String COUNTRY_PROPERTY = "COUNTRY";
/*  25:    */   public static final String LANGUAGE_PROPERTY = "LANGUAGE";
/*  26:    */   public static final String VARIANT_PROPERTY = "VARIANT";
/*  27:    */   public static final String TIMEZONE_PROPERTY = "TIMEZONE";
/*  28:    */   public static final String VERSION_PROPERTY = "VERSION";
/*  29:    */   public static final String MOBILEID_PROPERTY = "MOBILEID";
/*  30: 52 */   protected MobileDeviceAppService service = null;
/*  31:    */   
/*  32:    */   public DefaultMobileWebServiceProxy(String appName)
/*  33:    */   {
/*  34: 56 */     this.service = new MobileDeviceAppService(appName);
/*  35:    */   }
/*  36:    */   
/*  37:    */   protected MobileDeviceAppService getService()
/*  38:    */   {
/*  39: 61 */     return this.service;
/*  40:    */   }
/*  41:    */   
/*  42:    */   public void setProperty(String propertyName, String value)
/*  43:    */     throws MobileApplicationException
/*  44:    */   {
/*  45: 67 */     this.service.setProperty(propertyName, value);
/*  46:    */   }
/*  47:    */   
/*  48:    */   public void setCommunicationChannel(CommunicationChannel communicationChannel)
/*  49:    */     throws MobileApplicationException
/*  50:    */   {
/*  51: 73 */     this.service.setCommunicationChannel(communicationChannel);
/*  52:    */   }
/*  53:    */   
/*  54:    */   public MobileMetaData getMobileMetaData()
/*  55:    */     throws MobileApplicationException
/*  56:    */   {
/*  57: 80 */     MobileMetaData metaData = null;
/*  58: 81 */     metaData = (MobileMetaData)getService().invoke("getMobileMetaData", new Object[0]);
/*  59: 82 */     return metaData;
/*  60:    */   }
/*  61:    */   
/*  62:    */   public MobileMboData getMobileMbos(String name, Integer startIndex, Integer size)
/*  63:    */     throws MobileApplicationException
/*  64:    */   {
/*  65: 88 */     MobileMboData mboData = null;
/*  66: 89 */     mboData = (MobileMboData)getService().invoke("getMobileMbos", new Object[] { name, startIndex, size });
/*  67:    */     
/*  68:    */ 
/*  69:    */ 
/*  70: 93 */     return mboData;
/*  71:    */   }
/*  72:    */   
/*  73:    */   public MobileMboData getMobileMbos(String name, Integer startIndex, Integer size, MobileMboQBE filter, MobileMboOrder order)
/*  74:    */     throws MobileApplicationException
/*  75:    */   {
/*  76:101 */     return getMobileMbos(name, startIndex, size, filter, null, order);
/*  77:    */   }
/*  78:    */   
/*  79:    */   public MobileMboData getMobileMbos(String name, Integer startIndex, Integer size, MobileMboQBE filter, MobileWhereClause whereClause, MobileMboOrder order)
/*  80:    */     throws MobileApplicationException
/*  81:    */   {
/*  82:108 */     MobileMboData mboData = null;
/*  83:109 */     mboData = (MobileMboData)getService().invoke("getMobileMbos", new Object[] { name, startIndex, size, filter, whereClause, order });
/*  84:    */     
/*  85:    */ 
/*  86:    */ 
/*  87:    */ 
/*  88:    */ 
/*  89:    */ 
/*  90:116 */     return mboData;
/*  91:    */   }
/*  92:    */   
/*  93:    */   public int getMobileMboCount(String name)
/*  94:    */     throws MobileApplicationException
/*  95:    */   {
/*  96:122 */     Integer count = (Integer)getService().invoke("getMobileMboCount", new Object[] { name });
/*  97:123 */     return count.intValue();
/*  98:    */   }
/*  99:    */   
/* 100:    */   public int getMobileMboCount(String name, MobileMboQBE filter)
/* 101:    */     throws MobileApplicationException
/* 102:    */   {
/* 103:128 */     Integer count = (Integer)getService().invoke("getMobileMboCount", new Object[] { name, filter });
/* 104:129 */     return count.intValue();
/* 105:    */   }
/* 106:    */   
/* 107:    */   public int getMobileMboCount(String name, MobileMboQBE filter, MobileWhereClause whereClause)
/* 108:    */     throws MobileApplicationException
/* 109:    */   {
/* 110:134 */     Integer count = (Integer)getService().invoke("getMobileMboCount", new Object[] { name, filter, whereClause });
/* 111:135 */     return count.intValue();
/* 112:    */   }
/* 113:    */   
/* 114:    */   public MobileMboData getAppOptionsAuth(Integer startIndex, Integer size)
/* 115:    */     throws MobileApplicationException
/* 116:    */   {
/* 117:140 */     MobileMboData mboData = null;
/* 118:141 */     mboData = (MobileMboData)getService().invoke("getAppOptionsAuth", new Object[] { startIndex, size });
/* 119:    */     
/* 120:143 */     return mboData;
/* 121:    */   }
/* 122:    */   
/* 123:    */   public MobileMboData getIncrementalUpdateOfMobileMbos(String name, Integer startIndex, Integer size)
/* 124:    */     throws MobileApplicationException
/* 125:    */   {
/* 126:150 */     MobileMboData mboData = null;
/* 127:151 */     mboData = (MobileMboData)getService().invoke("getIncrementalUpdateOfMobileMbos", new Object[] { name, startIndex, size });
/* 128:    */     
/* 129:    */ 
/* 130:    */ 
/* 131:155 */     return mboData;
/* 132:    */   }
/* 133:    */   
/* 134:    */   public MobileMboData getIncrementalUpdateOfMobileMbos(String name, String[] queries, Integer startIndex, Integer size)
/* 135:    */     throws MobileApplicationException
/* 136:    */   {
/* 137:162 */     MobileMboData mboData = null;
/* 138:163 */     mboData = (MobileMboData)getService().invoke("getIncrementalUpdateOfMobileMbos", new Object[] { name, queries, startIndex, size });
/* 139:    */     
/* 140:    */ 
/* 141:    */ 
/* 142:167 */     return mboData;
/* 143:    */   }
/* 144:    */   
/* 145:    */   public MobileMboData getIncrementalUpdateOfMobileMbos(String name, String[] queries, Integer startIndex, Integer size, Boolean dependentFilterOnly)
/* 146:    */     throws MobileApplicationException
/* 147:    */   {
/* 148:174 */     MobileMboData mboData = null;
/* 149:175 */     mboData = (MobileMboData)getService().invoke("getIncrementalUpdateOfMobileMbos", new Object[] { name, queries, startIndex, size, dependentFilterOnly });
/* 150:    */     
/* 151:    */ 
/* 152:    */ 
/* 153:179 */     return mboData;
/* 154:    */   }
/* 155:    */   
/* 156:    */   public void acknowledgeIncrementalUpdate(String name)
/* 157:    */     throws MobileApplicationException
/* 158:    */   {
/* 159:185 */     getService().invoke("acknowledgeIncrementalUpdate", new Object[] { name });
/* 160:    */   }
/* 161:    */   
/* 162:    */   public void performDataTransaction(MobileMboChange mboChanges)
/* 163:    */     throws MobileApplicationException
/* 164:    */   {
/* 165:191 */     getService().invokeAsync("performDataTransaction", new Object[] { mboChanges });
/* 166:    */   }
/* 167:    */   
/* 168:    */   public void performDataTransaction(MobileMboData mbosChange)
/* 169:    */     throws MobileApplicationException
/* 170:    */   {
/* 171:197 */     getService().invokeAsync("performDataTransaction", new Object[] { mbosChange });
/* 172:    */   }
/* 173:    */   
/* 174:    */   public void performDataTransactionGivenUpOnError(MobileMboChange mboChanges)
/* 175:    */     throws MobileApplicationException
/* 176:    */   {
/* 177:204 */     getService().invokeAsync("performDataTransactionGivenUpOnError", new Object[] { mboChanges });
/* 178:    */   }
/* 179:    */   
/* 180:    */   public MobileMboData getDataTransactionResult(Integer startIndex, Integer chunkSize)
/* 181:    */     throws MobileApplicationException
/* 182:    */   {
/* 183:210 */     MobileMboData mboData = null;
/* 184:211 */     mboData = (MobileMboData)getService().invoke("getDataTransactionResult", new Object[] { startIndex, chunkSize });
/* 185:    */     
/* 186:    */ 
/* 187:214 */     return mboData;
/* 188:    */   }
/* 189:    */   
/* 190:    */   public void acknowledgeDataTransactionResult()
/* 191:    */     throws MobileApplicationException
/* 192:    */   {
/* 193:220 */     getService().invoke("acknowledgeDataTransactionResult", new Object[0]);
/* 194:    */   }
/* 195:    */   
/* 196:    */   public void hello()
/* 197:    */     throws MobileApplicationException
/* 198:    */   {
/* 199:225 */     getService().hello();
/* 200:    */   }
/* 201:    */   
/* 202:    */   public long getTimeDifference()
/* 203:    */     throws MobileApplicationException
/* 204:    */   {
/* 205:230 */     return getService().getTimeDifference();
/* 206:    */   }
/* 207:    */   
/* 208:    */   public boolean isServerAuthentication()
/* 209:    */     throws MobileApplicationException
/* 210:    */   {
/* 211:236 */     return getService().isServerAuthentication();
/* 212:    */   }
/* 213:    */   
/* 214:    */   public String getVersion()
/* 215:    */     throws MobileApplicationException
/* 216:    */   {
/* 217:241 */     String version = (String)getService().invoke("getVersion", new Object[0]);
/* 218:242 */     return version;
/* 219:    */   }
/* 220:    */   
/* 221:    */   public boolean hasPendingTransactions()
/* 222:    */     throws MobileApplicationException
/* 223:    */   {
/* 224:247 */     Boolean hasPendingTxn = (Boolean)getService().invoke("hasPendingTransactions", new Object[0]);
/* 225:    */     
/* 226:249 */     return hasPendingTxn.booleanValue();
/* 227:    */   }
/* 228:    */   
/* 229:    */   public boolean hasPendingErrorTransactions()
/* 230:    */     throws MobileApplicationException
/* 231:    */   {
/* 232:254 */     Boolean hasPendingETxn = (Boolean)getService().invoke("hasPendingErrorTransactions", new Object[0]);
/* 233:    */     
/* 234:256 */     return hasPendingETxn.booleanValue();
/* 235:    */   }
/* 236:    */   
/* 237:    */   public void logESigVerification(MobileMboChange mboChanges)
/* 238:    */     throws MobileApplicationException
/* 239:    */   {
/* 240:262 */     getService().invokeAsync("logESigVerification", new Object[] { mboChanges });
/* 241:    */   }
/* 242:    */   
/* 243:    */   public String[] getSmartSystemRefreshOrder()
/* 244:    */     throws MobileApplicationException
/* 245:    */   {
/* 246:267 */     String[] orderedNames = (String[])getService().invoke("getSmartSystemRefreshOrder", new Object[0]);
/* 247:    */     
/* 248:269 */     return orderedNames;
/* 249:    */   }
/* 250:    */   
/* 251:    */   public String[] getSystemRefreshOrder()
/* 252:    */     throws MobileApplicationException
/* 253:    */   {
/* 254:274 */     String[] orderedNames = (String[])getService().invoke("getSystemRefreshOrder", new Object[0]);
/* 255:    */     
/* 256:276 */     return orderedNames;
/* 257:    */   }
/* 258:    */   
/* 259:    */   public String[] getSmartRefreshOrder(String[] queries)
/* 260:    */     throws MobileApplicationException
/* 261:    */   {
/* 262:281 */     String[] orderedNames = (String[])getService().invoke("getSmartRefreshOrder", new Object[] { queries });
/* 263:    */     
/* 264:283 */     return orderedNames;
/* 265:    */   }
/* 266:    */   
/* 267:    */   public String[] getRefreshOrder()
/* 268:    */     throws MobileApplicationException
/* 269:    */   {
/* 270:288 */     String[] orderedNames = (String[])getService().invoke("getRefreshOrder", new Object[0]);
/* 271:    */     
/* 272:290 */     return orderedNames;
/* 273:    */   }
/* 274:    */   
/* 275:    */   public String[] getSmartWorkRefreshOrder(String[] queries)
/* 276:    */     throws MobileApplicationException
/* 277:    */   {
/* 278:295 */     String[] orderedNames = (String[])getService().invoke("getSmartWorkRefreshOrder", new Object[] { queries });
/* 279:    */     
/* 280:297 */     return orderedNames;
/* 281:    */   }
/* 282:    */   
/* 283:    */   public String[] getWorkRefreshOrder()
/* 284:    */     throws MobileApplicationException
/* 285:    */   {
/* 286:302 */     String[] orderedNames = (String[])getService().invoke("getWorkRefreshOrder", new Object[0]);
/* 287:    */     
/* 288:304 */     return orderedNames;
/* 289:    */   }
/* 290:    */   
/* 291:    */   public void changePassword(String oldPassword, String newPassword)
/* 292:    */     throws MobileApplicationException
/* 293:    */   {
/* 294:309 */     getService().invoke("changePassword", new Object[] { oldPassword, newPassword });
/* 295:    */   }
/* 296:    */   
/* 297:    */   public boolean isPasswordExpired()
/* 298:    */     throws MobileApplicationException
/* 299:    */   {
/* 300:314 */     Boolean passwordExpired = (Boolean)getService().invoke("isPasswordExpired", new Object[0]);
/* 301:315 */     return passwordExpired.booleanValue();
/* 302:    */   }
/* 303:    */   
/* 304:    */   public void changeExpiredPassword(String oldPassword, String newPassword)
/* 305:    */     throws MobileApplicationException
/* 306:    */   {
/* 307:320 */     getService().invoke("changeExpiredPassword", new Object[] { oldPassword, newPassword });
/* 308:    */   }
/* 309:    */   
/* 310:    */   public String[] getAdHocRefreshOrder(String dataGroupName)
/* 311:    */     throws MobileApplicationException
/* 312:    */   {
/* 313:325 */     String[] orderedNames = (String[])getService().invoke("getAdHocRefreshOrder", new Object[] { dataGroupName });
/* 314:    */     
/* 315:327 */     return orderedNames;
/* 316:    */   }
/* 317:    */   
/* 318:    */   public MobileMboData getAdHocMobileMbo(String name, String recordId)
/* 319:    */     throws MobileApplicationException
/* 320:    */   {
/* 321:333 */     MobileMboData mboData = null;
/* 322:334 */     mboData = (MobileMboData)getService().invoke("getAdHocMobileMbo", new Object[] { name, recordId });
/* 323:    */     
/* 324:336 */     return mboData;
/* 325:    */   }
/* 326:    */   
/* 327:    */   public void createAdHocQuery(String dataGroupName, String recordId)
/* 328:    */     throws MobileApplicationException
/* 329:    */   {
/* 330:342 */     getService().invoke("createAdHocQuery", new Object[] { dataGroupName, recordId });
/* 331:    */   }
/* 332:    */   
/* 333:    */   public void createAdHocQuery(String dataGroupName, String description, String recordId)
/* 334:    */     throws MobileApplicationException
/* 335:    */   {
/* 336:348 */     getService().invoke("createAdHocQuery", new Object[] { dataGroupName, description, recordId });
/* 337:    */   }
/* 338:    */   
/* 339:    */   public void removeAdHocQueryList()
/* 340:    */     throws MobileApplicationException
/* 341:    */   {
/* 342:353 */     getService().invoke("removeAdHocQueryList", new Object[0]);
/* 343:    */   }
/* 344:    */   
/* 345:    */   public void acknowledgeAdHocRecordData(String mobileMboName, String recordId)
/* 346:    */     throws MobileApplicationException
/* 347:    */   {
/* 348:359 */     getService().invoke("acknowledgeAdHocRecordData", new Object[] { mobileMboName, recordId });
/* 349:    */   }
/* 350:    */   
/* 351:    */   public boolean hasAdHocData()
/* 352:    */     throws MobileApplicationException
/* 353:    */   {
/* 354:364 */     Boolean hasAdHocData = (Boolean)getService().invoke("hasAdHocData", new Object[0]);
/* 355:365 */     return hasAdHocData.booleanValue();
/* 356:    */   }
/* 357:    */   
/* 358:    */   public MobileMbo getLatestTransactionData(MobileMbo mobileDataTxnMbo)
/* 359:    */     throws MobileApplicationException
/* 360:    */   {
/* 361:371 */     MobileMbo mobileMbo = (MobileMbo)getService().invoke("getLatestTransactionData", new Object[] { mobileDataTxnMbo });
/* 362:    */     
/* 363:373 */     return mobileMbo;
/* 364:    */   }
/* 365:    */   
/* 366:    */   public void cleanupErrTransactionData(MobileMbo mobileDataTxnMbo)
/* 367:    */     throws MobileApplicationException
/* 368:    */   {
/* 369:380 */     getService().invoke("cleanupErrTransactionData", new Object[] { mobileDataTxnMbo });
/* 370:    */   }
/* 371:    */   
/* 372:    */   public void storeSnapshot(byte[] snapshotData, String snapshotUserId)
/* 373:    */     throws MobileApplicationException
/* 374:    */   {
/* 375:386 */     getService().invoke("storeSnapshot", new Object[] { snapshotData, snapshotUserId });
/* 376:    */   }
/* 377:    */   
/* 378:    */   public byte[] retrieveSnapshot()
/* 379:    */     throws MobileApplicationException
/* 380:    */   {
/* 381:392 */     return (byte[])getService().invoke("retrieveSnapshot", new Object[0]);
/* 382:    */   }
/* 383:    */   
/* 384:    */   public void addSnapshotChunk(Integer chunkIndex, byte[] snapshotData)
/* 385:    */     throws MobileApplicationException
/* 386:    */   {
/* 387:397 */     getService().invoke("addSnapshotChunk", new Object[] { chunkIndex, snapshotData });
/* 388:    */   }
/* 389:    */   
/* 390:    */   public void storeSnapshotChunks(String snapshotUserId)
/* 391:    */     throws MobileApplicationException
/* 392:    */   {
/* 393:402 */     getService().invoke("storeSnapshotChunks", new Object[] { snapshotUserId });
/* 394:    */   }
/* 395:    */   
/* 396:    */   public void removeSnapshot()
/* 397:    */     throws MobileApplicationException
/* 398:    */   {
/* 399:407 */     getService().invoke("removeSnapshot", new Object[0]);
/* 400:    */   }
/* 401:    */   
/* 402:    */   public int getSnapshotChunks(int chunkSize)
/* 403:    */     throws MobileApplicationException
/* 404:    */   {
/* 405:412 */     Integer chunks = (Integer)getService().invoke("getSnapshotChunks", new Object[] { new Integer(chunkSize) });
/* 406:413 */     return chunks.intValue();
/* 407:    */   }
/* 408:    */   
/* 409:    */   public byte[] retrieveSnapshotChunk(int chunkIndex)
/* 410:    */     throws MobileApplicationException
/* 411:    */   {
/* 412:418 */     return (byte[])getService().invoke("retrieveSnapshotChunk", new Object[] { new Integer(chunkIndex) });
/* 413:    */   }
/* 414:    */   
/* 415:    */   public int checkForUpdate(String language, String version, String profile)
/* 416:    */     throws MobileApplicationException
/* 417:    */   {
/* 418:424 */     return ((Integer)getService().invoke("checkForUpdate", new Object[] { language, version, profile })).intValue();
/* 419:    */   }
/* 420:    */   
/* 421:    */   /**
/* 422:    */    * @deprecated
/* 423:    */    */
/* 424:    */   public MobileMbo getUpdateJar(String language, String profile)
/* 425:    */     throws MobileApplicationException
/* 426:    */   {
/* 427:434 */     return (MobileMbo)getService().invoke("getUpdateJar", new Object[] { language, profile });
/* 428:    */   }
/* 429:    */   
/* 430:    */   public int getUpdateJarNumberOfChunks(String profile, String language, int chunkSize)
/* 431:    */     throws MobileApplicationException
/* 432:    */   {
/* 433:439 */     Integer chunks = (Integer)getService().invoke("getUpdateJarNumberOfChunks", new Object[] { profile, language, new Integer(chunkSize) });
/* 434:440 */     return chunks.intValue();
/* 435:    */   }
/* 436:    */   
/* 437:    */   public byte[] retrieveUpdateJarFile(String profile, String language, int chunkSize, int chunkIndex)
/* 438:    */     throws MobileApplicationException
/* 439:    */   {
/* 440:445 */     return (byte[])getService().invoke("retrieveUpdateJarFile", new Object[] { profile, language, new Integer(chunkSize), new Integer(chunkIndex) });
/* 441:    */   }
/* 442:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.DefaultMobileWebServiceProxy
 * JD-Core Version:    0.7.0.1
 */