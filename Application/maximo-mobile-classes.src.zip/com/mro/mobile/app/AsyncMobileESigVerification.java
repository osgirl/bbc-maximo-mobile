/*  1:   */ package com.mro.mobile.app;
/*  2:   */ 
/*  3:   */ import com.mro.mobile.MobileApplicationException;
/*  4:   */ import com.mro.mobile.MobileMessageGenerator;
/*  5:   */ import com.mro.mobile.app.async.AsyncEventHandlerSupport;
/*  6:   */ import com.mro.mobile.ui.MobileMboDataBean;
/*  7:   */ import com.mro.mobile.ui.event.UIEvent;
/*  8:   */ import com.mro.mobile.ui.res.UIUtil;
/*  9:   */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/* 10:   */ 
/* 11:   */ public class AsyncMobileESigVerification
/* 12:   */   extends AsyncEventHandlerSupport
/* 13:   */ {
/* 14:   */   private static final String RUN_POSTESIG_INSTRUCTION = "RUN_POSTESIG_INSTRUCTION";
/* 15:28 */   private static final Boolean RUN_POSTESIG_YES = Boolean.TRUE;
/* 16:29 */   private static final Boolean RUN_POSTESIG_NO = Boolean.FALSE;
/* 17:31 */   private MobileMboDataBean databean = null;
/* 18:   */   private String userName;
/* 19:   */   private String password;
/* 20:   */   private String rc;
/* 21:   */   
/* 22:   */   public AsyncMobileESigVerification(MobileMboDataBean databean, String userName, String password, String rc)
/* 23:   */   {
/* 24:38 */     this.databean = databean;
/* 25:   */     
/* 26:40 */     this.userName = userName;
/* 27:41 */     this.password = password;
/* 28:42 */     this.rc = rc;
/* 29:   */   }
/* 30:   */   
/* 31:   */   public boolean doRealWok(UIEvent event)
/* 32:   */     throws MobileApplicationException
/* 33:   */   {
/* 34:46 */     super.updateProgressBar("sysconnectingserver", null, event);
/* 35:47 */     boolean ret = this.databean.verifyESig(this.userName, this.password, this.rc);
/* 36:48 */     if (ret) {
/* 37:49 */       MobileDeviceAppSession.getSession().setAttribute("RUN_POSTESIG_INSTRUCTION", RUN_POSTESIG_YES);
/* 38:   */     } else {
/* 39:52 */       MobileDeviceAppSession.getSession().setAttribute("RUN_POSTESIG_INSTRUCTION", RUN_POSTESIG_NO);
/* 40:   */     }
/* 41:54 */     return true;
/* 42:   */   }
/* 43:   */   
/* 44:   */   public void postRealWork(UIEvent event)
/* 45:   */     throws MobileApplicationException
/* 46:   */   {
/* 47:   */     try
/* 48:   */     {
/* 49:59 */       Object obj = MobileDeviceAppSession.getSession().getAttribute("RUN_POSTESIG_INSTRUCTION");
/* 50:60 */       if ((obj == null) || (!((Boolean)obj).booleanValue()))
/* 51:   */       {
/* 52:61 */         UIUtil.showFailureMessageBox(MobileMessageGenerator.generate("alertInvalidESig", null));
/* 53:62 */         event.setEventErrored();
/* 54:   */       }
/* 55:   */       else
/* 56:   */       {
/* 57:66 */         UIUtil.closePage();
/* 58:67 */         MobileDeviceAppSession session = MobileDeviceAppSession.getSession();
/* 59:68 */         UIEvent esigEvent = (UIEvent)session.getAttribute("esig_event");
/* 60:69 */         UIEvent origEvent = (UIEvent)esigEvent.getValue();
/* 61:70 */         origEvent.setPassedESig(true);
/* 62:71 */         origEvent.setEventErrored(false);
/* 63:72 */         UIUtil.getApplication().setUserEvent(origEvent);
/* 64:73 */         ((AbstractMobileControl)origEvent.getCreatingObject()).handleEvent(origEvent);
/* 65:74 */         session.removeAttribute("esig_event");
/* 66:   */       }
/* 67:   */     }
/* 68:   */     finally
/* 69:   */     {
/* 70:77 */       MobileDeviceAppSession.getSession().removeAttribute("RUN_POSTESIG_INSTRUCTION");
/* 71:   */     }
/* 72:   */   }
/* 73:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.AsyncMobileESigVerification
 * JD-Core Version:    0.7.0.1
 */