/*    1:     */ package com.mro.mobile.app;
/*    2:     */ 
/*    3:     */ import com.mro.mobile.MobileApplicationException;
/*    4:     */ import com.mro.mobile.MobileMessageGenerator;
/*    5:     */ import com.mro.mobile.ProgressObserver;
/*    6:     */ import com.mro.mobile.mbo.MobileMbo;
/*    7:     */ import com.mro.mobile.mbo.MobileMboAttributeInfo;
/*    8:     */ import com.mro.mobile.mbo.MobileMboDependencyManager;
/*    9:     */ import com.mro.mobile.mbo.MobileMboDependencyManager.RelationDisplayInfo;
/*   10:     */ import com.mro.mobile.mbo.MobileMboInfo;
/*   11:     */ import com.mro.mobile.mbo.MobileMboQBE;
/*   12:     */ import com.mro.mobile.mbo.MobileMboUtil;
/*   13:     */ import com.mro.mobile.ui.DataBeanCache;
/*   14:     */ import com.mro.mobile.ui.DataBeanCacheItem;
/*   15:     */ import com.mro.mobile.ui.MobileMboDataBean;
/*   16:     */ import com.mro.mobile.ui.MobileMboDataBeanManager;
/*   17:     */ import com.mro.mobile.ui.MobileMboDataBeanQBE;
/*   18:     */ import com.mro.mobile.ui.event.UIEvent;
/*   19:     */ import com.mro.mobile.ui.res.MobileUIManager;
/*   20:     */ import com.mro.mobile.ui.res.MobileUIResources;
/*   21:     */ import com.mro.mobile.ui.res.MobileUIResourcesType;
/*   22:     */ import com.mro.mobile.ui.res.UIUtil;
/*   23:     */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*   24:     */ import com.mro.mobile.ui.res.controls.ButtonControl;
/*   25:     */ import com.mro.mobile.ui.res.controls.CheckboxControl;
/*   26:     */ import com.mro.mobile.ui.res.controls.InputControl;
/*   27:     */ import com.mro.mobile.ui.res.controls.LinkControl;
/*   28:     */ import com.mro.mobile.ui.res.controls.LookupControl;
/*   29:     */ import com.mro.mobile.ui.res.controls.PageControl;
/*   30:     */ import com.mro.mobile.ui.res.controls.ReasonForChangeControl;
/*   31:     */ import com.mro.mobile.ui.res.controls.StateControl;
/*   32:     */ import com.mro.mobile.ui.res.controls.TextboxControl;
/*   33:     */ import com.mro.mobile.ui.res.controls.ToolBarContainerControl;
/*   34:     */ import com.mro.mobile.util.MaximoMobileConstants;
/*   35:     */ import com.mro.mobile.util.MobileLogger;
/*   36:     */ import com.mro.mobile.util.MobileLoggerFactory;
/*   37:     */ import com.mro.mobile.util.StringUtils;
/*   38:     */ import java.io.File;
/*   39:     */ import java.io.FileOutputStream;
/*   40:     */ import java.util.ArrayList;
/*   41:     */ import java.util.Date;
/*   42:     */ import java.util.Enumeration;
/*   43:     */ import java.util.Iterator;
/*   44:     */ import java.util.Locale;
/*   45:     */ import java.util.Vector;
/*   46:     */ 
/*   47:     */ public class AppEventHandler
/*   48:     */   extends DefaultEventHandler
/*   49:     */ {
/*   50:  75 */   private boolean resetAdHocDataPrompted = false;
/*   51:  77 */   private boolean updateChecked = false;
/*   52:  79 */   private boolean updateRefreshChecking = false;
/*   53:     */   
/*   54:     */   public boolean showpage(UIEvent event)
/*   55:     */     throws MobileApplicationException
/*   56:     */   {
/*   57:  90 */     UIUtil.showPage((String)event.getValue());
/*   58:  91 */     return true;
/*   59:     */   }
/*   60:     */   
/*   61:     */   public boolean gotopage(UIEvent event)
/*   62:     */     throws MobileApplicationException
/*   63:     */   {
/*   64: 105 */     UIUtil.gotoPage((String)event.getValue(), (AbstractMobileControl)event.getCreatingObject());
/*   65: 106 */     return true;
/*   66:     */   }
/*   67:     */   
/*   68:     */   public boolean gotoerrorpage(UIEvent event)
/*   69:     */     throws MobileApplicationException
/*   70:     */   {
/*   71: 117 */     AbstractMobileControl callingControl = (AbstractMobileControl)event.getCreatingObject();
/*   72: 118 */     callingControl.getDataBean().setErrorFilter();
/*   73: 119 */     UIUtil.gotoPage((String)event.getValue(), (AbstractMobileControl)event.getCreatingObject());
/*   74: 120 */     UIEvent uievent = new UIEvent(this, "gototab", null, callingControl.getStringValue("targettabid"));
/*   75: 121 */     UIUtil.getCurrentScreen().sendEventDown(uievent);
/*   76: 122 */     return true;
/*   77:     */   }
/*   78:     */   
/*   79:     */   public boolean adhocdownload(UIEvent event)
/*   80:     */     throws MobileApplicationException
/*   81:     */   {
/*   82: 126 */     AbstractMobileControl callingControl = (AbstractMobileControl)event.getCreatingObject();
/*   83: 127 */     MobileMboDataBean dataBean = callingControl.getDataBean();
/*   84:     */     
/*   85: 129 */     ProgressObserver observer = event.getProgressObserver();
/*   86: 130 */     BasicMobileDeviceUIApplication app = UIUtil.getApplication();
/*   87:     */     
/*   88: 132 */     MobileMbo mobileMbo = dataBean.getMobileMbo();
/*   89: 133 */     if (mobileMbo == null) {
/*   90: 134 */       return true;
/*   91:     */     }
/*   92: 137 */     app.downloadAdHocMobileMbo(observer, dataBean.getName(), "", mobileMbo.getId() + "");
/*   93:     */     
/*   94: 139 */     return true;
/*   95:     */   }
/*   96:     */   
/*   97:     */   public boolean displayadhocdownload(UIEvent event)
/*   98:     */     throws MobileApplicationException
/*   99:     */   {
/*  100: 143 */     AbstractMobileControl callingControl = (AbstractMobileControl)event.getCreatingObject();
/*  101: 144 */     MobileMboDataBean dataBean = callingControl.getDataBean();
/*  102: 146 */     if (dataBean.isOnline())
/*  103:     */     {
/*  104: 147 */       AbstractMobileControl control = (AbstractMobileControl)event.getCreatingObject();
/*  105: 148 */       control.setVisibility(true);
/*  106:     */     }
/*  107:     */     else
/*  108:     */     {
/*  109: 150 */       AbstractMobileControl control = (AbstractMobileControl)event.getCreatingObject();
/*  110: 151 */       control.setVisibility(false);
/*  111:     */     }
/*  112: 154 */     return true;
/*  113:     */   }
/*  114:     */   
/*  115:     */   public boolean displaydocextract(UIEvent event)
/*  116:     */     throws MobileApplicationException
/*  117:     */   {
/*  118: 159 */     AbstractMobileControl control = (AbstractMobileControl)event.getCreatingObject();
/*  119: 160 */     control.setVisibility(canDisplayDocExtract(event));
/*  120: 161 */     return true;
/*  121:     */   }
/*  122:     */   
/*  123:     */   private boolean canDisplayDocExtract(UIEvent event)
/*  124:     */     throws MobileApplicationException
/*  125:     */   {
/*  126: 165 */     AbstractMobileControl callingControl = (AbstractMobileControl)event.getCreatingObject();
/*  127: 166 */     MobileMboDataBean dataBean = callingControl.getDataBean();
/*  128: 167 */     if (dataBean.getMobileMbo().isNew()) {
/*  129: 168 */       return false;
/*  130:     */     }
/*  131: 170 */     if (!dataBean.getMobileMbo().isNull("CONTENT")) {
/*  132: 171 */       return true;
/*  133:     */     }
/*  134: 173 */     return false;
/*  135:     */   }
/*  136:     */   
/*  137:     */   public boolean docextract(UIEvent event)
/*  138:     */     throws MobileApplicationException
/*  139:     */   {
/*  140: 178 */     AbstractMobileControl callingControl = (AbstractMobileControl)event.getCreatingObject();
/*  141: 179 */     MobileMboDataBean dataBean = callingControl.getDataBean();
/*  142: 181 */     if (dataBean.getMobileMbo().isNull("CONTENT")) {
/*  143: 182 */       return true;
/*  144:     */     }
/*  145:     */     String fileName;
/*  146:     */     try
/*  147:     */     {
/*  148: 187 */       fileName = extractDocument(dataBean);
/*  149:     */     }
/*  150:     */     catch (Exception e)
/*  151:     */     {
/*  152: 189 */       MobileApplicationException ex = new MobileApplicationException(e.getMessage());
/*  153: 190 */       UIUtil.showExceptionMessage(ex, null, 0);
/*  154: 191 */       return true;
/*  155:     */     }
/*  156: 194 */     if (fileName != null) {
/*  157: 195 */       UIUtil.showInfoMessageBox(MobileMessageGenerator.generate("docextractinfo", new Object[] { fileName }));
/*  158:     */     }
/*  159: 198 */     return true;
/*  160:     */   }
/*  161:     */   
/*  162:     */   public String extractDocument(MobileMboDataBean dataBean)
/*  163:     */     throws Exception
/*  164:     */   {
/*  165: 202 */     String urlType = dataBean.getMobileMbo().getValue("INTERNALURLTYPE");
/*  166: 203 */     String fileName = dataBean.getMobileMbo().getValue("FILENAME");
/*  167: 204 */     byte[] docContent = dataBean.getMobileMbo().getBinaryValue("CONTENT");
/*  168:     */     
/*  169: 206 */     String docRootFolder = getDocRootFolder();
/*  170:     */     
/*  171: 208 */     String singleKeyAttribute = null;
/*  172: 209 */     MobileMbo topOwner = dataBean.getTopOwner();
/*  173: 210 */     MobileMboInfo ownerInfo = topOwner.getMobileMboInfo();
/*  174: 211 */     String[] attrs = ownerInfo.getAttributeNames();
/*  175: 212 */     for (int i = 0; i < attrs.length; i++)
/*  176:     */     {
/*  177: 213 */       String attrName = attrs[i];
/*  178:     */       
/*  179: 215 */       MobileMboAttributeInfo attrInfo = ownerInfo.getAttributeInfo(attrs[i]);
/*  180: 216 */       if ((attrInfo.isKey()) && 
/*  181: 217 */         (!attrName.equals(ownerInfo.getItemSetAttribute())) && (!attrName.equals(ownerInfo.getCompanySetAttribute())) && (!attrName.equals(ownerInfo.getOrgAttribute())) && (!attrName.equals(ownerInfo.getSiteAttribute())) && (!attrName.equals("CLASS")))
/*  182:     */       {
/*  183: 222 */         singleKeyAttribute = attrName;
/*  184: 223 */         break;
/*  185:     */       }
/*  186:     */     }
/*  187: 227 */     if ((!docRootFolder.endsWith("/")) && (!docRootFolder.endsWith("\\"))) {
/*  188: 228 */       docRootFolder = docRootFolder + File.separator;
/*  189:     */     }
/*  190: 231 */     String folderName = topOwner.getMobileMboInfo().getDescription();
/*  191: 232 */     docRootFolder = docRootFolder + folderName;
/*  192: 233 */     if (singleKeyAttribute != null)
/*  193:     */     {
/*  194: 234 */       String keyValue = topOwner.getValue(singleKeyAttribute);
/*  195:     */       
/*  196: 236 */       String siteAttr = ownerInfo.getSiteAttribute();
/*  197: 237 */       if ((siteAttr != null) && (siteAttr.length() > 0)) {
/*  198: 239 */         keyValue = topOwner.getValue(siteAttr) + File.separator + keyValue;
/*  199:     */       }
/*  200: 241 */       docRootFolder = docRootFolder + File.separator + keyValue + File.separator;
/*  201:     */     }
/*  202: 244 */     if ((!urlType.equalsIgnoreCase("FILE")) && (!urlType.equalsIgnoreCase("WWW"))) {
/*  203: 245 */       return null;
/*  204:     */     }
/*  205: 249 */     File f1 = new File(docRootFolder);
/*  206: 250 */     f1.mkdirs();
/*  207:     */     
/*  208: 252 */     String fileNameToWriteTo = docRootFolder + fileName;
/*  209: 253 */     File f = new File(fileNameToWriteTo);
/*  210:     */     
/*  211: 255 */     FileOutputStream fos = new FileOutputStream(f);
/*  212: 256 */     fos.write(docContent);
/*  213: 257 */     fos.flush();
/*  214: 258 */     fos.close();
/*  215:     */     
/*  216: 260 */     return fileNameToWriteTo;
/*  217:     */   }
/*  218:     */   
/*  219:     */   public boolean docextractall(UIEvent event)
/*  220:     */     throws MobileApplicationException
/*  221:     */   {
/*  222: 264 */     AbstractMobileControl callingControl = (AbstractMobileControl)event.getCreatingObject();
/*  223: 265 */     MobileMboDataBean dataBean = callingControl.getDataBean();
/*  224:     */     String fileName;
/*  225:     */     try
/*  226:     */     {
/*  227: 268 */       fileName = extractAllDocuments(dataBean);
/*  228:     */     }
/*  229:     */     catch (Exception e)
/*  230:     */     {
/*  231: 270 */       MobileApplicationException ex = new MobileApplicationException(e.getMessage());
/*  232: 271 */       UIUtil.showExceptionMessage(ex, null, 0);
/*  233: 272 */       return true;
/*  234:     */     }
/*  235: 275 */     if (fileName != null) {
/*  236: 276 */       UIUtil.showInfoMessageBox(MobileMessageGenerator.generate("docextractallinfo", new Object[] { fileName }));
/*  237:     */     }
/*  238: 279 */     return true;
/*  239:     */   }
/*  240:     */   
/*  241:     */   public static MobileMboDataBean getCachedDataBean(String dataBeanName)
/*  242:     */     throws MobileApplicationException
/*  243:     */   {
/*  244: 283 */     MobileMboDataBean dataBean = DataBeanCache.findDataBean(dataBeanName);
/*  245: 284 */     if (dataBean == null)
/*  246:     */     {
/*  247: 285 */       MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager(dataBeanName);
/*  248: 286 */       dataBean = mgrDBMgr.getDataBean();
/*  249:     */       
/*  250:     */ 
/*  251:     */ 
/*  252:     */ 
/*  253:     */ 
/*  254:     */ 
/*  255:     */ 
/*  256:     */ 
/*  257:     */ 
/*  258:     */ 
/*  259: 297 */       DataBeanCache.cacheDataBean(dataBeanName, new DataBeanCacheItem(dataBeanName, dataBeanName, dataBean));
/*  260:     */     }
/*  261: 300 */     return dataBean;
/*  262:     */   }
/*  263:     */   
/*  264:     */   private String getDocRootFolder()
/*  265:     */   {
/*  266: 304 */     BasicMobileDeviceUIApplication app = UIUtil.getApplication();
/*  267:     */     
/*  268: 306 */     String docRootFolder = app.getProperty("MOBILEWO.DOCEXTRACTFOLDER");
/*  269: 307 */     if (docRootFolder == null) {
/*  270: 308 */       docRootFolder = MaximoMobileConstants.ATTACHDOCDEFAULTFOLDER;
/*  271:     */     }
/*  272: 312 */     String rootFileStorageDir = app.getSystemProperty("maximo.mobile.root.storage.folder");
/*  273: 314 */     if (!StringUtils.isStringEmpty(rootFileStorageDir)) {
/*  274: 315 */       docRootFolder = rootFileStorageDir + docRootFolder;
/*  275:     */     }
/*  276: 318 */     return docRootFolder;
/*  277:     */   }
/*  278:     */   
/*  279:     */   public String extractAllDocuments(MobileMboDataBean dataBean)
/*  280:     */     throws Exception
/*  281:     */   {
/*  282: 323 */     String docRootFolder = getDocRootFolder();
/*  283:     */     
/*  284: 325 */     String singleKeyAttribute = null;
/*  285: 326 */     MobileMbo topOwner = dataBean.getTopOwner();
/*  286: 327 */     MobileMboInfo ownerInfo = topOwner.getMobileMboInfo();
/*  287: 328 */     String[] attrs = ownerInfo.getAttributeNames();
/*  288: 329 */     for (int i = 0; i < attrs.length; i++)
/*  289:     */     {
/*  290: 330 */       String attrName = attrs[i];
/*  291:     */       
/*  292: 332 */       MobileMboAttributeInfo attrInfo = ownerInfo.getAttributeInfo(attrs[i]);
/*  293: 333 */       if ((attrInfo.isKey()) && 
/*  294: 334 */         (!attrName.equals(ownerInfo.getItemSetAttribute())) && (!attrName.equals(ownerInfo.getCompanySetAttribute())) && (!attrName.equals(ownerInfo.getOrgAttribute())) && (!attrName.equals(ownerInfo.getSiteAttribute())) && (!attrName.equals("CLASS")))
/*  295:     */       {
/*  296: 346 */         singleKeyAttribute = attrName;
/*  297: 347 */         break;
/*  298:     */       }
/*  299:     */     }
/*  300: 351 */     if ((!docRootFolder.endsWith("/")) && (!docRootFolder.endsWith("\\"))) {
/*  301: 352 */       docRootFolder = docRootFolder + File.separator;
/*  302:     */     }
/*  303: 355 */     String folderName = topOwner.getMobileMboInfo().getDescription();
/*  304: 356 */     docRootFolder = docRootFolder + folderName;
/*  305: 357 */     if (singleKeyAttribute != null)
/*  306:     */     {
/*  307: 358 */       String keyValue = topOwner.getValue(singleKeyAttribute);
/*  308:     */       
/*  309: 360 */       String siteAttr = ownerInfo.getSiteAttribute();
/*  310: 361 */       if ((siteAttr != null) && (siteAttr.length() > 0)) {
/*  311: 363 */         keyValue = topOwner.getValue(siteAttr) + File.separator + keyValue;
/*  312:     */       }
/*  313: 365 */       docRootFolder = docRootFolder + File.separator + keyValue + File.separator;
/*  314:     */     }
/*  315: 368 */     int noOfFilesWritten = 0;
/*  316:     */     
/*  317: 370 */     int i = 0;
/*  318:     */     for (;;)
/*  319:     */     {
/*  320: 372 */       MobileMbo mobileMbo = dataBean.getMobileMbo(i);
/*  321: 373 */       if (mobileMbo == null) {
/*  322:     */         break;
/*  323:     */       }
/*  324: 377 */       i++;
/*  325: 379 */       if (!mobileMbo.isNull("CONTENT"))
/*  326:     */       {
/*  327: 383 */         String urlType = mobileMbo.getValue("INTERNALURLTYPE");
/*  328: 384 */         String fileName = mobileMbo.getValue("FILENAME");
/*  329: 385 */         byte[] docContent = mobileMbo.getBinaryValue("CONTENT");
/*  330: 387 */         if ((urlType.equalsIgnoreCase("FILE")) || (urlType.equalsIgnoreCase("WWW")))
/*  331:     */         {
/*  332: 392 */           File f1 = new File(docRootFolder);
/*  333: 393 */           f1.mkdirs();
/*  334:     */           
/*  335: 395 */           String fileNameToWriteTo = docRootFolder + fileName;
/*  336: 396 */           File f = new File(fileNameToWriteTo);
/*  337:     */           try
/*  338:     */           {
/*  339: 399 */             FileOutputStream fos = new FileOutputStream(f);
/*  340: 400 */             fos.write(docContent);
/*  341: 401 */             fos.flush();
/*  342: 402 */             fos.close();
/*  343:     */           }
/*  344:     */           catch (Exception ex)
/*  345:     */           {
/*  346: 404 */             MobileLoggerFactory.getDefaultLogger().warn("Error encountered writting docContent to file", ex);
/*  347:     */           }
/*  348: 407 */           noOfFilesWritten++;
/*  349:     */         }
/*  350:     */       }
/*  351:     */     }
/*  352: 410 */     if (noOfFilesWritten <= 0) {
/*  353: 411 */       return null;
/*  354:     */     }
/*  355: 414 */     if ((docRootFolder.endsWith("/")) || (docRootFolder.endsWith("\\"))) {
/*  356: 415 */       docRootFolder = docRootFolder.substring(0, docRootFolder.length() - 1);
/*  357:     */     }
/*  358: 418 */     return docRootFolder;
/*  359:     */   }
/*  360:     */   
/*  361:     */   public boolean displaydocextractall(UIEvent event)
/*  362:     */     throws MobileApplicationException
/*  363:     */   {
/*  364: 422 */     AbstractMobileControl callingControl = (AbstractMobileControl)event.getCreatingObject();
/*  365: 423 */     MobileMboDataBean dataBean = callingControl.getDataBean();
/*  366:     */     
/*  367: 425 */     AbstractMobileControl control = (AbstractMobileControl)event.getCreatingObject();
/*  368:     */     
/*  369: 427 */     int i = 0;
/*  370: 428 */     int extractFileCount = 0;
/*  371:     */     for (;;)
/*  372:     */     {
/*  373: 431 */       MobileMbo mobileMbo = dataBean.getMobileMbo(i);
/*  374: 432 */       if (mobileMbo == null) {
/*  375:     */         break;
/*  376:     */       }
/*  377: 436 */       i++;
/*  378:     */       
/*  379: 438 */       String urlType = mobileMbo.getValue("INTERNALURLTYPE");
/*  380: 439 */       if (urlType.equalsIgnoreCase("FILE"))
/*  381:     */       {
/*  382: 440 */         byte[] docContent = mobileMbo.getBinaryValue("CONTENT");
/*  383: 441 */         if (docContent != null) {
/*  384: 442 */           extractFileCount++;
/*  385:     */         }
/*  386:     */       }
/*  387:     */     }
/*  388: 447 */     if (extractFileCount > 0) {
/*  389: 448 */       control.setVisibility(true);
/*  390:     */     } else {
/*  391: 450 */       control.setVisibility(false);
/*  392:     */     }
/*  393: 453 */     return true;
/*  394:     */   }
/*  395:     */   
/*  396:     */   public boolean displaydocdelete(UIEvent event)
/*  397:     */     throws MobileApplicationException
/*  398:     */   {
/*  399: 457 */     AbstractMobileControl callingControl = (AbstractMobileControl)event.getCreatingObject();
/*  400: 458 */     MobileMboDataBean dataBean = callingControl.getDataBean();
/*  401:     */     
/*  402: 460 */     AbstractMobileControl control = (AbstractMobileControl)event.getCreatingObject();
/*  403: 461 */     if (dataBean.getMobileMbo().isNew()) {
/*  404: 462 */       control.setVisibility(true);
/*  405:     */     } else {
/*  406: 464 */       control.setVisibility(false);
/*  407:     */     }
/*  408: 467 */     return true;
/*  409:     */   }
/*  410:     */   
/*  411:     */   public boolean docdelete(UIEvent event)
/*  412:     */     throws MobileApplicationException
/*  413:     */   {
/*  414: 471 */     AbstractMobileControl callingControl = (AbstractMobileControl)event.getCreatingObject();
/*  415: 472 */     MobileMboDataBean dataBean = callingControl.getDataBean();
/*  416: 474 */     if (!dataBean.getMobileMbo().isNew()) {
/*  417: 475 */       return true;
/*  418:     */     }
/*  419: 478 */     if (event.getMsgResponse().equals("-1"))
/*  420:     */     {
/*  421: 479 */       UIUtil.showOKCANCELMessageBox(event, MobileMessageGenerator.generate("deleteattachdoc", null));
/*  422: 480 */       return true;
/*  423:     */     }
/*  424: 481 */     if (event.getMsgResponse().equals("1"))
/*  425:     */     {
/*  426: 482 */       dataBean.getMobileMbo().delete();
/*  427: 483 */       dataBean.getDataBeanManager().save();
/*  428: 484 */       UIUtil.refreshCurrentScreen();
/*  429:     */     }
/*  430: 487 */     return true;
/*  431:     */   }
/*  432:     */   
/*  433:     */   public boolean showpagenosave(UIEvent event)
/*  434:     */     throws MobileApplicationException
/*  435:     */   {
/*  436: 500 */     UIUtil.showPageNoSave((String)event.getValue(), (AbstractMobileControl)event.getCreatingObject());
/*  437: 501 */     return true;
/*  438:     */   }
/*  439:     */   
/*  440:     */   public boolean gotopagenosave(UIEvent event)
/*  441:     */     throws MobileApplicationException
/*  442:     */   {
/*  443: 513 */     UIUtil.gotoPageNoSave((String)event.getValue(), (AbstractMobileControl)event.getCreatingObject());
/*  444: 514 */     return true;
/*  445:     */   }
/*  446:     */   
/*  447:     */   public boolean popuppage(UIEvent event)
/*  448:     */     throws MobileApplicationException
/*  449:     */   {
/*  450: 525 */     UIUtil.popupPage((String)event.getValue(), event);
/*  451: 526 */     return true;
/*  452:     */   }
/*  453:     */   
/*  454:     */   public boolean startcenter(UIEvent event)
/*  455:     */     throws MobileApplicationException
/*  456:     */   {
/*  457: 537 */     BasicMobileDeviceUIApplication app = UIUtil.getApplication();
/*  458: 538 */     UIUtil.showPage(app.getStartupScreenId());
/*  459: 539 */     return true;
/*  460:     */   }
/*  461:     */   
/*  462:     */   public boolean closepage(UIEvent event)
/*  463:     */     throws MobileApplicationException
/*  464:     */   {
/*  465: 553 */     UIUtil.closePage();
/*  466: 554 */     return true;
/*  467:     */   }
/*  468:     */   
/*  469:     */   public boolean managedata(UIEvent event)
/*  470:     */     throws MobileApplicationException
/*  471:     */   {
/*  472: 565 */     event.setValue(event.getEventName());
/*  473: 566 */     return gotopage(event);
/*  474:     */   }
/*  475:     */   
/*  476:     */   public boolean preferences(UIEvent event)
/*  477:     */     throws MobileApplicationException
/*  478:     */   {
/*  479: 577 */     event.setValue(event.getEventName());
/*  480: 578 */     return gotopage(event);
/*  481:     */   }
/*  482:     */   
/*  483:     */   public boolean initpreferences(UIEvent event)
/*  484:     */     throws MobileApplicationException
/*  485:     */   {
/*  486: 589 */     MobileMboDataBean preferencesDataBean = ((PageControl)event.getCreatingObject()).getDataBean();
/*  487: 590 */     preferencesDataBean.setCurrentPosition(0);
/*  488:     */     
/*  489: 592 */     BasicMobileDeviceUIApplication app = UIUtil.getApplication();
/*  490:     */     
/*  491: 594 */     preferencesDataBean.setValue("DEFSITE", app.getDefaultInsertSite());
/*  492:     */     
/*  493:     */ 
/*  494: 597 */     preferencesDataBean.setValue("MOBFONTIMAGESIZE", MobileUIResources.getMode().toString());
/*  495: 598 */     preferencesDataBean.setValue("MOBFONTIMAGESIZE_OLD", MobileUIResources.getMode().toString());
/*  496:     */     
/*  497:     */ 
/*  498: 601 */     prepareDefSiteAttributes(preferencesDataBean.getMobileMbo());
/*  499:     */     
/*  500: 603 */     return true;
/*  501:     */   }
/*  502:     */   
/*  503:     */   public boolean savepreferences(UIEvent event)
/*  504:     */     throws MobileApplicationException
/*  505:     */   {
/*  506: 615 */     if (!UIUtil.getCurrentScreen().checkRequiredFields()) {
/*  507: 616 */       return true;
/*  508:     */     }
/*  509: 618 */     boolean fontChanged = false;
/*  510:     */     
/*  511: 620 */     MobileMboDataBean preferencesDataBean = UIUtil.getCurrentScreen().getDataBean();
/*  512:     */     
/*  513: 622 */     fontChanged = !preferencesDataBean.getValue("MOBFONTIMAGESIZE").equals(preferencesDataBean.getValue("MOBFONTIMAGESIZE_OLD"));
/*  514:     */     
/*  515: 624 */     BasicMobileDeviceUIApplication app = UIUtil.getApplication();
/*  516: 626 */     if ((event.getMsgResponse().equals("-1")) && (fontChanged))
/*  517:     */     {
/*  518: 627 */       UIUtil.showOKCANCELMessageBox(event, MobileMessageGenerator.generate("preferencesneedrestart", null));
/*  519: 628 */       event.setEventErrored();
/*  520:     */     }
/*  521: 629 */     else if ((event.getMsgResponse().equals("1")) || (!fontChanged))
/*  522:     */     {
/*  523: 631 */       if (fontChanged)
/*  524:     */       {
/*  525: 632 */         preferencesDataBean.setValue("MOBFONTIMAGESIZE_OLD", preferencesDataBean.getValue("MOBFONTIMAGESIZE"));
/*  526: 633 */         app.savePreferences(preferencesDataBean);
/*  527: 634 */         UIUtil.getApplication().setFontImageSizeResource(preferencesDataBean.getValue("MOBFONTIMAGESIZE"));
/*  528: 635 */         UIUtil.getApplication().getSystemInterface().exitSystem();
/*  529:     */       }
/*  530:     */       else
/*  531:     */       {
/*  532: 637 */         app.savePreferences(preferencesDataBean);
/*  533:     */         
/*  534:     */ 
/*  535:     */ 
/*  536:     */ 
/*  537:     */ 
/*  538: 643 */         UIUtil.closePage();
/*  539:     */       }
/*  540:     */     }
/*  541:     */     else
/*  542:     */     {
/*  543: 646 */       event.setEventErrored();
/*  544:     */     }
/*  545: 649 */     return true;
/*  546:     */   }
/*  547:     */   
/*  548:     */   public boolean uploadpending(UIEvent event)
/*  549:     */     throws MobileApplicationException
/*  550:     */   {
/*  551: 660 */     BasicMobileDeviceUIApplication app = UIUtil.getApplication();
/*  552: 661 */     int messageCount = app.getQueuedMessageCount();
/*  553: 662 */     if (messageCount == 0) {
/*  554: 663 */       return true;
/*  555:     */     }
/*  556: 666 */     ProgressObserver observer = event.getProgressObserver();
/*  557: 667 */     if (observer != null)
/*  558:     */     {
/*  559: 668 */       String msg = MobileMessageGenerator.generate("uploadpending", new Object[0]);
/*  560: 669 */       observer.setWorkProgressMessage(msg);
/*  561:     */     }
/*  562: 672 */     app.sendQueuedMessages();
/*  563:     */     
/*  564: 674 */     return true;
/*  565:     */   }
/*  566:     */   
/*  567:     */   public boolean haspendingcount(UIEvent event)
/*  568:     */     throws MobileApplicationException
/*  569:     */   {
/*  570: 685 */     BasicMobileDeviceUIApplication app = UIUtil.getApplication();
/*  571: 686 */     int messageCount = app.getQueuedMessageCount();
/*  572: 687 */     if (messageCount == 0)
/*  573:     */     {
/*  574: 688 */       AbstractMobileControl control = (AbstractMobileControl)event.getCreatingObject();
/*  575: 689 */       control.setVisibility(false);
/*  576:     */     }
/*  577:     */     else
/*  578:     */     {
/*  579: 691 */       AbstractMobileControl control = (AbstractMobileControl)event.getCreatingObject();
/*  580: 692 */       control.setVisibility(true);
/*  581:     */     }
/*  582: 695 */     return true;
/*  583:     */   }
/*  584:     */   
/*  585:     */   public boolean markalldone(UIEvent event)
/*  586:     */     throws MobileApplicationException
/*  587:     */   {
/*  588: 706 */     AbstractMobileControl control = (AbstractMobileControl)event.getCreatingObject();
/*  589: 707 */     MobileMboDataBean dataBean = control.getDataBean();
/*  590:     */     
/*  591: 709 */     int count = dataBean.getModifiedCount();
/*  592: 711 */     if (count > 0)
/*  593:     */     {
/*  594: 712 */       ProgressObserver observer = event.getProgressObserver();
/*  595: 713 */       if (observer != null)
/*  596:     */       {
/*  597: 714 */         String msg = MobileMessageGenerator.generate("markalldoneprogress", new Object[0]);
/*  598: 715 */         observer.setWorkProgressMessage(msg);
/*  599:     */       }
/*  600: 718 */       dataBean.doneAll();
/*  601:     */     }
/*  602: 721 */     return true;
/*  603:     */   }
/*  604:     */   
/*  605:     */   public boolean handleExecuteEvent(UIEvent event)
/*  606:     */     throws MobileApplicationException
/*  607:     */   {
/*  608: 733 */     return true;
/*  609:     */   }
/*  610:     */   
/*  611:     */   public boolean handleSignatureCapture(UIEvent event)
/*  612:     */     throws MobileApplicationException
/*  613:     */   {
/*  614: 743 */     PageControl page = (PageControl)UIUtil.getCurrentScreen();
/*  615: 744 */     AbstractMobileControl creator = (AbstractMobileControl)event.getCreatingObject();
/*  616: 745 */     String attribute = creator.getStringValue("value");
/*  617: 746 */     event.setValue("signature");
/*  618: 747 */     return gotopage(event);
/*  619:     */   }
/*  620:     */   
/*  621:     */   public boolean handleSaveSignature(UIEvent event)
/*  622:     */     throws MobileApplicationException
/*  623:     */   {
/*  624: 751 */     PageControl page = (PageControl)UIUtil.getCurrentScreen();
/*  625: 752 */     AbstractMobileControl creator = (AbstractMobileControl)event.getCreatingObject();
/*  626: 753 */     String attribute = creator.getStringValue("value");
/*  627: 754 */     event.setValue("signature");
/*  628: 755 */     return gotopage(event);
/*  629:     */   }
/*  630:     */   
/*  631:     */   public boolean saveQueries(UIEvent event)
/*  632:     */     throws MobileApplicationException
/*  633:     */   {
/*  634: 766 */     UIUtil.getCurrentScreen().getDataBean().getDataBeanManager().save();
/*  635: 767 */     UIUtil.closePage();
/*  636: 768 */     return true;
/*  637:     */   }
/*  638:     */   
/*  639:     */   public boolean refreshalldata(UIEvent event)
/*  640:     */     throws MobileApplicationException
/*  641:     */   {
/*  642: 779 */     UIUtil.getApplication().refreshAllMobileMbos(event.getProgressObserver());
/*  643: 780 */     DataBeanCache.removeAllDataBeans();
/*  644: 781 */     UIUtil.getApplication().initMobileOptions();
/*  645: 782 */     return true;
/*  646:     */   }
/*  647:     */   
/*  648:     */   public boolean refreshworkset(UIEvent event)
/*  649:     */     throws MobileApplicationException
/*  650:     */   {
/*  651: 795 */     MobileMboDataBean curDataBean = UIUtil.getCurrentScreen().getDataBean();
/*  652: 796 */     boolean isUserFiltered = false;
/*  653: 797 */     boolean isErrorFiltered = false;
/*  654: 798 */     MobileMboQBE curQBE = null;
/*  655: 799 */     if (curDataBean != null)
/*  656:     */     {
/*  657: 800 */       isUserFiltered = curDataBean.isFiltered();
/*  658: 801 */       isErrorFiltered = curDataBean.isSecondaryFilterOn();
/*  659: 802 */       if (isUserFiltered) {
/*  660: 803 */         curQBE = curDataBean.getQBE();
/*  661:     */       }
/*  662:     */     }
/*  663: 806 */     UIUtil.getApplication().refreshWorkList(event.getProgressObserver());
/*  664: 807 */     DataBeanCache.removeAllDataBeans();
/*  665: 808 */     curDataBean = UIUtil.getCurrentScreen().getDataBean();
/*  666: 809 */     if (curDataBean != null)
/*  667:     */     {
/*  668: 810 */       if (isErrorFiltered) {
/*  669: 811 */         curDataBean.setErrorFilter();
/*  670:     */       }
/*  671: 813 */       if (isUserFiltered)
/*  672:     */       {
/*  673: 814 */         Enumeration qbeEnum = curQBE.getQBEAttributes();
/*  674: 815 */         while (qbeEnum.hasMoreElements())
/*  675:     */         {
/*  676: 816 */           String QBEAttr = (String)qbeEnum.nextElement();
/*  677: 817 */           curDataBean.getQBE().setQBE(QBEAttr, curQBE.getQBE(QBEAttr));
/*  678:     */         }
/*  679: 819 */         curDataBean.setFiltered(isUserFiltered);
/*  680: 820 */         curDataBean.reset();
/*  681:     */       }
/*  682:     */     }
/*  683: 823 */     UIUtil.getApplication().initMobileOptions();
/*  684:     */     
/*  685: 825 */     return true;
/*  686:     */   }
/*  687:     */   
/*  688:     */   public boolean refreshrelatedset(UIEvent event)
/*  689:     */     throws MobileApplicationException
/*  690:     */   {
/*  691: 836 */     UIUtil.getApplication().refreshRelatedList(event.getProgressObserver());
/*  692: 837 */     DataBeanCache.removeAllDataBeans();
/*  693:     */     
/*  694: 839 */     return true;
/*  695:     */   }
/*  696:     */   
/*  697:     */   public boolean filter(UIEvent event)
/*  698:     */     throws MobileApplicationException
/*  699:     */   {
/*  700: 851 */     AbstractMobileControl ctrl = (AbstractMobileControl)event.getCreatingObject();
/*  701: 852 */     MobileMboDataBean dataBean = ctrl.getDataBean();
/*  702: 853 */     if (dataBean != null)
/*  703:     */     {
/*  704: 854 */       dataBean.reset();
/*  705: 855 */       dataBean.setFiltered(true);
/*  706: 856 */       dataBean.getMobileMbo(0);
/*  707:     */     }
/*  708: 858 */     return closepage(event);
/*  709:     */   }
/*  710:     */   
/*  711:     */   protected boolean clearFilterValues(UIEvent event)
/*  712:     */     throws MobileApplicationException
/*  713:     */   {
/*  714: 864 */     AbstractMobileControl ctrl = (AbstractMobileControl)event.getCreatingObject();
/*  715: 865 */     MobileMboDataBean dataBean = ctrl.getDataBean();
/*  716: 866 */     if (dataBean != null)
/*  717:     */     {
/*  718: 867 */       ((MobileMboDataBeanQBE)dataBean.getQBE()).restoreDefaultQBEValues(true);
/*  719: 868 */       dataBean.reset();
/*  720:     */     }
/*  721: 870 */     UIUtil.refreshCurrentScreen();
/*  722: 871 */     return true;
/*  723:     */   }
/*  724:     */   
/*  725:     */   public boolean clearfilter(UIEvent event)
/*  726:     */     throws MobileApplicationException
/*  727:     */   {
/*  728: 882 */     AbstractMobileControl ctrl = (AbstractMobileControl)event.getCreatingObject();
/*  729: 883 */     MobileMboDataBean dataBean = ctrl.getDataBean();
/*  730: 884 */     if (dataBean != null)
/*  731:     */     {
/*  732: 885 */       ((MobileMboDataBeanQBE)dataBean.getQBE()).restoreDefaultQBEValues();
/*  733: 886 */       dataBean.reset();
/*  734: 887 */       dataBean.setFiltered(false);
/*  735: 888 */       dataBean.setSecondaryFilter(false);
/*  736:     */     }
/*  737: 890 */     UIUtil.refreshCurrentScreen();
/*  738: 891 */     return true;
/*  739:     */   }
/*  740:     */   
/*  741:     */   public boolean cancelfilter(UIEvent event)
/*  742:     */     throws MobileApplicationException
/*  743:     */   {
/*  744: 902 */     AbstractMobileControl ctrl = (AbstractMobileControl)event.getCreatingObject();
/*  745: 903 */     MobileMboDataBean dataBean = ctrl.getDataBean();
/*  746: 904 */     if (dataBean != null)
/*  747:     */     {
/*  748: 905 */       ((MobileMboDataBeanQBE)dataBean.getQBE()).restoreSavedQBEValues();
/*  749: 906 */       dataBean.setSecondaryFilter(false);
/*  750:     */     }
/*  751: 908 */     return closepage(event);
/*  752:     */   }
/*  753:     */   
/*  754:     */   public boolean togglefilterbutton(UIEvent event)
/*  755:     */     throws MobileApplicationException
/*  756:     */   {
/*  757: 912 */     StateControl state = (StateControl)event.getCreatingObject();
/*  758: 913 */     MobileMboDataBean dataBean = state.getDataBean();
/*  759: 914 */     if ((dataBean != null) && (dataBean.isFiltered())) {
/*  760: 915 */       state.setStateViaState("filtered");
/*  761:     */     } else {
/*  762: 917 */       state.setStateViaState("notfiltered");
/*  763:     */     }
/*  764: 918 */     return true;
/*  765:     */   }
/*  766:     */   
/*  767:     */   public boolean save(UIEvent event)
/*  768:     */     throws MobileApplicationException
/*  769:     */   {
/*  770: 922 */     PageControl page = (PageControl)UIUtil.getCurrentScreen();
/*  771: 924 */     if ((page.savePage(event)) && (
/*  772: 925 */       (event.getValue() == null) || (!event.getValue().equals("norefresh")))) {
/*  773: 926 */       UIUtil.refreshCurrentScreen();
/*  774:     */     }
/*  775: 928 */     return true;
/*  776:     */   }
/*  777:     */   
/*  778:     */   public boolean saveclose(UIEvent event)
/*  779:     */     throws MobileApplicationException
/*  780:     */   {
/*  781: 932 */     UIUtil.getApplication().removeCurrentScreen(true);
/*  782: 933 */     return true;
/*  783:     */   }
/*  784:     */   
/*  785:     */   public boolean cancelpage(UIEvent event)
/*  786:     */     throws MobileApplicationException
/*  787:     */   {
/*  788: 937 */     UIUtil.cancelPage();
/*  789: 938 */     return true;
/*  790:     */   }
/*  791:     */   
/*  792:     */   public boolean cancelshowpage(UIEvent event)
/*  793:     */     throws MobileApplicationException
/*  794:     */   {
/*  795: 942 */     UIUtil.cancelShowPage((String)event.getValue());
/*  796: 943 */     return true;
/*  797:     */   }
/*  798:     */   
/*  799:     */   public boolean haserror(UIEvent event)
/*  800:     */     throws MobileApplicationException
/*  801:     */   {
/*  802: 947 */     if ((event.getCreatingObject() instanceof AbstractMobileControl))
/*  803:     */     {
/*  804: 948 */       MobileMboDataBean dataBean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*  805: 949 */       if (dataBean != null) {
/*  806: 950 */         ((AbstractMobileControl)event.getCreatingObject()).setVisibility(!UIUtil.isNull(dataBean.getErrorMessage()));
/*  807:     */       }
/*  808:     */     }
/*  809: 954 */     return true;
/*  810:     */   }
/*  811:     */   
/*  812:     */   public boolean isnew(UIEvent event)
/*  813:     */     throws MobileApplicationException
/*  814:     */   {
/*  815: 958 */     if ((event.getCreatingObject() instanceof AbstractMobileControl))
/*  816:     */     {
/*  817: 959 */       MobileMboDataBean dataBean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*  818: 961 */       if ((dataBean != null) && (dataBean.getMobileMbo() != null)) {
/*  819: 962 */         ((AbstractMobileControl)event.getCreatingObject()).setVisibility(dataBean.getMobileMbo().isNew());
/*  820:     */       }
/*  821:     */     }
/*  822: 966 */     return true;
/*  823:     */   }
/*  824:     */   
/*  825:     */   public boolean ismodified(UIEvent event)
/*  826:     */     throws MobileApplicationException
/*  827:     */   {
/*  828: 970 */     if ((event.getCreatingObject() instanceof AbstractMobileControl))
/*  829:     */     {
/*  830: 971 */       MobileMboDataBean dataBean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*  831: 973 */       if ((dataBean != null) && (dataBean.getMobileMbo() != null)) {
/*  832: 974 */         ((AbstractMobileControl)event.getCreatingObject()).setVisibility(dataBean.getMobileMbo().isModified());
/*  833:     */       }
/*  834:     */     }
/*  835: 978 */     return true;
/*  836:     */   }
/*  837:     */   
/*  838:     */   public boolean ismodifiedandnotnew(UIEvent event)
/*  839:     */     throws MobileApplicationException
/*  840:     */   {
/*  841: 982 */     if ((event.getCreatingObject() instanceof AbstractMobileControl))
/*  842:     */     {
/*  843: 983 */       MobileMboDataBean dataBean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*  844: 985 */       if ((dataBean != null) && (dataBean.getMobileMbo() != null))
/*  845:     */       {
/*  846: 986 */         boolean visible = false;
/*  847:     */         
/*  848: 988 */         MobileMbo mobileMbo = dataBean.getMobileMbo();
/*  849: 989 */         if ((mobileMbo.isModified()) && (!mobileMbo.isNew())) {
/*  850: 990 */           visible = true;
/*  851:     */         }
/*  852: 993 */         ((AbstractMobileControl)event.getCreatingObject()).setVisibility(visible);
/*  853:     */       }
/*  854:     */     }
/*  855: 997 */     return true;
/*  856:     */   }
/*  857:     */   
/*  858:     */   public boolean undochanges(UIEvent event)
/*  859:     */     throws MobileApplicationException
/*  860:     */   {
/*  861:1001 */     if (event.getMsgResponse().equals("-1"))
/*  862:     */     {
/*  863:1002 */       UIUtil.showOKCANCELMessageBox(event, MobileMessageGenerator.generate("undochanges", null));
/*  864:1003 */       return true;
/*  865:     */     }
/*  866:1004 */     if (event.getMsgResponse().equals("1"))
/*  867:     */     {
/*  868:1005 */       MobileMboDataBean dataBean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*  869:1006 */       if ((dataBean != null) && 
/*  870:1007 */         ((event.getCreatingObject() instanceof AbstractMobileControl)))
/*  871:     */       {
/*  872:1008 */         dataBean.undoChanges();
/*  873:1009 */         UIUtil.refreshCurrentScreen();
/*  874:     */       }
/*  875:     */     }
/*  876:1013 */     return true;
/*  877:     */   }
/*  878:     */   
/*  879:     */   public boolean deletenew(UIEvent event)
/*  880:     */     throws MobileApplicationException
/*  881:     */   {
/*  882:1017 */     if (event.getMsgResponse().equals("-1"))
/*  883:     */     {
/*  884:1018 */       MobileMboDataBean dataBean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*  885:1019 */       String desc = dataBean.getMobileMboInfo().getDescription();
/*  886:     */       
/*  887:1021 */       UIUtil.showOKCANCELMessageBox(event, MobileMessageGenerator.generate("deletenew", new Object[] { desc }));
/*  888:1022 */       return true;
/*  889:     */     }
/*  890:1023 */     if (event.getMsgResponse().equals("1"))
/*  891:     */     {
/*  892:1024 */       MobileMboDataBean dataBean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*  893:1025 */       if ((dataBean != null) && 
/*  894:1026 */         ((event.getCreatingObject() instanceof AbstractMobileControl)))
/*  895:     */       {
/*  896:1027 */         dataBean.delete();
/*  897:1028 */         dataBean.getDataBeanManager().save();
/*  898:1029 */         dataBean.reset();
/*  899:1030 */         UIUtil.refreshCurrentScreen();
/*  900:     */       }
/*  901:     */     }
/*  902:1034 */     return true;
/*  903:     */   }
/*  904:     */   
/*  905:     */   public boolean savesessionandexitapp(UIEvent event)
/*  906:     */     throws MobileApplicationException
/*  907:     */   {
/*  908:1038 */     BasicMobileDeviceUIApplication app = UIUtil.getApplication();
/*  909:1039 */     ProgressObserver observer = event.getProgressObserver();
/*  910:1040 */     app.storeSnapshot(app.getCurrentUser(), app.getCurrentUser(), observer);
/*  911:1041 */     app.releaseApplication();
/*  912:1042 */     app.getSystemInterface().exitSystem();
/*  913:1043 */     return true;
/*  914:     */   }
/*  915:     */   
/*  916:     */   public boolean exitapp(UIEvent event)
/*  917:     */     throws MobileApplicationException
/*  918:     */   {
/*  919:1047 */     BasicMobileDeviceUIApplication app = UIUtil.getApplication();
/*  920:1048 */     app.releaseApplication();
/*  921:1049 */     app.getSystemInterface().exitSystem();
/*  922:1050 */     return true;
/*  923:     */   }
/*  924:     */   
/*  925:     */   public boolean cancelexitapp(UIEvent event)
/*  926:     */     throws MobileApplicationException
/*  927:     */   {
/*  928:1056 */     return true;
/*  929:     */   }
/*  930:     */   
/*  931:     */   public boolean exit(UIEvent event)
/*  932:     */     throws MobileApplicationException
/*  933:     */   {
/*  934:1060 */     BasicMobileDeviceUIApplication app = UIUtil.getApplication();
/*  935:1061 */     if (app.isSnapshotEnabled())
/*  936:     */     {
/*  937:1062 */       String msg = MobileMessageGenerator.generate("savesessionexitapp", new Object[0]);
/*  938:1063 */       UIUtil.showMessageBoxControl("exitmessagepagebox", msg, event);
/*  939:     */       
/*  940:1065 */       event.setEventErrored();
/*  941:     */     }
/*  942:     */     else
/*  943:     */     {
/*  944:1067 */       if (event.getMsgResponse().equals("-1"))
/*  945:     */       {
/*  946:1068 */         UIUtil.showOKCANCELMessageBox(event, MobileMessageGenerator.generate("exitapp", null));
/*  947:1069 */         event.setEventErrored();
/*  948:1070 */         return true;
/*  949:     */       }
/*  950:1071 */       if (event.getMsgResponse().equals("1"))
/*  951:     */       {
/*  952:1072 */         app.releaseApplication();
/*  953:1073 */         app.getSystemInterface().exitSystem();
/*  954:     */       }
/*  955:     */     }
/*  956:1077 */     return true;
/*  957:     */   }
/*  958:     */   
/*  959:     */   public boolean exitnoprompt(UIEvent event)
/*  960:     */     throws MobileApplicationException
/*  961:     */   {
/*  962:1081 */     BasicMobileDeviceUIApplication app = UIUtil.getApplication();
/*  963:1082 */     app.releaseApplication();
/*  964:1083 */     app.getSystemInterface().exitSystem();
/*  965:     */     
/*  966:1085 */     return true;
/*  967:     */   }
/*  968:     */   
/*  969:     */   public boolean submit(UIEvent event)
/*  970:     */     throws MobileApplicationException
/*  971:     */   {
/*  972:1089 */     if ((event.getCreatingObject() instanceof AbstractMobileControl)) {
/*  973:1090 */       new AsyncMobileDataBeanDone().handleInBackground(event);
/*  974:     */     }
/*  975:1092 */     return true;
/*  976:     */   }
/*  977:     */   
/*  978:     */   public boolean sendback(UIEvent event)
/*  979:     */     throws MobileApplicationException
/*  980:     */   {
/*  981:1096 */     if ((event.getCreatingObject() instanceof AbstractMobileControl)) {
/*  982:1097 */       new AsyncMobileDataBeanGiveup().handleInBackground(event);
/*  983:     */     }
/*  984:1099 */     return true;
/*  985:     */   }
/*  986:     */   
/*  987:     */   public boolean viewerror(UIEvent event)
/*  988:     */     throws MobileApplicationException
/*  989:     */   {
/*  990:1103 */     if ((event.getCreatingObject() instanceof AbstractMobileControl))
/*  991:     */     {
/*  992:1104 */       MobileMboDataBean dataBean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*  993:1105 */       if (dataBean != null) {
/*  994:1106 */         UIUtil.showInfoMessageBox(dataBean.getErrorMessage());
/*  995:     */       }
/*  996:     */     }
/*  997:1110 */     return true;
/*  998:     */   }
/*  999:     */   
/* 1000:     */   public boolean barcoderead(UIEvent event)
/* 1001:     */     throws MobileApplicationException
/* 1002:     */   {
/* 1003:1114 */     return true;
/* 1004:     */   }
/* 1005:     */   
/* 1006:     */   public boolean cancelesig(UIEvent event)
/* 1007:     */     throws MobileApplicationException
/* 1008:     */   {
/* 1009:1118 */     MobileDeviceAppSession session = MobileDeviceAppSession.getSession();
/* 1010:1119 */     session.removeAttribute("esig_event");
/* 1011:1120 */     UIUtil.closePage();
/* 1012:1121 */     return true;
/* 1013:     */   }
/* 1014:     */   
/* 1015:     */   public boolean verifyesig(UIEvent event)
/* 1016:     */     throws MobileApplicationException
/* 1017:     */   {
/* 1018:1125 */     PageControl page = (PageControl)((AbstractMobileControl)event.getCreatingObject()).getPage();
/* 1019:1126 */     InputControl uCtrl = (InputControl)page.findChild("unametxt");
/* 1020:1127 */     InputControl pCtrl = (InputControl)page.findChild("pwd");
/* 1021:1128 */     ReasonForChangeControl rCtrl = (ReasonForChangeControl)page.findChild("rc1");
/* 1022:1129 */     String userName = uCtrl.getControlValue();
/* 1023:1130 */     String password = pCtrl.getControlValue();
/* 1024:1131 */     String rc = rCtrl.getControlValue();
/* 1025:1132 */     uCtrl.requiredcheck(event);
/* 1026:1133 */     pCtrl.requiredcheck(event);
/* 1027:1134 */     rCtrl.requiredcheck(event);
/* 1028:1135 */     AbstractMobileControl lCtrl = ((PageControl)UIUtil.getCurrentScreen()).getLaunchingControl();
/* 1029:1136 */     MobileMboDataBean bean = null;
/* 1030:1137 */     if (lCtrl != null)
/* 1031:     */     {
/* 1032:1138 */       AbstractMobileControl prevPage = lCtrl.getPage();
/* 1033:1139 */       String esigDataSrc = prevPage.getStringValue("esigdatasrc");
/* 1034:1140 */       if (esigDataSrc != null) {
/* 1035:1141 */         bean = DataBeanCache.findDataBean(esigDataSrc);
/* 1036:     */       }
/* 1037:1143 */       if (bean == null) {
/* 1038:1144 */         bean = lCtrl.getDataBean();
/* 1039:     */       }
/* 1040:     */     }
/* 1041:1146 */     if (bean == null) {
/* 1042:1147 */       bean = page.getDataBean();
/* 1043:     */     }
/* 1044:1148 */     while ((bean != null) && (bean.getParentBean() != null)) {
/* 1045:1149 */       bean = bean.getParentBean();
/* 1046:     */     }
/* 1047:1153 */     if (bean != null)
/* 1048:     */     {
/* 1049:1154 */       new AsyncMobileESigVerification(bean, userName, password, rc).handleInBackground(event);
/* 1050:     */     }
/* 1051:     */     else
/* 1052:     */     {
/* 1053:1156 */       UIUtil.showFailureMessageBox(MobileMessageGenerator.generate("alertInvalidESig", null));
/* 1054:1157 */       event.setEventErrored();
/* 1055:     */     }
/* 1056:1160 */     return true;
/* 1057:     */   }
/* 1058:     */   
/* 1059:     */   public boolean performEvent(UIEvent event)
/* 1060:     */     throws MobileApplicationException
/* 1061:     */   {
/* 1062:1164 */     if (event != null)
/* 1063:     */     {
/* 1064:1165 */       String eventId = getEventId(event);
/* 1065:1166 */       if (eventId.equalsIgnoreCase("showpage")) {
/* 1066:1167 */         return showpage(event);
/* 1067:     */       }
/* 1068:1168 */       if (eventId.equals("save")) {
/* 1069:1169 */         return save(event);
/* 1070:     */       }
/* 1071:1170 */       if (eventId.equals("saveclose")) {
/* 1072:1171 */         return saveclose(event);
/* 1073:     */       }
/* 1074:1172 */       if (eventId.equals("cancelpage")) {
/* 1075:1173 */         return cancelpage(event);
/* 1076:     */       }
/* 1077:1174 */       if (eventId.equals("cancelshowpage")) {
/* 1078:1175 */         return cancelshowpage(event);
/* 1079:     */       }
/* 1080:1176 */       if (eventId.equals("barcoderead")) {
/* 1081:1177 */         return barcoderead(event);
/* 1082:     */       }
/* 1083:1178 */       if (eventId.equals("gotopagenosave")) {
/* 1084:1179 */         return gotopagenosave(event);
/* 1085:     */       }
/* 1086:1180 */       if (eventId.equals("showpagenosave")) {
/* 1087:1181 */         return showpagenosave(event);
/* 1088:     */       }
/* 1089:1182 */       if (eventId.equals("verifyesig")) {
/* 1090:1183 */         return verifyesig(event);
/* 1091:     */       }
/* 1092:1184 */       if (eventId.equals("cancelesig")) {
/* 1093:1185 */         return cancelesig(event);
/* 1094:     */       }
/* 1095:1186 */       if (eventId.equals("check4errors")) {
/* 1096:1187 */         return check4errors(event);
/* 1097:     */       }
/* 1098:1188 */       if (eventId.equals("check4anyerrors")) {
/* 1099:1189 */         return check4anyerrors(event);
/* 1100:     */       }
/* 1101:1190 */       if (eventId.equals("gotoerrorpage")) {
/* 1102:1191 */         return gotoerrorpage(event);
/* 1103:     */       }
/* 1104:1192 */       if (eventId.equals("displayadhocdownload")) {
/* 1105:1193 */         return displayadhocdownload(event);
/* 1106:     */       }
/* 1107:1194 */       if (eventId.equals("docextract")) {
/* 1108:1195 */         return docextract(event);
/* 1109:     */       }
/* 1110:1196 */       if (eventId.equals("displaydocextract")) {
/* 1111:1197 */         return displaydocextract(event);
/* 1112:     */       }
/* 1113:1198 */       if (eventId.equals("docdelete")) {
/* 1114:1199 */         return docdelete(event);
/* 1115:     */       }
/* 1116:1200 */       if (eventId.equals("displaydocdelete")) {
/* 1117:1201 */         return displaydocdelete(event);
/* 1118:     */       }
/* 1119:1202 */       if (eventId.equals("docextractall")) {
/* 1120:1203 */         return docextractall(event);
/* 1121:     */       }
/* 1122:1206 */       if (eventId.equals("toggledocextractdeletebutton")) {
/* 1123:1207 */         return toggleDocExtractDeleteButton(event);
/* 1124:     */       }
/* 1125:1208 */       if (eventId.equals("displayextractall")) {
/* 1126:1209 */         return displaydocextractall(event);
/* 1127:     */       }
/* 1128:1210 */       if (eventId.equals("adhocdownload"))
/* 1129:     */       {
/* 1130:1211 */         switch (event.getThreadStatus())
/* 1131:     */         {
/* 1132:     */         case -1: 
/* 1133:1213 */           UIUtil.startWorkerThread(this, event);
/* 1134:1214 */           break;
/* 1135:     */         case 1: 
/* 1136:1216 */           return adhocdownload(event);
/* 1137:     */         case 2: 
/* 1138:1218 */           UIUtil.refreshCurrentScreen();
/* 1139:1219 */           UIEvent event1 = triggerLookupSelectEvent(event);
/* 1140:1220 */           UIUtil.getCurrentScreen().handleEvent(event1);
/* 1141:1221 */           break;
/* 1142:     */         case 0: 
/* 1143:1223 */           UIUtil.refreshCurrentScreen();
/* 1144:1224 */           break;
/* 1145:     */         case 3: 
/* 1146:1226 */           UIUtil.refreshCurrentScreen();
/* 1147:1227 */           UIUtil.showExceptionMessage(event.getException(), null, 0);
/* 1148:     */         }
/* 1149:1230 */         return true;
/* 1150:     */       }
/* 1151:1231 */       if (eventId.equals("adhocdownloadprompt"))
/* 1152:     */       {
/* 1153:1232 */         if (event.getMsgResponse().equals("-1"))
/* 1154:     */         {
/* 1155:1233 */           UIUtil.showOKCANCELMessageBox(event, MobileMessageGenerator.generate("adhocdownload", null));
/* 1156:1234 */           return true;
/* 1157:     */         }
/* 1158:1235 */         if (event.getMsgResponse().equals("1"))
/* 1159:     */         {
/* 1160:1236 */           switch (event.getThreadStatus())
/* 1161:     */           {
/* 1162:     */           case -1: 
/* 1163:1238 */             UIUtil.startWorkerThread(this, event);
/* 1164:1239 */             break;
/* 1165:     */           case 1: 
/* 1166:1241 */             return adhocdownload(event);
/* 1167:     */           case 2: 
/* 1168:1243 */             UIUtil.refreshCurrentScreen();
/* 1169:     */             
/* 1170:     */ 
/* 1171:1246 */             UIEvent event1 = triggerLookupSelectEvent(event);
/* 1172:1247 */             UIUtil.getCurrentScreen().handleEvent(event1);
/* 1173:1248 */             break;
/* 1174:     */           case 0: 
/* 1175:1250 */             UIUtil.refreshCurrentScreen();
/* 1176:1251 */             break;
/* 1177:     */           case 3: 
/* 1178:1253 */             UIUtil.refreshCurrentScreen();
/* 1179:1254 */             UIUtil.showExceptionMessage(event.getException(), null, 0);
/* 1180:     */           }
/* 1181:1257 */           return true;
/* 1182:     */         }
/* 1183:     */       }
/* 1184:     */       else
/* 1185:     */       {
/* 1186:1259 */         if (eventId.equalsIgnoreCase("gotopage")) {
/* 1187:1260 */           return gotopage(event);
/* 1188:     */         }
/* 1189:1261 */         if (eventId.equalsIgnoreCase("popuppage")) {
/* 1190:1262 */           return popuppage(event);
/* 1191:     */         }
/* 1192:1263 */         if (eventId.equalsIgnoreCase("startcenter")) {
/* 1193:1264 */           return startcenter(event);
/* 1194:     */         }
/* 1195:1265 */         if (eventId.equalsIgnoreCase("closepage")) {
/* 1196:1266 */           return closepage(event);
/* 1197:     */         }
/* 1198:1267 */         if (eventId.equalsIgnoreCase("execute")) {
/* 1199:1268 */           return handleExecuteEvent(event);
/* 1200:     */         }
/* 1201:1269 */         if (eventId.equalsIgnoreCase("showsignature")) {
/* 1202:1270 */           return handleSignatureCapture(event);
/* 1203:     */         }
/* 1204:1271 */         if (eventId.equalsIgnoreCase("savesignature")) {
/* 1205:1272 */           return handleSaveSignature(event);
/* 1206:     */         }
/* 1207:1273 */         if (eventId.equalsIgnoreCase("filter")) {
/* 1208:1274 */           return filter(event);
/* 1209:     */         }
/* 1210:1275 */         if (eventId.equalsIgnoreCase("cancelfilter")) {
/* 1211:1276 */           return cancelfilter(event);
/* 1212:     */         }
/* 1213:1277 */         if (eventId.equalsIgnoreCase("clearfilter")) {
/* 1214:1278 */           return clearfilter(event);
/* 1215:     */         }
/* 1216:1279 */         if (eventId.equalsIgnoreCase("togglefilterbutton")) {
/* 1217:1280 */           return togglefilterbutton(event);
/* 1218:     */         }
/* 1219:1281 */         if (eventId.equalsIgnoreCase("managedata")) {
/* 1220:1282 */           return managedata(event);
/* 1221:     */         }
/* 1222:1283 */         if (eventId.equalsIgnoreCase("preferences")) {
/* 1223:1284 */           return preferences(event);
/* 1224:     */         }
/* 1225:1285 */         if (eventId.equalsIgnoreCase("initpreferencespage")) {
/* 1226:1286 */           return initpreferences(event);
/* 1227:     */         }
/* 1228:1287 */         if (eventId.equalsIgnoreCase("savepreferences")) {
/* 1229:1288 */           return savepreferences(event);
/* 1230:     */         }
/* 1231:1289 */         if (eventId.equalsIgnoreCase("savequeries")) {
/* 1232:1290 */           return saveQueries(event);
/* 1233:     */         }
/* 1234:1291 */         if (eventId.equals("viewerror")) {
/* 1235:1292 */           return viewerror(event);
/* 1236:     */         }
/* 1237:1293 */         if (eventId.equals("haserror")) {
/* 1238:1294 */           return haserror(event);
/* 1239:     */         }
/* 1240:1295 */         if (eventId.equals("isnew")) {
/* 1241:1296 */           return isnew(event);
/* 1242:     */         }
/* 1243:1297 */         if (eventId.equals("submit")) {
/* 1244:1298 */           return submit(event);
/* 1245:     */         }
/* 1246:1299 */         if (eventId.equals("sendback")) {
/* 1247:1300 */           return sendback(event);
/* 1248:     */         }
/* 1249:1301 */         if (eventId.equals("deletenew")) {
/* 1250:1302 */           return deletenew(event);
/* 1251:     */         }
/* 1252:1303 */         if (eventId.equals("ismodified")) {
/* 1253:1304 */           return ismodified(event);
/* 1254:     */         }
/* 1255:1305 */         if (eventId.equals("ismodifiedandnotnew")) {
/* 1256:1306 */           return ismodifiedandnotnew(event);
/* 1257:     */         }
/* 1258:1307 */         if (eventId.equals("undochanges")) {
/* 1259:1308 */           return undochanges(event);
/* 1260:     */         }
/* 1261:1309 */         if (eventId.equals("exit")) {
/* 1262:1310 */           return exit(event);
/* 1263:     */         }
/* 1264:1311 */         if (eventId.equals("savesessionandexitapp"))
/* 1265:     */         {
/* 1266:1312 */           switch (event.getThreadStatus())
/* 1267:     */           {
/* 1268:     */           case -1: 
/* 1269:1314 */             UIUtil.startWorkerThread(this, event);
/* 1270:1315 */             break;
/* 1271:     */           case 1: 
/* 1272:1317 */             return savesessionandexitapp(event);
/* 1273:     */           case 2: 
/* 1274:     */             break;
/* 1275:     */           case 0: 
/* 1276:     */             break;
/* 1277:     */           case 3: 
/* 1278:1323 */             String msg = MobileMessageGenerator.generate("failedtostoresnapshot", new Object[0]);
/* 1279:1324 */             Exception ex1 = event.getException();
/* 1280:1325 */             if ((ex1 instanceof MobileApplicationException))
/* 1281:     */             {
/* 1282:1326 */               MobileApplicationException ex = (MobileApplicationException)ex1;
/* 1283:1327 */               if ((ex.getNestedException() instanceof MobileApplicationException))
/* 1284:     */               {
/* 1285:1328 */                 MobileApplicationException appex = (MobileApplicationException)ex.getNestedException();
/* 1286:1329 */                 msg = msg + " - " + appex.getCompleteMessage();
/* 1287:     */               }
/* 1288:     */             }
/* 1289:1332 */             UIUtil.showMessageBoxControl("storesnapshotfailbox", msg, event);
/* 1290:     */           }
/* 1291:1335 */           return true;
/* 1292:     */         }
/* 1293:1336 */         if (eventId.equals("exitapp")) {
/* 1294:1337 */           return exitapp(event);
/* 1295:     */         }
/* 1296:1338 */         if (eventId.equals("cancelexitapp")) {
/* 1297:1339 */           return cancelexitapp(event);
/* 1298:     */         }
/* 1299:1340 */         if (eventId.equals("exitnoprompt")) {
/* 1300:1341 */           return exitnoprompt(event);
/* 1301:     */         }
/* 1302:1342 */         if (eventId.equals("resetapp")) {
/* 1303:1343 */           return resetapp(event);
/* 1304:     */         }
/* 1305:1344 */         if (eventId.equals("resetappondbissues")) {
/* 1306:1345 */           return resetappondbissues(event);
/* 1307:     */         }
/* 1308:1346 */         if (eventId.equals("trackerrors")) {
/* 1309:1347 */           return trackerrors(event);
/* 1310:     */         }
/* 1311:1348 */         if (eventId.equals("showerrorlist")) {
/* 1312:1349 */           return showerrorlist(event);
/* 1313:     */         }
/* 1314:1350 */         if (eventId.equals("reseterrorlist")) {
/* 1315:1351 */           return reseterrorlist(event);
/* 1316:     */         }
/* 1317:1352 */         if (eventId.equals("setusername")) {
/* 1318:1353 */           return setusername(event);
/* 1319:     */         }
/* 1320:1354 */         if (eventId.equalsIgnoreCase("refreshrelatedset"))
/* 1321:     */         {
/* 1322:1355 */           if (event.getMsgResponse().equals("-1"))
/* 1323:     */           {
/* 1324:1356 */             UIUtil.showOKCANCELMessageBox(event, MobileMessageGenerator.generate("dourefreshreldata", null));
/* 1325:1357 */             return true;
/* 1326:     */           }
/* 1327:1358 */           if (event.getMsgResponse().equals("1"))
/* 1328:     */           {
/* 1329:1359 */             switch (event.getThreadStatus())
/* 1330:     */             {
/* 1331:     */             case -1: 
/* 1332:1361 */               UIUtil.startWorkerThread(this, event);
/* 1333:1362 */               break;
/* 1334:     */             case 1: 
/* 1335:1364 */               return refreshrelatedset(event);
/* 1336:     */             case 2: 
/* 1337:1366 */               UIUtil.refreshCurrentScreen();
/* 1338:1367 */               break;
/* 1339:     */             case 0: 
/* 1340:1369 */               UIUtil.refreshCurrentScreen();
/* 1341:1370 */               break;
/* 1342:     */             case 3: 
/* 1343:1372 */               UIUtil.showExceptionMessage(event.getException(), null, 0);
/* 1344:1373 */               UIUtil.refreshCurrentScreen();
/* 1345:     */             }
/* 1346:1376 */             return true;
/* 1347:     */           }
/* 1348:     */         }
/* 1349:1378 */         else if (eventId.equalsIgnoreCase("refreshworkset"))
/* 1350:     */         {
/* 1351:1380 */           if ((!this.updateRefreshChecking) && (event.getMsgResponse().equals("-1")))
/* 1352:     */           {
/* 1353:1381 */             UIUtil.showOKCANCELMessageBox(event, MobileMessageGenerator.generate("dourefreshworksetdata", null));
/* 1354:1382 */             return true;
/* 1355:     */           }
/* 1356:1383 */           if ((this.updateRefreshChecking) || (event.getMsgResponse().equals("1")))
/* 1357:     */           {
/* 1358:1385 */             switch (event.getThreadStatus())
/* 1359:     */             {
/* 1360:     */             case -1: 
/* 1361:1388 */               if (checkForUpdateInRefresh(event) == true)
/* 1362:     */               {
/* 1363:1389 */                 this.updateRefreshChecking = true;
/* 1364:1390 */                 return true;
/* 1365:     */               }
/* 1366:1393 */               UIUtil.startWorkerThread(this, event);
/* 1367:1394 */               break;
/* 1368:     */             case 1: 
/* 1369:1396 */               return refreshworkset(event);
/* 1370:     */             case 2: 
/* 1371:1398 */               this.updateRefreshChecking = false;
/* 1372:1399 */               UIUtil.refreshCurrentScreen();
/* 1373:1400 */               break;
/* 1374:     */             case 0: 
/* 1375:1402 */               this.updateRefreshChecking = false;
/* 1376:1403 */               UIUtil.refreshCurrentScreen();
/* 1377:1404 */               break;
/* 1378:     */             case 3: 
/* 1379:1406 */               this.updateRefreshChecking = false;
/* 1380:1407 */               UIUtil.refreshCurrentScreen();
/* 1381:1408 */               UIUtil.showExceptionMessage(event.getException(), null, 0);
/* 1382:     */             }
/* 1383:1411 */             return true;
/* 1384:     */           }
/* 1385:     */         }
/* 1386:     */         else
/* 1387:     */         {
/* 1388:1413 */           if (eventId.equalsIgnoreCase("refreshworksetnoprompt"))
/* 1389:     */           {
/* 1390:1414 */             switch (event.getThreadStatus())
/* 1391:     */             {
/* 1392:     */             case -1: 
/* 1393:1416 */               UIUtil.startWorkerThread(this, event);
/* 1394:1417 */               break;
/* 1395:     */             case 1: 
/* 1396:1419 */               return refreshworkset(event);
/* 1397:     */             case 2: 
/* 1398:1421 */               UIUtil.refreshCurrentScreen();
/* 1399:1422 */               break;
/* 1400:     */             case 0: 
/* 1401:1424 */               UIUtil.refreshCurrentScreen();
/* 1402:1425 */               break;
/* 1403:     */             case 3: 
/* 1404:1427 */               UIUtil.refreshCurrentScreen();
/* 1405:     */             }
/* 1406:1432 */             return true;
/* 1407:     */           }
/* 1408:1433 */           if (eventId.equalsIgnoreCase("refreshalldata"))
/* 1409:     */           {
/* 1410:1435 */             if ((!this.updateRefreshChecking) && (event.getMsgResponse().equals("-1")))
/* 1411:     */             {
/* 1412:1436 */               UIUtil.showOKCANCELMessageBox(event, MobileMessageGenerator.generate("dourefreshalldata", null));
/* 1413:1437 */               return true;
/* 1414:     */             }
/* 1415:1438 */             if ((this.updateRefreshChecking) || (event.getMsgResponse().equals("1")))
/* 1416:     */             {
/* 1417:1440 */               BasicMobileDeviceUIApplication app = UIUtil.getApplication();
/* 1418:1441 */               if (this.resetAdHocDataPrompted)
/* 1419:     */               {
/* 1420:1442 */                 switch (event.getThreadStatus())
/* 1421:     */                 {
/* 1422:     */                 case -1: 
/* 1423:1445 */                   if (checkForUpdateInRefresh(event) == true)
/* 1424:     */                   {
/* 1425:1446 */                     this.updateRefreshChecking = true;
/* 1426:1447 */                     return true;
/* 1427:     */                   }
/* 1428:1450 */                   UIUtil.startWorkerThread(this, event);
/* 1429:1451 */                   break;
/* 1430:     */                 case 1: 
/* 1431:1453 */                   app.removeAllAdHocMobileMbos(false);
/* 1432:1454 */                   return refreshalldata(event);
/* 1433:     */                 case 2: 
/* 1434:1456 */                   this.resetAdHocDataPrompted = false;
/* 1435:1457 */                   this.updateRefreshChecking = false;
/* 1436:1458 */                   UIUtil.refreshCurrentScreen();
/* 1437:1459 */                   break;
/* 1438:     */                 case 0: 
/* 1439:1461 */                   this.resetAdHocDataPrompted = false;
/* 1440:1462 */                   this.updateRefreshChecking = false;
/* 1441:1463 */                   UIUtil.refreshCurrentScreen();
/* 1442:1464 */                   break;
/* 1443:     */                 case 3: 
/* 1444:1466 */                   this.resetAdHocDataPrompted = false;
/* 1445:1467 */                   this.updateRefreshChecking = false;
/* 1446:1468 */                   app.removeAllAdHocMobileMbos(false);
/* 1447:1469 */                   UIUtil.refreshCurrentScreen();
/* 1448:1470 */                   UIUtil.showExceptionMessage(event.getException(), null, 0);
/* 1449:     */                 }
/* 1450:1473 */                 return true;
/* 1451:     */               }
/* 1452:1475 */               if ((!this.updateRefreshChecking) && (app.isAdHocDataPresent()) && (event.getThreadStatus() == -1))
/* 1453:     */               {
/* 1454:1476 */                 UIUtil.showMessageBox("resetadhocdata", new Object[0], "question", 12, event);
/* 1455:1477 */                 this.resetAdHocDataPrompted = true;
/* 1456:1478 */                 return true;
/* 1457:     */               }
/* 1458:1480 */               switch (event.getThreadStatus())
/* 1459:     */               {
/* 1460:     */               case -1: 
/* 1461:1483 */                 if (checkForUpdateInRefresh(event) == true)
/* 1462:     */                 {
/* 1463:1484 */                   this.updateRefreshChecking = true;
/* 1464:1485 */                   return true;
/* 1465:     */                 }
/* 1466:1487 */                 UIUtil.startWorkerThread(this, event);
/* 1467:1488 */                 break;
/* 1468:     */               case 1: 
/* 1469:1490 */                 app.removeAllAdHocMobileMbos(false);
/* 1470:1491 */                 return refreshalldata(event);
/* 1471:     */               case 2: 
/* 1472:1493 */                 this.updateRefreshChecking = false;
/* 1473:1494 */                 this.resetAdHocDataPrompted = false;
/* 1474:1495 */                 UIUtil.refreshCurrentScreen();
/* 1475:1496 */                 break;
/* 1476:     */               case 0: 
/* 1477:1498 */                 this.updateRefreshChecking = false;
/* 1478:1499 */                 this.resetAdHocDataPrompted = false;
/* 1479:1500 */                 UIUtil.refreshCurrentScreen();
/* 1480:1501 */                 break;
/* 1481:     */               case 3: 
/* 1482:1503 */                 this.updateRefreshChecking = false;
/* 1483:1504 */                 this.resetAdHocDataPrompted = false;
/* 1484:1505 */                 app.removeAllAdHocMobileMbos(false);
/* 1485:1506 */                 UIUtil.refreshCurrentScreen();
/* 1486:1507 */                 UIUtil.showExceptionMessage(event.getException(), null, 0);
/* 1487:     */               }
/* 1488:1510 */               return true;
/* 1489:     */             }
/* 1490:1513 */             if (event.getMsgResponse().equals("0"))
/* 1491:     */             {
/* 1492:1514 */               BasicMobileDeviceUIApplication app = UIUtil.getApplication();
/* 1493:1515 */               if (!this.resetAdHocDataPrompted)
/* 1494:     */               {
/* 1495:1516 */                 this.resetAdHocDataPrompted = false;
/* 1496:1517 */                 return true;
/* 1497:     */               }
/* 1498:1520 */               switch (event.getThreadStatus())
/* 1499:     */               {
/* 1500:     */               case -1: 
/* 1501:1522 */                 UIUtil.startWorkerThread(this, event);
/* 1502:1523 */                 break;
/* 1503:     */               case 1: 
/* 1504:1525 */                 app.removeAllAdHocMobileMbos(true);
/* 1505:1526 */                 return refreshalldata(event);
/* 1506:     */               case 2: 
/* 1507:1528 */                 this.resetAdHocDataPrompted = false;
/* 1508:1529 */                 UIUtil.refreshCurrentScreen();
/* 1509:1530 */                 break;
/* 1510:     */               case 0: 
/* 1511:1532 */                 this.resetAdHocDataPrompted = false;
/* 1512:1533 */                 UIUtil.refreshCurrentScreen();
/* 1513:1534 */                 break;
/* 1514:     */               case 3: 
/* 1515:1536 */                 this.resetAdHocDataPrompted = false;
/* 1516:1537 */                 app.removeAllAdHocMobileMbos(false);
/* 1517:1538 */                 UIUtil.refreshCurrentScreen();
/* 1518:1539 */                 UIUtil.showExceptionMessage(event.getException(), null, 0);
/* 1519:     */               }
/* 1520:1542 */               return true;
/* 1521:     */             }
/* 1522:     */           }
/* 1523:1544 */           else if (eventId.equalsIgnoreCase("refreshalldataonce"))
/* 1524:     */           {
/* 1525:1545 */             if (event.getMsgResponse().equals("-1"))
/* 1526:     */             {
/* 1527:1546 */               String msg = MobileMessageGenerator.generate("refreshallfirstlogin", null);
/* 1528:1547 */               UIUtil.showOKCANCELMessageBox(event, msg);
/* 1529:1548 */               return true;
/* 1530:     */             }
/* 1531:1549 */             if (event.getMsgResponse().equals("1"))
/* 1532:     */             {
/* 1533:1550 */               switch (event.getThreadStatus())
/* 1534:     */               {
/* 1535:     */               case -1: 
/* 1536:1552 */                 UIUtil.startWorkerThread(this, event);
/* 1537:1553 */                 break;
/* 1538:     */               case 1: 
/* 1539:1555 */                 return refreshalldata(event);
/* 1540:     */               case 2: 
/* 1541:1557 */                 UIUtil.refreshCurrentScreen();
/* 1542:1558 */                 break;
/* 1543:     */               case 0: 
/* 1544:1560 */                 UIUtil.refreshCurrentScreen();
/* 1545:1561 */                 break;
/* 1546:     */               case 3: 
/* 1547:1563 */                 UIUtil.refreshCurrentScreen();
/* 1548:1564 */                 UIUtil.showExceptionMessage(event.getException(), null, 0);
/* 1549:     */               }
/* 1550:1567 */               return true;
/* 1551:     */             }
/* 1552:     */           }
/* 1553:     */           else
/* 1554:     */           {
/* 1555:1569 */             if (eventId.equalsIgnoreCase("uploadpending"))
/* 1556:     */             {
/* 1557:1570 */               switch (event.getThreadStatus())
/* 1558:     */               {
/* 1559:     */               case -1: 
/* 1560:1572 */                 UIUtil.startWorkerThread(this, event);
/* 1561:1573 */                 break;
/* 1562:     */               case 1: 
/* 1563:1575 */                 return uploadpending(event);
/* 1564:     */               case 2: 
/* 1565:1577 */                 UIUtil.refreshCurrentScreen();
/* 1566:1578 */                 break;
/* 1567:     */               case 0: 
/* 1568:1580 */                 UIUtil.refreshCurrentScreen();
/* 1569:1581 */                 break;
/* 1570:     */               case 3: 
/* 1571:1583 */                 UIUtil.refreshCurrentScreen();
/* 1572:1584 */                 UIUtil.showExceptionMessage(event.getException(), null, 0);
/* 1573:     */               }
/* 1574:1587 */               return true;
/* 1575:     */             }
/* 1576:1588 */             if (eventId.equals("haspendingcount")) {
/* 1577:1589 */               return haspendingcount(event);
/* 1578:     */             }
/* 1579:1590 */             if (eventId.equalsIgnoreCase("markalldone"))
/* 1580:     */             {
/* 1581:1591 */               if (event.getMsgResponse().equals("-1"))
/* 1582:     */               {
/* 1583:1592 */                 String msg = MobileMessageGenerator.generate("markalldone", new Object[0]);
/* 1584:1593 */                 UIUtil.showOKCANCELMessageBox(event, msg);
/* 1585:1594 */                 return true;
/* 1586:     */               }
/* 1587:1595 */               if (event.getMsgResponse().equals("1")) {
/* 1588:1596 */                 switch (event.getThreadStatus())
/* 1589:     */                 {
/* 1590:     */                 case -1: 
/* 1591:1598 */                   UIUtil.startWorkerThread(this, event);
/* 1592:1599 */                   break;
/* 1593:     */                 case 1: 
/* 1594:1601 */                   return markalldone(event);
/* 1595:     */                 case 2: 
/* 1596:1603 */                   UIUtil.refreshCurrentScreen();
/* 1597:1604 */                   break;
/* 1598:     */                 case 0: 
/* 1599:1606 */                   UIUtil.refreshCurrentScreen();
/* 1600:1607 */                   break;
/* 1601:     */                 case 3: 
/* 1602:1609 */                   UIUtil.refreshCurrentScreen();
/* 1603:1610 */                   UIUtil.showExceptionMessage(event.getException(), null, 0);
/* 1604:     */                 }
/* 1605:     */               }
/* 1606:1614 */               return true;
/* 1607:     */             }
/* 1608:1617 */             if (eventId.equals("luconnect"))
/* 1609:     */             {
/* 1610:1618 */               switch (event.getThreadStatus())
/* 1611:     */               {
/* 1612:     */               case -1: 
/* 1613:1620 */                 UIUtil.startWorkerThread(this, event);
/* 1614:1621 */                 break;
/* 1615:     */               case 1: 
/* 1616:1623 */                 return luconnect(event);
/* 1617:     */               case 2: 
/* 1618:1625 */                 UIUtil.refreshCurrentScreen();
/* 1619:1626 */                 break;
/* 1620:     */               case 0: 
/* 1621:1628 */                 UIUtil.refreshCurrentScreen();
/* 1622:1629 */                 break;
/* 1623:     */               case 3: 
/* 1624:1632 */                 UIUtil.showFailureMessageBox(MobileMessageGenerator.generate("commfailure", null));
/* 1625:     */               }
/* 1626:1637 */               return true;
/* 1627:     */             }
/* 1628:1640 */             if (eventId.equalsIgnoreCase("commitResetUsers"))
/* 1629:     */             {
/* 1630:1641 */               if (event.getMsgResponse().equals("-1"))
/* 1631:     */               {
/* 1632:1642 */                 UIUtil.showOKCANCELMessageBox(event, MobileMessageGenerator.generate("resetappusers", null));
/* 1633:1643 */                 event.setEventErrored();
/* 1634:1644 */                 return true;
/* 1635:     */               }
/* 1636:1645 */               if (event.getMsgResponse().equals("1")) {
/* 1637:1646 */                 switch (event.getThreadStatus())
/* 1638:     */                 {
/* 1639:     */                 case -1: 
/* 1640:1648 */                   UIUtil.startWorkerThread(this, event);
/* 1641:1649 */                   break;
/* 1642:     */                 case 1: 
/* 1643:1651 */                   return commitResetUsers(event);
/* 1644:     */                 case 2: 
/* 1645:1654 */                   completeResetUsers(event);
/* 1646:1655 */                   break;
/* 1647:     */                 case 0: 
/* 1648:1657 */                   UIUtil.refreshCurrentScreen();
/* 1649:1658 */                   break;
/* 1650:     */                 case 3: 
/* 1651:1660 */                   UIUtil.refreshCurrentScreen();
/* 1652:1661 */                   UIUtil.showExceptionMessage(event.getException(), null, 0);
/* 1653:     */                 }
/* 1654:     */               }
/* 1655:1665 */               return true;
/* 1656:     */             }
/* 1657:1668 */             if (eventId.equalsIgnoreCase("selectAllUsers")) {
/* 1658:1669 */               return selectAllUsers(event);
/* 1659:     */             }
/* 1660:1672 */             if (eventId.equalsIgnoreCase("displayfontimagesize")) {
/* 1661:1673 */               return displayFontImageSize(event);
/* 1662:     */             }
/* 1663:1676 */             if (eventId.equalsIgnoreCase("setdefsiteattributes")) {
/* 1664:1677 */               return setDefSiteAttributes(event);
/* 1665:     */             }
/* 1666:1680 */             if (eventId.equalsIgnoreCase("clearfiltervalues")) {
/* 1667:1681 */               return clearFilterValues(event);
/* 1668:     */             }
/* 1669:1682 */             if (eventId.equalsIgnoreCase("checkForUpdate")) {
/* 1670:1683 */               return checkForUpdate(event, false, true, false);
/* 1671:     */             }
/* 1672:1684 */             if (eventId.startsWith("checkForUpdate?")) {
/* 1673:1685 */               return checkForUpdate(event, false, true, false, eventId.substring(eventId.indexOf("?") + 1, eventId.length()));
/* 1674:     */             }
/* 1675:1686 */             if (eventId.equalsIgnoreCase("checkForUpdateForce")) {
/* 1676:1687 */               return checkForUpdate(event, true, true, false);
/* 1677:     */             }
/* 1678:1688 */             if (eventId.equalsIgnoreCase("checkForUpdateDisplayMessages")) {
/* 1679:1689 */               return checkForUpdate(event, false, true, false);
/* 1680:     */             }
/* 1681:1690 */             if (eventId.equalsIgnoreCase("checkForUpdateAssync")) {
/* 1682:1691 */               return checkForUpdate(event, false, false, false);
/* 1683:     */             }
/* 1684:1692 */             if (eventId.equalsIgnoreCase("checkForUpdateLogin")) {
/* 1685:1693 */               return checkForUpdate(event, false, true, true);
/* 1686:     */             }
/* 1687:1694 */             if (eventId.equalsIgnoreCase("checkForUpdateAssyncLogin")) {
/* 1688:1695 */               return checkForUpdate(event, false, false, true);
/* 1689:     */             }
/* 1690:1696 */             if (eventId.equalsIgnoreCase("updateChecking")) {
/* 1691:1697 */               return updateCheking(event);
/* 1692:     */             }
/* 1693:1698 */             if (eventId.equalsIgnoreCase("hasUpdate")) {
/* 1694:1699 */               return hasUpdate(event);
/* 1695:     */             }
/* 1696:1700 */             if (eventId.equalsIgnoreCase("finalizeLogin")) {
/* 1697:1701 */               return finalizeLogin(event);
/* 1698:     */             }
/* 1699:1704 */             if (eventId.equalsIgnoreCase("openDependency")) {
/* 1700:1705 */               return openDependency(event);
/* 1701:     */             }
/* 1702:1706 */             if (eventId.equalsIgnoreCase("doneAllDependencies")) {
/* 1703:1707 */               return doneAllDependencies(event);
/* 1704:     */             }
/* 1705:1708 */             if (eventId.equalsIgnoreCase("canceldeppage")) {
/* 1706:1709 */               return canceldeppage(event);
/* 1707:     */             }
/* 1708:1712 */             if (eventId.equalsIgnoreCase("check4messages")) {
/* 1709:1713 */               return check4messages(event);
/* 1710:     */             }
/* 1711:1714 */             if (eventId.equalsIgnoreCase("filterNotRead")) {
/* 1712:1715 */               return filterNotRead(event);
/* 1713:     */             }
/* 1714:1716 */             if (eventId.equalsIgnoreCase("markRead")) {
/* 1715:1717 */               return markRead(event);
/* 1716:     */             }
/* 1717:1718 */             if (eventId.equalsIgnoreCase("markAllRead")) {
/* 1718:1719 */               return markAllRead(event);
/* 1719:     */             }
/* 1720:1720 */             if (eventId.equalsIgnoreCase("hideifpermsg")) {
/* 1721:1721 */               return hideIfPerMsg(event);
/* 1722:     */             }
/* 1723:1724 */             if (eventId.equalsIgnoreCase("validatePreferencesIntegerFields")) {
/* 1724:1725 */               return validatePreferencesIntegerFields(event);
/* 1725:     */             }
/* 1726:1726 */             if (eventId.equals("saveConnPrefs")) {
/* 1727:1727 */               return saveConnPrefs(event);
/* 1728:     */             }
/* 1729:1728 */             if (eventId.equals("displayconnprefs")) {
/* 1730:1729 */               return displaConnPrefs(event);
/* 1731:     */             }
/* 1732:1730 */             if (eventId.equals("resetConnSettings")) {
/* 1733:1731 */               return resetConnSettings(event);
/* 1734:     */             }
/* 1735:1732 */             if (eventId.equalsIgnoreCase("supportsCamera")) {
/* 1736:1733 */               return supportsCamera(event);
/* 1737:     */             }
/* 1738:1734 */             if (eventId.equalsIgnoreCase("initColumnResizerPage")) {
/* 1739:1735 */               return initColumnResizerPage(event);
/* 1740:     */             }
/* 1741:1736 */             if (eventId.equalsIgnoreCase("saveNewColumnSize")) {
/* 1742:1737 */               return saveNewColumnSize(event);
/* 1743:     */             }
/* 1744:     */           }
/* 1745:     */         }
/* 1746:     */       }
/* 1747:1739 */       return false;
/* 1748:     */     }
/* 1749:1741 */     return true;
/* 1750:     */   }
/* 1751:     */   
/* 1752:     */   protected boolean toggleDocExtractDeleteButton(UIEvent event)
/* 1753:     */     throws MobileApplicationException
/* 1754:     */   {
/* 1755:1745 */     StateControl state = (StateControl)event.getCreatingObject();
/* 1756:1746 */     String btnDelete = null;
/* 1757:1747 */     String btnExtract = null;
/* 1758:1748 */     Iterator buttons = state.getChildren();
/* 1759:1749 */     while (buttons.hasNext())
/* 1760:     */     {
/* 1761:1750 */       ButtonControl button = (ButtonControl)buttons.next();
/* 1762:1751 */       String buttonId = button.getId();
/* 1763:1752 */       if (buttonId.toLowerCase().endsWith("_delete")) {
/* 1764:1754 */         btnDelete = buttonId;
/* 1765:1756 */       } else if (buttonId.toLowerCase().endsWith("_extract")) {
/* 1766:1758 */         btnExtract = buttonId;
/* 1767:     */       }
/* 1768:     */     }
/* 1769:1761 */     if (canDisplayDocExtract(event)) {
/* 1770:1762 */       state.setNewState(btnExtract);
/* 1771:     */     } else {
/* 1772:1764 */       state.setNewState(btnDelete);
/* 1773:     */     }
/* 1774:1766 */     return true;
/* 1775:     */   }
/* 1776:     */   
/* 1777:     */   private boolean supportsCamera(UIEvent event)
/* 1778:     */     throws MobileApplicationException
/* 1779:     */   {
/* 1780:1770 */     boolean isCameraSupported = UIUtil.getApplication().getMobileUIManager().supportsCamera();
/* 1781:1771 */     AbstractMobileControl linkControl = (AbstractMobileControl)event.getCreatingObject();
/* 1782:1772 */     if (linkControl != null) {
/* 1783:1773 */       linkControl.setVisibility(isCameraSupported);
/* 1784:     */     }
/* 1785:1775 */     return true;
/* 1786:     */   }
/* 1787:     */   
/* 1788:     */   private boolean initColumnResizerPage(UIEvent event)
/* 1789:     */     throws MobileApplicationException
/* 1790:     */   {
/* 1791:1781 */     MobileMboDataBean resizerDataBean = ((PageControl)event.getCreatingObject()).getDataBean();
/* 1792:1782 */     resizerDataBean.setValue("TEMP_COLWIDTH", resizerDataBean.getValue("COLWIDTH"));
/* 1793:     */     
/* 1794:1784 */     return true;
/* 1795:     */   }
/* 1796:     */   
/* 1797:     */   private boolean saveNewColumnSize(UIEvent event)
/* 1798:     */     throws MobileApplicationException
/* 1799:     */   {
/* 1800:1788 */     MobileMboDataBean resizerDataBean = ((LinkControl)event.getCreatingObject()).getDataBean();
/* 1801:1789 */     resizerDataBean.setValue("COLWIDTH", resizerDataBean.getValue("TEMP_COLWIDTH"));
/* 1802:     */     
/* 1803:1791 */     UIUtil.getApplication().removeCurrentScreen(true);
/* 1804:     */     
/* 1805:1793 */     return true;
/* 1806:     */   }
/* 1807:     */   
/* 1808:     */   private boolean resetConnSettings(UIEvent event)
/* 1809:     */   {
/* 1810:1797 */     TextboxControl hostControl = (TextboxControl)UIUtil.findControl("maximo.mobile.hostname");
/* 1811:1798 */     TextboxControl portControl = (TextboxControl)UIUtil.findControl("maximo.mobile.port");
/* 1812:1799 */     CheckboxControl sslControl = (CheckboxControl)UIUtil.findControl("maximo.mobile.ssl");
/* 1813:1800 */     UIUtil.getApplication().loadApplicationProperties("/mobile.properties");
/* 1814:1801 */     hostControl.setTextOnWidget(UIUtil.getApplication().getProperty("maximo.mobile.hostname"));
/* 1815:1802 */     portControl.setTextOnWidget(UIUtil.getApplication().getProperty("maximo.mobile.port"));
/* 1816:1803 */     String ssl = UIUtil.getApplication().getProperty("maximo.mobile.ssl");
/* 1817:1804 */     sslControl.setStateOnCheckBoxWidget(ssl != null ? Boolean.valueOf(ssl).booleanValue() : false);
/* 1818:1805 */     return true;
/* 1819:     */   }
/* 1820:     */   
/* 1821:     */   protected boolean displaConnPrefs(UIEvent event)
/* 1822:     */   {
/* 1823:1809 */     TextboxControl hostControl = (TextboxControl)UIUtil.findControl("maximo.mobile.hostname");
/* 1824:1810 */     TextboxControl portControl = (TextboxControl)UIUtil.findControl("maximo.mobile.port");
/* 1825:1811 */     CheckboxControl sslControl = (CheckboxControl)UIUtil.findControl("maximo.mobile.ssl");
/* 1826:     */     
/* 1827:1813 */     hostControl.setTextOnWidget(getSetting("maximo.mobile.hostname"));
/* 1828:1814 */     portControl.setTextOnWidget(getSetting("maximo.mobile.port"));
/* 1829:1815 */     String ssl = getSetting("maximo.mobile.ssl");
/* 1830:1816 */     sslControl.setStateOnCheckBoxWidget(ssl != null ? Boolean.valueOf(ssl).booleanValue() : false);
/* 1831:1817 */     return true;
/* 1832:     */   }
/* 1833:     */   
/* 1834:     */   private String getSetting(String key)
/* 1835:     */   {
/* 1836:1821 */     String setting = UIUtil.getApplication().getSystemSetting(key);
/* 1837:1822 */     if (setting == null) {
/* 1838:1823 */       return UIUtil.getApplication().getProperty(key);
/* 1839:     */     }
/* 1840:1825 */     return setting;
/* 1841:     */   }
/* 1842:     */   
/* 1843:     */   protected boolean saveConnPrefs(UIEvent event)
/* 1844:     */     throws MobileApplicationException
/* 1845:     */   {
/* 1846:1829 */     TextboxControl hostControl = (TextboxControl)UIUtil.findControl("maximo.mobile.hostname");
/* 1847:1830 */     TextboxControl portControl = (TextboxControl)UIUtil.findControl("maximo.mobile.port");
/* 1848:1831 */     CheckboxControl sslControl = (CheckboxControl)UIUtil.findControl("maximo.mobile.ssl");
/* 1849:1832 */     setSetting("maximo.mobile.hostname", hostControl.getControlValue());
/* 1850:1833 */     setSetting("maximo.mobile.port", portControl.getControlValue());
/* 1851:1834 */     setSetting("maximo.mobile.ssl", "" + Boolean.valueOf(sslControl.getControlValue()));
/* 1852:1835 */     UIUtil.closePage();
/* 1853:1836 */     return true;
/* 1854:     */   }
/* 1855:     */   
/* 1856:     */   private void setSetting(String key, String value)
/* 1857:     */     throws MobileApplicationException
/* 1858:     */   {
/* 1859:1840 */     UIUtil.getApplication().setProperty(key, value);
/* 1860:1841 */     UIUtil.getApplication().setSystemSetting(key, value);
/* 1861:     */   }
/* 1862:     */   
/* 1863:     */   private void completeResetUsers(UIEvent event)
/* 1864:     */     throws MobileApplicationException
/* 1865:     */   {
/* 1866:1846 */     BasicMobileDeviceUIApplication app = UIUtil.getApplication();
/* 1867:     */     
/* 1868:1848 */     event.setValue(app.getStartupScreenId());
/* 1869:1849 */     gotopagenosave(event);
/* 1870:     */   }
/* 1871:     */   
/* 1872:     */   protected boolean validatePreferencesIntegerFields(UIEvent event)
/* 1873:     */     throws MobileApplicationException
/* 1874:     */   {
/* 1875:1855 */     String value = (String)event.getValue();
/* 1876:1856 */     if ((value != null) && (value.length() > 0)) {
/* 1877:1857 */       DefaultMobileMboDataFormatter.stringToLong(value, Locale.getDefault());
/* 1878:     */     }
/* 1879:1860 */     return true;
/* 1880:     */   }
/* 1881:     */   
/* 1882:     */   protected boolean setDefSiteAttributes(UIEvent event)
/* 1883:     */     throws MobileApplicationException
/* 1884:     */   {
/* 1885:1873 */     AbstractMobileControl control = (AbstractMobileControl)event.getCreatingObject();
/* 1886:1874 */     MobileMbo prefMbo = control.getDataBean().getMobileMbo(0);
/* 1887:     */     
/* 1888:1876 */     control.setReadonly(prefMbo.isReadOnly("DEFSITE"));
/* 1889:1877 */     control.setRequired(prefMbo.isRequired("DEFSITE"));
/* 1890:     */     
/* 1891:1879 */     return true;
/* 1892:     */   }
/* 1893:     */   
/* 1894:     */   private boolean prepareDefSiteAttributes(MobileMbo prefMbo)
/* 1895:     */     throws MobileApplicationException
/* 1896:     */   {
/* 1897:1892 */     boolean isDefSiteBlank = false;
/* 1898:1894 */     if (UIUtil.isNull(prefMbo.getValue("DEFSITE"))) {
/* 1899:1895 */       isDefSiteBlank = true;
/* 1900:     */     }
/* 1901:1899 */     prefMbo.setReadOnly("DEFSITE", isDefSiteBlank);
/* 1902:1900 */     prefMbo.setRequired("DEFSITE", !isDefSiteBlank);
/* 1903:     */     
/* 1904:1902 */     return isDefSiteBlank;
/* 1905:     */   }
/* 1906:     */   
/* 1907:     */   private UIEvent triggerLookupSelectEvent(UIEvent event)
/* 1908:     */   {
/* 1909:1911 */     AbstractMobileControl control = (AbstractMobileControl)event.getCreatingObject();
/* 1910:1912 */     UIEvent result = null;
/* 1911:1914 */     while (control != null)
/* 1912:     */     {
/* 1913:1915 */       if ((control instanceof LookupControl))
/* 1914:     */       {
/* 1915:1916 */         if (!control.isAttributeSet("nextsetattributes")) {
/* 1916:     */           break;
/* 1917:     */         }
/* 1918:1917 */         result = new UIEvent(UIUtil.getCurrentScreen(), "multiselect", null, null); break;
/* 1919:     */       }
/* 1920:1921 */       control = control.getParentControl();
/* 1921:     */     }
/* 1922:1923 */     if (result == null) {
/* 1923:1924 */       result = new UIEvent(UIUtil.getCurrentScreen(), "select", null, null);
/* 1924:     */     }
/* 1925:1926 */     return result;
/* 1926:     */   }
/* 1927:     */   
/* 1928:     */   private boolean hideIfPerMsg(UIEvent event)
/* 1929:     */     throws MobileApplicationException
/* 1930:     */   {
/* 1931:1930 */     AbstractMobileControl control = (AbstractMobileControl)event.getCreatingObject();
/* 1932:1931 */     if (control == null) {
/* 1933:1932 */       return false;
/* 1934:     */     }
/* 1935:1934 */     MobileMboDataBean databean = control.getDataBean();
/* 1936:1935 */     if (databean == null) {
/* 1937:1936 */       return false;
/* 1938:     */     }
/* 1939:1938 */     String toGroup = databean.getValue("TOGROUP");
/* 1940:1939 */     if ((toGroup == null) || (toGroup.trim().equals(""))) {
/* 1941:1940 */       control.setVisibility(false);
/* 1942:     */     }
/* 1943:1942 */     return false;
/* 1944:     */   }
/* 1945:     */   
/* 1946:     */   private boolean check4messages(UIEvent event)
/* 1947:     */     throws MobileApplicationException
/* 1948:     */   {
/* 1949:1950 */     AbstractMobileControl control = (AbstractMobileControl)event.getCreatingObject();
/* 1950:1951 */     if (control == null) {
/* 1951:1952 */       return false;
/* 1952:     */     }
/* 1953:1954 */     MobileMboDataBean databean = control.getDataBean();
/* 1954:1955 */     if (databean == null) {
/* 1955:1956 */       return false;
/* 1956:     */     }
/* 1957:1958 */     if (databean.count() == 0) {
/* 1958:1959 */       control.setVisibility(false);
/* 1959:     */     }
/* 1960:1961 */     return true;
/* 1961:     */   }
/* 1962:     */   
/* 1963:     */   protected boolean filterNotRead(UIEvent event)
/* 1964:     */     throws MobileApplicationException
/* 1965:     */   {
/* 1966:1968 */     MobileMboDataBean bulletinBean = DataBeanCache.getDataBean("MOBBULLETINBOARD", "MOBBULLETINBOARD");
/* 1967:     */     
/* 1968:1970 */     bulletinBean.setInternalQBE("ISREAD", "0");
/* 1969:1971 */     bulletinBean.reset();
/* 1970:     */     
/* 1971:1973 */     return true;
/* 1972:     */   }
/* 1973:     */   
/* 1974:     */   private boolean markRead(UIEvent event)
/* 1975:     */     throws MobileApplicationException
/* 1976:     */   {
/* 1977:1978 */     AbstractMobileControl control = (AbstractMobileControl)event.getCreatingObject();
/* 1978:1979 */     if (control == null) {
/* 1979:1980 */       return false;
/* 1980:     */     }
/* 1981:1982 */     MobileMboDataBean databean = control.getDataBean();
/* 1982:1983 */     if (databean == null) {
/* 1983:1984 */       return false;
/* 1984:     */     }
/* 1985:1986 */     MobileMbo mobileMbo = databean.getMobileMbo();
/* 1986:1987 */     if (mobileMbo == null) {
/* 1987:1988 */       return false;
/* 1988:     */     }
/* 1989:1990 */     mobileMbo.setBooleanValue("ISREAD", true);
/* 1990:1991 */     mobileMbo.setDateValue("DATEREAD", new Date());
/* 1991:     */     
/* 1992:1993 */     databean.getDataBeanManager().save();
/* 1993:1994 */     databean.reset();
/* 1994:1996 */     if ((control.getParentControl() instanceof ToolBarContainerControl)) {
/* 1995:1998 */       UIUtil.closePage();
/* 1996:     */     } else {
/* 1997:2001 */       UIUtil.refreshCurrentScreen();
/* 1998:     */     }
/* 1999:2004 */     return true;
/* 2000:     */   }
/* 2001:     */   
/* 2002:     */   private boolean markAllRead(UIEvent event)
/* 2003:     */     throws MobileApplicationException
/* 2004:     */   {
/* 2005:2009 */     boolean shouldContinue = checkUserAnswer(event);
/* 2006:2010 */     if (!shouldContinue) {
/* 2007:2011 */       return true;
/* 2008:     */     }
/* 2009:2013 */     AbstractMobileControl control = (AbstractMobileControl)event.getCreatingObject();
/* 2010:2014 */     if (control == null) {
/* 2011:2015 */       return false;
/* 2012:     */     }
/* 2013:2017 */     MobileMboDataBean databean = control.getDataBean();
/* 2014:2018 */     if (databean == null) {
/* 2015:2019 */       return false;
/* 2016:     */     }
/* 2017:2021 */     databean.reset();
/* 2018:     */     
/* 2019:2023 */     int index = 0;
/* 2020:2024 */     MobileMbo mobileMbo = databean.getMobileMbo(index);
/* 2021:2025 */     while (mobileMbo != null)
/* 2022:     */     {
/* 2023:2026 */       mobileMbo.setBooleanValue("ISREAD", true);
/* 2024:2027 */       mobileMbo.setDateValue("DATEREAD", new Date());
/* 2025:2028 */       index++;
/* 2026:2029 */       mobileMbo = databean.getMobileMbo(index);
/* 2027:     */     }
/* 2028:2031 */     databean.getDataBeanManager().save();
/* 2029:2032 */     databean.reset();
/* 2030:     */     
/* 2031:2034 */     UIUtil.refreshCurrentScreen();
/* 2032:     */     
/* 2033:2036 */     return true;
/* 2034:     */   }
/* 2035:     */   
/* 2036:     */   private boolean checkUserAnswer(UIEvent event)
/* 2037:     */   {
/* 2038:2042 */     boolean result = false;
/* 2039:2043 */     if (event.getMsgResponse().equalsIgnoreCase("-1"))
/* 2040:     */     {
/* 2041:2044 */       String message = MobileMessageGenerator.generate("markallreadconfig", null);
/* 2042:2045 */       UIUtil.showMessageBox(message, "question", 12, event);
/* 2043:2046 */       event.setEventErrored();
/* 2044:     */     }
/* 2045:2048 */     else if (event.getMsgResponse().equalsIgnoreCase("1"))
/* 2046:     */     {
/* 2047:2049 */       result = true;
/* 2048:     */     }
/* 2049:2051 */     return result;
/* 2050:     */   }
/* 2051:     */   
/* 2052:     */   public boolean canceldeppage(UIEvent event)
/* 2053:     */     throws MobileApplicationException
/* 2054:     */   {
/* 2055:2055 */     MobileMboDependencyManager.reset();
/* 2056:2056 */     UIUtil.cancelPage();
/* 2057:2057 */     return true;
/* 2058:     */   }
/* 2059:     */   
/* 2060:     */   public boolean doneAllDependencies(UIEvent event)
/* 2061:     */     throws MobileApplicationException
/* 2062:     */   {
/* 2063:2061 */     new AsyncMobileDependencyAllDone().handleInBackground(event);
/* 2064:2062 */     return true;
/* 2065:     */   }
/* 2066:     */   
/* 2067:     */   public boolean openDependency(UIEvent event)
/* 2068:     */     throws MobileApplicationException
/* 2069:     */   {
/* 2070:2067 */     AbstractMobileControl control = (AbstractMobileControl)event.getCreatingObject();
/* 2071:2068 */     MobileMboDataBean databean = control.getDataBean();
/* 2072:2069 */     String mobileMboName = databean.getValue("MOBILEMBONAME");
/* 2073:2070 */     MobileMboDependencyManager.RelationDisplayInfo info = MobileMboDependencyManager.getDisplayInfo(mobileMboName);
/* 2074:     */     
/* 2075:2072 */     showRecord(databean, mobileMboName, info);
/* 2076:     */     
/* 2077:2074 */     MobileMboDependencyManager.reset();
/* 2078:     */     
/* 2079:2076 */     return true;
/* 2080:     */   }
/* 2081:     */   
/* 2082:     */   public void showRecord(MobileMboDataBean databean, String mobileMboName, MobileMboDependencyManager.RelationDisplayInfo info)
/* 2083:     */     throws MobileApplicationException
/* 2084:     */   {
/* 2085:2081 */     String pageId = info.getPageIdToDisplay();
/* 2086:2082 */     String datasrc = info.getMobileMboDataSrc();
/* 2087:2083 */     if ((pageId == null) || (datasrc == null)) {
/* 2088:2084 */       return;
/* 2089:     */     }
/* 2090:2087 */     long recId = databean.getMobileMbo().getLongValue("RECID");
/* 2091:2088 */     MobileMboDataBean recDataBean = DataBeanCache.getDataBean(datasrc, mobileMboName);
/* 2092:     */     
/* 2093:2090 */     recDataBean.getQBE().reset();
/* 2094:2091 */     recDataBean.reset();
/* 2095:2092 */     MobileMbo mobileMbo = recDataBean.getMobileMbo(0);
/* 2096:2093 */     int index = 0;
/* 2097:2094 */     while (mobileMbo != null)
/* 2098:     */     {
/* 2099:2095 */       if (mobileMbo.getId() == recId)
/* 2100:     */       {
/* 2101:2096 */         recDataBean.setCurrentPosition(index);
/* 2102:2097 */         UIUtil.showPageNoSave(pageId, null);
/* 2103:2098 */         break;
/* 2104:     */       }
/* 2105:2100 */       index++;
/* 2106:2101 */       mobileMbo = recDataBean.getMobileMbo(index);
/* 2107:     */     }
/* 2108:     */   }
/* 2109:     */   
/* 2110:     */   public boolean loadUsersInformation(UIEvent event)
/* 2111:     */     throws MobileApplicationException
/* 2112:     */   {
/* 2113:2107 */     ProgressObserver observer = event.getProgressObserver();
/* 2114:2108 */     if (observer != null)
/* 2115:     */     {
/* 2116:2109 */       String msg = MobileMessageGenerator.generate("identifyingusers", new Object[0]);
/* 2117:2110 */       event.getProgressObserver().setWorkProgressMessage(msg);
/* 2118:2111 */       observer.updateWorkProgress();
/* 2119:2112 */       Vector deviceUsers = UIUtil.getApplication().getDeviceRegisteredUsers();
/* 2120:2113 */       MobileMboDataBean users = new MobileMboDataBeanManager("DEVICEREGISTEREDUSERS").getDataBean();
/* 2121:2114 */       observer.updateWorkProgress();
/* 2122:     */       
/* 2123:     */ 
/* 2124:2117 */       int count = users.count();
/* 2125:2118 */       while ((count-- > 0) && (users.dataExists(0)))
/* 2126:     */       {
/* 2127:2119 */         observer.updateWorkProgress();
/* 2128:2120 */         users.deleteLocal();
/* 2129:2121 */         observer.updateWorkProgress();
/* 2130:2122 */         users.getDataBeanManager().save();
/* 2131:     */       }
/* 2132:2126 */       for (int i = 0; i < deviceUsers.size(); i++)
/* 2133:     */       {
/* 2134:2127 */         observer.updateWorkProgress();
/* 2135:2128 */         users.insert();
/* 2136:2129 */         users.getMobileMbo().setValue("USERNAME", deviceUsers.get(i).toString());
/* 2137:2130 */         users.getMobileMbo().setBooleanValue("SELECTED", false);
/* 2138:2131 */         observer.updateWorkProgress();
/* 2139:     */       }
/* 2140:2133 */       users.getDataBeanManager().save();
/* 2141:     */     }
/* 2142:2135 */     return true;
/* 2143:     */   }
/* 2144:     */   
/* 2145:     */   public boolean commitResetUsers(UIEvent event)
/* 2146:     */     throws MobileApplicationException
/* 2147:     */   {
/* 2148:2140 */     ProgressObserver observer = event.getProgressObserver();
/* 2149:2141 */     if (observer != null)
/* 2150:     */     {
/* 2151:2142 */       String msg = MobileMessageGenerator.generate("resettingappusers", new Object[0]);
/* 2152:2143 */       event.getProgressObserver().setWorkProgressMessage(msg);
/* 2153:2144 */       observer.updateWorkProgress();
/* 2154:     */       
/* 2155:2146 */       BasicMobileDeviceUIApplication app = UIUtil.getApplication();
/* 2156:2147 */       MobileMboDataBean users = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/* 2157:2148 */       Vector selected = new Vector();
/* 2158:2149 */       observer.updateWorkProgress();
/* 2159:2150 */       for (int i = 0; users.dataExists(i); i++)
/* 2160:     */       {
/* 2161:2151 */         MobileMbo current = users.getMobileMbo(i);
/* 2162:2152 */         if (current.getBooleanValue("SELECTED"))
/* 2163:     */         {
/* 2164:2153 */           observer.updateWorkProgress();
/* 2165:2154 */           selected.addElement(current.getValue("USERNAME"));
/* 2166:     */         }
/* 2167:     */       }
/* 2168:2158 */       for (int i = 0; i < selected.size(); i++)
/* 2169:     */       {
/* 2170:2159 */         observer.updateWorkProgress();
/* 2171:2160 */         app.resetApplication(selected.elementAt(i).toString());
/* 2172:2161 */         observer.updateWorkProgress();
/* 2173:     */       }
/* 2174:2165 */       if (selected.contains(app.getCurrentUser()))
/* 2175:     */       {
/* 2176:2166 */         app.releaseApplication();
/* 2177:2167 */         app.getSystemInterface().exitSystem();
/* 2178:     */       }
/* 2179:2172 */       app.initializeAppUserRuntime(app.getCurrentUser(), observer);
/* 2180:2173 */       app.initApplicationFromMetaData(MobileDeviceAppSession.getSession().getMobileMetadata());
/* 2181:     */     }
/* 2182:2176 */     return true;
/* 2183:     */   }
/* 2184:     */   
/* 2185:     */   public boolean selectAllUsers(UIEvent event)
/* 2186:     */     throws MobileApplicationException
/* 2187:     */   {
/* 2188:2185 */     MobileMboDataBean dataBean = UIUtil.getCurrentScreen().getDataBean();
/* 2189:2186 */     for (int i = 0; (i < dataBean.count()) && (dataBean.dataExists(i)); i++) {
/* 2190:2187 */       dataBean.getMobileMbo(i).setBooleanValue("SELECTED", true);
/* 2191:     */     }
/* 2192:2189 */     UIUtil.refreshCurrentScreen();
/* 2193:2190 */     return true;
/* 2194:     */   }
/* 2195:     */   
/* 2196:     */   public boolean luconnect(UIEvent event)
/* 2197:     */     throws MobileApplicationException
/* 2198:     */   {
/* 2199:2197 */     BasicMobileDeviceApplication app = UIUtil.getApplication();
/* 2200:2198 */     app.checkUpdateError();
/* 2201:     */     
/* 2202:2200 */     MobileMboDataBean dataBean = (MobileMboDataBean)event.getSource();
/* 2203:2201 */     if (dataBean != null)
/* 2204:     */     {
/* 2205:2202 */       ProgressObserver observer = event.getProgressObserver();
/* 2206:2203 */       if ((observer != null) && (!dataBean.isOnline()))
/* 2207:     */       {
/* 2208:2204 */         String msg = MobileMessageGenerator.generate("determinelookupadhoc", new Object[0]);
/* 2209:2205 */         event.getProgressObserver().setWorkProgressMessage(msg);
/* 2210:2206 */         observer.updateWorkProgress();
/* 2211:2207 */         observer.updateWorkProgress();
/* 2212:     */       }
/* 2213:2209 */       dataBean.setOnline(!dataBean.isOnline());
/* 2214:2210 */       dataBean.reset();
/* 2215:2211 */       if (dataBean.isOnline())
/* 2216:     */       {
/* 2217:2213 */         dataBean.count();
/* 2218:2214 */         dataBean.getMobileMbo(0);
/* 2219:     */       }
/* 2220:     */     }
/* 2221:2218 */     return true;
/* 2222:     */   }
/* 2223:     */   
/* 2224:     */   private boolean setusername(UIEvent event)
/* 2225:     */   {
/* 2226:2226 */     if ((event.getCreatingObject() instanceof TextboxControl))
/* 2227:     */     {
/* 2228:2227 */       String username = UIUtil.getApplication().getCurrentUser();
/* 2229:2228 */       TextboxControl tb = (TextboxControl)event.getCreatingObject();
/* 2230:2229 */       if (UIUtil.isNull(username))
/* 2231:     */       {
/* 2232:2230 */         tb.setReadonly(false);
/* 2233:2231 */         tb.setRequired(true);
/* 2234:     */       }
/* 2235:     */       else
/* 2236:     */       {
/* 2237:2233 */         tb.setReadonly(true);
/* 2238:2234 */         tb.setRequired(false);
/* 2239:2235 */         tb.setTextOnWidget(username);
/* 2240:     */       }
/* 2241:     */     }
/* 2242:2238 */     return true;
/* 2243:     */   }
/* 2244:     */   
/* 2245:     */   public boolean resetapp(UIEvent event)
/* 2246:     */     throws MobileApplicationException
/* 2247:     */   {
/* 2248:2243 */     if ((!isSingleUser()) && (canResetOtherUsers()))
/* 2249:     */     {
/* 2250:2244 */       switch (event.getThreadStatus())
/* 2251:     */       {
/* 2252:     */       case -1: 
/* 2253:2246 */         UIUtil.startWorkerThread(this, event);
/* 2254:2247 */         break;
/* 2255:     */       case 1: 
/* 2256:2249 */         return loadUsersInformation(event);
/* 2257:     */       case 2: 
/* 2258:2251 */         event.setValue("resetusers");
/* 2259:2252 */         return showpage(event);
/* 2260:     */       case 0: 
/* 2261:2254 */         UIUtil.refreshCurrentScreen();
/* 2262:2255 */         break;
/* 2263:     */       case 3: 
/* 2264:2257 */         UIUtil.refreshCurrentScreen();
/* 2265:2258 */         UIUtil.showExceptionMessage(event.getException(), null, 0);
/* 2266:     */       }
/* 2267:2261 */       return true;
/* 2268:     */     }
/* 2269:2263 */     return alertReset(event);
/* 2270:     */   }
/* 2271:     */   
/* 2272:     */   private boolean canResetOtherUsers()
/* 2273:     */     throws MobileApplicationException
/* 2274:     */   {
/* 2275:2268 */     return UIUtil.getApplication().isOptionAuthorized("RSTALLUSRS");
/* 2276:     */   }
/* 2277:     */   
/* 2278:     */   private boolean isSingleUser()
/* 2279:     */     throws MobileApplicationException
/* 2280:     */   {
/* 2281:2273 */     return UIUtil.getApplication().getDeviceRegisteredUsers().size() == 1;
/* 2282:     */   }
/* 2283:     */   
/* 2284:     */   private boolean alertReset(UIEvent event)
/* 2285:     */     throws MobileApplicationException
/* 2286:     */   {
/* 2287:2278 */     if (event.getMsgResponse().equals("-1"))
/* 2288:     */     {
/* 2289:2279 */       UIUtil.showOKCANCELMessageBox(event, MobileMessageGenerator.generate("resetapp", null));
/* 2290:2280 */       event.setEventErrored();
/* 2291:2281 */       return true;
/* 2292:     */     }
/* 2293:2282 */     if (event.getMsgResponse().equals("1"))
/* 2294:     */     {
/* 2295:2283 */       BasicMobileDeviceUIApplication app = UIUtil.getApplication();
/* 2296:2284 */       app.releaseApplication();
/* 2297:2285 */       app.resetApplication(app.getCurrentUser());
/* 2298:2286 */       app.getSystemInterface().exitSystem();
/* 2299:     */     }
/* 2300:2288 */     return true;
/* 2301:     */   }
/* 2302:     */   
/* 2303:     */   public boolean resetappondbissues(UIEvent event)
/* 2304:     */     throws MobileApplicationException
/* 2305:     */   {
/* 2306:2296 */     if (event.getMsgResponse().equals("-1"))
/* 2307:     */     {
/* 2308:2297 */       UIUtil.showOKCANCELMessageBox(event, MobileMessageGenerator.generate("dbproblem", null));
/* 2309:2298 */       event.setEventErrored();
/* 2310:2299 */       return true;
/* 2311:     */     }
/* 2312:2300 */     if (event.getMsgResponse().equals("1"))
/* 2313:     */     {
/* 2314:2301 */       BasicMobileDeviceUIApplication app = UIUtil.getApplication();
/* 2315:2302 */       app.releaseApplication();
/* 2316:2303 */       app.resetApplication(app.getCurrentUser());
/* 2317:2304 */       app.getSystemInterface().exitSystem();
/* 2318:     */     }
/* 2319:2306 */     return true;
/* 2320:     */   }
/* 2321:     */   
/* 2322:     */   public boolean trackerrors(UIEvent event)
/* 2323:     */     throws MobileApplicationException
/* 2324:     */   {
/* 2325:2319 */     AbstractMobileControl callingControl = (AbstractMobileControl)event.getCreatingObject();
/* 2326:2320 */     MobileMboDataBean dataBean = callingControl.getDataBean();
/* 2327:2321 */     if (dataBean.getErrorCount() > 0)
/* 2328:     */     {
/* 2329:2322 */       callingControl.setVisibility(true);
/* 2330:2323 */       StateControl state = (StateControl)callingControl;
/* 2331:2324 */       if (dataBean.isSecondaryFilterOn()) {
/* 2332:2325 */         state.setStateViaState("filtered");
/* 2333:     */       } else {
/* 2334:2327 */         state.setStateViaState("notfiltered");
/* 2335:     */       }
/* 2336:     */     }
/* 2337:     */     else
/* 2338:     */     {
/* 2339:2330 */       callingControl.setVisibility(false);
/* 2340:     */     }
/* 2341:2332 */     return true;
/* 2342:     */   }
/* 2343:     */   
/* 2344:     */   public boolean showerrorlist(UIEvent event)
/* 2345:     */     throws MobileApplicationException
/* 2346:     */   {
/* 2347:2343 */     AbstractMobileControl callingControl = (AbstractMobileControl)event.getCreatingObject();
/* 2348:2344 */     MobileMboDataBean dataBean = callingControl.getDataBean();
/* 2349:2345 */     dataBean.setErrorFilter();
/* 2350:     */     
/* 2351:2347 */     dataBean.reset();
/* 2352:2348 */     UIUtil.refreshCurrentScreen();
/* 2353:2349 */     return true;
/* 2354:     */   }
/* 2355:     */   
/* 2356:     */   public boolean reseterrorlist(UIEvent event)
/* 2357:     */     throws MobileApplicationException
/* 2358:     */   {
/* 2359:2360 */     AbstractMobileControl callingControl = (AbstractMobileControl)event.getCreatingObject();
/* 2360:2361 */     MobileMboDataBean dataBean = callingControl.getDataBean();
/* 2361:2362 */     dataBean.clearErrorFilter();
/* 2362:     */     
/* 2363:2364 */     dataBean.reset();
/* 2364:2365 */     UIUtil.refreshCurrentScreen();
/* 2365:2366 */     return true;
/* 2366:     */   }
/* 2367:     */   
/* 2368:     */   public boolean check4errors(UIEvent event)
/* 2369:     */     throws MobileApplicationException
/* 2370:     */   {
/* 2371:2377 */     AbstractMobileControl callingControl = (AbstractMobileControl)event.getCreatingObject();
/* 2372:2378 */     MobileMboDataBean dataBean = callingControl.getDataBean();
/* 2373:2379 */     if (dataBean.getErrorCount() > 0) {
/* 2374:2380 */       callingControl.setVisibility(true);
/* 2375:     */     } else {
/* 2376:2382 */       callingControl.setVisibility(false);
/* 2377:     */     }
/* 2378:2385 */     return true;
/* 2379:     */   }
/* 2380:     */   
/* 2381:     */   public boolean check4anyerrors(UIEvent event)
/* 2382:     */     throws MobileApplicationException
/* 2383:     */   {
/* 2384:2396 */     AbstractMobileControl callingControl = (AbstractMobileControl)event.getCreatingObject();
/* 2385:2397 */     AbstractMobileDeviceApplication curApp = UIUtil.getApplication();
/* 2386:     */     
/* 2387:2399 */     ArrayList mobilembos = getChildMobileMbos(callingControl);
/* 2388:2400 */     boolean hasErrors = false;
/* 2389:2401 */     String mobileMboName = null;
/* 2390:2402 */     Iterator it = mobilembos.iterator();
/* 2391:2403 */     while (it.hasNext())
/* 2392:     */     {
/* 2393:2404 */       mobileMboName = (String)it.next();
/* 2394:2405 */       MobileMboInfo mboInfo = MobileMboUtil.getMobileMboInfo(curApp.getAppName(), mobileMboName);
/* 2395:2406 */       if (mboInfo != null) {
/* 2396:2408 */         if (mboInfo.getParent() == null) {
/* 2397:2412 */           if (((mboInfo.isWorkset()) || (mboInfo.isLocalWorksetUpload())) && 
/* 2398:2413 */             (curApp.getMobileMboErrorCount(mobileMboName) > 0))
/* 2399:     */           {
/* 2400:2414 */             hasErrors = true;
/* 2401:2415 */             break;
/* 2402:     */           }
/* 2403:     */         }
/* 2404:     */       }
/* 2405:     */     }
/* 2406:2422 */     if (hasErrors) {
/* 2407:2423 */       callingControl.setVisibility(true);
/* 2408:     */     } else {
/* 2409:2425 */       callingControl.setVisibility(false);
/* 2410:     */     }
/* 2411:2428 */     return true;
/* 2412:     */   }
/* 2413:     */   
/* 2414:     */   private ArrayList getChildMobileMbos(AbstractMobileControl control)
/* 2415:     */   {
/* 2416:2432 */     ArrayList result = new ArrayList();
/* 2417:     */     
/* 2418:2434 */     Iterator children = control.getChildren();
/* 2419:2435 */     if (children == null) {
/* 2420:2436 */       return result;
/* 2421:     */     }
/* 2422:2438 */     while (children.hasNext())
/* 2423:     */     {
/* 2424:2439 */       AbstractMobileControl child = (AbstractMobileControl)children.next();
/* 2425:2440 */       if ((child instanceof LinkControl))
/* 2426:     */       {
/* 2427:2441 */         String mobilembo = child.getStringValue("mobilembo");
/* 2428:2442 */         result.add(mobilembo);
/* 2429:     */       }
/* 2430:     */       else
/* 2431:     */       {
/* 2432:2445 */         result.addAll(getChildMobileMbos(child));
/* 2433:     */       }
/* 2434:     */     }
/* 2435:2449 */     return result;
/* 2436:     */   }
/* 2437:     */   
/* 2438:     */   public boolean displayFontImageSize(UIEvent event)
/* 2439:     */     throws MobileApplicationException
/* 2440:     */   {
/* 2441:2454 */     MobileDeviceAppSession deviceAppSession = MobileDeviceAppSession.getSession();
/* 2442:2455 */     BasicMobileDeviceUIApplication app = deviceAppSession.getApplicationAsUIApplication();
/* 2443:     */     
/* 2444:2457 */     AbstractMobileControl callingControl = (AbstractMobileControl)event.getCreatingObject();
/* 2445:2459 */     if (app.getMobileUIManager().supportFontImageSizeConfiguration())
/* 2446:     */     {
/* 2447:2460 */       if (UIUtil.getApplication().isSigOption("MODIFYSIZE")) {
/* 2448:2461 */         callingControl.setVisibility(true);
/* 2449:     */       } else {
/* 2450:2463 */         callingControl.setVisibility(false);
/* 2451:     */       }
/* 2452:     */     }
/* 2453:     */     else {
/* 2454:2466 */       callingControl.setVisibility(false);
/* 2455:     */     }
/* 2456:2469 */     return true;
/* 2457:     */   }
/* 2458:     */   
/* 2459:     */   public boolean checkForUpdate(UIEvent event, boolean force, boolean syncCheck, boolean login)
/* 2460:     */     throws MobileApplicationException
/* 2461:     */   {
/* 2462:2485 */     return checkForUpdate(event, force, syncCheck, login, null);
/* 2463:     */   }
/* 2464:     */   
/* 2465:     */   public boolean checkForUpdate(UIEvent event, boolean force, boolean syncCheck, boolean login, String refreshEvent)
/* 2466:     */     throws MobileApplicationException
/* 2467:     */   {
/* 2468:2491 */     MobileDeviceAppSession deviceAppSession = MobileDeviceAppSession.getSession();
/* 2469:2492 */     BasicMobileDeviceUIApplication app = deviceAppSession.getApplicationAsUIApplication();
/* 2470:     */     
/* 2471:2494 */     boolean checkUpdateAllowed = true;
/* 2472:2496 */     if ((!force) && 
/* 2473:2497 */       (!app.isOptionAuthorized("CHECKUPDATE")))
/* 2474:     */     {
/* 2475:2499 */       checkUpdateAllowed = false;
/* 2476:2500 */       this.updateChecked = true;
/* 2477:     */     }
/* 2478:2504 */     if ((syncCheck) && (!this.updateChecked) && (checkUpdateAllowed)) {
/* 2479:2505 */       switch (event.getThreadStatus())
/* 2480:     */       {
/* 2481:     */       case -1: 
/* 2482:2507 */         UIUtil.startWorkerThread(this, event);
/* 2483:2508 */         break;
/* 2484:     */       case 1: 
/* 2485:2511 */         String message = MobileMessageGenerator.generate("updatechecking", null);
/* 2486:2512 */         event.getProgressObserver().setWorkProgressMessage(message);
/* 2487:2513 */         app.getUpdateStatus(!login, true);
/* 2488:2514 */         break;
/* 2489:     */       case 2: 
/* 2490:2517 */         this.updateChecked = true;
/* 2491:2518 */         if (login) {
/* 2492:2519 */           return UIUtil.handleEvent("checkForUpdateLogin");
/* 2493:     */         }
/* 2494:2521 */         return UIUtil.handleEvent(event.getEventName());
/* 2495:     */       case 0: 
/* 2496:     */         break;
/* 2497:     */       case 3: 
/* 2498:2527 */         UIUtil.showExceptionMessage(event.getException(), null, 0);
/* 2499:     */       }
/* 2500:     */     }
/* 2501:2532 */     if ((!syncCheck) || (this.updateChecked) || (!checkUpdateAllowed)) {
/* 2502:2533 */       switch (event.getThreadStatus())
/* 2503:     */       {
/* 2504:     */       case -1: 
/* 2505:2536 */         int updateStatus = 0;
/* 2506:     */         
/* 2507:2538 */         String updateStatusStr = app.getAppSetting("_UPDATEAVAILABLE");
/* 2508:2539 */         if ((updateStatusStr != null) && (!"".equals(updateStatusStr))) {
/* 2509:2540 */           updateStatus = Integer.parseInt(app.getAppSetting("_UPDATEAVAILABLE"));
/* 2510:     */         }
/* 2511:2542 */         checkUpdateOptions(event, false, updateStatus);
/* 2512:2544 */         if (updateStatus == 0)
/* 2513:     */         {
/* 2514:2552 */           if (refreshEvent != null) {
/* 2515:2553 */             UIUtil.handleEvent(refreshEvent);
/* 2516:     */           }
/* 2517:2556 */           this.updateChecked = false;
/* 2518:2557 */           if (login) {
/* 2519:2558 */             UIUtil.handleEvent("finalizeLogin");
/* 2520:     */           }
/* 2521:     */         }
/* 2522:     */         break;
/* 2523:     */       case 1: 
/* 2524:2564 */         startUpdateProcess(event);
/* 2525:2565 */         break;
/* 2526:     */       case 2: 
/* 2527:2568 */         completeUpdateProcess(event);
/* 2528:2569 */         break;
/* 2529:     */       case 0: 
/* 2530:2572 */         this.updateChecked = false;
/* 2531:2573 */         break;
/* 2532:     */       case 3: 
/* 2533:2575 */         this.updateChecked = false;
/* 2534:2576 */         UIUtil.showExceptionMessage(event.getException(), null, 0);
/* 2535:     */       }
/* 2536:     */     }
/* 2537:2581 */     return true;
/* 2538:     */   }
/* 2539:     */   
/* 2540:     */   public boolean updateCheking(UIEvent event)
/* 2541:     */     throws MobileApplicationException
/* 2542:     */   {
/* 2543:2586 */     MobileDeviceAppSession deviceAppSession = MobileDeviceAppSession.getSession();
/* 2544:2587 */     BasicMobileDeviceUIApplication app = deviceAppSession.getApplicationAsUIApplication();
/* 2545:2589 */     switch (event.getThreadStatus())
/* 2546:     */     {
/* 2547:     */     case -1: 
/* 2548:2591 */       UIUtil.startWorkerThread(this, event);
/* 2549:2592 */       break;
/* 2550:     */     case 1: 
/* 2551:2595 */       String message = MobileMessageGenerator.generate("updatechecking", null);
/* 2552:2596 */       event.getProgressObserver().setWorkProgressMessage(message);
/* 2553:2597 */       app.getUpdateStatus(true, false);
/* 2554:2598 */       break;
/* 2555:     */     case 2: 
/* 2556:     */       break;
/* 2557:     */     case 0: 
/* 2558:     */       break;
/* 2559:     */     case 3: 
/* 2560:2606 */       UIUtil.showExceptionMessage(event.getException(), null, 0);
/* 2561:     */     }
/* 2562:2610 */     return true;
/* 2563:     */   }
/* 2564:     */   
/* 2565:     */   public boolean checkForUpdateInRefresh(UIEvent event)
/* 2566:     */   {
/* 2567:2615 */     BasicMobileDeviceApplication app = UIUtil.getApplication();
/* 2568:2616 */     String checkDataRefresh = app.getProperty("MOBILECDC.UPDATEDATEREFRESH");
/* 2569:2617 */     if ((checkDataRefresh != null) && (!"".equals(checkDataRefresh)))
/* 2570:     */     {
/* 2571:2618 */       boolean check = "1".equals(checkDataRefresh);
/* 2572:2619 */       if ((check) && (!this.updateRefreshChecking))
/* 2573:     */       {
/* 2574:2620 */         this.updateRefreshChecking = true;
/* 2575:2621 */         UIUtil.handleEvent("checkForUpdate?" + event.getEventName());
/* 2576:2622 */         return true;
/* 2577:     */       }
/* 2578:     */     }
/* 2579:2625 */     return false;
/* 2580:     */   }
/* 2581:     */   
/* 2582:     */   private boolean checkUpdateOptions(UIEvent event, boolean force, int updateStatus)
/* 2583:     */     throws MobileApplicationException
/* 2584:     */   {
/* 2585:2630 */     boolean processDownload = false;
/* 2586:     */     
/* 2587:2632 */     MobileDeviceAppSession deviceAppSession = MobileDeviceAppSession.getSession();
/* 2588:2633 */     BasicMobileDeviceUIApplication app = deviceAppSession.getApplicationAsUIApplication();
/* 2589:2635 */     if (updateStatus == 1)
/* 2590:     */     {
/* 2591:2636 */       UIUtil.refreshCurrentScreen();
/* 2592:2637 */       if (app.countRecordsModified() > 0)
/* 2593:     */       {
/* 2594:2639 */         if (!force)
/* 2595:     */         {
/* 2596:2640 */           if (event.getMsgResponse().equals("-1"))
/* 2597:     */           {
/* 2598:2642 */             String message = MobileMessageGenerator.generate("updateavialablerefresh", null);
/* 2599:2643 */             UIUtil.showMessageBox(message, "question", 12, event);
/* 2600:2644 */             event.setEventErrored();
/* 2601:2645 */             return true;
/* 2602:     */           }
/* 2603:2647 */           if (event.getMsgResponse().equals("1"))
/* 2604:     */           {
/* 2605:2650 */             app.doneAllRecordsModified();
/* 2606:2651 */             processDownload = true;
/* 2607:     */           }
/* 2608:     */           else
/* 2609:     */           {
/* 2610:2653 */             this.updateRefreshChecking = false;
/* 2611:     */           }
/* 2612:     */         }
/* 2613:     */       }
/* 2614:2659 */       else if (!force)
/* 2615:     */       {
/* 2616:2660 */         if (event.getMsgResponse().equals("-1"))
/* 2617:     */         {
/* 2618:2662 */           String message = MobileMessageGenerator.generate("updateavialablenow", null);
/* 2619:2663 */           UIUtil.showMessageBox(message, "question", 12, event);
/* 2620:2664 */           event.setEventErrored();
/* 2621:2665 */           return true;
/* 2622:     */         }
/* 2623:2668 */         if (event.getMsgResponse().equals("1")) {
/* 2624:2669 */           processDownload = true;
/* 2625:     */         } else {
/* 2626:2671 */           this.updateRefreshChecking = false;
/* 2627:     */         }
/* 2628:     */       }
/* 2629:     */       else
/* 2630:     */       {
/* 2631:2675 */         if (event.getMsgResponse().equals("-1"))
/* 2632:     */         {
/* 2633:2677 */           String message = MobileMessageGenerator.generate("updateavialablenowforce", null);
/* 2634:2678 */           UIUtil.showMessageBox(message, "question", 1, event);
/* 2635:2679 */           event.setEventErrored();
/* 2636:2680 */           return true;
/* 2637:     */         }
/* 2638:2683 */         if (event.getMsgResponse().equals("1")) {
/* 2639:2684 */           processDownload = true;
/* 2640:     */         } else {
/* 2641:2686 */           this.updateRefreshChecking = false;
/* 2642:     */         }
/* 2643:     */       }
/* 2644:2693 */       if (processDownload)
/* 2645:     */       {
/* 2646:2694 */         processDownload = false;
/* 2647:2695 */         event.setMsgResponse("-1");
/* 2648:2696 */         UIUtil.startWorkerThread(this, event);
/* 2649:     */       }
/* 2650:     */       else
/* 2651:     */       {
/* 2652:2699 */         this.updateChecked = false;
/* 2653:2700 */         this.updateRefreshChecking = false;
/* 2654:     */       }
/* 2655:2702 */       return true;
/* 2656:     */     }
/* 2657:2704 */     return true;
/* 2658:     */   }
/* 2659:     */   
/* 2660:     */   private void startUpdateProcess(UIEvent event)
/* 2661:     */     throws MobileApplicationException
/* 2662:     */   {
/* 2663:2709 */     MobileDeviceAppSession deviceAppSession = MobileDeviceAppSession.getSession();
/* 2664:2710 */     BasicMobileDeviceUIApplication app = deviceAppSession.getApplicationAsUIApplication();
/* 2665:     */     
/* 2666:2712 */     event.getProgressObserver().updateWorkProgress();
/* 2667:2713 */     String msg = MobileMessageGenerator.generate("updatederunning", null);
/* 2668:2714 */     event.getProgressObserver().setWorkProgressMessage(msg);
/* 2669:2715 */     event.getProgressObserver().updateWorkProgress();
/* 2670:2716 */     app.downloadUpdateFile();
/* 2671:     */   }
/* 2672:     */   
/* 2673:     */   private void completeUpdateProcess(UIEvent event)
/* 2674:     */     throws MobileApplicationException
/* 2675:     */   {
/* 2676:2720 */     MobileDeviceAppSession deviceAppSession = MobileDeviceAppSession.getSession();
/* 2677:2721 */     BasicMobileDeviceUIApplication app = deviceAppSession.getApplicationAsUIApplication();
/* 2678:2722 */     app.getSoftwareUpdateHelper().completeUpdateProcess(event);
/* 2679:     */   }
/* 2680:     */   
/* 2681:     */   public boolean hasUpdate(UIEvent event)
/* 2682:     */     throws MobileApplicationException
/* 2683:     */   {
/* 2684:2728 */     BasicMobileDeviceApplication app = UIUtil.getApplication();
/* 2685:2729 */     AbstractMobileControl control = (AbstractMobileControl)event.getCreatingObject();
/* 2686:2730 */     control.setVisibility(false);
/* 2687:2731 */     int updateStatus = app.getUpdateStatus(false, false);
/* 2688:2732 */     if (updateStatus != 0) {
/* 2689:2733 */       control.setVisibility(true);
/* 2690:     */     }
/* 2691:2736 */     return true;
/* 2692:     */   }
/* 2693:     */   
/* 2694:     */   public boolean finalizeLogin(UIEvent event)
/* 2695:     */   {
/* 2696:2741 */     MobileDeviceAppSession deviceAppSession = MobileDeviceAppSession.getSession();
/* 2697:2742 */     BasicMobileDeviceUIApplication app = deviceAppSession.getApplicationAsUIApplication();
/* 2698:2744 */     if (!app.isAllDataRefreshedOnce())
/* 2699:     */     {
/* 2700:2745 */       UIUtil.handleEvent("refreshalldataonce");
/* 2701:2746 */       return true;
/* 2702:     */     }
/* 2703:2749 */     if (app.isRefreshWorkListOnSignInEnabled())
/* 2704:     */     {
/* 2705:2750 */       UIUtil.handleEvent("refreshworksetnoprompt");
/* 2706:2751 */       return true;
/* 2707:     */     }
/* 2708:2753 */     return true;
/* 2709:     */   }
/* 2710:     */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.AppEventHandler
 * JD-Core Version:    0.7.0.1
 */