/*  1:   */ package com.mro.mobile.app;
/*  2:   */ 
/*  3:   */ import com.mro.mobile.MobileApplicationException;
/*  4:   */ import com.mro.mobile.app.async.AsyncEventHandlerSupport;
/*  5:   */ import com.mro.mobile.mbo.MobileMboDependencyManager;
/*  6:   */ import com.mro.mobile.ui.event.UIEvent;
/*  7:   */ import com.mro.mobile.ui.res.UIUtil;
/*  8:   */ 
/*  9:   */ public class AsyncMobileDependencyAllDone
/* 10:   */   extends AsyncEventHandlerSupport
/* 11:   */ {
/* 12:   */   public boolean doRealWok(UIEvent event)
/* 13:   */     throws MobileApplicationException
/* 14:   */   {
/* 15:26 */     super.updateProgressBar("submitdata", null, event);
/* 16:27 */     MobileMboDependencyManager.doneAllDependencies();
/* 17:28 */     return true;
/* 18:   */   }
/* 19:   */   
/* 20:   */   public void postRealWork(UIEvent event)
/* 21:   */     throws MobileApplicationException
/* 22:   */   {}
/* 23:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.AsyncMobileDependencyAllDone
 * JD-Core Version:    0.7.0.1
 */