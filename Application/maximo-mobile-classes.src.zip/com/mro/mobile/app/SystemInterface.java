package com.mro.mobile.app;

public abstract interface SystemInterface
{
  public abstract void exitSystem();
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.SystemInterface
 * JD-Core Version:    0.7.0.1
 */