package com.mro.mobile.app.async;

public abstract interface AsynchronousExecutor
{
  public abstract void scheduleForAsyncExecution(Runnable paramRunnable);
  
  public abstract Thread start(Runnable paramRunnable);
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.async.AsynchronousExecutor
 * JD-Core Version:    0.7.0.1
 */