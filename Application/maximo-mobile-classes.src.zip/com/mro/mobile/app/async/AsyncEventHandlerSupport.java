/*   1:    */ package com.mro.mobile.app.async;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.MobileMessageGenerator;
/*   5:    */ import com.mro.mobile.ProgressObserver;
/*   6:    */ import com.mro.mobile.app.DefaultEventHandler;
/*   7:    */ import com.mro.mobile.ui.MobileMboDataBean;
/*   8:    */ import com.mro.mobile.ui.event.UIEvent;
/*   9:    */ import com.mro.mobile.ui.res.UIUtil;
/*  10:    */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*  11:    */ 
/*  12:    */ public abstract class AsyncEventHandlerSupport
/*  13:    */   extends DefaultEventHandler
/*  14:    */   implements AsyncEventHandlerDef
/*  15:    */ {
/*  16:    */   private Object result;
/*  17:    */   
/*  18:    */   protected boolean callback(UIEvent event)
/*  19:    */     throws MobileApplicationException
/*  20:    */   {
/*  21: 31 */     switch (event.getThreadStatus())
/*  22:    */     {
/*  23:    */     case 1: 
/*  24: 33 */       doRealWok(event);
/*  25: 34 */       break;
/*  26:    */     case 2: 
/*  27: 37 */       postRealWork(event);
/*  28: 38 */       break;
/*  29:    */     case 0: 
/*  30: 41 */       realWorkStopped(event);
/*  31: 42 */       break;
/*  32:    */     case 3: 
/*  33: 45 */       realWorkFailed(event);
/*  34: 46 */       break;
/*  35:    */     }
/*  36: 51 */     return true;
/*  37:    */   }
/*  38:    */   
/*  39:    */   protected void realWorkFailed(UIEvent event)
/*  40:    */     throws MobileApplicationException
/*  41:    */   {
/*  42: 55 */     UIUtil.refreshCurrentScreen();
/*  43: 56 */     UIUtil.showExceptionMessage(event.getException(), null, 0);
/*  44:    */   }
/*  45:    */   
/*  46:    */   protected void realWorkStopped(UIEvent event)
/*  47:    */     throws MobileApplicationException
/*  48:    */   {}
/*  49:    */   
/*  50:    */   public abstract boolean doRealWok(UIEvent paramUIEvent)
/*  51:    */     throws MobileApplicationException;
/*  52:    */   
/*  53:    */   public void postRealWork(UIEvent event)
/*  54:    */     throws MobileApplicationException
/*  55:    */   {}
/*  56:    */   
/*  57:    */   public boolean performEvent(UIEvent event)
/*  58:    */     throws MobileApplicationException
/*  59:    */   {
/*  60: 89 */     return callback(event);
/*  61:    */   }
/*  62:    */   
/*  63:    */   public void handleInBackground(UIEvent event)
/*  64:    */     throws MobileApplicationException
/*  65:    */   {
/*  66: 93 */     if (event.getThreadStatus() != 1) {
/*  67: 94 */       UIUtil.startWorkerThread(this, event);
/*  68:    */     }
/*  69:    */   }
/*  70:    */   
/*  71:    */   public MobileMboDataBean getDataBeanOf(UIEvent event)
/*  72:    */     throws MobileApplicationException
/*  73:    */   {
/*  74: 99 */     AbstractMobileControl control = (AbstractMobileControl)event.getCreatingObject();
/*  75:100 */     return control != null ? control.getDataBean() : null;
/*  76:    */   }
/*  77:    */   
/*  78:    */   public AbstractMobileControl getUIControlOf(UIEvent event)
/*  79:    */     throws MobileApplicationException
/*  80:    */   {
/*  81:104 */     return (AbstractMobileControl)event.getCreatingObject();
/*  82:    */   }
/*  83:    */   
/*  84:    */   public MobileMboDataBean getDataBeanOfCurrentScreen()
/*  85:    */     throws MobileApplicationException
/*  86:    */   {
/*  87:108 */     return UIUtil.getCurrentScreen().getDataBean();
/*  88:    */   }
/*  89:    */   
/*  90:    */   protected void updateProgressBar(String progressbarMsgId, Object[] params, UIEvent event)
/*  91:    */   {
/*  92:112 */     ProgressObserver progress = event.getProgressObserver();
/*  93:113 */     if (progress != null)
/*  94:    */     {
/*  95:114 */       progress.setWorkProgressMessage(MobileMessageGenerator.generate(progressbarMsgId, params));
/*  96:115 */       progress.updateWorkProgress();
/*  97:116 */       progress.updateWorkProgress();
/*  98:    */     }
/*  99:    */   }
/* 100:    */   
/* 101:    */   public void setProcessReturnResult(Object result)
/* 102:    */   {
/* 103:122 */     this.result = result;
/* 104:    */   }
/* 105:    */   
/* 106:    */   public Object getProcessReturnResultOrNull()
/* 107:    */   {
/* 108:126 */     return this.result;
/* 109:    */   }
/* 110:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.async.AsyncEventHandlerSupport
 * JD-Core Version:    0.7.0.1
 */