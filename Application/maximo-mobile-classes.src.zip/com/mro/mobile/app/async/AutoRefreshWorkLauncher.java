/*  1:   */ package com.mro.mobile.app.async;
/*  2:   */ 
/*  3:   */ import com.mro.mobile.app.AppEventHandler;
/*  4:   */ import com.mro.mobile.app.BasicMobileDeviceUIApplication;
/*  5:   */ import com.mro.mobile.app.MobileDeviceAppSession;
/*  6:   */ import com.mro.mobile.ui.res.UIUtil;
/*  7:   */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*  8:   */ import com.mro.mobile.util.MobileLogger;
/*  9:   */ import com.mro.mobile.util.MobileLoggerFactory;
/* 10:   */ 
/* 11:   */ public class AutoRefreshWorkLauncher
/* 12:   */   extends BackgroundWorkLauncher
/* 13:   */ {
/* 14:   */   public AutoRefreshWorkLauncher(AsynchronousExecutor executor)
/* 15:   */   {
/* 16:24 */     super(executor);
/* 17:   */   }
/* 18:   */   
/* 19:   */   protected boolean canDoWork()
/* 20:   */   {
/* 21:28 */     return currentPageAllowsAutoRefresh();
/* 22:   */   }
/* 23:   */   
/* 24:   */   protected void doWork()
/* 25:   */   {
/* 26:32 */     if (currentPageAllowsAutoRefresh()) {
/* 27:33 */       launchBackgroundWork(new AutoRefreshWorkInternalBehavior(this));
/* 28:   */     }
/* 29:   */   }
/* 30:   */   
/* 31:   */   protected boolean currentPageAllowsAutoRefresh()
/* 32:   */   {
/* 33:38 */     AbstractMobileControl currentPage = UIUtil.getCurrentScreen();
/* 34:39 */     String currentScreenId = currentPage.getId();
/* 35:40 */     String startupScreenId = UIUtil.getApplication().getStartupScreenId();
/* 36:41 */     return (currentPage.getBooleanValue("autorefresh")) || (currentScreenId.equalsIgnoreCase(startupScreenId));
/* 37:   */   }
/* 38:   */   
/* 39:   */   static class AutoRefreshWorkInternalBehavior
/* 40:   */     implements Runnable
/* 41:   */   {
/* 42:45 */     private AutoRefreshWorkLauncher parent = null;
/* 43:   */     
/* 44:   */     public AutoRefreshWorkInternalBehavior(AutoRefreshWorkLauncher parent)
/* 45:   */     {
/* 46:48 */       this.parent = parent;
/* 47:   */     }
/* 48:   */     
/* 49:   */     public void run()
/* 50:   */     {
/* 51:   */       try
/* 52:   */       {
/* 53:53 */         MobileDeviceAppSession.getSession().getUIEventHandlerAsAppEventHandler().performEvent("refreshworksetnoprompt");
/* 54:   */       }
/* 55:   */       catch (Exception e)
/* 56:   */       {
/* 57:55 */         MobileLoggerFactory.getDefaultLogger().warn("Error encountered in AutoRefreshWorkInternalBehaviour thread", e);
/* 58:   */       }
/* 59:   */       finally
/* 60:   */       {
/* 61:57 */         this.parent.reset();
/* 62:   */       }
/* 63:   */     }
/* 64:   */   }
/* 65:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.async.AutoRefreshWorkLauncher
 * JD-Core Version:    0.7.0.1
 */