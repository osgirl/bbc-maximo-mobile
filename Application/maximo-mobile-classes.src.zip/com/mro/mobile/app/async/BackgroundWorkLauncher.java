/*   1:    */ package com.mro.mobile.app.async;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.util.MobileLogger;
/*   4:    */ import com.mro.mobile.util.MobileLoggerFactory;
/*   5:    */ 
/*   6:    */ public abstract class BackgroundWorkLauncher
/*   7:    */   implements Runnable
/*   8:    */ {
/*   9:    */   private static final long WAITTIME_IN_MILLIS = 15000L;
/*  10:    */   private static final long MINUTE_IN_MILLIS = 60000L;
/*  11: 37 */   private boolean inProgress = false;
/*  12: 38 */   private boolean autoRefresh = false;
/*  13: 39 */   private long intervalInMillis = 0L;
/*  14: 40 */   private long timer = 0L;
/*  15:    */   private AsynchronousExecutor executor;
/*  16:    */   
/*  17:    */   public BackgroundWorkLauncher(AsynchronousExecutor executor)
/*  18:    */   {
/*  19: 44 */     this.executor = executor;
/*  20:    */   }
/*  21:    */   
/*  22:    */   protected abstract void doWork();
/*  23:    */   
/*  24:    */   protected abstract boolean canDoWork();
/*  25:    */   
/*  26:    */   public void run()
/*  27:    */   {
/*  28:    */     try
/*  29:    */     {
/*  30: 53 */       reset();
/*  31:    */       for (;;)
/*  32:    */       {
/*  33: 55 */         if (this.autoRefresh)
/*  34:    */         {
/*  35: 56 */           long curTime = System.currentTimeMillis();
/*  36: 57 */           if (curTime - this.timer > this.intervalInMillis)
/*  37:    */           {
/*  38: 58 */             if ((canDoWork()) && (!this.inProgress))
/*  39:    */             {
/*  40: 59 */               this.inProgress = true;
/*  41: 60 */               doWork();
/*  42:    */             }
/*  43:    */             else
/*  44:    */             {
/*  45: 62 */               synchronized (this)
/*  46:    */               {
/*  47: 63 */                 waitRefreshToBeEnabled();
/*  48:    */               }
/*  49:    */             }
/*  50:    */           }
/*  51:    */           else {
/*  52: 67 */             synchronized (this)
/*  53:    */             {
/*  54: 68 */               waitRefreshToBeEnabled();
/*  55:    */             }
/*  56:    */           }
/*  57:    */         }
/*  58:    */         else
/*  59:    */         {
/*  60: 72 */           synchronized (this)
/*  61:    */           {
/*  62: 73 */             wait();
/*  63:    */           }
/*  64:    */         }
/*  65:    */       }
/*  66:    */     }
/*  67:    */     catch (Exception e)
/*  68:    */     {
/*  69: 78 */       MobileLoggerFactory.getDefaultLogger().warn("Error encountered in BackgroundWorkLauncher thread", e);
/*  70:    */     }
/*  71:    */   }
/*  72:    */   
/*  73:    */   protected void waitRefreshToBeEnabled()
/*  74:    */     throws InterruptedException
/*  75:    */   {
/*  76: 83 */     wait(15000L);
/*  77:    */   }
/*  78:    */   
/*  79:    */   public synchronized void reset()
/*  80:    */   {
/*  81: 88 */     this.timer = System.currentTimeMillis();
/*  82: 89 */     this.inProgress = false;
/*  83:    */   }
/*  84:    */   
/*  85:    */   public void reset(boolean autoRefresh, int interval)
/*  86:    */   {
/*  87: 93 */     init(autoRefresh, interval);
/*  88: 94 */     synchronized (this)
/*  89:    */     {
/*  90: 95 */       notify();
/*  91:    */     }
/*  92:    */   }
/*  93:    */   
/*  94:    */   public void init(boolean autoRefresh, int interval)
/*  95:    */   {
/*  96:100 */     this.autoRefresh = autoRefresh;
/*  97:101 */     if (interval <= 0) {
/*  98:102 */       this.autoRefresh = false;
/*  99:    */     }
/* 100:104 */     this.intervalInMillis = (interval * 60000L);
/* 101:    */     
/* 102:106 */     this.timer = System.currentTimeMillis();
/* 103:107 */     this.inProgress = false;
/* 104:    */   }
/* 105:    */   
/* 106:    */   public void launchBackgroundWork(Runnable task)
/* 107:    */   {
/* 108:111 */     this.executor.scheduleForAsyncExecution(task);
/* 109:    */   }
/* 110:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.async.BackgroundWorkLauncher
 * JD-Core Version:    0.7.0.1
 */