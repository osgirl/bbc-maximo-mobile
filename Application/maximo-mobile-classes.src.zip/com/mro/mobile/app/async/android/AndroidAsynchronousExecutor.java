/*  1:   */ package com.mro.mobile.app.async.android;
/*  2:   */ 
/*  3:   */ import com.ibm.tivoli.maximo.mobile.entrypoint.android.UiThreadRunner;
/*  4:   */ import com.mro.mobile.app.async.AsynchronousExecutor;
/*  5:   */ 
/*  6:   */ public class AndroidAsynchronousExecutor
/*  7:   */   implements AsynchronousExecutor
/*  8:   */ {
/*  9: 8 */   private UiThreadRunner runner = null;
/* 10:   */   
/* 11:   */   public AndroidAsynchronousExecutor(UiThreadRunner runner)
/* 12:   */   {
/* 13:11 */     this.runner = runner;
/* 14:   */   }
/* 15:   */   
/* 16:   */   public void scheduleForAsyncExecution(Runnable task)
/* 17:   */   {
/* 18:16 */     this.runner.runOnUiThread(task);
/* 19:   */   }
/* 20:   */   
/* 21:   */   public Thread start(Runnable task)
/* 22:   */   {
/* 23:20 */     Thread t = new Thread(task);
/* 24:21 */     t.start();
/* 25:22 */     return t;
/* 26:   */   }
/* 27:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.async.android.AndroidAsynchronousExecutor
 * JD-Core Version:    0.7.0.1
 */