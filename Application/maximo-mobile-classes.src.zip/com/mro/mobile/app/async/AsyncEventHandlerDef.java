package com.mro.mobile.app.async;

import com.mro.mobile.MobileApplicationException;
import com.mro.mobile.ui.event.UIEvent;

public abstract interface AsyncEventHandlerDef
{
  public abstract void handleInBackground(UIEvent paramUIEvent)
    throws MobileApplicationException;
  
  public abstract boolean doRealWok(UIEvent paramUIEvent)
    throws MobileApplicationException;
  
  public abstract void postRealWork(UIEvent paramUIEvent)
    throws MobileApplicationException;
  
  public abstract Object getProcessReturnResultOrNull();
  
  public abstract void setProcessReturnResult(Object paramObject);
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.async.AsyncEventHandlerDef
 * JD-Core Version:    0.7.0.1
 */