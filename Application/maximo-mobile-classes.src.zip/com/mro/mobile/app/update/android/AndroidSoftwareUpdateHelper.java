/*   1:    */ package com.mro.mobile.app.update.android;
/*   2:    */ 
/*   3:    */ import android.app.Activity;
/*   4:    */ import android.content.Intent;
/*   5:    */ import android.net.Uri;
/*   6:    */ import android.os.Environment;
/*   7:    */ import com.mro.mobile.MobileApplicationException;
/*   8:    */ import com.mro.mobile.app.BasicMobileDeviceApplication;
/*   9:    */ import com.mro.mobile.app.BasicMobileDeviceUIApplication;
/*  10:    */ import com.mro.mobile.app.MobileSoftwareUpdateHelper;
/*  11:    */ import com.mro.mobile.app.SystemInterface;
/*  12:    */ import com.mro.mobile.ui.event.UIEvent;
/*  13:    */ import com.mro.mobile.ui.res.UIUtil;
/*  14:    */ import com.mro.mobile.ui.res.widgets.android.AndroidEnv;
/*  15:    */ import com.mro.mobile.util.MobileLogger;
/*  16:    */ import java.io.File;
/*  17:    */ import java.io.FileFilter;
/*  18:    */ 
/*  19:    */ public class AndroidSoftwareUpdateHelper
/*  20:    */   extends MobileSoftwareUpdateHelper
/*  21:    */ {
/*  22: 37 */   private File location = null;
/*  23: 39 */   private File savedApk = null;
/*  24: 41 */   private String appName = null;
/*  25: 43 */   private MobileLogger logger = null;
/*  26:    */   
/*  27:    */   public AndroidSoftwareUpdateHelper(BasicMobileDeviceApplication application, String packageName, MobileLogger logger)
/*  28:    */   {
/*  29: 49 */     super(application);
/*  30: 50 */     this.appName = getApplicationName(packageName);
/*  31: 51 */     this.logger = logger;
/*  32:    */   }
/*  33:    */   
/*  34:    */   public File getAppJarOrApkFileLocationToSaveDownloadedFile()
/*  35:    */     throws MobileApplicationException
/*  36:    */   {
/*  37: 62 */     if (this.location == null)
/*  38:    */     {
/*  39: 63 */       String directoryName = null;
/*  40: 64 */       if (this.appName.equalsIgnoreCase("mobileinst")) {
/*  41: 65 */         directoryName = Environment.getExternalStorageDirectory().getAbsolutePath() + "/maximomobile-installer/updateapks";
/*  42:    */       } else {
/*  43: 67 */         directoryName = Environment.getExternalStorageDirectory().getAbsolutePath() + "/maximomobile/updateapks";
/*  44:    */       }
/*  45: 69 */       String fileName = this.appName + "_" + System.currentTimeMillis() + ".apk";
/*  46: 71 */       if (isExternalStorageWritable())
/*  47:    */       {
/*  48: 72 */         this.location = new File(directoryName);
/*  49:    */       }
/*  50:    */       else
/*  51:    */       {
/*  52: 75 */         MobileApplicationException ex = new MobileApplicationException("updatedeterminejarfailed", new Object[] { directoryName });
/*  53: 76 */         this.logger.error(ex.getCompleteMessage(), ex);
/*  54:    */       }
/*  55: 78 */       if (this.location != null)
/*  56:    */       {
/*  57: 79 */         if (!this.location.exists()) {
/*  58: 80 */           if (!this.location.mkdirs())
/*  59:    */           {
/*  60: 81 */             MobileApplicationException ex = new MobileApplicationException("updatedeterminejarfailed", new Object[] { this.location.getAbsolutePath() });
/*  61: 82 */             this.logger.error(ex.getCompleteMessage(), ex);
/*  62:    */           }
/*  63:    */           else
/*  64:    */           {
/*  65: 84 */             this.location = new File(this.location, fileName);
/*  66:    */           }
/*  67:    */         }
/*  68: 87 */         cleanUpApksFromLocation();
/*  69:    */       }
/*  70:    */     }
/*  71: 91 */     return this.location;
/*  72:    */   }
/*  73:    */   
/*  74:    */   private void cleanUpApksFromLocation()
/*  75:    */   {
/*  76: 95 */     File[] files = this.location.getParentFile().listFiles(new FileFilter()
/*  77:    */     {
/*  78:    */       public boolean accept(File pathname)
/*  79:    */       {
/*  80: 98 */         return pathname.getAbsolutePath().endsWith("apk");
/*  81:    */       }
/*  82:    */     });
/*  83:101 */     if (files == null) {
/*  84:102 */       return;
/*  85:    */     }
/*  86:104 */     for (int i = 0; i < files.length; i++)
/*  87:    */     {
/*  88:105 */       File f = files[i];
/*  89:106 */       if (!f.isDirectory()) {
/*  90:107 */         f.delete();
/*  91:    */       }
/*  92:    */     }
/*  93:    */   }
/*  94:    */   
/*  95:    */   protected boolean isExternalStorageWritable()
/*  96:    */   {
/*  97:113 */     return "mounted".equals(Environment.getExternalStorageState());
/*  98:    */   }
/*  99:    */   
/* 100:    */   public void postDownloadUpdateFile(File file)
/* 101:    */     throws MobileApplicationException
/* 102:    */   {
/* 103:125 */     this.savedApk = file;
/* 104:    */   }
/* 105:    */   
/* 106:    */   protected void installNewApk(File apk)
/* 107:    */   {
/* 108:129 */     Intent intent = new Intent("android.intent.action.VIEW");
/* 109:130 */     intent.setDataAndType(Uri.fromFile(apk), "application/vnd.android.package-archive");
/* 110:131 */     AndroidEnv.getCurrentActivity().startActivity(intent);
/* 111:    */     
/* 112:133 */     UIUtil.getApplication().getSystemInterface().exitSystem();
/* 113:    */   }
/* 114:    */   
/* 115:    */   public void completeUpdateProcess(UIEvent event)
/* 116:    */     throws MobileApplicationException
/* 117:    */   {
/* 118:138 */     installNewApk(this.savedApk);
/* 119:    */   }
/* 120:    */   
/* 121:    */   public String newFullNameForDownloadedFile(File reference)
/* 122:    */   {
/* 123:144 */     return reference.getAbsolutePath();
/* 124:    */   }
/* 125:    */   
/* 126:    */   private String getApplicationName(String packageName)
/* 127:    */   {
/* 128:148 */     if (packageName == null) {
/* 129:149 */       return "anApplication";
/* 130:    */     }
/* 131:151 */     int point = packageName.lastIndexOf(".");
/* 132:152 */     return point >= 0 ? packageName.substring(point + 1) : packageName;
/* 133:    */   }
/* 134:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.update.android.AndroidSoftwareUpdateHelper
 * JD-Core Version:    0.7.0.1
 */