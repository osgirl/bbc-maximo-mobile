/*   1:    */ package com.mro.mobile.app;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.comm.CommunicationChannel;
/*   5:    */ import com.mro.mobile.comm.Service;
/*   6:    */ import com.mro.mobile.mbo.MobileMbo;
/*   7:    */ import com.mro.mobile.mbo.MobileMboData;
/*   8:    */ import com.mro.mobile.mbo.MobileMboUpdate;
/*   9:    */ import com.mro.mobile.persist.DefaultQBE;
/*  10:    */ import com.mro.mobile.persist.RDO;
/*  11:    */ import com.mro.mobile.persist.RDOEnumeration;
/*  12:    */ import com.mro.mobile.persist.RDOException;
/*  13:    */ import com.mro.mobile.persist.RDOInfo;
/*  14:    */ import com.mro.mobile.persist.RDOInfoManager;
/*  15:    */ import com.mro.mobile.persist.RDOManager;
/*  16:    */ import com.mro.mobile.persist.RDORuntime;
/*  17:    */ import com.mro.mobile.persist.RDOTransactionManager;
/*  18:    */ import com.mro.mobile.util.MobileLogger;
/*  19:    */ import com.mro.mobile.util.MobileLoggerFactory;
/*  20:    */ import java.io.ByteArrayInputStream;
/*  21:    */ import java.io.IOException;
/*  22:    */ import java.io.ObjectInputStream;
/*  23:    */ import java.util.ArrayList;
/*  24:    */ import java.util.Enumeration;
/*  25:    */ import java.util.Iterator;
/*  26:    */ import java.util.List;
/*  27:    */ 
/*  28:    */ public class MobileDeviceAppService
/*  29:    */ {
/*  30: 43 */   private Service service = null;
/*  31: 44 */   private boolean processDataTxnOnce = false;
/*  32: 45 */   private boolean processedOnce = false;
/*  33: 46 */   private boolean enableProcessDataTxn = true;
/*  34:    */   
/*  35:    */   public MobileDeviceAppService(String appName)
/*  36:    */   {
/*  37: 51 */     this.service = new Service(appName);
/*  38:    */   }
/*  39:    */   
/*  40:    */   public void hello()
/*  41:    */     throws MobileApplicationException
/*  42:    */   {
/*  43: 56 */     this.service.invoke("hello", new Object[0]);
/*  44:    */   }
/*  45:    */   
/*  46:    */   public long getTimeDifference()
/*  47:    */     throws MobileApplicationException
/*  48:    */   {
/*  49: 66 */     long timeDifference = this.service.getTimeDifference();
/*  50: 67 */     return timeDifference;
/*  51:    */   }
/*  52:    */   
/*  53:    */   public boolean isServerAuthentication()
/*  54:    */     throws MobileApplicationException
/*  55:    */   {
/*  56: 73 */     return this.service.getAuthType();
/*  57:    */   }
/*  58:    */   
/*  59:    */   public void suspendProcessPendingRequests()
/*  60:    */   {
/*  61: 78 */     this.service.suspendProcessPendingRequests();
/*  62:    */   }
/*  63:    */   
/*  64:    */   public void resumeProcessPendingRequests()
/*  65:    */   {
/*  66: 83 */     this.service.resumeProcessPendingRequests();
/*  67:    */   }
/*  68:    */   
/*  69:    */   public void suspendUpdateLastCommunication()
/*  70:    */   {
/*  71: 88 */     this.service.suspendUpdateLastCommunication();
/*  72:    */   }
/*  73:    */   
/*  74:    */   public void resumeUpdateLastCommunication()
/*  75:    */   {
/*  76: 93 */     this.service.resumeUpdateLastCommunication();
/*  77:    */   }
/*  78:    */   
/*  79:    */   public Object invoke(String operationName, Object[] params)
/*  80:    */     throws MobileApplicationException
/*  81:    */   {
/*  82:100 */     processDataTransactionResult();
/*  83:    */     
/*  84:102 */     return this.service.invoke(operationName, params);
/*  85:    */   }
/*  86:    */   
/*  87:    */   public void invokeAsync(String operationName, Object[] params)
/*  88:    */     throws MobileApplicationException
/*  89:    */   {
/*  90:108 */     this.service.invokeAsync(operationName, params);
/*  91:    */   }
/*  92:    */   
/*  93:    */   public void invokeAsync(String operationName, Object[] params, String correlationId)
/*  94:    */     throws MobileApplicationException
/*  95:    */   {
/*  96:114 */     this.service.invokeAsync(operationName, params, correlationId);
/*  97:    */   }
/*  98:    */   
/*  99:    */   public void invokeAsyncWithAck(String operationName, Object[] params)
/* 100:    */     throws MobileApplicationException
/* 101:    */   {
/* 102:120 */     this.service.invokeAsyncWithAck(operationName, params);
/* 103:    */   }
/* 104:    */   
/* 105:    */   public void invokeAsyncWithAck(String operationName, Object[] params, String correlationId)
/* 106:    */     throws MobileApplicationException
/* 107:    */   {
/* 108:126 */     this.service.invokeAsyncWithAck(operationName, params, correlationId);
/* 109:    */   }
/* 110:    */   
/* 111:    */   public void invokeAsyncWithNoAck(String operationName, Object[] params)
/* 112:    */     throws MobileApplicationException
/* 113:    */   {
/* 114:132 */     this.service.invokeAsyncWithNoAck(operationName, params);
/* 115:    */   }
/* 116:    */   
/* 117:    */   public void invokeAsyncWithNoAck(String operationName, Object[] params, String correlationId)
/* 118:    */     throws MobileApplicationException
/* 119:    */   {
/* 120:138 */     this.service.invokeAsyncWithNoAck(operationName, params, correlationId);
/* 121:    */   }
/* 122:    */   
/* 123:    */   public void setProperty(String propertyName, String value)
/* 124:    */     throws MobileApplicationException
/* 125:    */   {
/* 126:144 */     this.service.setProperty(propertyName, value);
/* 127:    */   }
/* 128:    */   
/* 129:    */   public void setCommunicationChannel(CommunicationChannel communicationChannel)
/* 130:    */   {
/* 131:149 */     this.service.setCommunicationChannel(communicationChannel);
/* 132:    */   }
/* 133:    */   
/* 134:    */   public void processPendingRequests()
/* 135:    */     throws MobileApplicationException
/* 136:    */   {
/* 137:154 */     this.service.processPendingRequests();
/* 138:    */   }
/* 139:    */   
/* 140:    */   public boolean isBatchAsyncMode()
/* 141:    */   {
/* 142:159 */     return this.service.isBatchAsyncMode();
/* 143:    */   }
/* 144:    */   
/* 145:    */   public void setBatchAsyncMode(boolean enable)
/* 146:    */   {
/* 147:164 */     this.service.setBatchAsyncMode(enable);
/* 148:    */   }
/* 149:    */   
/* 150:    */   public void setProcessDataTransactionResultOnce()
/* 151:    */   {
/* 152:169 */     this.processDataTxnOnce = true;
/* 153:170 */     this.processedOnce = false;
/* 154:    */   }
/* 155:    */   
/* 156:    */   public void resetProcessDataTransactionResultOnce()
/* 157:    */   {
/* 158:175 */     this.processedOnce = false;
/* 159:176 */     this.processDataTxnOnce = false;
/* 160:    */   }
/* 161:    */   
/* 162:    */   public void enableProcessDataTxn(boolean enable)
/* 163:    */   {
/* 164:181 */     this.enableProcessDataTxn = enable;
/* 165:    */   }
/* 166:    */   
/* 167:    */   protected void processDataTransactionResult()
/* 168:    */     throws MobileApplicationException
/* 169:    */   {
/* 170:187 */     if (!this.enableProcessDataTxn) {
/* 171:189 */       return;
/* 172:    */     }
/* 173:192 */     int startIndex = 0;
/* 174:193 */     int size = 10;
/* 175:    */     
/* 176:195 */     MobileDeviceAppSession deviceAppSession = MobileDeviceAppSession.getSession();
/* 177:197 */     if ((this.processDataTxnOnce) && (this.processedOnce)) {
/* 178:199 */       return;
/* 179:    */     }
/* 180:202 */     AbstractMobileDeviceApplication app = deviceAppSession.getApplication();
/* 181:    */     
/* 182:204 */     RDORuntime rdoRuntime = app.getRDORuntime();
/* 183:    */     
/* 184:206 */     int noOfRecordsProcessed = 0;
/* 185:    */     try
/* 186:    */     {
/* 187:210 */       MobileMboData mboData = null;
/* 188:    */       do
/* 189:    */       {
/* 190:213 */         mboData = (MobileMboData)this.service.invoke("getDataTransactionResult", new Object[] { new Integer(startIndex), new Integer(size) });
/* 191:218 */         if (mboData.isMoreAvailable()) {
/* 192:220 */           startIndex += mboData.getSize();
/* 193:    */         }
/* 194:223 */         rdoRuntime.getRDOTransactionManager().begin();
/* 195:224 */         MobileMbo[] mbos = mboData.getMobileMbos();
/* 196:225 */         for (int i = 0; i < mbos.length; i++)
/* 197:    */         {
/* 198:227 */           processDataTransactionResult(rdoRuntime, mbos[i]);
/* 199:228 */           noOfRecordsProcessed++;
/* 200:    */         }
/* 201:230 */         rdoRuntime.getRDOTransactionManager().commit();
/* 202:232 */       } while (mboData.isMoreAvailable());
/* 203:234 */       if (noOfRecordsProcessed > 0) {
/* 204:236 */         this.service.invoke("acknowledgeDataTransactionResult", new Object[0]);
/* 205:    */       }
/* 206:240 */       performDeleteOfPendingDeleteTransactions(rdoRuntime);
/* 207:    */       
/* 208:242 */       this.processedOnce = true;
/* 209:    */     }
/* 210:    */     catch (Exception ex)
/* 211:    */     {
/* 212:    */       try
/* 213:    */       {
/* 214:247 */         rdoRuntime.getRDOTransactionManager().rollback();
/* 215:    */       }
/* 216:    */       catch (Exception e) {}
/* 217:250 */       if ((ex instanceof MobileApplicationException)) {
/* 218:252 */         throw ((MobileApplicationException)ex);
/* 219:    */       }
/* 220:256 */       throw new MobileApplicationException(ex);
/* 221:    */     }
/* 222:    */   }
/* 223:    */   
/* 224:    */   protected void performDeleteOfPendingDeleteTransactions(RDORuntime rdoRuntime)
/* 225:    */     throws MobileApplicationException
/* 226:    */   {
/* 227:    */     try
/* 228:    */     {
/* 229:266 */       rdoRuntime.getRDOTransactionManager().begin();
/* 230:267 */       RDOEnumeration iterator = rdoRuntime.getRDOManager().getAll("PENDINGRECORDSTODELETE");
/* 231:268 */       List removed = new ArrayList();
/* 232:269 */       while (iterator.hasMoreElements())
/* 233:    */       {
/* 234:271 */         RDO candidate = (RDO)iterator.nextElement();
/* 235:272 */         String objectName = candidate.getStringValue("DATAGROUPNAME");
/* 236:273 */         long objectId = candidate.getLongValue("RECORDID");
/* 237:274 */         RDO theRecord = rdoRuntime.getRDOManager().get(objectName, objectId);
/* 238:275 */         if (theRecord == null)
/* 239:    */         {
/* 240:277 */           removed.add(new Long(candidate.getId()));
/* 241:    */         }
/* 242:279 */         else if (!theRecord.getBooleanValue("_MODIFIED"))
/* 243:    */         {
/* 244:281 */           rdoRuntime.getRDOManager().remove(objectName, objectId);
/* 245:282 */           removed.add(new Long(candidate.getId()));
/* 246:    */         }
/* 247:    */       }
/* 248:285 */       for (int i = 0; i < removed.size(); i++) {
/* 249:287 */         rdoRuntime.getRDOManager().remove("PENDINGRECORDSTODELETE", ((Long)removed.get(i)).longValue());
/* 250:    */       }
/* 251:289 */       rdoRuntime.getRDOTransactionManager().commit();
/* 252:    */     }
/* 253:    */     catch (Exception e)
/* 254:    */     {
/* 255:    */       try
/* 256:    */       {
/* 257:295 */         rdoRuntime.getRDOTransactionManager().rollback();
/* 258:    */       }
/* 259:    */       catch (Exception ex)
/* 260:    */       {
/* 261:299 */         if ((ex instanceof MobileApplicationException)) {
/* 262:301 */           throw ((MobileApplicationException)ex);
/* 263:    */         }
/* 264:305 */         throw new MobileApplicationException(ex);
/* 265:    */       }
/* 266:    */     }
/* 267:    */   }
/* 268:    */   
/* 269:    */   protected void processDataTransactionResult(RDORuntime rdoRuntime, MobileMbo mobileMbo)
/* 270:    */     throws MobileApplicationException
/* 271:    */   {
/* 272:315 */     String dataGroupName = mobileMbo.getValue("OWNERDATAGROUPNAME");
/* 273:316 */     String recordId = mobileMbo.getValue("OWNERRECORDID");
/* 274:317 */     boolean isError = mobileMbo.getBooleanValue("ISERROR");
/* 275:318 */     String errorMessage = mobileMbo.getValue("ERRORMESSAGE");
/* 276:    */     
/* 277:320 */     String errDataGroupName = mobileMbo.getValue("DATAGROUPNAME");
/* 278:321 */     String errRecordId = mobileMbo.getValue("RECORDID");
/* 279:    */     
/* 280:323 */     RDO existingRDO = rdoRuntime.getRDOManager().get(dataGroupName, Long.parseLong(recordId));
/* 281:324 */     if (existingRDO != null) {
/* 282:326 */       if (isError)
/* 283:    */       {
/* 284:328 */         MobileMboUpdate update = new MobileMboUpdate();
/* 285:329 */         update.setID(Long.parseLong(recordId));
/* 286:330 */         update.setName(errDataGroupName);
/* 287:    */         
/* 288:332 */         byte[] txndataupdate = mobileMbo.getBinaryValue("TXNDATAUPDATE");
/* 289:333 */         if ((txndataupdate != null) && (txndataupdate.length > 0))
/* 290:    */         {
/* 291:335 */           ByteArrayInputStream bais = new ByteArrayInputStream(txndataupdate);
/* 292:    */           try
/* 293:    */           {
/* 294:339 */             ObjectInputStream ois = new ObjectInputStream(bais);
/* 295:340 */             update.readInstance(ois);
/* 296:    */           }
/* 297:    */           catch (IOException e)
/* 298:    */           {
/* 299:347 */             MobileLoggerFactory.getDefaultLogger().warn("txndata could not be read", e);
/* 300:    */           }
/* 301:    */         }
/* 302:351 */         updateRecordsWithError(rdoRuntime, existingRDO, errDataGroupName, errRecordId, errorMessage, update);
/* 303:    */       }
/* 304:    */       else
/* 305:    */       {
/* 306:357 */         removeRecordsProcessedSuccessfully(rdoRuntime, existingRDO);
/* 307:    */       }
/* 308:    */     }
/* 309:    */   }
/* 310:    */   
/* 311:    */   private void updateRecordsWithError(RDORuntime rdoRuntime, RDO rdo, String errDataGroupName, String errRecordId, String errorMessage, MobileMboUpdate updates)
/* 312:    */     throws MobileApplicationException
/* 313:    */   {
/* 314:367 */     if (rdo == null) {
/* 315:369 */       return;
/* 316:    */     }
/* 317:372 */     rdo.setBooleanValue("_ERR", true);
/* 318:373 */     rdo.setStringValue("_ERRMSG", errorMessage);
/* 319:374 */     rdo.setBooleanValue("_DONE", false);
/* 320:    */     
/* 321:    */ 
/* 322:377 */     Iterator it = updates.getAttributeNames();
/* 323:378 */     while (it.hasNext())
/* 324:    */     {
/* 325:380 */       String attributeName = (String)it.next();
/* 326:381 */       Object value = updates.getAttributeValue(attributeName);
/* 327:    */       
/* 328:383 */       rdo.setStringValue(attributeName, value != null ? value.toString() : null);
/* 329:    */     }
/* 330:386 */     String dataGroupName = rdo.getName();
/* 331:    */     
/* 332:388 */     rdoRuntime.getRDOManager().update(dataGroupName, rdo);
/* 333:    */     
/* 334:    */ 
/* 335:    */ 
/* 336:    */ 
/* 337:393 */     boolean processed = false;
/* 338:394 */     if (errDataGroupName.equals(dataGroupName)) {
/* 339:396 */       processed = true;
/* 340:    */     }
/* 341:399 */     RDOInfo rdoInfo = rdoRuntime.getRDOInfoManager().getInfo(rdo.getName());
/* 342:400 */     String[] depNames = rdoInfo.getDependentNames();
/* 343:401 */     for (int i = 0; i < depNames.length; i++)
/* 344:    */     {
/* 345:403 */       String depName = depNames[i];
/* 346:    */       
/* 347:405 */       Enumeration depEnum = rdo.getDependents(depName);
/* 348:406 */       while (depEnum.hasMoreElements())
/* 349:    */       {
/* 350:408 */         RDO depRDO = (RDO)depEnum.nextElement();
/* 351:409 */         String mobileMboName = depRDO.getName();
/* 352:410 */         long mobileMboId = depRDO.getId();
/* 353:411 */         MobileMboUpdate depUpdate = updates.getDependent(mobileMboName, mobileMboId);
/* 354:412 */         if (depUpdate != null) {
/* 355:413 */           updateDepRecords(rdoRuntime, depUpdate, rdo.getId());
/* 356:    */         }
/* 357:415 */         if (!processed) {
/* 358:417 */           processed = updateDepRecordsWithError(rdoRuntime, depRDO.getId() + "", depRDO, errDataGroupName, errRecordId, errorMessage);
/* 359:    */         }
/* 360:    */       }
/* 361:    */     }
/* 362:    */   }
/* 363:    */   
/* 364:    */   private void updateDepRecords(RDORuntime rdoRuntime, MobileMboUpdate mboUpdate, long parentId)
/* 365:    */     throws RDOException
/* 366:    */   {
/* 367:426 */     DefaultQBE qbe = new DefaultQBE();
/* 368:427 */     qbe.setQbeExactMatch(true);
/* 369:428 */     qbe.setQBE("_ID", mboUpdate.getID() + "");
/* 370:429 */     qbe.setQBE("_PARENTID", parentId + "");
/* 371:    */     
/* 372:431 */     String mobileMboName = mboUpdate.getName();
/* 373:432 */     RDOEnumeration rdoEnum = rdoRuntime.getRDOManager().getAll(mobileMboName, qbe, null);
/* 374:433 */     if (rdoEnum.hasMoreElements())
/* 375:    */     {
/* 376:435 */       RDO rdoToUpdate = (RDO)rdoEnum.nextElement();
/* 377:436 */       Iterator attrsToUpdate = mboUpdate.getAttributeNames();
/* 378:437 */       boolean needUpdate = false;
/* 379:438 */       while (attrsToUpdate.hasNext())
/* 380:    */       {
/* 381:440 */         String attributeName = (String)attrsToUpdate.next();
/* 382:441 */         Object fieldValue = mboUpdate.getAttributeValue(attributeName);
/* 383:    */         
/* 384:443 */         rdoToUpdate.setStringValue(attributeName, fieldValue != null ? fieldValue.toString() : null);
/* 385:444 */         needUpdate = true;
/* 386:    */       }
/* 387:446 */       if (needUpdate) {
/* 388:447 */         rdoRuntime.getRDOManager().update(mobileMboName, rdoToUpdate);
/* 389:    */       }
/* 390:449 */       String[] depNames = rdoToUpdate.getInfo().getDependentNames();
/* 391:450 */       int nDepNames = depNames.length;
/* 392:451 */       for (int index = 0; index < nDepNames; index++)
/* 393:    */       {
/* 394:453 */         String depName = depNames[index];
/* 395:454 */         RDOEnumeration rdoDepEnum = rdoToUpdate.getDependents(depName);
/* 396:455 */         while (rdoDepEnum.hasMoreElements())
/* 397:    */         {
/* 398:457 */           RDO rdoDepToUpdate = (RDO)rdoEnum.nextElement();
/* 399:458 */           String mobileMboDepName = rdoDepToUpdate.getName();
/* 400:459 */           long mobileMboDepId = rdoDepToUpdate.getId();
/* 401:460 */           MobileMboUpdate depUpdate = mboUpdate.getDependent(mobileMboDepName, mobileMboDepId);
/* 402:461 */           if (depUpdate != null) {
/* 403:463 */             updateDepRecords(rdoRuntime, depUpdate, mobileMboDepId);
/* 404:    */           }
/* 405:    */         }
/* 406:    */       }
/* 407:    */     }
/* 408:    */   }
/* 409:    */   
/* 410:    */   private boolean updateDepRecordsWithError(RDORuntime rdoRuntime, String parentRecordId, RDO depRDOToCheck, String errDataGroupName, String errRecordId, String errorMessage)
/* 411:    */     throws MobileApplicationException
/* 412:    */   {
/* 413:477 */     String depToCheck = depRDOToCheck.getName();
/* 414:479 */     if (depToCheck.equals(errDataGroupName))
/* 415:    */     {
/* 416:481 */       DefaultQBE qbe = new DefaultQBE();
/* 417:482 */       qbe.setQbeExactMatch(true);
/* 418:483 */       qbe.setQBE("_ID", errRecordId);
/* 419:484 */       qbe.setQBE("_PARENTID", parentRecordId);
/* 420:    */       
/* 421:486 */       RDOEnumeration rdoEnum = rdoRuntime.getRDOManager().getAll(depToCheck, qbe, null);
/* 422:487 */       if (rdoEnum.hasMoreElements())
/* 423:    */       {
/* 424:489 */         RDO rdoToUpdate = (RDO)rdoEnum.nextElement();
/* 425:490 */         rdoToUpdate.setBooleanValue("_ERR", true);
/* 426:491 */         rdoToUpdate.setStringValue("_ERRMSG", errorMessage);
/* 427:492 */         rdoToUpdate.setBooleanValue("_DONE", false);
/* 428:    */         
/* 429:494 */         rdoRuntime.getRDOManager().update(depToCheck, rdoToUpdate);
/* 430:    */       }
/* 431:496 */       return true;
/* 432:    */     }
/* 433:499 */     RDOInfo rdoInfo = rdoRuntime.getRDOInfoManager().getInfo(depToCheck);
/* 434:500 */     String[] depNames = rdoInfo.getDependentNames();
/* 435:501 */     for (int i = 0; i < depNames.length; i++)
/* 436:    */     {
/* 437:503 */       String depName = depNames[i];
/* 438:504 */       Enumeration depEnum = depRDOToCheck.getDependents(depName);
/* 439:505 */       while (depEnum.hasMoreElements())
/* 440:    */       {
/* 441:507 */         RDO depRDO = (RDO)depEnum.nextElement();
/* 442:508 */         boolean processed = updateDepRecordsWithError(rdoRuntime, depRDO.getId() + "", depRDO, errDataGroupName, errRecordId, errorMessage);
/* 443:509 */         if (processed) {
/* 444:511 */           return true;
/* 445:    */         }
/* 446:    */       }
/* 447:    */     }
/* 448:516 */     return false;
/* 449:    */   }
/* 450:    */   
/* 451:    */   private void removeRecordsProcessedSuccessfully(RDORuntime rdoRuntime, RDO rdo)
/* 452:    */     throws MobileApplicationException
/* 453:    */   {
/* 454:524 */     if (rdo == null) {
/* 455:526 */       return;
/* 456:    */     }
/* 457:529 */     String dataGroupName = rdo.getName();
/* 458:    */     
/* 459:    */ 
/* 460:532 */     long recordId = rdo.getId();
/* 461:    */     
/* 462:    */ 
/* 463:    */ 
/* 464:536 */     rdoRuntime.getRDOManager().remove(dataGroupName, recordId);
/* 465:    */   }
/* 466:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.MobileDeviceAppService
 * JD-Core Version:    0.7.0.1
 */