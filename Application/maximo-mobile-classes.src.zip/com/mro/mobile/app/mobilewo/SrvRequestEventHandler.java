/*   1:    */ package com.mro.mobile.app.mobilewo;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.mbo.MobileMbo;
/*   5:    */ import com.mro.mobile.mbo.MobileMboQBE;
/*   6:    */ import com.mro.mobile.ui.DataBeanCache;
/*   7:    */ import com.mro.mobile.ui.MobileMboDataBean;
/*   8:    */ import com.mro.mobile.ui.MobileMboDataBeanManager;
/*   9:    */ import com.mro.mobile.ui.event.UIEvent;
/*  10:    */ import com.mro.mobile.ui.res.UIUtil;
/*  11:    */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*  12:    */ import com.mro.mobileapp.WOApp;
/*  13:    */ import java.util.Date;
/*  14:    */ 
/*  15:    */ public class SrvRequestEventHandler
/*  16:    */   extends MobileWOCommonEventHandler
/*  17:    */ {
/*  18:    */   public boolean performEvent(UIEvent event)
/*  19:    */     throws MobileApplicationException
/*  20:    */   {
/*  21: 32 */     if (event == null) {
/*  22: 32 */       return false;
/*  23:    */     }
/*  24: 34 */     String eventId = event.getEventName();
/*  25: 36 */     if (eventId.equalsIgnoreCase("initpage")) {
/*  26: 38 */       return initpage(event);
/*  27:    */     }
/*  28: 40 */     if (eventId.equalsIgnoreCase("assetchanged")) {
/*  29: 42 */       return assetchanged(event);
/*  30:    */     }
/*  31: 44 */     if (eventId.equalsIgnoreCase("locchanged")) {
/*  32: 46 */       return locchanged(event);
/*  33:    */     }
/*  34: 49 */     super.performEvent(event);
/*  35:    */     
/*  36: 51 */     return false;
/*  37:    */   }
/*  38:    */   
/*  39:    */   public boolean initpage(UIEvent event)
/*  40:    */     throws MobileApplicationException
/*  41:    */   {
/*  42: 56 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/*  43: 57 */     databean.insert();
/*  44:    */     
/*  45: 59 */     Date createDate = ((WOApp)UIUtil.getApplication()).getCurrentTime();
/*  46: 60 */     databean.getMobileMbo().setDateValue("REPORTDATE", createDate);
/*  47:    */     
/*  48: 62 */     String eventValue = (String)event.getValue();
/*  49: 63 */     if (eventValue.equalsIgnoreCase("startcenter"))
/*  50:    */     {
/*  51: 65 */       UIUtil.refreshCurrentScreen();
/*  52: 66 */       return true;
/*  53:    */     }
/*  54: 70 */     MobileMboDataBean wodatabean = DataBeanCache.findDataBean("WORKORDER");
/*  55: 72 */     if (eventValue.equalsIgnoreCase("workorder"))
/*  56:    */     {
/*  57: 74 */       if (wodatabean == null) {
/*  58: 74 */         return false;
/*  59:    */       }
/*  60: 75 */       databean.setValue("ORIGRECORDID", wodatabean.getValue("WONUM"));
/*  61: 76 */       databean.setValue("ORIGRECSITEID", wodatabean.getValue("SITEID"));
/*  62: 77 */       databean.setValue("ORIGRECORDCLASS", wodatabean.getValue("WOCLASS"));
/*  63: 78 */       databean.setValue("ASSETNUM", wodatabean.getValue("ASSETNUM"));
/*  64: 79 */       databean.setValue("LOCATION", wodatabean.getValue("LOCATION"));
/*  65: 80 */       databean.setValue("REPORTEDPRIORITY", wodatabean.getValue("WOPRIORITY"));
/*  66: 81 */       databean.setValue("SITEID", wodatabean.getValue("SITEID"));
/*  67: 82 */       databean.setValue("ASSETSITEID", wodatabean.getValue("SITEID"));
/*  68: 83 */       databean.setValue("ORIGWOID", wodatabean.getValue("WONUM"));
/*  69: 85 */       if ((!wodatabean.getValue("ASSETNUM").equals("")) || (!wodatabean.getValue("LOCATION").equals("")))
/*  70:    */       {
/*  71: 87 */         databean.setValue("ASSETORGID", wodatabean.getValue("ORGID"));
/*  72: 88 */         databean.setValue("ASSETSITEID", wodatabean.getValue("SITEID"));
/*  73:    */       }
/*  74: 93 */       MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager("CLASSSTRUCTURE");
/*  75: 94 */       MobileMboDataBean csBean = mgrDBMgr.getDataBean();
/*  76: 95 */       csBean.getQBE().reset();
/*  77: 96 */       csBean.getQBE().setQbeExactMatch(true);
/*  78:    */       
/*  79: 98 */       csBean.getQBE().setQBE("CLASSSTRUCTUREID", wodatabean.getValue("CLASSSTRUCTUREID"));
/*  80: 99 */       csBean.reset();
/*  81:100 */       int count = csBean.count();
/*  82:101 */       if (count == 1)
/*  83:    */       {
/*  84:103 */         databean.setValue("CLASSSTRUCTUREID", wodatabean.getValue("CLASSSTRUCTUREID"));
/*  85:104 */         databean.setValue("CLASSSTRUCTURE_HIERARCHYPATH", wodatabean.getValue("CLASSSTRUCTURE_HIERARCHYPATH"));
/*  86:    */       }
/*  87:    */     }
/*  88:107 */     else if (eventValue.equalsIgnoreCase("asset"))
/*  89:    */     {
/*  90:109 */       if (wodatabean == null) {
/*  91:109 */         return false;
/*  92:    */       }
/*  93:110 */       databean.setValue("ASSETNUM", wodatabean.getValue("ASSETNUM"));
/*  94:111 */       databean.setValue("LOCATION", wodatabean.getValue("LOCATION"));
/*  95:112 */       if ((!wodatabean.getValue("ASSETNUM").equals("")) || (!wodatabean.getValue("LOCATION").equals("")))
/*  96:    */       {
/*  97:114 */         databean.setValue("ASSETORGID", wodatabean.getValue("ORGID"));
/*  98:115 */         databean.setValue("ASSETSITEID", wodatabean.getValue("SITEID"));
/*  99:    */       }
/* 100:    */     }
/* 101:118 */     else if (eventValue.equalsIgnoreCase("location"))
/* 102:    */     {
/* 103:120 */       if (wodatabean == null) {
/* 104:120 */         return false;
/* 105:    */       }
/* 106:121 */       databean.setValue("LOCATION", wodatabean.getValue("LOCATION"));
/* 107:122 */       if (!wodatabean.getValue("LOCATION").equals(""))
/* 108:    */       {
/* 109:124 */         databean.setValue("ASSETORGID", wodatabean.getValue("ORGID"));
/* 110:125 */         databean.setValue("ASSETSITEID", wodatabean.getValue("SITEID"));
/* 111:    */       }
/* 112:    */     }
/* 113:129 */     UIUtil.refreshCurrentScreen();
/* 114:    */     
/* 115:131 */     return true;
/* 116:    */   }
/* 117:    */   
/* 118:    */   public boolean assetchanged(UIEvent event)
/* 119:    */     throws MobileApplicationException
/* 120:    */   {
/* 121:137 */     MobileMboDataBean databean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/* 122:138 */     if (databean != null) {
/* 123:140 */       if (event.getValue() != null)
/* 124:    */       {
/* 125:143 */         MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager("ASSET");
/* 126:144 */         MobileMboDataBean assetBean = mgrDBMgr.getDataBean();
/* 127:145 */         assetBean.getQBE().reset();
/* 128:146 */         assetBean.getQBE().setQbeExactMatch(true);
/* 129:    */         
/* 130:148 */         assetBean.getQBE().setQBE("SITEID", databean.getValue("SITEID"));
/* 131:149 */         assetBean.getQBE().setQBE("ASSETNUM", (String)event.getValue());
/* 132:150 */         assetBean.reset();
/* 133:151 */         int count = assetBean.count();
/* 134:152 */         if (count == 1)
/* 135:    */         {
/* 136:154 */           databean.setValue("ASSETORGID", assetBean.getMobileMbo(0).getValue("ORGID"));
/* 137:155 */           databean.setValue("ASSETSITEID", assetBean.getMobileMbo(0).getValue("SITEID"));
/* 138:156 */           databean.setValue("LOCATION", assetBean.getMobileMbo(0).getValue("LOCATION"));
/* 139:    */         }
/* 140:    */       }
/* 141:    */     }
/* 142:161 */     return true;
/* 143:    */   }
/* 144:    */   
/* 145:    */   public boolean locchanged(UIEvent event)
/* 146:    */     throws MobileApplicationException
/* 147:    */   {
/* 148:167 */     MobileMboDataBean databean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/* 149:168 */     if (databean != null) {
/* 150:170 */       if (event.getValue() != null) {
/* 151:173 */         if ((databean.getValue("ASSETORGID").equals("")) || (databean.getValue("ASSETSITEID").equals("")))
/* 152:    */         {
/* 153:175 */           MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager("LOCATIONS");
/* 154:176 */           MobileMboDataBean locBean = mgrDBMgr.getDataBean();
/* 155:177 */           locBean.getQBE().reset();
/* 156:178 */           locBean.getQBE().setQbeExactMatch(true);
/* 157:    */           
/* 158:180 */           locBean.getQBE().setQBE("SITEID", databean.getValue("SITEID"));
/* 159:181 */           locBean.getQBE().setQBE("LOCATION", (String)event.getValue());
/* 160:182 */           locBean.reset();
/* 161:183 */           int count = locBean.count();
/* 162:184 */           if (count == 1)
/* 163:    */           {
/* 164:186 */             databean.setValue("ASSETORGID", locBean.getMobileMbo(0).getValue("ORGID"));
/* 165:187 */             databean.setValue("ASSETSITEID", locBean.getMobileMbo(0).getValue("SITEID"));
/* 166:    */           }
/* 167:    */         }
/* 168:    */       }
/* 169:    */     }
/* 170:192 */     return true;
/* 171:    */   }
/* 172:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.mobilewo.SrvRequestEventHandler
 * JD-Core Version:    0.7.0.1
 */