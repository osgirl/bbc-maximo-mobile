/*  1:   */ package com.mro.mobile.app.mobilewo;
/*  2:   */ 
/*  3:   */ import com.mro.mobile.MobileApplicationException;
/*  4:   */ import com.mro.mobile.app.DefaultMobileWebServiceProxy;
/*  5:   */ import com.mro.mobile.app.MobileDeviceAppService;
/*  6:   */ import com.mro.mobile.mbo.MobileMbo;
/*  7:   */ import com.mro.mobile.mbo.MobileMboChange;
/*  8:   */ import java.util.Date;
/*  9:   */ 
/* 10:   */ public class MobileWOWebServiceProxy
/* 11:   */   extends DefaultMobileWebServiceProxy
/* 12:   */   implements MobileWOWebService
/* 13:   */ {
/* 14:   */   public MobileWOWebServiceProxy(String appName)
/* 15:   */   {
/* 16:27 */     super(appName);
/* 17:   */   }
/* 18:   */   
/* 19:   */   public void performAction(String parentName, Long parentId, MobileMbo actionInputMbo)
/* 20:   */     throws MobileApplicationException
/* 21:   */   {
/* 22:32 */     this.service.invokeAsync("performAction", new Object[] { parentName, parentId, actionInputMbo });
/* 23:   */   }
/* 24:   */   
/* 25:   */   public void requestWork(MobileMbo workMbo)
/* 26:   */     throws MobileApplicationException
/* 27:   */   {
/* 28:37 */     this.service.invokeAsync("requestWork", new Object[] { workMbo });
/* 29:   */   }
/* 30:   */   
/* 31:   */   public void applyChanges(MobileMboChange workMbo)
/* 32:   */     throws MobileApplicationException
/* 33:   */   {
/* 34:42 */     getService().invokeAsync("applyChanges", new Object[] { workMbo });
/* 35:   */   }
/* 36:   */   
/* 37:   */   public void createServiceRequest(MobileMboChange workMbo)
/* 38:   */     throws MobileApplicationException
/* 39:   */   {
/* 40:47 */     getService().invokeAsync("createServiceRequest", new Object[] { workMbo });
/* 41:   */   }
/* 42:   */   
/* 43:   */   public void changeWOStatus(String wonum, String siteID, String currentStatus, String status, Date statusDate, String memo)
/* 44:   */     throws MobileApplicationException
/* 45:   */   {
/* 46:52 */     getService().invoke("changeWOStatus", new Object[] { wonum, siteID, currentStatus, status, statusDate, memo });
/* 47:   */   }
/* 48:   */   
/* 49:   */   public void changeTKStatus(String ticketId, String ticketClass, String currentStatus, String status, Date statusDate, String memo)
/* 50:   */     throws MobileApplicationException
/* 51:   */   {
/* 52:57 */     getService().invoke("changeTKStatus", new Object[] { ticketId, ticketClass, currentStatus, status, statusDate, memo });
/* 53:   */   }
/* 54:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.mobilewo.MobileWOWebServiceProxy
 * JD-Core Version:    0.7.0.1
 */