/*   1:    */ package com.mro.mobile.app.mobilewo;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.MobileMessageGenerator;
/*   5:    */ import com.mro.mobile.ProgressObserver;
/*   6:    */ import com.mro.mobile.app.BasicMobileDeviceUIApplication;
/*   7:    */ import com.mro.mobile.mbo.MobileMbo;
/*   8:    */ import com.mro.mobile.persist.RDO;
/*   9:    */ import com.mro.mobile.ui.DataBeanCache;
/*  10:    */ import com.mro.mobile.ui.MobileMboDataBean;
/*  11:    */ import com.mro.mobile.ui.MobileMboDataBeanManager;
/*  12:    */ import com.mro.mobile.ui.event.UIEvent;
/*  13:    */ import com.mro.mobile.ui.res.UIUtil;
/*  14:    */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*  15:    */ import com.mro.mobile.ui.res.controls.PageControl;
/*  16:    */ import com.mro.mobileapp.WOApp;
/*  17:    */ import java.net.ConnectException;
/*  18:    */ 
/*  19:    */ public class TKChangeStatusEventHandler
/*  20:    */   extends MobileWOCommonEventHandler
/*  21:    */ {
/*  22: 33 */   private boolean mobileMboModified = false;
/*  23:    */   
/*  24:    */   public boolean performEvent(UIEvent event)
/*  25:    */     throws MobileApplicationException
/*  26:    */   {
/*  27: 37 */     if (event == null) {
/*  28: 37 */       return false;
/*  29:    */     }
/*  30: 39 */     String eventId = event.getEventName();
/*  31: 41 */     if (eventId.equalsIgnoreCase("initpage")) {
/*  32: 43 */       return initpage(event);
/*  33:    */     }
/*  34: 45 */     if (eventId.equalsIgnoreCase("validatepage")) {
/*  35: 47 */       return validatepage(event);
/*  36:    */     }
/*  37: 49 */     if (eventId.equalsIgnoreCase("saveclose")) {
/*  38: 51 */       return saveclose(event);
/*  39:    */     }
/*  40: 53 */     if (eventId.equalsIgnoreCase("cancelpage")) {
/*  41: 55 */       this.mobileMboModified = false;
/*  42:    */     }
/*  43: 58 */     super.performEvent(event);
/*  44:    */     
/*  45: 60 */     return false;
/*  46:    */   }
/*  47:    */   
/*  48:    */   private boolean saveclose(UIEvent event)
/*  49:    */     throws MobileApplicationException
/*  50:    */   {
/*  51: 65 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/*  52: 66 */     PageControl page = (PageControl)UIUtil.getCurrentScreen();
/*  53: 67 */     if ((page != null) && 
/*  54: 68 */       (!page.checkRequiredFields()))
/*  55:    */     {
/*  56: 69 */       event.setEventErrored();
/*  57: 70 */       return true;
/*  58:    */     }
/*  59: 75 */     if (!checkEsig(databean, event))
/*  60:    */     {
/*  61: 77 */       event.setEventErrored();
/*  62: 78 */       return true;
/*  63:    */     }
/*  64: 81 */     if (isRealTimeStatusChange(databean, databean.getCurrentPosition()))
/*  65:    */     {
/*  66: 82 */       switch (event.getThreadStatus())
/*  67:    */       {
/*  68:    */       case -1: 
/*  69: 85 */         UIUtil.startWorkerThread(this, event);
/*  70: 86 */         break;
/*  71:    */       case 1: 
/*  72: 89 */         event.getProgressObserver().setWorkProgressMessage(MobileMessageGenerator.generateSimpleMessage("sendingstatus", null));
/*  73: 90 */         event.getProgressObserver().updateWorkProgress();
/*  74: 91 */         doRealTimeStatusChange(databean, databean.getCurrentPosition(), event);
/*  75: 92 */         return true;
/*  76:    */       case 2: 
/*  77: 95 */         if (event.getException() != null) {
/*  78: 96 */           UIUtil.showExceptionMessage(event.getException(), null, 0);
/*  79:    */         }
/*  80: 99 */         databean.getDataBeanManager().save();
/*  81:    */         
/*  82:101 */         UIUtil.closePage();
/*  83:102 */         return true;
/*  84:    */       case 0: 
/*  85:    */         break;
/*  86:    */       case 3: 
/*  87:106 */         UIUtil.showExceptionMessage(event.getException(), null, 0);
/*  88:107 */         databean.getDataBeanManager().save();
/*  89:    */         
/*  90:109 */         UIUtil.closePage();
/*  91:110 */         return true;
/*  92:    */       }
/*  93:    */     }
/*  94:    */     else
/*  95:    */     {
/*  96:113 */       validatepage(event);
/*  97:114 */       databean.getDataBeanManager().save();
/*  98:115 */       UIUtil.closePage();
/*  99:    */     }
/* 100:117 */     return true;
/* 101:    */   }
/* 102:    */   
/* 103:    */   protected void doRealTimeStatusChange(MobileMboDataBean databean, int pos, UIEvent event)
/* 104:    */     throws MobileApplicationException
/* 105:    */   {
/* 106:122 */     BasicMobileDeviceUIApplication app = UIUtil.getApplication();
/* 107:123 */     MobileWOWebServiceProxy service = (MobileWOWebServiceProxy)app.getDefaultMobileWebServiceProxy();
/* 108:124 */     MobileMbo mobileMbo = databean.getMobileMbo(pos);
/* 109:125 */     event.getProgressObserver().updateWorkProgress();
/* 110:    */     
/* 111:    */ 
/* 112:128 */     event.getProgressObserver().setWorkProgressMessage(MobileMessageGenerator.generate("connectingserver", null));
/* 113:    */     try
/* 114:    */     {
/* 115:130 */       service.changeTKStatus(mobileMbo.getValue("TICKETID"), mobileMbo.getValue("CLASS"), mobileMbo.getValue("STATUS"), mobileMbo.getValue("NEWSTATUSDISPLAY"), mobileMbo.getDateValue("NEWSTATUSASOFDATE"), mobileMbo.getValue("NEWSTATUSMEMO"));
/* 116:    */       
/* 117:    */ 
/* 118:    */ 
/* 119:    */ 
/* 120:    */ 
/* 121:    */ 
/* 122:137 */       validatepage(event, false);
/* 123:    */       
/* 124:139 */       event.getProgressObserver().updateWorkProgress();
/* 125:140 */       event.getProgressObserver().setWorkProgressMessage(MobileMessageGenerator.generateSimpleMessage("sendstatuscompl", null));
/* 126:141 */       event.setThreadStatus(2);
/* 127:    */       
/* 128:143 */       mobileMbo.changeOriginalValue("STATUS", mobileMbo.getValue("NEWSTATUSDISPLAY"));
/* 129:144 */       mobileMbo.changeOriginalDateValue("STATUSDATE", mobileMbo.getDateValue("NEWSTATUSASOFDATE"));
/* 130:145 */       mobileMbo.setValue("NEWSTATUS", "");
/* 131:147 */       if (!this.mobileMboModified) {
/* 132:148 */         mobileMbo.getRDO().setBooleanValue("_MODIFIED", false);
/* 133:    */       }
/* 134:150 */       event.setThreadStatus(2);
/* 135:    */     }
/* 136:    */     catch (MobileApplicationException e)
/* 137:    */     {
/* 138:152 */       if (isConnectException(e))
/* 139:    */       {
/* 140:153 */         queuePendingStatusChange(mobileMbo);
/* 141:    */         
/* 142:155 */         validatepage(event, true);
/* 143:    */       }
/* 144:158 */       else if (!this.mobileMboModified)
/* 145:    */       {
/* 146:159 */         mobileMbo.getRDO().setBooleanValue("_MODIFIED", false);
/* 147:    */       }
/* 148:162 */       generateErrorMessage(event, e);
/* 149:    */     }
/* 150:    */   }
/* 151:    */   
/* 152:    */   private boolean isConnectException(MobileApplicationException e)
/* 153:    */   {
/* 154:168 */     return e.getNestedException() instanceof ConnectException;
/* 155:    */   }
/* 156:    */   
/* 157:    */   protected boolean isRealTimeStatusChange(MobileMboDataBean databean, int pos)
/* 158:    */     throws MobileApplicationException
/* 159:    */   {
/* 160:173 */     MobileMbo currentMbo = databean.getMobileMbo(pos);
/* 161:175 */     if (currentMbo.isNew()) {
/* 162:176 */       return false;
/* 163:    */     }
/* 164:179 */     MobileMboDataBean userConfig = DataBeanCache.getDataBean("MOBREALSTATUSCFG", "MOBREALSTATUSCFG");
/* 165:    */     
/* 166:181 */     int count = userConfig.count();
/* 167:182 */     userConfig.dataExists(count);
/* 168:183 */     userConfig.close();
/* 169:184 */     userConfig.indexMobileMboDataBean("MOBREALSTATUSCFG", new String[] { "DOMAINID", "VALUE", "CLASS" }, false);
/* 170:    */     
/* 171:    */ 
/* 172:187 */     String internalClass = ((WOApp)UIUtil.getApplication()).getInternalValue(databean, "TKCLASS", currentMbo.getValue("CLASS"));
/* 173:188 */     String statusDomainId = internalClass + "STATUS";
/* 174:189 */     String displayStatus = currentMbo.getValue("NEWSTATUSDISPLAY");
/* 175:    */     
/* 176:    */ 
/* 177:192 */     return userConfig.getIndexedMobileMbo("MOBREALSTATUSCFG", new String[] { statusDomainId, displayStatus, internalClass }) != null;
/* 178:    */   }
/* 179:    */   
/* 180:    */   private void generateErrorMessage(UIEvent event, MobileApplicationException e)
/* 181:    */   {
/* 182:199 */     StringBuffer buf = new StringBuffer(MobileMessageGenerator.generate("errorsendingstatus", null));
/* 183:200 */     buf.append(":\n");
/* 184:201 */     buf.append(e.getCompleteMessage());
/* 185:202 */     MobileApplicationException exception = new MobileApplicationException(buf.toString(), e);
/* 186:203 */     event.setException(exception);
/* 187:    */   }
/* 188:    */   
/* 189:    */   private void queuePendingStatusChange(MobileMbo mobileMbo)
/* 190:    */     throws MobileApplicationException
/* 191:    */   {
/* 192:209 */     MobileMboDataBeanManager mngr = new MobileMboDataBeanManager("PENDINGCHGSTATUS");
/* 193:210 */     MobileMboDataBean pendingQueue = mngr.getDataBean();
/* 194:211 */     pendingQueue.insert();
/* 195:    */     
/* 196:213 */     pendingQueue.setValue("TICKETID", mobileMbo.getValue("TICKETID"));
/* 197:214 */     pendingQueue.setValue("SITEID", mobileMbo.getValue("SITEID"));
/* 198:215 */     pendingQueue.setValue("CURRENTSTATUS", mobileMbo.getValue("STATUS"));
/* 199:216 */     pendingQueue.setValue("NEWSTATUS", mobileMbo.getValue("NEWSTATUSDISPLAY"));
/* 200:217 */     pendingQueue.getMobileMbo().setDateValue("STATUSDATE", mobileMbo.getDateValue("NEWSTATUSASOFDATE"));
/* 201:218 */     pendingQueue.setValue("MEMO", mobileMbo.getValue("NEWSTATUSMEMO"));
/* 202:219 */     pendingQueue.setValue("MOBMBONAME", mobileMbo.getValue("CLASS"));
/* 203:220 */     mngr.save();
/* 204:    */   }
/* 205:    */   
/* 206:    */   public boolean initpage(UIEvent event)
/* 207:    */     throws MobileApplicationException
/* 208:    */   {
/* 209:226 */     MobileMboDataBean databean = ((PageControl)event.getCreatingObject()).getDataBean();
/* 210:227 */     this.mobileMboModified = databean.isMobileMboModified();
/* 211:    */     
/* 212:229 */     databean.getMobileMbo().setValue("NEWSTATUSDISPLAY", "");
/* 213:230 */     databean.getMobileMbo().setDateValue("NEWSTATUSASOFDATE", databean.getCurrentTime());
/* 214:231 */     databean.getMobileMbo().setValue("NEWSTATUSMEMO", "");
/* 215:    */     
/* 216:233 */     return true;
/* 217:    */   }
/* 218:    */   
/* 219:    */   public boolean validatepage(UIEvent event)
/* 220:    */     throws MobileApplicationException
/* 221:    */   {
/* 222:237 */     return validatepage(event, true);
/* 223:    */   }
/* 224:    */   
/* 225:    */   private boolean validatepage(UIEvent event, boolean generateHistory)
/* 226:    */     throws MobileApplicationException
/* 227:    */   {
/* 228:242 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/* 229:244 */     if (!databean.getValue("NEWSTATUSDISPLAY").equals(""))
/* 230:    */     {
/* 231:246 */       databean.setValue("STATUS", databean.getValue("NEWSTATUSDISPLAY"), false);
/* 232:247 */       databean.setValue("NEWSTATUS", databean.getValue("NEWSTATUSDISPLAY"));
/* 233:249 */       if (generateHistory)
/* 234:    */       {
/* 235:251 */         MobileMboDataBean histbean = databean.getDataBean("TKSTATUSHIST");
/* 236:252 */         if (histbean != null)
/* 237:    */         {
/* 238:254 */           histbean.insert();
/* 239:    */           
/* 240:256 */           histbean.setValue("CHANGEBY", WOApp.getUserId());
/* 241:257 */           histbean.getMobileMbo().setDateValue("CHANGEDATE", databean.getMobileMbo().getDateValue("NEWSTATUSASOFDATE"));
/* 242:258 */           histbean.setValue("ORGID", databean.getValue("ORGID"));
/* 243:259 */           histbean.setValue("SITEID", databean.getValue("SITEID"));
/* 244:260 */           histbean.setValue("STATUS", databean.getValue("NEWSTATUSDISPLAY"));
/* 245:261 */           histbean.setValue("MEMO", databean.getValue("NEWSTATUSMEMO"));
/* 246:    */         }
/* 247:    */       }
/* 248:    */     }
/* 249:266 */     return false;
/* 250:    */   }
/* 251:    */   
/* 252:    */   private boolean checkEsig(MobileMboDataBean databean, UIEvent event)
/* 253:    */     throws MobileApplicationException
/* 254:    */   {
/* 255:280 */     String tkClass = ((WOApp)UIUtil.getApplication()).getInternalValue(databean, "TKCLASS", databean.getValue("CLASS"));
/* 256:281 */     String statusListName = "SRSTATUS";
/* 257:282 */     if (tkClass.equals("INCIDENT")) {
/* 258:284 */       statusListName = "INCIDENTSTATUS";
/* 259:286 */     } else if (tkClass.equals("PROBLEM")) {
/* 260:288 */       statusListName = "PROBLEMSTATUS";
/* 261:    */     }
/* 262:291 */     TKStatusHandler tkHandler = new TKStatusHandler((WOApp)UIUtil.getApplication(), databean, statusListName);
/* 263:292 */     String newStatus = ((WOApp)UIUtil.getApplication()).getInternalValue(databean, statusListName, databean.getValue("NEWSTATUSDISPLAY"));
/* 264:293 */     String optionName = tkHandler.getOptionName(newStatus);
/* 265:    */     
/* 266:295 */     return UIUtil.checkESignature(event, databean, optionName);
/* 267:    */   }
/* 268:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.mobilewo.TKChangeStatusEventHandler
 * JD-Core Version:    0.7.0.1
 */