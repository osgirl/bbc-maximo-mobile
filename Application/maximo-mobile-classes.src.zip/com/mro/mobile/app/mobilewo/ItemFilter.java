/*   1:    */ package com.mro.mobile.app.mobilewo;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.mbo.MobileMboQBE;
/*   5:    */ import com.mro.mobile.ui.MobileMboDataBean;
/*   6:    */ import com.mro.mobile.ui.MobileMboDataBeanManager;
/*   7:    */ import com.mro.mobile.ui.res.UIUtil;
/*   8:    */ import com.mro.mobileapp.WOApp;
/*   9:    */ import java.util.ArrayList;
/*  10:    */ import java.util.List;
/*  11:    */ 
/*  12:    */ public class ItemFilter
/*  13:    */ {
/*  14: 32 */   private MobileMboDataBean itembean = null;
/*  15:    */   
/*  16:    */   public static List translateItemStatusName(MobileMboDataBean databean, String[] statusNames)
/*  17:    */     throws MobileApplicationException
/*  18:    */   {
/*  19: 35 */     List result = new ArrayList();
/*  20: 36 */     int count = statusNames.length;
/*  21: 37 */     for (int i = 0; i < count; i++)
/*  22:    */     {
/*  23: 39 */       String statusName = statusNames[i];
/*  24:    */       
/*  25:    */ 
/*  26: 42 */       String statuses = ((WOApp)UIUtil.getApplication()).getSynonymValues(databean, "ITEMSTATUS", statusName);
/*  27:    */       
/*  28: 44 */       String[] aux = split(statuses, ',');
/*  29: 45 */       for (int j = 0; j < aux.length; j++) {
/*  30: 47 */         result.add(aux[j]);
/*  31:    */       }
/*  32:    */     }
/*  33: 50 */     return result;
/*  34:    */   }
/*  35:    */   
/*  36:    */   private static String[] split(String list, char separator)
/*  37:    */   {
/*  38: 56 */     List temp = new ArrayList();
/*  39: 57 */     int end = list.indexOf(separator);
/*  40: 58 */     while (end >= 0)
/*  41:    */     {
/*  42: 59 */       String token = list.substring(0, end);
/*  43: 60 */       temp.add(token);
/*  44: 61 */       if (end + 1 >= list.length()) {
/*  45:    */         break;
/*  46:    */       }
/*  47: 62 */       list = list.substring(end + 1, list.length());
/*  48: 63 */       end = list.indexOf(separator);
/*  49:    */     }
/*  50: 68 */     if (list.length() > 0) {
/*  51: 69 */       temp.add(list);
/*  52:    */     }
/*  53: 71 */     String[] array = new String[temp.size()];
/*  54: 72 */     for (int i = 0; i < array.length; i++) {
/*  55: 73 */       array[i] = ((String)temp.get(i));
/*  56:    */     }
/*  57: 75 */     return array;
/*  58:    */   }
/*  59:    */   
/*  60:    */   public ItemFilter(MobileMboDataBean itembean)
/*  61:    */     throws MobileApplicationException
/*  62:    */   {
/*  63: 79 */     if (itembean == null) {
/*  64: 81 */       throw new MobileApplicationException(new IllegalArgumentException("itembean"));
/*  65:    */     }
/*  66: 84 */     itembean.getQBE().reset();
/*  67: 85 */     itembean.reset();
/*  68: 86 */     int counti = itembean.count();
/*  69: 87 */     for (int i = 0; i < counti; i++) {
/*  70: 89 */       itembean.setValue(i, "DISPLAY_IN_LOOKUP", "1");
/*  71:    */     }
/*  72: 91 */     MobileMboQBE qbe = itembean.getQBE();
/*  73: 92 */     qbe.reset();
/*  74: 93 */     qbe.setQBE("DISPLAY_IN_LOOKUP", "1");
/*  75: 94 */     itembean.getDataBeanManager().save();
/*  76: 95 */     this.itembean = itembean;
/*  77:    */   }
/*  78:    */   
/*  79:    */   public void applyInventoryFilter(String inventoryMboName, List statuses, String location, String siteid)
/*  80:    */     throws MobileApplicationException
/*  81:    */   {
/*  82:100 */     this.itembean.reset();
/*  83:101 */     int count = this.itembean.count();
/*  84:102 */     for (int i = 0; i < count; i++) {
/*  85:104 */       if (!isValidAtInventory(i, inventoryMboName, statuses, location, siteid)) {
/*  86:106 */         this.itembean.setValue(i, "DISPLAY_IN_LOOKUP", "0");
/*  87:    */       }
/*  88:    */     }
/*  89:109 */     this.itembean.getDataBeanManager().save();
/*  90:    */   }
/*  91:    */   
/*  92:    */   public void applyInventoryFilter(String inventoryMboName, List statuses)
/*  93:    */     throws MobileApplicationException
/*  94:    */   {
/*  95:114 */     applyInventoryFilter(inventoryMboName, statuses, null, null);
/*  96:    */   }
/*  97:    */   
/*  98:    */   private boolean isValidAtInventory(int index, String inventoryMboName, List statuses, String location, String siteid)
/*  99:    */     throws MobileApplicationException
/* 100:    */   {
/* 101:119 */     MobileMboDataBean iteminv = this.itembean.getDataBean(index, inventoryMboName);
/* 102:120 */     int countInv = iteminv.count();
/* 103:121 */     for (int k = 0; k < countInv; k++) {
/* 104:123 */       if (statuses.indexOf(iteminv.getValue(k, "STATUS")) > -1) {
/* 105:126 */         if ((location == null) || (location.equals("")) || (iteminv.getValue(k, "LOCATION").equals(location))) {
/* 106:128 */           if ((siteid == null) || (siteid.equals("")) || (iteminv.getValue(k, "SITEID").equals(siteid))) {
/* 107:130 */             return true;
/* 108:    */           }
/* 109:    */         }
/* 110:    */       }
/* 111:    */     }
/* 112:135 */     return false;
/* 113:    */   }
/* 114:    */   
/* 115:    */   public void applyInvbalancesFilter(String InvBalancesMboNameString, String location, String binnum, String lotnum)
/* 116:    */     throws MobileApplicationException
/* 117:    */   {
/* 118:140 */     this.itembean.reset();
/* 119:141 */     int count = this.itembean.count();
/* 120:142 */     for (int i = 0; i < count; i++)
/* 121:    */     {
/* 122:144 */       MobileMboDataBean itembal = this.itembean.getDataBean(i, InvBalancesMboNameString);
/* 123:145 */       boolean found = false;
/* 124:146 */       int countBal = itembal.count();
/* 125:147 */       for (int k = 0; k < countBal; k++)
/* 126:    */       {
/* 127:149 */         if ((location.equals("")) || (itembal.getValue(k, "LOCATION").equals(location)))
/* 128:    */         {
/* 129:151 */           found = true;
/* 130:    */         }
/* 131:    */         else
/* 132:    */         {
/* 133:153 */           found = false;
/* 134:154 */           continue;
/* 135:    */         }
/* 136:156 */         if ((binnum.equals("")) || (itembal.getValue(k, "BINNUM").equals(binnum)))
/* 137:    */         {
/* 138:158 */           found = true;
/* 139:    */         }
/* 140:    */         else
/* 141:    */         {
/* 142:160 */           found = false;
/* 143:161 */           continue;
/* 144:    */         }
/* 145:163 */         if ((lotnum.equals("")) || (itembal.getValue(k, "LOTNUM").equals(lotnum)))
/* 146:    */         {
/* 147:165 */           found = true;
/* 148:166 */           break;
/* 149:    */         }
/* 150:168 */         found = false;
/* 151:    */       }
/* 152:173 */       if (!found) {
/* 153:175 */         this.itembean.setValue(i, "DISPLAY_IN_LOOKUP", "0");
/* 154:    */       }
/* 155:    */     }
/* 156:178 */     this.itembean.getDataBeanManager().save();
/* 157:    */   }
/* 158:    */   
/* 159:    */   public void applyItemOrgInfoFilter(String itemOrgInfoMboName, List statusesItemOrg, boolean stockedOnly, String orgid, String inventoryMboName, List statusesInv, String location, String siteid)
/* 160:    */     throws MobileApplicationException
/* 161:    */   {
/* 162:183 */     this.itembean.reset();
/* 163:184 */     int count = this.itembean.count();
/* 164:185 */     for (int i = 0; i < count; i++)
/* 165:    */     {
/* 166:187 */       MobileMboDataBean itemorgbean = this.itembean.getDataBean(i, itemOrgInfoMboName);
/* 167:188 */       boolean found = false;
/* 168:189 */       int countItemOrg = itemorgbean.count();
/* 169:190 */       for (int j = 0; j < countItemOrg; j++)
/* 170:    */       {
/* 171:192 */         String itemorginfoOrgid = itemorgbean.getValue(j, "ORGID");
/* 172:193 */         String itemorginfoStatus = itemorgbean.getValue(j, "STATUS");
/* 173:194 */         if ((statusesItemOrg.indexOf(itemorginfoStatus) > -1) && (orgid.equalsIgnoreCase(itemorginfoOrgid)))
/* 174:    */         {
/* 175:197 */           found = true;
/* 176:198 */           break;
/* 177:    */         }
/* 178:    */       }
/* 179:202 */       if ((inventoryMboName != null) && ((stockedOnly) || (!found))) {
/* 180:204 */         found = isValidAtInventory(i, inventoryMboName, statusesInv, location, siteid);
/* 181:    */       }
/* 182:207 */       if (!found) {
/* 183:209 */         this.itembean.setValue(i, "DISPLAY_IN_LOOKUP", "0");
/* 184:    */       }
/* 185:    */     }
/* 186:212 */     this.itembean.getDataBeanManager().save();
/* 187:    */   }
/* 188:    */   
/* 189:    */   public void applyItemOrgInfoFilter(String itemOrgInfoMboName, List statusesItemOrg, boolean stockedOnly, String orgid, String inventoryMboName, List statusesInv)
/* 190:    */     throws MobileApplicationException
/* 191:    */   {
/* 192:217 */     applyItemOrgInfoFilter(itemOrgInfoMboName, statusesItemOrg, stockedOnly, orgid, inventoryMboName, statusesInv, null, null);
/* 193:    */   }
/* 194:    */   
/* 195:    */   public void applyItemOrgInfoFilter(String itemOrgInfoMboName, List statusesItemOrg, String orgid)
/* 196:    */     throws MobileApplicationException
/* 197:    */   {
/* 198:222 */     applyItemOrgInfoFilter(itemOrgInfoMboName, statusesItemOrg, false, orgid, null, null);
/* 199:    */   }
/* 200:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.mobilewo.ItemFilter
 * JD-Core Version:    0.7.0.1
 */