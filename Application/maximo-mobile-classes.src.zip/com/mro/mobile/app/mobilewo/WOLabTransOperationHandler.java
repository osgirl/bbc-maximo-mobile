/*  1:   */ package com.mro.mobile.app.mobilewo;
/*  2:   */ 
/*  3:   */ import com.mro.mobile.MobileApplicationException;
/*  4:   */ import com.mro.mobile.mbo.MobileMbo;
/*  5:   */ import com.mro.mobile.ui.MobileMboDataBean;
/*  6:   */ 
/*  7:   */ public class WOLabTransOperationHandler
/*  8:   */   extends CommonLabTransOperationHandler
/*  9:   */ {
/* 10:   */   protected void setSpecificValues(MobileMboDataBean targetBean, MobileMboDataBean sourceBean)
/* 11:   */     throws MobileApplicationException
/* 12:   */   {
/* 13:27 */     MobileMbo targetMbo = targetBean.getMobileMbo();
/* 14:28 */     MobileMbo sourceMbo = sourceBean.getMobileMbo();
/* 15:   */     
/* 16:30 */     targetMbo.setValue("REFWO", sourceMbo.getValue("REFWO"));
/* 17:31 */     targetMbo.setValue("ACTUALSTASKID", sourceMbo.getValue("ACTUALSTASKID"));
/* 18:32 */     targetMbo.setValue("WOCLASS", sourceMbo.getValue("WOCLASS"));
/* 19:33 */     targetMbo.setValue("RECORDCLASS", sourceMbo.getValue("WOCLASS"));
/* 20:34 */     targetMbo.setValue("RECORD", sourceMbo.getValue("REFWO"), true);
/* 21:   */     
/* 22:   */ 
/* 23:37 */     targetMbo.setValue("NAME", getLaborDisplayName(sourceMbo.getValue("LABORCODE"), sourceMbo.getValue("ORGID")));
/* 24:   */   }
/* 25:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.mobilewo.WOLabTransOperationHandler
 * JD-Core Version:    0.7.0.1
 */