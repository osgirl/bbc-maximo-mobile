/*   1:    */ package com.mro.mobile.app.mobilewo;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.app.OperationHandler;
/*   5:    */ import com.mro.mobile.mbo.MobileMbo;
/*   6:    */ import com.mro.mobile.mbo.MobileMboQBE;
/*   7:    */ import com.mro.mobile.persist.RDO;
/*   8:    */ import com.mro.mobile.ui.DataBeanCache;
/*   9:    */ import com.mro.mobile.ui.MobileMboDataBean;
/*  10:    */ import com.mro.mobile.ui.MobileMboDataBeanManager;
/*  11:    */ 
/*  12:    */ public abstract class CommonLabTransOperationHandler
/*  13:    */   extends MobileWOOperationHandler
/*  14:    */   implements OperationHandler
/*  15:    */ {
/*  16:    */   public void handleOperation(String operationName, MobileMboDataBean dataBean, int index)
/*  17:    */     throws MobileApplicationException
/*  18:    */   {
/*  19: 30 */     if (operationName.equals("save"))
/*  20:    */     {
/*  21: 33 */       MobileMbo modifiedMbo = dataBean.getMobileMbo(index);
/*  22:    */       
/*  23: 35 */       dataBean.setCurrentPosition(index);
/*  24:    */       
/*  25: 37 */       MobileMboDataBean labTransBean = DataBeanCache.getDataBean("LABTRANS", "LABTRANS");
/*  26: 39 */       if (modifiedMbo.isToBeDeleted())
/*  27:    */       {
/*  28: 41 */         int position = findMboInLabTrans(labTransBean, modifiedMbo);
/*  29: 42 */         if (position > -1)
/*  30:    */         {
/*  31: 44 */           labTransBean.deleteLocal(position);
/*  32: 45 */           labTransBean.getDataBeanManager().save();
/*  33:    */         }
/*  34:    */       }
/*  35: 48 */       else if (modifiedMbo.isToBeInserted())
/*  36:    */       {
/*  37: 50 */         int position = findMboInLabTrans(labTransBean, modifiedMbo);
/*  38: 52 */         if (position == -1)
/*  39:    */         {
/*  40: 54 */           labTransBean.insert();
/*  41: 55 */           copyMboValues(labTransBean, dataBean);
/*  42: 56 */           labTransBean.getDataBeanManager().save();
/*  43:    */         }
/*  44:    */       }
/*  45: 59 */       else if (modifiedMbo.isToBeUpdated())
/*  46:    */       {
/*  47: 61 */         int position = findMboInLabTrans(labTransBean, modifiedMbo);
/*  48: 62 */         if (position > -1)
/*  49:    */         {
/*  50: 64 */           labTransBean.setCurrentPosition(position);
/*  51: 65 */           copyMboValues(labTransBean, dataBean);
/*  52: 66 */           labTransBean.getDataBeanManager().save();
/*  53:    */         }
/*  54:    */       }
/*  55:    */     }
/*  56:    */   }
/*  57:    */   
/*  58:    */   public void copyMboValues(MobileMboDataBean targetBean, MobileMboDataBean sourceBean)
/*  59:    */     throws MobileApplicationException
/*  60:    */   {
/*  61: 79 */     setCommonFields(targetBean, sourceBean);
/*  62: 80 */     setSpecificValues(targetBean, sourceBean);
/*  63: 81 */     setFlags(targetBean, sourceBean);
/*  64:    */   }
/*  65:    */   
/*  66:    */   protected abstract void setSpecificValues(MobileMboDataBean paramMobileMboDataBean1, MobileMboDataBean paramMobileMboDataBean2)
/*  67:    */     throws MobileApplicationException;
/*  68:    */   
/*  69:    */   protected void setCommonFields(MobileMboDataBean targetBean, MobileMboDataBean sourceBean)
/*  70:    */     throws MobileApplicationException
/*  71:    */   {
/*  72: 92 */     MobileMbo targetMbo = targetBean.getMobileMbo();
/*  73: 93 */     MobileMbo sourceMbo = sourceBean.getMobileMbo();
/*  74:    */     
/*  75: 95 */     targetMbo.setValue("SITEID", sourceMbo.getValue("SITEID"));
/*  76: 96 */     targetMbo.setValue("LABORCODE", sourceMbo.getValue("LABORCODE"));
/*  77: 97 */     targetMbo.setValue("ORGID", sourceMbo.getValue("ORGID"));
/*  78: 98 */     targetMbo.setValue("CONTRACTNUM", sourceMbo.getValue("CONTRACTNUM"));
/*  79: 99 */     targetMbo.setValue("CRAFT", sourceMbo.getValue("CRAFT"));
/*  80:100 */     targetMbo.setValue("SKILLLEVEL", sourceMbo.getValue("SKILLLEVEL"));
/*  81:101 */     targetMbo.setValue("VENDOR", sourceMbo.getValue("VENDOR"));
/*  82:102 */     targetMbo.setValue("REVISIONNUM", sourceMbo.getValue("REVISIONNUM"));
/*  83:103 */     targetMbo.setDateValue("STARTDATE", sourceMbo.getDateValue("STARTDATE"), false);
/*  84:104 */     targetMbo.setValue("STARTTIME", sourceMbo.getValue("STARTTIME"));
/*  85:105 */     targetMbo.setDateValue("FINISHDATE", sourceMbo.getDateValue("FINISHDATE"), false);
/*  86:106 */     targetMbo.setValue("FINISHTIME", sourceMbo.getValue("FINISHTIME"));
/*  87:107 */     targetMbo.setValue("REGULARHRS", sourceMbo.getValue("REGULARHRS"));
/*  88:108 */     targetMbo.setValue("PREMIUMPAYCODE", sourceMbo.getValue("PREMIUMPAYCODE"));
/*  89:109 */     targetMbo.setValue("PREMIUMPAYHOURS", sourceMbo.getValue("PREMIUMPAYHOURS"));
/*  90:110 */     targetMbo.setValue("TIMERSTATUS", sourceMbo.getValue("TIMERSTATUS"));
/*  91:111 */     targetMbo.setValue("TRANSTYPE", sourceMbo.getValue("TRANSTYPE"));
/*  92:112 */     targetMbo.setValue("STARTDATETIME", sourceMbo.getValue("STARTDATETIME"));
/*  93:113 */     targetMbo.setValue("FINISHDATETIME", sourceMbo.getValue("FINISHDATETIME"));
/*  94:114 */     targetMbo.setValue("ISLASTINSERTED", sourceMbo.getValue("ISLASTINSERTED"));
/*  95:115 */     targetMbo.setValue("GENAPPRSERVRECEIPT", sourceMbo.getValue("GENAPPRSERVRECEIPT"));
/*  96:116 */     targetMbo.setValue("ISNEW", sourceMbo.isNew() ? "1" : "0");
/*  97:117 */     targetMbo.setValue("ORIGINALRECORDID", sourceMbo.getValue("_ID"));
/*  98:    */   }
/*  99:    */   
/* 100:    */   protected void setFlags(MobileMboDataBean targetBean, MobileMboDataBean sourceBean)
/* 101:    */     throws MobileApplicationException
/* 102:    */   {
/* 103:124 */     MobileMbo targetMbo = targetBean.getMobileMbo();
/* 104:125 */     MobileMbo sourceMbo = sourceBean.getMobileMbo();
/* 105:    */     
/* 106:    */ 
/* 107:    */ 
/* 108:129 */     targetMbo.getRDO().setBooleanValue("_NEW", sourceMbo.getBooleanValue("_NEW"));
/* 109:130 */     targetMbo.getRDO().setBooleanValue("_MODIFIED", sourceMbo.getBooleanValue("_MODIFIED"));
/* 110:    */   }
/* 111:    */   
/* 112:    */   public String getLaborDisplayName(String laborCode, String orgId)
/* 113:    */     throws MobileApplicationException
/* 114:    */   {
/* 115:136 */     MobileMboDataBeanManager dmgr = new MobileMboDataBeanManager("LABORCRAFTRATE");
/* 116:137 */     MobileMboDataBean dataBean = dmgr.getDataBean();
/* 117:138 */     dataBean.getQBE().setQBE("LABORCODE", laborCode);
/* 118:139 */     dataBean.getQBE().setQBE("ORGID", orgId);
/* 119:140 */     dataBean.reset();
/* 120:142 */     if (dataBean.count() > 0) {
/* 121:144 */       return dataBean.getValue("LABOR_DISPLAYNAME");
/* 122:    */     }
/* 123:147 */     return "";
/* 124:    */   }
/* 125:    */   
/* 126:    */   private int findMboInLabTrans(MobileMboDataBean labTransDataBean, MobileMbo modifiedMbo)
/* 127:    */     throws MobileApplicationException
/* 128:    */   {
/* 129:159 */     int count = labTransDataBean.count();
/* 130:160 */     if (count > 0)
/* 131:    */     {
/* 132:162 */       int curPos = labTransDataBean.getCurrentPosition();
/* 133:164 */       if (curPos > -1) {
/* 134:166 */         if (compareLabTrans(labTransDataBean, modifiedMbo, curPos)) {
/* 135:167 */           return labTransDataBean.getCurrentPosition();
/* 136:    */         }
/* 137:    */       }
/* 138:170 */       for (int i = 0; i < count; i++) {
/* 139:172 */         if (compareLabTrans(labTransDataBean, modifiedMbo, i)) {
/* 140:174 */           return i;
/* 141:    */         }
/* 142:    */       }
/* 143:    */     }
/* 144:178 */     return -1;
/* 145:    */   }
/* 146:    */   
/* 147:    */   private boolean compareLabTrans(MobileMboDataBean labTransDataBean, MobileMbo modifiedMbo, int index)
/* 148:    */     throws MobileApplicationException
/* 149:    */   {
/* 150:191 */     if ((labTransDataBean.getMobileMbo(index).getValue("ORIGINALRECORDID").equals(modifiedMbo.getValue("_ID"))) && ((labTransDataBean.getMobileMbo(index).getValue("RECORD").equalsIgnoreCase(modifiedMbo.getValue("TICKETID"))) || (labTransDataBean.getMobileMbo(index).getValue("RECORD").equalsIgnoreCase(modifiedMbo.getValue("REFWO")))) && (labTransDataBean.getMobileMbo(index).getValue("SITEID").equalsIgnoreCase(modifiedMbo.getValue("SITEID")))) {
/* 151:196 */       return true;
/* 152:    */     }
/* 153:198 */     return false;
/* 154:    */   }
/* 155:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.mobilewo.CommonLabTransOperationHandler
 * JD-Core Version:    0.7.0.1
 */