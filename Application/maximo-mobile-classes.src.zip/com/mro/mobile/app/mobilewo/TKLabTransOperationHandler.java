/*  1:   */ package com.mro.mobile.app.mobilewo;
/*  2:   */ 
/*  3:   */ import com.mro.mobile.MobileApplicationException;
/*  4:   */ import com.mro.mobile.mbo.MobileMbo;
/*  5:   */ import com.mro.mobile.ui.MobileMboDataBean;
/*  6:   */ 
/*  7:   */ public class TKLabTransOperationHandler
/*  8:   */   extends CommonLabTransOperationHandler
/*  9:   */ {
/* 10:   */   protected void setSpecificValues(MobileMboDataBean targetBean, MobileMboDataBean sourceBean)
/* 11:   */     throws MobileApplicationException
/* 12:   */   {
/* 13:27 */     MobileMbo targetMbo = targetBean.getMobileMbo();
/* 14:28 */     MobileMbo sourceMbo = sourceBean.getMobileMbo();
/* 15:   */     
/* 16:   */ 
/* 17:31 */     String ticketId = sourceMbo.getValue("TICKETID");
/* 18:32 */     if ((ticketId != null) && (ticketId.length() > 0))
/* 19:   */     {
/* 20:34 */       targetMbo.setValue("TICKETID", ticketId);
/* 21:35 */       targetMbo.setValue("TICKETCLASS", sourceMbo.getValue("TICKETCLASS"));
/* 22:36 */       targetMbo.setValue("RECORDCLASS", sourceMbo.getValue("TICKETCLASS"));
/* 23:37 */       targetMbo.setValue("RECORD", ticketId, true);
/* 24:   */     }
/* 25:   */     else
/* 26:   */     {
/* 27:41 */       targetMbo.setValue("REFWO", sourceMbo.getValue("REFWO"));
/* 28:42 */       targetMbo.setValue("WOCLASS", sourceMbo.getValue("WOCLASS"));
/* 29:43 */       targetMbo.setValue("RECORDCLASS", sourceMbo.getValue("WOCLASS"));
/* 30:44 */       targetMbo.setValue("RECORD", sourceMbo.getValue("REFWO"), true);
/* 31:   */     }
/* 32:48 */     targetMbo.setValue("NAME", getLaborDisplayName(sourceMbo.getValue("LABORCODE"), sourceMbo.getValue("ORGID")));
/* 33:   */   }
/* 34:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.mobilewo.TKLabTransOperationHandler
 * JD-Core Version:    0.7.0.1
 */