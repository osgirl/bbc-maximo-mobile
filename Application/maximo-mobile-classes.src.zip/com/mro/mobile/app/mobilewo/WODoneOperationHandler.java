/*  1:   */ package com.mro.mobile.app.mobilewo;
/*  2:   */ 
/*  3:   */ import com.mro.mobile.MobileApplicationException;
/*  4:   */ import com.mro.mobile.app.OperationHandler;
/*  5:   */ import com.mro.mobile.mbo.MobileMboQBE;
/*  6:   */ import com.mro.mobile.ui.MobileMboDataBean;
/*  7:   */ import com.mro.mobile.ui.MobileMboDataBeanManager;
/*  8:   */ 
/*  9:   */ public class WODoneOperationHandler
/* 10:   */   extends MobileWOOperationHandler
/* 11:   */   implements OperationHandler
/* 12:   */ {
/* 13:   */   public void handleOperation(String operationName, MobileMboDataBean dataBean, int index)
/* 14:   */     throws MobileApplicationException
/* 15:   */   {
/* 16:27 */     if (!dataBean.getName().equals("WORKORDER")) {
/* 17:28 */       return;
/* 18:   */     }
/* 19:30 */     if (operationName.equals("done"))
/* 20:   */     {
/* 21:33 */       String wonum = dataBean.getValue(index, "WONUM");
/* 22:34 */       String siteid = dataBean.getValue(index, "SITEID");
/* 23:   */       
/* 24:   */ 
/* 25:37 */       MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager("MR");
/* 26:38 */       MobileMboDataBean mrBean = mgrDBMgr.getDataBean();
/* 27:   */       
/* 28:40 */       mrBean.getQBE().reset();
/* 29:41 */       mrBean.getQBE().setQbeExactMatch(true);
/* 30:42 */       mrBean.getQBE().setQBE("WONUM", wonum);
/* 31:43 */       mrBean.getQBE().setQBE("SITEID", siteid);
/* 32:44 */       mrBean.reset();
/* 33:45 */       mrBean.doneAll();
/* 34:   */       
/* 35:   */ 
/* 36:48 */       cleanUpPendingStatusChange(wonum, siteid, "WONUM");
/* 37:   */       
/* 38:   */ 
/* 39:51 */       cleanUpWOLabTransRecords(wonum, siteid);
/* 40:   */     }
/* 41:54 */     else if (operationName.equals("undo"))
/* 42:   */     {
/* 43:57 */       String wonum = dataBean.getValue(index, "WONUM");
/* 44:58 */       String siteid = dataBean.getValue(index, "SITEID");
/* 45:   */       
/* 46:   */ 
/* 47:61 */       MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager("MR");
/* 48:62 */       MobileMboDataBean mrBean = mgrDBMgr.getDataBean();
/* 49:   */       
/* 50:64 */       mrBean.getQBE().reset();
/* 51:65 */       mrBean.getQBE().setQbeExactMatch(true);
/* 52:66 */       mrBean.getQBE().setQBE("WONUM", wonum);
/* 53:67 */       mrBean.getQBE().setQBE("SITEID", siteid);
/* 54:68 */       mrBean.reset();
/* 55:69 */       int count = mrBean.count();
/* 56:70 */       for (int i = count - 1; i >= 0; i--) {
/* 57:72 */         mrBean.deleteLocal(i);
/* 58:   */       }
/* 59:74 */       mrBean.getDataBeanManager().save();
/* 60:   */       
/* 61:   */ 
/* 62:77 */       cleanUpPendingStatusChange(wonum, siteid, "WONUM");
/* 63:   */       
/* 64:   */ 
/* 65:80 */       cleanUpTaskHistory(wonum, siteid);
/* 66:   */     }
/* 67:83 */     if (operationName.equals("save")) {
/* 68:85 */       super.handleOperation(operationName, dataBean, index);
/* 69:   */     }
/* 70:   */   }
/* 71:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.mobilewo.WODoneOperationHandler
 * JD-Core Version:    0.7.0.1
 */