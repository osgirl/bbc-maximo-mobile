/*  1:   */ package com.mro.mobile.app.mobilewo;
/*  2:   */ 
/*  3:   */ import com.mro.mobile.MobileApplicationException;
/*  4:   */ import com.mro.mobile.app.async.AsyncEventHandlerSupport;
/*  5:   */ import com.mro.mobile.ui.MobileMboDataBean;
/*  6:   */ import com.mro.mobile.ui.event.UIEvent;
/*  7:   */ import com.mro.mobile.ui.res.UIUtil;
/*  8:   */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*  9:   */ 
/* 10:   */ public class AssetMenuBarEventHandler
/* 11:   */   extends MobileWOCommonEventHandler
/* 12:   */ {
/* 13:   */   public boolean performEvent(UIEvent event)
/* 14:   */     throws MobileApplicationException
/* 15:   */   {
/* 16:25 */     if (event == null) {
/* 17:25 */       return false;
/* 18:   */     }
/* 19:27 */     String eventId = event.getEventName();
/* 20:29 */     if (eventId.equalsIgnoreCase("done")) {
/* 21:31 */       return done(event);
/* 22:   */     }
/* 23:34 */     super.performEvent(event);
/* 24:   */     
/* 25:36 */     return false;
/* 26:   */   }
/* 27:   */   
/* 28:   */   public boolean done(UIEvent event)
/* 29:   */     throws MobileApplicationException
/* 30:   */   {
/* 31:41 */     new AsyncEventHandlerSupport()
/* 32:   */     {
/* 33:   */       public boolean doRealWok(UIEvent event)
/* 34:   */         throws MobileApplicationException
/* 35:   */       {
/* 36:44 */         super.updateProgressBar("processdatainprogress", null, event);
/* 37:45 */         getDataBeanOfCurrentScreen().done();
/* 38:46 */         return true;
/* 39:   */       }
/* 40:   */       
/* 41:   */       public void postRealWork(UIEvent event)
/* 42:   */         throws MobileApplicationException
/* 43:   */       {
/* 44:50 */         String listpage = UIUtil.getCurrentScreen().getParentControl().getStringValue("listpage");
/* 45:51 */         if (listpage != null) {
/* 46:52 */           UIUtil.showPage(listpage);
/* 47:   */         }
/* 48:   */       }
/* 49:52 */     }.handleInBackground(event);
/* 50:   */     
/* 51:   */ 
/* 52:55 */     return true;
/* 53:   */   }
/* 54:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.mobilewo.AssetMenuBarEventHandler
 * JD-Core Version:    0.7.0.1
 */