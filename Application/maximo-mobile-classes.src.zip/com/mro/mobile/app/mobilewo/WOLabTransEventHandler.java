/*    1:     */ package com.mro.mobile.app.mobilewo;
/*    2:     */ 
/*    3:     */ import com.mro.mobile.MobileApplicationException;
/*    4:     */ import com.mro.mobile.app.BasicMobileDeviceUIApplication;
/*    5:     */ import com.mro.mobile.app.CurrentTimeProvider;
/*    6:     */ import com.mro.mobile.app.DefaultMobileMboDataFormatter;
/*    7:     */ import com.mro.mobile.mbo.MobileMbo;
/*    8:     */ import com.mro.mobile.mbo.MobileMboQBE;
/*    9:     */ import com.mro.mobile.ui.DataBeanCache;
/*   10:     */ import com.mro.mobile.ui.MobileMboDataBean;
/*   11:     */ import com.mro.mobile.ui.MobileMboDataBeanManager;
/*   12:     */ import com.mro.mobile.ui.UIHandlerManager;
/*   13:     */ import com.mro.mobile.ui.event.UIEvent;
/*   14:     */ import com.mro.mobile.ui.res.UIUtil;
/*   15:     */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*   16:     */ import com.mro.mobile.ui.res.controls.PageControl;
/*   17:     */ import com.mro.mobile.ui.res.controls.TextboxControl;
/*   18:     */ import com.mro.mobileapp.WOApp;
/*   19:     */ import java.util.Calendar;
/*   20:     */ import java.util.Date;
/*   21:     */ import java.util.HashSet;
/*   22:     */ import java.util.Iterator;
/*   23:     */ import java.util.Locale;
/*   24:     */ import java.util.Set;
/*   25:     */ import java.util.TimeZone;
/*   26:     */ 
/*   27:     */ public class WOLabTransEventHandler
/*   28:     */   extends MobileWOCommonEventHandler
/*   29:     */ {
/*   30:  45 */   private boolean wotaskvisibility = false;
/*   31:  46 */   private boolean hasChangedSinceLastTotalsDisplay = false;
/*   32:     */   
/*   33:     */   public boolean performEvent(UIEvent event)
/*   34:     */     throws MobileApplicationException
/*   35:     */   {
/*   36:  50 */     if (event == null) {
/*   37:  50 */       return false;
/*   38:     */     }
/*   39:  52 */     String eventId = event.getEventName();
/*   40:  54 */     if (eventId.equalsIgnoreCase("initpage")) {
/*   41:  56 */       return initpage(event);
/*   42:     */     }
/*   43:  58 */     if (eventId.equalsIgnoreCase("validatepage")) {
/*   44:  60 */       return validatepage(event);
/*   45:     */     }
/*   46:  62 */     if (eventId.equalsIgnoreCase("insertlabactual")) {
/*   47:  64 */       return insertlabactual(event);
/*   48:     */     }
/*   49:  66 */     if (eventId.equalsIgnoreCase("validatelaborfield")) {
/*   50:  68 */       return validatelaborfield(event);
/*   51:     */     }
/*   52:  70 */     if (eventId.equalsIgnoreCase("validatelabtransfield")) {
/*   53:  72 */       return validatelabtransfield(event);
/*   54:     */     }
/*   55:  74 */     if (eventId.equalsIgnoreCase("initpage_stoptimer")) {
/*   56:  76 */       return initpage_stoptimer(event);
/*   57:     */     }
/*   58:  78 */     if (eventId.equalsIgnoreCase("initpage_stopthenstarttimer")) {
/*   59:  80 */       return initpage_stopthenstarttimer(event);
/*   60:     */     }
/*   61:  82 */     if (eventId.equalsIgnoreCase("validatepage_stoptimer"))
/*   62:     */     {
/*   63:  84 */       boolean bRet = validatepage_stoptimer(event, false, UIUtil.getCurrentScreen().getDataBean());
/*   64:  85 */       if (!event.errorOccured())
/*   65:     */       {
/*   66:  88 */         UIUtil.refreshCurrentScreen();
/*   67:  89 */         ((PageControl)UIUtil.getCurrentScreen()).refresh(event);
/*   68:     */       }
/*   69:  91 */       return bRet;
/*   70:     */     }
/*   71:  93 */     if (eventId.equalsIgnoreCase("validatepage_stopstarttimer")) {
/*   72:  95 */       return validatepage_stopstarttimer(event);
/*   73:     */     }
/*   74:  97 */     if (eventId.equalsIgnoreCase("validate_startdate")) {
/*   75:  99 */       return validate_startdate(event);
/*   76:     */     }
/*   77: 101 */     if (eventId.equalsIgnoreCase("validate_enddate")) {
/*   78: 103 */       return validate_enddate(event);
/*   79:     */     }
/*   80: 105 */     if (eventId.equalsIgnoreCase("validate_reghours")) {
/*   81: 107 */       return validate_reghours(event);
/*   82:     */     }
/*   83: 109 */     if (eventId.equalsIgnoreCase("validate_ppc")) {
/*   84: 111 */       return validate_ppc(event);
/*   85:     */     }
/*   86: 113 */     if (eventId.equalsIgnoreCase("initpagePPC")) {
/*   87: 115 */       return initpagePPC(event);
/*   88:     */     }
/*   89: 117 */     if (eventId.equalsIgnoreCase("save")) {
/*   90: 119 */       return save(event);
/*   91:     */     }
/*   92: 122 */     if (eventId.equalsIgnoreCase("totalhourscalc")) {
/*   93: 123 */       return totalHoursCalc(event);
/*   94:     */     }
/*   95: 126 */     if (eventId.equalsIgnoreCase("filter")) {
/*   96: 128 */       return filter(event);
/*   97:     */     }
/*   98: 132 */     return super.performEvent(event);
/*   99:     */   }
/*  100:     */   
/*  101:     */   protected boolean filter(UIEvent event)
/*  102:     */     throws MobileApplicationException
/*  103:     */   {
/*  104: 139 */     AbstractMobileControl curPage = UIUtil.getCurrentScreen();
/*  105: 140 */     if (curPage.getId().equalsIgnoreCase("ppcodefilter"))
/*  106:     */     {
/*  107: 142 */       MobileMboDataBean databean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*  108:     */       
/*  109: 144 */       databean.getQBE().setQbeExactMatch(false);
/*  110:     */     }
/*  111: 147 */     return false;
/*  112:     */   }
/*  113:     */   
/*  114:     */   private boolean totalHoursCalc(UIEvent event)
/*  115:     */     throws MobileApplicationException
/*  116:     */   {
/*  117: 159 */     MobileMboDataBean parentDataBean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*  118:     */     
/*  119: 161 */     double tolerance = 0.001D;
/*  120: 164 */     if (("WOLABTRANS".equals(parentDataBean.getName())) || ("TKLABTRANS".equals(parentDataBean.getName()))) {
/*  121: 166 */       parentDataBean = parentDataBean.getParentBean();
/*  122:     */     }
/*  123: 168 */     MobileMboDataBean wotkDatabean = null;
/*  124: 169 */     String key = null;
/*  125: 171 */     if (isWorkorder(parentDataBean.getName())) {
/*  126: 175 */       wotkDatabean = parentDataBean.getDataBean("WOLABTRANS");
/*  127: 176 */     } else if (isTicket(parentDataBean.getName())) {
/*  128: 181 */       wotkDatabean = parentDataBean.getDataBean("TKLABTRANS");
/*  129:     */     }
/*  130: 184 */     double hours = 0.0D;
/*  131: 185 */     if (wotkDatabean != null)
/*  132:     */     {
/*  133: 187 */       int size = wotkDatabean.count();
/*  134: 188 */       for (int count = 0; count < size; count++)
/*  135:     */       {
/*  136: 189 */         MobileMbo mbo = wotkDatabean.getMobileMbo(count);
/*  137: 190 */         if (mbo.getValue("REGULARHRS").length() > 0) {
/*  138: 191 */           hours += Double.parseDouble(mbo.getValue("REGULARHRS"));
/*  139:     */         }
/*  140: 193 */         if (mbo.getValue("PREMIUMPAYHOURS").length() > 0) {
/*  141: 194 */           hours += Double.parseDouble(mbo.getValue("PREMIUMPAYHOURS"));
/*  142:     */         }
/*  143:     */       }
/*  144:     */     }
/*  145: 201 */     if (Math.ceil(hours) - hours < 0.001D) {
/*  146: 203 */       hours = Math.ceil(hours);
/*  147:     */     }
/*  148: 205 */     parentDataBean.setValue("TOTALHOURS", new Double(hours).toString());
/*  149:     */     
/*  150: 207 */     return true;
/*  151:     */   }
/*  152:     */   
/*  153:     */   protected boolean isTicket(String recordclass)
/*  154:     */   {
/*  155: 216 */     if (("TICKET".equalsIgnoreCase(recordclass)) || ("SR".equalsIgnoreCase(recordclass)) || ("INCIDENT".equalsIgnoreCase(recordclass)) || ("PROBLEM".equalsIgnoreCase(recordclass))) {
/*  156: 218 */       return true;
/*  157:     */     }
/*  158: 220 */     return false;
/*  159:     */   }
/*  160:     */   
/*  161:     */   protected boolean isWorkorder(String recordclass)
/*  162:     */   {
/*  163: 230 */     if (("WORKORDER".equalsIgnoreCase(recordclass)) || ("CHANGE".equalsIgnoreCase(recordclass)) || ("REVISIONNUM".equalsIgnoreCase(recordclass)) || ("RELEASE".equalsIgnoreCase(recordclass)) || ("ACTIVITY".equalsIgnoreCase(recordclass))) {
/*  164: 232 */       return true;
/*  165:     */     }
/*  166: 234 */     return false;
/*  167:     */   }
/*  168:     */   
/*  169:     */   public boolean initpage(UIEvent event)
/*  170:     */     throws MobileApplicationException
/*  171:     */   {
/*  172: 242 */     MobileMboDataBean databean = ((PageControl)event.getCreatingObject()).getDataBean();
/*  173: 244 */     if ((databean != null) && ((!databean.getValue("STARTDATE").equals("")) || (!databean.getValue("STARTTIME").equals("")))) {
/*  174: 245 */       databean.setValue("STARTDATETIME", databean.getValue("STARTDATE") + " " + databean.getValue("STARTTIME"));
/*  175:     */     }
/*  176: 247 */     if ((databean != null) && ((!databean.getValue("FINISHDATE").equals("")) || (!databean.getValue("FINISHTIME").equals("")))) {
/*  177: 248 */       databean.setValue("FINISHDATETIME", databean.getValue("FINISHDATE") + " " + databean.getValue("FINISHTIME"));
/*  178:     */     }
/*  179: 250 */     if ((databean != null) && (databean.getMobileMbo() != null) && (((!"LABTRANS".equals(databean.getName())) && (!databean.getMobileMbo().isNew())) || (("LABTRANS".equals(databean.getName())) && ("0".equals(databean.getValue("ISNEW")))))) {
/*  180: 254 */       databean.getMobileMbo().setReadOnly(true);
/*  181:     */     }
/*  182: 257 */     if ((databean != null) && (isWorkorder(((WOApp)UIUtil.getApplication()).getInternalValue(databean, "WOCLASS", databean.getValue("RECORDCLASS"))))) {
/*  183: 258 */       this.wotaskvisibility = true;
/*  184:     */     } else {
/*  185: 260 */       this.wotaskvisibility = false;
/*  186:     */     }
/*  187: 263 */     return true;
/*  188:     */   }
/*  189:     */   
/*  190:     */   protected void updateLastInsertedTkWoLabTrans()
/*  191:     */     throws MobileApplicationException
/*  192:     */   {
/*  193: 274 */     MobileMboDataBean lastInsertedLabTransDataBean = getDataBean("LABTRANS", "ISLASTINSERTED", "1");
/*  194: 275 */     if (lastInsertedLabTransDataBean.count() == 1)
/*  195:     */     {
/*  196: 277 */       String lastCreatedMboName = isWorkorder(((WOApp)UIUtil.getApplication()).getInternalValue(lastInsertedLabTransDataBean, "WOCLASS", lastInsertedLabTransDataBean.getValue("RECORDCLASS"))) ? "WOLABTRANS" : "TKLABTRANS";
/*  197: 278 */       MobileMboDataBean lastInsertedWOTKDataBean = getDataBean(lastCreatedMboName, "_ID", lastInsertedLabTransDataBean.getMobileMbo().getValue("ORIGINALRECORDID"));
/*  198: 279 */       lastInsertedLabTransDataBean.getMobileMbo().setValue("ISLASTINSERTED", "0");
/*  199: 280 */       lastInsertedWOTKDataBean.getMobileMbo().setValue("ISLASTINSERTED", "0");
/*  200: 281 */       lastInsertedWOTKDataBean.getDataBeanManager().save();
/*  201: 282 */       lastInsertedLabTransDataBean.getDataBeanManager().save();
/*  202:     */     }
/*  203:     */   }
/*  204:     */   
/*  205:     */   protected MobileMboDataBean getDataBean(String name, String[] columnname, String[] value)
/*  206:     */     throws MobileApplicationException
/*  207:     */   {
/*  208: 296 */     MobileMboDataBean persondatabean = new MobileMboDataBeanManager(name).getDataBean();
/*  209: 297 */     if ((columnname != null) && (value != null))
/*  210:     */     {
/*  211: 298 */       persondatabean.reset();
/*  212: 299 */       persondatabean.getQBE().setQbeExactMatch(true);
/*  213: 300 */       for (int count = 0; count < value.length; count++) {
/*  214: 301 */         persondatabean.getQBE().setQBE(columnname[count], value[count]);
/*  215:     */       }
/*  216: 303 */       persondatabean.reset();
/*  217:     */     }
/*  218: 305 */     return persondatabean;
/*  219:     */   }
/*  220:     */   
/*  221:     */   protected MobileMboDataBean getDataBean(String name, String columnName, String attributeKey)
/*  222:     */     throws MobileApplicationException
/*  223:     */   {
/*  224: 317 */     return getDataBean(name, new String[] { columnName }, new String[] { attributeKey });
/*  225:     */   }
/*  226:     */   
/*  227:     */   protected MobileMboDataBean getDataBean(String name)
/*  228:     */     throws MobileApplicationException
/*  229:     */   {
/*  230: 327 */     String[] columnName = null;
/*  231: 328 */     String[] attributeKey = null;
/*  232: 329 */     return getDataBean(name, columnName, attributeKey);
/*  233:     */   }
/*  234:     */   
/*  235:     */   protected boolean createRecordClassList(String[] getFromName, String[] getFromColumnName)
/*  236:     */     throws MobileApplicationException
/*  237:     */   {
/*  238: 340 */     MobileMboDataBeanManager mgr = new MobileMboDataBeanManager("TKWOCLASS");
/*  239: 341 */     MobileMboDataBean tkwoclassbean = mgr.getDataBean();
/*  240:     */     
/*  241: 343 */     Set classes = new HashSet();
/*  242: 344 */     for (int count = 0; count < getFromName.length; count++) {
/*  243: 345 */       addValuesFromColumn(classes, getFromName[count], getFromColumnName[count]);
/*  244:     */     }
/*  245: 347 */     deleteAllFromDataBean(tkwoclassbean);
/*  246:     */     
/*  247: 349 */     Iterator iterator = classes.iterator();
/*  248: 350 */     while (iterator.hasNext())
/*  249:     */     {
/*  250: 351 */       tkwoclassbean.insert();
/*  251: 352 */       tkwoclassbean.getMobileMbo().setValue("VALUE", iterator.next().toString());
/*  252:     */     }
/*  253: 354 */     mgr.save();
/*  254: 355 */     return true;
/*  255:     */   }
/*  256:     */   
/*  257:     */   protected void addValuesFromColumn(Set classes, String databeanname, String columnname)
/*  258:     */     throws MobileApplicationException
/*  259:     */   {
/*  260: 369 */     MobileMboDataBean databean = getDataBean(databeanname);
/*  261: 370 */     int size = databean.count();
/*  262: 371 */     for (int count = 0; count < size; count++) {
/*  263: 372 */       classes.add(databean.getMobileMbo(count).getValue(columnname));
/*  264:     */     }
/*  265:     */   }
/*  266:     */   
/*  267:     */   protected void deleteAllFromDataBean(MobileMboDataBean databean)
/*  268:     */     throws MobileApplicationException
/*  269:     */   {
/*  270: 384 */     for (int count = 0; count < databean.count(); count++) {
/*  271: 385 */       databean.getMobileMbo(count).deleteLocal();
/*  272:     */     }
/*  273: 387 */     databean.getDataBeanManager().save();
/*  274: 388 */     databean.reset();
/*  275:     */   }
/*  276:     */   
/*  277:     */   public boolean validatepage(UIEvent event)
/*  278:     */     throws MobileApplicationException
/*  279:     */   {
/*  280: 393 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/*  281: 395 */     if (databean.isMobileMboReadOnly()) {
/*  282: 397 */       return true;
/*  283:     */     }
/*  284: 401 */     MobileMboDataBean wodatabean = databean.getParentBean();
/*  285: 402 */     if (databean.getValue("ACTUALSTASKID").equals(""))
/*  286:     */     {
/*  287: 404 */       if (wodatabean.getValue("WOACCEPTSCHARGES").equals("0")) {
/*  288: 405 */         throw new MobileApplicationException("WOAcceptsChargesNo");
/*  289:     */       }
/*  290:     */     }
/*  291:     */     else
/*  292:     */     {
/*  293: 409 */       MobileMboDataBean wotasks = wodatabean.getDataBean("WOTASKS");
/*  294: 410 */       int count = wotasks.count();
/*  295: 411 */       for (int i = 0; i < count; i++) {
/*  296: 413 */         if (wotasks.getMobileMbo(i).getValue("TASKID").equals(databean.getValue("ACTUALSTASKID")))
/*  297:     */         {
/*  298: 415 */           if (!wotasks.getMobileMbo(i).getValue("WOACCEPTSCHARGES").equals("0")) {
/*  299:     */             break;
/*  300:     */           }
/*  301: 416 */           throw new MobileApplicationException("TaskAcceptsChargesNo");
/*  302:     */         }
/*  303:     */       }
/*  304:     */     }
/*  305: 425 */     if ("WOLABTRANS".equals(databean.getName()))
/*  306:     */     {
/*  307: 426 */       MobileMboDataBean parentBean = databean.getParentBean();
/*  308: 427 */       databean.setValue("REFWO", parentBean.getValue("WONUM"));
/*  309: 428 */       databean.setValue("WOCLASS", parentBean.getValue("WOCLASS"));
/*  310:     */       
/*  311: 430 */       updateLastInsertedTkWoLabTrans();
/*  312: 431 */       databean.setValue("ISLASTINSERTED", "1");
/*  313:     */     }
/*  314: 432 */     else if ("TKLABTRANS".equals(databean.getName()))
/*  315:     */     {
/*  316: 433 */       MobileMboDataBean parentBean = databean.getParentBean();
/*  317: 434 */       databean.setValue("TICKETID", parentBean.getValue("TICKETID"));
/*  318:     */       
/*  319:     */ 
/*  320: 437 */       String ticketClass = parentBean.getValue("TICKETCLASS");
/*  321: 438 */       if ((ticketClass != null) && (ticketClass.length() > 0)) {
/*  322: 439 */         databean.setValue("TICKETCLASS", ticketClass);
/*  323:     */       }
/*  324: 442 */       updateLastInsertedTkWoLabTrans();
/*  325: 443 */       databean.setValue("ISLASTINSERTED", "1");
/*  326:     */     }
/*  327: 448 */     MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager("LABORCRAFTRATE");
/*  328: 449 */     MobileMboDataBean lcrBean = mgrDBMgr.getDataBean();
/*  329: 451 */     if (databean.getValue("LABORCODE").equals("")) {
/*  330: 452 */       lcrBean.getQBE().setQBE("LABORCODE", "~NULL~");
/*  331:     */     } else {
/*  332: 454 */       lcrBean.getQBE().setQBE("LABORCODE", databean.getValue("LABORCODE"));
/*  333:     */     }
/*  334: 456 */     if (databean.getValue("CRAFT").equals("")) {
/*  335: 457 */       lcrBean.getQBE().setQBE("CRAFT", "~NULL~");
/*  336:     */     } else {
/*  337: 459 */       lcrBean.getQBE().setQBE("CRAFT", databean.getValue("CRAFT"));
/*  338:     */     }
/*  339: 461 */     if (databean.getValue("SKILLLEVEL").equals("")) {
/*  340: 462 */       lcrBean.getQBE().setQBE("SKILLLEVEL", "~NULL~");
/*  341:     */     } else {
/*  342: 464 */       lcrBean.getQBE().setQBE("SKILLLEVEL", databean.getValue("SKILLLEVEL"));
/*  343:     */     }
/*  344: 466 */     if (databean.getValue("VENDOR").equals("")) {
/*  345: 467 */       lcrBean.getQBE().setQBE("VENDOR", "~NULL~");
/*  346:     */     } else {
/*  347: 469 */       lcrBean.getQBE().setQBE("VENDOR", databean.getValue("VENDOR"));
/*  348:     */     }
/*  349: 471 */     if (databean.getValue("CONTRACTNUM").equals("")) {
/*  350: 472 */       lcrBean.getQBE().setQBE("CONTRACTNUM", "~NULL~");
/*  351:     */     } else {
/*  352: 474 */       lcrBean.getQBE().setQBE("CONTRACTNUM", databean.getValue("CONTRACTNUM"));
/*  353:     */     }
/*  354: 476 */     lcrBean.reset();
/*  355: 477 */     int count = lcrBean.count();
/*  356: 478 */     if (count == 0) {
/*  357: 480 */       throw new MobileApplicationException("invalidlcr");
/*  358:     */     }
/*  359: 484 */     String autoapprove = "0";
/*  360: 485 */     if (databean.getValue("VENDOR").equals("")) {
/*  361: 488 */       autoapprove = ((WOApp)UIUtil.getApplication()).getMaxVar(databean, "LR_APPR_IN_LABOR");
/*  362:     */     } else {
/*  363: 493 */       autoapprove = ((WOApp)UIUtil.getApplication()).getMaxVar(databean, "LR_APPR_OUT_LABOR");
/*  364:     */     }
/*  365: 495 */     databean.setValue("GENAPPRSERVRECEIPT", autoapprove);
/*  366:     */     
/*  367:     */ 
/*  368:     */ 
/*  369: 499 */     validateRegularOrPremiumHoursEntered(databean);
/*  370: 502 */     if ((databean.getValue("STARTDATETIME").equals("")) && (databean.getValue("FINISHDATETIME").equals(""))) {
/*  371: 506 */       databean.getMobileMbo().setDateValue("STARTDATETIME", databean.getCurrentTime());
/*  372:     */     }
/*  373: 510 */     double totalHrs = DefaultMobileMboDataFormatter.durationToDouble(databean.getValue("REGULARHRS"));
/*  374: 512 */     if (totalHrs > 0.0D) {
/*  375: 514 */       if ((!databean.getValue("STARTDATETIME").equals("")) && (!databean.getValue("FINISHDATETIME").equals("")) && (totalHrs > 0.0D))
/*  376:     */       {
/*  377: 517 */         double calHours = WOApp.calculateHours(databean.getMobileMbo().getDateValue("STARTDATETIME"), databean.getMobileMbo().getDateValue("FINISHDATETIME"));
/*  378: 521 */         if (totalHrs > calHours) {
/*  379: 523 */           throw new MobileApplicationException("toomanyhours");
/*  380:     */         }
/*  381:     */       }
/*  382:     */     }
/*  383: 529 */     String startdate = "";
/*  384: 530 */     String starttime = "";
/*  385: 531 */     String finishdate = "";
/*  386: 532 */     String finishtime = "";
/*  387:     */     
/*  388: 534 */     String startdatetime = databean.getValue("STARTDATETIME");
/*  389: 535 */     if (!startdatetime.equals(""))
/*  390:     */     {
/*  391: 537 */       startdate = startdatetime.substring(0, startdatetime.indexOf(" "));
/*  392: 538 */       starttime = startdatetime.substring(startdatetime.indexOf(" ") + 1);
/*  393:     */     }
/*  394: 541 */     String finishdatetime = databean.getValue("FINISHDATETIME");
/*  395: 542 */     if (!finishdatetime.equals(""))
/*  396:     */     {
/*  397: 544 */       finishdate = finishdatetime.substring(0, finishdatetime.indexOf(" "));
/*  398: 545 */       finishtime = finishdatetime.substring(finishdatetime.indexOf(" ") + 1);
/*  399:     */     }
/*  400: 548 */     databean.setValue("STARTDATE", startdate);
/*  401: 549 */     databean.setValue("STARTTIME", starttime);
/*  402: 550 */     databean.setValue("FINISHDATE", finishdate);
/*  403: 551 */     databean.setValue("FINISHTIME", finishtime);
/*  404: 554 */     if (!databean.isComplete()) {
/*  405: 555 */       databean.markComplete();
/*  406:     */     }
/*  407: 557 */     return true;
/*  408:     */   }
/*  409:     */   
/*  410:     */   protected void validateRegularOrPremiumHoursEntered(MobileMboDataBean databean)
/*  411:     */     throws MobileApplicationException
/*  412:     */   {
/*  413: 568 */     if ((databean.getValue("REGULARHRS").equals("")) && (databean.getValue("PREMIUMPAYHOURS").equals(""))) {
/*  414: 571 */       throw new MobileApplicationException("noHoursEntered");
/*  415:     */     }
/*  416:     */   }
/*  417:     */   
/*  418:     */   public boolean insertlabactual(UIEvent event)
/*  419:     */     throws MobileApplicationException
/*  420:     */   {
/*  421: 578 */     setHasChangedSinceLastTotalsDisplay(true);
/*  422: 579 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/*  423: 580 */     if (databean != null)
/*  424:     */     {
/*  425: 583 */       MobileMboDataBean parentBean = databean.getParentBean();
/*  426: 584 */       if (parentBean != null)
/*  427:     */       {
/*  428: 586 */         String parentSite = parentBean.getValue("SITEID");
/*  429: 587 */         if ((parentSite == null) || (parentSite.length() == 0)) {
/*  430: 590 */           throw new MobileApplicationException("siteidnull");
/*  431:     */         }
/*  432:     */       }
/*  433: 593 */       String name = databean.getName();
/*  434: 594 */       if ((name.equals("LABTRANS")) || (name.equals("WOLABTRANS")) || (name.equals("TKLABTRANS")))
/*  435:     */       {
/*  436: 596 */         databean.insert();
/*  437: 597 */         this.wotaskvisibility = false;
/*  438:     */         
/*  439: 599 */         databean.setValue("TRANSTYPE", ((WOApp)UIUtil.getApplication()).getDefaultValue(databean, "LTTYPE", "WORK"));
/*  440:     */         
/*  441:     */ 
/*  442: 602 */         String mylaborcode = null;
/*  443: 604 */         if ("TKLABTRANS".equals(name))
/*  444:     */         {
/*  445: 605 */           MobileMboDataBean parentbean = databean.getParentBean();
/*  446: 606 */           databean.setValue("TICKETID", parentbean.getValue("TICKETID"));
/*  447: 607 */           databean.setValue("TICKETCLASS", parentbean.getValue("CLASS"));
/*  448:     */         }
/*  449: 611 */         if ((name.equals("WOLABTRANS")) || (name.equals("TKLABTRANS")))
/*  450:     */         {
/*  451: 613 */           databean.setValue("ORGID", databean.getParentBean().getMobileMbo().getValue("ORGID"));
/*  452: 614 */           databean.setValue("SITEID", databean.getParentBean().getMobileMbo().getValue("SITEID"));
/*  453:     */           
/*  454: 616 */           mylaborcode = WOApp.getUsersLaborcode(databean.getParentBean().getValue("ORGID"));
/*  455:     */         }
/*  456:     */         else
/*  457:     */         {
/*  458: 619 */           String[] getFromName = { "WORKLIST" };
/*  459: 620 */           String[] getFromColumnName = { "CLASS" };
/*  460: 621 */           createRecordClassList(getFromName, getFromColumnName);
/*  461: 622 */           DataBeanCache.removeDataBean("WORKLIST");
/*  462:     */         }
/*  463: 625 */         if ((mylaborcode == null) || (mylaborcode.equals(""))) {
/*  464: 629 */           mylaborcode = UIUtil.getApplication().getCurrentUser().toUpperCase();
/*  465:     */         }
/*  466: 635 */         Calendar currentCalendar = Calendar.getInstance();
/*  467: 636 */         currentCalendar.setTime(CurrentTimeProvider.getInstance().getCurrentTime());
/*  468: 637 */         currentCalendar.set(13, 0);
/*  469: 638 */         currentCalendar.set(14, 0);
/*  470: 639 */         long currentTime = currentCalendar.getTimeInMillis();
/*  471:     */         
/*  472: 641 */         databean.setValue("STARTDATETIME", DefaultMobileMboDataFormatter.dateTimeToString(new Date(currentTime), Locale.getDefault(), TimeZone.getDefault()));
/*  473:     */         
/*  474: 643 */         MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager("LABORCRAFTRATE");
/*  475: 644 */         MobileMboDataBean lcrBean = mgrDBMgr.getDataBean();
/*  476: 645 */         lcrBean.getQBE().reset();
/*  477: 646 */         lcrBean.getQBE().setQbeExactMatch(true);
/*  478: 647 */         lcrBean.getQBE().setQBE("ORGID", databean.getValue("ORGID"));
/*  479: 648 */         lcrBean.getQBE().setQBE("LABORCODE", mylaborcode);
/*  480: 649 */         lcrBean.getQBE().setQBE("DEFAULTCRAFT", "1");
/*  481: 650 */         MobileMbo lbrMbo = lcrBean.getMobileMbo(0);
/*  482: 651 */         if (lbrMbo != null)
/*  483:     */         {
/*  484: 653 */           databean.setValue("LABORCODE", lbrMbo.getValue("LABORCODE"));
/*  485: 654 */           databean.setValue("CRAFT", lbrMbo.getValue("CRAFT"));
/*  486: 655 */           databean.setValue("SKILLLEVEL", lbrMbo.getValue("SKILLLEVEL"));
/*  487: 656 */           databean.setValue("VENDOR", lbrMbo.getValue("VENDOR"));
/*  488: 657 */           databean.setValue("CONTRACTNUM", lbrMbo.getValue("CONTRACTNUM"));
/*  489:     */         }
/*  490:     */       }
/*  491:     */     }
/*  492: 662 */     UIUtil.refreshCurrentScreen();
/*  493: 663 */     return true;
/*  494:     */   }
/*  495:     */   
/*  496:     */   public boolean validatelaborfield(UIEvent event)
/*  497:     */     throws MobileApplicationException
/*  498:     */   {
/*  499: 668 */     MobileMboDataBean databean = ((TextboxControl)event.getCreatingObject()).getDataBean();
/*  500: 669 */     String field = ((TextboxControl)event.getCreatingObject()).getStringValue("dataattribute");
/*  501: 671 */     if ((event.getValue() == null) || (event.getValue().equals("")))
/*  502:     */     {
/*  503: 674 */       databean.setValue("CRAFT", "");
/*  504: 675 */       databean.setValue("SKILLLEVEL", "");
/*  505: 676 */       databean.setValue("VENDOR", "");
/*  506: 677 */       databean.setValue("CONTRACTNUM", "");
/*  507:     */       
/*  508: 679 */       UIUtil.refreshCurrentScreen();
/*  509:     */     }
/*  510:     */     else
/*  511:     */     {
/*  512: 684 */       MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager("LABORCRAFTRATE");
/*  513: 685 */       MobileMboDataBean lcrBean = mgrDBMgr.getDataBean();
/*  514: 686 */       lcrBean.getQBE().reset();
/*  515: 687 */       lcrBean.getQBE().setQbeExactMatch(true);
/*  516: 688 */       lcrBean.getQBE().setQBE("ORGID", databean.getValue("ORGID"));
/*  517:     */       
/*  518: 690 */       lcrBean.getQBE().setQBE(field, (String)event.getValue());
/*  519: 692 */       if ((!field.equals("LABORCODE")) && (!databean.getValue("LABORCODE").equals(""))) {
/*  520: 693 */         lcrBean.getQBE().setQBE("LABORCODE", databean.getValue("LABORCODE"));
/*  521:     */       }
/*  522: 695 */       if ((!field.equals("CRAFT")) && (!databean.getValue("CRAFT").equals(""))) {
/*  523: 696 */         lcrBean.getQBE().setQBE("CRAFT", databean.getValue("CRAFT"));
/*  524:     */       }
/*  525: 698 */       if ((!field.equals("SKILLLEVEL")) && (!databean.getValue("SKILLLEVEL").equals(""))) {
/*  526: 699 */         lcrBean.getQBE().setQBE("SKILLLEVEL", databean.getValue("SKILLLEVEL"));
/*  527:     */       }
/*  528: 701 */       if ((!field.equals("VENDOR")) && (!databean.getValue("VENDOR").equals(""))) {
/*  529: 702 */         lcrBean.getQBE().setQBE("VENDOR", databean.getValue("VENDOR"));
/*  530:     */       }
/*  531: 704 */       if ((!field.equals("CONTRACTNUM")) && (!databean.getValue("CONTRACTNUM").equals(""))) {
/*  532: 705 */         lcrBean.getQBE().setQBE("CONTRACTNUM", databean.getValue("CONTRACTNUM"));
/*  533:     */       }
/*  534: 707 */       lcrBean.reset();
/*  535: 708 */       int count = lcrBean.count();
/*  536: 709 */       if (count == 0)
/*  537:     */       {
/*  538: 712 */         databean.setValue("CRAFT", "");
/*  539: 713 */         databean.setValue("SKILLLEVEL", "");
/*  540: 714 */         databean.setValue("VENDOR", "");
/*  541: 715 */         databean.setValue("CONTRACTNUM", "");
/*  542:     */         
/*  543: 717 */         mgrDBMgr = new MobileMboDataBeanManager("LABORCRAFTRATE");
/*  544: 718 */         lcrBean = mgrDBMgr.getDataBean();
/*  545: 719 */         lcrBean.getQBE().reset();
/*  546: 720 */         lcrBean.getQBE().setQbeExactMatch(true);
/*  547: 721 */         lcrBean.getQBE().setQBE("ORGID", databean.getValue("ORGID"));
/*  548: 722 */         lcrBean.getQBE().setQBE(field, (String)event.getValue());
/*  549: 723 */         lcrBean.reset();
/*  550: 724 */         count = lcrBean.count();
/*  551:     */       }
/*  552: 727 */       if (count == 0) {
/*  553: 730 */         throw new MobileApplicationException("invalidlabor");
/*  554:     */       }
/*  555: 732 */       if (count == 1)
/*  556:     */       {
/*  557: 735 */         databean.setValue("CRAFT", lcrBean.getMobileMbo(0).getValue("CRAFT"));
/*  558: 736 */         databean.setValue("SKILLLEVEL", lcrBean.getMobileMbo(0).getValue("SKILLLEVEL"));
/*  559: 737 */         databean.setValue("VENDOR", lcrBean.getMobileMbo(0).getValue("VENDOR"));
/*  560: 738 */         databean.setValue("CONTRACTNUM", lcrBean.getMobileMbo(0).getValue("CONTRACTNUM"));
/*  561:     */       }
/*  562: 740 */       else if (count > 0)
/*  563:     */       {
/*  564: 743 */         MobileMbo lcrMbo = null;
/*  565: 744 */         boolean[] unique = { true, true, true, true };
/*  566: 745 */         String[] lastvalue = { "", "", "", "" };
/*  567: 746 */         for (int i = 0; i < count; i++)
/*  568:     */         {
/*  569: 748 */           lcrMbo = lcrBean.getMobileMbo(i);
/*  570: 749 */           if (i == 0)
/*  571:     */           {
/*  572: 751 */             lastvalue[0] = lcrMbo.getValue("CRAFT");
/*  573: 752 */             lastvalue[1] = lcrMbo.getValue("SKILLLEVEL");
/*  574: 753 */             lastvalue[2] = lcrMbo.getValue("VENDOR");
/*  575: 754 */             lastvalue[3] = lcrMbo.getValue("CONTRACTNUM");
/*  576:     */           }
/*  577:     */           else
/*  578:     */           {
/*  579: 757 */             if (!lastvalue[0].equals(lcrMbo.getValue("CRAFT"))) {
/*  580: 757 */               unique[0] = false;
/*  581:     */             }
/*  582: 758 */             if (!lastvalue[1].equals(lcrMbo.getValue("SKILLLEVEL"))) {
/*  583: 758 */               unique[1] = false;
/*  584:     */             }
/*  585: 759 */             if (!lastvalue[2].equals(lcrMbo.getValue("VENDOR"))) {
/*  586: 759 */               unique[2] = false;
/*  587:     */             }
/*  588: 760 */             if (!lastvalue[3].equals(lcrMbo.getValue("CONTRACTNUM"))) {
/*  589: 760 */               unique[3] = false;
/*  590:     */             }
/*  591: 762 */             if ((unique[0] == 0) && (unique[1] == 0) && (unique[2] == 0) && (unique[3] == 0)) {
/*  592:     */               break;
/*  593:     */             }
/*  594:     */           }
/*  595:     */         }
/*  596: 765 */         if (unique[0] != 0) {
/*  597: 765 */           databean.setValue("CRAFT", lcrBean.getMobileMbo(0).getValue("CRAFT"));
/*  598:     */         }
/*  599: 766 */         if (unique[1] != 0) {
/*  600: 766 */           databean.setValue("SKILLLEVEL", lcrBean.getMobileMbo(0).getValue("SKILLLEVEL"));
/*  601:     */         }
/*  602: 767 */         if (unique[2] != 0) {
/*  603: 767 */           databean.setValue("VENDOR", lcrBean.getMobileMbo(0).getValue("VENDOR"));
/*  604:     */         }
/*  605: 768 */         if (unique[3] != 0) {
/*  606: 768 */           databean.setValue("CONTRACTNUM", lcrBean.getMobileMbo(0).getValue("CONTRACTNUM"));
/*  607:     */         }
/*  608:     */       }
/*  609:     */     }
/*  610: 772 */     return true;
/*  611:     */   }
/*  612:     */   
/*  613:     */   public boolean validatelabtransfield(UIEvent event)
/*  614:     */     throws MobileApplicationException
/*  615:     */   {
/*  616: 777 */     MobileMboDataBean databean = ((TextboxControl)event.getCreatingObject()).getDataBean();
/*  617: 778 */     String field = ((TextboxControl)event.getCreatingObject()).getStringValue("dataattribute");
/*  618: 780 */     if ((event.getValue() != null) && (!event.getValue().equals("")))
/*  619:     */     {
/*  620: 783 */       MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager("LABORCRAFTRATE");
/*  621: 784 */       MobileMboDataBean lcrBean = mgrDBMgr.getDataBean();
/*  622: 785 */       lcrBean.getQBE().reset();
/*  623: 786 */       lcrBean.getQBE().setQbeExactMatch(true);
/*  624: 787 */       lcrBean.getQBE().setQBE("ORGID", databean.getValue("ORGID"));
/*  625:     */       
/*  626: 789 */       lcrBean.getQBE().setQBE(field, (String)event.getValue());
/*  627: 791 */       if ((!field.equals("LABORCODE")) && (!databean.getValue("LABORCODE").equals(""))) {
/*  628: 792 */         lcrBean.getQBE().setQBE("LABORCODE", databean.getValue("LABORCODE"));
/*  629:     */       }
/*  630: 794 */       if ((!field.equals("CRAFT")) && (!databean.getValue("CRAFT").equals(""))) {
/*  631: 795 */         lcrBean.getQBE().setQBE("CRAFT", databean.getValue("CRAFT"));
/*  632:     */       }
/*  633: 797 */       if ((!field.equals("SKILLLEVEL")) && (!databean.getValue("SKILLLEVEL").equals(""))) {
/*  634: 798 */         lcrBean.getQBE().setQBE("SKILLLEVEL", databean.getValue("SKILLLEVEL"));
/*  635:     */       }
/*  636: 800 */       if ((!field.equals("VENDOR")) && (!databean.getValue("VENDOR").equals(""))) {
/*  637: 801 */         lcrBean.getQBE().setQBE("VENDOR", databean.getValue("VENDOR"));
/*  638:     */       }
/*  639: 803 */       if ((!field.equals("CONTRACTNUM")) && (!databean.getValue("CONTRACTNUM").equals(""))) {
/*  640: 804 */         lcrBean.getQBE().setQBE("CONTRACTNUM", databean.getValue("CONTRACTNUM"));
/*  641:     */       }
/*  642: 806 */       lcrBean.reset();
/*  643: 807 */       int count = lcrBean.count();
/*  644: 808 */       if (count == 0) {
/*  645: 810 */         throw new MobileApplicationException("invalidlcr");
/*  646:     */       }
/*  647: 812 */       if (count == 1)
/*  648:     */       {
/*  649: 815 */         databean.setValue("LABORCODE", lcrBean.getMobileMbo(0).getValue("LABORCODE"));
/*  650: 816 */         databean.setValue("CRAFT", lcrBean.getMobileMbo(0).getValue("CRAFT"));
/*  651: 817 */         databean.setValue("SKILLLEVEL", lcrBean.getMobileMbo(0).getValue("SKILLLEVEL"));
/*  652: 818 */         databean.setValue("VENDOR", lcrBean.getMobileMbo(0).getValue("VENDOR"));
/*  653: 819 */         databean.setValue("CONTRACTNUM", lcrBean.getMobileMbo(0).getValue("CONTRACTNUM"));
/*  654:     */       }
/*  655: 821 */       else if (count > 0)
/*  656:     */       {
/*  657: 824 */         MobileMbo lcrMbo = null;
/*  658: 825 */         boolean[] unique = { true, true, true, true, true };
/*  659: 826 */         String[] lastvalue = { "", "", "", "", "" };
/*  660: 827 */         for (int i = 0; i < count; i++)
/*  661:     */         {
/*  662: 829 */           lcrMbo = lcrBean.getMobileMbo(i);
/*  663: 830 */           if (i == 0)
/*  664:     */           {
/*  665: 832 */             lastvalue[0] = lcrMbo.getValue("CRAFT");
/*  666: 833 */             lastvalue[1] = lcrMbo.getValue("SKILLLEVEL");
/*  667: 834 */             lastvalue[2] = lcrMbo.getValue("VENDOR");
/*  668: 835 */             lastvalue[3] = lcrMbo.getValue("CONTRACTNUM");
/*  669: 836 */             lastvalue[3] = lcrMbo.getValue("LABORCODE");
/*  670:     */           }
/*  671:     */           else
/*  672:     */           {
/*  673: 839 */             if (!lastvalue[0].equals(lcrMbo.getValue("CRAFT"))) {
/*  674: 839 */               unique[0] = false;
/*  675:     */             }
/*  676: 840 */             if (!lastvalue[1].equals(lcrMbo.getValue("SKILLLEVEL"))) {
/*  677: 840 */               unique[1] = false;
/*  678:     */             }
/*  679: 841 */             if (!lastvalue[2].equals(lcrMbo.getValue("VENDOR"))) {
/*  680: 841 */               unique[2] = false;
/*  681:     */             }
/*  682: 842 */             if (!lastvalue[3].equals(lcrMbo.getValue("CONTRACTNUM"))) {
/*  683: 842 */               unique[3] = false;
/*  684:     */             }
/*  685: 843 */             if (!lastvalue[4].equals(lcrMbo.getValue("LABORCODE"))) {
/*  686: 843 */               unique[4] = false;
/*  687:     */             }
/*  688: 845 */             if ((unique[0] == 0) && (unique[1] == 0) && (unique[2] == 0) && (unique[3] == 0) && (unique[4] == 0)) {
/*  689:     */               break;
/*  690:     */             }
/*  691:     */           }
/*  692:     */         }
/*  693: 848 */         if (unique[0] != 0) {
/*  694: 848 */           databean.setValue("CRAFT", lcrBean.getMobileMbo(0).getValue("CRAFT"));
/*  695:     */         }
/*  696: 849 */         if (unique[1] != 0) {
/*  697: 849 */           databean.setValue("SKILLLEVEL", lcrBean.getMobileMbo(0).getValue("SKILLLEVEL"));
/*  698:     */         }
/*  699: 850 */         if (unique[2] != 0) {
/*  700: 850 */           databean.setValue("VENDOR", lcrBean.getMobileMbo(0).getValue("VENDOR"));
/*  701:     */         }
/*  702: 851 */         if (unique[3] != 0) {
/*  703: 851 */           databean.setValue("CONTRACTNUM", lcrBean.getMobileMbo(0).getValue("CONTRACTNUM"));
/*  704:     */         }
/*  705: 852 */         if (unique[4] != 0) {
/*  706: 852 */           databean.setValue("LABORCODE", lcrBean.getMobileMbo(0).getValue("LABORCODE"));
/*  707:     */         }
/*  708:     */       }
/*  709:     */     }
/*  710: 856 */     return true;
/*  711:     */   }
/*  712:     */   
/*  713:     */   public boolean initpage_stopthenstarttimer(UIEvent event)
/*  714:     */     throws MobileApplicationException
/*  715:     */   {
/*  716: 861 */     return initTheStopTimerPage(event, true);
/*  717:     */   }
/*  718:     */   
/*  719:     */   public boolean initpage_stoptimer(UIEvent event)
/*  720:     */     throws MobileApplicationException
/*  721:     */   {
/*  722: 866 */     return initTheStopTimerPage(event, false);
/*  723:     */   }
/*  724:     */   
/*  725:     */   public boolean initTheStopTimerPage(UIEvent event, boolean findtimertostop)
/*  726:     */     throws MobileApplicationException
/*  727:     */   {
/*  728: 874 */     MobileMboDataBean databean = ((PageControl)event.getCreatingObject()).getDataBean();
/*  729: 875 */     databean.reset();
/*  730:     */     
/*  731:     */ 
/*  732: 878 */     MobileMboDataBean wodatabean = UIUtil.getCurrentScreen().getDataBean();
/*  733: 882 */     if (UIUtil.getCurrentScreen().getId().equals("assetlists")) {
/*  734: 883 */       wodatabean = wodatabean.getDataBean("WOCHILDREN");
/*  735: 885 */     } else if ((wodatabean != null) && (wodatabean.getName().equals("WORKLIST"))) {
/*  736: 887 */       wodatabean = new MobileWOAppEventHandler().setWorklistRecordBean(event, wodatabean);
/*  737:     */     }
/*  738: 891 */     String laborcode = "";
/*  739: 892 */     if (wodatabean != null) {
/*  740: 894 */       laborcode = WOApp.getUsersLaborcode(wodatabean.getValue("ORGID"));
/*  741:     */     } else {
/*  742: 897 */       throw new MobileApplicationException("needlaborcode");
/*  743:     */     }
/*  744: 900 */     if (laborcode.equals("")) {
/*  745: 902 */       throw new MobileApplicationException("needlaborcode");
/*  746:     */     }
/*  747: 905 */     int wocount = 0;
/*  748: 906 */     int tkcount = 0;
/*  749: 907 */     MobileMboDataBeanManager mgrWODBMgr = null;
/*  750: 908 */     MobileMboDataBean wolabtransBean = null;
/*  751: 909 */     MobileMboDataBeanManager mgrTKDBMgr = null;
/*  752: 910 */     MobileMboDataBean tklabtransBean = null;
/*  753: 912 */     if (findtimertostop)
/*  754:     */     {
/*  755: 914 */       mgrWODBMgr = new MobileMboDataBeanManager("WOLABTRANS");
/*  756: 915 */       wolabtransBean = mgrWODBMgr.getDataBean();
/*  757: 916 */       wolabtransBean.getQBE().reset();
/*  758: 917 */       wolabtransBean.getQBE().setQbeExactMatch(true);
/*  759: 918 */       wolabtransBean.getQBE().setQBE("LABORCODE", laborcode);
/*  760:     */       
/*  761: 920 */       wolabtransBean.getQBE().setQBE("TIMERSTATUS", getApp().getExternalValue(wolabtransBean, "TIMERSTATUS", "ACTIVE"));
/*  762: 921 */       wolabtransBean.reset();
/*  763: 922 */       wocount = wolabtransBean.count();
/*  764:     */       
/*  765: 924 */       mgrTKDBMgr = new MobileMboDataBeanManager("TKLABTRANS");
/*  766: 925 */       tklabtransBean = mgrTKDBMgr.getDataBean();
/*  767: 926 */       tklabtransBean.getQBE().reset();
/*  768: 927 */       tklabtransBean.getQBE().setQbeExactMatch(true);
/*  769: 928 */       tklabtransBean.getQBE().setQBE("LABORCODE", laborcode);
/*  770:     */       
/*  771: 930 */       tklabtransBean.getQBE().setQBE("TIMERSTATUS", getApp().getExternalValue(tklabtransBean, "TIMERSTATUS", "ACTIVE"));
/*  772: 931 */       tklabtransBean.reset();
/*  773: 932 */       tkcount = tklabtransBean.count();
/*  774:     */     }
/*  775: 935 */     MobileMboDataBeanManager mgrDBMgr = null;
/*  776: 936 */     MobileMboDataBean labtransBean = null;
/*  777: 937 */     if ((findtimertostop) && (wocount + tkcount == 1))
/*  778:     */     {
/*  779: 939 */       if (wocount == 1)
/*  780:     */       {
/*  781: 941 */         mgrDBMgr = new MobileMboDataBeanManager("WORKORDER");
/*  782: 942 */         labtransBean = wolabtransBean;
/*  783:     */       }
/*  784: 944 */       else if (tkcount == 1)
/*  785:     */       {
/*  786: 946 */         mgrDBMgr = new MobileMboDataBeanManager("TICKET");
/*  787: 947 */         labtransBean = tklabtransBean;
/*  788:     */       }
/*  789: 949 */       labtransBean.setCurrentPosition(0);
/*  790:     */       
/*  791:     */ 
/*  792: 952 */       MobileMboDataBean tmpwodatabean = mgrDBMgr.getDataBean();
/*  793: 953 */       tmpwodatabean.getQBE().reset();
/*  794: 954 */       tmpwodatabean.getQBE().setQbeExactMatch(true);
/*  795: 955 */       tmpwodatabean.getQBE().setQBE("_ID", "" + labtransBean.getMobileMbo().getLongValue("_PARENTID"));
/*  796: 956 */       tmpwodatabean.reset();
/*  797: 957 */       if (tmpwodatabean.getMobileMbo(0) != null)
/*  798:     */       {
/*  799: 959 */         wodatabean = tmpwodatabean;
/*  800: 960 */         wodatabean.setCurrentPosition(0);
/*  801:     */       }
/*  802:     */     }
/*  803: 963 */     else if (!findtimertostop)
/*  804:     */     {
/*  805: 966 */       if ((wodatabean.getName().equals("WORKORDER")) || (wodatabean.getName().equals("WOCHILDREN"))) {
/*  806: 967 */         labtransBean = wodatabean.getDataBean("WOLABTRANS");
/*  807: 968 */       } else if (wodatabean.getName().equals("TICKET")) {
/*  808: 969 */         labtransBean = wodatabean.getDataBean("TKLABTRANS");
/*  809:     */       }
/*  810: 971 */       int count = labtransBean.count();
/*  811: 972 */       for (int i = 0; i < count; i++) {
/*  812: 975 */         if ((labtransBean.getMobileMbo(i).getValue("LABORCODE").equals(laborcode)) && (labtransBean.getMobileMbo(i).getValue("TIMERSTATUS").equals(getApp().getExternalValue(labtransBean, "TIMERSTATUS", "ACTIVE"))))
/*  813:     */         {
/*  814: 978 */           labtransBean.setCurrentPosition(i);
/*  815: 979 */           break;
/*  816:     */         }
/*  817:     */       }
/*  818:     */     }
/*  819: 990 */     boolean nullSite = false;
/*  820: 991 */     if ((wodatabean.getValue("SITEID").equals("")) || (wodatabean.getValue("SITEID") == null)) {
/*  821: 993 */       nullSite = true;
/*  822:     */     }
/*  823: 996 */     if ((labtransBean != null) && (labtransBean.getCurrentPosition() >= 0))
/*  824:     */     {
/*  825: 999 */       if (nullSite)
/*  826:     */       {
/*  827:1001 */         labtransBean.setValue("SITEID", UIUtil.getApplication().getDefaultInsertSite(), false);
/*  828:1002 */         labtransBean.setValue("ORGID", UIUtil.getApplication().getDefaultInsertOrg(), false);
/*  829:     */       }
/*  830:1005 */       databean.insert();
/*  831:1006 */       databean.setValue("STARTDATETIME", labtransBean.getValue("STARTDATE") + " " + labtransBean.getValue("STARTTIME"));
/*  832:1007 */       databean.getMobileMbo(0).setDateValue("FINISHDATETIME", databean.getCurrentTime());
/*  833:1008 */       databean.getMobileMbo(0).setBooleanValue("ALSOCOMPLETE", MobileWOAppEventHandler.getStopTimerDefaultCompleteState(wodatabean));
/*  834:     */       
/*  835:     */ 
/*  836:     */ 
/*  837:1012 */       double regHrs = WOApp.calculateHours(databean.getMobileMbo(0).getDateValue("STARTDATETIME"), databean.getMobileMbo(0).getDateValue("FINISHDATETIME"));
/*  838:     */       
/*  839:1014 */       Calendar startDate = Calendar.getInstance();
/*  840:1015 */       startDate.setTime(databean.getMobileMbo(0).getDateValue("STARTDATETIME"));
/*  841:1016 */       Calendar finishDate = Calendar.getInstance();
/*  842:1017 */       finishDate.setTime(databean.getMobileMbo(0).getDateValue("FINISHDATETIME"));
/*  843:     */       
/*  844:     */ 
/*  845:     */ 
/*  846:     */ 
/*  847:     */ 
/*  848:1023 */       double diff = 0.0D;
/*  849:1025 */       if (finishDate.get(5) == startDate.get(5))
/*  850:     */       {
/*  851:1027 */         diff = ((finishDate.get(11) - startDate.get(11)) * 60 + (finishDate.get(12) - startDate.get(12))) / 60.0D;
/*  852:1029 */         if (regHrs > diff) {
/*  853:1031 */           regHrs = diff;
/*  854:     */         }
/*  855:     */       }
/*  856:1035 */       databean.getMobileMbo().setDoubleValue("REGULARHRS", regHrs);
/*  857:     */       
/*  858:     */ 
/*  859:     */ 
/*  860:1039 */       databean.setValue("_PARENTID", "" + wodatabean.getMobileMbo().getLongValue("_ID"));
/*  861:     */       
/*  862:1041 */       databean.setValue("TRANSTYPE", ((WOApp)UIUtil.getApplication()).getDefaultValue(databean, "LTTYPE", "WORK"));
/*  863:1045 */       if (((findtimertostop) && (wocount == 1)) || (wodatabean.getName().equals("WORKORDER")) || (wodatabean.getName().equals("WOCHILDREN")))
/*  864:     */       {
/*  865:1047 */         databean.setValue("MOBILEOBJECT", "WORKORDER");
/*  866:1048 */         databean.setValue("WONUM", wodatabean.getValue("WONUM"));
/*  867:1049 */         databean.setValue("DESCRIPTION", wodatabean.getValue("DESCRIPTION"));
/*  868:     */       }
/*  869:1051 */       else if (((findtimertostop) && (tkcount == 1)) || (wodatabean.getName().equals("TICKET")))
/*  870:     */       {
/*  871:1053 */         databean.setValue("MOBILEOBJECT", "TICKET");
/*  872:1054 */         databean.setValue("TICKETID", wodatabean.getValue("TICKETID"));
/*  873:1055 */         databean.setValue("DESCRIPTION", wodatabean.getValue("DESCRIPTION"));
/*  874:     */       }
/*  875:     */     }
/*  876:1059 */     if (MobileWOAppEventHandler.isTimerConfiguredToNotConfirm(databean))
/*  877:     */     {
/*  878:1060 */       validatepage_stoptimer(event, false, databean, false, false);
/*  879:     */       
/*  880:1062 */       event.setEventErrored();
/*  881:     */     }
/*  882:1065 */     return true;
/*  883:     */   }
/*  884:     */   
/*  885:     */   public boolean validatepage_stopstarttimer(UIEvent event)
/*  886:     */     throws MobileApplicationException
/*  887:     */   {
/*  888:1070 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/*  889:1071 */     if (UIUtil.checkESignature(event, databean, "LABACTUALS,STOPTIMER")) {
/*  890:1073 */       validatepage_stoptimer(event, true, databean, true, true);
/*  891:     */     } else {
/*  892:1077 */       event.setEventErrored();
/*  893:     */     }
/*  894:1080 */     return true;
/*  895:     */   }
/*  896:     */   
/*  897:     */   public boolean validatepage_stoptimer(UIEvent event, boolean startNewTimer, MobileMboDataBean stopTimerBean)
/*  898:     */     throws MobileApplicationException
/*  899:     */   {
/*  900:1084 */     return validatepage_stoptimer(event, startNewTimer, stopTimerBean, true, true);
/*  901:     */   }
/*  902:     */   
/*  903:     */   public boolean validatepage_stoptimer(UIEvent event, boolean startNewTimer, MobileMboDataBean stopTimerBean, boolean validateFields, boolean validateESig)
/*  904:     */     throws MobileApplicationException
/*  905:     */   {
/*  906:1090 */     MobileMboDataBean databean = stopTimerBean;
/*  907:1091 */     boolean alsoComplete = databean.getMobileMbo().getBooleanValue("ALSOCOMPLETE");
/*  908:1094 */     if ((validateFields) && (!((AbstractMobileControl)event.getCreatingObject()).checkRequiredFields()))
/*  909:     */     {
/*  910:1096 */       event.setEventErrored();
/*  911:1097 */       return true;
/*  912:     */     }
/*  913:1099 */     boolean eSigChecked = (!validateESig) || (UIUtil.checkESignature(event, databean, "LABACTUALS,STOPTIMER"));
/*  914:1100 */     if (eSigChecked)
/*  915:     */     {
/*  916:1103 */       if ((databean.getValue("FINISHDATETIME").equals("")) || (databean.getValue("REGULARHRS").equals(""))) {
/*  917:1105 */         throw new MobileApplicationException("NeedValidHours");
/*  918:     */       }
/*  919:1109 */       MobileMboDataBean wodatabean = null;
/*  920:1110 */       MobileMboDataBean initBean = validateESig ? ((PageControl)UIUtil.getCurrentScreen()).getLaunchingControl().getDataBean() : null;
/*  921:1111 */       if ((initBean != null) && (initBean.getName().equalsIgnoreCase(databean.getValue("MOBILEOBJECT"))) && (initBean.getMobileMbo().getLongValue("_ID") == databean.getMobileMbo().getLongValue("_PARENTID")))
/*  922:     */       {
/*  923:1114 */         wodatabean = initBean;
/*  924:     */       }
/*  925:     */       else
/*  926:     */       {
/*  927:1119 */         wodatabean = DataBeanCache.findDataBean(databean.getValue("MOBILEOBJECT"));
/*  928:1120 */         if ((wodatabean == null) || ((wodatabean != null) && (wodatabean.getMobileMbo().getLongValue("_ID") != databean.getMobileMbo().getLongValue("_PARENTID"))))
/*  929:     */         {
/*  930:1121 */           MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager(databean.getValue("MOBILEOBJECT"));
/*  931:1122 */           wodatabean = mgrDBMgr.getDataBean();
/*  932:1123 */           wodatabean.getQBE().reset();
/*  933:1124 */           wodatabean.getQBE().setQbeExactMatch(true);
/*  934:1125 */           wodatabean.getQBE().setQBE("_ID", "" + databean.getMobileMbo().getLongValue("_PARENTID"));
/*  935:1126 */           wodatabean.reset();
/*  936:     */         }
/*  937:     */       }
/*  938:1130 */       if (wodatabean.getMobileMbo(0) == null) {
/*  939:1132 */         throw new MobileApplicationException("CannotFindWorkListRecord");
/*  940:     */       }
/*  941:1135 */       String labtransName = "WOLABTRANS";
/*  942:1136 */       if (wodatabean.getName().equalsIgnoreCase("TICKET")) {
/*  943:1137 */         labtransName = "TKLABTRANS";
/*  944:     */       }
/*  945:1139 */       MobileMboDataBean ltdatabean = wodatabean.getDataBean(labtransName);
/*  946:     */       
/*  947:1141 */       int count = ltdatabean.count();
/*  948:1142 */       for (int i = 0; i < count; i++) {
/*  949:1146 */         if (ltdatabean.getMobileMbo(i).getValue("TIMERSTATUS").equals(getApp().getExternalValue(ltdatabean, "TIMERSTATUS", "ACTIVE")))
/*  950:     */         {
/*  951:1151 */           String laborcode = WOApp.getUsersLaborcode(ltdatabean.getMobileMbo(i).getValue("ORGID"));
/*  952:1152 */           if (!laborcode.equals("")) {
/*  953:1155 */             if (ltdatabean.getMobileMbo(i).getValue("LABORCODE").equals(laborcode))
/*  954:     */             {
/*  955:1158 */               stopTimerOnLabTrans(ltdatabean.getMobileMbo(i), databean.getMobileMbo(0));
/*  956:     */               
/*  957:     */ 
/*  958:1161 */               databean.delete(0);
/*  959:1162 */               wodatabean.getMobileMbo().setValue("ISTIMERRUNNING", "0");
/*  960:1166 */               if (count == 1) {
/*  961:1168 */                 if ("WORKORDER".equalsIgnoreCase(wodatabean.getName()))
/*  962:     */                 {
/*  963:1171 */                   if (wodatabean.getValue("ACTSTART").trim().length() == 0) {
/*  964:1173 */                     wodatabean.setValue("ACTSTART", databean.getValue("STARTDATETIME"));
/*  965:     */                   }
/*  966:     */                 }
/*  967:1179 */                 else if (wodatabean.getValue("ACTUALSTART").trim().length() == 0) {
/*  968:1181 */                   wodatabean.setValue("ACTUALSTART", databean.getValue("STARTDATETIME"));
/*  969:     */                 }
/*  970:     */               }
/*  971:1186 */               if (alsoComplete)
/*  972:     */               {
/*  973:1188 */                 changeRecordToCompIfNeeded(wodatabean, wodatabean.getMobileMbo(), eSigChecked, startNewTimer, event);
/*  974:1189 */                 return true;
/*  975:     */               }
/*  976:1191 */               wodatabean.getDataBeanManager().save();
/*  977:     */             }
/*  978:     */           }
/*  979:     */         }
/*  980:     */       }
/*  981:1195 */       if (startNewTimer)
/*  982:     */       {
/*  983:1197 */         ((MobileWOAppEventHandler)UIUtil.getAppEventHandler()).starttimer(event);
/*  984:1203 */         if (!event.hasPassedESig()) {
/*  985:1204 */           UIUtil.getApplication().removeCurrentScreen(false);
/*  986:     */         }
/*  987:1205 */         return true;
/*  988:     */       }
/*  989:1208 */       if (event.hasPassedESig()) {
/*  990:1209 */         UIUtil.getApplication().removeCurrentScreen(false);
/*  991:     */       }
/*  992:     */     }
/*  993:     */     else
/*  994:     */     {
/*  995:1214 */       event.setEventErrored();
/*  996:     */     }
/*  997:1217 */     return true;
/*  998:     */   }
/*  999:     */   
/* 1000:     */   private void changeRecordToCompIfNeeded(MobileMboDataBean refDataBean, MobileMbo record, boolean closeESigPageAtEnd, boolean startNewTimer, UIEvent refEvent)
/* 1001:     */     throws MobileApplicationException
/* 1002:     */   {
/* 1003:1222 */     if ((MobileWOAppEventHandler.isWorkOrderRecord(record)) && ((WOChangeStatusEventHandler.isInprogStatus(refDataBean)) || (WOChangeStatusEventHandler.isApprStatus(refDataBean))))
/* 1004:     */     {
/* 1005:1223 */       WOChangeStatusEventHandler handler = (WOChangeStatusEventHandler)UIHandlerManager.getInstance().getUIHandler("wochangestatushandler");
/* 1006:1224 */       handler.completeWorkOrder(refDataBean, record, closeESigPageAtEnd, startNewTimer, refEvent);
/* 1007:     */     }
/* 1008:     */     else
/* 1009:     */     {
/* 1010:1226 */       refDataBean.getDataBeanManager().save();
/* 1011:1227 */       if (startNewTimer)
/* 1012:     */       {
/* 1013:1228 */         ((MobileWOAppEventHandler)UIUtil.getAppEventHandler()).starttimer(refEvent);
/* 1014:1229 */         if (!refEvent.hasPassedESig()) {
/* 1015:1230 */           UIUtil.getApplication().removeCurrentScreen(false);
/* 1016:     */         }
/* 1017:     */       }
/* 1018:     */     }
/* 1019:     */   }
/* 1020:     */   
/* 1021:     */   public boolean validate_startdate(UIEvent event)
/* 1022:     */     throws MobileApplicationException
/* 1023:     */   {
/* 1024:1239 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/* 1025:1240 */     if (databean == null) {
/* 1026:1243 */       databean = ((PageControl)UIUtil.getCurrentScreen()).getLaunchingControl().getDataBean();
/* 1027:     */     }
/* 1028:1246 */     if ((event.getValue() == null) || (event.getValue().equals(""))) {
/* 1029:1248 */       return true;
/* 1030:     */     }
/* 1031:1252 */     double totalHrs = DefaultMobileMboDataFormatter.durationToDouble(databean.getValue("REGULARHRS"));
/* 1032:1254 */     if (!databean.getValue("FINISHDATETIME").equals(""))
/* 1033:     */     {
/* 1034:1256 */       if (databean.getMobileMbo().getDateValue("FINISHDATETIME").before((Date)event.getValue())) {
/* 1035:1257 */         throw new MobileApplicationException("endbeforestart");
/* 1036:     */       }
/* 1037:1259 */       Date finishDateTime = databean.getMobileMbo().getDateValue("FINISHDATETIME");
/* 1038:1260 */       double interval = WOApp.calculateHours((Date)event.getValue(), finishDateTime);
/* 1039:1266 */       if ((databean.getName().equals("STOPTIMER")) || (databean.getValue("REGULARHRS").equals("")) || (totalHrs == 0.0D) || (totalHrs > interval) || (totalHrs < interval)) {
/* 1040:1268 */         databean.getMobileMbo().setValue("REGULARHRS", "" + interval);
/* 1041:     */       }
/* 1042:     */     }
/* 1043:1273 */     if ((totalHrs > 0.0D) && (databean.getValue("FINISHDATETIME").equals("")))
/* 1044:     */     {
/* 1045:1275 */       double min = totalHrs * 60.0D;
/* 1046:1276 */       Double newMinutes = new Double(min);
/* 1047:1277 */       int totalminutes = newMinutes.intValue();
/* 1048:1278 */       Calendar cal = Calendar.getInstance();
/* 1049:1279 */       cal.setTime((Date)event.getValue());
/* 1050:1280 */       cal.add(12, totalminutes);
/* 1051:1281 */       Date finishDate = cal.getTime();
/* 1052:     */       
/* 1053:1283 */       databean.getMobileMbo().setDateValue("FINISHDATETIME", finishDate);
/* 1054:     */     }
/* 1055:1287 */     UIUtil.refreshCurrentScreen();
/* 1056:1288 */     return true;
/* 1057:     */   }
/* 1058:     */   
/* 1059:     */   public boolean validate_enddate(UIEvent event)
/* 1060:     */     throws MobileApplicationException
/* 1061:     */   {
/* 1062:1293 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/* 1063:1294 */     if (databean == null) {
/* 1064:1297 */       databean = ((PageControl)UIUtil.getCurrentScreen()).getLaunchingControl().getDataBean();
/* 1065:     */     }
/* 1066:1300 */     if ((event.getValue() == null) || (event.getValue().equals(""))) {
/* 1067:1302 */       return true;
/* 1068:     */     }
/* 1069:1306 */     double totalHrs = DefaultMobileMboDataFormatter.durationToDouble(databean.getValue("REGULARHRS"));
/* 1070:1308 */     if (!databean.getValue("STARTDATETIME").equals(""))
/* 1071:     */     {
/* 1072:1311 */       if (databean.getMobileMbo().getDateValue("STARTDATETIME").after((Date)event.getValue())) {
/* 1073:1312 */         throw new MobileApplicationException("endbeforestart");
/* 1074:     */       }
/* 1075:1314 */       Date startDateTime = databean.getMobileMbo().getDateValue("STARTDATETIME");
/* 1076:1315 */       double interval = WOApp.calculateHours(startDateTime, (Date)event.getValue());
/* 1077:1321 */       if ((databean.getName().equals("STOPTIMER")) || (databean.getValue("REGULARHRS").equals("")) || (totalHrs == 0.0D) || (totalHrs > interval) || (totalHrs < interval)) {
/* 1078:1323 */         databean.getMobileMbo().setValue("REGULARHRS", "" + interval);
/* 1079:     */       }
/* 1080:     */     }
/* 1081:1328 */     if ((totalHrs > 0.0D) && (databean.getValue("STARTDATETIME").equals("")))
/* 1082:     */     {
/* 1083:1330 */       double min = totalHrs * 60.0D;
/* 1084:1331 */       Double newMinutes = new Double(min);
/* 1085:1332 */       int totalminutes = newMinutes.intValue();
/* 1086:1333 */       Calendar cal = Calendar.getInstance();
/* 1087:1334 */       cal.setTime((Date)event.getValue());
/* 1088:1335 */       cal.add(12, totalminutes * -1);
/* 1089:1336 */       Date startDate = cal.getTime();
/* 1090:     */       
/* 1091:1338 */       databean.getMobileMbo().setDateValue("STARTDATETIME", startDate);
/* 1092:     */     }
/* 1093:1342 */     UIUtil.refreshCurrentScreen();
/* 1094:1343 */     return true;
/* 1095:     */   }
/* 1096:     */   
/* 1097:     */   public boolean validate_reghours(UIEvent event)
/* 1098:     */     throws MobileApplicationException
/* 1099:     */   {
/* 1100:1348 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/* 1101:1349 */     if (databean == null) {
/* 1102:1352 */       databean = ((PageControl)UIUtil.getCurrentScreen()).getLaunchingControl().getDataBean();
/* 1103:     */     }
/* 1104:1355 */     if ((event.getValue() == null) || (event.getValue().equals(""))) {
/* 1105:1357 */       return true;
/* 1106:     */     }
/* 1107:1361 */     double totalHrs = DefaultMobileMboDataFormatter.durationToDouble((String)event.getValue());
/* 1108:1363 */     if (totalHrs < 0.0D) {
/* 1109:1365 */       throw new MobileApplicationException("invalidduration");
/* 1110:     */     }
/* 1111:1368 */     double min = totalHrs * 60.0D;
/* 1112:1369 */     Double newMinutes = new Double(min);
/* 1113:1370 */     int totalminutes = newMinutes.intValue();
/* 1114:1375 */     if ((!databean.getValue("STARTDATETIME").equals("")) && (!databean.getValue("FINISHDATETIME").equals("")) && (totalHrs > 0.0D))
/* 1115:     */     {
/* 1116:1378 */       double calHours = WOApp.calculateHours(databean.getMobileMbo().getDateValue("STARTDATETIME"), databean.getMobileMbo().getDateValue("FINISHDATETIME"));
/* 1117:1382 */       if (totalHrs > calHours) {
/* 1118:1384 */         databean.getMobileMbo().setValue("FINISHDATETIME", null);
/* 1119:     */       }
/* 1120:     */     }
/* 1121:1389 */     if ((!databean.getValue("STARTDATETIME").equals("")) && (databean.getValue("FINISHDATETIME").equals("")))
/* 1122:     */     {
/* 1123:1391 */       Calendar cal = Calendar.getInstance();
/* 1124:1392 */       cal.setTime(databean.getMobileMbo().getDateValue("STARTDATETIME"));
/* 1125:1393 */       cal.add(12, totalminutes);
/* 1126:1394 */       Date finishDate = cal.getTime();
/* 1127:     */       
/* 1128:1396 */       databean.getMobileMbo().setDateValue("FINISHDATETIME", finishDate);
/* 1129:1398 */       if (databean.getMobileMbo().getDateValue("STARTDATETIME").after(databean.getMobileMbo().getDateValue("FINISHDATETIME"))) {
/* 1130:1399 */         throw new MobileApplicationException("endbeforestart");
/* 1131:     */       }
/* 1132:     */     }
/* 1133:1403 */     if ((!databean.getValue("FINISHDATETIME").equals("")) && (databean.getValue("STARTDATETIME").equals("")))
/* 1134:     */     {
/* 1135:1405 */       Calendar cal = Calendar.getInstance();
/* 1136:1406 */       cal.setTime(databean.getMobileMbo().getDateValue("FINISHDATETIME"));
/* 1137:1407 */       cal.add(12, totalminutes * -1);
/* 1138:1408 */       Date startDate = cal.getTime();
/* 1139:     */       
/* 1140:1410 */       databean.getMobileMbo().setDateValue("STARTDATETIME", startDate);
/* 1141:     */     }
/* 1142:1415 */     UIUtil.refreshCurrentScreen();
/* 1143:1416 */     return true;
/* 1144:     */   }
/* 1145:     */   
/* 1146:     */   public boolean stopTimerOnLabTrans(MobileMbo ltMbo, MobileMbo valuesMbo)
/* 1147:     */     throws MobileApplicationException
/* 1148:     */   {
/* 1149:1421 */     String laborcode = WOApp.getUsersLaborcode(ltMbo.getValue("ORGID"));
/* 1150:1422 */     if (laborcode.equals("")) {
/* 1151:1424 */       throw new MobileApplicationException("needlaborcode");
/* 1152:     */     }
/* 1153:1427 */     ltMbo.setDateValue("STARTDATE", WOApp.getDateFromDate(valuesMbo.getDateValue("STARTDATETIME")), false);
/* 1154:1428 */     ltMbo.setDateValue("STARTTIME", WOApp.getTimeFromDate(valuesMbo.getDateValue("STARTDATETIME")), false);
/* 1155:1429 */     ltMbo.setDateValue("FINISHDATE", WOApp.getDateFromDate(valuesMbo.getDateValue("FINISHDATETIME")), false);
/* 1156:1430 */     ltMbo.setDateValue("FINISHTIME", WOApp.getTimeFromDate(valuesMbo.getDateValue("FINISHDATETIME")), false);
/* 1157:1431 */     String ppcode = valuesMbo.getValue("PREMIUMPAYCODE");
/* 1158:1432 */     if (!"".equals(ppcode))
/* 1159:     */     {
/* 1160:1433 */       ltMbo.setValue("PREMIUMPAYHOURS", valuesMbo.getValue("REGULARHRS"), false);
/* 1161:1434 */       ltMbo.setValue("PREMIUMPAYCODE", valuesMbo.getValue("PREMIUMPAYCODE"), false);
/* 1162:1435 */       ltMbo.setValue("REGULARHRS", "0", false);
/* 1163:     */     }
/* 1164:     */     else
/* 1165:     */     {
/* 1166:1437 */       ltMbo.setValue("REGULARHRS", valuesMbo.getValue("REGULARHRS"), false);
/* 1167:     */     }
/* 1168:1440 */     ltMbo.setValue("TIMERSTATUS", getApp().getExternalValue(null, "TIMERSTATUS", "COMPLETE"), false);
/* 1169:1441 */     ltMbo.setValue("TRANSTYPE", valuesMbo.getValue("TRANSTYPE"), false);
/* 1170:     */     
/* 1171:1443 */     return true;
/* 1172:     */   }
/* 1173:     */   
/* 1174:     */   public boolean save(UIEvent event)
/* 1175:     */     throws MobileApplicationException
/* 1176:     */   {
/* 1177:1448 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/* 1178:1450 */     if (((PageControl)event.getCreatingObject()).getId().equalsIgnoreCase("actuals"))
/* 1179:     */     {
/* 1180:1453 */       MobileMboDataBean ltdatabean = databean.getDataBean("WOLABTRANS");
/* 1181:1454 */       if (ltdatabean != null)
/* 1182:     */       {
/* 1183:1456 */         int count = ltdatabean.count();
/* 1184:1457 */         for (int i = 0; i < count; i++)
/* 1185:     */         {
/* 1186:1459 */           boolean incomplete = ltdatabean.getMobileMbo(i).getBooleanValue("_INCOMPLETE");
/* 1187:1460 */           if (incomplete) {
/* 1188:1462 */             throw new MobileApplicationException("labactincomplete");
/* 1189:     */           }
/* 1190:     */         }
/* 1191:     */       }
/* 1192:1468 */       MobileMboDataBean mtdatabean = databean.getDataBean("WOMATTRANS");
/* 1193:1469 */       if (mtdatabean != null)
/* 1194:     */       {
/* 1195:1471 */         int count = mtdatabean.count();
/* 1196:1472 */         for (int i = 0; i < count; i++)
/* 1197:     */         {
/* 1198:1474 */           boolean incomplete = mtdatabean.getMobileMbo(i).getBooleanValue("_INCOMPLETE");
/* 1199:1475 */           if (incomplete) {
/* 1200:1477 */             throw new MobileApplicationException("matactincomplete");
/* 1201:     */           }
/* 1202:     */         }
/* 1203:     */       }
/* 1204:1483 */       MobileMboDataBean ttdatabean = databean.getDataBean("WOTOOLTRANS");
/* 1205:1484 */       if (ttdatabean != null)
/* 1206:     */       {
/* 1207:1486 */         int count = ttdatabean.count();
/* 1208:1487 */         for (int i = 0; i < count; i++)
/* 1209:     */         {
/* 1210:1489 */           boolean incomplete = ttdatabean.getMobileMbo(i).getBooleanValue("_INCOMPLETE");
/* 1211:1490 */           if (incomplete) {
/* 1212:1492 */             throw new MobileApplicationException("toolactincomplete");
/* 1213:     */           }
/* 1214:     */         }
/* 1215:     */       }
/* 1216:     */     }
/* 1217:1499 */     return false;
/* 1218:     */   }
/* 1219:     */   
/* 1220:     */   public boolean validate_ppc(UIEvent event)
/* 1221:     */     throws MobileApplicationException
/* 1222:     */   {
/* 1223:1504 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/* 1224:1505 */     if ((event.getValue() == null) || (event.getValue().equals(""))) {
/* 1225:1507 */       return true;
/* 1226:     */     }
/* 1227:1512 */     if (databean.getValue("CRAFT").equals("")) {
/* 1228:1513 */       throw new MobileApplicationException("needcraftforppc");
/* 1229:     */     }
/* 1230:1516 */     MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager("PPCRAFTRATE");
/* 1231:1517 */     MobileMboDataBean ppcrBean = mgrDBMgr.getDataBean();
/* 1232:1518 */     ppcrBean.getQBE().reset();
/* 1233:1519 */     ppcrBean.getQBE().setQbeExactMatch(true);
/* 1234:1520 */     ppcrBean.getQBE().setQBE("ORGID", databean.getValue("ORGID"));
/* 1235:1521 */     ppcrBean.getQBE().setQBE("CRAFT", databean.getValue("CRAFT"));
/* 1236:1522 */     ppcrBean.getQBE().setQBE("PREMIUMPAYCODE", (String)event.getValue());
/* 1237:1523 */     ppcrBean.reset();
/* 1238:1524 */     int count = ppcrBean.count();
/* 1239:1525 */     if (count != 1) {
/* 1240:1527 */       throw new MobileApplicationException("invalidppc");
/* 1241:     */     }
/* 1242:1531 */     return true;
/* 1243:     */   }
/* 1244:     */   
/* 1245:     */   public boolean initpagePPC(UIEvent event)
/* 1246:     */     throws MobileApplicationException
/* 1247:     */   {
/* 1248:1537 */     MobileMboDataBean databean = ((PageControl)event.getCreatingObject()).getDataBean();
/* 1249:     */     
/* 1250:     */ 
/* 1251:1540 */     MobileMboDataBean ltdatabean = UIUtil.getCurrentScreen().getDataBean();
/* 1252:1542 */     if (ltdatabean.getValue("CRAFT").equals("")) {
/* 1253:1543 */       throw new MobileApplicationException("needcraftforppc");
/* 1254:     */     }
/* 1255:1545 */     databean.getQBE().setQbeExactMatch(true);
/* 1256:1546 */     databean.getQBE().setQBE("ORGID", ltdatabean.getValue("ORGID"));
/* 1257:1547 */     databean.getQBE().setQBE("CRAFT", ltdatabean.getValue("CRAFT"));
/* 1258:1548 */     databean.reset();
/* 1259:     */     
/* 1260:1550 */     return true;
/* 1261:     */   }
/* 1262:     */   
/* 1263:     */   public boolean isWOTasksVisible()
/* 1264:     */   {
/* 1265:1554 */     return this.wotaskvisibility;
/* 1266:     */   }
/* 1267:     */   
/* 1268:     */   public void setWOTasksVisibility(boolean visibility)
/* 1269:     */   {
/* 1270:1558 */     this.wotaskvisibility = visibility;
/* 1271:     */   }
/* 1272:     */   
/* 1273:     */   public boolean isHasChangedSinceLastTotalsDisplay()
/* 1274:     */   {
/* 1275:1562 */     return this.hasChangedSinceLastTotalsDisplay;
/* 1276:     */   }
/* 1277:     */   
/* 1278:     */   public void setHasChangedSinceLastTotalsDisplay(boolean hasChangedSinceLastTotalsDisplay)
/* 1279:     */   {
/* 1280:1567 */     this.hasChangedSinceLastTotalsDisplay = hasChangedSinceLastTotalsDisplay;
/* 1281:     */   }
/* 1282:     */   
/* 1283:     */   private WOApp getApp()
/* 1284:     */   {
/* 1285:1572 */     return (WOApp)UIUtil.getApplication();
/* 1286:     */   }
/* 1287:     */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.mobilewo.WOLabTransEventHandler
 * JD-Core Version:    0.7.0.1
 */