/*   1:    */ package com.mro.mobile.app.mobilewo;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.app.BasicMobileDeviceUIApplication;
/*   5:    */ import com.mro.mobile.app.DefaultMobileMboDataFormatter;
/*   6:    */ import com.mro.mobile.mbo.MobileMbo;
/*   7:    */ import com.mro.mobile.mbo.MobileMboQBE;
/*   8:    */ import com.mro.mobile.ui.DataBeanCache;
/*   9:    */ import com.mro.mobile.ui.MobileMboDataBean;
/*  10:    */ import com.mro.mobile.ui.MobileMboDataBeanManager;
/*  11:    */ import com.mro.mobile.ui.event.UIEvent;
/*  12:    */ import com.mro.mobile.ui.res.UIUtil;
/*  13:    */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*  14:    */ import com.mro.mobile.ui.res.controls.PageControl;
/*  15:    */ import com.mro.mobileapp.WOApp;
/*  16:    */ 
/*  17:    */ public class WOSpecEventHandler
/*  18:    */   extends MobileWOCommonEventHandler
/*  19:    */ {
/*  20:    */   public boolean performEvent(UIEvent event)
/*  21:    */     throws MobileApplicationException
/*  22:    */   {
/*  23: 30 */     if (event == null) {
/*  24: 30 */       return false;
/*  25:    */     }
/*  26: 32 */     String eventId = event.getEventName();
/*  27: 34 */     if (eventId.equalsIgnoreCase("initAssetScreen")) {
/*  28: 36 */       return initAssetScreen(event);
/*  29:    */     }
/*  30: 38 */     if (eventId.equalsIgnoreCase("updateAssetSpecs")) {
/*  31: 40 */       return updateAssetSpecs(event);
/*  32:    */     }
/*  33: 42 */     if (eventId.equalsIgnoreCase("toggleSpecView")) {
/*  34: 44 */       return toggleSpecView(event);
/*  35:    */     }
/*  36: 46 */     if (eventId.equalsIgnoreCase("initLocScreen")) {
/*  37: 48 */       return initLocScreen(event);
/*  38:    */     }
/*  39: 50 */     if (eventId.equalsIgnoreCase("updateLocSpecs")) {
/*  40: 52 */       return updateLocSpecs(event);
/*  41:    */     }
/*  42: 54 */     if (eventId.equalsIgnoreCase("initCIScreen")) {
/*  43: 56 */       return initCIScreen(event);
/*  44:    */     }
/*  45: 58 */     if (eventId.equalsIgnoreCase("updateCISpecs")) {
/*  46: 60 */       return updateCISpecs(event);
/*  47:    */     }
/*  48: 62 */     super.performEvent(event);
/*  49:    */     
/*  50: 64 */     return false;
/*  51:    */   }
/*  52:    */   
/*  53:    */   public boolean initAssetScreen(UIEvent event)
/*  54:    */     throws MobileApplicationException
/*  55:    */   {
/*  56: 69 */     return initScreen(event, "ASSET");
/*  57:    */   }
/*  58:    */   
/*  59:    */   public boolean updateAssetSpecs(UIEvent event)
/*  60:    */     throws MobileApplicationException
/*  61:    */   {
/*  62: 73 */     return updateSpecs(event, "ASSET");
/*  63:    */   }
/*  64:    */   
/*  65:    */   public boolean initLocScreen(UIEvent event)
/*  66:    */     throws MobileApplicationException
/*  67:    */   {
/*  68: 77 */     return initScreen(event, "LOCATION");
/*  69:    */   }
/*  70:    */   
/*  71:    */   public boolean updateLocSpecs(UIEvent event)
/*  72:    */     throws MobileApplicationException
/*  73:    */   {
/*  74: 81 */     return updateSpecs(event, "LOCATION");
/*  75:    */   }
/*  76:    */   
/*  77:    */   public boolean initCIScreen(UIEvent event)
/*  78:    */     throws MobileApplicationException
/*  79:    */   {
/*  80: 85 */     return initScreen(event, "CI");
/*  81:    */   }
/*  82:    */   
/*  83:    */   public boolean updateCISpecs(UIEvent event)
/*  84:    */     throws MobileApplicationException
/*  85:    */   {
/*  86: 89 */     return updateSpecs(event, "CI");
/*  87:    */   }
/*  88:    */   
/*  89:    */   public boolean initScreen(UIEvent event, String page)
/*  90:    */     throws MobileApplicationException
/*  91:    */   {
/*  92: 96 */     String extAln = ((WOApp)UIUtil.getApplication()).getExternalValue(null, "DATATYPE", "ALN");
/*  93:    */     
/*  94: 98 */     MobileMboDataBean databean = ((PageControl)event.getCreatingObject()).getDataBean();
/*  95:100 */     if ((databean == null) || (databean.count() == 0)) {
/*  96:101 */       return true;
/*  97:    */     }
/*  98:103 */     MobileMboDataBean attrvaluedatabean = null;
/*  99:    */     
/* 100:105 */     MobileMboDataBean multibean = databean.getParentBean();
/* 101:106 */     MobileMboDataBean wobean = multibean.getParentBean();
/* 102:108 */     if (DataBeanCache.findDataBean("WOMULTI") == null) {
/* 103:109 */       DataBeanCache.cacheDataBean("WOMULTI", wobean);
/* 104:    */     }
/* 105:114 */     String keyvalue = "";
/* 106:115 */     String keyfield = "";
/* 107:116 */     String keyfieldname = "";
/* 108:117 */     String dataset = "";
/* 109:118 */     if (page.equals("ASSET"))
/* 110:    */     {
/* 111:120 */       keyfield = "ASSET";
/* 112:121 */       keyvalue = databean.getValue("ASSETNUM");
/* 113:122 */       dataset = "ASSET_ASSETSPEC";
/* 114:123 */       keyfieldname = "ASSETNUM";
/* 115:124 */       attrvaluedatabean = multibean.getDataBean("ASSAUTOATTRUPDATE");
/* 116:126 */       if (attrvaluedatabean == null)
/* 117:    */       {
/* 118:127 */         attrvaluedatabean = new MobileMboDataBeanManager("ASSAUTOATTRUPDATE").getDataBean();
/* 119:128 */         attrvaluedatabean.reset();
/* 120:    */       }
/* 121:    */     }
/* 122:131 */     else if (page.equals("LOCATION"))
/* 123:    */     {
/* 124:133 */       keyfield = "LOCATION";
/* 125:134 */       keyvalue = databean.getValue("LOCATION");
/* 126:135 */       dataset = "LOC_LOCSPEC";
/* 127:136 */       keyfieldname = "LOCATION";
/* 128:137 */       attrvaluedatabean = multibean.getDataBean("LOCAUTOATTRUPDATE");
/* 129:139 */       if (attrvaluedatabean == null)
/* 130:    */       {
/* 131:140 */         attrvaluedatabean = new MobileMboDataBeanManager("LOCAUTOATTRUPDATE").getDataBean();
/* 132:141 */         attrvaluedatabean.reset();
/* 133:    */       }
/* 134:    */     }
/* 135:144 */     else if (page.equals("CI"))
/* 136:    */     {
/* 137:146 */       keyfield = "CINUM";
/* 138:147 */       keyvalue = databean.getValue("CINUM");
/* 139:148 */       dataset = "CI_CISPEC";
/* 140:149 */       keyfieldname = "CINUM";
/* 141:150 */       attrvaluedatabean = multibean.getDataBean("CIAUTOATTRUPDATE");
/* 142:152 */       if (attrvaluedatabean == null)
/* 143:    */       {
/* 144:153 */         attrvaluedatabean = new MobileMboDataBeanManager("CIAUTOATTRUPDATE").getDataBean();
/* 145:154 */         attrvaluedatabean.reset();
/* 146:    */       }
/* 147:    */     }
/* 148:158 */     int attrvalcount = attrvaluedatabean != null ? attrvaluedatabean.count() : 0;
/* 149:    */     
/* 150:160 */     MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager(dataset);
/* 151:161 */     MobileMboDataBean aspecBean = mgrDBMgr.getDataBean();
/* 152:162 */     aspecBean.getQBE().reset();
/* 153:163 */     aspecBean.getQBE().setQbeExactMatch(true);
/* 154:164 */     aspecBean.getQBE().setQBE(keyfieldname, keyvalue);
/* 155:165 */     if (!dataset.equals("CI_CISPEC")) {
/* 156:166 */       aspecBean.getQBE().setQBE("SITEID", databean.getValue("SITEID"));
/* 157:    */     }
/* 158:167 */     aspecBean.reset();
/* 159:    */     
/* 160:169 */     int dcount = aspecBean.count();
/* 161:170 */     for (int i = 0; i < dcount; i++)
/* 162:    */     {
/* 163:173 */       if (!aspecBean.getMobileMbo(i).getValue("DISPLAYVALUESET").equals("1"))
/* 164:    */       {
/* 165:175 */         if (aspecBean.getMobileMbo(i).getValue("ASSETATTRIBUTE_DATATYPE").equals(extAln)) {
/* 166:177 */           aspecBean.getMobileMbo(i).setValue("DISPLAYVALUE", aspecBean.getMobileMbo(i).getValue("ALNVALUE"));
/* 167:    */         } else {
/* 168:181 */           aspecBean.getMobileMbo(i).setDoubleValue("DISPLAYVALUE", aspecBean.getMobileMbo(i).getDoubleValue("NUMVALUE"));
/* 169:    */         }
/* 170:183 */         aspecBean.getMobileMbo(i).setValue("DISPLAYVALUESET", "1");
/* 171:    */       }
/* 172:186 */       aspecBean.getMobileMbo(i).setValue("NEWVALUEMODIFIED", "0");
/* 173:    */       
/* 174:188 */       aspecBean.getMobileMbo(i).setValue("NEWVALUE", aspecBean.getMobileMbo(i).getValue("DISPLAYVALUE"));
/* 175:    */       
/* 176:190 */       String attribid = aspecBean.getMobileMbo(i).getValue("ASSETATTRID");
/* 177:193 */       for (int j = 0; j < attrvalcount; j++) {
/* 178:196 */         if (attrvaluedatabean.getMobileMbo(j).getValue(keyfield).equalsIgnoreCase(keyvalue)) {
/* 179:200 */           if (attrvaluedatabean.getMobileMbo(j).getValue("ATTRIBUTE").equalsIgnoreCase(attribid))
/* 180:    */           {
/* 181:203 */             aspecBean.getMobileMbo(i).setValue("COMPLETEDATETIME", attrvaluedatabean.getMobileMbo(j).getValue("COMPLETEDATETIME"));
/* 182:206 */             if (attrvaluedatabean.getMobileMbo(j).getValue("COMPLETEDATETIME").equalsIgnoreCase(""))
/* 183:    */             {
/* 184:210 */               aspecBean.getMobileMbo(i).setValue("NEWVALUEMODIFIED", "1");
/* 185:211 */               if (aspecBean.getMobileMbo(i).getValue("ASSETATTRIBUTE_DATATYPE").equals(extAln))
/* 186:    */               {
/* 187:212 */                 aspecBean.getMobileMbo(i).setValue("NEWVALUE", attrvaluedatabean.getMobileMbo(j).getValue("NEWALNVALUE")); break;
/* 188:    */               }
/* 189:214 */               aspecBean.getMobileMbo(i).setDoubleValue("NEWVALUE", attrvaluedatabean.getMobileMbo(j).getDoubleValue("NEWNUMVALUE"));
/* 190:    */               
/* 191:216 */               break;
/* 192:    */             }
/* 193:    */           }
/* 194:    */         }
/* 195:    */       }
/* 196:219 */       aspecBean.getMobileMbo(i).setValue("NEWVALUEUNCHANGED", aspecBean.getMobileMbo(i).getValue("NEWVALUE"));
/* 197:    */     }
/* 198:221 */     aspecBean.getDataBeanManager().save();
/* 199:223 */     if (wobean == null) {
/* 200:224 */       return true;
/* 201:    */     }
/* 202:227 */     if (page.equals("ASSET")) {
/* 203:229 */       filterData(wobean.getValue("SHOWPENDINGASSETCHANGES"), databean, false);
/* 204:231 */     } else if (page.equals("LOCATION")) {
/* 205:233 */       filterData(wobean.getValue("SHOWPENDINGLOCCHANGES"), databean, false);
/* 206:235 */     } else if (page.equals("CI")) {
/* 207:237 */       filterData(wobean.getValue("SHOWPENDINGCICHANGES"), databean, false);
/* 208:    */     }
/* 209:239 */     return true;
/* 210:    */   }
/* 211:    */   
/* 212:    */   public boolean updateSpecs(UIEvent event, String page)
/* 213:    */     throws MobileApplicationException
/* 214:    */   {
/* 215:244 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/* 216:245 */     MobileMboDataBean multibean = databean.getParentBean();
/* 217:246 */     MobileMboDataBean wobean = multibean.getParentBean();
/* 218:247 */     MobileMboDataBean attrvaluedatabean = null;
/* 219:249 */     if (UIUtil.checkESignature(event, multibean, "MASSMOVE"))
/* 220:    */     {
/* 221:251 */       String keyvalue = "";
/* 222:252 */       String keyfield = "";
/* 223:253 */       if (page.equals("ASSET"))
/* 224:    */       {
/* 225:255 */         keyfield = "ASSET";
/* 226:256 */         keyvalue = databean.getValue("ASSETNUM");
/* 227:257 */         attrvaluedatabean = multibean.getDataBean("ASSAUTOATTRUPDATE");
/* 228:258 */         if (attrvaluedatabean == null)
/* 229:    */         {
/* 230:259 */           attrvaluedatabean = new MobileMboDataBeanManager("ASSAUTOATTRUPDATE").getDataBean();
/* 231:260 */           attrvaluedatabean.reset();
/* 232:    */         }
/* 233:    */       }
/* 234:263 */       else if (page.equals("LOCATION"))
/* 235:    */       {
/* 236:265 */         keyfield = "LOCATION";
/* 237:266 */         keyvalue = databean.getValue("LOCATION");
/* 238:267 */         attrvaluedatabean = multibean.getDataBean("LOCAUTOATTRUPDATE");
/* 239:268 */         if (attrvaluedatabean == null)
/* 240:    */         {
/* 241:269 */           attrvaluedatabean = new MobileMboDataBeanManager("LOCAUTOATTRUPDATE").getDataBean();
/* 242:270 */           attrvaluedatabean.reset();
/* 243:    */         }
/* 244:    */       }
/* 245:273 */       else if (page.equals("CI"))
/* 246:    */       {
/* 247:275 */         keyfield = "CI";
/* 248:276 */         keyvalue = databean.getValue("CINUM");
/* 249:277 */         attrvaluedatabean = multibean.getDataBean("CIAUTOATTRUPDATE");
/* 250:278 */         if (attrvaluedatabean == null)
/* 251:    */         {
/* 252:279 */           attrvaluedatabean = new MobileMboDataBeanManager("CIAUTOATTRUPDATE").getDataBean();
/* 253:280 */           attrvaluedatabean.reset();
/* 254:    */         }
/* 255:    */       }
/* 256:284 */       String assetattrid = databean.getValue("ASSETATTRID");
/* 257:285 */       String newvalueunchanged = databean.getValue("NEWVALUEUNCHANGED");
/* 258:286 */       String newvalue = databean.getValue("NEWVALUE");
/* 259:289 */       if (newvalue.equals(newvalueunchanged)) {
/* 260:290 */         return true;
/* 261:    */       }
/* 262:293 */       boolean bcontainsattr = false;
/* 263:294 */       int attrvalcount = attrvaluedatabean != null ? attrvaluedatabean.count() : 0;
/* 264:295 */       for (int j = 0; j < attrvalcount; j++) {
/* 265:298 */         if (attrvaluedatabean.getMobileMbo(j).getValue(keyfield).equalsIgnoreCase(keyvalue)) {
/* 266:302 */           if (attrvaluedatabean.getMobileMbo(j).getValue("ATTRIBUTE").equalsIgnoreCase(assetattrid))
/* 267:    */           {
/* 268:307 */             if (!attrvaluedatabean.getMobileMbo(j).getValue("COMPLETEDATETIME").equalsIgnoreCase("")) {
/* 269:308 */               return true;
/* 270:    */             }
/* 271:320 */             if (attrvaluedatabean.getMobileMbo().isNew())
/* 272:    */             {
/* 273:326 */               String extAln = ((WOApp)UIUtil.getApplication()).getExternalValue(databean, "DATATYPE", "ALN");
/* 274:327 */               if (databean.getValue("ASSETATTRIBUTE_DATATYPE").equals(extAln)) {
/* 275:328 */                 attrvaluedatabean.getMobileMbo(j).setValue("NEWALNVALUE", newvalue);
/* 276:    */               } else {
/* 277:330 */                 attrvaluedatabean.getMobileMbo(j).setDoubleValue("NEWNUMVALUE", DefaultMobileMboDataFormatter.stringToDouble(newvalue));
/* 278:    */               }
/* 279:332 */               bcontainsattr = true;
/* 280:333 */               break;
/* 281:    */             }
/* 282:    */           }
/* 283:    */         }
/* 284:    */       }
/* 285:338 */       if (!bcontainsattr)
/* 286:    */       {
/* 287:341 */         attrvaluedatabean.insert();
/* 288:342 */         if (page.equals("ASSET")) {
/* 289:343 */           attrvaluedatabean.setValue("ASSET", databean.getValue("ASSETNUM"));
/* 290:344 */         } else if (page.equals("LOCATION")) {
/* 291:345 */           attrvaluedatabean.setValue("LOCATION", databean.getValue("LOCATION"));
/* 292:346 */         } else if (page.equals("CI")) {
/* 293:347 */           attrvaluedatabean.setValue("CINUM", databean.getValue("CINUM"));
/* 294:    */         }
/* 295:349 */         attrvaluedatabean.setValue("ATTRIBUTE", databean.getValue("ASSETATTRID"));
/* 296:350 */         attrvaluedatabean.setValue("SECTION", databean.getValue("SECTION"));
/* 297:    */         
/* 298:    */ 
/* 299:353 */         String extAln = ((WOApp)UIUtil.getApplication()).getExternalValue(databean, "DATATYPE", "ALN");
/* 300:354 */         if (databean.getValue("ASSETATTRIBUTE_DATATYPE").equals(extAln))
/* 301:    */         {
/* 302:356 */           attrvaluedatabean.setValue("OLDALNVALUE", databean.getValue("DISPLAYVALUE"));
/* 303:357 */           attrvaluedatabean.setValue("NEWALNVALUE", newvalue);
/* 304:    */         }
/* 305:    */         else
/* 306:    */         {
/* 307:361 */           attrvaluedatabean.setValue("OLDNUMVALUE", databean.getValue("DISPLAYVALUE"));
/* 308:362 */           attrvaluedatabean.setValue("NEWNUMVALUE", newvalue);
/* 309:    */         }
/* 310:    */       }
/* 311:371 */       if (wobean != null)
/* 312:    */       {
/* 313:373 */         attrvaluedatabean.setValue("WONUM", wobean.getValue("WONUM"));
/* 314:374 */         attrvaluedatabean.setValue("SITEID", wobean.getValue("SITEID"));
/* 315:375 */         attrvaluedatabean.setValue("WORKSITEID", wobean.getValue("SITEID"));
/* 316:376 */         attrvaluedatabean.setValue("WORKORGID", wobean.getValue("ORGID"));
/* 317:377 */         wobean.setValue("EXECUTEATTRMOVECHANGES", "1");
/* 318:    */       }
/* 319:    */       else
/* 320:    */       {
/* 321:380 */         attrvaluedatabean.setValue("WONUM", multibean.getValue("WONUM"));
/* 322:381 */         attrvaluedatabean.setValue("SITEID", multibean.getValue("SITEID"));
/* 323:382 */         attrvaluedatabean.setValue("WORKSITEID", multibean.getValue("SITEID"));
/* 324:383 */         attrvaluedatabean.setValue("WORKORGID", multibean.getValue("ORGID"));
/* 325:384 */         multibean.setValue("EXECUTEATTRMOVECHANGES", "1");
/* 326:    */       }
/* 327:391 */       String extAln = ((WOApp)UIUtil.getApplication()).getExternalValue(databean, "DATATYPE", "ALN");
/* 328:392 */       if (databean.getValue("ASSETATTRIBUTE_DATATYPE").equals(extAln)) {
/* 329:393 */         databean.setValue("ALNVALUE", newvalue);
/* 330:    */       } else {
/* 331:395 */         databean.setValue("NUMVALUE", newvalue);
/* 332:    */       }
/* 333:397 */       databean.setValue("NEWVALUEMODIFIED", "1");
/* 334:    */       
/* 335:    */ 
/* 336:    */ 
/* 337:    */ 
/* 338:402 */       databean.getDataBeanManager().save();
/* 339:403 */       multibean.getDataBeanManager().save();
/* 340:404 */       attrvaluedatabean.getDataBeanManager().save();
/* 341:406 */       if (wobean != null) {
/* 342:408 */         wobean.getDataBeanManager().save();
/* 343:    */       }
/* 344:410 */       UIUtil.getApplication().removeCurrentScreen(false);
/* 345:    */     }
/* 346:413 */     return true;
/* 347:    */   }
/* 348:    */   
/* 349:    */   public boolean toggleSpecView(UIEvent event)
/* 350:    */     throws MobileApplicationException
/* 351:    */   {
/* 352:418 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/* 353:419 */     filterData((String)event.getValue(), databean, true);
/* 354:    */     
/* 355:421 */     return true;
/* 356:    */   }
/* 357:    */   
/* 358:    */   public boolean filterData(String checkValue, MobileMboDataBean databean, boolean refresh)
/* 359:    */     throws MobileApplicationException
/* 360:    */   {
/* 361:443 */     if (checkValue.equals("true"))
/* 362:    */     {
/* 363:445 */       databean.getQBE().setQBE("NEWVALUEMODIFIED", "1");
/* 364:446 */       databean.getQBE().setQbeExactMatch(true);
/* 365:    */     }
/* 366:    */     else
/* 367:    */     {
/* 368:450 */       databean.getQBE().reset();
/* 369:    */     }
/* 370:452 */     databean.reset();
/* 371:453 */     if (refresh) {
/* 372:454 */       UIUtil.refreshCurrentScreen();
/* 373:    */     }
/* 374:457 */     return true;
/* 375:    */   }
/* 376:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.mobilewo.WOSpecEventHandler
 * JD-Core Version:    0.7.0.1
 */