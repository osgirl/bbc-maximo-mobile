/*   1:    */ package com.mro.mobile.app.mobilewo;
/*   2:    */ 
/*   3:    */ import com.ibm.tivoli.maximo.util.mboadapter.mobile.MobileMboAdapter;
/*   4:    */ import com.mro.mobile.MobileApplicationException;
/*   5:    */ import com.mro.mobile.app.pluscmobwo.PlusCMobileWODelegate;
/*   6:    */ import com.mro.mobile.ui.MobileMboDataBean;
/*   7:    */ import com.mro.mobile.ui.res.UIUtil;
/*   8:    */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*   9:    */ import com.mro.mobileapp.WOApp;
/*  10:    */ import java.util.Vector;
/*  11:    */ import psdi.plusc.app.pluscwo.pluscmobilecommon.PlusCWODelegate;
/*  12:    */ 
/*  13:    */ public class WOStatusHandler
/*  14:    */ {
/*  15: 36 */   WOApp woapp = null;
/*  16: 39 */   MobileMboDataBean wodatabean = null;
/*  17:    */   private static final String unapprList = "WSCH";
/*  18:    */   private static final String apprList = "APPR,WAPPR,WSCH";
/*  19:    */   private static final String wmatlList = "WMATL,APPR,INPRG,WSCH";
/*  20:    */   private static final String inprgList = "INPRG,WAPPR,APPR,WSCH,WMATL";
/*  21:    */   private static final String compList = "COMP,WAPPR,APPR,WSCH,WMATL,INPRG";
/*  22:    */   private static final String closeList = "WSCH";
/*  23:    */   private static final String cancelList = "CAN,WAPPR,APPR,WMATL,WSCH";
/*  24:    */   
/*  25:    */   public WOStatusHandler(WOApp app, MobileMboDataBean womdb)
/*  26:    */   {
/*  27: 44 */     this.woapp = app;
/*  28: 45 */     this.wodatabean = womdb;
/*  29:    */   }
/*  30:    */   
/*  31:    */   private boolean possibleStatusChange(String currentMaxStatus, String desiredMaxStatus)
/*  32:    */   {
/*  33: 69 */     if ((desiredMaxStatus.equals("WAPPR")) && ("WSCH".indexOf(currentMaxStatus) == -1)) {
/*  34: 71 */       return false;
/*  35:    */     }
/*  36: 73 */     if ((desiredMaxStatus.equals("APPR")) && ("APPR,WAPPR,WSCH".indexOf(currentMaxStatus) == -1)) {
/*  37: 75 */       return false;
/*  38:    */     }
/*  39: 77 */     if ((desiredMaxStatus.equals("WMATL")) && ("WMATL,APPR,INPRG,WSCH".indexOf(currentMaxStatus) == -1)) {
/*  40: 79 */       return false;
/*  41:    */     }
/*  42: 81 */     if ((desiredMaxStatus.equals("INPRG")) && ("INPRG,WAPPR,APPR,WSCH,WMATL".indexOf(currentMaxStatus) == -1)) {
/*  43: 83 */       return false;
/*  44:    */     }
/*  45: 85 */     if ((desiredMaxStatus.equals("COMP")) && ("COMP,WAPPR,APPR,WSCH,WMATL,INPRG".indexOf(currentMaxStatus) == -1)) {
/*  46: 87 */       return false;
/*  47:    */     }
/*  48: 89 */     if ((desiredMaxStatus.equals("CLOSE")) && ("WSCH".indexOf(currentMaxStatus) == -1)) {
/*  49: 91 */       return false;
/*  50:    */     }
/*  51: 93 */     if ((desiredMaxStatus.equals("CAN")) && ("CAN,WAPPR,APPR,WMATL,WSCH".indexOf(currentMaxStatus) == -1)) {
/*  52: 95 */       return false;
/*  53:    */     }
/*  54: 97 */     if (desiredMaxStatus.equals("WSCH")) {
/*  55: 99 */       return false;
/*  56:    */     }
/*  57:102 */     return true;
/*  58:    */   }
/*  59:    */   
/*  60:    */   public boolean canChangeStatus(String currentStatus, String desiredStatus)
/*  61:    */     throws MobileApplicationException
/*  62:    */   {
/*  63:115 */     String currentMaxStatus = this.woapp.getInternalValue(this.wodatabean, "WOSTATUS", currentStatus);
/*  64:116 */     String desiredMaxStatus = this.woapp.getInternalValue(this.wodatabean, "WOSTATUS", desiredStatus);
/*  65:119 */     if ((desiredMaxStatus.equals("WSCH")) || (desiredMaxStatus.equals("HISTEDIT")) || (desiredStatus.equals("WSCH")) || (desiredStatus.equals("HISTEDIT")) || (desiredStatus.equals("WPCOND"))) {
/*  66:122 */       return false;
/*  67:    */     }
/*  68:125 */     if (!possibleStatusChange(currentMaxStatus, desiredMaxStatus)) {
/*  69:126 */       return false;
/*  70:    */     }
/*  71:129 */     if (desiredMaxStatus.equals("APPR"))
/*  72:    */     {
/*  73:130 */       if (!canApprove(currentMaxStatus)) {
/*  74:130 */         return false;
/*  75:    */       }
/*  76:    */     }
/*  77:131 */     else if (desiredMaxStatus.equals("INPRG"))
/*  78:    */     {
/*  79:132 */       if (!canInitiate(currentMaxStatus)) {
/*  80:132 */         return false;
/*  81:    */       }
/*  82:    */     }
/*  83:133 */     else if (desiredMaxStatus.equals("COMP"))
/*  84:    */     {
/*  85:134 */       if (!canComplete(currentMaxStatus)) {
/*  86:134 */         return false;
/*  87:    */       }
/*  88:    */     }
/*  89:    */     else
/*  90:    */     {
/*  91:135 */       if (desiredMaxStatus.equals("CLOSE")) {
/*  92:136 */         return false;
/*  93:    */       }
/*  94:137 */       if (desiredMaxStatus.equals("CAN"))
/*  95:    */       {
/*  96:138 */         if (!canCancel(currentMaxStatus)) {
/*  97:138 */           return false;
/*  98:    */         }
/*  99:    */       }
/* 100:    */       else
/* 101:    */       {
/* 102:139 */         if (desiredMaxStatus.equals("WAPPR")) {
/* 103:140 */           return false;
/* 104:    */         }
/* 105:141 */         if (!desiredMaxStatus.equals("WMATL"))
/* 106:    */         {
/* 107:144 */           if (desiredMaxStatus.equals("WSCH")) {
/* 108:145 */             return false;
/* 109:    */           }
/* 110:146 */           if (desiredMaxStatus.equals("WPCOND")) {
/* 111:147 */             return false;
/* 112:    */           }
/* 113:151 */           return false;
/* 114:    */         }
/* 115:    */       }
/* 116:    */     }
/* 117:155 */     String optionName = getOptionName(desiredMaxStatus);
/* 118:    */     
/* 119:157 */     return checkUserSecurity(optionName);
/* 120:    */   }
/* 121:    */   
/* 122:    */   public boolean checkUserSecurity(String optionName)
/* 123:    */     throws MobileApplicationException
/* 124:    */   {
/* 125:168 */     if ((optionName == null) || (optionName.equals(""))) {
/* 126:168 */       return false;
/* 127:    */     }
/* 128:170 */     if (this.wodatabean != null) {
/* 129:171 */       return this.wodatabean.isOptionAuthorized(optionName);
/* 130:    */     }
/* 131:173 */     return this.woapp.isOptionAuthorized(optionName);
/* 132:    */   }
/* 133:    */   
/* 134:    */   public boolean isChangeOK(String currentStatus, String desiredStatus)
/* 135:    */     throws MobileApplicationException
/* 136:    */   {
/* 137:189 */     MobileMboDataBean woDatabean = UIUtil.getCurrentScreen().getDataBean();
/* 138:190 */     PlusCWODelegate wo = new PlusCMobileWODelegate(new MobileMboAdapter(woDatabean.getMobileMbo(), woDatabean));
/* 139:    */     try
/* 140:    */     {
/* 141:192 */       if (!wo.isChangeOK(currentStatus, desiredStatus)) {
/* 142:193 */         return false;
/* 143:    */       }
/* 144:    */     }
/* 145:    */     catch (MobileApplicationException me)
/* 146:    */     {
/* 147:196 */       throw me;
/* 148:    */     }
/* 149:    */     catch (RuntimeException rte)
/* 150:    */     {
/* 151:197 */       throw rte;
/* 152:    */     }
/* 153:    */     catch (Exception e)
/* 154:    */     {
/* 155:199 */       e.printStackTrace();
/* 156:200 */       throw new MobileApplicationException("internalerror", e);
/* 157:    */     }
/* 158:209 */     String desiredOptionName = getOptionName(desiredStatus);
/* 159:210 */     String currentOptionName = getOptionName(currentStatus);
/* 160:212 */     if (desiredOptionName == null) {
/* 161:214 */       return false;
/* 162:    */     }
/* 163:216 */     if (desiredOptionName.equals("CANCEL")) {
/* 164:218 */       return checkUserSecurity(desiredOptionName);
/* 165:    */     }
/* 166:220 */     if (desiredOptionName.equals("UNDOAPPR")) {
/* 167:222 */       return checkUserSecurity(desiredOptionName);
/* 168:    */     }
/* 169:225 */     Vector statusProgression = getStatusProgression();
/* 170:226 */     int currentPos = statusProgression.indexOf(currentOptionName);
/* 171:227 */     int desiredPos = statusProgression.indexOf(desiredOptionName);
/* 172:229 */     if (currentPos > desiredPos) {
/* 173:231 */       return checkUserSecurity(desiredOptionName);
/* 174:    */     }
/* 175:235 */     for (int i = currentPos + 1; i <= desiredPos; i++)
/* 176:    */     {
/* 177:237 */       String oneOptionName = (String)statusProgression.get(i);
/* 178:238 */       if (!checkUserSecurity(oneOptionName)) {
/* 179:240 */         return false;
/* 180:    */       }
/* 181:    */     }
/* 182:244 */     return true;
/* 183:    */   }
/* 184:    */   
/* 185:250 */   private static Vector spVector = null;
/* 186:    */   
/* 187:    */   protected static Vector getStatusProgression()
/* 188:    */   {
/* 189:256 */     synchronized (WOStatusHandler.class)
/* 190:    */     {
/* 191:258 */       if (spVector == null)
/* 192:    */       {
/* 193:260 */         spVector = new Vector();
/* 194:261 */         spVector.add("UNDOAPPR");
/* 195:262 */         spVector.add("APPR");
/* 196:263 */         spVector.add("INIT");
/* 197:264 */         spVector.add("COMP");
/* 198:265 */         spVector.add("CLOSE");
/* 199:    */       }
/* 200:    */     }
/* 201:268 */     return spVector;
/* 202:    */   }
/* 203:    */   
/* 204:    */   String getOptionName(String status)
/* 205:    */   {
/* 206:282 */     String optionName = null;
/* 207:283 */     if ((status.equals("APPR")) || (status.equals("COMP")) || (status.equals("CLOSE"))) {
/* 208:285 */       optionName = status;
/* 209:287 */     } else if (status.equals("WMATL")) {
/* 210:289 */       optionName = "APPR";
/* 211:291 */     } else if (status.equals("CAN")) {
/* 212:293 */       optionName = "CANCEL";
/* 213:295 */     } else if (status.equals("INPRG")) {
/* 214:297 */       optionName = "INIT";
/* 215:299 */     } else if (status.equals("WAPPR")) {
/* 216:301 */       optionName = "UNDOAPPR";
/* 217:303 */     } else if (status.equals("WSCH")) {
/* 218:305 */       optionName = "APPR";
/* 219:    */     }
/* 220:307 */     return optionName;
/* 221:    */   }
/* 222:    */   
/* 223:    */   boolean canUnapprove(String currentStatus)
/* 224:    */     throws MobileApplicationException
/* 225:    */   {
/* 226:316 */     if (!isChangeOK(currentStatus, "WAPPR")) {
/* 227:318 */       return false;
/* 228:    */     }
/* 229:320 */     return true;
/* 230:    */   }
/* 231:    */   
/* 232:    */   boolean canWaitMaterial(String currentStatus)
/* 233:    */     throws MobileApplicationException
/* 234:    */   {
/* 235:331 */     if (!isChangeOK(currentStatus, "WMATL")) {
/* 236:333 */       return false;
/* 237:    */     }
/* 238:335 */     return true;
/* 239:    */   }
/* 240:    */   
/* 241:    */   boolean canApprove(String currentStatus)
/* 242:    */     throws MobileApplicationException
/* 243:    */   {
/* 244:345 */     if (!isChangeOK(currentStatus, "APPR")) {
/* 245:347 */       return false;
/* 246:    */     }
/* 247:349 */     return true;
/* 248:    */   }
/* 249:    */   
/* 250:    */   boolean canInitiate(String currentStatus)
/* 251:    */     throws MobileApplicationException
/* 252:    */   {
/* 253:359 */     if (!isChangeOK(currentStatus, "INPRG")) {
/* 254:361 */       return false;
/* 255:    */     }
/* 256:363 */     return true;
/* 257:    */   }
/* 258:    */   
/* 259:    */   boolean canComplete(String currentStatus)
/* 260:    */     throws MobileApplicationException
/* 261:    */   {
/* 262:372 */     if (!isChangeOK(currentStatus, "COMP")) {
/* 263:374 */       return false;
/* 264:    */     }
/* 265:376 */     return true;
/* 266:    */   }
/* 267:    */   
/* 268:    */   boolean canClose(String currentStatus)
/* 269:    */     throws MobileApplicationException
/* 270:    */   {
/* 271:385 */     if (!isChangeOK(currentStatus, "CLOSE")) {
/* 272:387 */       return false;
/* 273:    */     }
/* 274:390 */     return true;
/* 275:    */   }
/* 276:    */   
/* 277:    */   boolean canCancel(String currentStatus)
/* 278:    */     throws MobileApplicationException
/* 279:    */   {
/* 280:401 */     if (!isChangeOK(currentStatus, "CAN")) {
/* 281:403 */       return false;
/* 282:    */     }
/* 283:406 */     return true;
/* 284:    */   }
/* 285:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.mobilewo.WOStatusHandler
 * JD-Core Version:    0.7.0.1
 */