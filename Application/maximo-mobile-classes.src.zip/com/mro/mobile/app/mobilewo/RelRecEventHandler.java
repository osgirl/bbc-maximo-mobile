/*   1:    */ package com.mro.mobile.app.mobilewo;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.mbo.MobileMbo;
/*   5:    */ import com.mro.mobile.mbo.MobileMboQBE;
/*   6:    */ import com.mro.mobile.ui.MobileMboDataBean;
/*   7:    */ import com.mro.mobile.ui.event.UIEvent;
/*   8:    */ import com.mro.mobile.ui.res.UIUtil;
/*   9:    */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*  10:    */ 
/*  11:    */ public class RelRecEventHandler
/*  12:    */   extends MobileWOCommonEventHandler
/*  13:    */ {
/*  14:    */   public boolean performEvent(UIEvent event)
/*  15:    */     throws MobileApplicationException
/*  16:    */   {
/*  17: 28 */     if (event == null) {
/*  18: 28 */       return false;
/*  19:    */     }
/*  20: 30 */     String eventId = event.getEventName();
/*  21: 32 */     if (eventId.equalsIgnoreCase("initrelwolookup")) {
/*  22: 34 */       return initrelwolookup(event);
/*  23:    */     }
/*  24: 36 */     if (eventId.equalsIgnoreCase("initreltklookup")) {
/*  25: 38 */       return initreltklookup(event);
/*  26:    */     }
/*  27: 40 */     if (eventId.equalsIgnoreCase("refreshlookup")) {
/*  28: 42 */       return refreshlookup(event);
/*  29:    */     }
/*  30: 45 */     return false;
/*  31:    */   }
/*  32:    */   
/*  33:    */   public boolean refreshlookup(UIEvent event)
/*  34:    */     throws MobileApplicationException
/*  35:    */   {
/*  36: 50 */     MobileMboDataBean dataBean = UIUtil.getCurrentScreen().getDataBean();
/*  37: 51 */     dataBean.resetWithoutSite();
/*  38:    */     
/*  39: 53 */     return true;
/*  40:    */   }
/*  41:    */   
/*  42:    */   public boolean initrelwolookup(UIEvent event)
/*  43:    */     throws MobileApplicationException
/*  44:    */   {
/*  45: 58 */     MobileMboDataBean laudatabean = UIUtil.getCurrentScreen().getDataBean();
/*  46: 59 */     MobileMboDataBean databean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*  47:    */     
/*  48:    */ 
/*  49:    */ 
/*  50:    */ 
/*  51:    */ 
/*  52:    */ 
/*  53:    */ 
/*  54:    */ 
/*  55: 68 */     long idStr = laudatabean.getMobileMbo().getLongValue("_ID");
/*  56: 69 */     if (idStr > 0L)
/*  57:    */     {
/*  58: 71 */       databean.getQBE().reset();
/*  59:    */       
/*  60:    */ 
/*  61: 74 */       databean.getQBE().setQBE("_ID", "!=" + Long.toString(idStr));
/*  62:    */       
/*  63:    */ 
/*  64: 77 */       databean.getQBE().setQBE("HISTORYFLAG", "0");
/*  65: 78 */       databean.getQBE().setQBE("ISTASK", "0");
/*  66:    */       
/*  67:    */ 
/*  68:    */ 
/*  69:    */ 
/*  70: 83 */       databean.resetWithoutSite();
/*  71:    */     }
/*  72: 92 */     return true;
/*  73:    */   }
/*  74:    */   
/*  75:    */   public boolean initreltklookup(UIEvent event)
/*  76:    */     throws MobileApplicationException
/*  77:    */   {
/*  78: 97 */     MobileMboDataBean laudatabean = UIUtil.getCurrentScreen().getDataBean();
/*  79: 98 */     MobileMboDataBean databean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*  80:    */     
/*  81:    */ 
/*  82:    */ 
/*  83:    */ 
/*  84:    */ 
/*  85:    */ 
/*  86:105 */     long idStr = laudatabean.getMobileMbo().getLongValue("_ID");
/*  87:106 */     if (idStr > 0L)
/*  88:    */     {
/*  89:108 */       databean.getQBE().reset();
/*  90:    */       
/*  91:    */ 
/*  92:111 */       databean.getQBE().setQBE("_ID", "!=" + Long.toString(idStr));
/*  93:    */       
/*  94:    */ 
/*  95:    */ 
/*  96:    */ 
/*  97:116 */       databean.getQBE().setQBE("HISTORYFLAG", "0");
/*  98:    */       
/*  99:    */ 
/* 100:    */ 
/* 101:    */ 
/* 102:121 */       databean.resetWithoutSite();
/* 103:    */     }
/* 104:130 */     return true;
/* 105:    */   }
/* 106:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.mobilewo.RelRecEventHandler
 * JD-Core Version:    0.7.0.1
 */