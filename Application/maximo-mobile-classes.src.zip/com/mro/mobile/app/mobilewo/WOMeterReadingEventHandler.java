/*   1:    */ package com.mro.mobile.app.mobilewo;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.MobileMessageGenerator;
/*   5:    */ import com.mro.mobile.app.DefaultMobileMboDataFormatter;
/*   6:    */ import com.mro.mobile.mbo.MobileMbo;
/*   7:    */ import com.mro.mobile.mbo.MobileMboOrder;
/*   8:    */ import com.mro.mobile.mbo.MobileMboQBE;
/*   9:    */ import com.mro.mobile.ui.MobileMboDataBean;
/*  10:    */ import com.mro.mobile.ui.MobileMboDataBeanManager;
/*  11:    */ import com.mro.mobile.ui.event.UIEvent;
/*  12:    */ import com.mro.mobile.ui.res.UIUtil;
/*  13:    */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*  14:    */ import com.mro.mobile.ui.res.controls.PageControl;
/*  15:    */ import com.mro.mobile.ui.res.controls.TableControl;
/*  16:    */ import com.mro.mobileapp.WOApp;
/*  17:    */ import java.text.DecimalFormat;
/*  18:    */ import java.text.NumberFormat;
/*  19:    */ import java.text.ParseException;
/*  20:    */ import java.util.Date;
/*  21:    */ import java.util.Locale;
/*  22:    */ 
/*  23:    */ public class WOMeterReadingEventHandler
/*  24:    */   extends MobileWOCommonEventHandler
/*  25:    */ {
/*  26:    */   public boolean performEvent(UIEvent event)
/*  27:    */     throws MobileApplicationException
/*  28:    */   {
/*  29: 41 */     if (event == null) {
/*  30: 41 */       return false;
/*  31:    */     }
/*  32: 43 */     String eventId = event.getEventName();
/*  33: 45 */     if (eventId.equalsIgnoreCase("initAssetMeterReading")) {
/*  34: 47 */       return initAssetMeterReading(event);
/*  35:    */     }
/*  36: 49 */     if (eventId.equalsIgnoreCase("initLocMeterReading")) {
/*  37: 51 */       return initLocMeterReading(event);
/*  38:    */     }
/*  39: 53 */     if (eventId.equalsIgnoreCase("initAssetMeterReadingHist")) {
/*  40: 55 */       return initAssetMeterReadingHist(event);
/*  41:    */     }
/*  42: 57 */     if (eventId.equalsIgnoreCase("initLocMeterReadingHist")) {
/*  43: 59 */       return initLocMeterReadingHist(event);
/*  44:    */     }
/*  45: 61 */     if (eventId.equalsIgnoreCase("initMeterReadings")) {
/*  46: 63 */       return initMeterReadings(event);
/*  47:    */     }
/*  48: 65 */     if (eventId.equalsIgnoreCase("validateAssetReading")) {
/*  49: 67 */       return validateAssetReading(event);
/*  50:    */     }
/*  51: 69 */     if (eventId.equalsIgnoreCase("validateLocationReading")) {
/*  52: 71 */       return validateLocationReading(event);
/*  53:    */     }
/*  54: 73 */     if (eventId.equalsIgnoreCase("validateReading")) {
/*  55: 75 */       return validateReading(event);
/*  56:    */     }
/*  57: 77 */     if (eventId.equalsIgnoreCase("validateReadingDate")) {
/*  58: 79 */       return validateReadingDate(event);
/*  59:    */     }
/*  60: 81 */     if (eventId.equalsIgnoreCase("deletemeterreading")) {
/*  61: 83 */       return deletemeterreading(event);
/*  62:    */     }
/*  63: 85 */     if (eventId.equalsIgnoreCase("filterbydomainid")) {
/*  64: 87 */       return filterbydomainid(event);
/*  65:    */     }
/*  66: 90 */     if ("gotoassetmeterpage".equalsIgnoreCase(eventId)) {
/*  67: 92 */       return goToMeterPage(event, "ASSET");
/*  68:    */     }
/*  69: 95 */     if ("gotolocmeterpage".equalsIgnoreCase(eventId)) {
/*  70: 97 */       return goToMeterPage(event, "LOCATION");
/*  71:    */     }
/*  72:100 */     super.performEvent(event);
/*  73:    */     
/*  74:102 */     return false;
/*  75:    */   }
/*  76:    */   
/*  77:    */   protected boolean goToMeterPage(UIEvent event, String objectType)
/*  78:    */   {
/*  79:114 */     AbstractMobileControl control = (AbstractMobileControl)event.getCreatingObject();
/*  80:116 */     if (control != null)
/*  81:    */     {
/*  82:117 */       String parentDataSrcName = control.getStringValue("datasrcname");
/*  83:119 */       if ("ASSET".equalsIgnoreCase(objectType))
/*  84:    */       {
/*  85:120 */         if ("WOMULTI".equalsIgnoreCase(parentDataSrcName)) {
/*  86:121 */           event.setValue("multiassetmeter");
/*  87:    */         } else {
/*  88:125 */           event.setValue("woassetmeter");
/*  89:    */         }
/*  90:    */       }
/*  91:130 */       else if ("WOMULTI".equalsIgnoreCase(parentDataSrcName)) {
/*  92:131 */         event.setValue("multilocmeter");
/*  93:    */       } else {
/*  94:135 */         event.setValue("wolocmeter");
/*  95:    */       }
/*  96:138 */       event.setEventName("gotopage");
/*  97:    */     }
/*  98:141 */     return false;
/*  99:    */   }
/* 100:    */   
/* 101:    */   public boolean initAssetMeterReading(UIEvent event)
/* 102:    */     throws MobileApplicationException
/* 103:    */   {
/* 104:146 */     return initMeterReading(event, "ASSET");
/* 105:    */   }
/* 106:    */   
/* 107:    */   public boolean initLocMeterReading(UIEvent event)
/* 108:    */     throws MobileApplicationException
/* 109:    */   {
/* 110:151 */     return initMeterReading(event, "LOCATION");
/* 111:    */   }
/* 112:    */   
/* 113:    */   public boolean initMeterReading(UIEvent event, String mboObj)
/* 114:    */     throws MobileApplicationException
/* 115:    */   {
/* 116:157 */     MobileMboDataBean databean = ((PageControl)event.getCreatingObject()).getDataBean();
/* 117:    */     
/* 118:    */ 
/* 119:160 */     databean.setValue("NEWREADING", "");
/* 120:161 */     databean.setValue("NEWREADINGDATE", "");
/* 121:    */     
/* 122:163 */     databean.setValue("ISDELTA", "", false);
/* 123:164 */     databean.setValue("DOROLLOVER", "");
/* 124:165 */     databean.setValue("INSPECTOR", "");
/* 125:166 */     databean.setValue("REMARKS", "");
/* 126:    */     
/* 127:    */ 
/* 128:169 */     databean.setValue("INSPECTOR", WOApp.getUsersPersonId());
/* 129:170 */     databean.getMobileMbo().setDateValue("NEWREADINGDATE", databean.getCurrentTime());
/* 130:    */     
/* 131:    */ 
/* 132:173 */     String metertype = ((WOApp)UIUtil.getApplication()).getInternalValue(databean, "METERTYPE", databean.getValue("METER_METERTYPE"));
/* 133:174 */     if (mboObj.equals("ASSET"))
/* 134:    */     {
/* 135:176 */       if (metertype.equals("GAUGE"))
/* 136:    */       {
/* 137:178 */         UIUtil.gotoPageNoSave("woassetmeter_gauge", UIUtil.getCurrentScreen());
/* 138:179 */         event.setEventErrored();
/* 139:    */       }
/* 140:181 */       else if (metertype.equals("CHARACTERISTIC"))
/* 141:    */       {
/* 142:183 */         UIUtil.gotoPageNoSave("woassetmeter_char", UIUtil.getCurrentScreen());
/* 143:    */         
/* 144:185 */         event.setEventErrored();
/* 145:    */       }
/* 146:    */     }
/* 147:188 */     else if (mboObj.equals("LOCATION")) {
/* 148:190 */       if (metertype.equals("GAUGE"))
/* 149:    */       {
/* 150:192 */         UIUtil.gotoPageNoSave("wolocmeter_gauge", UIUtil.getCurrentScreen());
/* 151:193 */         event.setEventErrored();
/* 152:    */       }
/* 153:195 */       else if (metertype.equals("CHARACTERISTIC"))
/* 154:    */       {
/* 155:197 */         UIUtil.gotoPageNoSave("wolocmeter_char", UIUtil.getCurrentScreen());
/* 156:198 */         event.setEventErrored();
/* 157:    */       }
/* 158:    */     }
/* 159:203 */     String SrolloverValue = databean.getValue("ROLLOVER");
/* 160:204 */     double rolloverValue = DefaultMobileMboDataFormatter.stringToDouble(SrolloverValue);
/* 161:205 */     if (rolloverValue == 0.0D) {
/* 162:206 */       databean.getMobileMbo().setReadOnly("DOROLLOVER", true);
/* 163:    */     }
/* 164:209 */     String readingtype = ((WOApp)UIUtil.getApplication()).getInternalValue(databean, "METERREADINGTYPE", databean.getValue("METER_READINGTYPE"));
/* 165:211 */     if (readingtype.equals("DELTA")) {
/* 166:213 */       databean.setValue("ISDELTA", "1", false);
/* 167:    */     }
/* 168:215 */     return true;
/* 169:    */   }
/* 170:    */   
/* 171:    */   public boolean initAssetMeterReadingHist(UIEvent event)
/* 172:    */     throws MobileApplicationException
/* 173:    */   {
/* 174:220 */     return initMeterReadingHist(event, "ASSET");
/* 175:    */   }
/* 176:    */   
/* 177:    */   public boolean initLocMeterReadingHist(UIEvent event)
/* 178:    */     throws MobileApplicationException
/* 179:    */   {
/* 180:225 */     return initMeterReadingHist(event, "LOCATION");
/* 181:    */   }
/* 182:    */   
/* 183:    */   public boolean initMeterReadingHist(UIEvent event, String mboObj)
/* 184:    */     throws MobileApplicationException
/* 185:    */   {
/* 186:231 */     MobileMboDataBean databean = ((PageControl)event.getCreatingObject()).getDataBean();
/* 187:    */     
/* 188:    */ 
/* 189:234 */     String metertype = ((WOApp)UIUtil.getApplication()).getInternalValue(databean, "METERTYPE", databean.getValue("METER_METERTYPE"));
/* 190:235 */     if (mboObj.equals("ASSET"))
/* 191:    */     {
/* 192:237 */       if (metertype.equals("GAUGE"))
/* 193:    */       {
/* 194:239 */         UIUtil.gotoPageNoSave("woassetmeterread_gauge", UIUtil.getCurrentScreen());
/* 195:240 */         event.setEventErrored();
/* 196:    */       }
/* 197:242 */       else if (metertype.equals("CHARACTERISTIC"))
/* 198:    */       {
/* 199:244 */         UIUtil.gotoPageNoSave("woassetmeterread_char", UIUtil.getCurrentScreen());
/* 200:245 */         event.setEventErrored();
/* 201:    */       }
/* 202:    */     }
/* 203:248 */     else if (mboObj.equals("LOCATION")) {
/* 204:250 */       if (metertype.equals("GAUGE"))
/* 205:    */       {
/* 206:252 */         UIUtil.gotoPageNoSave("wolocmeterread_gauge", UIUtil.getCurrentScreen());
/* 207:253 */         event.setEventErrored();
/* 208:    */       }
/* 209:255 */       else if (metertype.equals("CHARACTERISTIC"))
/* 210:    */       {
/* 211:257 */         UIUtil.gotoPageNoSave("wolocmeterread_char", UIUtil.getCurrentScreen());
/* 212:258 */         event.setEventErrored();
/* 213:    */       }
/* 214:    */     }
/* 215:263 */     String SrolloverValue = databean.getValue("ROLLOVER");
/* 216:264 */     double rolloverValue = DefaultMobileMboDataFormatter.stringToDouble(SrolloverValue);
/* 217:265 */     if (rolloverValue == 0.0D) {
/* 218:266 */       databean.getMobileMbo().setReadOnly("DOROLLOVER", true);
/* 219:    */     }
/* 220:268 */     return true;
/* 221:    */   }
/* 222:    */   
/* 223:    */   public boolean validateAssetReading(UIEvent event)
/* 224:    */     throws MobileApplicationException
/* 225:    */   {
/* 226:273 */     return validateMeterReading(event, "ASSET");
/* 227:    */   }
/* 228:    */   
/* 229:    */   public boolean validateLocationReading(UIEvent event)
/* 230:    */     throws MobileApplicationException
/* 231:    */   {
/* 232:278 */     return validateMeterReading(event, "LOCATION");
/* 233:    */   }
/* 234:    */   
/* 235:    */   public boolean validateMeterReading(UIEvent event, String mboObj)
/* 236:    */     throws MobileApplicationException
/* 237:    */   {
/* 238:284 */     if (!UIUtil.getCurrentScreen().checkRequiredFields())
/* 239:    */     {
/* 240:285 */       event.setEventErrored();
/* 241:286 */       return true;
/* 242:    */     }
/* 243:289 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/* 244:290 */     MobileMboDataBean wodatabean = databean.getParentBean();
/* 245:    */     
/* 246:    */ 
/* 247:293 */     checkReading(databean.getValue("NEWREADING"), true);
/* 248:    */     
/* 249:295 */     String sdb = "ASSETMETERREADINGS";
/* 250:296 */     if (mboObj.equals("LOCATION")) {
/* 251:297 */       sdb = "LOCMETERREADINGS";
/* 252:    */     }
/* 253:298 */     MobileMboDataBean mrdatabean = wodatabean.getDataBean(sdb);
/* 254:    */     
/* 255:    */ 
/* 256:301 */     mrdatabean.insert();
/* 257:303 */     if (mboObj.equals("ASSET")) {
/* 258:304 */       mrdatabean.setValue("ASSETNUM", databean.getValue("ASSETNUM"));
/* 259:    */     }
/* 260:305 */     if (mboObj.equals("LOCATION")) {
/* 261:306 */       mrdatabean.setValue("LOCATION", databean.getValue("LOCATION"));
/* 262:    */     }
/* 263:308 */     mrdatabean.setValue("METERNAME", databean.getValue("METERNAME"));
/* 264:310 */     if (isNumbericValue(databean.getValue("NEWREADING")))
/* 265:    */     {
/* 266:312 */       mrdatabean.getMobileMbo().setDoubleValue("TEMP_NEWREADING", convertFormattedValueToDouble(databean.getValue("NEWREADING")));
/* 267:    */       
/* 268:314 */       mrdatabean.setValue("NEWREADING", null);
/* 269:    */     }
/* 270:    */     else
/* 271:    */     {
/* 272:321 */       mrdatabean.setValue("NEWREADING", databean.getValue("NEWREADING"));
/* 273:    */     }
/* 274:324 */     mrdatabean.getMobileMbo().setDateValue("NEWREADINGDATE", databean.getMobileMbo().getDateValue("NEWREADINGDATE"));
/* 275:    */     
/* 276:326 */     mrdatabean.setValue("ISDELTA", databean.getValue("ISDELTA"), false);
/* 277:327 */     mrdatabean.setValue("DOROLLOVER", databean.getValue("DOROLLOVER"));
/* 278:328 */     mrdatabean.setValue("INSPECTOR", databean.getValue("INSPECTOR"));
/* 279:329 */     mrdatabean.setValue("REMARKS", databean.getValue("REMARKS"));
/* 280:330 */     mrdatabean.setValue("METER_DESCRIPTION", databean.getValue("METER_DESCRIPTION"));
/* 281:331 */     mrdatabean.setValue("METER_METERTYPE", databean.getValue("METER_METERTYPE"));
/* 282:332 */     mrdatabean.setValue("MEASUREUNITID", databean.getValue("MEASUREUNITID"));
/* 283:333 */     mrdatabean.setValue("ROLLOVER", databean.getValue("ROLLOVER"));
/* 284:334 */     mrdatabean.setValue("AVERAGE", databean.getValue("AVERAGE"));
/* 285:335 */     mrdatabean.setValue("LIFETODATE", databean.getValue("LIFETODATE"));
/* 286:336 */     mrdatabean.setValue("METER_DOMAINID", databean.getValue("METER_DOMAINID"));
/* 287:337 */     mrdatabean.setValue("METER_READINGTYPE", databean.getValue("METER_READINGTYPE"));
/* 288:    */     
/* 289:    */ 
/* 290:340 */     mrdatabean.setValue("LASTREADING", databean.getValue("LASTREADING"));
/* 291:341 */     mrdatabean.getMobileMbo().setDateValue("LASTREADINGDATE", databean.getMobileMbo().getDateValue("LASTREADINGDATE"));
/* 292:342 */     mrdatabean.setValue("LASTREADINGINSPCTR", databean.getValue("LASTREADINGINSPCTR"));
/* 293:346 */     if (databean.getValue("ISDELTA").equals("1"))
/* 294:    */     {
/* 295:348 */       String SnewReading = databean.getValue("NEWREADING");
/* 296:    */       
/* 297:    */ 
/* 298:    */ 
/* 299:352 */       double newReading = convertFormattedValueToDouble(SnewReading);
/* 300:    */       
/* 301:354 */       String SpreviousReading = databean.getValue("LASTREADING");
/* 302:355 */       double previousReading = DefaultMobileMboDataFormatter.stringToDouble(SpreviousReading);
/* 303:356 */       String SrolloverValue = databean.getValue("ROLLOVER");
/* 304:357 */       double rolloverValue = DefaultMobileMboDataFormatter.stringToDouble(SrolloverValue);
/* 305:    */       
/* 306:359 */       newReading = previousReading + newReading;
/* 307:361 */       if (databean.getValue("DOROLLOVER").equals("1")) {
/* 308:363 */         newReading -= rolloverValue;
/* 309:    */       }
/* 310:371 */       databean.setValue("LASTREADING", convertDoubleToFormattedValue(newReading), false);
/* 311:    */     }
/* 312:    */     else
/* 313:    */     {
/* 314:382 */       String metertype = ((WOApp)UIUtil.getApplication()).getInternalValue(databean, "METERTYPE", databean.getValue("METER_METERTYPE"));
/* 315:383 */       if (!metertype.equals("CHARACTERISTIC")) {
/* 316:386 */         databean.setValue("LASTREADING", convertDoubleToFormattedValue(convertFormattedValueToDouble(databean.getValue("NEWREADING"))), false);
/* 317:    */       } else {
/* 318:390 */         databean.setValue("LASTREADING", databean.getValue("NEWREADING"), false);
/* 319:    */       }
/* 320:    */     }
/* 321:398 */     databean.getMobileMbo().setDateValue("LASTREADINGDATE", databean.getMobileMbo().getDateValue("NEWREADINGDATE"), false);
/* 322:399 */     databean.setValue("LASTREADINGINSPCTR", databean.getValue("INSPECTOR"), false);
/* 323:    */     
/* 324:401 */     return true;
/* 325:    */   }
/* 326:    */   
/* 327:    */   public boolean validateReading(UIEvent event)
/* 328:    */     throws MobileApplicationException
/* 329:    */   {
/* 330:406 */     if ((event.getValue() == null) || (((String)event.getValue()).equals(""))) {
/* 331:407 */       return true;
/* 332:    */     }
/* 333:409 */     return checkReading((String)event.getValue(), false);
/* 334:    */   }
/* 335:    */   
/* 336:    */   public boolean checkReading(String SnewReading, boolean pagevalidation)
/* 337:    */     throws MobileApplicationException
/* 338:    */   {
/* 339:414 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/* 340:    */     
/* 341:416 */     String metertype = ((WOApp)UIUtil.getApplication()).getInternalValue(databean, "METERTYPE", databean.getValue("METER_METERTYPE"));
/* 342:417 */     if (!metertype.equals("CHARACTERISTIC"))
/* 343:    */     {
/* 344:427 */       String SrolloverValue = databean.getValue("ROLLOVER");
/* 345:428 */       double rolloverValue = DefaultMobileMboDataFormatter.stringToDouble(SrolloverValue);
/* 346:    */       
/* 347:430 */       String SpreviousReading = databean.getValue("LASTREADING");
/* 348:431 */       double previousReading = DefaultMobileMboDataFormatter.stringToDouble(SpreviousReading);
/* 349:    */       
/* 350:433 */       Date previousReadingDate = databean.getMobileMbo().getDateValue("LASTREADINGDATE");
/* 351:    */       
/* 352:    */ 
/* 353:    */ 
/* 354:    */ 
/* 355:438 */       String convertedReading = SnewReading;
/* 356:439 */       double newReading = -1.0D;
/* 357:440 */       if (!pagevalidation)
/* 358:    */       {
/* 359:443 */         convertedReading = convertReading(SnewReading);
/* 360:444 */         databean.setValue("NEWREADING", convertedReading);
/* 361:445 */         newReading = DefaultMobileMboDataFormatter.stringToDouble(SnewReading);
/* 362:    */       }
/* 363:    */       else
/* 364:    */       {
/* 365:451 */         newReading = convertFormattedValueToDouble(convertedReading);
/* 366:    */       }
/* 367:454 */       Date newReadingDate = databean.getMobileMbo().getDateValue("NEWREADINGDATE");
/* 368:455 */       String isdelta = databean.getMobileMbo().getValue("ISDELTA");
/* 369:456 */       String dorollover = databean.getMobileMbo().getValue("DOROLLOVER");
/* 370:458 */       if (metertype.equals("CONTINUOUS"))
/* 371:    */       {
/* 372:460 */         if (newReading < 0.0D) {
/* 373:462 */           throw new MobileApplicationException("bePositive");
/* 374:    */         }
/* 375:465 */         if ((rolloverValue > 0.0D) && (newReading > rolloverValue))
/* 376:    */         {
/* 377:467 */           Object[] msgParams2 = { "" + newReading, "" + rolloverValue };
/* 378:468 */           throw new MobileApplicationException("cantExceedRollover", msgParams2);
/* 379:    */         }
/* 380:471 */         if (pagevalidation) {
/* 381:473 */           if (((isdelta.equals("")) || (isdelta.equals("0"))) && (newReading < previousReading) && (newReadingDate != null) && (previousReadingDate != null) && (newReadingDate.after(previousReadingDate))) {
/* 382:478 */             if ((rolloverValue > 0.0D) && ((dorollover.equals("")) || (dorollover.equals("0"))))
/* 383:    */             {
/* 384:480 */               Object[] errLowRead = new Object[5];
/* 385:481 */               String newReadingStr = SnewReading;
/* 386:482 */               errLowRead[0] = newReadingStr;
/* 387:483 */               errLowRead[1] = newReadingDate;
/* 388:484 */               errLowRead[2] = ("" + previousReading);
/* 389:485 */               errLowRead[3] = previousReadingDate;
/* 390:486 */               errLowRead[4] = databean.getValue("METERNAME");
/* 391:487 */               throw new MobileApplicationException("lowReading", errLowRead);
/* 392:    */             }
/* 393:    */           }
/* 394:    */         }
/* 395:    */       }
/* 396:    */     }
/* 397:494 */     return false;
/* 398:    */   }
/* 399:    */   
/* 400:    */   private String convertReading(String value)
/* 401:    */     throws MobileApplicationException
/* 402:    */   {
/* 403:501 */     double dValue = DefaultMobileMboDataFormatter.stringToDouble(value);
/* 404:    */     
/* 405:503 */     NumberFormat fmt = NumberFormat.getInstance(Locale.getDefault());
/* 406:504 */     DecimalFormat df = (DecimalFormat)fmt;
/* 407:    */     
/* 408:506 */     return df.format(dValue);
/* 409:    */   }
/* 410:    */   
/* 411:    */   private String convertDoubleToFormattedValue(double number)
/* 412:    */     throws MobileApplicationException
/* 413:    */   {
/* 414:515 */     String s = String.valueOf(number);
/* 415:516 */     if (s != null) {
/* 416:518 */       return DefaultMobileMboDataFormatter.doubleToString(number, 4, Locale.getDefault());
/* 417:    */     }
/* 418:521 */     return s;
/* 419:    */   }
/* 420:    */   
/* 421:    */   private double convertFormattedValueToDouble(String value)
/* 422:    */     throws MobileApplicationException
/* 423:    */   {
/* 424:529 */     if ((value == null) || (value.length() == 0)) {
/* 425:531 */       return 0.0D;
/* 426:    */     }
/* 427:    */     try
/* 428:    */     {
/* 429:536 */       Double.parseDouble(value);
/* 430:    */     }
/* 431:    */     catch (NumberFormatException e)
/* 432:    */     {
/* 433:542 */       return DefaultMobileMboDataFormatter.stringToDouble(value);
/* 434:    */     }
/* 435:545 */     double newReading = 0.0D;
/* 436:    */     try
/* 437:    */     {
/* 438:548 */       newReading = NumberFormat.getInstance(Locale.getDefault()).parse(value).doubleValue();
/* 439:    */     }
/* 440:    */     catch (ParseException e)
/* 441:    */     {
/* 442:551 */       throw new MobileApplicationException("invalidnumber", e);
/* 443:    */     }
/* 444:554 */     return newReading;
/* 445:    */   }
/* 446:    */   
/* 447:    */   public boolean validateReadingDate(UIEvent event)
/* 448:    */     throws MobileApplicationException
/* 449:    */   {
/* 450:560 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/* 451:563 */     if ((event.getValue() instanceof Date))
/* 452:    */     {
/* 453:565 */       if (((Date)event.getValue()).after(((WOApp)UIUtil.getApplication()).getCurrentTime())) {
/* 454:566 */         throw new MobileApplicationException("futuredatenotallowed");
/* 455:    */       }
/* 456:568 */       Date previousReadingDate = databean.getMobileMbo().getDateValue("LASTREADINGDATE");
/* 457:569 */       if ((previousReadingDate != null) && (((Date)event.getValue()).before(previousReadingDate))) {
/* 458:570 */         throw new MobileApplicationException("earlierdatenotallowed");
/* 459:    */       }
/* 460:    */     }
/* 461:573 */     return false;
/* 462:    */   }
/* 463:    */   
/* 464:    */   public boolean initMeterReadings(UIEvent event)
/* 465:    */     throws MobileApplicationException
/* 466:    */   {
/* 467:579 */     MobileMboDataBean databean = ((TableControl)event.getCreatingObject()).getDataBean();
/* 468:    */     
/* 469:581 */     databean.getOrder().setOrder("METERNAME", true);
/* 470:582 */     databean.getOrder().setOrder("NEWREADINGDATE", false);
/* 471:583 */     databean.reset();
/* 472:    */     
/* 473:585 */     return false;
/* 474:    */   }
/* 475:    */   
/* 476:    */   public boolean deletemeterreading(UIEvent event)
/* 477:    */     throws MobileApplicationException
/* 478:    */   {
/* 479:590 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/* 480:591 */     if ((databean != null) && ((databean.getName().equals("ASSETMETERREADINGS")) || (databean.getName().equals("LOCMETERREADINGS"))))
/* 481:    */     {
/* 482:599 */       boolean displayConfirmationBox = true;
/* 483:600 */       String meterBeanName = "WOASSETMETER";
/* 484:601 */       if (databean.getName().equals("LOCMETERREADINGS")) {
/* 485:603 */         meterBeanName = "WOLOCATIONMETER";
/* 486:    */       }
/* 487:607 */       MobileMboDataBean woAssetMeterBean = databean.getParentBean().getDataBean(meterBeanName);
/* 488:608 */       String assetNum = databean.getValue("ASSETNUM");
/* 489:609 */       String meterName = databean.getValue("METERNAME");
/* 490:610 */       String siteId = databean.getValue("SITEID");
/* 491:    */       
/* 492:612 */       woAssetMeterBean.getQBE().setQBE("ASSETNUM", assetNum);
/* 493:613 */       woAssetMeterBean.getQBE().setQBE("METERNAME", meterName);
/* 494:614 */       woAssetMeterBean.getQBE().setQBE("SITEID", siteId);
/* 495:615 */       woAssetMeterBean.reset();
/* 496:    */       
/* 497:    */ 
/* 498:618 */       Date readingDate = databean.getMobileMbo().getDateValue("NEWREADINGDATE");
/* 499:619 */       if (readingDate.equals(woAssetMeterBean.getMobileMbo().getDateValue("LASTREADINGDATE"))) {
/* 500:621 */         displayConfirmationBox = false;
/* 501:    */       }
/* 502:624 */       if ((displayConfirmationBox) && (event.getMsgResponse().equals("-1")))
/* 503:    */       {
/* 504:626 */         UIUtil.showOKCANCELMessageBox(event, MobileMessageGenerator.generate("deletemeter", null));
/* 505:627 */         return true;
/* 506:    */       }
/* 507:629 */       if ((!displayConfirmationBox) || (event.getMsgResponse().equals("1")))
/* 508:    */       {
/* 509:633 */         MobileMboOrder order = new MobileMboOrder();
/* 510:634 */         order.setOrder("NEWREADINGDATE", false);
/* 511:    */         
/* 512:636 */         databean.getQBE().setQBE("ASSETNUM", assetNum);
/* 513:637 */         databean.getQBE().setQBE("METERNAME", meterName);
/* 514:638 */         databean.getQBE().setQBE("SITEID", siteId);
/* 515:639 */         databean.setOrder(order);
/* 516:640 */         databean.reset();
/* 517:    */         
/* 518:642 */         deleteReadings(databean, woAssetMeterBean, readingDate);
/* 519:643 */         UIUtil.closePage();
/* 520:    */       }
/* 521:648 */       woAssetMeterBean.getQBE().reset();
/* 522:649 */       woAssetMeterBean.reset();
/* 523:    */     }
/* 524:652 */     return true;
/* 525:    */   }
/* 526:    */   
/* 527:    */   private void deleteReadings(MobileMboDataBean databean, MobileMboDataBean woAssetMeterBean, Date readingDate)
/* 528:    */     throws MobileApplicationException
/* 529:    */   {
/* 530:665 */     int i = 0;
/* 531:666 */     MobileMbo mbo = databean.getMobileMbo(i);
/* 532:667 */     boolean hasPreviousReading = false;
/* 533:668 */     while (mbo != null)
/* 534:    */     {
/* 535:670 */       if ((mbo.getDateValue("NEWREADINGDATE").equals(readingDate)) || (mbo.getDateValue("NEWREADINGDATE").after(readingDate)))
/* 536:    */       {
/* 537:672 */         databean.delete(i);
/* 538:    */       }
/* 539:    */       else
/* 540:    */       {
/* 541:677 */         hasPreviousReading = true;
/* 542:678 */         double lastReading = -1.0D;
/* 543:679 */         if (mbo.getBooleanValue("ISDELTA")) {
/* 544:681 */           lastReading = convertFormattedValueToDouble(mbo.getValue("LASTREADING")) + convertFormattedValueToDouble(mbo.getValue("NEWREADING"));
/* 545:    */         } else {
/* 546:685 */           lastReading = convertFormattedValueToDouble(mbo.getValue("NEWREADING"));
/* 547:    */         }
/* 548:687 */         woAssetMeterBean.setValue("LASTREADING", convertDoubleToFormattedValue(lastReading), false);
/* 549:688 */         woAssetMeterBean.getMobileMbo().setDateValue("LASTREADINGDATE", mbo.getDateValue("NEWREADINGDATE"), false);
/* 550:689 */         woAssetMeterBean.setValue("LASTREADINGINSPCTR", mbo.getValue("INSPECTOR"), false);
/* 551:690 */         woAssetMeterBean.getDataBeanManager().save();
/* 552:691 */         break;
/* 553:    */       }
/* 554:694 */       mbo = databean.getMobileMbo(++i);
/* 555:    */     }
/* 556:698 */     if (!hasPreviousReading)
/* 557:    */     {
/* 558:700 */       woAssetMeterBean.getMobileMbo().restoreOriginal();
/* 559:701 */       woAssetMeterBean.getDataBeanManager().save();
/* 560:    */     }
/* 561:704 */     databean.getDataBeanManager().save();
/* 562:    */     
/* 563:706 */     databean.getQBE().reset();
/* 564:707 */     databean.reset();
/* 565:    */   }
/* 566:    */   
/* 567:    */   public boolean filterbydomainid(UIEvent event)
/* 568:    */     throws MobileApplicationException
/* 569:    */   {
/* 570:713 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/* 571:714 */     if (databean != null)
/* 572:    */     {
/* 573:716 */       MobileMboDataBean dropdownbean = (MobileMboDataBean)event.getValue();
/* 574:717 */       if (databean != null)
/* 575:    */       {
/* 576:719 */         dropdownbean.getQBE().setQbeExactMatch(true);
/* 577:720 */         dropdownbean.getQBE().setQBE("DOMAINID", databean.getValue("METER_DOMAINID"));
/* 578:721 */         dropdownbean.reset();
/* 579:    */       }
/* 580:    */     }
/* 581:724 */     return false;
/* 582:    */   }
/* 583:    */   
/* 584:    */   private boolean isNumbericValue(String s)
/* 585:    */   {
/* 586:728 */     boolean isnumberic = true;
/* 587:730 */     if (s.indexOf("/") >= 0) {
/* 588:730 */       return false;
/* 589:    */     }
/* 590:    */     try
/* 591:    */     {
/* 592:732 */       convertFormattedValueToDouble(s);
/* 593:    */     }
/* 594:    */     catch (MobileApplicationException e)
/* 595:    */     {
/* 596:734 */       isnumberic = false;
/* 597:    */     }
/* 598:736 */     return isnumberic;
/* 599:    */   }
/* 600:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.mobilewo.WOMeterReadingEventHandler
 * JD-Core Version:    0.7.0.1
 */