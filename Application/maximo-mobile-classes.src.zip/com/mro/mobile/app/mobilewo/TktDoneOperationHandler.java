/*  1:   */ package com.mro.mobile.app.mobilewo;
/*  2:   */ 
/*  3:   */ import com.mro.mobile.MobileApplicationException;
/*  4:   */ import com.mro.mobile.app.OperationHandler;
/*  5:   */ import com.mro.mobile.ui.MobileMboDataBean;
/*  6:   */ 
/*  7:   */ public class TktDoneOperationHandler
/*  8:   */   extends MobileWOOperationHandler
/*  9:   */   implements OperationHandler
/* 10:   */ {
/* 11:   */   public void handleOperation(String operationName, MobileMboDataBean dataBean, int index)
/* 12:   */     throws MobileApplicationException
/* 13:   */   {
/* 14:26 */     if (!dataBean.getName().equals("TICKET")) {
/* 15:27 */       return;
/* 16:   */     }
/* 17:29 */     if (operationName.equals("save")) {
/* 18:31 */       super.handleOperation(operationName, dataBean, index);
/* 19:   */     }
/* 20:35 */     if ((operationName.equals("done")) || (operationName.equals("undo")))
/* 21:   */     {
/* 22:36 */       cleanUpPendingStatusChange(dataBean.getValue(index, "TICKETID"), dataBean.getValue(index, "SITEID"), "TICKETID");
/* 23:40 */       if (operationName.equals("done")) {
/* 24:42 */         cleanUpTkLabTransRecords(dataBean.getValue(index, "TICKETID"), dataBean.getValue(index, "CLASS"));
/* 25:44 */       } else if (operationName.equals("undo")) {
/* 26:47 */         cleanUpActivityHistory(dataBean.getValue(index, "TICKETID"), dataBean.getValue(index, "CLASS"));
/* 27:   */       }
/* 28:   */     }
/* 29:   */   }
/* 30:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.mobilewo.TktDoneOperationHandler
 * JD-Core Version:    0.7.0.1
 */