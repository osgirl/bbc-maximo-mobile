/*   1:    */ package com.mro.mobile.app.mobilewo;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.app.BasicMobileDeviceUIApplication;
/*   5:    */ import com.mro.mobile.app.OperationHandler;
/*   6:    */ import com.mro.mobile.mbo.MobileMbo;
/*   7:    */ import com.mro.mobile.mbo.MobileMboAttributeInfo;
/*   8:    */ import com.mro.mobile.mbo.MobileMboInfo;
/*   9:    */ import com.mro.mobile.mbo.MobileMboQBE;
/*  10:    */ import com.mro.mobile.persist.QBE;
/*  11:    */ import com.mro.mobile.persist.RDORuntime;
/*  12:    */ import com.mro.mobile.persist.RDOTransactionManager;
/*  13:    */ import com.mro.mobile.ui.DataBeanCache;
/*  14:    */ import com.mro.mobile.ui.MobileMboDataBean;
/*  15:    */ import com.mro.mobile.ui.MobileMboDataBeanManager;
/*  16:    */ import com.mro.mobile.ui.res.UIUtil;
/*  17:    */ import com.mro.mobileapp.WOApp;
/*  18:    */ 
/*  19:    */ public class MobileWOOperationHandler
/*  20:    */   implements OperationHandler
/*  21:    */ {
/*  22: 33 */   private String[] assetLocWOFields = { "DESCRIPTION", "STATUS", "SCHEDSTART", "SUPERVISOR", "FAILURECODE", "FAILURECODE1", "FAILURECODE2", "FAILURECODE3", "REMARKDESC", "REMARKENTERDATE" };
/*  23: 34 */   private String[] assetLocTicketFields = { "DESCRIPTION", "REPORTEDBY", "AFFECTEDPERSON", "STATUS", "OWNER", "OWNERGROUP", "HISTORYFLAG" };
/*  24:    */   
/*  25:    */   public void handleOperation(String operationName, MobileMboDataBean dataBean, int index)
/*  26:    */     throws MobileApplicationException
/*  27:    */   {
/*  28: 39 */     if ((operationName.equals("save")) && ((dataBean.getName().equals("WORKORDER")) || (dataBean.getName().equals("TICKET"))))
/*  29:    */     {
/*  30: 42 */       MobileMboDataBean relrecBean1 = null;
/*  31: 43 */       MobileMboDataBean relrecBean2 = null;
/*  32: 44 */       MobileMboDataBean relrecBean3 = null;
/*  33: 45 */       MobileMboDataBean relrecBean4 = null;
/*  34:    */       
/*  35:    */ 
/*  36:    */ 
/*  37: 49 */       MobileMbo modifiedMobileMbo = dataBean.getMobileMbo(index);
/*  38: 50 */       MobileMboDataBean worklistBean = DataBeanCache.findDataBean("WORKLIST");
/*  39: 51 */       if (worklistBean == null) {
/*  40: 53 */         worklistBean = MobileWOAppEventHandler.getCachedDataBean("WORKLIST");
/*  41:    */       }
/*  42: 55 */       int worklistPos = worklistBean.getCurrentPosition();
/*  43: 57 */       if (modifiedMobileMbo.isToBeDeleted())
/*  44:    */       {
/*  45: 60 */         int pos = ((WOApp)UIUtil.getApplication()).findMboInWorkList(worklistBean, modifiedMobileMbo);
/*  46: 61 */         if (pos > -1) {
/*  47: 63 */           worklistBean.deleteLocal(pos);
/*  48:    */         }
/*  49: 66 */         MobileMboDataBeanManager mgrDBMgr = null;
/*  50: 67 */         MobileMboDataBean relrecBean = null;
/*  51: 68 */         for (int iloop = 1; iloop < 5; iloop++)
/*  52:    */         {
/*  53: 70 */           switch (iloop)
/*  54:    */           {
/*  55:    */           case 1: 
/*  56: 73 */             mgrDBMgr = new MobileMboDataBeanManager("WORELWOS");
/*  57: 74 */             relrecBean1 = mgrDBMgr.getDataBean();
/*  58: 75 */             relrecBean = relrecBean1;
/*  59: 76 */             break;
/*  60:    */           case 2: 
/*  61: 78 */             mgrDBMgr = new MobileMboDataBeanManager("WORELTICKETS");
/*  62: 79 */             relrecBean2 = mgrDBMgr.getDataBean();
/*  63: 80 */             relrecBean = relrecBean2;
/*  64: 81 */             break;
/*  65:    */           case 3: 
/*  66: 83 */             mgrDBMgr = new MobileMboDataBeanManager("TKRELWOS");
/*  67: 84 */             relrecBean3 = mgrDBMgr.getDataBean();
/*  68: 85 */             relrecBean = relrecBean3;
/*  69: 86 */             break;
/*  70:    */           case 4: 
/*  71: 88 */             mgrDBMgr = new MobileMboDataBeanManager("TKRELTICKETS");
/*  72: 89 */             relrecBean4 = mgrDBMgr.getDataBean();
/*  73: 90 */             relrecBean = relrecBean4;
/*  74:    */           }
/*  75: 93 */           relrecBean.getQBE().reset();
/*  76: 94 */           relrecBean.getQBE().setQbeExactMatch(true);
/*  77: 95 */           relrecBean.getQBE().setQBE("RELATEDRECKEYID", modifiedMobileMbo.getValue("_ID"));
/*  78: 96 */           int count = relrecBean.count();
/*  79: 97 */           for (int i = count - 1; i > -1; i--) {
/*  80: 99 */             relrecBean.deleteLocal(i);
/*  81:    */           }
/*  82:    */         }
/*  83:    */       }
/*  84:103 */       else if ((modifiedMobileMbo.isToBeInserted()) && (!modifiedMobileMbo.getValue("_DONE").equals("1")))
/*  85:    */       {
/*  86:105 */         ((WOApp)UIUtil.getApplication()).copyMboToWorkList(worklistBean, dataBean, modifiedMobileMbo);
/*  87:    */       }
/*  88:107 */       else if (modifiedMobileMbo.isToBeUpdated())
/*  89:    */       {
/*  90:109 */         int pos = ((WOApp)UIUtil.getApplication()).findMboInWorkList(worklistBean, modifiedMobileMbo);
/*  91:110 */         if (pos > -1) {
/*  92:112 */           if (modifiedMobileMbo.getValue("_DONE").equalsIgnoreCase("1")) {
/*  93:113 */             worklistBean.deleteLocal(pos);
/*  94:    */           } else {
/*  95:115 */             ((WOApp)UIUtil.getApplication()).updateMboInDataBean(worklistBean, pos, dataBean, modifiedMobileMbo);
/*  96:    */           }
/*  97:    */         }
/*  98:122 */         updateRelatedRecord(modifiedMobileMbo);
/*  99:    */         
/* 100:    */ 
/* 101:    */ 
/* 102:126 */         updateAssetLocationRecords(modifiedMobileMbo);
/* 103:130 */         if (dataBean.getName().equals("WORKORDER"))
/* 104:    */         {
/* 105:132 */           MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager("WOTASKS");
/* 106:133 */           MobileMboDataBean wotaskBean = mgrDBMgr.getDataBean();
/* 107:134 */           wotaskBean.getQBE().setQbeExactMatch(true);
/* 108:135 */           wotaskBean.getQBE().setQBE("WONUM", modifiedMobileMbo.getValue("WONUM"));
/* 109:136 */           wotaskBean.getQBE().setQBE("SITEID", modifiedMobileMbo.getValue("SITEID"));
/* 110:137 */           if (wotaskBean.getMobileMbo(0) != null)
/* 111:    */           {
/* 112:140 */             ((WOApp)UIUtil.getApplication()).updateMboInDataBean(wotaskBean, 0, dataBean, dataBean.getMobileMbo(index));
/* 113:    */             
/* 114:142 */             wotaskBean.getMobileMbo(0).setValue("_MODIFIED", "0");
/* 115:143 */             wotaskBean.getDataBeanManager().save();
/* 116:    */           }
/* 117:146 */           mgrDBMgr = new MobileMboDataBeanManager("WOACTIVITY");
/* 118:147 */           MobileMboDataBean woactBean = mgrDBMgr.getDataBean();
/* 119:148 */           woactBean.getQBE().setQbeExactMatch(true);
/* 120:149 */           woactBean.getQBE().setQBE("WONUM", modifiedMobileMbo.getValue("WONUM"));
/* 121:150 */           woactBean.getQBE().setQBE("SITEID", modifiedMobileMbo.getValue("SITEID"));
/* 122:151 */           if (woactBean.getMobileMbo(0) != null)
/* 123:    */           {
/* 124:154 */             ((WOApp)UIUtil.getApplication()).updateMboInDataBean(woactBean, 0, dataBean, dataBean.getMobileMbo(index));
/* 125:    */             
/* 126:156 */             woactBean.getMobileMbo(0).setValue("_MODIFIED", "0");
/* 127:157 */             woactBean.getDataBeanManager().save();
/* 128:    */           }
/* 129:    */         }
/* 130:    */       }
/* 131:163 */       RDORuntime rdoRuntime = UIUtil.getApplication().getRDORuntime();
/* 132:164 */       RDOTransactionManager txnManager = rdoRuntime.getRDOTransactionManager();
/* 133:    */       try
/* 134:    */       {
/* 135:167 */         txnManager.begin();
/* 136:    */         
/* 137:169 */         worklistBean.getDataBeanManager().save();
/* 138:170 */         if (relrecBean1 != null) {
/* 139:170 */           relrecBean1.getDataBeanManager().save();
/* 140:    */         }
/* 141:171 */         if (relrecBean2 != null) {
/* 142:171 */           relrecBean2.getDataBeanManager().save();
/* 143:    */         }
/* 144:172 */         if (relrecBean3 != null) {
/* 145:172 */           relrecBean3.getDataBeanManager().save();
/* 146:    */         }
/* 147:173 */         if (relrecBean4 != null) {
/* 148:173 */           relrecBean4.getDataBeanManager().save();
/* 149:    */         }
/* 150:174 */         txnManager.commit();
/* 151:    */       }
/* 152:    */       catch (Exception ex)
/* 153:    */       {
/* 154:178 */         ex.printStackTrace();
/* 155:    */         try
/* 156:    */         {
/* 157:182 */           txnManager.rollback();
/* 158:    */         }
/* 159:    */         catch (Exception ex1) {}
/* 160:186 */         throw new MobileApplicationException("savefailed");
/* 161:    */       }
/* 162:189 */       worklistBean.setCurrentPosition(worklistPos);
/* 163:    */     }
/* 164:    */   }
/* 165:    */   
/* 166:    */   private void updateAssetLocationRecords(MobileMbo modifiedMobileMbo)
/* 167:    */     throws MobileApplicationException
/* 168:    */   {
/* 169:196 */     String assetBeanName = "ASSET_WORKORDERS";
/* 170:197 */     String locBeanName = "LOC_WORKORDERS";
/* 171:198 */     String[] keyFields = { "WONUM", "SITEID" };
/* 172:199 */     if (modifiedMobileMbo.getName().equals("TICKET"))
/* 173:    */     {
/* 174:201 */       assetBeanName = "ASSETTICKETS";
/* 175:202 */       locBeanName = "LOCTICKETS";
/* 176:203 */       keyFields[0] = "TICKETID";
/* 177:204 */       keyFields[1] = "CLASS";
/* 178:    */     }
/* 179:207 */     processRecords(modifiedMobileMbo, assetBeanName, keyFields);
/* 180:208 */     processRecords(modifiedMobileMbo, locBeanName, keyFields);
/* 181:    */   }
/* 182:    */   
/* 183:    */   private void processRecords(MobileMbo modifiedMobileMbo, String beanName, String[] keyFields)
/* 184:    */     throws MobileApplicationException
/* 185:    */   {
/* 186:217 */     MobileMboDataBean assetLocRecs = DataBeanCache.getDataBean(beanName, beanName);
/* 187:218 */     MobileMboQBE qbe = assetLocRecs.getQBE();
/* 188:219 */     qbe.setQbeExactMatch(true);
/* 189:220 */     qbe.reset();
/* 190:221 */     for (int i = 0; i < keyFields.length; i++)
/* 191:    */     {
/* 192:223 */       String attributeName = keyFields[i];
/* 193:224 */       qbe.setQBE(attributeName, modifiedMobileMbo.getValue(attributeName));
/* 194:    */     }
/* 195:226 */     assetLocRecs.reset();
/* 196:    */     
/* 197:228 */     MobileMbo mbo = assetLocRecs.getMobileMbo();
/* 198:229 */     if (mbo != null)
/* 199:    */     {
/* 200:231 */       updateRecords(modifiedMobileMbo, mbo);
/* 201:232 */       assetLocRecs.getDataBeanManager().save();
/* 202:    */     }
/* 203:    */   }
/* 204:    */   
/* 205:    */   private void updateRecords(MobileMbo modifiedMobileMbo, MobileMbo assetLocMbo)
/* 206:    */     throws MobileApplicationException
/* 207:    */   {
/* 208:240 */     String[] fieldsToUpdate = this.assetLocWOFields;
/* 209:241 */     if (modifiedMobileMbo.getName().equals("TICKET")) {
/* 210:243 */       fieldsToUpdate = this.assetLocTicketFields;
/* 211:    */     }
/* 212:246 */     for (int i = 0; i < fieldsToUpdate.length; i++) {
/* 213:251 */       assetLocMbo.setValue(fieldsToUpdate[i], modifiedMobileMbo.getValue(fieldsToUpdate[i]), false);
/* 214:    */     }
/* 215:    */   }
/* 216:    */   
/* 217:    */   private boolean recordsMatch(MobileMbo modifiedMobileMbo, MobileMbo targetMbo, String[] keyFields)
/* 218:    */     throws MobileApplicationException
/* 219:    */   {
/* 220:259 */     for (int i = 0; i < keyFields.length; i++) {
/* 221:261 */       if (!modifiedMobileMbo.getValue(keyFields[i]).equals(targetMbo.getValue(keyFields[i]))) {
/* 222:263 */         return false;
/* 223:    */       }
/* 224:    */     }
/* 225:266 */     return true;
/* 226:    */   }
/* 227:    */   
/* 228:    */   private void updateRelatedRecord(MobileMbo modifiedMobileMbo)
/* 229:    */     throws MobileApplicationException
/* 230:    */   {
/* 231:272 */     String fieldClass = "WOCLASS";
/* 232:273 */     String fieldNum = "WONUM";
/* 233:274 */     String currentRecordType = modifiedMobileMbo.getName();
/* 234:275 */     if ("TICKET".equalsIgnoreCase(currentRecordType))
/* 235:    */     {
/* 236:277 */       fieldClass = "CLASS";
/* 237:278 */       fieldNum = "TICKETID";
/* 238:    */     }
/* 239:281 */     String currentClass = modifiedMobileMbo.getValue(fieldClass);
/* 240:282 */     String recNum = modifiedMobileMbo.getValue(fieldNum);
/* 241:    */     
/* 242:284 */     updateWORelWOs(modifiedMobileMbo, currentClass, recNum);
/* 243:285 */     updateWORelTickets(modifiedMobileMbo, currentClass, recNum);
/* 244:286 */     updateTKRelWOs(modifiedMobileMbo, currentClass, recNum);
/* 245:287 */     updateTKRelTickets(modifiedMobileMbo, currentClass, recNum);
/* 246:    */   }
/* 247:    */   
/* 248:    */   private void updateRelRecords(MobileMbo modifiedMobileMbo, String currentClass, String recNum, String relatedRecClassField, String relatedRecNumField, String targetMobileMboName)
/* 249:    */     throws MobileApplicationException
/* 250:    */   {
/* 251:296 */     MobileMboDataBean databean = new MobileMboDataBeanManager(targetMobileMboName).getDataBean();
/* 252:297 */     QBE qbe = databean.getQBE();
/* 253:298 */     qbe.setQbeExactMatch(true);
/* 254:299 */     qbe.setQBE(relatedRecClassField, currentClass);
/* 255:300 */     qbe.setQBE(relatedRecNumField, recNum);
/* 256:301 */     qbe.setQBE("RELATEDRECKEYID", "" + modifiedMobileMbo.getId());
/* 257:302 */     databean.reset();
/* 258:    */     
/* 259:304 */     String[] fieldsToUpdate = { "STATUS", "DESCRIPTION", "DESCRIPTION_LONGDESCRIPTION", "ASSETNUM", "ASSET_DESCRIPTION", "LOCATION", "LOCATION_DESCRIPTION" };
/* 260:    */     
/* 261:    */ 
/* 262:    */ 
/* 263:    */ 
/* 264:    */ 
/* 265:    */ 
/* 266:    */ 
/* 267:    */ 
/* 268:313 */     int count = fieldsToUpdate.length;
/* 269:314 */     MobileMbo mobileMbo = databean.getMobileMbo(0);
/* 270:315 */     int i = 0;
/* 271:316 */     boolean updated = false;
/* 272:317 */     while (mobileMbo != null)
/* 273:    */     {
/* 274:319 */       updated = true;
/* 275:320 */       for (int j = 0; j < count; j++)
/* 276:    */       {
/* 277:322 */         String fieldName = fieldsToUpdate[j];
/* 278:    */         
/* 279:324 */         MobileMboAttributeInfo info = mobileMbo.getMobileMboInfo().getAttributeInfo(fieldName);
/* 280:325 */         info.setChangeTrackingEnabled(false);
/* 281:326 */         mobileMbo.setValue(fieldName, modifiedMobileMbo.getValue(fieldName), false);
/* 282:    */       }
/* 283:329 */       i++;
/* 284:330 */       mobileMbo = databean.getMobileMbo(i);
/* 285:    */     }
/* 286:333 */     if (updated) {
/* 287:335 */       databean.getDataBeanManager().save();
/* 288:    */     }
/* 289:    */   }
/* 290:    */   
/* 291:    */   private void updateWORelWOs(MobileMbo modifiedMobileMbo, String currentClass, String recNum)
/* 292:    */     throws MobileApplicationException
/* 293:    */   {
/* 294:344 */     updateRelRecords(modifiedMobileMbo, currentClass, recNum, "RELATEDRECWOCLASS", "RELATEDRECWONUM", "WORELWOS");
/* 295:    */   }
/* 296:    */   
/* 297:    */   private void updateWORelTickets(MobileMbo modifiedMobileMbo, String currentClass, String recNum)
/* 298:    */     throws MobileApplicationException
/* 299:    */   {
/* 300:352 */     updateRelRecords(modifiedMobileMbo, currentClass, recNum, "RELATEDRECCLASS", "RELATEDRECKEY", "WORELTICKETS");
/* 301:    */   }
/* 302:    */   
/* 303:    */   private void updateTKRelWOs(MobileMbo modifiedMobileMbo, String currentClass, String recNum)
/* 304:    */     throws MobileApplicationException
/* 305:    */   {
/* 306:360 */     updateRelRecords(modifiedMobileMbo, currentClass, recNum, "RELATEDRECWOCLASS", "RELATEDRECWONUM", "TKRELWOS");
/* 307:    */   }
/* 308:    */   
/* 309:    */   private void updateTKRelTickets(MobileMbo modifiedMobileMbo, String currentClass, String recNum)
/* 310:    */     throws MobileApplicationException
/* 311:    */   {
/* 312:368 */     updateRelRecords(modifiedMobileMbo, currentClass, recNum, "RELATEDRECCLASS", "RELATEDRECKEY", "TKRELTICKETS");
/* 313:    */   }
/* 314:    */   
/* 315:    */   protected void cleanUpPendingStatusChange(String objectNumber, String siteid, String fieldName)
/* 316:    */     throws MobileApplicationException
/* 317:    */   {
/* 318:374 */     MobileMboDataBeanManager manager = new MobileMboDataBeanManager("PENDINGCHGSTATUS");
/* 319:375 */     MobileMboDataBean pendingChanges = manager.getDataBean();
/* 320:    */     
/* 321:377 */     pendingChanges.getQBE().setQbeExactMatch(true);
/* 322:378 */     pendingChanges.getQBE().setQBE(fieldName, objectNumber);
/* 323:379 */     pendingChanges.getQBE().setQBE("SITEID", siteid);
/* 324:380 */     pendingChanges.reset();
/* 325:    */     
/* 326:    */ 
/* 327:383 */     pendingChanges.getMobileMbo(pendingChanges.count());
/* 328:385 */     for (int i = 0; i < pendingChanges.count(); i++) {
/* 329:386 */       pendingChanges.deleteLocal(i);
/* 330:    */     }
/* 331:389 */     manager.save();
/* 332:    */   }
/* 333:    */   
/* 334:    */   public boolean beforeOperation(String operationName, MobileMboDataBean dataBean, int index)
/* 335:    */     throws MobileApplicationException
/* 336:    */   {
/* 337:396 */     if (operationName.equalsIgnoreCase("undo")) {
/* 338:398 */       if (("WORELWOS".equalsIgnoreCase(dataBean.getName())) || ("WORELTICKETS".equalsIgnoreCase(dataBean.getName()))) {
/* 339:401 */         return false;
/* 340:    */       }
/* 341:    */     }
/* 342:405 */     return true;
/* 343:    */   }
/* 344:    */   
/* 345:    */   protected void cleanUpWOLabTransRecords(String woId, String siteId)
/* 346:    */     throws MobileApplicationException
/* 347:    */   {
/* 348:411 */     cleanUpLabTransRecords(woId, siteId, "SITEID");
/* 349:    */   }
/* 350:    */   
/* 351:    */   protected void cleanUpTkLabTransRecords(String tkId, String tkClass)
/* 352:    */     throws MobileApplicationException
/* 353:    */   {
/* 354:417 */     cleanUpLabTransRecords(tkId, tkClass, "TICKETCLASS");
/* 355:    */   }
/* 356:    */   
/* 357:    */   private void cleanUpLabTransRecords(String tkWoId, String fieldValue, String fieldName)
/* 358:    */     throws MobileApplicationException
/* 359:    */   {
/* 360:423 */     MobileMboDataBean labTransBean = DataBeanCache.getDataBean("LABTRANS", "LABTRANS");
/* 361:424 */     int count = labTransBean.count();
/* 362:425 */     for (int i = 0; i < count; i++) {
/* 363:427 */       if ((labTransBean.getValue(i, "RECORD").equalsIgnoreCase(tkWoId)) && (labTransBean.getValue(i, fieldName).equalsIgnoreCase(fieldValue))) {
/* 364:430 */         labTransBean.deleteLocal(i);
/* 365:    */       }
/* 366:    */     }
/* 367:433 */     labTransBean.getDataBeanManager().save();
/* 368:    */   }
/* 369:    */   
/* 370:    */   protected void cleanUpTaskHistory(String woNum, String siteId)
/* 371:    */     throws MobileApplicationException
/* 372:    */   {
/* 373:440 */     MobileMboDataBean woBean = DataBeanCache.getDataBean("WORKORDER", "WORKORDER");
/* 374:441 */     int i = 0;
/* 375:442 */     MobileMbo woMbo = woBean.getMobileMbo(i);
/* 376:443 */     while (woMbo != null)
/* 377:    */     {
/* 378:445 */       if ((woMbo.getValue("WONUM").equals(woNum)) && (woMbo.getValue("SITEID").equals(siteId)))
/* 379:    */       {
/* 380:447 */         MobileMboDataBean tasksBean = woBean.getDataBean(i, "WOTASKS");
/* 381:448 */         if ((tasksBean != null) && (tasksBean.count() > 0)) {
/* 382:450 */           processStatuses(tasksBean, "WOTASKSTATUSHIST");
/* 383:    */         }
/* 384:    */       }
/* 385:453 */       woMbo = woBean.getMobileMbo(++i);
/* 386:    */     }
/* 387:    */   }
/* 388:    */   
/* 389:    */   protected void cleanUpActivityHistory(String ticketId, String ticketClass)
/* 390:    */     throws MobileApplicationException
/* 391:    */   {
/* 392:461 */     MobileMboDataBean ticketBean = DataBeanCache.getDataBean("TICKET", "TICKET");
/* 393:462 */     int i = 0;
/* 394:463 */     MobileMbo ticketMbo = ticketBean.getMobileMbo(i);
/* 395:464 */     while (ticketMbo != null)
/* 396:    */     {
/* 397:466 */       if ((ticketMbo.getValue("TICKETID").equals(ticketId)) && (ticketMbo.getValue("CLASS").equals(ticketClass)))
/* 398:    */       {
/* 399:468 */         MobileMboDataBean activityBean = ticketBean.getDataBean(i, "WOACTIVITY");
/* 400:469 */         if ((activityBean != null) && (activityBean.count() > 0)) {
/* 401:471 */           processStatuses(activityBean, "WOACTSTATUSHIST");
/* 402:    */         }
/* 403:    */       }
/* 404:474 */       ticketMbo = ticketBean.getMobileMbo(++i);
/* 405:    */     }
/* 406:    */   }
/* 407:    */   
/* 408:    */   private void processStatuses(MobileMboDataBean taskActBean, String statusBeanName)
/* 409:    */     throws MobileApplicationException
/* 410:    */   {
/* 411:482 */     int count = taskActBean.count();
/* 412:483 */     for (int i = 0; i < count; i++)
/* 413:    */     {
/* 414:485 */       MobileMboDataBean taskActHistBean = taskActBean.getDataBean(i, statusBeanName);
/* 415:486 */       deleteNewStatusesFromHistory(taskActHistBean);
/* 416:    */     }
/* 417:    */   }
/* 418:    */   
/* 419:    */   private void deleteNewStatusesFromHistory(MobileMboDataBean taskActHistBean)
/* 420:    */     throws MobileApplicationException
/* 421:    */   {
/* 422:494 */     if (taskActHistBean != null)
/* 423:    */     {
/* 424:496 */       int i = 0;
/* 425:497 */       MobileMbo histMbo = taskActHistBean.getMobileMbo(i);
/* 426:498 */       while (histMbo != null)
/* 427:    */       {
/* 428:500 */         if (histMbo.isNew()) {
/* 429:502 */           histMbo.delete();
/* 430:    */         }
/* 431:504 */         histMbo = taskActHistBean.getMobileMbo(++i);
/* 432:    */       }
/* 433:    */     }
/* 434:    */   }
/* 435:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.mobilewo.MobileWOOperationHandler
 * JD-Core Version:    0.7.0.1
 */