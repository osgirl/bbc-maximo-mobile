/*     1:      */ package com.mro.mobile.app.mobilewo;
/*     2:      */ 
/*     3:      */ import com.ibm.tivoli.maximo.util.mboadapter.mobile.MobileMboAdapter;
/*     4:      */ import com.ibm.tivoli.maximo.util.mboadapter.mobile.MobileMboSetAdapter;
/*     5:      */ import com.mro.mobile.MobileApplicationException;
/*     6:      */ import com.mro.mobile.MobileMessageGenerator;
/*     7:      */ import com.mro.mobile.ProgressObserver;
/*     8:      */ import com.mro.mobile.app.AbstractMobileDeviceApplication;
/*     9:      */ import com.mro.mobile.app.AppEventHandler;
/*    10:      */ import com.mro.mobile.app.BasicMobileDeviceUIApplication;
/*    11:      */ import com.mro.mobile.app.CurrentTimeProvider;
/*    12:      */ import com.mro.mobile.app.MobileDeviceAppSession;
/*    13:      */ import com.mro.mobile.app.async.AsyncEventHandlerSupport;
/*    14:      */ import com.mro.mobile.app.pluscmobwo.PlusCMobUtil;
/*    15:      */ import com.mro.mobile.app.pluscmobwo.PlusCMobileWODelegate;
/*    16:      */ import com.mro.mobile.app.pluscmobwo.PlusCMobileWODsDelegate;
/*    17:      */ import com.mro.mobile.app.pluscmobwo.PlusCMobileWODsInstrDelegate;
/*    18:      */ import com.mro.mobile.app.pluscmobwo.PlusCMobileWODsPointDelegate;
/*    19:      */ import com.mro.mobile.app.pluscmobwo.PlusCMobileWODsSetDelegate;
/*    20:      */ import com.mro.mobile.app.pluscmobwo.PlusCToolKitTOMobile;
/*    21:      */ import com.mro.mobile.mbo.MobileMbo;
/*    22:      */ import com.mro.mobile.mbo.MobileMboInfo;
/*    23:      */ import com.mro.mobile.mbo.MobileMboOrder;
/*    24:      */ import com.mro.mobile.mbo.MobileMboQBE;
/*    25:      */ import com.mro.mobile.persist.QBEData;
/*    26:      */ import com.mro.mobile.persist.RDO;
/*    27:      */ import com.mro.mobile.persist.RDOException;
/*    28:      */ import com.mro.mobile.ui.AutoKeyGenerator;
/*    29:      */ import com.mro.mobile.ui.DataBeanCache;
/*    30:      */ import com.mro.mobile.ui.DataBeanCacheItem;
/*    31:      */ import com.mro.mobile.ui.MobileMboDataBean;
/*    32:      */ import com.mro.mobile.ui.MobileMboDataBeanManager;
/*    33:      */ import com.mro.mobile.ui.UIHandlerManager;
/*    34:      */ import com.mro.mobile.ui.event.UIEvent;
/*    35:      */ import com.mro.mobile.ui.event.UIEventHandler;
/*    36:      */ import com.mro.mobile.ui.res.ControlData;
/*    37:      */ import com.mro.mobile.ui.res.UIUtil;
/*    38:      */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*    39:      */ import com.mro.mobile.ui.res.controls.ButtonControl;
/*    40:      */ import com.mro.mobile.ui.res.controls.CheckboxControl;
/*    41:      */ import com.mro.mobile.ui.res.controls.InputControl;
/*    42:      */ import com.mro.mobile.ui.res.controls.LabelControl;
/*    43:      */ import com.mro.mobile.ui.res.controls.PageControl;
/*    44:      */ import com.mro.mobile.ui.res.controls.StateControl;
/*    45:      */ import com.mro.mobile.ui.res.controls.TabControl;
/*    46:      */ import com.mro.mobile.ui.res.controls.TabGroupControl;
/*    47:      */ import com.mro.mobile.ui.res.controls.TableControl;
/*    48:      */ import com.mro.mobile.ui.res.controls.TextboxControl;
/*    49:      */ import com.mro.mobile.ui.res.controls.utils.ControlStyle;
/*    50:      */ import com.mro.mobile.ui.res.controls.utils.StyleManager;
/*    51:      */ import com.mro.mobile.ui.res.controls.utils.TreeNodeData;
/*    52:      */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*    53:      */ import com.mro.mobile.util.MobileLogger;
/*    54:      */ import com.mro.mobile.util.MobileLoggerFactory;
/*    55:      */ import com.mro.mobileapp.WOApp;
/*    56:      */ import java.io.PrintStream;
/*    57:      */ import java.net.ConnectException;
/*    58:      */ import java.util.ArrayList;
/*    59:      */ import java.util.Arrays;
/*    60:      */ import java.util.Date;
/*    61:      */ import java.util.Enumeration;
/*    62:      */ import java.util.HashMap;
/*    63:      */ import java.util.HashSet;
/*    64:      */ import java.util.Hashtable;
/*    65:      */ import java.util.Iterator;
/*    66:      */ import java.util.List;
/*    67:      */ import java.util.Locale;
/*    68:      */ import java.util.Map;
/*    69:      */ import java.util.Set;
/*    70:      */ import java.util.StringTokenizer;
/*    71:      */ import java.util.Vector;
/*    72:      */ import psdi.plusc.app.pluscds.pluscmobilecommon.PlusCDSCalculation;
/*    73:      */ import psdi.plusc.app.pluscds.pluscmobilecommon.PlusCMboRemote;
/*    74:      */ import psdi.plusc.app.pluscds.pluscmobilecommon.PlusCToolKitTOCommon;
/*    75:      */ import psdi.plusc.app.pluscds.pluscmobilecommon.PlusCWODSInstrTO;
/*    76:      */ import psdi.plusc.app.pluscds.pluscmobilecommon.PlusCWODSPointTO;
/*    77:      */ import psdi.plusc.app.pluscds.pluscmobilecommon.PlusCWODSTO;
/*    78:      */ import psdi.plusc.app.pluscds.pluscmobilecommon.PlusCWODsDelegate;
/*    79:      */ import psdi.plusc.app.pluscds.pluscmobilecommon.PlusCWODsInstrDelegate;
/*    80:      */ import psdi.plusc.app.pluscds.pluscmobilecommon.PlusCWODsPointDelegate;
/*    81:      */ import psdi.plusc.app.pluscds.pluscmobilecommon.PlusCWODsSetDelegate;
/*    82:      */ import psdi.plusc.app.pluscwo.pluscmobilecommon.PlusCWODelegate;
/*    83:      */ 
/*    84:      */ public class MobileWOAppEventHandler
/*    85:      */   extends AppEventHandler
/*    86:      */ {
/*    87:      */   private static final String CALPOINT = "CALPOINT";
/*    88:      */   private static final String CALFUNCTION = "CALFUNCTION";
/*    89:      */   private static final String CALDYNAMIC = "CALDYNAMIC";
/*    90:      */   private int currentAFIndex;
/*    91:      */   private int currentCPIndex;
/*    92:      */   private int currentWODSIndex;
/*    93:  123 */   Set failDSStatusSet = null;
/*    94:  124 */   Set failSynonymDSStatusSet = null;
/*    95:  126 */   Set passDSStatusSet = null;
/*    96:  128 */   private static String[] DS_UNCERTAINTY_FIELDS = { "SYSTEMID", "KFACTOR", "CONFIDLEVEL", "GBMETHOD", "GUARDBAND", "UNCERTFREQ", "UNCERTUNITS" };
/*    97:  138 */   private static String[] INSTR_UNCERTAINTY_FIELDS = { "SYSTEMID", "KFACTOR", "CONFIDLEVEL", "TUR", "GBMETHOD", "GUARDBAND", "UNCERTFREQ", "UNCERTUNITS", "COMSTDUNCERT", "CALIBFUNCTION", "CALIBFUNCTIONTIME" };
/*    98:  152 */   private static String[] POINT_UNCERTAINTY_FIELDS = { "INPUTUNCERT", "INPUTUNCERTEU", "UNCERTVALUE", "UNCERTVALUEEU", "EXPECTDRIFT", "EXPECTDRIFTEU", "TUR" };
/*    99:      */   private static final String KEY_SEPARATOR = "::";
/*   100:      */   public static final String CREATEWOMULTI_NONE = "NONE";
/*   101:      */   public static final String CREATEWOMULTI_CHILD = "CHILD";
/*   102:      */   public static final String CREATEWOMULTI_TASK = "TASK";
/*   103:      */   public static final String CREATEWOMULTI_MULTI = "MULTI";
/*   104:      */   public static final String CREATEWOMULTI_TOPLEVEL = "TOPLEVEL";
/*   105:  179 */   private Map worklistTreeCache = new HashMap();
/*   106:      */   
/*   107:      */   public boolean performEvent(UIEvent event)
/*   108:      */     throws MobileApplicationException
/*   109:      */   {
/*   110:  185 */     if (event == null) {
/*   111:  186 */       return super.performEvent(event);
/*   112:      */     }
/*   113:  188 */     String eventId = event.getEventName();
/*   114:  191 */     if ((eventId.equalsIgnoreCase("insertwo")) || (eventId.equalsIgnoreCase("insertsr")) || (eventId.equalsIgnoreCase("insertincident")) || (eventId.equalsIgnoreCase("insertproblem")) || (eventId.equalsIgnoreCase("insertchange")) || (eventId.equalsIgnoreCase("insertrelease")))
/*   115:      */     {
/*   116:  198 */       if (!isDataRefreshed()) {
/*   117:  201 */         return true;
/*   118:      */       }
/*   119:  205 */       AbstractMobileDeviceApplication app = UIUtil.getApplication();
/*   120:  206 */       String defaultSite = app.getDefaultInsertSite();
/*   121:  207 */       if ((defaultSite == null) || ("".equals(defaultSite))) {
/*   122:  208 */         throw new MobileApplicationException("nodefaultsite");
/*   123:      */       }
/*   124:      */     }
/*   125:  212 */     if (eventId.equalsIgnoreCase("insertwo")) {
/*   126:  214 */       return insertwo(event);
/*   127:      */     }
/*   128:  216 */     if (eventId.equalsIgnoreCase("insertchange")) {
/*   129:  218 */       return insertchange(event);
/*   130:      */     }
/*   131:  220 */     if (eventId.equalsIgnoreCase("insertrelease")) {
/*   132:  222 */       return insertrelease(event);
/*   133:      */     }
/*   134:  224 */     if (eventId.equalsIgnoreCase("insertsr")) {
/*   135:  226 */       return insertsr(event);
/*   136:      */     }
/*   137:  228 */     if (eventId.equalsIgnoreCase("insertincident")) {
/*   138:  230 */       return insertincident(event);
/*   139:      */     }
/*   140:  232 */     if (eventId.equalsIgnoreCase("insertproblem")) {
/*   141:  234 */       return insertproblem(event);
/*   142:      */     }
/*   143:  236 */     if (eventId.equalsIgnoreCase("caninserttask")) {
/*   144:  238 */       return caninserttask(event);
/*   145:      */     }
/*   146:  240 */     if (eventId.equalsIgnoreCase("inserttask")) {
/*   147:  242 */       return inserttask(event);
/*   148:      */     }
/*   149:  244 */     if (eventId.equalsIgnoreCase("caninsertactivity")) {
/*   150:  246 */       return caninsertactivity(event);
/*   151:      */     }
/*   152:  248 */     if (eventId.equalsIgnoreCase("insertactivity")) {
/*   153:  250 */       return insertactivity(event);
/*   154:      */     }
/*   155:  252 */     if (eventId.equalsIgnoreCase("candeleteactivity")) {
/*   156:  254 */       return candeleteactivity(event);
/*   157:      */     }
/*   158:  256 */     if (eventId.equalsIgnoreCase("deleteactivity")) {
/*   159:  258 */       return deleteactivity(event);
/*   160:      */     }
/*   161:  260 */     if (eventId.equalsIgnoreCase("createfollowupwo")) {
/*   162:  262 */       return createfollowupwo(event);
/*   163:      */     }
/*   164:  264 */     if (eventId.equalsIgnoreCase("createfollowupchange")) {
/*   165:  266 */       return createfollowupchange(event);
/*   166:      */     }
/*   167:  268 */     if (eventId.equalsIgnoreCase("createfollowuprelease")) {
/*   168:  270 */       return createfollowuprelease(event);
/*   169:      */     }
/*   170:  272 */     if (eventId.equalsIgnoreCase("createfollowupsr")) {
/*   171:  274 */       return createfollowupsr(event);
/*   172:      */     }
/*   173:  276 */     if (eventId.equalsIgnoreCase("createfollowupincident")) {
/*   174:  278 */       return createfollowupincident(event);
/*   175:      */     }
/*   176:  280 */     if (eventId.equalsIgnoreCase("createfollowupproblem")) {
/*   177:  282 */       return createfollowupproblem(event);
/*   178:      */     }
/*   179:  284 */     if (eventId.equalsIgnoreCase("capturesignature")) {
/*   180:  286 */       return capturesignature(event);
/*   181:      */     }
/*   182:  288 */     if (eventId.equalsIgnoreCase("attachdoc")) {
/*   183:  290 */       return attachdoc(event);
/*   184:      */     }
/*   185:  292 */     if (eventId.equalsIgnoreCase("filterppcodevalues")) {
/*   186:  294 */       return filterppcodevalues(event);
/*   187:      */     }
/*   188:  296 */     if (eventId.equalsIgnoreCase("filterstatusvalues")) {
/*   189:  298 */       return filterstatusvalues(event);
/*   190:      */     }
/*   191:  300 */     if (eventId.equalsIgnoreCase("filtertaskstatusvalues")) {
/*   192:  302 */       return filterstatusvalues(event);
/*   193:      */     }
/*   194:  304 */     if (eventId.equalsIgnoreCase("filtertkstatusvalues")) {
/*   195:  306 */       return filtertkstatusvalues(event);
/*   196:      */     }
/*   197:  308 */     if (eventId.equalsIgnoreCase("submitSR")) {
/*   198:  310 */       return submitSR(event);
/*   199:      */     }
/*   200:  312 */     if (eventId.equalsIgnoreCase("starttimer")) {
/*   201:  314 */       return starttimer(event);
/*   202:      */     }
/*   203:  316 */     if (eventId.equalsIgnoreCase("stoptimer")) {
/*   204:  318 */       return stoptimer(event);
/*   205:      */     }
/*   206:  320 */     if (eventId.equalsIgnoreCase("toggletimerbuttonstate")) {
/*   207:  322 */       return toggletimerbuttonstate(event);
/*   208:      */     }
/*   209:  324 */     if (eventId.equalsIgnoreCase("refreshwos")) {
/*   210:  326 */       return refreshwos(event);
/*   211:      */     }
/*   212:  328 */     if (eventId.equalsIgnoreCase("setworkliststyle")) {
/*   213:  330 */       return setworkliststyle(event);
/*   214:      */     }
/*   215:  332 */     if (eventId.equalsIgnoreCase("setassetliststyle")) {
/*   216:  334 */       return setassetliststyle(event);
/*   217:      */     }
/*   218:  336 */     if (eventId.equalsIgnoreCase("displayslaicon")) {
/*   219:  338 */       return displayslaicon(event);
/*   220:      */     }
/*   221:  340 */     if (eventId.equalsIgnoreCase("refreshplannedlabortable")) {
/*   222:  342 */       return refreshplannedlabortable(event);
/*   223:      */     }
/*   224:  344 */     if (eventId.equalsIgnoreCase("refreshplannedmattable")) {
/*   225:  346 */       return refreshplannedmattable(event);
/*   226:      */     }
/*   227:  348 */     if (eventId.equalsIgnoreCase("refreshactualmattable")) {
/*   228:  350 */       return refreshactualmattable(event);
/*   229:      */     }
/*   230:  352 */     if (eventId.equalsIgnoreCase("cancreatesr")) {
/*   231:  354 */       return cancreatesr(event);
/*   232:      */     }
/*   233:  356 */     if (eventId.equalsIgnoreCase("cancreatefollowup")) {
/*   234:  358 */       return cancreatefollowup(event);
/*   235:      */     }
/*   236:  360 */     if (eventId.equalsIgnoreCase("displaySRTab")) {
/*   237:  362 */       return displaySRTab(event);
/*   238:      */     }
/*   239:  364 */     if (eventId.equals("buildwoparenttree"))
/*   240:      */     {
/*   241:  366 */       event.setValue(scan4Parents(event));
/*   242:  367 */       return true;
/*   243:      */     }
/*   244:  369 */     if (eventId.equals("buildwobranchtree"))
/*   245:      */     {
/*   246:  371 */       event.setValue(scan4Children(event));
/*   247:  372 */       return true;
/*   248:      */     }
/*   249:  374 */     if (eventId.equals("scansettreewodata"))
/*   250:      */     {
/*   251:  376 */       scansettreewodata(event);
/*   252:  377 */       return true;
/*   253:      */     }
/*   254:  379 */     if (eventId.equalsIgnoreCase("canenteractuals")) {
/*   255:  381 */       return canenteractuals(event);
/*   256:      */     }
/*   257:  383 */     if (eventId.equalsIgnoreCase("canChangeFailureCode")) {
/*   258:  385 */       return canChangeFailureCode(event);
/*   259:      */     }
/*   260:  387 */     if (eventId.equalsIgnoreCase("canChangeFailureCodeLink")) {
/*   261:  389 */       return canChangeFailureCodeLink(event);
/*   262:      */     }
/*   263:  391 */     if (eventId.equalsIgnoreCase("initassetwofailurereport")) {
/*   264:  393 */       return initassetwofailurereport(event);
/*   265:      */     }
/*   266:  395 */     if (eventId.equalsIgnoreCase("initlocwofailurereport")) {
/*   267:  397 */       return initlocwofailurereport(event);
/*   268:      */     }
/*   269:  399 */     if (eventId.equalsIgnoreCase("candeleteactual")) {
/*   270:  401 */       return candeleteactual(event);
/*   271:      */     }
/*   272:  403 */     if (eventId.equalsIgnoreCase("deleteactual")) {
/*   273:  405 */       return deleteactual(event);
/*   274:      */     }
/*   275:  408 */     if (eventId.equalsIgnoreCase("selectclassesvalues")) {
/*   276:  409 */       return selectclassesvalues(event);
/*   277:      */     }
/*   278:  412 */     if (eventId.equalsIgnoreCase("selectstatusvalues")) {
/*   279:  414 */       return selectstatusvalues(event);
/*   280:      */     }
/*   281:  416 */     if (eventId.equalsIgnoreCase("selectworktypevalues")) {
/*   282:  418 */       return selectworktypevalues(event);
/*   283:      */     }
/*   284:  420 */     if (eventId.equalsIgnoreCase("selectassetvalues")) {
/*   285:  422 */       return selectassetvalues(event);
/*   286:      */     }
/*   287:  424 */     if (eventId.equalsIgnoreCase("selectlocationvalues")) {
/*   288:  426 */       return selectlocationvalues(event);
/*   289:      */     }
/*   290:  428 */     if (eventId.equalsIgnoreCase("selectfcvalues")) {
/*   291:  430 */       return selectfcvalues(event);
/*   292:      */     }
/*   293:  432 */     if (eventId.equalsIgnoreCase("selectlaborvalues")) {
/*   294:  434 */       return selectlaborvalues(event);
/*   295:      */     }
/*   296:  436 */     if (eventId.equalsIgnoreCase("canattachdocs")) {
/*   297:  438 */       return canattachdocs(event);
/*   298:      */     }
/*   299:  440 */     if (eventId.equalsIgnoreCase("initLocOpOnlyLookup")) {
/*   300:  442 */       return initLocOpOnlyLookup(event);
/*   301:      */     }
/*   302:  444 */     if (eventId.equalsIgnoreCase("caninsertlog")) {
/*   303:  446 */       return caninsertlog(event);
/*   304:      */     }
/*   305:  448 */     if (eventId.equalsIgnoreCase("insertlog")) {
/*   306:  450 */       return insertlog(event);
/*   307:      */     }
/*   308:  452 */     if (eventId.equalsIgnoreCase("candeletelog")) {
/*   309:  454 */       return candeletelog(event);
/*   310:      */     }
/*   311:  456 */     if (eventId.equalsIgnoreCase("deletelog")) {
/*   312:  458 */       return deletelog(event);
/*   313:      */     }
/*   314:  460 */     if (eventId.equalsIgnoreCase("iswobased")) {
/*   315:  462 */       return iswobased(event);
/*   316:      */     }
/*   317:  464 */     if (eventId.equalsIgnoreCase("cancreatecommunication")) {
/*   318:  466 */       return cancreatecommunication(event);
/*   319:      */     }
/*   320:  468 */     if (eventId.equalsIgnoreCase("submitCommunication")) {
/*   321:  470 */       return submitCommunication(event);
/*   322:      */     }
/*   323:  472 */     if (eventId.equalsIgnoreCase("cancreatetkcommunication")) {
/*   324:  474 */       return cancreatetkcommunication(event);
/*   325:      */     }
/*   326:  476 */     if (eventId.equalsIgnoreCase("displayCOMMTab")) {
/*   327:  478 */       return displayCOMMTab(event);
/*   328:      */     }
/*   329:  480 */     if (eventId.equalsIgnoreCase("initcommlog")) {
/*   330:  482 */       return initcommlog(event);
/*   331:      */     }
/*   332:  484 */     if (eventId.equalsIgnoreCase("displayMRTab")) {
/*   333:  486 */       return displayMRTab(event);
/*   334:      */     }
/*   335:  488 */     if (eventId.equalsIgnoreCase("initmr")) {
/*   336:  490 */       return initmr(event);
/*   337:      */     }
/*   338:  492 */     if (eventId.equalsIgnoreCase("canmovemodify")) {
/*   339:  494 */       return canmovemodify(event);
/*   340:      */     }
/*   341:  496 */     if (eventId.equalsIgnoreCase("woadhocdownloadAssetWO")) {
/*   342:  498 */       return woadhocdownloadAssetWO(event);
/*   343:      */     }
/*   344:  500 */     if (eventId.equalsIgnoreCase("woadhocdownloadAssetTK")) {
/*   345:  502 */       return woadhocdownloadAssetTK(event);
/*   346:      */     }
/*   347:  504 */     if (eventId.equalsIgnoreCase("woadhocdownloadLocWO")) {
/*   348:  506 */       return woadhocdownloadLocWO(event);
/*   349:      */     }
/*   350:  508 */     if (eventId.equalsIgnoreCase("woadhocdownloadLocTK")) {
/*   351:  510 */       return woadhocdownloadLocTK(event);
/*   352:      */     }
/*   353:  512 */     if (eventId.equalsIgnoreCase("initInvAvailability")) {
/*   354:  514 */       return initInvAvailability(event);
/*   355:      */     }
/*   356:  516 */     if (eventId.equalsIgnoreCase("refreshInvAvailability")) {
/*   357:  518 */       return refreshInvAvailability(event);
/*   358:      */     }
/*   359:  520 */     if (eventId.equalsIgnoreCase("selectInvAvailability")) {
/*   360:  522 */       return selectInvAvailability(event);
/*   361:      */     }
/*   362:  524 */     if (eventId.equalsIgnoreCase("canrequestmaterial")) {
/*   363:  526 */       return canrequestmaterial(event);
/*   364:      */     }
/*   365:  528 */     if (eventId.equalsIgnoreCase("setitemqbe")) {
/*   366:  530 */       return setitemqbe(event);
/*   367:      */     }
/*   368:  539 */     if (eventId.equalsIgnoreCase("submitMR")) {
/*   369:  541 */       return submitMR(event);
/*   370:      */     }
/*   371:  543 */     if (eventId.equalsIgnoreCase("displayMRSend")) {
/*   372:  545 */       return displayMRSend(event);
/*   373:      */     }
/*   374:  547 */     if (eventId.equalsIgnoreCase("displayMROk")) {
/*   375:  549 */       return displayMROk(event);
/*   376:      */     }
/*   377:  551 */     if (eventId.equalsIgnoreCase("canchangestatus")) {
/*   378:  553 */       return canchangestatus(event);
/*   379:      */     }
/*   380:  555 */     if (eventId.equalsIgnoreCase("canchangetaskstatus")) {
/*   381:  557 */       return canchangetaskstatus(event);
/*   382:      */     }
/*   383:  559 */     if (eventId.equalsIgnoreCase("cancapturesignature")) {
/*   384:  561 */       return cancapturesignature(event);
/*   385:      */     }
/*   386:  563 */     if (eventId.equalsIgnoreCase("initWOAssetPage")) {
/*   387:  565 */       return initWOAssetPage(event);
/*   388:      */     }
/*   389:  567 */     if (eventId.equalsIgnoreCase("initWOLocPage")) {
/*   390:  569 */       return initWOLocPage(event);
/*   391:      */     }
/*   392:  571 */     if (eventId.equalsIgnoreCase("gotoerrorpage")) {
/*   393:  573 */       return gotoerrorpage(event);
/*   394:      */     }
/*   395:  575 */     if (eventId.equalsIgnoreCase("toggleShowMRErrors")) {
/*   396:  577 */       return toggleShowMRErrors(event);
/*   397:      */     }
/*   398:  579 */     if (eventId.equalsIgnoreCase("gotoworklistmainpage")) {
/*   399:  581 */       return gotoworklistmainpage(event);
/*   400:      */     }
/*   401:  583 */     if (eventId.equalsIgnoreCase("isworkorder")) {
/*   402:  585 */       return isworkorder(event);
/*   403:      */     }
/*   404:  587 */     if (eventId.equalsIgnoreCase("ischange")) {
/*   405:  589 */       return ischange(event);
/*   406:      */     }
/*   407:  591 */     if (eventId.equalsIgnoreCase("isrelease")) {
/*   408:  593 */       return isrelease(event);
/*   409:      */     }
/*   410:  595 */     if (eventId.equalsIgnoreCase("ischangeorrelease")) {
/*   411:  597 */       return ischangeorrelease(event);
/*   412:      */     }
/*   413:  599 */     if (eventId.equalsIgnoreCase("isticket")) {
/*   414:  601 */       return isticket(event);
/*   415:      */     }
/*   416:  603 */     if (eventId.equalsIgnoreCase("canchangetkstatus")) {
/*   417:  605 */       return canchangetkstatus(event);
/*   418:      */     }
/*   419:  607 */     if (eventId.equalsIgnoreCase("changetkstatus")) {
/*   420:  609 */       return changetkstatus(event);
/*   421:      */     }
/*   422:  611 */     if (eventId.equalsIgnoreCase("canchangeactstatus")) {
/*   423:  613 */       return canchangeactstatus(event);
/*   424:      */     }
/*   425:  615 */     if (eventId.equalsIgnoreCase("iswooractivity")) {
/*   426:  617 */       return iswooractivity(event);
/*   427:      */     }
/*   428:  619 */     if (eventId.equalsIgnoreCase("caneditactivity")) {
/*   429:  621 */       return caneditactivity(event);
/*   430:      */     }
/*   431:  623 */     if (eventId.equalsIgnoreCase("activityiswo")) {
/*   432:  625 */       return activityiswo(event);
/*   433:      */     }
/*   434:  627 */     if (eventId.equalsIgnoreCase("activitynotwo")) {
/*   435:  629 */       return activitynotwo(event);
/*   436:      */     }
/*   437:  631 */     if (eventId.equalsIgnoreCase("candownloadactivity")) {
/*   438:  633 */       return candownloadactivity(event);
/*   439:      */     }
/*   440:  635 */     if (eventId.equalsIgnoreCase("gotowo")) {
/*   441:  637 */       return gotowo(event);
/*   442:      */     }
/*   443:  639 */     if (eventId.equalsIgnoreCase("canedittask")) {
/*   444:  641 */       return canedittask(event);
/*   445:      */     }
/*   446:  643 */     if (eventId.equalsIgnoreCase("togglerelrecbutton")) {
/*   447:  645 */       return togglerelrecbutton(event);
/*   448:      */     }
/*   449:  647 */     if (eventId.equalsIgnoreCase("downloadable")) {
/*   450:  649 */       return downloadable(event);
/*   451:      */     }
/*   452:  651 */     if (eventId.equalsIgnoreCase("adhocdownloadrelrec")) {
/*   453:  653 */       return adhocdownloadrelrec(event);
/*   454:      */     }
/*   455:  655 */     if (eventId.equalsIgnoreCase("adhocdownloadwoctivity")) {
/*   456:  657 */       return adhocdownloadwoctivity(event);
/*   457:      */     }
/*   458:  659 */     if (eventId.equalsIgnoreCase("gotorelrec")) {
/*   459:  661 */       return gotorelrec(event);
/*   460:      */     }
/*   461:  663 */     if (eventId.equalsIgnoreCase("selectrelwovalues")) {
/*   462:  665 */       return selectrelwovalues(event);
/*   463:      */     }
/*   464:  667 */     if (eventId.equalsIgnoreCase("selectreltkvalues")) {
/*   465:  669 */       return selectreltkvalues(event);
/*   466:      */     }
/*   467:  671 */     if (eventId.equalsIgnoreCase("deleterelatedrecord")) {
/*   468:  673 */       return deleterelatedrecord(event);
/*   469:      */     }
/*   470:  675 */     if (eventId.equalsIgnoreCase("candeleterelatedrecord")) {
/*   471:  677 */       return candeleterelatedrecord(event);
/*   472:      */     }
/*   473:  679 */     if (eventId.equalsIgnoreCase("canAddRelatedRecord")) {
/*   474:  681 */       return canAddRelatedRecord(event);
/*   475:      */     }
/*   476:  683 */     if (eventId.equalsIgnoreCase("deleterelatedasset")) {
/*   477:  685 */       return deleterelatedasset(event);
/*   478:      */     }
/*   479:  687 */     if (eventId.equalsIgnoreCase("candeleterelatedasset")) {
/*   480:  689 */       return candeleterelatedasset(event);
/*   481:      */     }
/*   482:  691 */     if (eventId.equalsIgnoreCase("initAllStatuses")) {
/*   483:  693 */       return initAllStatuses(event);
/*   484:      */     }
/*   485:  696 */     if (eventId.equalsIgnoreCase("initAllClasses")) {
/*   486:  697 */       return initAllClasses(event);
/*   487:      */     }
/*   488:  700 */     if (eventId.equalsIgnoreCase("gotoslapage")) {
/*   489:  702 */       return gotoslapage(event);
/*   490:      */     }
/*   491:  704 */     if (eventId.equalsIgnoreCase("relatedassetchanged")) {
/*   492:  706 */       return relatedassetchanged(event);
/*   493:      */     }
/*   494:  708 */     if (eventId.equalsIgnoreCase("relatedlocassetchanged")) {
/*   495:  710 */       return relatedlocassetchanged(event);
/*   496:      */     }
/*   497:  712 */     if (eventId.equalsIgnoreCase("validaterelatedasset")) {
/*   498:  714 */       return validaterelatedasset(event);
/*   499:      */     }
/*   500:  716 */     if (eventId.equalsIgnoreCase("selectsiteid")) {
/*   501:  718 */       return selectsiteid(event);
/*   502:      */     }
/*   503:  720 */     if (eventId.equalsIgnoreCase("markalldone")) {
/*   504:  722 */       return markalldone(event);
/*   505:      */     }
/*   506:  724 */     if (eventId.equalsIgnoreCase("initservicegrouplookup")) {
/*   507:  726 */       return initservicegrouplookup(event);
/*   508:      */     }
/*   509:  728 */     if (eventId.equalsIgnoreCase("validateservicegroup")) {
/*   510:  730 */       return validateservicegroup(event);
/*   511:      */     }
/*   512:  732 */     if (eventId.equalsIgnoreCase("initservicelookup")) {
/*   513:  734 */       return initservicelookup(event);
/*   514:      */     }
/*   515:  736 */     if (eventId.equalsIgnoreCase("validateservice")) {
/*   516:  738 */       return validateservice(event);
/*   517:      */     }
/*   518:  740 */     if (eventId.equalsIgnoreCase("insertrelasset")) {
/*   519:  742 */       return insertrelasset(event);
/*   520:      */     }
/*   521:  744 */     if (eventId.equalsIgnoreCase("actualenablebc")) {
/*   522:  746 */       return actualenablebc(event);
/*   523:      */     }
/*   524:  749 */     if (eventId.equalsIgnoreCase("hideIfNullOrNotDownloaded")) {
/*   525:  751 */       return processPopUpMenuDisplay(event, true);
/*   526:      */     }
/*   527:  754 */     if (eventId.equalsIgnoreCase("hideIfNotNullAndDownloaded")) {
/*   528:  756 */       return processPopUpMenuDisplay(event, false);
/*   529:      */     }
/*   530:  758 */     if (eventId.equalsIgnoreCase("createPrimaryMultiEntry")) {
/*   531:  760 */       return createPrimaryMultiEntry(event);
/*   532:      */     }
/*   533:  762 */     if (eventId.equalsIgnoreCase("moveSwapAsset")) {
/*   534:  764 */       return moveSwapAsset(event);
/*   535:      */     }
/*   536:  766 */     if (eventId.equalsIgnoreCase("gotoSpecsPage")) {
/*   537:  768 */       return gotoSpecsPage(event);
/*   538:      */     }
/*   539:  770 */     if (eventId.equalsIgnoreCase("canSubmit")) {
/*   540:  772 */       return canSubmit(event);
/*   541:      */     }
/*   542:  775 */     if (eventId.equalsIgnoreCase("openTicketAndCommunication")) {
/*   543:  777 */       return openTicketAndCommunication(event);
/*   544:      */     }
/*   545:  780 */     if (eventId.equalsIgnoreCase("workTypeFilterLookup")) {
/*   546:  782 */       return workTypeFilterLookup(event);
/*   547:      */     }
/*   548:  783 */     if (eventId.equalsIgnoreCase("haspendingstatuschange")) {
/*   549:  784 */       return haspendingstatuschange(event);
/*   550:      */     }
/*   551:  785 */     if (eventId.equalsIgnoreCase("uploadpendingstatus")) {
/*   552:  786 */       return uploadpendingstatus(event);
/*   553:      */     }
/*   554:  789 */     if (eventId.equalsIgnoreCase("deletecrewmember")) {
/*   555:  790 */       return deleteCrewMember(event);
/*   556:      */     }
/*   557:  793 */     if (eventId.equalsIgnoreCase("inittkstatuseslookup")) {
/*   558:  795 */       return initTKStatusesLookup(event);
/*   559:      */     }
/*   560:  798 */     if (eventId.equalsIgnoreCase("goToChildPage")) {
/*   561:  800 */       return goToChildPage(event);
/*   562:      */     }
/*   563:  803 */     if (eventId.equalsIgnoreCase("refreshChildrenPage")) {
/*   564:  805 */       return refreshChildrenPage(event);
/*   565:      */     }
/*   566:  808 */     if (eventId.equalsIgnoreCase("moveSwapAssetfromChildren")) {
/*   567:  810 */       return moveSwapAssetfromChildren(event);
/*   568:      */     }
/*   569:  813 */     if (eventId.equalsIgnoreCase("setAssetRowMenuVisibility")) {
/*   570:  815 */       return setRouteChildrenMenuVisibility(event, "ASSETNUM");
/*   571:      */     }
/*   572:  818 */     if (eventId.equalsIgnoreCase("setLocationRowMenuVisibility")) {
/*   573:  820 */       return setRouteChildrenMenuVisibility(event, "LOCATION");
/*   574:      */     }
/*   575:  823 */     if (eventId.equalsIgnoreCase("gotocreatecommpage")) {
/*   576:  825 */       return gotocreatecommpage(event);
/*   577:      */     }
/*   578:  828 */     if (eventId.equalsIgnoreCase("canchangeactowner")) {
/*   579:  830 */       return canchangeactowner(event);
/*   580:      */     }
/*   581:  833 */     if (eventId.equalsIgnoreCase("filteractivities")) {
/*   582:  835 */       return filterActivities(event);
/*   583:      */     }
/*   584:  838 */     if (eventId.equalsIgnoreCase("validateactivity")) {
/*   585:  840 */       return validateActivity(event);
/*   586:      */     }
/*   587:  843 */     if (eventId.equals("validateactivityforlabtrans")) {
/*   588:  845 */       return validateActivityForLabtrans(event);
/*   589:      */     }
/*   590:  848 */     if (eventId.equalsIgnoreCase("pluscinsertwods")) {
/*   591:  849 */       return pluscinsertwods(event);
/*   592:      */     }
/*   593:  850 */     if (eventId.equalsIgnoreCase("plusccopydsplanstowo")) {
/*   594:  851 */       return plusccopydsplanstowo(event);
/*   595:      */     }
/*   596:  852 */     if (eventId.equalsIgnoreCase("plusccanattachdatasheet")) {
/*   597:  853 */       return plusccanattachdatasheet(event);
/*   598:      */     }
/*   599:  854 */     if (eventId.equalsIgnoreCase("pluscselectstatusvalues")) {
/*   600:  855 */       return pluscselectstatusvalues(event);
/*   601:      */     }
/*   602:  856 */     if (eventId.equalsIgnoreCase("pluscdscalselectasfoundstatusvalues")) {
/*   603:  857 */       return pluscdscalselectasfoundstatusvalues(event);
/*   604:      */     }
/*   605:  858 */     if (eventId.equalsIgnoreCase("pluscdscalselectasleftstatusvalues")) {
/*   606:  859 */       return pluscdscalselectasleftstatusvalues(event);
/*   607:      */     }
/*   608:  860 */     if (eventId.equalsIgnoreCase("pluscselectfromengunitvalues")) {
/*   609:  861 */       return pluscselectfromengunitvalues(event);
/*   610:      */     }
/*   611:  862 */     if (eventId.equalsIgnoreCase("pluscselecttoengunitvalues")) {
/*   612:  863 */       return pluscselecttoengunitvalues(event);
/*   613:      */     }
/*   614:  864 */     if (eventId.equalsIgnoreCase("pluscselectdsplannumvalues")) {
/*   615:  865 */       return pluscselectdsplannumvalues(event);
/*   616:      */     }
/*   617:  866 */     if (eventId.equalsIgnoreCase("pluscbuilddsparenttree"))
/*   618:      */     {
/*   619:  867 */       event.setValue(pluscscan4Parents(event));
/*   620:  868 */       return true;
/*   621:      */     }
/*   622:  869 */     if (eventId.equalsIgnoreCase("pluscbuilddsbranchtree"))
/*   623:      */     {
/*   624:  870 */       event.setValue(pluscscan4Children(event));
/*   625:  871 */       return true;
/*   626:      */     }
/*   627:  872 */     if (eventId.equalsIgnoreCase("pluscscansettreedsdata"))
/*   628:      */     {
/*   629:  873 */       pluscscansettreedsdata(event);
/*   630:  874 */       return true;
/*   631:      */     }
/*   632:  875 */     if (eventId.equalsIgnoreCase("pluscselectwoengunitvalues"))
/*   633:      */     {
/*   634:  876 */       pluscselectwoengunitvalues(event);
/*   635:  877 */       return true;
/*   636:      */     }
/*   637:  878 */     if (eventId.equalsIgnoreCase("pluscselectwodsplannum"))
/*   638:      */     {
/*   639:  879 */       pluscselectwodsplannum(event);
/*   640:  880 */       return true;
/*   641:      */     }
/*   642:  881 */     if (eventId.equalsIgnoreCase("pluscselectafnumvalues")) {
/*   643:  882 */       return pluscselectafnumvalues(event);
/*   644:      */     }
/*   645:  883 */     if (eventId.equalsIgnoreCase("pluscdsafcalselectasfoundstatusvalues")) {
/*   646:  884 */       return pluscdsafcalselectasfoundstatusvalues(event);
/*   647:      */     }
/*   648:  885 */     if (eventId.equalsIgnoreCase("pluscdsafcalselectasleftstatusvalues")) {
/*   649:  886 */       return pluscdsafcalselectasleftstatusvalues(event);
/*   650:      */     }
/*   651:  887 */     if (eventId.equalsIgnoreCase("pluscafselectfromengunitvalues")) {
/*   652:  888 */       return pluscafselectfromengunitvalues(event);
/*   653:      */     }
/*   654:  889 */     if (eventId.equalsIgnoreCase("pluscafselecttoengunitvalues")) {
/*   655:  890 */       return pluscafselecttoengunitvalues(event);
/*   656:      */     }
/*   657:  891 */     if (eventId.equalsIgnoreCase("pluscfailrowstyle")) {
/*   658:  892 */       return pluscfailrowstyle(event);
/*   659:      */     }
/*   660:  893 */     if (eventId.equalsIgnoreCase("pluscfailtextstyle")) {
/*   661:  894 */       return pluscfailtextstyle(event);
/*   662:      */     }
/*   663:  895 */     if (eventId.equalsIgnoreCase("pluscselectcpnumvalues")) {
/*   664:  896 */       return pluscselectcpnumvalues(event);
/*   665:      */     }
/*   666:  897 */     if (eventId.equalsIgnoreCase("calculateValues")) {
/*   667:  898 */       return calculateValues(event);
/*   668:      */     }
/*   669:  899 */     if (eventId.equalsIgnoreCase("afterUpdateMeasuredValues")) {
/*   670:  900 */       return afterUpdateMeasuredValues(event);
/*   671:      */     }
/*   672:  901 */     if (eventId.equalsIgnoreCase("setAnalogDiscreteReadOnlyField")) {
/*   673:  902 */       return setAnalogDiscreteReadOnlyField(event);
/*   674:      */     }
/*   675:  903 */     if (eventId.equalsIgnoreCase("pluscsetaflabel")) {
/*   676:  904 */       return pluscsetaflabel(event);
/*   677:      */     }
/*   678:  905 */     if (eventId.equalsIgnoreCase("pluscinsertcp")) {
/*   679:  906 */       return pluscinsertcp(event);
/*   680:      */     }
/*   681:  907 */     if (eventId.equalsIgnoreCase("pluscinsertfc")) {
/*   682:  908 */       return pluscInsertFunDynChk(event, "pluscfcmain", "CALFUNCTION");
/*   683:      */     }
/*   684:  909 */     if (eventId.equalsIgnoreCase("pluscinsertdc")) {
/*   685:  910 */       return pluscInsertFunDynChk(event, "pluscdcmain", "CALDYNAMIC");
/*   686:      */     }
/*   687:  911 */     if (eventId.equalsIgnoreCase("pluscsetinvisible")) {
/*   688:  912 */       return pluscsetinvisible(event);
/*   689:      */     }
/*   690:  913 */     if (eventId.equalsIgnoreCase("pluscsetpointactionvalues")) {
/*   691:  914 */       return pluscsetpointactionvalues(event);
/*   692:      */     }
/*   693:  915 */     if (eventId.equalsIgnoreCase("pluscrefresh")) {
/*   694:  916 */       return pluscrefresh(event);
/*   695:      */     }
/*   696:  917 */     if (eventId.equalsIgnoreCase("pluscinitcppage")) {
/*   697:  918 */       return pluscinitcppage(event);
/*   698:      */     }
/*   699:  919 */     if (eventId.equalsIgnoreCase("pluscgotoaftab")) {
/*   700:  920 */       return pluscgotoaftab(event);
/*   701:      */     }
/*   702:  921 */     if (eventId.equalsIgnoreCase("pluscGotoAsFoundPageFromCPTab")) {
/*   703:  922 */       return pluscGotoAsFoundPageFromCPTab(event);
/*   704:      */     }
/*   705:  923 */     if (eventId.equalsIgnoreCase("pluscGotoAsLeftPageFromCPTab")) {
/*   706:  924 */       return pluscGotoAsLeftPageFromCPTab(event);
/*   707:      */     }
/*   708:  925 */     if (eventId.equalsIgnoreCase("pluscGotoFcAsFoundPageFromCPTab")) {
/*   709:  926 */       return pluscGotoFcAsFoundPageFromCPTab(event);
/*   710:      */     }
/*   711:  927 */     if (eventId.equalsIgnoreCase("pluscGotoFcAsLeftPageFromCPTab")) {
/*   712:  928 */       return pluscGotoFcAsLeftPageFromCPTab(event);
/*   713:      */     }
/*   714:  929 */     if (eventId.equalsIgnoreCase("pluscGotoDcAsFoundPageFromCPTab")) {
/*   715:  930 */       return pluscGotoDcAsFoundPageFromCPTab(event);
/*   716:      */     }
/*   717:  931 */     if (eventId.equalsIgnoreCase("pluscGotoDcAsLeftPageFromCPTab")) {
/*   718:  932 */       return pluscGotoDcAsLeftPageFromCPTab(event);
/*   719:      */     }
/*   720:  933 */     if (eventId.equalsIgnoreCase("pluscGotoViewRecordPageFromCPTab")) {
/*   721:  934 */       return pluscGotoPageFromCPTab(event, "plusccpdetails");
/*   722:      */     }
/*   723:  935 */     if (eventId.equalsIgnoreCase("pluscinitdstab")) {
/*   724:  936 */       return pluscinitdstab(event);
/*   725:      */     }
/*   726:  937 */     if (eventId.equalsIgnoreCase("pluscinitdshierarchytab")) {
/*   727:  938 */       return pluscinitdshierarchytab(event);
/*   728:      */     }
/*   729:  939 */     if (eventId.equalsIgnoreCase("pluscnextrec")) {
/*   730:  940 */       return pluscnextrec(event);
/*   731:      */     }
/*   732:  941 */     if (eventId.equalsIgnoreCase("pluscinitchangeviewCalpoint")) {
/*   733:  942 */       return pluscinitchangeviewCalpoint(event);
/*   734:      */     }
/*   735:  943 */     if (eventId.equalsIgnoreCase("pluscinitchangeviewCalfunction")) {
/*   736:  944 */       return pluscinitchangeviewCalfunction(event);
/*   737:      */     }
/*   738:  945 */     if (eventId.equalsIgnoreCase("pluscinitchangeviewCaldynamic")) {
/*   739:  946 */       return pluscinitchangeviewCaldynamic(event);
/*   740:      */     }
/*   741:  947 */     if (eventId.equalsIgnoreCase("pluscdisplaychangeview")) {
/*   742:  948 */       return pluscdisplaychangeview(event);
/*   743:      */     }
/*   744:  949 */     if (eventId.equalsIgnoreCase("pluscdochangeview")) {
/*   745:  950 */       return pluscdochangeview(event);
/*   746:      */     }
/*   747:  951 */     if (eventId.equalsIgnoreCase("pluscsetaddpointvisibility")) {
/*   748:  952 */       return pluscsetaddpointvisibility(event);
/*   749:      */     }
/*   750:  953 */     if (eventId.equalsIgnoreCase("pluscshowchangeviewbutton")) {
/*   751:  954 */       return pluscshowchangeviewbutton(event);
/*   752:      */     }
/*   753:  955 */     if (eventId.equalsIgnoreCase("pluscinitcp")) {
/*   754:  956 */       return pluscinitcp(event);
/*   755:      */     }
/*   756:  957 */     if (eventId.equalsIgnoreCase("pluscsetinputoutputeditable")) {
/*   757:  958 */       return pluscsetinputoutputeditable(event);
/*   758:      */     }
/*   759:  959 */     if (eventId.equalsIgnoreCase("pluscsetinputoutputeditable")) {
/*   760:  960 */       return pluscsetinputoutputeditable(event);
/*   761:      */     }
/*   762:  961 */     if (eventId.equalsIgnoreCase("pluscsetunitseditable")) {
/*   763:  962 */       return pluscsetunitseditable(event);
/*   764:      */     }
/*   765:  963 */     if (eventId.equalsIgnoreCase("pluscsetsetpointeditable")) {
/*   766:  964 */       return pluscsetsetpointeditable(event);
/*   767:      */     }
/*   768:  965 */     if (eventId.equalsIgnoreCase("pluscsetsetpointactioneditable")) {
/*   769:  966 */       return pluscsetsetpointactioneditable(event);
/*   770:      */     }
/*   771:  969 */     if (eventId.equalsIgnoreCase("pluscformatnumber")) {
/*   772:  970 */       return pluscformatnumber(event);
/*   773:      */     }
/*   774:  971 */     if (eventId.equalsIgnoreCase("pluscdsselectfromengunitvalues")) {
/*   775:  972 */       return pluscdsselectfromengunitvalues(event);
/*   776:      */     }
/*   777:  973 */     if (eventId.equalsIgnoreCase("pluscdsselecttoengunitvalues")) {
/*   778:  974 */       return pluscdsselecttoengunitvalues(event);
/*   779:      */     }
/*   780:  975 */     if (eventId.equalsIgnoreCase("pluscdsselectstatusvalues")) {
/*   781:  976 */       return pluscdsselectstatusvalues(event);
/*   782:      */     }
/*   783:  977 */     if (eventId.equalsIgnoreCase("pluscinitWOAssetPage")) {
/*   784:  978 */       return pluscinitWOAssetPage(event);
/*   785:      */     }
/*   786:  979 */     if (eventId.equalsIgnoreCase("pluscinitdsstatus")) {
/*   787:  980 */       return pluscinitdsstatus(event);
/*   788:      */     }
/*   789:  981 */     if (eventId.equalsIgnoreCase("pluscerrorrowstyle")) {
/*   790:  982 */       return pluscerrorrowstyle(event);
/*   791:      */     }
/*   792:  983 */     if (eventId.equalsIgnoreCase("pluscdsfailrowstyle")) {
/*   793:  984 */       return pluscdsfailrowstyle(event);
/*   794:      */     }
/*   795:  985 */     if (eventId.equalsIgnoreCase("pluscnoadjmade")) {
/*   796:  986 */       return pluscnoadjmade(event);
/*   797:      */     }
/*   798:  987 */     if (eventId.equalsIgnoreCase("pluscsaveclose")) {
/*   799:  988 */       return pluscsaveclose(event);
/*   800:      */     }
/*   801:  989 */     if (eventId.equalsIgnoreCase("refreshwos")) {
/*   802:  990 */       return refreshwos(event);
/*   803:      */     }
/*   804:  993 */     if (eventId.equalsIgnoreCase("displayAsLeftInput")) {
/*   805:  994 */       return displayAsLeftInput(event);
/*   806:      */     }
/*   807:  995 */     if (eventId.equalsIgnoreCase("displayAsLeftOutput")) {
/*   808:  996 */       return displayAsLeftOutput(event);
/*   809:      */     }
/*   810:  997 */     if (eventId.equalsIgnoreCase("validateLocation")) {
/*   811:  998 */       return validateLocation(event);
/*   812:      */     }
/*   813:  999 */     if (eventId.equalsIgnoreCase("initWODsDetails")) {
/*   814: 1000 */       return initWODsDetails(event);
/*   815:      */     }
/*   816: 1001 */     if (eventId.equalsIgnoreCase("pluscgotoaftabFromDSTree")) {
/*   817: 1002 */       return pluscgotoaftabFromDSTree(event);
/*   818:      */     }
/*   819: 1003 */     if (eventId.equalsIgnoreCase("pluscGOTOpluscdsafresultsT1")) {
/*   820: 1004 */       return pluscGOTOpluscdsafresultsT1(event);
/*   821:      */     }
/*   822: 1005 */     if (eventId.equalsIgnoreCase("displayAfCalPointsMenu")) {
/*   823: 1006 */       return displayAfCalPointsMenu(event);
/*   824:      */     }
/*   825: 1007 */     if (eventId.equalsIgnoreCase("displayAfFuncChecksMenu")) {
/*   826: 1008 */       return displayAfFuncChecksMenu(event);
/*   827:      */     }
/*   828: 1009 */     if (eventId.equalsIgnoreCase("displayAfDynChecksMenu")) {
/*   829: 1010 */       return displayAfDynChecksMenu(event);
/*   830:      */     }
/*   831: 1011 */     if (eventId.equalsIgnoreCase("displayDsCalPointsMenu")) {
/*   832: 1012 */       return displayDsCalPointsMenu(event);
/*   833:      */     }
/*   834: 1013 */     if (eventId.equalsIgnoreCase("displayDsFuncChecksMenu")) {
/*   835: 1014 */       return displayDsFuncChecksMenu(event);
/*   836:      */     }
/*   837: 1015 */     if (eventId.equalsIgnoreCase("displayDsDynChecksMenu")) {
/*   838: 1016 */       return displayDsDynChecksMenu(event);
/*   839:      */     }
/*   840: 1017 */     if (eventId.equalsIgnoreCase("pluscgotocptabFromAfList")) {
/*   841: 1018 */       return pluscgotocptabFromAfList(event);
/*   842:      */     }
/*   843: 1019 */     if (eventId.equalsIgnoreCase("pluscgotofctabFromAfList")) {
/*   844: 1020 */       return pluscgotofctabFromAfList(event);
/*   845:      */     }
/*   846: 1021 */     if (eventId.equalsIgnoreCase("pluscgotodctabFromAfList")) {
/*   847: 1022 */       return pluscgotodctabFromAfList(event);
/*   848:      */     }
/*   849: 1023 */     if (eventId.equalsIgnoreCase("pluscgotocptabFromAfTree")) {
/*   850: 1024 */       return pluscgotocptabFromAfTree(event);
/*   851:      */     }
/*   852: 1025 */     if (eventId.equalsIgnoreCase("pluscgotofctabFromAfTree")) {
/*   853: 1026 */       return pluscgotofctabFromAfTree(event);
/*   854:      */     }
/*   855: 1027 */     if (eventId.equalsIgnoreCase("pluscgotodctabFromAfTree")) {
/*   856: 1028 */       return pluscgotodctabFromAfTree(event);
/*   857:      */     }
/*   858: 1029 */     if (eventId.equalsIgnoreCase("pluscgotocptabFromDsList")) {
/*   859: 1030 */       return pluscgotocptabFromDsList(event);
/*   860:      */     }
/*   861: 1031 */     if (eventId.equalsIgnoreCase("pluscgotofctabFromDsList")) {
/*   862: 1032 */       return pluscgotofctabFromDsList(event);
/*   863:      */     }
/*   864: 1033 */     if (eventId.equalsIgnoreCase("pluscgotodctabFromDsList")) {
/*   865: 1034 */       return pluscgotodctabFromDsList(event);
/*   866:      */     }
/*   867: 1035 */     if (eventId.equalsIgnoreCase("displaydslist")) {
/*   868: 1036 */       return displaydslist(event);
/*   869:      */     }
/*   870: 1037 */     if (eventId.equalsIgnoreCase("afterUpdateFunctionCheck")) {
/*   871: 1038 */       return afterUpdateFunctionCheck(event);
/*   872:      */     }
/*   873: 1039 */     if (eventId.equalsIgnoreCase("validateDynCheckInput")) {
/*   874: 1040 */       return validateDynCheckInput(event);
/*   875:      */     }
/*   876: 1041 */     if (eventId.equalsIgnoreCase("displayCpAveragesMenu")) {
/*   877: 1042 */       return displayCpAveragesMenu(event);
/*   878:      */     }
/*   879: 1043 */     if (eventId.equalsIgnoreCase("pluscGotoAsFoundAveragesPage")) {
/*   880: 1044 */       return pluscGotoAsFoundAveragesPage(event);
/*   881:      */     }
/*   882: 1045 */     if (eventId.equalsIgnoreCase("pluscGotoAsLeftAveragesPage")) {
/*   883: 1046 */       return pluscGotoAsLeftAveragesPage(event);
/*   884:      */     }
/*   885: 1047 */     if (eventId.equalsIgnoreCase("initResponsePage")) {
/*   886: 1048 */       return initResponsePage(event);
/*   887:      */     }
/*   888: 1049 */     if (eventId.equalsIgnoreCase("pluscValidateAssociatedTool")) {
/*   889: 1050 */       return pluscValidateAssociatedTool(event);
/*   890:      */     }
/*   891: 1051 */     if (eventId.equalsIgnoreCase("validateInsertWODS")) {
/*   892: 1052 */       return validateInsertWODS(event);
/*   893:      */     }
/*   894: 1053 */     if (eventId.equalsIgnoreCase("displaydspage")) {
/*   895: 1054 */       return displaydspage(event);
/*   896:      */     }
/*   897: 1055 */     if (eventId.equalsIgnoreCase("pluscdspckenterdsdata")) {
/*   898: 1056 */       return pluscdspckenterdsdata(event);
/*   899:      */     }
/*   900: 1057 */     if (eventId.equalsIgnoreCase("pluscWODsInstrNoAdjMadeDisplayEvent")) {
/*   901: 1058 */       return pluscWODsInstrNoAdjMadeDisplayEvent(event);
/*   902:      */     }
/*   903: 1059 */     if (eventId.equalsIgnoreCase("plusCDSRequiredValidate")) {
/*   904: 1060 */       return plusCDSRequiredValidate(event);
/*   905:      */     }
/*   906: 1061 */     if (eventId.equalsIgnoreCase("pluscWODsInstrNoAdjMadeInitEvent")) {
/*   907: 1062 */       return pluscWODsInstrNoAdjMadeInitEvent(event);
/*   908:      */     }
/*   909: 1063 */     if (eventId.equalsIgnoreCase("pluscGotoAsFoundPageFromCPTree")) {
/*   910: 1064 */       return pluscGotoAsFoundPageFromCPTree(event);
/*   911:      */     }
/*   912: 1065 */     if (eventId.equalsIgnoreCase("pluscGotoAsLeftPageFromCPTree")) {
/*   913: 1066 */       return pluscGotoAsLeftPageFromCPTree(event);
/*   914:      */     }
/*   915: 1067 */     if (eventId.equalsIgnoreCase("pluscGotoDetailsPageFromCPTree")) {
/*   916: 1068 */       return pluscGotoDetailsPageFromCPTree(event);
/*   917:      */     }
/*   918: 1071 */     if (eventId.equalsIgnoreCase("pluscWODsAsfAslStatusEvent")) {
/*   919: 1072 */       return pluscWODsAsfAslStatusEvent(event);
/*   920:      */     }
/*   921: 1075 */     if (eventId.equalsIgnoreCase("pluscinitafstatus")) {
/*   922: 1076 */       return pluscInitAFStatusEvent(event);
/*   923:      */     }
/*   924: 1079 */     if (eventId.equalsIgnoreCase("workTypeFilterLookupNoQBE")) {
/*   925: 1081 */       return workTypeFilterLookupNoQBE(event);
/*   926:      */     }
/*   927: 1097 */     return super.performEvent(event);
/*   928:      */   }
/*   929:      */   
/*   930:      */   public boolean workTypeFilterLookupNoQBE(UIEvent event)
/*   931:      */     throws MobileApplicationException
/*   932:      */   {
/*   933: 1107 */     MobileMboDataBean creatingObjDataBean = DataBeanCache.findDataBean("WORKLIST");
/*   934: 1108 */     MobileMboDataBean databean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*   935: 1109 */     if (databean != null)
/*   936:      */     {
/*   937: 1110 */       String orgid = creatingObjDataBean.getValue("ORGID");
/*   938: 1111 */       if (!"".equals(orgid)) {
/*   939: 1112 */         databean.getQBE().setQBE("ORGID", orgid);
/*   940:      */       }
/*   941: 1115 */       if (creatingObjDataBean.getValue("CLASS") != null)
/*   942:      */       {
/*   943: 1116 */         String woclass = creatingObjDataBean.getValue("CLASS");
/*   944: 1117 */         if (!"".equals(woclass)) {
/*   945: 1118 */           databean.getQBE().setQBE("WOCLASS", woclass);
/*   946:      */         }
/*   947:      */       }
/*   948:      */     }
/*   949: 1122 */     return true;
/*   950:      */   }
/*   951:      */   
/*   952:      */   protected void treatAdditionalWhere(UIEvent event)
/*   953:      */     throws MobileApplicationException
/*   954:      */   {
/*   955: 1133 */     if (event.getThreadStatus() != 1) {
/*   956: 1135 */       return;
/*   957:      */     }
/*   958: 1139 */     MobileMboDataBean lookupBean = getItemLookupBean(event);
/*   959: 1140 */     if (lookupBean == null) {
/*   960: 1142 */       return;
/*   961:      */     }
/*   962: 1146 */     MobileMboDataBean dataBean = getSourceBean(event);
/*   963: 1148 */     if (dataBean != null)
/*   964:      */     {
/*   965: 1150 */       StringBuffer where = new StringBuffer();
/*   966: 1151 */       String lineType = dataBean.getValue("LINETYPE");
/*   967: 1152 */       List whereParams = new ArrayList();
/*   968: 1153 */       if (lineType.length() > 0)
/*   969:      */       {
/*   970: 1155 */         where.append("(itemtype = ?)");
/*   971: 1156 */         whereParams.add(lineType);
/*   972:      */       }
/*   973:      */       else
/*   974:      */       {
/*   975: 1159 */         where.append("(itemtype in (select value from synonymdomain where domainid='ITEMTYPE' and maxvalue in ('ITEM', 'TOOL', 'STDSERVICE')))");
/*   976:      */       }
/*   977: 1161 */       where.append(" and status in (select value from synonymdomain where domainid='ITEMSTATUS' and maxvalue in ('ACTIVE','PLANNING', 'PENDOBS'))");
/*   978: 1162 */       String storeLoc = dataBean.getValue("STORELOC");
/*   979: 1163 */       if (storeLoc.length() > 0)
/*   980:      */       {
/*   981: 1165 */         where.append(" and (exists (select itemnum from inventory where item.itemnum = inventory.itemnum and location = ? and siteid = ? and status in (select value from synonymdomain where domainid='ITEMSTATUS' and maxvalue in ('ACTIVE', 'PENDOBS', 'PLANNING'))))");
/*   982: 1166 */         String siteId = dataBean.getValue("SITEID");
/*   983: 1167 */         whereParams.add(storeLoc);
/*   984: 1168 */         whereParams.add(siteId);
/*   985:      */       }
/*   986: 1171 */       lookupBean.setAdditionalWhere(where.toString(), whereParams.toArray());
/*   987: 1172 */       lookupBean.setAditionalWhereScope(2);
/*   988:      */     }
/*   989:      */   }
/*   990:      */   
/*   991:      */   protected MobileMboDataBean getSourceBean(UIEvent event)
/*   992:      */     throws MobileApplicationException
/*   993:      */   {
/*   994: 1179 */     return ((PageControl)((AbstractMobileControl)event.getCreatingObject()).getPage()).getLaunchingControl().getDataBean();
/*   995:      */   }
/*   996:      */   
/*   997:      */   protected MobileMboDataBean getItemLookupBean(UIEvent event)
/*   998:      */     throws MobileApplicationException
/*   999:      */   {
/*  1000: 1185 */     return ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*  1001:      */   }
/*  1002:      */   
/*  1003:      */   private boolean validateActivityForLabtrans(UIEvent event)
/*  1004:      */     throws MobileApplicationException
/*  1005:      */   {
/*  1006: 1192 */     if (event.getValue() == null) {
/*  1007: 1194 */       return true;
/*  1008:      */     }
/*  1009: 1196 */     String value = event.getValue().toString();
/*  1010:      */     
/*  1011: 1198 */     MobileMboDataBean labTransBean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*  1012:      */     
/*  1013: 1200 */     MobileMboDataBean tasksBean = DataBeanCache.getDataBean("WOTASKS", "WOTASKS");
/*  1014: 1201 */     tasksBean.getQBE().reset();
/*  1015: 1202 */     tasksBean.getQBE().setQbeExactMatch(true);
/*  1016: 1203 */     tasksBean.getQBE().setQBE("DISPLAYWONUM", labTransBean.getValue("REFWO"));
/*  1017: 1204 */     tasksBean.getQBE().setQBE("SITEID", labTransBean.getValue("SITEID"));
/*  1018: 1205 */     tasksBean.getQBE().setQBE("TASKID", value);
/*  1019: 1206 */     tasksBean.reset();
/*  1020: 1208 */     if (tasksBean.count() == 1)
/*  1021:      */     {
/*  1022: 1210 */       String wapprExt = ((WOApp)UIUtil.getApplication()).getInternalValue(labTransBean, "WOSTATUS", "WAPPR");
/*  1023: 1211 */       if (wapprExt.equals(tasksBean.getValue(0, "STATUS")))
/*  1024:      */       {
/*  1025: 1213 */         UIUtil.showFailureMessageBox(MobileMessageGenerator.generate("NotAllowedTaskIDActual", new Object[] { value }));
/*  1026: 1214 */         event.setEventErrored();
/*  1027: 1215 */         ((AbstractMobileControl)event.getCreatingObject()).refresh(event);
/*  1028:      */       }
/*  1029:      */     }
/*  1030: 1218 */     return true;
/*  1031:      */   }
/*  1032:      */   
/*  1033:      */   private boolean validateActivity(UIEvent event)
/*  1034:      */     throws MobileApplicationException
/*  1035:      */   {
/*  1036: 1225 */     if (event.getValue() == null) {
/*  1037: 1227 */       return true;
/*  1038:      */     }
/*  1039: 1229 */     String value = event.getValue().toString();
/*  1040:      */     
/*  1041: 1231 */     MobileMboDataBean woTkDataBean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean().getParentBean();
/*  1042: 1232 */     String actBeanName = "WOTASKS";
/*  1043: 1233 */     String fieldId = "TASKID";
/*  1044: 1234 */     String messageId = "NotAllowedTaskIDActual";
/*  1045: 1235 */     if (woTkDataBean.getName().equals("TICKET"))
/*  1046:      */     {
/*  1047: 1237 */       actBeanName = "WOACTIVITY";
/*  1048: 1238 */       fieldId = "WONUM";
/*  1049: 1239 */       messageId = "NotValidApprovedWo";
/*  1050:      */     }
/*  1051: 1242 */     MobileMboDataBean actBean = woTkDataBean.getDataBean(actBeanName);
/*  1052: 1243 */     MobileMbo actMbo = actBean.getMobileMbo(0);
/*  1053: 1244 */     int i = 0;
/*  1054: 1245 */     while (actMbo != null)
/*  1055:      */     {
/*  1056: 1247 */       if (actMbo.getValue(fieldId).equals(value))
/*  1057:      */       {
/*  1058: 1249 */         String wapprExt = ((WOApp)UIUtil.getApplication()).getInternalValue(woTkDataBean, "WOSTATUS", "WAPPR");
/*  1059: 1250 */         if (wapprExt.equals(actMbo.getValue("STATUS")))
/*  1060:      */         {
/*  1061: 1252 */           UIUtil.showFailureMessageBox(MobileMessageGenerator.generate(messageId, new Object[] { value }));
/*  1062: 1253 */           event.setEventErrored();
/*  1063: 1254 */           ((AbstractMobileControl)event.getCreatingObject()).refresh(event);
/*  1064:      */         }
/*  1065: 1256 */         return true;
/*  1066:      */       }
/*  1067: 1258 */       actMbo = actBean.getMobileMbo(++i);
/*  1068:      */     }
/*  1069: 1261 */     return true;
/*  1070:      */   }
/*  1071:      */   
/*  1072:      */   private boolean filterActivities(UIEvent event)
/*  1073:      */     throws MobileApplicationException
/*  1074:      */   {
/*  1075: 1267 */     MobileMboDataBean databean = (MobileMboDataBean)event.getValue();
/*  1076: 1268 */     if (databean.isFiltered())
/*  1077:      */     {
/*  1078: 1270 */       databean.getQBE().reset();
/*  1079: 1271 */       databean.reset();
/*  1080:      */     }
/*  1081: 1274 */     return true;
/*  1082:      */   }
/*  1083:      */   
/*  1084:      */   protected boolean setRouteChildrenMenuVisibility(UIEvent event, String fieldToCheck)
/*  1085:      */     throws MobileApplicationException
/*  1086:      */   {
/*  1087: 1282 */     MobileMboDataBean dataBean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*  1088: 1283 */     if ((dataBean.getValue(fieldToCheck) == null) || (dataBean.getValue(fieldToCheck).length() == 0)) {
/*  1089: 1285 */       ((AbstractMobileControl)event.getCreatingObject()).setVisibility(false);
/*  1090:      */     } else {
/*  1091: 1289 */       ((AbstractMobileControl)event.getCreatingObject()).setVisibility(true);
/*  1092:      */     }
/*  1093: 1292 */     return true;
/*  1094:      */   }
/*  1095:      */   
/*  1096:      */   public boolean canchangeactowner(UIEvent event)
/*  1097:      */     throws MobileApplicationException
/*  1098:      */   {
/*  1099: 1299 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/*  1100: 1300 */     if ((databean != null) && (!databean.getName().equals("WOACTIVITY"))) {
/*  1101: 1301 */       databean = DataBeanCache.findDataBean("WOACTIVITY");
/*  1102:      */     }
/*  1103: 1303 */     if ((databean != null) && (databean.getName().equals("WOACTIVITY")))
/*  1104:      */     {
/*  1105: 1305 */       boolean bShow = true;
/*  1106:      */       
/*  1107: 1307 */       String maxStatus = ((WOApp)UIUtil.getApplication()).getInternalValue(databean, "WOSTATUS", databean.getValue("STATUS"));
/*  1108: 1310 */       if ((maxStatus.equals("CLOSE")) || (maxStatus.equals("CAN"))) {
/*  1109: 1311 */         bShow = false;
/*  1110:      */       }
/*  1111: 1313 */       ((AbstractMobileControl)event.getCreatingObject()).setVisibility(bShow);
/*  1112:      */     }
/*  1113: 1315 */     return true;
/*  1114:      */   }
/*  1115:      */   
/*  1116:      */   protected boolean refreshChildrenPage(UIEvent event)
/*  1117:      */     throws MobileApplicationException
/*  1118:      */   {
/*  1119: 1322 */     AbstractMobileControl control = (AbstractMobileControl)event.getCreatingObject();
/*  1120: 1323 */     MobileMboDataBean woChildrenBean = control.getDataBean();
/*  1121:      */     
/*  1122: 1325 */     woChildrenBean.setInternalQBE("_DONE", "0");
/*  1123: 1326 */     if ("alistTbl".equalsIgnoreCase(control.getId()))
/*  1124:      */     {
/*  1125: 1327 */       woChildrenBean.setInternalQBE("ASSETNUM", "!=~NULL~");
/*  1126: 1328 */       woChildrenBean.setInternalQBE("LOCATION", null);
/*  1127:      */     }
/*  1128: 1329 */     else if ("llistTbl".equalsIgnoreCase(control.getId()))
/*  1129:      */     {
/*  1130: 1330 */       woChildrenBean.setInternalQBE("ASSETNUM", null);
/*  1131: 1331 */       woChildrenBean.setInternalQBE("LOCATION", "!=~NULL~");
/*  1132:      */     }
/*  1133: 1333 */     woChildrenBean.reset();
/*  1134:      */     
/*  1135: 1335 */     return true;
/*  1136:      */   }
/*  1137:      */   
/*  1138:      */   protected boolean goToChildPage(UIEvent event)
/*  1139:      */     throws MobileApplicationException
/*  1140:      */   {
/*  1141: 1342 */     MobileMboDataBean woChildrenBean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*  1142: 1343 */     MobileMboDataBean woBean = DataBeanCache.getDataBean("WORKORDER_CHILDREN", "WORKORDER");
/*  1143: 1344 */     if (woBean != null)
/*  1144:      */     {
/*  1145: 1346 */       woBean.getQBE().setQBE("WONUM", woChildrenBean.getValue("WONUM"));
/*  1146: 1347 */       woBean.getQBE().setQBE("SITEID", woChildrenBean.getValue("SITEID"));
/*  1147: 1348 */       woBean.reset();
/*  1148: 1349 */       UIUtil.gotoPage(event.getValue().toString(), (AbstractMobileControl)event.getCreatingObject());
/*  1149:      */     }
/*  1150: 1351 */     return true;
/*  1151:      */   }
/*  1152:      */   
/*  1153:      */   public boolean initTKStatusesLookup(UIEvent event)
/*  1154:      */     throws MobileApplicationException
/*  1155:      */   {
/*  1156: 1361 */     String[] allStatusesMbos = { "SRSTATUS", "PROBLEMSTATUS", "INCIDENTSTATUS" };
/*  1157: 1362 */     return initAllValues(event, allStatusesMbos);
/*  1158:      */   }
/*  1159:      */   
/*  1160:      */   private boolean initAllValues(UIEvent event, String[] mbos)
/*  1161:      */     throws MobileApplicationException
/*  1162:      */   {
/*  1163: 1369 */     MobileMboDataBean lookupBean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*  1164: 1370 */     if (lookupBean.count() > 0) {
/*  1165: 1372 */       return true;
/*  1166:      */     }
/*  1167: 1375 */     Set statusSet = new HashSet();
/*  1168: 1376 */     for (int i = 0; i < mbos.length; i++)
/*  1169:      */     {
/*  1170: 1378 */       MobileMboDataBean dataBean = DataBeanCache.getDataBean(mbos[i], mbos[i]);
/*  1171: 1379 */       int j = 0;
/*  1172: 1380 */       MobileMbo mbo = dataBean.getMobileMbo(j);
/*  1173: 1381 */       while (mbo != null)
/*  1174:      */       {
/*  1175: 1384 */         statusSet.add(mbo.getValue("VALUE") + "|" + mbo.getValue("DESCRIPTION"));
/*  1176: 1385 */         mbo = dataBean.getMobileMbo(++j);
/*  1177:      */       }
/*  1178:      */     }
/*  1179: 1389 */     Iterator i = statusSet.iterator();
/*  1180: 1391 */     while (i.hasNext())
/*  1181:      */     {
/*  1182: 1393 */       String value = (String)i.next();
/*  1183: 1394 */       int index = value.indexOf("|");
/*  1184: 1395 */       lookupBean.insert();
/*  1185: 1396 */       lookupBean.setValue("VALUE", value.substring(0, index));
/*  1186: 1397 */       lookupBean.setValue("DESCRIPTION", value.substring(index + 1));
/*  1187:      */     }
/*  1188: 1400 */     lookupBean.getDataBeanManager().save();
/*  1189: 1401 */     return true;
/*  1190:      */   }
/*  1191:      */   
/*  1192:      */   public boolean deleteCrewMember(UIEvent event)
/*  1193:      */     throws MobileApplicationException
/*  1194:      */   {
/*  1195: 1406 */     MobileMboDataBean databean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*  1196: 1407 */     databean.deleteLocal();
/*  1197: 1408 */     databean.getDataBeanManager().save();
/*  1198: 1409 */     databean.reset();
/*  1199: 1410 */     UIUtil.refreshCurrentScreen();
/*  1200: 1411 */     return true;
/*  1201:      */   }
/*  1202:      */   
/*  1203:      */   protected boolean uploadpendingstatus(UIEvent event)
/*  1204:      */     throws MobileApplicationException
/*  1205:      */   {
/*  1206: 1416 */     if (event.getMsgResponse().equals("-1"))
/*  1207:      */     {
/*  1208: 1417 */       UIUtil.showOKCANCELMessageBox(event, MobileMessageGenerator.generate("confimtosendstatus", null));
/*  1209: 1418 */       return true;
/*  1210:      */     }
/*  1211: 1420 */     if (event.getMsgResponse().equals("1")) {
/*  1212: 1422 */       switch (event.getThreadStatus())
/*  1213:      */       {
/*  1214:      */       case -1: 
/*  1215: 1425 */         UIUtil.startWorkerThread(this, event);
/*  1216: 1426 */         break;
/*  1217:      */       case 1: 
/*  1218: 1429 */         doUploadPendingStatus(event);
/*  1219: 1430 */         break;
/*  1220:      */       case 2: 
/*  1221: 1433 */         UIUtil.refreshCurrentScreen();
/*  1222: 1434 */         break;
/*  1223:      */       case 0: 
/*  1224: 1436 */         UIUtil.refreshCurrentScreen();
/*  1225: 1437 */         break;
/*  1226:      */       case 3: 
/*  1227: 1439 */         UIUtil.refreshCurrentScreen();
/*  1228: 1440 */         if (isConnectException(event.getException()))
/*  1229:      */         {
/*  1230: 1441 */           UIUtil.showExceptionMessage(event.getException(), null, 0);
/*  1231:      */         }
/*  1232:      */         else
/*  1233:      */         {
/*  1234: 1443 */           UIUtil.showOKCANCELMessageBox(event, MobileMessageGenerator.generate("realstatuserrormessage", new Object[] { event.getException().getCompleteMessage() }));
/*  1235:      */           
/*  1236: 1445 */           event.setThreadStatus(-1);
/*  1237:      */         }
/*  1238:      */         break;
/*  1239:      */       }
/*  1240:      */     }
/*  1241: 1450 */     return true;
/*  1242:      */   }
/*  1243:      */   
/*  1244:      */   protected void doUploadPendingStatus(UIEvent event)
/*  1245:      */     throws MobileApplicationException
/*  1246:      */   {
/*  1247: 1456 */     MobileMboDataBeanManager mngr = new MobileMboDataBeanManager("PENDINGCHGSTATUS");
/*  1248: 1457 */     MobileMboDataBean pendingChanges = mngr.getDataBean();
/*  1249:      */     
/*  1250: 1459 */     ProgressObserver progress = event.getProgressObserver();
/*  1251: 1460 */     MobileWOWebServiceProxy service = (MobileWOWebServiceProxy)UIUtil.getApplication().getDefaultMobileWebServiceProxy();
/*  1252:      */     
/*  1253:      */ 
/*  1254: 1463 */     progress.setWorkProgressMessage(MobileMessageGenerator.generate("sendingstatus", null));
/*  1255: 1464 */     progress.updateWorkProgress();
/*  1256: 1465 */     int count = pendingChanges.count();
/*  1257: 1466 */     for (int i = 0; i < count; i++)
/*  1258:      */     {
/*  1259: 1467 */       MobileMbo current = pendingChanges.getMobileMbo(i);
/*  1260: 1468 */       String fieldName = getIdFieldName(current);
/*  1261: 1469 */       progress.setWorkProgressMessage(MobileMessageGenerator.generate("sendingstatusof", new Object[] { current.getValue(fieldName) }));
/*  1262:      */       
/*  1263: 1471 */       progress.updateWorkProgress();
/*  1264:      */       try
/*  1265:      */       {
/*  1266: 1473 */         if (fieldName.equalsIgnoreCase("wonum")) {
/*  1267: 1474 */           service.changeWOStatus(current.getValue(fieldName), current.getValue("SITEID"), current.getValue("CURRENTSTATUS"), current.getValue("NEWSTATUS"), current.getDateValue("STATUSDATE"), current.getValue("MEMO"));
/*  1268:      */         } else {
/*  1269: 1481 */           service.changeTKStatus(current.getValue(fieldName), current.getValue("MOBMBONAME"), current.getValue("CURRENTSTATUS"), current.getValue("NEWSTATUS"), current.getDateValue("STATUSDATE"), current.getValue("MEMO"));
/*  1270:      */         }
/*  1271: 1488 */         progress.updateWorkProgress();
/*  1272:      */         
/*  1273: 1490 */         updateOriginalRecord(current, fieldName);
/*  1274: 1491 */         current.delete();
/*  1275: 1492 */         current.deleteLocal();
/*  1276:      */       }
/*  1277:      */       catch (MobileApplicationException e)
/*  1278:      */       {
/*  1279: 1494 */         if (!isConnectException(e))
/*  1280:      */         {
/*  1281: 1495 */           current.delete();
/*  1282: 1496 */           current.deleteLocal();
/*  1283:      */         }
/*  1284: 1498 */         mngr.save();
/*  1285: 1499 */         throw e;
/*  1286:      */       }
/*  1287: 1502 */       progress.updateWorkProgress();
/*  1288:      */     }
/*  1289: 1504 */     mngr.save();
/*  1290:      */   }
/*  1291:      */   
/*  1292:      */   private String getIdFieldName(MobileMbo current)
/*  1293:      */     throws MobileApplicationException
/*  1294:      */   {
/*  1295: 1509 */     return current.isNull("WONUM") ? "TICKETID" : "WONUM";
/*  1296:      */   }
/*  1297:      */   
/*  1298:      */   private void updateOriginalRecord(MobileMbo current, String fieldName)
/*  1299:      */     throws MobileApplicationException
/*  1300:      */   {
/*  1301: 1514 */     MobileMboDataBeanManager manager = new MobileMboDataBeanManager(getMobileMboName(current.getValue("MOBMBONAME")));
/*  1302: 1515 */     MobileMboDataBean bean = manager.getDataBean();
/*  1303:      */     
/*  1304: 1517 */     bean.getQBE().setQBE(fieldName, current.getValue(fieldName));
/*  1305: 1518 */     bean.getQBE().setQBE("SITEID", current.getValue("SITEID"));
/*  1306: 1519 */     bean.reset();
/*  1307: 1520 */     MobileMbo record = bean.getMobileMbo();
/*  1308: 1521 */     if (record != null)
/*  1309:      */     {
/*  1310: 1522 */       cleanupLocalStatusChangeValues(record);
/*  1311: 1523 */       if (fieldName.equalsIgnoreCase("wonum"))
/*  1312:      */       {
/*  1313: 1524 */         cleanupLocalStatusChangeValuesForDepedendent(current, bean.getDataBean("WOCHILDREN"));
/*  1314: 1525 */         cleanupLocalStatusChangeValuesForDepedendent(current, bean.getDataBean("WOTASKS"));
/*  1315:      */         
/*  1316: 1527 */         cleanupLocalStatusHistory(current, bean.getDataBean("WOSTATUSHIST"));
/*  1317:      */       }
/*  1318:      */       else
/*  1319:      */       {
/*  1320: 1530 */         cleanupLocalStatusHistory(current, bean.getDataBean("TKSTATUSHIST"));
/*  1321:      */       }
/*  1322:      */     }
/*  1323: 1535 */     manager.save();
/*  1324:      */   }
/*  1325:      */   
/*  1326:      */   private void cleanupLocalStatusHistory(MobileMbo statusChangeInfo, MobileMboDataBean historyBean)
/*  1327:      */     throws MobileApplicationException
/*  1328:      */   {
/*  1329: 1539 */     if (historyBean != null)
/*  1330:      */     {
/*  1331: 1540 */       MobileMbo mbo = historyBean.getMobileMbo();
/*  1332: 1541 */       if (mbo != null) {
/*  1333: 1542 */         historyBean.deleteLocal();
/*  1334:      */       }
/*  1335:      */     }
/*  1336:      */   }
/*  1337:      */   
/*  1338:      */   private void cleanupLocalStatusChangeValuesForDepedendent(MobileMbo statusChangeInfo, MobileMboDataBean dataBean)
/*  1339:      */     throws MobileApplicationException
/*  1340:      */   {
/*  1341: 1548 */     if (dataBean != null) {
/*  1342: 1549 */       for (int i = 0; i < dataBean.count(); i++)
/*  1343:      */       {
/*  1344: 1550 */         cleanupLocalStatusChangeValues(dataBean.getMobileMbo(i));
/*  1345:      */         
/*  1346: 1552 */         cleanupLocalStatusHistory(statusChangeInfo, dataBean.getDataBean("WOSTATUSHIST"));
/*  1347:      */       }
/*  1348:      */     }
/*  1349:      */   }
/*  1350:      */   
/*  1351:      */   private void cleanupLocalStatusChangeValues(MobileMbo mobileMbo)
/*  1352:      */     throws MobileApplicationException
/*  1353:      */   {
/*  1354:      */     try
/*  1355:      */     {
/*  1356: 1558 */       mobileMbo.changeOriginalValue("STATUS", mobileMbo.getValue("NEWSTATUSDISPLAY"));
/*  1357: 1559 */       mobileMbo.changeOriginalDateValue("STATUSDATE", mobileMbo.getDateValue("NEWSTATUSASOFDATE"));
/*  1358:      */     }
/*  1359:      */     catch (MobileApplicationException e)
/*  1360:      */     {
/*  1361: 1564 */       MobileLoggerFactory.getLogger("maximo.mobile.persistence").info("Could not override original status", e);
/*  1362:      */     }
/*  1363: 1566 */     mobileMbo.setValue("NEWSTATUS", "A");
/*  1364: 1567 */     mobileMbo.setValue("NEWSTATUS", "");
/*  1365: 1569 */     if (mobileMbo.getMobileMboInfo().getAttributeInfo("CHANGEDATE") != null) {
/*  1366: 1570 */       mobileMbo.setDateValue("CHANGEDATE", CurrentTimeProvider.getInstance().getCurrentTime());
/*  1367:      */     }
/*  1368:      */   }
/*  1369:      */   
/*  1370:      */   private String getMobileMboName(String value)
/*  1371:      */   {
/*  1372: 1575 */     return value.equalsIgnoreCase("WORKORDER") ? "WORKORDER" : "TICKET";
/*  1373:      */   }
/*  1374:      */   
/*  1375:      */   private boolean isConnectException(MobileApplicationException e)
/*  1376:      */   {
/*  1377: 1580 */     return e.getNestedException() instanceof ConnectException;
/*  1378:      */   }
/*  1379:      */   
/*  1380:      */   protected boolean haspendingstatuschange(UIEvent event)
/*  1381:      */     throws MobileApplicationException
/*  1382:      */   {
/*  1383: 1585 */     boolean visibility = new MobileMboDataBeanManager("PENDINGCHGSTATUS").getDataBean().count() > 0;
/*  1384: 1586 */     ((AbstractMobileControl)event.getCreatingObject()).setVisibility(visibility);
/*  1385: 1587 */     return true;
/*  1386:      */   }
/*  1387:      */   
/*  1388:      */   public boolean isDataRefreshed()
/*  1389:      */     throws MobileApplicationException
/*  1390:      */   {
/*  1391: 1593 */     boolean ret = true;
/*  1392:      */     
/*  1393: 1595 */     MobileDeviceAppSession deviceAppSession = MobileDeviceAppSession.getSession();
/*  1394: 1596 */     BasicMobileDeviceUIApplication app = deviceAppSession.getApplicationAsUIApplication();
/*  1395: 1598 */     if (!app.isAllDataRefreshedOnce())
/*  1396:      */     {
/*  1397: 1600 */       ret = false;
/*  1398: 1601 */       UIUtil.handleEvent("refreshalldataonce");
/*  1399:      */     }
/*  1400: 1604 */     return ret;
/*  1401:      */   }
/*  1402:      */   
/*  1403:      */   public boolean refreshwos(UIEvent event)
/*  1404:      */     throws MobileApplicationException
/*  1405:      */   {
/*  1406: 1609 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/*  1407: 1610 */     if (databean != null) {
/*  1408: 1613 */       if (databean.isFiltered())
/*  1409:      */       {
/*  1410: 1615 */         String assetNum = databean.getQBE().getQBE("ASSETNUM");
/*  1411: 1616 */         String location = databean.getQBE().getQBE("LOCATION");
/*  1412: 1617 */         if ((assetNum != null) || (location != null))
/*  1413:      */         {
/*  1414: 1619 */           StringBuffer recordNum = new StringBuffer();
/*  1415:      */           
/*  1416: 1621 */           String womulti = queryMultiAssetLocCITable("WOMULTIASSETLOCCI", assetNum, location);
/*  1417: 1622 */           String tkmulti = queryMultiAssetLocCITable("TKMULTIASSETLOCCI", assetNum, location);
/*  1418: 1623 */           recordNum.append(womulti).append(tkmulti);
/*  1419: 1624 */           String recordNums = recordNum.toString().trim().length() > 0 ? recordNum.substring(0, recordNum.length() - 1) : null;
/*  1420: 1625 */           if (recordNums != null)
/*  1421:      */           {
/*  1422: 1630 */             databean.getQBE().setQBE("ASSETNUM", null);
/*  1423: 1631 */             databean.getQBE().setQBE("LOCATION", null);
/*  1424: 1632 */             databean.getQBE().setQBE("_RECID", recordNums);
/*  1425:      */             
/*  1426: 1634 */             databean.reset();
/*  1427:      */             
/*  1428:      */ 
/*  1429: 1637 */             databean.getQBE().setQBE("ASSETNUM", assetNum);
/*  1430: 1638 */             databean.getQBE().setQBE("LOCATION", location);
/*  1431:      */           }
/*  1432:      */           else
/*  1433:      */           {
/*  1434: 1644 */             databean.reset();
/*  1435:      */           }
/*  1436:      */         }
/*  1437:      */       }
/*  1438:      */       else
/*  1439:      */       {
/*  1440: 1658 */         String id = databean.getValue("_ID");
/*  1441: 1659 */         databean.reset();
/*  1442: 1660 */         for (int i = 0; i < databean.count(); i++) {
/*  1443: 1662 */           if (id.equals(databean.getValue(i, "_ID")))
/*  1444:      */           {
/*  1445: 1664 */             databean.setCurrentPosition(i);
/*  1446: 1665 */             break;
/*  1447:      */           }
/*  1448:      */         }
/*  1449:      */       }
/*  1450:      */     }
/*  1451: 1671 */     DataBeanCache.removeDataBean("PLUSCWODS");
/*  1452:      */     
/*  1453:      */ 
/*  1454: 1674 */     return true;
/*  1455:      */   }
/*  1456:      */   
/*  1457:      */   private String queryMultiAssetLocCITable(String mboName, String assetNum, String location)
/*  1458:      */     throws MobileApplicationException, RDOException
/*  1459:      */   {
/*  1460: 1681 */     StringBuffer recordNum = new StringBuffer();
/*  1461: 1682 */     MobileMboDataBeanManager mgr = new MobileMboDataBeanManager(mboName);
/*  1462: 1683 */     MobileMboDataBean multibean = mgr.getDataBean();
/*  1463:      */     
/*  1464: 1685 */     MobileMboQBE woqbe = multibean.getQBE();
/*  1465: 1686 */     woqbe.reset();
/*  1466: 1687 */     woqbe.setQbeExactMatch(true);
/*  1467: 1688 */     woqbe.setQBE("ASSETNUM", assetNum);
/*  1468: 1689 */     woqbe.setQBE("LOCATION", location);
/*  1469: 1690 */     multibean.reset();
/*  1470: 1691 */     int count = multibean.count();
/*  1471: 1692 */     Set nums = new HashSet();
/*  1472:      */     Iterator it;
/*  1473: 1693 */     if (count > 0)
/*  1474:      */     {
/*  1475: 1695 */       for (int i = 0; i < count; i++)
/*  1476:      */       {
/*  1477: 1698 */         long parentId = multibean.getMobileMbo(i).getLongValue("_PARENTID");
/*  1478: 1699 */         nums.add(new Long(parentId).toString());
/*  1479:      */       }
/*  1480: 1701 */       for (it = nums.iterator(); it.hasNext();)
/*  1481:      */       {
/*  1482: 1703 */         String num = (String)it.next();
/*  1483:      */         
/*  1484: 1705 */         recordNum.append(num).append(";");
/*  1485:      */       }
/*  1486:      */     }
/*  1487: 1708 */     return recordNum.toString();
/*  1488:      */   }
/*  1489:      */   
/*  1490:      */   public boolean insertworkorder(UIEvent event, String woclass)
/*  1491:      */     throws MobileApplicationException
/*  1492:      */   {
/*  1493: 1713 */     MobileMboDataBean databean = getCachedDataBean("WORKORDER");
/*  1494:      */     
/*  1495: 1715 */     Date createDate = databean.getCurrentTime();
/*  1496:      */     
/*  1497:      */ 
/*  1498: 1718 */     String msg = AutoKeyGenerator.generateKey("WORKORDER", "WONUM");
/*  1499:      */     
/*  1500: 1720 */     databean.insert();
/*  1501:      */     
/*  1502: 1722 */     databean.setValue("WONUM", msg);
/*  1503: 1723 */     databean.setValue("STATUS", ((WOApp)UIUtil.getApplication()).getDefaultValue(databean, "WOSTATUS", "WAPPR"));
/*  1504:      */     
/*  1505: 1725 */     databean.setValue("WOCLASS", ((WOApp)UIUtil.getApplication()).getDefaultValue(databean, "WOCLASS", woclass));
/*  1506:      */     
/*  1507: 1727 */     databean.setValue("ESTDUR", "0");
/*  1508: 1728 */     databean.getMobileMbo().setDateValue("STATUSDATE", createDate);
/*  1509: 1729 */     databean.getMobileMbo().setDateValue("REPORTDATE", createDate);
/*  1510: 1730 */     databean.getMobileMbo().setDateValue("CHANGEDATE", createDate);
/*  1511: 1731 */     databean.getMobileMbo().setValue("WOACCEPTSCHARGES", "1");
/*  1512: 1732 */     databean.getMobileMbo().setValue("HISTORYFLAG", "0");
/*  1513: 1733 */     databean.getMobileMbo().setBooleanValue("WOISSWAP", false);
/*  1514:      */     
/*  1515:      */ 
/*  1516: 1736 */     databean.getMobileMbo().setValue("REPORTEDBY", UIUtil.getApplication().getCurrentUser().toUpperCase());
/*  1517:      */     
/*  1518:      */ 
/*  1519: 1739 */     MobileMboDataBean histbean = databean.getDataBean("WOSTATUSHIST");
/*  1520: 1740 */     if (histbean != null)
/*  1521:      */     {
/*  1522: 1742 */       histbean.insert();
/*  1523: 1743 */       histbean.setValue("CHANGEBY", WOApp.getUsersPersonId());
/*  1524: 1744 */       histbean.getMobileMbo().setDateValue("CHANGEDATE", createDate);
/*  1525: 1745 */       histbean.setValue("ORGID", databean.getValue("ORGID"));
/*  1526: 1746 */       histbean.setValue("SITEID", databean.getValue("SITEID"));
/*  1527: 1747 */       histbean.setValue("STATUS", ((WOApp)UIUtil.getApplication()).getDefaultValue(databean, "WOSTATUS", "WAPPR"));
/*  1528:      */     }
/*  1529: 1750 */     databean.getDataBeanManager().save();
/*  1530:      */     
/*  1531: 1752 */     long id = databean.getMobileMbo().getId();
/*  1532:      */     
/*  1533:      */ 
/*  1534: 1755 */     UIUtil.getApplication().getScreen("woresults").refresh(null);
/*  1535: 1756 */     UIUtil.enableMenu(true);
/*  1536:      */     
/*  1537:      */ 
/*  1538: 1759 */     databean.getQBE().reset();
/*  1539: 1760 */     databean.getQBE().setQBE("_ID", "" + id);
/*  1540: 1761 */     databean.reset();
/*  1541: 1762 */     databean.getMobileMbo();
/*  1542:      */     
/*  1543: 1764 */     return true;
/*  1544:      */   }
/*  1545:      */   
/*  1546:      */   public boolean insertticket(UIEvent event, String tkclass)
/*  1547:      */     throws MobileApplicationException
/*  1548:      */   {
/*  1549: 1769 */     MobileMboDataBean databean = getCachedDataBean("TICKET");
/*  1550:      */     
/*  1551: 1771 */     Date createDate = databean.getCurrentTime();
/*  1552:      */     
/*  1553:      */ 
/*  1554: 1774 */     String msg = AutoKeyGenerator.generateKey("TICKET", "TICKETID");
/*  1555:      */     
/*  1556: 1776 */     databean.insert();
/*  1557:      */     
/*  1558: 1778 */     databean.setValue("TICKETID", msg);
/*  1559:      */     
/*  1560: 1780 */     databean.setValue("TICKETUID", databean.getValue("_ID"));
/*  1561: 1781 */     String statusdomain = "";
/*  1562: 1783 */     if (tkclass.equalsIgnoreCase("SR")) {
/*  1563: 1784 */       statusdomain = "SRSTATUS";
/*  1564: 1785 */     } else if (tkclass.equalsIgnoreCase("INCIDENT")) {
/*  1565: 1786 */       statusdomain = "INCIDENTSTATUS";
/*  1566: 1787 */     } else if (tkclass.equalsIgnoreCase("PROBLEM")) {
/*  1567: 1788 */       statusdomain = "PROBLEMSTATUS";
/*  1568:      */     }
/*  1569: 1790 */     databean.setValue("STATUS", ((WOApp)UIUtil.getApplication()).getDefaultValue(databean, statusdomain, "NEW"));
/*  1570:      */     
/*  1571: 1792 */     databean.setValue("CLASS", ((WOApp)UIUtil.getApplication()).getDefaultValue(databean, "TKCLASS", tkclass));
/*  1572:      */     
/*  1573: 1794 */     databean.getMobileMbo().setDateValue("STATUSDATE", createDate);
/*  1574: 1795 */     databean.getMobileMbo().setDateValue("REPORTDATE", createDate);
/*  1575: 1796 */     databean.getMobileMbo().setDateValue("CHANGEDATE", createDate);
/*  1576: 1797 */     databean.getMobileMbo().setValue("HISTORYFLAG", "0");
/*  1577:      */     
/*  1578:      */ 
/*  1579:      */ 
/*  1580:      */ 
/*  1581:      */ 
/*  1582:      */ 
/*  1583: 1804 */     MobileMboDataBean histbean = databean.getDataBean("TKSTATUSHIST");
/*  1584: 1805 */     if (histbean != null)
/*  1585:      */     {
/*  1586: 1807 */       histbean.insert();
/*  1587: 1808 */       histbean.setValue("CHANGEBY", WOApp.getUsersPersonId());
/*  1588: 1809 */       histbean.getMobileMbo().setDateValue("CHANGEDATE", createDate);
/*  1589: 1810 */       histbean.setValue("ORGID", databean.getValue("ORGID"));
/*  1590: 1811 */       histbean.setValue("SITEID", databean.getValue("SITEID"));
/*  1591:      */       
/*  1592:      */ 
/*  1593: 1814 */       histbean.setValue("STATUS", databean.getValue("STATUS"));
/*  1594:      */     }
/*  1595: 1819 */     databean.getDataBeanManager().save();
/*  1596:      */     
/*  1597:      */ 
/*  1598: 1822 */     UIUtil.getApplication().getScreen("woresults").refresh(null);
/*  1599: 1823 */     UIUtil.enableMenu(true);
/*  1600:      */     
/*  1601: 1825 */     return true;
/*  1602:      */   }
/*  1603:      */   
/*  1604:      */   public boolean caninserttask(UIEvent event)
/*  1605:      */     throws MobileApplicationException
/*  1606:      */   {
/*  1607: 1831 */     MobileMboDataBean wodatabean = UIUtil.getCurrentScreen().getDataBean();
/*  1608: 1833 */     if ((wodatabean != null) && (wodatabean.getName().equals("WORKORDER")))
/*  1609:      */     {
/*  1610: 1835 */       boolean bShow = true;
/*  1611: 1836 */       if (wodatabean.getValue("HISTORYFLAG").equals("1")) {
/*  1612: 1837 */         bShow = false;
/*  1613:      */       }
/*  1614: 1839 */       ((AbstractMobileControl)event.getCreatingObject()).setVisibility(bShow);
/*  1615:      */     }
/*  1616: 1841 */     return true;
/*  1617:      */   }
/*  1618:      */   
/*  1619:      */   public boolean inserttask(UIEvent event)
/*  1620:      */     throws MobileApplicationException
/*  1621:      */   {
/*  1622: 1846 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/*  1623: 1847 */     if (databean != null) {
/*  1624: 1849 */       if (databean.getName().equals("WOTASKS"))
/*  1625:      */       {
/*  1626: 1851 */         databean.insert(databean.getCurrentSize());
/*  1627: 1852 */         databean.getMobileMbo().setReadOnly("MEASUREMENTVALUE", true);
/*  1628: 1853 */         databean.getMobileMbo().setReadOnly("MEASUREDATE", true);
/*  1629:      */         
/*  1630:      */ 
/*  1631: 1856 */         int maxTask = 0;
/*  1632: 1857 */         for (int i = 0; i < databean.count(); i++) {
/*  1633: 1859 */           if ((!databean.getMobileMbo(i).isNull("TASKID")) && (!databean.getMobileMbo(i).getValue("TASKID").equals("")))
/*  1634:      */           {
/*  1635: 1862 */             int thisTask = new Integer(databean.getMobileMbo(i).getValue("TASKID")).intValue();
/*  1636: 1863 */             if (thisTask > maxTask) {
/*  1637: 1865 */               maxTask = thisTask;
/*  1638:      */             }
/*  1639:      */           }
/*  1640:      */         }
/*  1641: 1868 */         int taskid = getNextTaskID(maxTask, "TASKSEED", "TASKINTERVAL", databean);
/*  1642: 1869 */         databean.setValue("TASKID", "" + taskid);
/*  1643:      */         
/*  1644: 1871 */         databean.setValue("STATUS", ((WOApp)UIUtil.getApplication()).getDefaultValue(databean, "WOSTATUS", "WAPPR"));
/*  1645:      */         
/*  1646:      */ 
/*  1647: 1874 */         databean.getMobileMbo().setDateValue("STATUSDATE", databean.getCurrentTime(), false);
/*  1648: 1878 */         if (databean.getParentBean() != null) {
/*  1649: 1880 */           databean.getMobileMbo().setValue("WOACCEPTSCHARGES", databean.getParentBean().getValue("WOACCEPTSCHARGES"));
/*  1650:      */         }
/*  1651: 1884 */         databean.setValue("PARENTCHGSSTATUS", "1");
/*  1652:      */         
/*  1653:      */ 
/*  1654:      */ 
/*  1655: 1888 */         MobileMboDataBean parentwo = databean.getParentBean();
/*  1656: 1889 */         if (parentwo != null)
/*  1657:      */         {
/*  1658: 1891 */           MobileMbo parentmbo = parentwo.getMobileMbo();
/*  1659: 1892 */           if (parentmbo != null)
/*  1660:      */           {
/*  1661: 1894 */             databean.getMobileMbo().setDateValue("SCHEDSTART", parentmbo.getDateValue("SCHEDSTART"));
/*  1662: 1895 */             databean.getMobileMbo().setDateValue("SCHEDFINISH", parentmbo.getDateValue("SCHEDFINISH"));
/*  1663: 1896 */             databean.getMobileMbo().setDateValue("TARGSTARTDATE", parentmbo.getDateValue("TARGSTARTDATE"));
/*  1664: 1897 */             databean.getMobileMbo().setDateValue("TARGCOMPDATE", parentmbo.getDateValue("TARGCOMPDATE"));
/*  1665:      */           }
/*  1666:      */         }
/*  1667: 1902 */         MobileMboDataBean histbean = databean.getDataBean("WOTASKSTATUSHIST");
/*  1668: 1903 */         if (histbean != null)
/*  1669:      */         {
/*  1670: 1905 */           histbean.insert();
/*  1671: 1906 */           histbean.setValue("CHANGEBY", WOApp.getUsersPersonId());
/*  1672: 1907 */           histbean.getMobileMbo().setDateValue("CHANGEDATE", databean.getCurrentTime());
/*  1673: 1908 */           histbean.setValue("ORGID", databean.getValue("ORGID"));
/*  1674: 1909 */           histbean.setValue("SITEID", databean.getValue("SITEID"));
/*  1675: 1910 */           histbean.setValue("STATUS", ((WOApp)UIUtil.getApplication()).getDefaultValue(databean, "WOSTATUS", "WAPPR"));
/*  1676:      */         }
/*  1677: 1913 */         UIUtil.refreshCurrentScreen();
/*  1678: 1914 */         return true;
/*  1679:      */       }
/*  1680:      */     }
/*  1681: 1917 */     return false;
/*  1682:      */   }
/*  1683:      */   
/*  1684:      */   public boolean createfollowupwo(UIEvent event)
/*  1685:      */     throws MobileApplicationException
/*  1686:      */   {
/*  1687: 1922 */     createfollowupworkorder(event, "WORKORDER");
/*  1688: 1923 */     return showMainPage(event, "WORKORDER");
/*  1689:      */   }
/*  1690:      */   
/*  1691:      */   public boolean createfollowupchange(UIEvent event)
/*  1692:      */     throws MobileApplicationException
/*  1693:      */   {
/*  1694: 1928 */     createfollowupworkorder(event, "CHANGE");
/*  1695: 1929 */     return showMainPage(event, "CHANGE");
/*  1696:      */   }
/*  1697:      */   
/*  1698:      */   public boolean createfollowuprelease(UIEvent event)
/*  1699:      */     throws MobileApplicationException
/*  1700:      */   {
/*  1701: 1934 */     createfollowupworkorder(event, "RELEASE");
/*  1702: 1935 */     return showMainPage(event, "RELEASE");
/*  1703:      */   }
/*  1704:      */   
/*  1705:      */   public boolean createfollowupworkorder(UIEvent event, String internalWOClass)
/*  1706:      */     throws MobileApplicationException
/*  1707:      */   {
/*  1708: 1941 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/*  1709:      */     
/*  1710: 1943 */     String newwoclass = ((WOApp)UIUtil.getApplication()).getExternalValue(databean, "WOCLASS", internalWOClass);
/*  1711: 1949 */     if ((databean != null) && (databean.getName().equals("PLUSCWODS"))) {
/*  1712: 1950 */       setCurrentScreenDataSrc(databean.getParentBean().getName());
/*  1713:      */     }
/*  1714: 1954 */     WOApp app = (WOApp)UIUtil.getApplication();
/*  1715:      */     
/*  1716:      */ 
/*  1717: 1957 */     MobileMbo origrec = databean.getMobileMbo();
/*  1718:      */     
/*  1719: 1959 */     Date createDate = databean.getCurrentTime();
/*  1720:      */     
/*  1721: 1961 */     MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager("WORKORDER");
/*  1722: 1962 */     MobileMboDataBean newWOBean = mgrDBMgr.getDataBean();
/*  1723:      */     
/*  1724:      */ 
/*  1725: 1965 */     String msg = AutoKeyGenerator.generateKey("WORKORDER", "WONUM");
/*  1726: 1966 */     newWOBean.insert();
/*  1727:      */     
/*  1728: 1968 */     newWOBean.setValue("WONUM", msg);
/*  1729: 1969 */     newWOBean.setValue("WOCLASS", newwoclass);
/*  1730: 1970 */     newWOBean.setValue("STATUS", app.getDefaultValue(databean, "WOSTATUS", "WAPPR"));
/*  1731:      */     
/*  1732: 1972 */     newWOBean.setValue("ESTDUR", "0");
/*  1733: 1973 */     newWOBean.getMobileMbo().setDateValue("STATUSDATE", createDate);
/*  1734: 1974 */     newWOBean.getMobileMbo().setDateValue("REPORTDATE", createDate);
/*  1735: 1975 */     newWOBean.getMobileMbo().setDateValue("CHANGEDATE", createDate);
/*  1736: 1977 */     if (databean.getName().equalsIgnoreCase("WORKORDER"))
/*  1737:      */     {
/*  1738: 1987 */       newWOBean.setValue("ORIGRECORDCLASS", origrec.getValue("WOCLASS"));
/*  1739: 1988 */       newWOBean.setValue("ORIGRECORDID", origrec.getValue("WONUM"));
/*  1740:      */       
/*  1741: 1990 */       newWOBean.setValue("DESCRIPTION", origrec.getValue("DESCRIPTION"));
/*  1742: 1991 */       newWOBean.setValue("DESCRIPTION_LONGDESCRIPTION", origrec.getValue("DESCRIPTION_LONGDESCRIPTION"));
/*  1743: 1992 */       newWOBean.setValue("ASSETNUM", origrec.getValue("ASSETNUM"));
/*  1744: 1993 */       newWOBean.setValue("LOCATION", origrec.getValue("LOCATION"));
/*  1745: 1994 */       newWOBean.setValue("WOPRIORITY", origrec.getValue("WOPRIORITY"));
/*  1746: 1995 */       newWOBean.setValue("REPORTEDBY", origrec.getValue("REPORTEDBY"));
/*  1747: 1996 */       newWOBean.setValue("PHONE", origrec.getValue("PHONE"));
/*  1748: 1997 */       newWOBean.setValue("INTERRUPTIBLE", origrec.getValue("INTERRUPTIBLE"));
/*  1749: 1998 */       newWOBean.setValue("FAILURECODE", origrec.getValue("FAILURECODE"));
/*  1750: 1999 */       newWOBean.setValue("ORGID", origrec.getValue("ORGID"));
/*  1751: 2000 */       newWOBean.setValue("SITEID", origrec.getValue("SITEID"));
/*  1752: 2001 */       newWOBean.setValue("ONBEHALFOF", origrec.getValue("ONBEHALFOF"));
/*  1753: 2002 */       newWOBean.setValue("JUSTIFYPRIORITY", origrec.getValue("JUSTIFYPRIORITY"));
/*  1754: 2003 */       newWOBean.setValue("JUSTIFYPRIORITY_LONGDESCRIPTION", origrec.getValue("JUSTIFYPRIORITY_LONGDESCRIPTION"));
/*  1755: 2004 */       newWOBean.setValue("BACKOUTPLAN", origrec.getValue("BACKOUTPLAN"));
/*  1756: 2005 */       newWOBean.setValue("BACKOUTPLAN_LONGDESCRIPTION", origrec.getValue("BACKOUTPLAN_LONGDESCRIPTION"));
/*  1757: 2006 */       newWOBean.setValue("PERSONGROUP", origrec.getValue("PERSONGROUP"));
/*  1758: 2007 */       newWOBean.setValue("OWNER", origrec.getValue("OWNER"));
/*  1759: 2008 */       newWOBean.setValue("OWNERGROUP", origrec.getValue("OWNERGROUP"));
/*  1760: 2009 */       newWOBean.setValue("NEWOWNER", origrec.getValue("OWNER"));
/*  1761: 2010 */       newWOBean.setValue("NEWOWNERGROUP", origrec.getValue("OWNERGROUP"));
/*  1762: 2011 */       newWOBean.setValue("COMMODITYGROUP", origrec.getValue("COMMODITYGROUP"));
/*  1763: 2012 */       newWOBean.setValue("COMMODITY", origrec.getValue("COMMODITY"));
/*  1764: 2013 */       newWOBean.setValue("SUPERVISOR", origrec.getValue("SUPERVISOR"));
/*  1765: 2015 */       if (origrec.getValue("WOCLASS").equalsIgnoreCase(newWOBean.getValue("WOCLASS"))) {
/*  1766: 2017 */         newWOBean.setValue("WORKTYPE", origrec.getValue("WORKTYPE"));
/*  1767:      */       } else {
/*  1768: 2019 */         newWOBean.setValue("WORKTYPE", "");
/*  1769:      */       }
/*  1770: 2021 */       newWOBean.setValue("CLASSSTRUCTUREID", origrec.getValue("CLASSSTRUCTUREID"));
/*  1771: 2022 */       newWOBean.setValue("CLASSSTRUCTURE_HIERARCHYPATH", origrec.getValue("CLASSSTRUCTURE_HIERARCHYPATH"));
/*  1772: 2023 */       newWOBean.setValue("CLASSSTRUCTURE_DESCRIPTION", origrec.getValue("CLASSSTRUCTURE_DESCRIPTION"));
/*  1773: 2024 */       newWOBean.setValue("GLACCOUNT", origrec.getValue("GLACCOUNT"));
/*  1774:      */       
/*  1775: 2026 */       newWOBean.setValue("PARENTCHGSSTATUS", "1");
/*  1776:      */       
/*  1777:      */ 
/*  1778: 2029 */       newWOBean.setValue("WOACCEPTSCHARGES", "1");
/*  1779:      */       
/*  1780:      */ 
/*  1781: 2032 */       createSpecRecords(origrec, newWOBean, databean);
/*  1782:      */       
/*  1783:      */ 
/*  1784:      */ 
/*  1785: 2036 */       MobileMboDataBean fromMultiBean = databean.getDataBean("WOMULTIASSETLOCCI");
/*  1786: 2037 */       MobileMboDataBean toMultiBean = newWOBean.getDataBean("WOMULTIASSETLOCCI");
/*  1787: 2038 */       fromMultiBean.getQBE().reset();
/*  1788: 2039 */       fromMultiBean.reset();
/*  1789: 2040 */       int count = fromMultiBean.count();
/*  1790: 2041 */       for (int i = 0; i < count; i++)
/*  1791:      */       {
/*  1792: 2043 */         toMultiBean.insert();
/*  1793:      */         
/*  1794: 2045 */         MobileMbo fromMbo = fromMultiBean.getMobileMbo(i);
/*  1795: 2046 */         MobileMbo newMbo = toMultiBean.getMobileMbo();
/*  1796:      */         
/*  1797: 2048 */         fromMbo.copyAttributeValue(newMbo, "ASSETNUM");
/*  1798: 2049 */         fromMbo.copyAttributeValue(newMbo, "LOCATION");
/*  1799: 2050 */         fromMbo.copyAttributeValue(newMbo, "CINUM");
/*  1800: 2051 */         fromMbo.copyAttributeValue(newMbo, "TARGETDESC");
/*  1801: 2052 */         fromMbo.copyAttributeValue(newMbo, "TARGETDESC_LONGDESCRIPTION");
/*  1802: 2053 */         fromMbo.copyAttributeValue(newMbo, "ISPRIMARY");
/*  1803: 2054 */         fromMbo.copyAttributeValue(newMbo, "SEQUENCE");
/*  1804: 2055 */         fromMbo.copyAttributeValue(newMbo, "ORGID");
/*  1805: 2056 */         fromMbo.copyAttributeValue(newMbo, "SITEID");
/*  1806: 2057 */         fromMbo.copyAttributeValue(newMbo, "WORKORGID");
/*  1807: 2058 */         fromMbo.copyAttributeValue(newMbo, "WORKSITEID");
/*  1808: 2059 */         newMbo.setValue("RECORDCLASS", newwoclass);
/*  1809: 2060 */         newMbo.setValue("RECORDKEY", msg);
/*  1810:      */         
/*  1811: 2062 */         toMultiBean.setValue("COPIED", "1");
/*  1812:      */         
/*  1813:      */ 
/*  1814: 2065 */         processLinearDetails(newMbo, fromMbo, fromMbo.getValue("ASSETNUM"), fromMbo.getValue("SITEID"));
/*  1815:      */       }
/*  1816: 2068 */       toMultiBean.getDataBeanManager().save();
/*  1817:      */     }
/*  1818: 2073 */     else if (databean.getName().equalsIgnoreCase("TICKET"))
/*  1819:      */     {
/*  1820: 2083 */       newWOBean.setValue("ORIGRECORDCLASS", origrec.getValue("CLASS"));
/*  1821: 2084 */       newWOBean.setValue("ORIGRECORDID", origrec.getValue("TICKETID"));
/*  1822:      */       
/*  1823: 2086 */       newWOBean.setValue("DESCRIPTION", origrec.getValue("DESCRIPTION"));
/*  1824: 2087 */       newWOBean.setValue("DESCRIPTION_LONGDESCRIPTION", origrec.getValue("DESCRIPTION_LONGDESCRIPTION"));
/*  1825: 2088 */       newWOBean.setValue("WOPRIORITY", origrec.getValue("INTERNALPRIORITY"));
/*  1826: 2089 */       newWOBean.setValue("REPORTEDBY", origrec.getValue("REPORTEDBY"));
/*  1827: 2090 */       newWOBean.setValue("PHONE", origrec.getValue("REPORTEDPHONE"));
/*  1828: 2091 */       newWOBean.setValue("ONBEHALFOF", origrec.getValue("AFFECTEDPERSONID"));
/*  1829: 2092 */       newWOBean.setValue("ASSETNUM", origrec.getValue("ASSETNUM"));
/*  1830: 2093 */       newWOBean.setValue("LOCATION", origrec.getValue("LOCATION"));
/*  1831: 2094 */       newWOBean.setValue("GLACCOUNT", origrec.getValue("GLACCOUNT"));
/*  1832: 2095 */       newWOBean.setValue("COMMODITYGROUP", origrec.getValue("COMMODITYGROUP"));
/*  1833: 2096 */       newWOBean.setValue("COMMODITY", origrec.getValue("COMMODITY"));
/*  1834:      */       
/*  1835:      */ 
/*  1836: 2099 */       newWOBean.setValue("CLASSSTRUCTUREID", origrec.getValue("CLASSSTRUCTUREID"));
/*  1837: 2100 */       createSpecRecords(origrec, newWOBean, databean);
/*  1838:      */       
/*  1839:      */ 
/*  1840: 2103 */       String createWOMulti = ((WOApp)UIUtil.getApplication()).getInternalValue(databean, "CREATEWOMULTI", origrec.getValue("CREATEWOMULTI"));
/*  1841: 2106 */       if (createWOMulti.equalsIgnoreCase("CHILD"))
/*  1842:      */       {
/*  1843: 2107 */         MobileMboDataBean fromMultiBean = databean.getDataBean("TKMULTIASSETLOCCI");
/*  1844: 2108 */         String site = origrec.getValue("SITEID");
/*  1845: 2109 */         int count = fromMultiBean.count();
/*  1846: 2110 */         for (int i = 0; i < count; i++)
/*  1847:      */         {
/*  1848: 2111 */           MobileMbo multi = fromMultiBean.getMobileMbo(i);
/*  1849: 2112 */           String primary = multi.getValue("ISPRIMARY");
/*  1850: 2115 */           if ("0".equals(primary))
/*  1851:      */           {
/*  1852: 2117 */             newWOBean.insert();
/*  1853: 2118 */             String newWOKey = AutoKeyGenerator.generateKey("WORKORDER");
/*  1854: 2119 */             MobileMbo newChild = newWOBean.getMobileMbo();
/*  1855:      */             
/*  1856: 2121 */             newChild.setValue("DESCRIPTION", origrec.getValue("DESCRIPTION"));
/*  1857: 2122 */             newChild.setValue("DESCRIPTION_LONGDESCRIPTION", origrec.getValue("DESCRIPTION_LONGDESCRIPTION"));
/*  1858:      */             
/*  1859: 2124 */             newChild.setValue("PARENT", msg);
/*  1860: 2125 */             newChild.setValue("ORIGRECORDCLASS", origrec.getValue("CLASS"));
/*  1861: 2126 */             newChild.setValue("ESTDUR", "0");
/*  1862:      */             
/*  1863:      */ 
/*  1864:      */ 
/*  1865:      */ 
/*  1866: 2131 */             newChild.setValue("ORGID", origrec.getValue("ORGID"));
/*  1867: 2132 */             newChild.setValue("SITEID", origrec.getValue("SITEID"));
/*  1868: 2133 */             newChild.setValue("WONUM", newWOKey);
/*  1869: 2134 */             newChild.setValue("WOCLASS", newwoclass);
/*  1870:      */             
/*  1871:      */ 
/*  1872: 2137 */             newChild.setValue("CLASSSTRUCTUREID", origrec.getValue("CLASSSTRUCTUREID"));
/*  1873: 2138 */             createSpecRecords(origrec, newWOBean, databean);
/*  1874:      */             
/*  1875: 2140 */             MobileMboDataBean toMultiBean = newWOBean.getDataBean("WOMULTIASSETLOCCI");
/*  1876: 2141 */             toMultiBean.insert();
/*  1877:      */             
/*  1878:      */ 
/*  1879: 2144 */             MobileMbo newMultiMbo = toMultiBean.getMobileMbo();
/*  1880: 2145 */             newMultiMbo.setValue("RECORDKEY", newWOKey);
/*  1881: 2146 */             newMultiMbo.setValue("RECORDCLASS", newwoclass);
/*  1882: 2147 */             newMultiMbo.setValue("SITEID", multi.getValue("SITEID"));
/*  1883: 2148 */             newMultiMbo.setValue("ORGID", multi.getValue("ORGID"));
/*  1884:      */             
/*  1885:      */ 
/*  1886:      */ 
/*  1887:      */ 
/*  1888:      */ 
/*  1889: 2154 */             newMultiMbo.setValue("WORKSITEID", origrec.getValue("SITEID"));
/*  1890: 2155 */             newMultiMbo.setValue("WORKORGID", origrec.getValue("ORGID"));
/*  1891:      */             
/*  1892: 2157 */             newMultiMbo.setValue("ASSETNUM", multi.getValue("ASSETNUM"));
/*  1893: 2158 */             newMultiMbo.setValue("TARGETDESC", multi.getValue("TARGETDESC"));
/*  1894: 2159 */             newMultiMbo.setValue("TARGETDESC_LONGDESCRIPTION", multi.getValue("TARGETDESC_LONGDESCRIPTION"));
/*  1895: 2160 */             newMultiMbo.setValue("LOCATION", multi.getValue("LOCATION"));
/*  1896: 2161 */             newMultiMbo.setValue("CINUM", multi.getValue("CINUM"));
/*  1897: 2163 */             if (multi.getValue("SITEID").equalsIgnoreCase(site))
/*  1898:      */             {
/*  1899: 2165 */               newChild.setValue("ASSETNUM", multi.getValue("ASSETNUM"));
/*  1900: 2166 */               newChild.setValue("LOCATION", multi.getValue("LOCATION"));
/*  1901: 2167 */               newChild.setValue("CINUM", multi.getValue("CINUM"));
/*  1902: 2168 */               newChild.setValue("TARGETDESC", multi.getValue("TARGETDESC"));
/*  1903: 2169 */               newChild.setValue("TARGETDESC_LONGDESCRIPTION", multi.getValue("TARGETDESC_LONGDESCRIPTION"));
/*  1904:      */               
/*  1905: 2171 */               newMultiMbo.setValue("ISPRIMARY", "1");
/*  1906:      */             }
/*  1907:      */             else
/*  1908:      */             {
/*  1909: 2175 */               newMultiMbo.setValue("ISPRIMARY", "0");
/*  1910:      */             }
/*  1911: 2179 */             processLinearDetails(newMultiMbo, multi, multi.getValue("ASSETNUM"), multi.getValue("SITEID"));
/*  1912:      */           }
/*  1913:      */         }
/*  1914: 2182 */         newWOBean.getDataBeanManager().save();
/*  1915:      */       }
/*  1916: 2184 */       else if (createWOMulti.equalsIgnoreCase("TASK"))
/*  1917:      */       {
/*  1918: 2185 */         MobileMboDataBean tasks = newWOBean.getDataBean("WOTASKS");
/*  1919: 2186 */         MobileMboDataBean fromMultiBean = databean.getDataBean("TKMULTIASSETLOCCI");
/*  1920: 2187 */         String site = origrec.getValue("SITEID");
/*  1921:      */         
/*  1922: 2189 */         int count = fromMultiBean.count();
/*  1923: 2190 */         for (int i = 0; i < count; i++)
/*  1924:      */         {
/*  1925: 2191 */           MobileMbo multi = fromMultiBean.getMobileMbo(i);
/*  1926: 2192 */           tasks.insert();
/*  1927: 2193 */           String newTaskKey = "" + getNextTaskID(i * 10, "TASKSEED", "TASKINTERVAL", tasks);
/*  1928: 2194 */           MobileMbo newTask = tasks.getMobileMbo();
/*  1929:      */           
/*  1930: 2196 */           newTask.setValue("ORIGRECORDCLASS", origrec.getValue("CLASS"));
/*  1931: 2197 */           newTask.setValue("ESTDUR", "0");
/*  1932: 2198 */           newTask.setValue("TARGETDESC", multi.getValue("TARGETDESC"));
/*  1933: 2199 */           newTask.setValue("TARGETDESC_LONGDESCRIPTION", multi.getValue("TARGETDESC_LONGDESCRIPTION"));
/*  1934: 2200 */           newTask.setValue("ORGID", multi.getValue("ORGID"));
/*  1935: 2201 */           newTask.setValue("SITEID", multi.getValue("SITEID"));
/*  1936: 2202 */           newTask.setReadOnly("MEASUREMENTVALUE", true);
/*  1937: 2203 */           newTask.setReadOnly("MEASUREDATE", true);
/*  1938: 2204 */           newTask.setValue("TASKID", newTaskKey);
/*  1939: 2205 */           newTask.setValue("STATUS", ((WOApp)UIUtil.getApplication()).getDefaultValue(databean, "WOSTATUS", "WAPPR"));
/*  1940: 2206 */           newTask.setDateValue("STATUSDATE", databean.getCurrentTime(), false);
/*  1941:      */           
/*  1942: 2208 */           MobileMboDataBean toMultiBean = tasks.getDataBean("WOTASKMULTIASSETLOCCI");
/*  1943:      */           
/*  1944:      */ 
/*  1945:      */ 
/*  1946: 2212 */           toMultiBean.insert();
/*  1947: 2213 */           MobileMbo newMultiMbo = toMultiBean.getMobileMbo();
/*  1948: 2214 */           newMultiMbo.setValue("RECORDKEY", newTaskKey);
/*  1949: 2215 */           newMultiMbo.setValue("RECORDCLASS", newwoclass);
/*  1950: 2216 */           newMultiMbo.setValue("SITEID", multi.getValue("SITEID"));
/*  1951: 2217 */           newMultiMbo.setValue("ORGID", multi.getValue("ORGID"));
/*  1952: 2218 */           newMultiMbo.setValue("WORKSITEID", multi.getValue("SITEID"));
/*  1953: 2219 */           newMultiMbo.setValue("WORKORGID", multi.getValue("ORGID"));
/*  1954: 2220 */           newMultiMbo.setValue("ASSETNUM", multi.getValue("ASSETNUM"));
/*  1955: 2221 */           newMultiMbo.setValue("TARGETDESC", multi.getValue("TARGETDESC"));
/*  1956: 2222 */           newMultiMbo.setValue("TARGETDESC_LONGDESCRIPTION", multi.getValue("TARGETDESC_LONGDESCRIPTION"));
/*  1957: 2223 */           newMultiMbo.setValue("LOCATION", multi.getValue("LOCATION"));
/*  1958: 2224 */           newMultiMbo.setValue("CINUM", multi.getValue("CINUM"));
/*  1959: 2226 */           if (multi.getValue("SITEID").equalsIgnoreCase(site))
/*  1960:      */           {
/*  1961: 2227 */             newTask.setValue("ASSETNUM", multi.getValue("ASSETNUM"));
/*  1962: 2228 */             newTask.setValue("LOCATION", multi.getValue("LOCATION"));
/*  1963: 2229 */             newTask.setValue("CINUM", multi.getValue("CINUM"));
/*  1964:      */             
/*  1965: 2231 */             newMultiMbo.setValue("ISPRIMARY", "1");
/*  1966:      */           }
/*  1967:      */           else
/*  1968:      */           {
/*  1969: 2234 */             newMultiMbo.setValue("ISPRIMARY", "0");
/*  1970:      */           }
/*  1971: 2238 */           processLinearDetails(newMultiMbo, multi, multi.getValue("ASSETNUM"), multi.getValue("SITEID"));
/*  1972:      */         }
/*  1973: 2240 */         tasks.getDataBeanManager().save();
/*  1974:      */       }
/*  1975: 2241 */       else if (createWOMulti.equalsIgnoreCase("MULTI"))
/*  1976:      */       {
/*  1977: 2242 */         MobileMboDataBean fromMultiBean = databean.getDataBean("TKMULTIASSETLOCCI");
/*  1978: 2243 */         MobileMboDataBean toMultiBean = newWOBean.getDataBean("WOMULTIASSETLOCCI");
/*  1979: 2244 */         fromMultiBean.getQBE().reset();
/*  1980: 2245 */         fromMultiBean.reset();
/*  1981: 2246 */         int count = fromMultiBean.count();
/*  1982: 2247 */         for (int i = 0; i < count; i++)
/*  1983:      */         {
/*  1984: 2248 */           toMultiBean.insert();
/*  1985: 2249 */           MobileMbo fromMbo = fromMultiBean.getMobileMbo(i);
/*  1986: 2250 */           MobileMbo newMbo = toMultiBean.getMobileMbo();
/*  1987: 2251 */           fromMbo.copyAttributeValue(newMbo, "ASSETNUM");
/*  1988: 2252 */           fromMbo.copyAttributeValue(newMbo, "LOCATION");
/*  1989: 2253 */           fromMbo.copyAttributeValue(newMbo, "CINUM");
/*  1990: 2254 */           fromMbo.copyAttributeValue(newMbo, "TARGETDESC");
/*  1991: 2255 */           fromMbo.copyAttributeValue(newMbo, "TARGETDESC_LONGDESCRIPTION");
/*  1992: 2256 */           fromMbo.copyAttributeValue(newMbo, "ISPRIMARY");
/*  1993: 2257 */           fromMbo.copyAttributeValue(newMbo, "SEQUENCE");
/*  1994: 2258 */           fromMbo.copyAttributeValue(newMbo, "ORGID");
/*  1995: 2259 */           fromMbo.copyAttributeValue(newMbo, "SITEID");
/*  1996: 2260 */           fromMbo.copyAttributeValue(newMbo, "WORKORGID");
/*  1997: 2261 */           fromMbo.copyAttributeValue(newMbo, "WORKSITEID");
/*  1998: 2262 */           newMbo.setValue("RECORDCLASS", newwoclass);
/*  1999: 2263 */           newMbo.setValue("RECORDKEY", msg);
/*  2000:      */           
/*  2001: 2265 */           toMultiBean.setValue("COPIED", "1");
/*  2002:      */           
/*  2003:      */ 
/*  2004: 2268 */           processLinearDetails(newMbo, fromMbo, fromMbo.getValue("ASSETNUM"), fromMbo.getValue("SITEID"));
/*  2005:      */         }
/*  2006: 2270 */         toMultiBean.getDataBeanManager().save();
/*  2007:      */       }
/*  2008: 2271 */       else if (createWOMulti.equalsIgnoreCase("TOPLEVEL"))
/*  2009:      */       {
/*  2010: 2272 */         MobileMboDataBean fromMultiBean = databean.getDataBean("TKMULTIASSETLOCCI");
/*  2011: 2273 */         fromMultiBean.getQBE().reset();
/*  2012: 2274 */         fromMultiBean.reset();
/*  2013: 2275 */         int count = fromMultiBean.count();
/*  2014: 2276 */         for (int i = 0; i < count; i++)
/*  2015:      */         {
/*  2016: 2278 */           newWOBean.insert();
/*  2017: 2279 */           MobileMbo fromMbo = fromMultiBean.getMobileMbo(i);
/*  2018: 2280 */           MobileMbo newMbo = newWOBean.getMobileMbo();
/*  2019:      */           
/*  2020: 2282 */           fromMbo.copyAttributeValue(newMbo, "ASSETNUM");
/*  2021: 2283 */           fromMbo.copyAttributeValue(newMbo, "LOCATION");
/*  2022: 2284 */           fromMbo.copyAttributeValue(newMbo, "CINUM");
/*  2023: 2285 */           fromMbo.copyAttributeValue(newMbo, "TARGETDESC");
/*  2024: 2286 */           fromMbo.copyAttributeValue(newMbo, "TARGETDESC_LONGDESCRIPTION");
/*  2025:      */           
/*  2026: 2288 */           fromMbo.copyAttributeValue(newMbo, "ORGID");
/*  2027: 2289 */           fromMbo.copyAttributeValue(newMbo, "SITEID");
/*  2028: 2290 */           String newWOKey = AutoKeyGenerator.generateKey("WORKORDER", "WONUM");
/*  2029: 2291 */           newMbo.setValue("WONUM", newWOKey);
/*  2030: 2292 */           newMbo.setValue("STATUS", ((WOApp)UIUtil.getApplication()).getDefaultValue(newWOBean, "WOSTATUS", "WAPPR"));
/*  2031:      */           
/*  2032: 2294 */           newMbo.setValue("WOCLASS", ((WOApp)UIUtil.getApplication()).getDefaultValue(newWOBean, "WOCLASS", newwoclass));
/*  2033:      */           
/*  2034: 2296 */           newMbo.setValue("ESTDUR", "0");
/*  2035: 2297 */           newMbo.setDateValue("STATUSDATE", createDate);
/*  2036: 2298 */           newMbo.setDateValue("REPORTDATE", createDate);
/*  2037: 2299 */           newMbo.setDateValue("CHANGEDATE", createDate);
/*  2038: 2300 */           newMbo.setValue("HISTORYFLAG", "0");
/*  2039: 2301 */           newMbo.setValue("REPORTEDBY", UIUtil.getApplication().getCurrentUser().toUpperCase());
/*  2040: 2302 */           newMbo.setValue("ORIGRECORDCLASS", origrec.getValue("CLASS"));
/*  2041: 2303 */           newMbo.setValue("ORIGRECORDID", origrec.getValue("TICKETID"));
/*  2042: 2304 */           newMbo.setValue("DESCRIPTION", origrec.getValue("DESCRIPTION"));
/*  2043: 2305 */           newMbo.setValue("DESCRIPTION_LONGDESCRIPTION", origrec.getValue("DESCRIPTION_LONGDESCRIPTION"));
/*  2044: 2306 */           newMbo.setValue("WOPRIORITY", origrec.getValue("INTERNALPRIORITY"));
/*  2045: 2307 */           newMbo.setValue("REPORTEDBY", origrec.getValue("REPORTEDBY"));
/*  2046: 2308 */           newMbo.setValue("PHONE", origrec.getValue("REPORTEDPHONE"));
/*  2047: 2309 */           newMbo.setValue("ONBEHALFOF", origrec.getValue("AFFECTEDPERSONID"));
/*  2048: 2310 */           newMbo.setValue("GLACCOUNT", origrec.getValue("GLACCOUNT"));
/*  2049: 2311 */           newMbo.setValue("COMMODITYGROUP", origrec.getValue("COMMODITYGROUP"));
/*  2050: 2312 */           newMbo.setValue("COMMODITY", origrec.getValue("COMMODITY"));
/*  2051:      */           
/*  2052:      */ 
/*  2053: 2315 */           newMbo.setValue("CLASSSTRUCTUREID", origrec.getValue("CLASSSTRUCTUREID"));
/*  2054: 2316 */           createSpecRecords(origrec, newWOBean, databean);
/*  2055:      */           
/*  2056: 2318 */           MobileMboDataBean toMultiBean = newWOBean.getDataBean("WOMULTIASSETLOCCI");
/*  2057: 2319 */           toMultiBean.insert();
/*  2058:      */           
/*  2059:      */ 
/*  2060: 2322 */           MobileMbo newMultiMbo = toMultiBean.getMobileMbo();
/*  2061: 2323 */           newMultiMbo.setValue("RECORDKEY", newWOKey);
/*  2062: 2324 */           newMultiMbo.setValue("RECORDCLASS", newwoclass);
/*  2063: 2325 */           newMultiMbo.setValue("SITEID", newMbo.getValue("SITEID"));
/*  2064: 2326 */           newMultiMbo.setValue("ORGID", newMbo.getValue("ORGID"));
/*  2065: 2327 */           newMultiMbo.setValue("WORKSITEID", newMbo.getValue("SITEID"));
/*  2066: 2328 */           newMultiMbo.setValue("WORKORGID", newMbo.getValue("ORGID"));
/*  2067: 2329 */           newMultiMbo.setValue("ASSETNUM", newMbo.getValue("ASSETNUM"));
/*  2068: 2330 */           newMultiMbo.setValue("TARGETDESC", newMbo.getValue("TARGETDESC"));
/*  2069: 2331 */           newMultiMbo.setValue("TARGETDESC_LONGDESCRIPTION", newMbo.getValue("TARGETDESC_LONGDESCRIPTION"));
/*  2070: 2332 */           newMultiMbo.setValue("LOCATION", newMbo.getValue("LOCATION"));
/*  2071: 2333 */           newMultiMbo.setValue("CINUM", newMbo.getValue("CINUM"));
/*  2072: 2334 */           newMultiMbo.setValue("ISPRIMARY", "1");
/*  2073:      */           
/*  2074:      */ 
/*  2075: 2337 */           processLinearDetails(newMultiMbo, fromMbo, fromMbo.getValue("ASSETNUM"), fromMbo.getValue("SITEID"));
/*  2076:      */         }
/*  2077: 2339 */         newWOBean.getDataBeanManager().save();
/*  2078:      */       }
/*  2079:      */     }
/*  2080: 2347 */     MobileMboDataBean newWorkLogBean = newWOBean.getDataBean("WORKLOG");
/*  2081: 2348 */     String origWorkLogName = "WORKLOG";
/*  2082: 2349 */     if (databean.getName().equalsIgnoreCase("TICKET")) {
/*  2083: 2350 */       origWorkLogName = "TKWORKLOG";
/*  2084:      */     }
/*  2085: 2351 */     MobileMboDataBean origWorkLogBean = databean.getDataBean(origWorkLogName);
/*  2086: 2352 */     int count = origWorkLogBean.count();
/*  2087: 2353 */     for (int i = 0; i < count; i++)
/*  2088:      */     {
/*  2089: 2355 */       newWorkLogBean.insert();
/*  2090: 2356 */       newWorkLogBean.setValue("SITEID", origWorkLogBean.getValue(i, "SITEID"));
/*  2091: 2357 */       newWorkLogBean.setValue("RECORDKEY", origWorkLogBean.getValue(i, "RECORDKEY"));
/*  2092: 2358 */       newWorkLogBean.setValue("CLASS", origWorkLogBean.getValue(i, "CLASS"));
/*  2093: 2359 */       newWorkLogBean.setValue("CREATEBY", origWorkLogBean.getValue(i, "CREATEBY"));
/*  2094: 2360 */       newWorkLogBean.setValue("CREATEDATE", origWorkLogBean.getValue(i, "CREATEDATE"));
/*  2095: 2361 */       newWorkLogBean.setValue("LOGTYPE", origWorkLogBean.getValue(i, "LOGTYPE"));
/*  2096: 2362 */       newWorkLogBean.setValue("CLIENTVIEWABLE", origWorkLogBean.getValue(i, "CLIENTVIEWABLE"));
/*  2097: 2363 */       newWorkLogBean.setValue("DESCRIPTION", origWorkLogBean.getValue(i, "DESCRIPTION"));
/*  2098: 2364 */       newWorkLogBean.setValue("DESCRIPTION_LONGDESCRIPTION", origWorkLogBean.getValue(i, "DESCRIPTION_LONGDESCRIPTION"));
/*  2099: 2365 */       newWorkLogBean.setValue("CREATEDFROMFOLLOWUP", "1");
/*  2100:      */     }
/*  2101: 2368 */     newWOBean.getDataBeanManager().save();
/*  2102: 2373 */     if (origrec.getName().equalsIgnoreCase("WORKORDER")) {
/*  2103: 2375 */       app.addRelatedRecToWO(origrec.getValue("_ID"), origrec.getValue("WONUM"), origrec.getValue("ORGID"), origrec.getValue("SITEID"), origrec.getValue("WOCLASS"), newWOBean.getMobileMbo().getLongValue("_ID"), "WORKORDER", app.getDefaultValue(newWOBean, "RELATETYPE", "FOLLOWUP"), newWOBean.getValue("WONUM"), newWOBean.getValue("ORGID"), newWOBean.getValue("SITEID"), newWOBean.getValue("WOCLASS"));
/*  2104:      */     } else {
/*  2105: 2391 */       app.addRelatedRecToTK(origrec.getValue("_ID"), origrec.getValue("TICKETID"), origrec.getValue("ORGID"), origrec.getValue("SITEID"), origrec.getValue("CLASS"), newWOBean.getMobileMbo().getLongValue("_ID"), "WORKORDER", app.getDefaultValue(newWOBean, "RELATETYPE", "FOLLOWUP"), newWOBean.getValue("WONUM"), newWOBean.getValue("ORGID"), newWOBean.getValue("SITEID"), newWOBean.getValue("WOCLASS"));
/*  2106:      */     }
/*  2107: 2409 */     if (origrec.getName().equalsIgnoreCase("WORKORDER")) {
/*  2108: 2411 */       app.addRelatedRecToWO(newWOBean.getValue("_ID"), newWOBean.getValue("WONUM"), newWOBean.getValue("ORGID"), newWOBean.getValue("SITEID"), newWOBean.getValue("WOCLASS"), databean.getMobileMbo().getLongValue("_ID"), "WORKORDER", app.getDefaultValue(newWOBean, "RELATETYPE", "ORIGINATOR"), origrec.getValue("WONUM"), origrec.getValue("ORGID"), origrec.getValue("SITEID"), origrec.getValue("WOCLASS"));
/*  2109:      */     } else {
/*  2110: 2427 */       app.addRelatedRecToWO(newWOBean.getValue("_ID"), newWOBean.getValue("WONUM"), newWOBean.getValue("ORGID"), newWOBean.getValue("SITEID"), newWOBean.getValue("WOCLASS"), databean.getMobileMbo().getLongValue("_ID"), "TICKET", app.getDefaultValue(newWOBean, "RELATETYPE", "ORIGINATOR"), origrec.getValue("TICKETID"), origrec.getValue("ORGID"), origrec.getValue("SITEID"), origrec.getValue("CLASS"));
/*  2111:      */     }
/*  2112: 2442 */     setWorklistRecordBean(event, newWOBean);
/*  2113:      */     
/*  2114: 2444 */     return true;
/*  2115:      */   }
/*  2116:      */   
/*  2117:      */   private void processLinearDetails(MobileMbo toMultiMbo, MobileMbo origMultiMbo, String assetNum, String siteId)
/*  2118:      */     throws MobileApplicationException
/*  2119:      */   {
/*  2120: 2453 */     MobileMboDataBean assetBean = DataBeanCache.getDataBean("ASSET", "ASSET");
/*  2121: 2454 */     int currentPos = assetBean.getCurrentPosition();
/*  2122:      */     
/*  2123: 2456 */     MobileMboQBE qbe = assetBean.getQBE();
/*  2124: 2457 */     qbe.saveState();
/*  2125: 2458 */     qbe.setQBE("ASSETNUM", assetNum);
/*  2126: 2459 */     qbe.setQBE("SITEID", siteId);
/*  2127: 2460 */     assetBean.reset();
/*  2128: 2461 */     MobileMbo assetMbo = assetBean.getMobileMbo(0);
/*  2129: 2462 */     qbe.restoreState();
/*  2130: 2463 */     assetBean.reset();
/*  2131: 2464 */     assetBean.setCurrentPosition(currentPos);
/*  2132: 2465 */     if ((assetMbo != null) && (assetMbo.getBooleanValue("ISLINEAR"))) {
/*  2133: 2468 */       copyLinearDetails(toMultiMbo, origMultiMbo);
/*  2134:      */     }
/*  2135:      */   }
/*  2136:      */   
/*  2137:      */   private void copyLinearDetails(MobileMbo toMultiMbo, MobileMbo origMultiMbo)
/*  2138:      */     throws MobileApplicationException
/*  2139:      */   {
/*  2140: 2477 */     toMultiMbo.setValue("FEATURE", origMultiMbo.getValue("FEATURE"));
/*  2141: 2478 */     toMultiMbo.setValue("FEATURELABEL", origMultiMbo.getValue("FEATURELABEL"));
/*  2142: 2479 */     toMultiMbo.setValue("ASSETFEATUREID", origMultiMbo.getValue("ASSETFEATUREID"));
/*  2143: 2480 */     toMultiMbo.setValue("ASSETLRM", origMultiMbo.getValue("ASSETLRM"), false);
/*  2144: 2481 */     toMultiMbo.setValue("STARTFEATURELABEL", origMultiMbo.getValue("STARTFEATURELABEL"));
/*  2145: 2482 */     toMultiMbo.setValue("STARTOFFSET", origMultiMbo.getValue("STARTOFFSET"));
/*  2146: 2483 */     toMultiMbo.setValue("STARTMEASURE", origMultiMbo.getValue("STARTMEASURE"));
/*  2147: 2484 */     toMultiMbo.setValue("STARTYOFFSET", origMultiMbo.getValue("STARTYOFFSET"));
/*  2148:      */     
/*  2149: 2486 */     toMultiMbo.setValue("STARTZOFFSET", origMultiMbo.getValue("STARTZOFFSET"));
/*  2150: 2487 */     toMultiMbo.setValue("ENDFEATURELABEL", origMultiMbo.getValue("ENDFEATURELABEL"));
/*  2151: 2488 */     toMultiMbo.setValue("ENDOFFSET", origMultiMbo.getValue("ENDOFFSET"));
/*  2152: 2489 */     toMultiMbo.setValue("ENDMEASURE", origMultiMbo.getValue("ENDMEASURE"));
/*  2153: 2490 */     toMultiMbo.setValue("ENDYOFFSET", origMultiMbo.getValue("ENDYOFFSET"));
/*  2154:      */     
/*  2155: 2492 */     toMultiMbo.setValue("ENDZOFFSET", origMultiMbo.getValue("ENDZOFFSET"));
/*  2156: 2493 */     toMultiMbo.setValue("STARTYOFFSETREF", origMultiMbo.getValue("STARTYOFFSETREF"));
/*  2157: 2494 */     toMultiMbo.setValue("STARTZOFFSETREF", origMultiMbo.getValue("STARTZOFFSETREF"));
/*  2158: 2495 */     toMultiMbo.setValue("ENDYOFFSETREF", origMultiMbo.getValue("ENDYOFFSETREF"));
/*  2159: 2496 */     toMultiMbo.setValue("ENDZOFFSETREF", origMultiMbo.getValue("ENDZOFFSETREF"));
/*  2160: 2497 */     toMultiMbo.setValue("YOFFSETMEASUREUNITID", origMultiMbo.getValue("YOFFSETMEASUREUNITID"));
/*  2161: 2498 */     toMultiMbo.setValue("ZOFFSETMEASUREUNITID", origMultiMbo.getValue("ZOFFSETMEASUREUNITID"));
/*  2162: 2499 */     toMultiMbo.setValue("STARTMEASUREUNITID", origMultiMbo.getValue("STARTMEASUREUNITID"));
/*  2163: 2500 */     toMultiMbo.setValue("ENDMEASUREUNITID", origMultiMbo.getValue("ENDMEASUREUNITID"));
/*  2164: 2501 */     toMultiMbo.setValue("STARTOFFSETUNITID", origMultiMbo.getValue("STARTOFFSETUNITID"));
/*  2165: 2502 */     toMultiMbo.setValue("ENDOFFSETUNITID", origMultiMbo.getValue("ENDOFFSETUNITID"));
/*  2166:      */     
/*  2167: 2504 */     toMultiMbo.setValue("STARTASSETFEATUREID", origMultiMbo.getValue("STARTASSETFEATUREID"));
/*  2168: 2505 */     toMultiMbo.setValue("ENDASSETFEATUREID", origMultiMbo.getValue("ENDASSETFEATUREID"));
/*  2169: 2507 */     if (toMultiMbo.getName().equalsIgnoreCase("WOMULTIASSETLOCCI"))
/*  2170:      */     {
/*  2171: 2509 */       String orgField = "WORKORGID";
/*  2172: 2510 */       String siteField = "WORKSITEID";
/*  2173: 2512 */       if (origMultiMbo.getName().equalsIgnoreCase("TKMULTIASSETLOCCI"))
/*  2174:      */       {
/*  2175: 2514 */         orgField = "ORGID";
/*  2176: 2515 */         siteField = "SITEID";
/*  2177:      */       }
/*  2178: 2518 */       toMultiMbo.setValue("WORKORGID", origMultiMbo.getValue(orgField));
/*  2179: 2519 */       toMultiMbo.setValue("WORKSITEID", origMultiMbo.getValue(siteField));
/*  2180:      */     }
/*  2181:      */   }
/*  2182:      */   
/*  2183:      */   private void createSpecRecords(MobileMbo origRec, MobileMboDataBean newBean, MobileMboDataBean dataBean)
/*  2184:      */     throws MobileApplicationException
/*  2185:      */   {
/*  2186: 2527 */     String fromSpecBeanName = dataBean.getName() + "SPEC";
/*  2187: 2528 */     String toSpecBeanName = newBean.getName() + "SPEC";
/*  2188:      */     
/*  2189: 2530 */     String recordKey = "";
/*  2190: 2532 */     if (newBean.getName().equals("WORKORDER")) {
/*  2191: 2533 */       recordKey = "WONUM";
/*  2192:      */     } else {
/*  2193: 2535 */       recordKey = "TICKETID";
/*  2194:      */     }
/*  2195: 2537 */     MobileMboDataBean fromSpecBean = dataBean.getDataBean(fromSpecBeanName);
/*  2196: 2538 */     fromSpecBean.getQBE().reset();
/*  2197: 2539 */     fromSpecBean.reset();
/*  2198:      */     
/*  2199: 2541 */     MobileMboDataBean toSpecBean = newBean.getDataBean(toSpecBeanName);
/*  2200:      */     
/*  2201: 2543 */     int specCount = fromSpecBean.count();
/*  2202: 2544 */     for (int i = 0; i < specCount; i++)
/*  2203:      */     {
/*  2204: 2546 */       toSpecBean.insert();
/*  2205:      */       
/*  2206: 2548 */       MobileMbo fromMbo = fromSpecBean.getMobileMbo(i);
/*  2207: 2549 */       MobileMbo newMbo = toSpecBean.getMobileMbo();
/*  2208:      */       
/*  2209: 2551 */       newMbo.setValue(recordKey, newBean.getValue(recordKey));
/*  2210: 2552 */       newMbo.setValue("ALNVALUE", fromMbo.getValue("ALNVALUE"));
/*  2211: 2553 */       newMbo.setValue("ASSETATTRID", fromMbo.getValue("ASSETATTRID"));
/*  2212: 2554 */       newMbo.setValue("CHANGEBY", fromMbo.getValue("CHANGEBY"));
/*  2213: 2555 */       newMbo.setValue("CHANGEDATE", fromMbo.getValue("CHANGEDATE"));
/*  2214: 2556 */       newMbo.setValue("CLASSSTRUCTUREID", fromMbo.getValue("CLASSSTRUCTUREID"));
/*  2215: 2557 */       newMbo.setValue("DISPLAYSEQUENCE", fromMbo.getValue("DISPLAYSEQUENCE"));
/*  2216: 2558 */       newMbo.setValue("LINKEDTOATTRIBUTE", fromMbo.getValue("LINKEDTOATTRIBUTE"));
/*  2217: 2559 */       newMbo.setValue("LINKEDTOSECTION", fromMbo.getValue("LINKEDTOSECTION"));
/*  2218: 2560 */       newMbo.setValue("MEASUREUNITID", fromMbo.getValue("MEASUREUNITID"));
/*  2219: 2561 */       newMbo.setValue("NUMVALUE", fromMbo.getValue("NUMVALUE"));
/*  2220: 2562 */       newMbo.setValue("ORGID", fromMbo.getValue("ORGID"));
/*  2221: 2563 */       newMbo.setValue("SECTION", fromMbo.getValue("SECTION"));
/*  2222: 2564 */       newMbo.setValue("CLASSSPECID", fromMbo.getValue("CLASSSPECID"));
/*  2223: 2565 */       newMbo.setValue("MANDATORY", fromMbo.getValue("MANDATORY"));
/*  2224: 2566 */       newMbo.setValue("TABLEVALUE", fromMbo.getValue("TABLEVALUE"));
/*  2225: 2567 */       newMbo.setValue("DISPLAY_VALUE", fromMbo.getValue("DISPLAY_VALUE"));
/*  2226: 2568 */       newMbo.setValue("DESCRIPTION", fromMbo.getValue("DESCRIPTION"), false);
/*  2227: 2569 */       newMbo.setValue("DATATYPE", fromMbo.getValue("DATATYPE"), false);
/*  2228:      */     }
/*  2229: 2572 */     toSpecBean.getDataBeanManager().save();
/*  2230:      */   }
/*  2231:      */   
/*  2232:      */   public boolean createfollowupsr(UIEvent event)
/*  2233:      */     throws MobileApplicationException
/*  2234:      */   {
/*  2235: 2577 */     createfollowupticket(event, "SR");
/*  2236: 2578 */     return showMainPage(event, "SR");
/*  2237:      */   }
/*  2238:      */   
/*  2239:      */   public boolean createfollowupincident(UIEvent event)
/*  2240:      */     throws MobileApplicationException
/*  2241:      */   {
/*  2242: 2583 */     createfollowupticket(event, "INCIDENT");
/*  2243: 2584 */     return showMainPage(event, "INCIDENT");
/*  2244:      */   }
/*  2245:      */   
/*  2246:      */   public boolean createfollowupproblem(UIEvent event)
/*  2247:      */     throws MobileApplicationException
/*  2248:      */   {
/*  2249: 2589 */     createfollowupticket(event, "PROBLEM");
/*  2250: 2590 */     return showMainPage(event, "PROBLEM");
/*  2251:      */   }
/*  2252:      */   
/*  2253:      */   public boolean createfollowupticket(UIEvent event, String newtkclass)
/*  2254:      */     throws MobileApplicationException
/*  2255:      */   {
/*  2256: 2595 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/*  2257: 2596 */     WOApp app = (WOApp)UIUtil.getApplication();
/*  2258:      */     
/*  2259:      */ 
/*  2260: 2599 */     MobileMbo origrec = databean.getMobileMbo();
/*  2261:      */     
/*  2262: 2601 */     Date createDate = databean.getCurrentTime();
/*  2263:      */     
/*  2264: 2603 */     MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager("TICKET");
/*  2265: 2604 */     MobileMboDataBean newTKBean = mgrDBMgr.getDataBean();
/*  2266:      */     
/*  2267:      */ 
/*  2268: 2607 */     String msg = AutoKeyGenerator.generateKey("TICKET", "TICKETID");
/*  2269: 2608 */     newTKBean.insert();
/*  2270:      */     
/*  2271: 2610 */     newTKBean.setValue("TICKETID", msg);
/*  2272:      */     
/*  2273:      */ 
/*  2274: 2613 */     newTKBean.setValue("CLASS", app.getExternalValue(databean, "TKCLASS", newtkclass));
/*  2275:      */     
/*  2276: 2615 */     String statusdomain = "";
/*  2277: 2616 */     if (newtkclass.equalsIgnoreCase("SR")) {
/*  2278: 2617 */       statusdomain = "SRSTATUS";
/*  2279: 2618 */     } else if (newtkclass.equalsIgnoreCase("INCIDENT")) {
/*  2280: 2619 */       statusdomain = "INCIDENTSTATUS";
/*  2281: 2620 */     } else if (newtkclass.equalsIgnoreCase("PROBLEM")) {
/*  2282: 2621 */       statusdomain = "PROBLEMSTATUS";
/*  2283:      */     }
/*  2284: 2623 */     newTKBean.setValue("STATUS", app.getDefaultValue(databean, statusdomain, "NEW"));
/*  2285:      */     
/*  2286:      */ 
/*  2287: 2626 */     newTKBean.getMobileMbo().setDateValue("STATUSDATE", createDate);
/*  2288: 2627 */     newTKBean.getMobileMbo().setDateValue("REPORTDATE", createDate);
/*  2289: 2628 */     newTKBean.getMobileMbo().setDateValue("CHANGEDATE", createDate);
/*  2290: 2631 */     if (databean.getName().equalsIgnoreCase("TICKET"))
/*  2291:      */     {
/*  2292: 2641 */       newTKBean.setValue("ORIGRECORGID", origrec.getValue("ORGID"));
/*  2293: 2642 */       newTKBean.setValue("ORIGRECSITEID", origrec.getValue("SITEID"));
/*  2294: 2643 */       newTKBean.setValue("ORIGRECORDCLASS", origrec.getValue("CLASS"));
/*  2295: 2644 */       newTKBean.setValue("ORIGRECORDID", origrec.getValue("TICKETID"));
/*  2296:      */       
/*  2297: 2646 */       newTKBean.setValue("DESCRIPTION", origrec.getValue("DESCRIPTION"));
/*  2298: 2647 */       newTKBean.setValue("DESCRIPTION_LONGDESCRIPTION", origrec.getValue("DESCRIPTION_LONGDESCRIPTION"));
/*  2299: 2648 */       newTKBean.setValue("SOURCE", origrec.getValue("SOURCE"));
/*  2300: 2649 */       newTKBean.setValue("REPORTEDPRIORITY", origrec.getValue("REPORTEDPRIORITY"));
/*  2301: 2650 */       newTKBean.setValue("INTERNALPRIORITY", origrec.getValue("INTERNALPRIORITY"));
/*  2302: 2651 */       newTKBean.setValue("IMPACT", origrec.getValue("IMPACT"));
/*  2303: 2652 */       newTKBean.setValue("URGENCY", origrec.getValue("URGENCY"));
/*  2304: 2653 */       newTKBean.setValue("REPORTEDBYID", origrec.getValue("REPORTEDBYID"));
/*  2305: 2654 */       newTKBean.setValue("REPORTEDPHONE", origrec.getValue("REPORTEDPHONE"));
/*  2306: 2655 */       newTKBean.setValue("REPORTEDEMAIL", origrec.getValue("REPORTEDEMAIL"));
/*  2307: 2656 */       newTKBean.setValue("AFFECTEDPERSONID", origrec.getValue("AFFECTEDPERSONID"));
/*  2308: 2657 */       newTKBean.setValue("AFFECTEDPHONE", origrec.getValue("AFFECTEDPHONE"));
/*  2309: 2658 */       newTKBean.setValue("AFFECTEDEMAIL", origrec.getValue("AFFECTEDEMAIL"));
/*  2310: 2659 */       newTKBean.setValue("ORGID", origrec.getValue("ORGID"));
/*  2311: 2660 */       newTKBean.setValue("SITEID", origrec.getValue("SITEID"));
/*  2312: 2661 */       newTKBean.setValue("ASSETORGID", origrec.getValue("ASSETORGID"));
/*  2313: 2662 */       newTKBean.setValue("ASSETSITEID", origrec.getValue("ASSETSITEID"));
/*  2314: 2663 */       newTKBean.setValue("ASSETNUM", origrec.getValue("ASSETNUM"));
/*  2315: 2664 */       newTKBean.setValue("LOCATION", origrec.getValue("LOCATION"));
/*  2316: 2665 */       newTKBean.setValue("CLASSSTRUCTUREID", origrec.getValue("CLASSSTRUCTUREID"));
/*  2317: 2666 */       newTKBean.setValue("CLASSSTRUCTURE_HIERARCHYPATH", origrec.getValue("CLASSSTRUCTURE_HIERARCHYPATH"));
/*  2318: 2667 */       newTKBean.setValue("CLASSSTRUCTURE_DESCRIPTION", origrec.getValue("CLASSSTRUCTURE_DESCRIPTION"));
/*  2319: 2668 */       newTKBean.setValue("COMMODITYGROUP", origrec.getValue("COMMODITYGROUP"));
/*  2320: 2669 */       newTKBean.setValue("COMMODITY", origrec.getValue("COMMODITY"));
/*  2321: 2670 */       newTKBean.setValue("GLACCOUNT", origrec.getValue("GLACCOUNT"));
/*  2322: 2671 */       newTKBean.setValue("VENDOR", origrec.getValue("VENDOR"));
/*  2323:      */       
/*  2324:      */ 
/*  2325: 2674 */       newTKBean.setValue("CLASSSTRUCTUREID", origrec.getValue("CLASSSTRUCTUREID"));
/*  2326: 2675 */       createSpecRecords(origrec, newTKBean, databean);
/*  2327:      */       
/*  2328:      */ 
/*  2329:      */ 
/*  2330: 2679 */       MobileMboDataBean fromMultiBean = databean.getDataBean("TKMULTIASSETLOCCI");
/*  2331: 2680 */       MobileMboDataBean toMultiBean = newTKBean.getDataBean("TKMULTIASSETLOCCI");
/*  2332: 2681 */       fromMultiBean.getQBE().reset();
/*  2333: 2682 */       fromMultiBean.reset();
/*  2334: 2683 */       int count = fromMultiBean.count();
/*  2335: 2684 */       for (int i = 0; i < count; i++)
/*  2336:      */       {
/*  2337: 2686 */         toMultiBean.insert();
/*  2338:      */         
/*  2339: 2688 */         MobileMbo fromMbo = fromMultiBean.getMobileMbo(i);
/*  2340: 2689 */         MobileMbo newMbo = toMultiBean.getMobileMbo();
/*  2341:      */         
/*  2342: 2691 */         fromMbo.copyAttributeValue(newMbo, "ASSETNUM");
/*  2343: 2692 */         fromMbo.copyAttributeValue(newMbo, "LOCATION");
/*  2344: 2693 */         fromMbo.copyAttributeValue(newMbo, "CINUM");
/*  2345: 2694 */         fromMbo.copyAttributeValue(newMbo, "TARGETDESC");
/*  2346: 2695 */         fromMbo.copyAttributeValue(newMbo, "TARGETDESC_LONGDESCRIPTION");
/*  2347: 2696 */         fromMbo.copyAttributeValue(newMbo, "ISPRIMARY");
/*  2348: 2697 */         fromMbo.copyAttributeValue(newMbo, "SEQUENCE");
/*  2349: 2698 */         fromMbo.copyAttributeValue(newMbo, "ORGID");
/*  2350: 2699 */         fromMbo.copyAttributeValue(newMbo, "SITEID");
/*  2351: 2700 */         fromMbo.copyAttributeValue(newMbo, "WORKORGID");
/*  2352: 2701 */         fromMbo.copyAttributeValue(newMbo, "WORKSITEID");
/*  2353:      */         
/*  2354:      */ 
/*  2355: 2704 */         newMbo.setValue("RECORDCLASS", app.getExternalValue(databean, "TKCLASS", newtkclass));
/*  2356: 2705 */         newMbo.setValue("RECORDKEY", msg);
/*  2357:      */         
/*  2358: 2707 */         toMultiBean.setValue("COPIED", "1");
/*  2359:      */         
/*  2360:      */ 
/*  2361: 2710 */         processLinearDetails(newMbo, fromMbo, fromMbo.getValue("ASSETNUM"), fromMbo.getValue("SITEID"));
/*  2362:      */       }
/*  2363: 2713 */       toMultiBean.getDataBeanManager().save();
/*  2364:      */     }
/*  2365: 2726 */     else if (databean.getName().equalsIgnoreCase("WORKORDER"))
/*  2366:      */     {
/*  2367: 2736 */       newTKBean.setValue("DESCRIPTION", origrec.getValue("DESCRIPTION"));
/*  2368: 2737 */       newTKBean.setValue("DESCRIPTION_LONGDESCRIPTION", origrec.getValue("DESCRIPTION_LONGDESCRIPTION"));
/*  2369: 2738 */       newTKBean.setValue("ASSETNUM", origrec.getValue("ASSETNUM"));
/*  2370:      */       
/*  2371:      */ 
/*  2372:      */ 
/*  2373:      */ 
/*  2374:      */ 
/*  2375: 2744 */       MobileMboDataBean woassetbean = databean.getDataBean("WOASSET");
/*  2376: 2745 */       if (woassetbean != null)
/*  2377:      */       {
/*  2378: 2747 */         newTKBean.setValue("ASSETORGID", woassetbean.getValue("ORGID"));
/*  2379: 2748 */         newTKBean.setValue("ASSETSITEID", woassetbean.getValue("SITEID"));
/*  2380:      */       }
/*  2381: 2751 */       if (!origrec.getValue("FAILURECODE").equals(""))
/*  2382:      */       {
/*  2383: 2753 */         newTKBean.setValue("FAILUREREPORTCHANGED", "1");
/*  2384: 2754 */         newTKBean.setValue("FAILURECODE", origrec.getValue("FAILURECODE"));
/*  2385:      */       }
/*  2386: 2756 */       newTKBean.setValue("LOCATION", origrec.getValue("LOCATION"));
/*  2387: 2757 */       newTKBean.setValue("ORIGRECORGID", origrec.getValue("ORGID"));
/*  2388: 2758 */       newTKBean.setValue("ORIGRECSITEID", origrec.getValue("SITEID"));
/*  2389:      */       
/*  2390:      */ 
/*  2391:      */ 
/*  2392: 2762 */       String woInternalPriority = origrec.getValue("WOPRIORITY");
/*  2393: 2763 */       if (woInternalPriority.equals("5")) {
/*  2394: 2765 */         woInternalPriority = "4";
/*  2395:      */       }
/*  2396: 2767 */       newTKBean.setValue("INTERNALPRIORITY", woInternalPriority);
/*  2397: 2768 */       newTKBean.setValue("ORIGRECORDCLASS", origrec.getValue("WOCLASS"));
/*  2398: 2769 */       newTKBean.setValue("ORIGRECORDID", origrec.getValue("WONUM"));
/*  2399: 2770 */       newTKBean.setValue("ORIGWOID", origrec.getValue("WONUM"));
/*  2400: 2771 */       newTKBean.setValue("OWNER", origrec.getValue("OWNER"));
/*  2401: 2772 */       newTKBean.setValue("OWNERGROUP", origrec.getValue("OWNERGROUP"));
/*  2402:      */       
/*  2403:      */ 
/*  2404: 2775 */       newTKBean.setValue("CLASSSTRUCTUREID", origrec.getValue("CLASSSTRUCTUREID"));
/*  2405: 2776 */       createSpecRecords(origrec, newTKBean, databean);
/*  2406:      */       
/*  2407:      */ 
/*  2408:      */ 
/*  2409: 2780 */       MobileMboDataBean fromMultiBean = databean.getDataBean("WOMULTIASSETLOCCI");
/*  2410: 2781 */       MobileMboDataBean toMultiBean = newTKBean.getDataBean("TKMULTIASSETLOCCI");
/*  2411: 2782 */       fromMultiBean.getQBE().reset();
/*  2412: 2783 */       fromMultiBean.reset();
/*  2413: 2784 */       int count = fromMultiBean.count();
/*  2414: 2785 */       for (int i = 0; i < count; i++)
/*  2415:      */       {
/*  2416: 2787 */         toMultiBean.insert();
/*  2417:      */         
/*  2418: 2789 */         MobileMbo fromMbo = fromMultiBean.getMobileMbo(i);
/*  2419: 2790 */         MobileMbo newMbo = toMultiBean.getMobileMbo();
/*  2420:      */         
/*  2421: 2792 */         fromMbo.copyAttributeValue(newMbo, "ASSETNUM");
/*  2422: 2793 */         fromMbo.copyAttributeValue(newMbo, "LOCATION");
/*  2423: 2794 */         fromMbo.copyAttributeValue(newMbo, "CINUM");
/*  2424: 2795 */         fromMbo.copyAttributeValue(newMbo, "TARGETDESC");
/*  2425: 2796 */         fromMbo.copyAttributeValue(newMbo, "TARGETDESC_LONGDESCRIPTION");
/*  2426: 2797 */         fromMbo.copyAttributeValue(newMbo, "ISPRIMARY");
/*  2427: 2798 */         fromMbo.copyAttributeValue(newMbo, "SEQUENCE");
/*  2428: 2799 */         fromMbo.copyAttributeValue(newMbo, "ORGID");
/*  2429: 2800 */         fromMbo.copyAttributeValue(newMbo, "SITEID");
/*  2430:      */         
/*  2431:      */ 
/*  2432:      */ 
/*  2433:      */ 
/*  2434:      */ 
/*  2435:      */ 
/*  2436: 2807 */         newMbo.setValue("RECORDCLASS", app.getExternalValue(databean, "TKCLASS", newtkclass));
/*  2437: 2808 */         newMbo.setValue("RECORDKEY", msg);
/*  2438:      */         
/*  2439: 2810 */         toMultiBean.setValue("COPIED", "1");
/*  2440:      */         
/*  2441:      */ 
/*  2442: 2813 */         processLinearDetails(newMbo, fromMbo, fromMbo.getValue("ASSETNUM"), fromMbo.getValue("SITEID"));
/*  2443:      */         
/*  2444: 2815 */         toMultiBean.getDataBeanManager().save();
/*  2445:      */       }
/*  2446:      */     }
/*  2447: 2823 */     MobileMboDataBean newWorkLogBean = newTKBean.getDataBean("TKWORKLOG");
/*  2448: 2824 */     String origWorkLogName = "WORKLOG";
/*  2449: 2825 */     if (databean.getName().equalsIgnoreCase("TICKET")) {
/*  2450: 2826 */       origWorkLogName = "TKWORKLOG";
/*  2451:      */     }
/*  2452: 2827 */     MobileMboDataBean origWorkLogBean = databean.getDataBean(origWorkLogName);
/*  2453: 2828 */     int count = origWorkLogBean.count();
/*  2454: 2829 */     for (int i = 0; i < count; i++)
/*  2455:      */     {
/*  2456: 2831 */       newWorkLogBean.insert();
/*  2457: 2832 */       newWorkLogBean.setValue("SITEID", origWorkLogBean.getValue(i, "SITEID"));
/*  2458: 2833 */       newWorkLogBean.setValue("RECORDKEY", origWorkLogBean.getValue(i, "RECORDKEY"));
/*  2459: 2834 */       newWorkLogBean.setValue("CLASS", origWorkLogBean.getValue(i, "CLASS"));
/*  2460: 2835 */       newWorkLogBean.setValue("CREATEBY", origWorkLogBean.getValue(i, "CREATEBY"));
/*  2461: 2836 */       newWorkLogBean.setValue("CREATEDATE", origWorkLogBean.getValue(i, "CREATEDATE"));
/*  2462: 2837 */       newWorkLogBean.setValue("LOGTYPE", origWorkLogBean.getValue(i, "LOGTYPE"));
/*  2463: 2838 */       newWorkLogBean.setValue("CLIENTVIEWABLE", origWorkLogBean.getValue(i, "CLIENTVIEWABLE"));
/*  2464: 2839 */       newWorkLogBean.setValue("DESCRIPTION", origWorkLogBean.getValue(i, "DESCRIPTION"));
/*  2465: 2840 */       newWorkLogBean.setValue("DESCRIPTION_LONGDESCRIPTION", origWorkLogBean.getValue(i, "DESCRIPTION_LONGDESCRIPTION"));
/*  2466: 2841 */       newWorkLogBean.setValue("CREATEDFROMFOLLOWUP", "1");
/*  2467:      */     }
/*  2468: 2844 */     newTKBean.getDataBeanManager().save();
/*  2469: 2849 */     if (origrec.getName().equalsIgnoreCase("WORKORDER")) {
/*  2470: 2851 */       app.addRelatedRecToWO(origrec.getValue("_ID"), origrec.getValue("WONUM"), origrec.getValue("ORGID"), origrec.getValue("SITEID"), origrec.getValue("WOCLASS"), newTKBean.getMobileMbo().getLongValue("_ID"), "TICKET", app.getDefaultValue(newTKBean, "RELATETYPE", "FOLLOWUP"), newTKBean.getValue("TICKETID"), newTKBean.getValue("ORGID"), newTKBean.getValue("SITEID"), newTKBean.getValue("CLASS"));
/*  2471:      */     } else {
/*  2472: 2867 */       app.addRelatedRecToTK(origrec.getValue("_ID"), origrec.getValue("TICKETID"), origrec.getValue("ORGID"), origrec.getValue("SITEID"), origrec.getValue("CLASS"), newTKBean.getMobileMbo().getLongValue("_ID"), "TICKET", app.getDefaultValue(newTKBean, "RELATETYPE", "FOLLOWUP"), newTKBean.getValue("TICKETID"), newTKBean.getValue("ORGID"), newTKBean.getValue("SITEID"), newTKBean.getValue("CLASS"));
/*  2473:      */     }
/*  2474: 2885 */     if (origrec.getName().equalsIgnoreCase("WORKORDER")) {
/*  2475: 2887 */       app.addRelatedRecToTK(newTKBean.getValue("_ID"), newTKBean.getValue("TICKETID"), newTKBean.getValue("ORGID"), newTKBean.getValue("SITEID"), newTKBean.getValue("CLASS"), origrec.getLongValue("_ID"), "WORKORDER", app.getDefaultValue(newTKBean, "RELATETYPE", "ORIGINATOR"), origrec.getValue("WONUM"), origrec.getValue("ORGID"), origrec.getValue("SITEID"), origrec.getValue("WOCLASS"));
/*  2476:      */     } else {
/*  2477: 2903 */       app.addRelatedRecToTK(newTKBean.getValue("_ID"), newTKBean.getValue("TICKETID"), newTKBean.getValue("ORGID"), newTKBean.getValue("SITEID"), newTKBean.getValue("CLASS"), origrec.getLongValue("_ID"), "TICKET", app.getDefaultValue(newTKBean, "RELATETYPE", "ORIGINATOR"), origrec.getValue("TICKETID"), origrec.getValue("ORGID"), origrec.getValue("SITEID"), origrec.getValue("CLASS"));
/*  2478:      */     }
/*  2479: 2918 */     setWorklistRecordBean(event, newTKBean);
/*  2480:      */     
/*  2481: 2920 */     return true;
/*  2482:      */   }
/*  2483:      */   
/*  2484:      */   public boolean capturesignature(UIEvent event)
/*  2485:      */     throws MobileApplicationException
/*  2486:      */   {
/*  2487: 2925 */     MobileMboDataBean databean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*  2488: 2926 */     if (databean != null)
/*  2489:      */     {
/*  2490: 2928 */       databean.insert();
/*  2491: 2929 */       databean.getMobileMbo().setDateValue("CHANGEDATE", databean.getCurrentTime());
/*  2492: 2930 */       databean.getMobileMbo().setBooleanValue("ISSIGNATURE", true);
/*  2493:      */     }
/*  2494: 2932 */     return true;
/*  2495:      */   }
/*  2496:      */   
/*  2497:      */   public boolean attachdoc(UIEvent event)
/*  2498:      */     throws MobileApplicationException
/*  2499:      */   {
/*  2500: 2937 */     MobileMboDataBean databean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*  2501: 2938 */     if (databean != null)
/*  2502:      */     {
/*  2503: 2940 */       databean.insert();
/*  2504: 2941 */       databean.getMobileMbo().setDateValue("CHANGEDATE", databean.getCurrentTime());
/*  2505: 2942 */       databean.getMobileMbo().setBooleanValue("ISSIGNATURE", false);
/*  2506:      */     }
/*  2507: 2944 */     return true;
/*  2508:      */   }
/*  2509:      */   
/*  2510:      */   public boolean filterppcodevalues(UIEvent event)
/*  2511:      */     throws MobileApplicationException
/*  2512:      */   {
/*  2513: 2948 */     MobileMboDataBean dropdownbean = (MobileMboDataBean)event.getValue();
/*  2514: 2949 */     MobileMboDataBean parentdatabean = ((PageControl)UIUtil.getCurrentScreen()).getLaunchingControl().getDataBean();
/*  2515: 2950 */     MobileMboDataBean trans = null;
/*  2516: 2951 */     if ("WORKORDER".equalsIgnoreCase(parentdatabean.getName())) {
/*  2517: 2952 */       trans = parentdatabean.getDataBean("WOLABTRANS");
/*  2518: 2953 */     } else if ("TICKET".equalsIgnoreCase(parentdatabean.getName())) {
/*  2519: 2954 */       trans = parentdatabean.getDataBean("TKLABTRANS");
/*  2520:      */     }
/*  2521: 2956 */     if (trans != null)
/*  2522:      */     {
/*  2523: 2957 */       String matchCraft = trans.getValue("CRAFT");
/*  2524: 2958 */       for (int i = dropdownbean.count() - 1; i > 0; i--)
/*  2525:      */       {
/*  2526: 2959 */         String craft = dropdownbean.getValue(i, "CRAFT");
/*  2527: 2960 */         if (!craft.equals(matchCraft)) {
/*  2528: 2961 */           dropdownbean.remove(i);
/*  2529:      */         }
/*  2530:      */       }
/*  2531:      */     }
/*  2532: 2965 */     return false;
/*  2533:      */   }
/*  2534:      */   
/*  2535:      */   public boolean filterstatusvalues(UIEvent event)
/*  2536:      */     throws MobileApplicationException
/*  2537:      */   {
/*  2538: 2970 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/*  2539: 2971 */     if (databean != null)
/*  2540:      */     {
/*  2541: 2973 */       MobileMboDataBean dropdownbean = (MobileMboDataBean)event.getValue();
/*  2542: 2974 */       if (databean != null)
/*  2543:      */       {
/*  2544: 2976 */         WOStatusHandler wostatushandler = new WOStatusHandler((WOApp)UIUtil.getApplication(), databean);
/*  2545: 2977 */         for (int i = dropdownbean.count() - 1; i >= 0; i--) {
/*  2546: 2980 */           if ((databean.getValue("STATUS").equals(dropdownbean.getValue(i, "VALUE"))) || (!wostatushandler.canChangeStatus(databean.getValue("STATUS"), dropdownbean.getValue(i, "VALUE")))) {
/*  2547: 2982 */             dropdownbean.remove(i);
/*  2548:      */           }
/*  2549:      */         }
/*  2550:      */       }
/*  2551:      */     }
/*  2552: 2986 */     return false;
/*  2553:      */   }
/*  2554:      */   
/*  2555:      */   public boolean filtertkstatusvalues(UIEvent event)
/*  2556:      */     throws MobileApplicationException
/*  2557:      */   {
/*  2558: 2991 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/*  2559: 2992 */     if (databean != null)
/*  2560:      */     {
/*  2561: 2994 */       MobileMboDataBean dropdownbean = (MobileMboDataBean)event.getValue();
/*  2562: 2995 */       if (databean != null)
/*  2563:      */       {
/*  2564: 2997 */         String tkclass = ((WOApp)UIUtil.getApplication()).getInternalValue(databean, "TKCLASS", databean.getValue("CLASS"));
/*  2565:      */         
/*  2566:      */ 
/*  2567:      */ 
/*  2568: 3001 */         String statuslistname = "";
/*  2569: 3002 */         if (tkclass.equals("INCIDENT")) {
/*  2570: 3003 */           statuslistname = "INCIDENTSTATUS";
/*  2571: 3004 */         } else if (tkclass.equals("PROBLEM")) {
/*  2572: 3005 */           statuslistname = "PROBLEMSTATUS";
/*  2573: 3006 */         } else if (tkclass.equals("SR")) {
/*  2574: 3007 */           statuslistname = "SRSTATUS";
/*  2575:      */         }
/*  2576: 3009 */         TKStatusHandler tkstatushandler = new TKStatusHandler((WOApp)UIUtil.getApplication(), databean, statuslistname);
/*  2577: 3010 */         for (int i = dropdownbean.count() - 1; i >= 0; i--) {
/*  2578: 3013 */           if ((databean.getValue("STATUS").equals(dropdownbean.getValue(i, "VALUE"))) || (!tkstatushandler.canChangeStatus(databean.getValue("STATUS"), dropdownbean.getValue(i, "VALUE")))) {
/*  2579: 3015 */             dropdownbean.remove(i);
/*  2580:      */           }
/*  2581:      */         }
/*  2582:      */       }
/*  2583:      */     }
/*  2584: 3019 */     return false;
/*  2585:      */   }
/*  2586:      */   
/*  2587:      */   public boolean submitSR(UIEvent event)
/*  2588:      */     throws MobileApplicationException
/*  2589:      */   {
/*  2590: 3024 */     final MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/*  2591: 3025 */     if (!UIUtil.getCurrentScreen().validateControl()) {
/*  2592: 3026 */       return true;
/*  2593:      */     }
/*  2594: 3028 */     if (UIUtil.checkESignature(event, databean, "CREATESREQ")) {
/*  2595: 3030 */       new AsyncEventHandlerSupport()
/*  2596:      */       {
/*  2597:      */         public boolean doRealWok(UIEvent event)
/*  2598:      */           throws MobileApplicationException
/*  2599:      */         {
/*  2600: 3032 */           super.updateProgressBar("processdatainprogress", null, event);
/*  2601: 3033 */           databean.done();
/*  2602: 3034 */           return true;
/*  2603:      */         }
/*  2604:      */         
/*  2605:      */         public void postRealWork(UIEvent event)
/*  2606:      */           throws MobileApplicationException
/*  2607:      */         {
/*  2608: 3037 */           UIUtil.getApplication().removeCurrentScreen(false);
/*  2609:      */         }
/*  2610: 3037 */       }.handleInBackground(event);
/*  2611:      */     } else {
/*  2612: 3043 */       event.setEventErrored();
/*  2613:      */     }
/*  2614: 3046 */     return true;
/*  2615:      */   }
/*  2616:      */   
/*  2617:      */   public boolean submitMR(UIEvent event)
/*  2618:      */     throws MobileApplicationException
/*  2619:      */   {
/*  2620: 3051 */     final MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/*  2621: 3052 */     if (!UIUtil.getCurrentScreen().validateControl()) {
/*  2622: 3053 */       return true;
/*  2623:      */     }
/*  2624: 3055 */     if (UIUtil.checkESignature(event, databean, "MATREQ"))
/*  2625:      */     {
/*  2626: 3057 */       MobileMboDataBean wodatabean = DataBeanCache.findDataBean("WORKORDER");
/*  2627: 3058 */       String origMaxStatus = ((WOApp)UIUtil.getApplication()).getInternalValue(wodatabean, "WOSTATUS", wodatabean.getValue("ORIGSTATUS"));
/*  2628: 3062 */       if ((origMaxStatus.equalsIgnoreCase("WAPPR")) || (origMaxStatus.equalsIgnoreCase("CLOSE")) || (origMaxStatus.equalsIgnoreCase("CAN")))
/*  2629:      */       {
/*  2630: 3065 */         UIUtil.showInfoMessageBox(MobileMessageGenerator.generate("mrcantbesent", new Object[0]));
/*  2631: 3066 */         databean.getDataBeanManager().save();
/*  2632:      */       }
/*  2633:      */       else
/*  2634:      */       {
/*  2635: 3070 */         new AsyncEventHandlerSupport()
/*  2636:      */         {
/*  2637:      */           public boolean doRealWok(UIEvent event)
/*  2638:      */             throws MobileApplicationException
/*  2639:      */           {
/*  2640: 3072 */             updateProgressBar("submitdata", null, event);
/*  2641: 3073 */             databean.done();
/*  2642: 3074 */             return true;
/*  2643:      */           }
/*  2644:      */           
/*  2645:      */           public void postRealWork(UIEvent event)
/*  2646:      */             throws MobileApplicationException
/*  2647:      */           {
/*  2648: 3078 */             UIUtil.getApplication().removeCurrentScreen(false);
/*  2649:      */           }
/*  2650: 3078 */         }.handleInBackground(event);
/*  2651:      */         
/*  2652:      */ 
/*  2653: 3081 */         return true;
/*  2654:      */       }
/*  2655: 3084 */       UIUtil.getApplication().removeCurrentScreen(false);
/*  2656: 3085 */       return true;
/*  2657:      */     }
/*  2658: 3089 */     event.setEventErrored();
/*  2659:      */     
/*  2660:      */ 
/*  2661: 3092 */     return true;
/*  2662:      */   }
/*  2663:      */   
/*  2664:      */   public boolean displayMRSend(UIEvent event)
/*  2665:      */     throws MobileApplicationException
/*  2666:      */   {
/*  2667: 3102 */     return true;
/*  2668:      */   }
/*  2669:      */   
/*  2670:      */   public boolean displayMROk(UIEvent event)
/*  2671:      */     throws MobileApplicationException
/*  2672:      */   {
/*  2673: 3107 */     MobileMboDataBean wodatabean = DataBeanCache.findDataBean("WORKORDER");
/*  2674: 3108 */     ((AbstractMobileControl)event.getCreatingObject()).setVisibility(wodatabean.getMobileMbo().isNew());
/*  2675:      */     
/*  2676: 3110 */     return true;
/*  2677:      */   }
/*  2678:      */   
/*  2679:      */   public boolean starttimer(UIEvent event)
/*  2680:      */     throws MobileApplicationException
/*  2681:      */   {
/*  2682: 3116 */     boolean multipletimersallowed = false;
/*  2683: 3117 */     MobileMboDataBeanManager mgrDBMgr = null;
/*  2684: 3118 */     boolean warnMultipleTimersRunning = false;
/*  2685:      */     
/*  2686: 3120 */     String propvalue = UIUtil.getApplication().getProperty("MOBILEWO.MULTILABORTIMERS");
/*  2687: 3121 */     if ((propvalue != null) && ((propvalue.toLowerCase().equals("true")) || (propvalue.equals("1")))) {
/*  2688: 3122 */       multipletimersallowed = true;
/*  2689:      */     }
/*  2690: 3124 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/*  2691: 3125 */     if (databean.getName().equals("STOPTIMER")) {
/*  2692: 3126 */       databean = ((PageControl)UIUtil.getCurrentScreen()).getLaunchingControl().getDataBean();
/*  2693:      */     }
/*  2694: 3130 */     if (UIUtil.getCurrentScreen().getId().equals("assetlists")) {
/*  2695: 3131 */       databean = databean.getDataBean("WOCHILDREN");
/*  2696: 3133 */     } else if ((databean != null) && (databean.getName().equals("WORKLIST"))) {
/*  2697: 3135 */       databean = setWorklistRecordBean(event, databean);
/*  2698:      */     }
/*  2699: 3138 */     Date currentDateTime = databean.getCurrentTime();
/*  2700: 3139 */     String recordKeyField = "WONUM";
/*  2701: 3140 */     String labtransRecordKeyField = "REFWO";
/*  2702: 3141 */     String labtransName = "WOLABTRANS";
/*  2703: 3142 */     String actStartName = "ACTSTART";
/*  2704:      */     
/*  2705: 3144 */     String labtransRecordClass = "WOCLASS";
/*  2706: 3145 */     String classField = "WOCLASS";
/*  2707: 3146 */     if (databean.getName().equalsIgnoreCase("TICKET"))
/*  2708:      */     {
/*  2709: 3148 */       labtransName = "TKLABTRANS";
/*  2710: 3149 */       labtransRecordClass = "TICKETCLASS";
/*  2711: 3150 */       labtransRecordKeyField = "TICKETID";
/*  2712: 3151 */       recordKeyField = "TICKETID";
/*  2713: 3152 */       actStartName = "ACTUALSTART";
/*  2714:      */       
/*  2715: 3154 */       classField = "CLASS";
/*  2716:      */     }
/*  2717: 3156 */     String recordKey = databean.getValue(recordKeyField);
/*  2718:      */     
/*  2719: 3158 */     MobileMboDataBean ltdatabean = databean.getDataBean(labtransName);
/*  2720:      */     
/*  2721: 3160 */     String laborcode = WOApp.getUsersLaborcode(databean.getValue("ORGID"));
/*  2722: 3161 */     if (laborcode.equals("")) {
/*  2723: 3163 */       throw new MobileApplicationException("needlaborcode");
/*  2724:      */     }
/*  2725: 3169 */     if (!event.hasPassedESig())
/*  2726:      */     {
/*  2727: 3173 */       int count = ltdatabean.count();
/*  2728: 3174 */       for (int i = 0; i < count; i++)
/*  2729:      */       {
/*  2730: 3176 */         boolean hasLabRecord = ltdatabean.getMobileMbo(i).getValue(labtransRecordKeyField).equals(recordKey);
/*  2731: 3177 */         if (databean.getName().equalsIgnoreCase("TICKET")) {
/*  2732: 3179 */           hasLabRecord = (ltdatabean.getMobileMbo(i).getValue(labtransRecordKeyField).equals(recordKey)) && (ltdatabean.getMobileMbo(i).getValue(labtransRecordClass).equals(databean.getValue("CLASS")));
/*  2733:      */         }
/*  2734: 3186 */         if ((hasLabRecord) && (ltdatabean.getMobileMbo(i).getValue("LABORCODE").equals(laborcode)) && (ltdatabean.getMobileMbo(i).getValue("TIMERSTATUS").equals(getApp().getExternalValue(ltdatabean, "TIMERSTATUS", "ACTIVE"))))
/*  2735:      */         {
/*  2736: 3191 */           if (event.getMsgResponse().equals("-1"))
/*  2737:      */           {
/*  2738: 3193 */             Object[] param = { recordKey };
/*  2739: 3194 */             UIUtil.showYESNOCANCELMessageBox(event, MobileMessageGenerator.generate("onetimerrunning", param));
/*  2740: 3195 */             event.setEventErrored();
/*  2741: 3196 */             return true;
/*  2742:      */           }
/*  2743: 3198 */           if (event.getMsgResponse().equals("1"))
/*  2744:      */           {
/*  2745: 3200 */             if (databean.getName().equalsIgnoreCase("WORKORDER")) {
/*  2746: 3201 */               UIUtil.gotoPage("stopthenstarttimer", (AbstractMobileControl)event.getCreatingObject());
/*  2747: 3202 */             } else if (databean.getName().equalsIgnoreCase("TICKET")) {
/*  2748: 3203 */               UIUtil.gotoPage("tkstopthenstarttimer", (AbstractMobileControl)event.getCreatingObject());
/*  2749:      */             }
/*  2750: 3204 */             return true;
/*  2751:      */           }
/*  2752: 3206 */           if ((!event.getMsgResponse().equals("0")) && (!event.getMsgResponse().equals("2"))) {
/*  2753:      */             break;
/*  2754:      */           }
/*  2755: 3211 */           return true;
/*  2756:      */         }
/*  2757:      */       }
/*  2758: 3221 */       MobileMboDataBeanManager mgrWODBMgr = new MobileMboDataBeanManager("WOLABTRANS");
/*  2759: 3222 */       MobileMboDataBean wolabtransBean = mgrWODBMgr.getDataBean();
/*  2760: 3223 */       wolabtransBean.getQBE().reset();
/*  2761: 3224 */       wolabtransBean.getQBE().setQbeExactMatch(true);
/*  2762: 3225 */       wolabtransBean.getQBE().setQBE("LABORCODE", laborcode);
/*  2763:      */       
/*  2764: 3227 */       wolabtransBean.getQBE().setQBE("TIMERSTATUS", getApp().getExternalValue(wolabtransBean, "TIMERSTATUS", "ACTIVE"));
/*  2765: 3228 */       wolabtransBean.reset();
/*  2766: 3229 */       int wocount = wolabtransBean.count();
/*  2767:      */       
/*  2768: 3231 */       MobileMboDataBeanManager mgrTKDBMgr = new MobileMboDataBeanManager("TKLABTRANS");
/*  2769: 3232 */       MobileMboDataBean tklabtransBean = mgrTKDBMgr.getDataBean();
/*  2770: 3233 */       tklabtransBean.getQBE().reset();
/*  2771: 3234 */       tklabtransBean.getQBE().setQbeExactMatch(true);
/*  2772: 3235 */       tklabtransBean.getQBE().setQBE("LABORCODE", laborcode);
/*  2773:      */       
/*  2774: 3237 */       tklabtransBean.getQBE().setQBE("TIMERSTATUS", getApp().getExternalValue(wolabtransBean, "TIMERSTATUS", "ACTIVE"));
/*  2775: 3238 */       tklabtransBean.reset();
/*  2776: 3239 */       int tkcount = tklabtransBean.count();
/*  2777:      */       
/*  2778: 3241 */       count = wocount + tkcount;
/*  2779: 3242 */       if (count == 1)
/*  2780:      */       {
/*  2781: 3245 */         if (event.getMsgResponse().equals("-1"))
/*  2782:      */         {
/*  2783: 3247 */           String value = "";
/*  2784: 3248 */           if (wocount == 1) {
/*  2785: 3249 */             value = wolabtransBean.getMobileMbo(0).getValue("REFWO");
/*  2786:      */           }
/*  2787: 3250 */           if (tkcount == 1) {
/*  2788: 3251 */             value = tklabtransBean.getMobileMbo(0).getValue("TICKETID");
/*  2789:      */           }
/*  2790: 3252 */           Object[] param = { value };
/*  2791: 3254 */           if (!multipletimersallowed) {
/*  2792: 3255 */             UIUtil.showOKCANCELMessageBox(event, MobileMessageGenerator.generate("onetimerrunnomultiple", param));
/*  2793:      */           } else {
/*  2794: 3257 */             UIUtil.showYESNOCANCELMessageBox(event, MobileMessageGenerator.generate("onetimerrunning", param));
/*  2795:      */           }
/*  2796: 3259 */           event.setEventErrored();
/*  2797: 3260 */           return true;
/*  2798:      */         }
/*  2799: 3263 */         if ((event.getMsgResponse().equals("1")) || (event.getMsgResponse().equals("1")))
/*  2800:      */         {
/*  2801: 3267 */           if (wocount == 1) {
/*  2802: 3268 */             UIUtil.gotoPage("stopthenstarttimer", (AbstractMobileControl)event.getCreatingObject());
/*  2803: 3269 */           } else if (tkcount == 1) {
/*  2804: 3270 */             UIUtil.gotoPage("tkstopthenstarttimer", (AbstractMobileControl)event.getCreatingObject());
/*  2805:      */           }
/*  2806: 3272 */           return true;
/*  2807:      */         }
/*  2808: 3274 */         if ((!multipletimersallowed) || (!event.getMsgResponse().equals("0"))) {
/*  2809: 3280 */           if (event.getMsgResponse().equals("2")) {
/*  2810: 3284 */             return true;
/*  2811:      */           }
/*  2812:      */         }
/*  2813:      */       }
/*  2814: 3287 */       else if (count > 0)
/*  2815:      */       {
/*  2816: 3290 */         warnMultipleTimersRunning = true;
/*  2817:      */       }
/*  2818:      */     }
/*  2819: 3294 */     if (UIUtil.checkESignature(event, databean, "LABACTUALS,STARTTIMER"))
/*  2820:      */     {
/*  2821: 3297 */       ltdatabean.insert();
/*  2822:      */       
/*  2823: 3299 */       ltdatabean.setValue("ORGID", databean.getValue("ORGID"));
/*  2824: 3300 */       ltdatabean.setValue("SITEID", databean.getValue("SITEID"));
/*  2825:      */       
/*  2826: 3302 */       ltdatabean.setValue("LABORCODE", laborcode);
/*  2827: 3303 */       ltdatabean.setValue(labtransRecordKeyField, recordKey);
/*  2828: 3304 */       if (!labtransRecordClass.equalsIgnoreCase("")) {
/*  2829: 3307 */         ltdatabean.setValue(labtransRecordClass, databean.getValue(classField));
/*  2830:      */       }
/*  2831: 3311 */       mgrDBMgr = new MobileMboDataBeanManager("LABORCRAFTRATE");
/*  2832: 3312 */       MobileMboDataBean lcrBean = mgrDBMgr.getDataBean();
/*  2833: 3313 */       lcrBean.getQBE().reset();
/*  2834: 3314 */       lcrBean.getQBE().setQbeExactMatch(true);
/*  2835: 3315 */       lcrBean.getQBE().setQBE("ORGID", ltdatabean.getValue("ORGID"));
/*  2836: 3316 */       lcrBean.getQBE().setQBE("LABORCODE", laborcode);
/*  2837: 3317 */       lcrBean.getQBE().setQBE("DEFAULTCRAFT", "1");
/*  2838: 3318 */       lcrBean.reset();
/*  2839: 3319 */       MobileMbo lcrMbo = lcrBean.getMobileMbo(0);
/*  2840: 3320 */       if (lcrMbo != null)
/*  2841:      */       {
/*  2842: 3322 */         ltdatabean.setValue("CRAFT", lcrMbo.getValue("CRAFT"));
/*  2843: 3323 */         ltdatabean.setValue("SKILLLEVEL", lcrMbo.getValue("SKILLLEVEL"));
/*  2844: 3324 */         ltdatabean.setValue("VENDOR", lcrMbo.getValue("VENDOR"));
/*  2845: 3325 */         ltdatabean.setValue("CONTRACTNUM", lcrMbo.getValue("CONTRACTNUM"));
/*  2846:      */       }
/*  2847: 3328 */       ltdatabean.setValue("TIMERSTATUS", getApp().getExternalValue(ltdatabean, "TIMERSTATUS", "ACTIVE"));
/*  2848: 3329 */       ltdatabean.getMobileMbo().setDateValue("STARTDATE", WOApp.getDateFromDate(currentDateTime));
/*  2849: 3330 */       ltdatabean.getMobileMbo().setDateValue("STARTTIME", WOApp.getTimeFromDate(currentDateTime));
/*  2850: 3331 */       ltdatabean.setValue("GENAPPRSERVRECEIPT", "0");
/*  2851: 3335 */       if (databean.getValue(actStartName).equals("")) {
/*  2852: 3337 */         databean.getMobileMbo().setDateValue(actStartName, currentDateTime);
/*  2853: 3339 */       } else if (databean.getMobileMbo().getDateValue(actStartName).after(currentDateTime)) {
/*  2854: 3344 */         databean.getMobileMbo().setDateValue(actStartName, currentDateTime);
/*  2855:      */       }
/*  2856: 3346 */       databean.setValue("ISTIMERRUNNING", "1");
/*  2857: 3349 */       if (UIUtil.getCurrentScreen().getId().equals("assetlists"))
/*  2858:      */       {
/*  2859: 3350 */         MobileMboDataBean woBean = DataBeanCache.getDataBean("WORKLIST", "WORKLIST");
/*  2860: 3351 */         if (woBean != null)
/*  2861:      */         {
/*  2862: 3352 */           woBean.getQBE().setQBE("RECORDID", databean.getValue("WONUM"));
/*  2863: 3353 */           woBean.getQBE().setQBE("SITEID", databean.getValue("SITEID"));
/*  2864: 3354 */           woBean.reset();
/*  2865: 3355 */           woBean.setValue("ISTIMERRUNNING", "1");
/*  2866:      */         }
/*  2867:      */       }
/*  2868: 3359 */       if (isStartTimeConfiguredToMoveToInprog(databean))
/*  2869:      */       {
/*  2870: 3360 */         changeRecordToInProgressIfNeeded(databean, databean.getMobileMbo(), event, warnMultipleTimersRunning);
/*  2871:      */       }
/*  2872:      */       else
/*  2873:      */       {
/*  2874: 3362 */         if (warnMultipleTimersRunning) {
/*  2875: 3363 */           showWarnOfMultipleTimers();
/*  2876:      */         }
/*  2877: 3365 */         databean.getDataBeanManager().save();
/*  2878: 3366 */         UIUtil.refreshCurrentScreen();
/*  2879:      */       }
/*  2880:      */     }
/*  2881: 3369 */     return true;
/*  2882:      */   }
/*  2883:      */   
/*  2884:      */   private void showWarnOfMultipleTimers()
/*  2885:      */   {
/*  2886: 3373 */     String msg = MobileMessageGenerator.generate("manytimersrunning", new Object[0]);
/*  2887: 3374 */     UIUtil.showInfoMessageBox(msg);
/*  2888:      */   }
/*  2889:      */   
/*  2890:      */   private void changeRecordToInProgressIfNeeded(MobileMboDataBean refDataBean, MobileMbo record, UIEvent refEvent, boolean warnMultipleTimersRunning)
/*  2891:      */     throws MobileApplicationException
/*  2892:      */   {
/*  2893: 3379 */     if ((isWorkOrderRecord(record)) && (WOChangeStatusEventHandler.isApprStatus(refDataBean)))
/*  2894:      */     {
/*  2895: 3381 */       WOChangeStatusEventHandler handler = (WOChangeStatusEventHandler)UIHandlerManager.getInstance().getUIHandler("wochangestatushandler");
/*  2896: 3382 */       handler.startWorkOrder(refDataBean, record, refEvent);
/*  2897:      */     }
/*  2898:      */     else
/*  2899:      */     {
/*  2900: 3384 */       if (warnMultipleTimersRunning) {
/*  2901: 3385 */         showWarnOfMultipleTimers();
/*  2902:      */       }
/*  2903: 3387 */       refDataBean.getDataBeanManager().save();
/*  2904: 3388 */       UIUtil.refreshCurrentScreen();
/*  2905:      */     }
/*  2906:      */   }
/*  2907:      */   
/*  2908:      */   protected static boolean isWorkOrderRecord(MobileMbo record)
/*  2909:      */   {
/*  2910: 3393 */     return (record.getName().equals("WORKORDER")) || (record.getName().equals("WOCHILDREN")) || (record.getName().equals("WOACTIVITY"));
/*  2911:      */   }
/*  2912:      */   
/*  2913:      */   protected static boolean isStartTimeConfiguredToMoveToInprog(MobileMboDataBean databean)
/*  2914:      */     throws MobileApplicationException
/*  2915:      */   {
/*  2916: 3397 */     String maxvar = ((WOApp)UIUtil.getApplication()).getMaxVar(databean, "STARTTIMERINPRG");
/*  2917: 3398 */     return (maxvar != null) && (maxvar.equals("1"));
/*  2918:      */   }
/*  2919:      */   
/*  2920:      */   protected static boolean isTimerConfiguredToNotConfirm(MobileMboDataBean databean)
/*  2921:      */     throws MobileApplicationException
/*  2922:      */   {
/*  2923: 3402 */     String maxvar = ((WOApp)UIUtil.getApplication()).getMaxVar(databean, "CONFIRMLABTRANS");
/*  2924: 3403 */     return (maxvar != null) && (maxvar.equals("0"));
/*  2925:      */   }
/*  2926:      */   
/*  2927:      */   protected static boolean getStopTimerDefaultCompleteState(MobileMboDataBean databean)
/*  2928:      */     throws MobileApplicationException
/*  2929:      */   {
/*  2930: 3407 */     String maxvar = ((WOApp)UIUtil.getApplication()).getMaxVar(databean, "STOPTIMERCOMP");
/*  2931: 3408 */     return (maxvar != null) && (maxvar.equals("1"));
/*  2932:      */   }
/*  2933:      */   
/*  2934:      */   public boolean stoptimer(UIEvent event)
/*  2935:      */     throws MobileApplicationException
/*  2936:      */   {
/*  2937: 3414 */     MobileMboDataBean wodatabean = UIUtil.getCurrentScreen().getDataBean();
/*  2938: 3418 */     if (UIUtil.getCurrentScreen().getId().equals("assetlists")) {
/*  2939: 3419 */       wodatabean = wodatabean.getDataBean("WOCHILDREN");
/*  2940: 3421 */     } else if ((wodatabean != null) && (wodatabean.getName().equals("WORKLIST"))) {
/*  2941: 3423 */       wodatabean = setWorklistRecordBean(event, null);
/*  2942:      */     }
/*  2943: 3426 */     String recordKeyField = "WONUM";
/*  2944: 3427 */     String labtransRecordKeyField = "REFWO";
/*  2945: 3428 */     String labtransRecordClass = "";
/*  2946: 3429 */     String labtransName = "WOLABTRANS";
/*  2947: 3430 */     if (wodatabean.getName().equalsIgnoreCase("TICKET"))
/*  2948:      */     {
/*  2949: 3432 */       labtransName = "TKLABTRANS";
/*  2950: 3433 */       labtransRecordClass = "TICKETCLASS";
/*  2951: 3434 */       labtransRecordKeyField = "TICKETID";
/*  2952: 3435 */       recordKeyField = "TICKETID";
/*  2953:      */     }
/*  2954: 3437 */     String recordKey = wodatabean.getValue(recordKeyField);
/*  2955:      */     
/*  2956: 3439 */     MobileMboDataBean ltdatabean = wodatabean.getDataBean(labtransName);
/*  2957:      */     
/*  2958: 3441 */     boolean runningtimerfound = false;
/*  2959:      */     
/*  2960: 3443 */     String laborcode = WOApp.getUsersLaborcode(wodatabean.getValue("ORGID"));
/*  2961: 3444 */     if (laborcode.equals("")) {
/*  2962: 3446 */       throw new MobileApplicationException("needlaborcode");
/*  2963:      */     }
/*  2964: 3449 */     int count = ltdatabean.count();
/*  2965: 3450 */     for (int i = 0; i < count; i++)
/*  2966:      */     {
/*  2967: 3452 */       boolean hasLabRecord = ltdatabean.getMobileMbo(i).getValue(labtransRecordKeyField).equals(recordKey);
/*  2968: 3453 */       if (wodatabean.getName().equalsIgnoreCase("TICKET")) {
/*  2969: 3455 */         hasLabRecord = (ltdatabean.getMobileMbo(i).getValue(labtransRecordKeyField).equals(recordKey)) && (ltdatabean.getMobileMbo(i).getValue(labtransRecordClass).equals(wodatabean.getValue("CLASS")));
/*  2970:      */       }
/*  2971: 3460 */       if ((hasLabRecord) && (ltdatabean.getMobileMbo(i).getValue("LABORCODE").equals(laborcode)) && (ltdatabean.getMobileMbo(i).getValue("TIMERSTATUS").equals(getApp().getExternalValue(ltdatabean, "TIMERSTATUS", "ACTIVE"))))
/*  2972:      */       {
/*  2973: 3464 */         runningtimerfound = true;
/*  2974: 3465 */         break;
/*  2975:      */       }
/*  2976:      */     }
/*  2977: 3469 */     if (runningtimerfound)
/*  2978:      */     {
/*  2979: 3471 */       if (wodatabean.getName().equalsIgnoreCase("WORKORDER"))
/*  2980:      */       {
/*  2981: 3472 */         UIUtil.gotoPage("stoptimer", (AbstractMobileControl)event.getCreatingObject());
/*  2982:      */       }
/*  2983: 3473 */       else if (wodatabean.getName().equalsIgnoreCase("TICKET"))
/*  2984:      */       {
/*  2985: 3474 */         UIUtil.gotoPage("tkstoptimer", (AbstractMobileControl)event.getCreatingObject());
/*  2986:      */       }
/*  2987: 3476 */       else if (wodatabean.getName().equalsIgnoreCase("WOCHILDREN"))
/*  2988:      */       {
/*  2989: 3477 */         MobileMboDataBean woBean = DataBeanCache.getDataBean("WORKORDER_CHILDREN", "WORKORDER");
/*  2990: 3478 */         if (woBean != null)
/*  2991:      */         {
/*  2992: 3480 */           woBean.getQBE().setQBE("WONUM", wodatabean.getValue("WONUM"));
/*  2993: 3481 */           woBean.getQBE().setQBE("SITEID", wodatabean.getValue("SITEID"));
/*  2994: 3482 */           woBean.reset();
/*  2995: 3483 */           UIUtil.gotoPage("stoptimerfromchild", (AbstractMobileControl)event.getCreatingObject());
/*  2996:      */         }
/*  2997:      */       }
/*  2998:      */     }
/*  2999:      */     else
/*  3000:      */     {
/*  3001: 3489 */       Object[] param = { wodatabean.getValue(recordKeyField) };
/*  3002: 3490 */       String msg = MobileMessageGenerator.generate("notimersrunning", param);
/*  3003: 3491 */       UIUtil.showInfoMessageBox(msg);
/*  3004:      */     }
/*  3005: 3494 */     return true;
/*  3006:      */   }
/*  3007:      */   
/*  3008:      */   public boolean toggletimerbuttonstate(UIEvent event)
/*  3009:      */     throws MobileApplicationException
/*  3010:      */   {
/*  3011: 3499 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/*  3012:      */     
/*  3013:      */ 
/*  3014: 3502 */     String[] timersOnWO = { "timerOnA", "timerOnB", "lr_timerOnB", "timerOnC" };
/*  3015: 3503 */     String[] timersOffWO = { "timerOffA", "timerOffB", "lr_timerOffB", "timerOffC" };
/*  3016:      */     
/*  3017:      */ 
/*  3018: 3506 */     String[] timersOnTK = { "tktimerOnA" };
/*  3019: 3507 */     String[] timersOffTK = { "tktimerOffA" };
/*  3020:      */     
/*  3021:      */ 
/*  3022: 3510 */     boolean canEnterActuals = false;
/*  3023: 3511 */     if (databean.getName().equalsIgnoreCase("WORKORDER")) {
/*  3024: 3512 */       canEnterActuals = canEnterActualsOnWO(databean);
/*  3025:      */     }
/*  3026: 3513 */     if (databean.getName().equalsIgnoreCase("TICKET")) {
/*  3027: 3514 */       canEnterActuals = canEnterActualsOnTicket(databean);
/*  3028:      */     }
/*  3029: 3516 */     if (canEnterActuals)
/*  3030:      */     {
/*  3031: 3518 */       ((AbstractMobileControl)event.getCreatingObject()).setVisibility(true);
/*  3032: 3519 */       boolean istimerrunning = isTimerRunning(databean);
/*  3033: 3520 */       StateControl state = (StateControl)event.getCreatingObject();
/*  3034: 3521 */       if (istimerrunning)
/*  3035:      */       {
/*  3036: 3524 */         setNewStates(state, timersOffWO);
/*  3037: 3525 */         setNewStates(state, timersOffTK);
/*  3038:      */       }
/*  3039:      */       else
/*  3040:      */       {
/*  3041: 3530 */         setNewStates(state, timersOnWO);
/*  3042: 3531 */         setNewStates(state, timersOnTK);
/*  3043:      */       }
/*  3044:      */     }
/*  3045:      */     else
/*  3046:      */     {
/*  3047: 3536 */       ((AbstractMobileControl)event.getCreatingObject()).setVisibility(false);
/*  3048:      */     }
/*  3049: 3539 */     return true;
/*  3050:      */   }
/*  3051:      */   
/*  3052:      */   private void setNewStates(StateControl state, String[] fields)
/*  3053:      */     throws MobileApplicationException
/*  3054:      */   {
/*  3055: 3543 */     int i = 0;
/*  3056: 3544 */     for (i = 0; i < fields.length; i++) {
/*  3057: 3545 */       state.setNewState(fields[i]);
/*  3058:      */     }
/*  3059:      */   }
/*  3060:      */   
/*  3061:      */   public boolean displayslaicon(UIEvent event)
/*  3062:      */     throws MobileApplicationException
/*  3063:      */   {
/*  3064: 3551 */     MobileMboDataBean wodatabean = UIUtil.getCurrentScreen().getDataBean();
/*  3065: 3552 */     boolean bShow = false;
/*  3066: 3553 */     if (wodatabean.getValue("SLAAPPLIED").equals("1")) {
/*  3067: 3554 */       bShow = true;
/*  3068:      */     }
/*  3069: 3556 */     ((AbstractMobileControl)event.getCreatingObject()).setVisibility(bShow);
/*  3070:      */     
/*  3071: 3558 */     return true;
/*  3072:      */   }
/*  3073:      */   
/*  3074:      */   public boolean isTimerRunning(MobileMboDataBean databean)
/*  3075:      */     throws MobileApplicationException
/*  3076:      */   {
/*  3077: 3563 */     boolean istimerrunning = false;
/*  3078: 3565 */     if (databean.getCurrentPosition() == -1) {
/*  3079: 3566 */       return false;
/*  3080:      */     }
/*  3081: 3568 */     if (databean.getValue("ISTIMERRUNNING").equals("0")) {
/*  3082: 3569 */       return false;
/*  3083:      */     }
/*  3084: 3570 */     if (databean.getValue("ISTIMERRUNNING").equals("1")) {
/*  3085: 3571 */       return true;
/*  3086:      */     }
/*  3087: 3575 */     String labtransName = "WOLABTRANS";
/*  3088: 3576 */     if (databean.getName().equalsIgnoreCase("TICKET")) {
/*  3089: 3577 */       labtransName = "TKLABTRANS";
/*  3090:      */     }
/*  3091: 3578 */     MobileMboDataBean ltdatabean = databean.getDataBean(labtransName);
/*  3092: 3579 */     if ((ltdatabean == null) || (ltdatabean.count() == 0)) {
/*  3093: 3580 */       return false;
/*  3094:      */     }
/*  3095: 3581 */     String laborcode = WOApp.getUsersLaborcode(databean.getValue("ORGID"));
/*  3096: 3582 */     if (laborcode.equals("")) {
/*  3097: 3583 */       return false;
/*  3098:      */     }
/*  3099: 3585 */     String wonum = databean.getValue("WONUM");
/*  3100:      */     
/*  3101:      */ 
/*  3102: 3588 */     int count = ltdatabean.count();
/*  3103: 3589 */     for (int i = 0; i < count; i++) {
/*  3104: 3591 */       if ((ltdatabean.getMobileMbo(i).getValue("REFWO").equals(wonum)) && (ltdatabean.getMobileMbo(i).getValue("LABORCODE").equals(laborcode)) && (ltdatabean.getMobileMbo(i).getValue("TIMERSTATUS").equals(getApp().getExternalValue(ltdatabean, "TIMERSTATUS", "ACTIVE"))))
/*  3105:      */       {
/*  3106: 3595 */         istimerrunning = true;
/*  3107: 3596 */         break;
/*  3108:      */       }
/*  3109:      */     }
/*  3110: 3599 */     if (istimerrunning) {
/*  3111: 3600 */       databean.setValue("ISTIMERRUNNING", "1");
/*  3112:      */     } else {
/*  3113: 3602 */       databean.setValue("ISTIMERRUNNING", "0");
/*  3114:      */     }
/*  3115: 3605 */     return istimerrunning;
/*  3116:      */   }
/*  3117:      */   
/*  3118:      */   public boolean setworkliststyle(UIEvent event)
/*  3119:      */     throws MobileApplicationException
/*  3120:      */   {
/*  3121: 3610 */     MobileMboDataBean wodatabean = UIUtil.getCurrentScreen().getDataBean();
/*  3122: 3611 */     boolean istimerrunning = isTimerRunning(wodatabean);
/*  3123: 3613 */     if (istimerrunning) {
/*  3124: 3615 */       event.setValue(StyleManager.getStyle("rowtimeron.table", null));
/*  3125:      */     }
/*  3126: 3618 */     return true;
/*  3127:      */   }
/*  3128:      */   
/*  3129:      */   public boolean setassetliststyle(UIEvent event)
/*  3130:      */     throws MobileApplicationException
/*  3131:      */   {
/*  3132: 3623 */     MobileMboDataBean wodatabean = UIUtil.getCurrentScreen().getDataBean();
/*  3133: 3624 */     wodatabean = wodatabean.getDataBean("WOCHILDREN");
/*  3134:      */     
/*  3135: 3626 */     boolean istimerrunning = isTimerRunning(wodatabean);
/*  3136: 3628 */     if (istimerrunning) {
/*  3137: 3630 */       event.setValue(StyleManager.getStyle("rowtimeron.table", null));
/*  3138:      */     }
/*  3139: 3633 */     return true;
/*  3140:      */   }
/*  3141:      */   
/*  3142:      */   public int getNextTaskID(int maxTask, String seedName, String intervalName, MobileMboDataBean databean)
/*  3143:      */     throws MobileApplicationException
/*  3144:      */   {
/*  3145: 3640 */     String sTaskSeed = ((WOApp)UIUtil.getApplication()).getMaxVar(databean, "TASKSEED");
/*  3146: 3641 */     String sTaskInterval = ((WOApp)UIUtil.getApplication()).getMaxVar(databean, "TASKINTERVAL");
/*  3147:      */     
/*  3148: 3643 */     int taskSeed = 0;
/*  3149: 3644 */     int taskInterval = 0;
/*  3150: 3646 */     if (sTaskSeed != null) {
/*  3151: 3647 */       taskSeed = new Integer(sTaskSeed).intValue();
/*  3152:      */     }
/*  3153: 3648 */     if (sTaskInterval != null) {
/*  3154: 3649 */       taskInterval = new Integer(sTaskInterval).intValue();
/*  3155:      */     }
/*  3156:      */     int nextTask;
/*  3157:      */     int nextTask;
/*  3158: 3651 */     if (maxTask < taskSeed) {
/*  3159: 3653 */       nextTask = taskSeed;
/*  3160:      */     } else {
/*  3161: 3657 */       nextTask = maxTask - (maxTask - taskSeed) % taskInterval + taskInterval;
/*  3162:      */     }
/*  3163: 3660 */     return nextTask;
/*  3164:      */   }
/*  3165:      */   
/*  3166:      */   private Vector scan4Parents(UIEvent inEvent)
/*  3167:      */     throws MobileApplicationException
/*  3168:      */   {
/*  3169: 3667 */     this.worklistTreeCache.clear();
/*  3170: 3668 */     AbstractMobileControl calledControl = (AbstractMobileControl)inEvent.getCreatingObject();
/*  3171: 3669 */     MobileMboDataBean worklistBean = DataBeanCache.getDataBean("DRILLDOWNWORKLIST", "WORKLIST");
/*  3172:      */     
/*  3173: 3671 */     worklistBean.getQBE().reset();
/*  3174: 3672 */     worklistBean.reset();
/*  3175: 3673 */     worklistBean.getMobileMbo();
/*  3176: 3674 */     Vector parentVector = new Vector();
/*  3177:      */     
/*  3178: 3676 */     int count = worklistBean.count();
/*  3179: 3677 */     for (int i = 0; i < count; i++)
/*  3180:      */     {
/*  3181: 3678 */       String parentRec = null;
/*  3182: 3679 */       String parentRecClass = null;
/*  3183: 3680 */       String description = null;
/*  3184: 3681 */       String keyValue = null;
/*  3185: 3682 */       String label = null;
/*  3186: 3683 */       String type = null;
/*  3187: 3685 */       if (worklistBean.getMobileMbo(i).isNull("PARENT"))
/*  3188:      */       {
/*  3189: 3686 */         parentRec = worklistBean.getValue(i, "RECORDID");
/*  3190: 3687 */         parentRecClass = getInternalRecordClass(worklistBean, worklistBean.getValue(i, "CLASS"));
/*  3191: 3688 */         description = worklistBean.getValue(i, "DESCRIPTION");
/*  3192:      */         
/*  3193:      */ 
/*  3194: 3691 */         keyValue = parentRecClass + "::" + parentRec;
/*  3195: 3692 */         label = parentRec + " - " + description;
/*  3196: 3693 */         type = worklistBean.getName();
/*  3197:      */       }
/*  3198:      */       else
/*  3199:      */       {
/*  3200: 3697 */         String parentRecId = worklistBean.getValue(i, "PARENT");
/*  3201: 3698 */         String siteId = worklistBean.getValue("SITEID");
/*  3202:      */         
/*  3203: 3700 */         MobileMboDataBean auxAssetBean = findRecordsInDevice("WORKLIST", new String[] { "RECORDID", "SITEID" }, new String[] { parentRecId, siteId });
/*  3204: 3703 */         if (auxAssetBean == null)
/*  3205:      */         {
/*  3206: 3705 */           parentRec = worklistBean.getValue(i, "RECORDID");
/*  3207: 3706 */           parentRecClass = getInternalRecordClass(worklistBean, worklistBean.getValue(i, "CLASS"));
/*  3208: 3707 */           description = worklistBean.getValue(i, "DESCRIPTION");
/*  3209:      */           
/*  3210:      */ 
/*  3211: 3710 */           keyValue = parentRecClass + "::" + parentRec;
/*  3212: 3711 */           label = parentRec + " - " + description;
/*  3213: 3712 */           type = worklistBean.getName();
/*  3214:      */         }
/*  3215:      */       }
/*  3216: 3716 */       if (parentRec != null)
/*  3217:      */       {
/*  3218: 3718 */         TreeNodeData beanLocator = createTreeData(calledControl, i, worklistBean, type, keyValue, label, null, "treetest1");
/*  3219:      */         
/*  3220: 3720 */         parentVector.add(beanLocator);
/*  3221:      */       }
/*  3222:      */     }
/*  3223: 3724 */     return parentVector;
/*  3224:      */   }
/*  3225:      */   
/*  3226:      */   private TreeNodeData createTreeData(AbstractMobileControl calledControl, int index, MobileMboDataBean databean, String type, String keyValue, String label, String img, String popKey)
/*  3227:      */     throws MobileApplicationException
/*  3228:      */   {
/*  3229: 3734 */     TreeNodeData beanLocator = new TreeNodeData(index, type, keyValue, true);
/*  3230: 3735 */     beanLocator.setChildDataBean(databean);
/*  3231:      */     
/*  3232: 3737 */     UIComponent displayPanel = calledControl.createDataPanel(calledControl, label, img, popKey, databean, beanLocator);
/*  3233: 3738 */     beanLocator.setDisplayPanel(displayPanel);
/*  3234: 3739 */     return beanLocator;
/*  3235:      */   }
/*  3236:      */   
/*  3237:      */   public MobileMboDataBean findRecordsInDevice(String mobileMboName, String[] keyField, String[] keyValue)
/*  3238:      */     throws MobileApplicationException
/*  3239:      */   {
/*  3240: 3744 */     return findRecordsInDevice(mobileMboName, "$" + mobileMboName, keyField, keyValue);
/*  3241:      */   }
/*  3242:      */   
/*  3243:      */   public MobileMboDataBean findRecordsInDevice(String mobileMboName, String databeanCacheName, String[] keyField, String[] keyValue)
/*  3244:      */     throws MobileApplicationException
/*  3245:      */   {
/*  3246: 3749 */     if ((mobileMboName == null) || (mobileMboName.trim().equals(""))) {
/*  3247: 3751 */       return null;
/*  3248:      */     }
/*  3249: 3753 */     if ((keyField == null) || (keyField.length == 0)) {
/*  3250: 3755 */       return null;
/*  3251:      */     }
/*  3252: 3757 */     if ((keyValue == null) || (keyValue.length == 0)) {
/*  3253: 3759 */       return null;
/*  3254:      */     }
/*  3255: 3761 */     if (keyField.length != keyValue.length) {
/*  3256: 3763 */       return null;
/*  3257:      */     }
/*  3258: 3766 */     MobileMboDataBean databean = DataBeanCache.getDataBean(databeanCacheName, mobileMboName);
/*  3259:      */     
/*  3260: 3768 */     databean.getQBE().reset();
/*  3261: 3769 */     for (int i = 0; i < keyField.length; i++) {
/*  3262: 3771 */       databean.getQBE().setQBE(keyField[i], keyValue[i]);
/*  3263:      */     }
/*  3264: 3773 */     databean.reset();
/*  3265: 3774 */     databean.getMobileMbo();
/*  3266: 3775 */     if (databean.getMobileMbo() != null) {
/*  3267: 3777 */       return databean;
/*  3268:      */     }
/*  3269: 3779 */     return null;
/*  3270:      */   }
/*  3271:      */   
/*  3272:      */   private void setRecordPositionInWorkList(String[] keyField, String[] keyValue)
/*  3273:      */     throws MobileApplicationException
/*  3274:      */   {
/*  3275: 3787 */     MobileMboDataBean dataBean = DataBeanCache.getDataBean("WORKLIST", "WORKLIST");
/*  3276: 3788 */     int beanCount = dataBean.count();
/*  3277: 3789 */     int keysCount = keyField.length;
/*  3278: 3791 */     for (int i = 0; i < beanCount; i++)
/*  3279:      */     {
/*  3280: 3793 */       boolean match = true;
/*  3281: 3794 */       for (int j = 0; j < keysCount; j++) {
/*  3282: 3797 */         if (!dataBean.getMobileMbo(i).getValue(keyField[j]).equals(keyValue[j]))
/*  3283:      */         {
/*  3284: 3799 */           match = false;
/*  3285: 3800 */           break;
/*  3286:      */         }
/*  3287:      */       }
/*  3288: 3804 */       if (match)
/*  3289:      */       {
/*  3290: 3806 */         dataBean.setCurrentPosition(i);
/*  3291: 3807 */         return;
/*  3292:      */       }
/*  3293:      */     }
/*  3294:      */   }
/*  3295:      */   
/*  3296:      */   private Vector scan4Children(UIEvent event)
/*  3297:      */     throws MobileApplicationException
/*  3298:      */   {
/*  3299: 3816 */     Vector childVector = new Vector();
/*  3300: 3817 */     AbstractMobileControl calledControl = (AbstractMobileControl)event.getCreatingObject();
/*  3301: 3818 */     TreeNodeData data = (TreeNodeData)event.getValue();
/*  3302: 3819 */     String keyValue = data.getDisplayValue();
/*  3303: 3821 */     if (this.worklistTreeCache.containsKey(keyValue)) {
/*  3304: 3823 */       return (Vector)this.worklistTreeCache.get(keyValue);
/*  3305:      */     }
/*  3306: 3826 */     MobileMboDataBean parentDataBean = data.getChildDataBean();
/*  3307:      */     
/*  3308: 3828 */     int sepPos = keyValue.indexOf("::");
/*  3309: 3829 */     String parentRecClass = keyValue.substring(0, sepPos);
/*  3310:      */     
/*  3311: 3831 */     int currentIndex = data.getIndex();
/*  3312: 3832 */     if (parentDataBean.getName().equalsIgnoreCase("WORKLIST"))
/*  3313:      */     {
/*  3314: 3834 */       long recId = parentDataBean.getMobileMbo(currentIndex).getLongValue("_RECID");
/*  3315: 3835 */       String mobileMboName = getMobileMboNameForClass(parentRecClass);
/*  3316: 3836 */       parentDataBean = findRecordsInDevice(mobileMboName, new String[] { "_ID" }, new String[] { "" + recId });
/*  3317: 3837 */       currentIndex = 0;
/*  3318:      */     }
/*  3319: 3840 */     if ((parentRecClass.equals("WORKORDER")) || (parentRecClass.equals("ACTIVITY")) || (parentRecClass.equals("CHANGE")) || (parentRecClass.equals("RELEASE"))) {
/*  3320: 3845 */       addWOChildrenToTree(parentDataBean, childVector, calledControl, currentIndex);
/*  3321: 3847 */     } else if ((parentRecClass.equals("SR")) || (parentRecClass.equals("INCIDENT")) || (parentRecClass.equals("PROBLEM"))) {
/*  3322: 3851 */       addTKChildrenToTree(childVector, calledControl, parentDataBean, currentIndex);
/*  3323:      */     }
/*  3324: 3855 */     this.worklistTreeCache.put(data.getDisplayValue(), childVector);
/*  3325:      */     
/*  3326: 3857 */     return childVector;
/*  3327:      */   }
/*  3328:      */   
/*  3329:      */   private void addTKChildrenToTree(Vector childVector, AbstractMobileControl calledControl, MobileMboDataBean parentDataBean, int currentIndex)
/*  3330:      */     throws MobileApplicationException
/*  3331:      */   {
/*  3332: 3866 */     MobileMboDataBean childDataBean = null;
/*  3333: 3867 */     childDataBean = parentDataBean.getDataBean(currentIndex, "WOACTIVITY");
/*  3334:      */     
/*  3335: 3869 */     childDataBean.reset();
/*  3336: 3870 */     int count = childDataBean.count();
/*  3337: 3871 */     childDataBean.dataExists(count - 1);
/*  3338: 3873 */     for (int i = 0; i < count; i++)
/*  3339:      */     {
/*  3340: 3874 */       TreeNodeData beanLocator = null;
/*  3341:      */       
/*  3342: 3876 */       String parentRec = childDataBean.getValue(i, "WONUM");
/*  3343: 3877 */       String parentRecClass = getInternalRecordClass(childDataBean, childDataBean.getValue(i, "WOCLASS"));
/*  3344: 3878 */       String description = childDataBean.getValue(i, "DESCRIPTION");
/*  3345: 3879 */       String keyValue = parentRecClass + "::" + parentRec;
/*  3346: 3880 */       String label = parentRec + " " + description;
/*  3347: 3881 */       String type = childDataBean.getName();
/*  3348:      */       
/*  3349: 3883 */       beanLocator = createTreeData(calledControl, i, childDataBean, type, keyValue, label, null, "treetest2");
/*  3350:      */       
/*  3351:      */ 
/*  3352:      */ 
/*  3353:      */ 
/*  3354:      */ 
/*  3355:      */ 
/*  3356:      */ 
/*  3357:      */ 
/*  3358: 3892 */       beanLocator.setHasChildren(true);
/*  3359:      */       
/*  3360: 3894 */       childVector.add(beanLocator);
/*  3361:      */     }
/*  3362:      */   }
/*  3363:      */   
/*  3364:      */   private void addWOChildrenToTree(MobileMboDataBean parentDataBean, Vector childVector, AbstractMobileControl calledControl, int currentIndex)
/*  3365:      */     throws MobileApplicationException
/*  3366:      */   {
/*  3367: 3904 */     MobileMboDataBean childDataBean = null;
/*  3368: 3905 */     String recordIdField = "";
/*  3369: 3906 */     String sEvent = "";
/*  3370: 3907 */     int WOTASK = 0;
/*  3371: 3908 */     int WOCHILDREN = 1;
/*  3372: 3910 */     for (int rec = WOTASK; rec <= WOCHILDREN; rec++)
/*  3373:      */     {
/*  3374: 3911 */       if (rec == WOTASK)
/*  3375:      */       {
/*  3376: 3912 */         childDataBean = parentDataBean.getDataBean(currentIndex, "WOTASKS");
/*  3377: 3913 */         recordIdField = "TASKID";
/*  3378: 3914 */         sEvent = "treetest2";
/*  3379:      */       }
/*  3380: 3916 */       else if (rec == WOCHILDREN)
/*  3381:      */       {
/*  3382: 3917 */         childDataBean = parentDataBean.getDataBean(currentIndex, "WOCHILDREN");
/*  3383: 3918 */         recordIdField = "WONUM";
/*  3384: 3919 */         sEvent = "treetest1";
/*  3385:      */       }
/*  3386: 3922 */       if (childDataBean != null)
/*  3387:      */       {
/*  3388: 3923 */         childDataBean.reset();
/*  3389: 3924 */         int count = childDataBean.count();
/*  3390: 3925 */         childDataBean.dataExists(count - 1);
/*  3391: 3927 */         for (int i = 0; i < count; i++)
/*  3392:      */         {
/*  3393: 3928 */           TreeNodeData beanLocator = null;
/*  3394:      */           
/*  3395: 3930 */           String parentRec = childDataBean.getValue(i, recordIdField);
/*  3396: 3931 */           String parentRecClass = getInternalRecordClass(childDataBean, childDataBean.getValue(i, "WOCLASS"));
/*  3397: 3932 */           String description = childDataBean.getValue(i, "DESCRIPTION");
/*  3398: 3933 */           String keyValue = parentRecClass + "::" + parentRec;
/*  3399: 3934 */           String label = parentRec + " " + description;
/*  3400: 3935 */           String type = childDataBean.getName();
/*  3401:      */           
/*  3402: 3937 */           beanLocator = createTreeData(calledControl, i, childDataBean, type, keyValue, label, null, sEvent);
/*  3403:      */           
/*  3404:      */ 
/*  3405:      */ 
/*  3406:      */ 
/*  3407:      */ 
/*  3408:      */ 
/*  3409:      */ 
/*  3410:      */ 
/*  3411: 3946 */           beanLocator.setHasChildren(rec == WOCHILDREN);
/*  3412:      */           
/*  3413: 3948 */           childVector.add(beanLocator);
/*  3414:      */         }
/*  3415:      */       }
/*  3416:      */     }
/*  3417:      */   }
/*  3418:      */   
/*  3419:      */   private String getMobileMboNameForClass(String parentRecClass)
/*  3420:      */   {
/*  3421: 3958 */     String result = null;
/*  3422: 3959 */     if ((parentRecClass.equalsIgnoreCase("WORKORDER")) || (parentRecClass.equalsIgnoreCase("CHANGE")) || (parentRecClass.equalsIgnoreCase("RELEASE")) || (parentRecClass.equalsIgnoreCase("ACTIVITY"))) {
/*  3423: 3964 */       result = "WORKORDER";
/*  3424: 3966 */     } else if ((parentRecClass.equalsIgnoreCase("SR")) || (parentRecClass.equalsIgnoreCase("PROBLEM")) || (parentRecClass.equalsIgnoreCase("INCIDENT"))) {
/*  3425: 3970 */       result = "TICKET";
/*  3426:      */     }
/*  3427: 3972 */     return result;
/*  3428:      */   }
/*  3429:      */   
/*  3430:      */   private String getInternalRecordClass(MobileMboDataBean databean, String recordClass)
/*  3431:      */     throws MobileApplicationException
/*  3432:      */   {
/*  3433: 3978 */     String recClass = ((WOApp)UIUtil.getApplication()).getInternalValue(databean, "WOCLASS", recordClass);
/*  3434: 3980 */     if (recClass.equals("")) {
/*  3435: 3982 */       recClass = ((WOApp)UIUtil.getApplication()).getInternalValue(databean, "TKCLASS", recordClass);
/*  3436:      */     }
/*  3437: 3985 */     return recClass;
/*  3438:      */   }
/*  3439:      */   
/*  3440:      */   private void scansettreewodata(UIEvent event)
/*  3441:      */     throws MobileApplicationException
/*  3442:      */   {
/*  3443: 3991 */     TreeNodeData selectedTreeNode = (TreeNodeData)event.getValue();
/*  3444:      */     
/*  3445:      */ 
/*  3446: 3994 */     MobileMboDataBean curDataBean = selectedTreeNode.getChildDataBean();
/*  3447: 3995 */     String keyValue = selectedTreeNode.getDisplayValue();
/*  3448:      */     
/*  3449: 3997 */     int sepPos = keyValue.indexOf("::");
/*  3450: 3998 */     String parentRecClass = keyValue.substring(0, sepPos);
/*  3451: 3999 */     String type = selectedTreeNode.getType();
/*  3452: 4000 */     if ((type.equals("WOCHILDREN")) || (type.equals("WORKLIST")))
/*  3453:      */     {
/*  3454: 4004 */       long recId = curDataBean.getMobileMbo(selectedTreeNode.getIndex()).getId();
/*  3455: 4005 */       if (type.equals("WORKLIST")) {
/*  3456: 4007 */         recId = curDataBean.getMobileMbo(selectedTreeNode.getIndex()).getLongValue("_RECID");
/*  3457:      */       }
/*  3458: 4011 */       findRecordsInDevice("WORKORDER", "WORKORDER", new String[] { "_ID" }, new String[] { "" + recId });
/*  3459:      */       
/*  3460:      */ 
/*  3461:      */ 
/*  3462:      */ 
/*  3463: 4016 */       setRecordPositionInWorkList(new String[] { "_RECID", "CLASS" }, new String[] { "" + recId, parentRecClass });
/*  3464:      */     }
/*  3465: 4018 */     else if (type.equals("WOTASKS"))
/*  3466:      */     {
/*  3467: 4021 */       MobileMbo parentMbo = curDataBean.getMobileMbo(selectedTreeNode.getIndex()).getOwner();
/*  3468: 4022 */       long recId = parentMbo.getId();
/*  3469: 4023 */       MobileMboDataBean parentDataBean = findRecordsInDevice("WORKORDER", "WORKORDER", new String[] { "_ID" }, new String[] { "" + recId });
/*  3470: 4024 */       parentDataBean.getDataBean("WOTASKS").setCurrentPosition(selectedTreeNode.getIndex());
/*  3471:      */       
/*  3472: 4026 */       setRecordPositionInWorkList(new String[] { "_RECID", "CLASS" }, new String[] { "" + parentMbo.getId(), parentMbo.getValue("WOCLASS") });
/*  3473:      */     }
/*  3474: 4028 */     else if (type.equals("WOACTIVITY"))
/*  3475:      */     {
/*  3476: 4031 */       MobileMbo parentMbo = curDataBean.getMobileMbo(selectedTreeNode.getIndex()).getOwner();
/*  3477: 4032 */       long recId = parentMbo.getId();
/*  3478: 4033 */       MobileMboDataBean parentDataBean = findRecordsInDevice("TICKET", "TICKET", new String[] { "_ID" }, new String[] { "" + recId });
/*  3479: 4034 */       parentDataBean.getDataBean("WOACTIVITY").setCurrentPosition(selectedTreeNode.getIndex());
/*  3480:      */       
/*  3481: 4036 */       setRecordPositionInWorkList(new String[] { "_RECID", "CLASS" }, new String[] { "" + parentMbo.getId(), parentMbo.getValue("CLASS") });
/*  3482:      */     }
/*  3483:      */   }
/*  3484:      */   
/*  3485:      */   public boolean refreshplannedlabortable(UIEvent event)
/*  3486:      */     throws MobileApplicationException
/*  3487:      */   {
/*  3488: 4042 */     MobileMboDataBean databean = ((TableControl)event.getCreatingObject()).getDataBean();
/*  3489:      */     
/*  3490: 4044 */     int count = databean.count();
/*  3491: 4048 */     for (int i = 0; i < count; i++) {
/*  3492: 4050 */       if (!databean.getMobileMbo(i).getValue("LABORCODE").equals("")) {
/*  3493: 4051 */         databean.getMobileMbo(i).setValue("PLAN", databean.getMobileMbo(i).getValue("LABORCODE"), false);
/*  3494:      */       } else {
/*  3495: 4053 */         databean.getMobileMbo(i).setValue("PLAN", databean.getMobileMbo(i).getValue("CRAFT") + " " + databean.getMobileMbo(i).getValue("SKILLLEVEL"), false);
/*  3496:      */       }
/*  3497:      */     }
/*  3498: 4056 */     databean.getDataBeanManager().save();
/*  3499: 4057 */     return true;
/*  3500:      */   }
/*  3501:      */   
/*  3502:      */   public boolean refreshplannedmattable(UIEvent event)
/*  3503:      */     throws MobileApplicationException
/*  3504:      */   {
/*  3505: 4062 */     MobileMboDataBean databean = ((TableControl)event.getCreatingObject()).getDataBean();
/*  3506:      */     
/*  3507: 4064 */     int count = databean.count();
/*  3508: 4067 */     for (int i = 0; i < count; i++) {
/*  3509: 4069 */       if (databean.getMobileMbo(i).getValue("ITEMNUM").equals("")) {
/*  3510: 4070 */         databean.getMobileMbo(i).setValue("ITEMNUMDISPLAY", databean.getMobileMbo(i).getValue("DESCRIPTION"), false);
/*  3511:      */       } else {
/*  3512: 4072 */         databean.getMobileMbo(i).setValue("ITEMNUMDISPLAY", databean.getMobileMbo(i).getValue("ITEMNUM"), false);
/*  3513:      */       }
/*  3514:      */     }
/*  3515: 4074 */     databean.getDataBeanManager().save();
/*  3516: 4075 */     return true;
/*  3517:      */   }
/*  3518:      */   
/*  3519:      */   public boolean refreshactualmattable(UIEvent event)
/*  3520:      */     throws MobileApplicationException
/*  3521:      */   {
/*  3522: 4080 */     MobileMboDataBean databean = ((TableControl)event.getCreatingObject()).getDataBean();
/*  3523:      */     
/*  3524: 4082 */     int count = databean.count();
/*  3525: 4083 */     for (int i = 0; i < count; i++) {
/*  3526: 4085 */       if (databean.getMobileMbo(i).getValue("ITEMNUM").equals("")) {
/*  3527: 4086 */         databean.getMobileMbo(i).setValue("ITEMNUMDISPLAY", databean.getMobileMbo(i).getValue("DESCRIPTION"));
/*  3528:      */       } else {
/*  3529: 4088 */         databean.getMobileMbo(i).setValue("ITEMNUMDISPLAY", databean.getMobileMbo(i).getValue("ITEMNUM"));
/*  3530:      */       }
/*  3531:      */     }
/*  3532: 4090 */     return true;
/*  3533:      */   }
/*  3534:      */   
/*  3535:      */   public boolean cancreatesr(UIEvent event)
/*  3536:      */     throws MobileApplicationException
/*  3537:      */   {
/*  3538: 4095 */     MobileMboDataBean wodatabean = UIUtil.getCurrentScreen().getDataBean();
/*  3539: 4096 */     if ((wodatabean != null) && (wodatabean.getName().equals("WORKORDER")))
/*  3540:      */     {
/*  3541: 4098 */       boolean bShow = true;
/*  3542: 4099 */       if ((wodatabean.getMobileMbo() == null) || (wodatabean.getMobileMbo().isNew())) {
/*  3543: 4100 */         bShow = false;
/*  3544:      */       }
/*  3545: 4102 */       ((AbstractMobileControl)event.getCreatingObject()).setVisibility(bShow);
/*  3546:      */     }
/*  3547: 4104 */     return true;
/*  3548:      */   }
/*  3549:      */   
/*  3550:      */   public boolean canrequestmaterial(UIEvent event)
/*  3551:      */     throws MobileApplicationException
/*  3552:      */   {
/*  3553: 4109 */     boolean bShow = false;
/*  3554: 4110 */     MobileMboDataBean wodatabean = UIUtil.getCurrentScreen().getDataBean();
/*  3555: 4111 */     if ((wodatabean != null) && (wodatabean.getName().equals("WORKORDER"))) {
/*  3556: 4113 */       if ((wodatabean.getMobileMbo() == null) || (wodatabean.getMobileMbo().isNew()))
/*  3557:      */       {
/*  3558: 4115 */         bShow = false;
/*  3559:      */       }
/*  3560:      */       else
/*  3561:      */       {
/*  3562: 4119 */         bShow = true;
/*  3563: 4120 */         String currentMaxStatus = ((WOApp)UIUtil.getApplication()).getInternalValue(wodatabean, "WOSTATUS", wodatabean.getValue("STATUS"));
/*  3564: 4123 */         if ((currentMaxStatus.equalsIgnoreCase("WAPPR")) || (currentMaxStatus.equalsIgnoreCase("CLOSE")) || (currentMaxStatus.equalsIgnoreCase("CAN"))) {
/*  3565: 4125 */           bShow = false;
/*  3566:      */         }
/*  3567:      */       }
/*  3568:      */     }
/*  3569: 4128 */     ((AbstractMobileControl)event.getCreatingObject()).setVisibility(bShow);
/*  3570: 4129 */     return true;
/*  3571:      */   }
/*  3572:      */   
/*  3573:      */   public boolean cancreatefollowup(UIEvent event)
/*  3574:      */     throws MobileApplicationException
/*  3575:      */   {
/*  3576: 4134 */     MobileMboDataBean wodatabean = UIUtil.getCurrentScreen().getDataBean();
/*  3577:      */     
/*  3578:      */ 
/*  3579: 4137 */     String dataBeanName = null;
/*  3580: 4138 */     if (wodatabean != null)
/*  3581:      */     {
/*  3582: 4139 */       dataBeanName = wodatabean.getName();
/*  3583: 4140 */       if (dataBeanName.equals("PLUSCWODS")) {
/*  3584: 4141 */         setCurrentScreenDataSrc(wodatabean.getParentBean().getName());
/*  3585:      */       }
/*  3586:      */     }
/*  3587: 4151 */     if ((wodatabean != null) && (wodatabean.getName().equals("TKLABTRANS"))) {
/*  3588: 4152 */       wodatabean = wodatabean.getParentBean();
/*  3589:      */     }
/*  3590: 4155 */     if ((wodatabean != null) && ((wodatabean.getName().equals("WORKORDER")) || (wodatabean.getName().equals("TICKET"))))
/*  3591:      */     {
/*  3592: 4157 */       boolean bShow = true;
/*  3593: 4158 */       if ((wodatabean.getMobileMbo() == null) || (wodatabean.getMobileMbo().isNew())) {
/*  3594: 4159 */         bShow = false;
/*  3595:      */       }
/*  3596: 4161 */       if ((bShow) && (wodatabean.getName().equalsIgnoreCase("WORKORDER")))
/*  3597:      */       {
/*  3598: 4163 */         String woclass = ((WOApp)UIUtil.getApplication()).getInternalValue(wodatabean, "WOCLASS", wodatabean.getValue("WOCLASS"));
/*  3599: 4164 */         if (woclass.equalsIgnoreCase("ACTIVITY")) {
/*  3600: 4165 */           bShow = false;
/*  3601:      */         }
/*  3602:      */       }
/*  3603: 4167 */       ((AbstractMobileControl)event.getCreatingObject()).setVisibility(bShow);
/*  3604:      */     }
/*  3605: 4170 */     if ((dataBeanName != null) && (dataBeanName.equals("PLUSCWODS"))) {
/*  3606: 4171 */       setCurrentScreenDataSrc(wodatabean.getName());
/*  3607:      */     }
/*  3608: 4175 */     return true;
/*  3609:      */   }
/*  3610:      */   
/*  3611:      */   public boolean displaySRTab(UIEvent event)
/*  3612:      */     throws MobileApplicationException
/*  3613:      */   {
/*  3614: 4180 */     MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager("SR");
/*  3615: 4181 */     MobileMboDataBean srdatabean = mgrDBMgr.getDataBean();
/*  3616: 4183 */     if (srdatabean.count() == 0) {
/*  3617: 4184 */       ((AbstractMobileControl)event.getCreatingObject()).setVisibility(false);
/*  3618:      */     }
/*  3619: 4186 */     return true;
/*  3620:      */   }
/*  3621:      */   
/*  3622:      */   public boolean canenteractuals(UIEvent event)
/*  3623:      */     throws MobileApplicationException
/*  3624:      */   {
/*  3625: 4192 */     MobileMboDataBean controlBean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*  3626: 4193 */     boolean isChild = false;
/*  3627: 4194 */     if (controlBean.getName().equals("WOCHILDREN")) {
/*  3628: 4196 */       isChild = true;
/*  3629:      */     }
/*  3630: 4199 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/*  3631: 4200 */     if ((databean != null) && (databean.getName().equals("WORKLIST"))) {
/*  3632: 4204 */       databean = getWorklistRecordBean(event);
/*  3633:      */     }
/*  3634: 4207 */     if ((databean != null) && ((databean.getName().equals("WORKORDER")) || (databean.getName().equals("TICKET")))) {
/*  3635: 4209 */       if (databean.getName().equals("WORKORDER"))
/*  3636:      */       {
/*  3637: 4212 */         if (isChild) {
/*  3638: 4214 */           ((AbstractMobileControl)event.getCreatingObject()).setVisibility(canEnterActualsOnWO(controlBean));
/*  3639:      */         } else {
/*  3640: 4218 */           ((AbstractMobileControl)event.getCreatingObject()).setVisibility(canEnterActualsOnWO(databean));
/*  3641:      */         }
/*  3642:      */       }
/*  3643: 4221 */       else if (databean.getName().equals("TICKET")) {
/*  3644: 4224 */         if (isChild) {
/*  3645: 4226 */           ((AbstractMobileControl)event.getCreatingObject()).setVisibility(canEnterActualsOnTicket(controlBean));
/*  3646:      */         } else {
/*  3647: 4230 */           ((AbstractMobileControl)event.getCreatingObject()).setVisibility(canEnterActualsOnTicket(databean));
/*  3648:      */         }
/*  3649:      */       }
/*  3650:      */     }
/*  3651: 4234 */     return true;
/*  3652:      */   }
/*  3653:      */   
/*  3654:      */   public boolean canEnterActualsOnWO(MobileMboDataBean databean)
/*  3655:      */     throws MobileApplicationException
/*  3656:      */   {
/*  3657: 4239 */     String currentMaxStatus = ((WOApp)UIUtil.getApplication()).getInternalValue(databean, "WOSTATUS", databean.getValue("STATUS"));
/*  3658: 4242 */     if ((databean.getValue("HISTORYFLAG").equals("0")) && (!currentMaxStatus.equals("WAPPR")) && (woAcceptsCharges(databean))) {
/*  3659: 4244 */       return true;
/*  3660:      */     }
/*  3661: 4246 */     return false;
/*  3662:      */   }
/*  3663:      */   
/*  3664:      */   public boolean canEnterActualsOnTicket(MobileMboDataBean databean)
/*  3665:      */     throws MobileApplicationException
/*  3666:      */   {
/*  3667: 4268 */     if ((databean.getValue("HISTORYFLAG").equals("0")) && (tkAcceptsCharges(databean))) {
/*  3668: 4270 */       return true;
/*  3669:      */     }
/*  3670: 4272 */     return false;
/*  3671:      */   }
/*  3672:      */   
/*  3673:      */   public boolean woAcceptsCharges(MobileMboDataBean wodatabean)
/*  3674:      */     throws MobileApplicationException
/*  3675:      */   {
/*  3676: 4278 */     if (wodatabean.getValue("WOACCEPTSCHARGES").equals("1")) {
/*  3677: 4279 */       return true;
/*  3678:      */     }
/*  3679: 4282 */     MobileMboDataBean wotasks = wodatabean.getDataBean("WOTASKS");
/*  3680: 4283 */     int count = wotasks.count();
/*  3681: 4284 */     for (int i = 0; i < count; i++) {
/*  3682: 4286 */       if (wotasks.getMobileMbo(i).getValue("WOACCEPTSCHARGES").equals("1")) {
/*  3683: 4287 */         return true;
/*  3684:      */       }
/*  3685:      */     }
/*  3686: 4290 */     return false;
/*  3687:      */   }
/*  3688:      */   
/*  3689:      */   public boolean tkAcceptsCharges(MobileMboDataBean wodatabean)
/*  3690:      */     throws MobileApplicationException
/*  3691:      */   {
/*  3692: 4308 */     return true;
/*  3693:      */   }
/*  3694:      */   
/*  3695:      */   public boolean canChangeFailureCode(UIEvent event)
/*  3696:      */     throws MobileApplicationException
/*  3697:      */   {
/*  3698: 4313 */     MobileMboDataBean wodatabean = UIUtil.getCurrentScreen().getDataBean();
/*  3699: 4315 */     if ((wodatabean != null) && ((wodatabean.getName().equals("WORKORDER")) || (wodatabean.getName().equals("TICKET"))))
/*  3700:      */     {
/*  3701: 4318 */       boolean bShow = true;
/*  3702: 4319 */       if (wodatabean.getValue("HISTORYFLAG").equals("1")) {
/*  3703: 4320 */         bShow = false;
/*  3704:      */       }
/*  3705: 4322 */       if ((bShow) && ((((AbstractMobileControl)event.getCreatingObject()).getParentControl().getParentControl() instanceof TextboxControl)))
/*  3706:      */       {
/*  3707: 4325 */         String textValue = ((TextboxControl)((AbstractMobileControl)event.getCreatingObject()).getParentControl().getParentControl()).getControlValue();
/*  3708: 4326 */         if ((textValue == null) || (textValue.equals(""))) {
/*  3709: 4327 */           bShow = false;
/*  3710:      */         }
/*  3711:      */       }
/*  3712: 4330 */       ((AbstractMobileControl)event.getCreatingObject()).setVisibility(bShow);
/*  3713:      */     }
/*  3714: 4332 */     return true;
/*  3715:      */   }
/*  3716:      */   
/*  3717:      */   public boolean canChangeFailureCodeLink(UIEvent event)
/*  3718:      */     throws MobileApplicationException
/*  3719:      */   {
/*  3720: 4337 */     MobileMboDataBean wodatabean = UIUtil.getCurrentScreen().getDataBean();
/*  3721: 4339 */     if ((wodatabean != null) && ((wodatabean.getName().equals("WORKORDER")) || (wodatabean.getName().equals("TICKET"))))
/*  3722:      */     {
/*  3723: 4342 */       boolean bShow = true;
/*  3724: 4343 */       if (wodatabean.getValue("HISTORYFLAG").equals("1")) {
/*  3725: 4344 */         bShow = false;
/*  3726:      */       }
/*  3727: 4345 */       if ((bShow) && ((((AbstractMobileControl)event.getCreatingObject()).getParentControl().getParentControl().getParentControl() instanceof TextboxControl)))
/*  3728:      */       {
/*  3729: 4347 */         String textValue = ((TextboxControl)((AbstractMobileControl)event.getCreatingObject()).getParentControl().getParentControl().getParentControl()).getControlValue();
/*  3730: 4348 */         if ((textValue == null) || (textValue.equals(""))) {
/*  3731: 4349 */           bShow = false;
/*  3732:      */         }
/*  3733:      */       }
/*  3734: 4352 */       WOFailCodeEventHandler failcodehandler = new WOFailCodeEventHandler();
/*  3735: 4353 */       int failurecodes = failcodehandler.getFailRepLevels(wodatabean);
/*  3736: 4354 */       if ((bShow) && (!wodatabean.getValue("FAILURECODE" + failurecodes).equals(""))) {
/*  3737: 4355 */         bShow = false;
/*  3738:      */       }
/*  3739: 4357 */       ((AbstractMobileControl)event.getCreatingObject()).setVisibility(bShow);
/*  3740:      */     }
/*  3741: 4359 */     return true;
/*  3742:      */   }
/*  3743:      */   
/*  3744:      */   public boolean initassetwofailurereport(UIEvent event)
/*  3745:      */     throws MobileApplicationException
/*  3746:      */   {
/*  3747: 4365 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/*  3748: 4366 */     MobileMboDataBean frdatabean = databean.getDataBean("ASSETWOFAILREPORT");
/*  3749:      */     
/*  3750:      */ 
/*  3751: 4369 */     WOFailCodeEventHandler failcodehandler = new WOFailCodeEventHandler();
/*  3752: 4370 */     for (int i = 1; i <= failcodehandler.getFailRepLevels(databean); i++) {
/*  3753: 4372 */       databean.setValue("FAILURECODE" + i, "");
/*  3754:      */     }
/*  3755: 4375 */     int listcount = frdatabean.count();
/*  3756: 4376 */     for (int i = 1; i < listcount + 1; i++) {
/*  3757: 4378 */       databean.setValue("FAILURECODE" + i, frdatabean.getMobileMbo(i - 1).getValue("FAILURECODE"));
/*  3758:      */     }
/*  3759: 4380 */     return true;
/*  3760:      */   }
/*  3761:      */   
/*  3762:      */   public boolean initlocwofailurereport(UIEvent event)
/*  3763:      */     throws MobileApplicationException
/*  3764:      */   {
/*  3765: 4386 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/*  3766: 4387 */     MobileMboDataBean frdatabean = databean.getDataBean("LOCWOFAILREPORT");
/*  3767:      */     
/*  3768:      */ 
/*  3769: 4390 */     WOFailCodeEventHandler failcodehandler = new WOFailCodeEventHandler();
/*  3770: 4391 */     for (int i = 1; i <= failcodehandler.getFailRepLevels(databean); i++) {
/*  3771: 4393 */       databean.setValue("FAILURECODE" + i, "");
/*  3772:      */     }
/*  3773: 4396 */     int listcount = frdatabean.count();
/*  3774: 4397 */     for (int i = 1; i < listcount + 1; i++) {
/*  3775: 4399 */       databean.setValue("FAILURECODE" + i, frdatabean.getMobileMbo(i - 1).getValue("FAILURECODE"));
/*  3776:      */     }
/*  3777: 4401 */     return true;
/*  3778:      */   }
/*  3779:      */   
/*  3780:      */   public boolean candeleteactual(UIEvent event)
/*  3781:      */     throws MobileApplicationException
/*  3782:      */   {
/*  3783: 4406 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/*  3784: 4408 */     if (databean != null)
/*  3785:      */     {
/*  3786: 4410 */       boolean bShow = false;
/*  3787: 4411 */       if ((databean.getMobileMbo() == null) || (databean.getMobileMbo().isNew())) {
/*  3788: 4412 */         bShow = true;
/*  3789:      */       }
/*  3790: 4415 */       if (databean.getName().equals("WOLABTRANS")) {
/*  3791: 4416 */         bShow = !hasRunningTimerWOLabTrans(databean.getMobileMbo());
/*  3792:      */       }
/*  3793: 4419 */       ((AbstractMobileControl)event.getCreatingObject()).setVisibility(bShow);
/*  3794:      */     }
/*  3795: 4421 */     return true;
/*  3796:      */   }
/*  3797:      */   
/*  3798:      */   private boolean hasRunningTimerWOLabTrans(MobileMbo mobileMbo)
/*  3799:      */     throws MobileApplicationException
/*  3800:      */   {
/*  3801: 4425 */     return mobileMbo == null ? false : mobileMbo.getValue("TIMERSTATUS").equals("ACTIVE");
/*  3802:      */   }
/*  3803:      */   
/*  3804:      */   public boolean deleteactual(UIEvent event)
/*  3805:      */     throws MobileApplicationException
/*  3806:      */   {
/*  3807: 4430 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/*  3808: 4431 */     if (databean != null) {
/*  3809: 4433 */       if (databean.getMobileMbo().isNew())
/*  3810:      */       {
/*  3811: 4435 */         databean.delete();
/*  3812: 4436 */         databean.getDataBeanManager().save();
/*  3813: 4437 */         databean.reset();
/*  3814: 4440 */         if (databean.getName().equals("WOMATTRANS"))
/*  3815:      */         {
/*  3816: 4442 */           int count = databean.count();
/*  3817: 4443 */           for (int i = 0; i < count; i++) {
/*  3818: 4445 */             if (databean.getMobileMbo(i).getValue("ITEMNUM").equals("")) {
/*  3819: 4446 */               databean.getMobileMbo(i).setValue("ITEMNUMDISPLAY", databean.getMobileMbo(i).getValue("DESCRIPTION"));
/*  3820:      */             } else {
/*  3821: 4448 */               databean.getMobileMbo(i).setValue("ITEMNUMDISPLAY", databean.getMobileMbo(i).getValue("ITEMNUM"));
/*  3822:      */             }
/*  3823:      */           }
/*  3824:      */         }
/*  3825: 4452 */         UIUtil.closePage();
/*  3826:      */       }
/*  3827:      */     }
/*  3828: 4455 */     return true;
/*  3829:      */   }
/*  3830:      */   
/*  3831:      */   public boolean selectclassesvalues(UIEvent event)
/*  3832:      */     throws MobileApplicationException
/*  3833:      */   {
/*  3834: 4460 */     setQbeValues("CLASS", "VALUE");
/*  3835: 4461 */     UIUtil.getApplication().removeCurrentScreen(true);
/*  3836: 4462 */     return true;
/*  3837:      */   }
/*  3838:      */   
/*  3839:      */   public boolean selectstatusvalues(UIEvent event)
/*  3840:      */     throws MobileApplicationException
/*  3841:      */   {
/*  3842: 4468 */     setQbeValues("STATUS", "VALUE");
/*  3843:      */     
/*  3844: 4470 */     UIUtil.getApplication().removeCurrentScreen(true);
/*  3845: 4471 */     return true;
/*  3846:      */   }
/*  3847:      */   
/*  3848:      */   public boolean selectworktypevalues(UIEvent event)
/*  3849:      */     throws MobileApplicationException
/*  3850:      */   {
/*  3851: 4476 */     setQbeValues("WORKTYPE", "WORKTYPE");
/*  3852:      */     
/*  3853: 4478 */     UIUtil.getApplication().removeCurrentScreen(true);
/*  3854: 4479 */     return true;
/*  3855:      */   }
/*  3856:      */   
/*  3857:      */   public boolean selectassetvalues(UIEvent event)
/*  3858:      */     throws MobileApplicationException
/*  3859:      */   {
/*  3860: 4484 */     setQbeValues("ASSETNUM", "ASSETNUM");
/*  3861:      */     
/*  3862: 4486 */     UIUtil.getApplication().removeCurrentScreen(true);
/*  3863: 4487 */     return true;
/*  3864:      */   }
/*  3865:      */   
/*  3866:      */   public boolean selectlocationvalues(UIEvent event)
/*  3867:      */     throws MobileApplicationException
/*  3868:      */   {
/*  3869: 4492 */     setQbeValues("LOCATION", "LOCATION");
/*  3870:      */     
/*  3871: 4494 */     UIUtil.getApplication().removeCurrentScreen(true);
/*  3872: 4495 */     return true;
/*  3873:      */   }
/*  3874:      */   
/*  3875:      */   public boolean selectfcvalues(UIEvent event)
/*  3876:      */     throws MobileApplicationException
/*  3877:      */   {
/*  3878: 4500 */     setQbeValues("FAILURECODE", "FAILURECODE");
/*  3879:      */     
/*  3880: 4502 */     UIUtil.getApplication().removeCurrentScreen(true);
/*  3881: 4503 */     return true;
/*  3882:      */   }
/*  3883:      */   
/*  3884:      */   public boolean selectlaborvalues(UIEvent event)
/*  3885:      */     throws MobileApplicationException
/*  3886:      */   {
/*  3887: 4508 */     setQbeValues("WOPLANNEDLABOR.LABORCODE", "LABORCODE");
/*  3888:      */     
/*  3889: 4510 */     UIUtil.getApplication().removeCurrentScreen(true);
/*  3890: 4511 */     return true;
/*  3891:      */   }
/*  3892:      */   
/*  3893:      */   public boolean setQbeValues(String qbefield, String lukeyfield)
/*  3894:      */     throws MobileApplicationException
/*  3895:      */   {
/*  3896: 4516 */     MobileMboDataBean ludatabean = UIUtil.getCurrentScreen().getDataBean();
/*  3897: 4517 */     MobileMboDataBean qbedatabean = ((PageControl)UIUtil.getCurrentScreen()).getLaunchingControl().getDataBean();
/*  3898:      */     
/*  3899: 4519 */     StringBuffer str = new StringBuffer();
/*  3900:      */     
/*  3901:      */ 
/*  3902: 4522 */     Vector selectedMbos = ludatabean.getSelection();
/*  3903: 4523 */     if (!selectedMbos.isEmpty())
/*  3904:      */     {
/*  3905: 4525 */       Iterator it = selectedMbos.iterator();
/*  3906: 4526 */       while (it.hasNext())
/*  3907:      */       {
/*  3908: 4528 */         MobileMbo selectedMbo = (MobileMbo)it.next();
/*  3909: 4529 */         if (str.length() > 0) {
/*  3910: 4530 */           str.append(",");
/*  3911:      */         }
/*  3912: 4531 */         str.append(selectedMbo.getValue(lukeyfield));
/*  3913:      */       }
/*  3914:      */     }
/*  3915: 4536 */     qbedatabean.getQBE().setQBE(qbefield, str.toString());
/*  3916:      */     
/*  3917: 4538 */     return true;
/*  3918:      */   }
/*  3919:      */   
/*  3920:      */   public boolean canattachdocs(UIEvent event)
/*  3921:      */     throws MobileApplicationException
/*  3922:      */   {
/*  3923: 4543 */     MobileMboDataBean wodatabean = UIUtil.getCurrentScreen().getDataBean();
/*  3924: 4544 */     if ((wodatabean != null) && (wodatabean.getName().equals("WORKORDER")))
/*  3925:      */     {
/*  3926: 4546 */       boolean bShow = true;
/*  3927: 4547 */       if ((wodatabean.getMobileMbo() == null) || (wodatabean.getMobileMbo().isReadOnly())) {
/*  3928: 4548 */         bShow = false;
/*  3929:      */       }
/*  3930: 4550 */       ((AbstractMobileControl)event.getCreatingObject()).setVisibility(bShow);
/*  3931:      */     }
/*  3932: 4552 */     return true;
/*  3933:      */   }
/*  3934:      */   
/*  3935:      */   public boolean initLocOpOnlyLookup(UIEvent event)
/*  3936:      */     throws MobileApplicationException
/*  3937:      */   {
/*  3938: 4557 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/*  3939: 4558 */     databean.getQBE().setQBE("TYPE", ((WOApp)UIUtil.getApplication()).getDefaultValue(databean, "LOCTYPE", "OPERATING"));
/*  3940:      */     
/*  3941: 4560 */     databean.reset();
/*  3942:      */     
/*  3943: 4562 */     return false;
/*  3944:      */   }
/*  3945:      */   
/*  3946:      */   public boolean caninsertlog(UIEvent event)
/*  3947:      */     throws MobileApplicationException
/*  3948:      */   {
/*  3949: 4567 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/*  3950: 4569 */     if ((databean != null) && ((databean.getName().equals("WORKORDER")) || (databean.getName().equals("TICKET"))))
/*  3951:      */     {
/*  3952: 4571 */       boolean bShow = true;
/*  3953: 4572 */       if (databean.getValue("HISTORYFLAG").equals("1")) {
/*  3954: 4573 */         bShow = false;
/*  3955:      */       }
/*  3956: 4575 */       ((AbstractMobileControl)event.getCreatingObject()).setVisibility(bShow);
/*  3957:      */     }
/*  3958: 4577 */     return true;
/*  3959:      */   }
/*  3960:      */   
/*  3961:      */   public boolean insertlog(UIEvent event)
/*  3962:      */     throws MobileApplicationException
/*  3963:      */   {
/*  3964: 4582 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/*  3965: 4583 */     if (databean != null)
/*  3966:      */     {
/*  3967: 4585 */       if ((databean.getName().equals("WORKLOG")) || (databean.getName().equals("TKWORKLOG")))
/*  3968:      */       {
/*  3969: 4587 */         databean.insert();
/*  3970: 4588 */         databean.setValue("LOGTYPE", ((WOApp)UIUtil.getApplication()).getDefaultValue(databean, "LOGTYPE", "CLIENTNOTE"));
/*  3971:      */         
/*  3972: 4590 */         databean.setValue("CREATEBY", ((WOApp)UIUtil.getApplication()).getCurrentUser());
/*  3973: 4591 */         databean.getMobileMbo().setDateValue("CREATEDATE", databean.getCurrentTime());
/*  3974:      */         
/*  3975: 4593 */         databean.setValue("CREATEDFROMFOLLOWUP", "0");
/*  3976: 4594 */         if (databean.getName().equals("WORKLOG"))
/*  3977:      */         {
/*  3978: 4596 */           databean.setValue("RECORDKEY", databean.getOwner().getValue("WONUM"));
/*  3979: 4597 */           databean.setValue("CLASS", databean.getOwner().getValue("WOCLASS"));
/*  3980:      */         }
/*  3981: 4599 */         else if (databean.getName().equals("TKWORKLOG"))
/*  3982:      */         {
/*  3983: 4601 */           databean.setValue("RECORDKEY", databean.getOwner().getValue("TICKETID"));
/*  3984: 4602 */           databean.setValue("CLASS", databean.getOwner().getValue("CLASS"));
/*  3985:      */         }
/*  3986: 4605 */         databean.getMobileMbo().setReadOnly("CLIENTVIEWABLE", false);
/*  3987:      */       }
/*  3988: 4607 */       UIUtil.refreshCurrentScreen();
/*  3989:      */     }
/*  3990: 4610 */     return true;
/*  3991:      */   }
/*  3992:      */   
/*  3993:      */   public boolean candeletelog(UIEvent event)
/*  3994:      */     throws MobileApplicationException
/*  3995:      */   {
/*  3996: 4615 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/*  3997: 4617 */     if (databean != null)
/*  3998:      */     {
/*  3999: 4619 */       boolean bShow = false;
/*  4000: 4620 */       if ((databean.getMobileMbo() != null) && (databean.getMobileMbo().isNew()) && (!databean.getMobileMbo().isToBeSaved())) {
/*  4001: 4621 */         bShow = true;
/*  4002:      */       }
/*  4003: 4623 */       ((AbstractMobileControl)event.getCreatingObject()).setVisibility(bShow);
/*  4004:      */     }
/*  4005: 4625 */     return true;
/*  4006:      */   }
/*  4007:      */   
/*  4008:      */   public boolean deletelog(UIEvent event)
/*  4009:      */     throws MobileApplicationException
/*  4010:      */   {
/*  4011: 4630 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/*  4012: 4631 */     if (databean != null) {
/*  4013: 4633 */       if (databean.getMobileMbo().isNew())
/*  4014:      */       {
/*  4015: 4635 */         databean.delete();
/*  4016: 4636 */         databean.getDataBeanManager().save();
/*  4017: 4637 */         databean.reset();
/*  4018:      */         
/*  4019: 4639 */         UIUtil.closePage();
/*  4020:      */       }
/*  4021:      */     }
/*  4022: 4642 */     return true;
/*  4023:      */   }
/*  4024:      */   
/*  4025:      */   public boolean submitCommunication(UIEvent event)
/*  4026:      */     throws MobileApplicationException
/*  4027:      */   {
/*  4028: 4650 */     final MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/*  4029: 4651 */     if (!UIUtil.getCurrentScreen().validateControl()) {
/*  4030: 4652 */       return true;
/*  4031:      */     }
/*  4032: 4654 */     if (UIUtil.checkESignature(event, databean, "CREATECOMM")) {
/*  4033: 4656 */       new AsyncEventHandlerSupport()
/*  4034:      */       {
/*  4035:      */         public boolean doRealWok(UIEvent event)
/*  4036:      */           throws MobileApplicationException
/*  4037:      */         {
/*  4038: 4659 */           super.updateProgressBar("processdatainprogress", null, event);
/*  4039: 4660 */           databean.done();
/*  4040: 4661 */           return true;
/*  4041:      */         }
/*  4042:      */         
/*  4043:      */         public void postRealWork(UIEvent event)
/*  4044:      */           throws MobileApplicationException
/*  4045:      */         {
/*  4046: 4664 */           UIUtil.getApplication().removeCurrentScreen(false);
/*  4047:      */         }
/*  4048: 4664 */       }.handleInBackground(event);
/*  4049:      */     } else {
/*  4050: 4670 */       event.setEventErrored();
/*  4051:      */     }
/*  4052: 4673 */     return true;
/*  4053:      */   }
/*  4054:      */   
/*  4055:      */   public boolean cancreatecommunication(UIEvent event)
/*  4056:      */     throws MobileApplicationException
/*  4057:      */   {
/*  4058: 4678 */     MobileMboDataBean wodatabean = UIUtil.getCurrentScreen().getDataBean();
/*  4059: 4679 */     if ((wodatabean != null) && (!wodatabean.getName().equals("WORKORDER"))) {
/*  4060: 4680 */       wodatabean = DataBeanCache.findDataBean("WORKORDER");
/*  4061:      */     }
/*  4062: 4682 */     if ((wodatabean != null) && (wodatabean.getName().equals("WORKORDER")))
/*  4063:      */     {
/*  4064: 4684 */       boolean bShow = true;
/*  4065: 4685 */       MobileMbo mbo = wodatabean.getMobileMbo();
/*  4066: 4686 */       if (mbo == null)
/*  4067:      */       {
/*  4068: 4686 */         bShow = false;
/*  4069:      */       }
/*  4070:      */       else
/*  4071:      */       {
/*  4072: 4689 */         if (mbo.isNew()) {
/*  4073: 4690 */           bShow = false;
/*  4074:      */         }
/*  4075: 4693 */         String maxStatus = ((WOApp)UIUtil.getApplication()).getInternalValue(wodatabean, "WOSTATUS", wodatabean.getValue("STATUS"));
/*  4076: 4696 */         if (maxStatus.equals("CLOSE")) {
/*  4077: 4697 */           bShow = false;
/*  4078:      */         }
/*  4079:      */       }
/*  4080: 4699 */       ((AbstractMobileControl)event.getCreatingObject()).setVisibility(bShow);
/*  4081:      */     }
/*  4082: 4702 */     return true;
/*  4083:      */   }
/*  4084:      */   
/*  4085:      */   public boolean cancreatetkcommunication(UIEvent event)
/*  4086:      */     throws MobileApplicationException
/*  4087:      */   {
/*  4088: 4707 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/*  4089: 4708 */     if ((databean != null) && (!databean.getName().equals("TICKET"))) {
/*  4090: 4709 */       databean = DataBeanCache.findDataBean("TICKET");
/*  4091:      */     }
/*  4092: 4712 */     if ((databean != null) && (databean.getMobileMbo() != null) && (databean.getName().equals("TICKET")))
/*  4093:      */     {
/*  4094: 4714 */       boolean bShow = true;
/*  4095: 4717 */       if (databean.getMobileMbo().isNew()) {
/*  4096: 4718 */         bShow = false;
/*  4097:      */       }
/*  4098: 4721 */       String statusdomain = "";
/*  4099:      */       
/*  4100: 4723 */       String tkclass = ((WOApp)UIUtil.getApplication()).getInternalValue(databean, "TKCLASS", databean.getValue("CLASS"));
/*  4101: 4724 */       if (tkclass.equalsIgnoreCase("SR")) {
/*  4102: 4725 */         statusdomain = "SRSTATUS";
/*  4103: 4726 */       } else if (tkclass.equalsIgnoreCase("INCIDENT")) {
/*  4104: 4727 */         statusdomain = "INCIDENTSTATUS";
/*  4105: 4728 */       } else if (tkclass.equalsIgnoreCase("PROBLEM")) {
/*  4106: 4729 */         statusdomain = "PROBLEMSTATUS";
/*  4107:      */       }
/*  4108: 4731 */       String maxStatus = ((WOApp)UIUtil.getApplication()).getInternalValue(databean, statusdomain, databean.getValue("STATUS"));
/*  4109: 4734 */       if (maxStatus.equals("CLOSE")) {
/*  4110: 4735 */         bShow = false;
/*  4111:      */       }
/*  4112: 4737 */       ((AbstractMobileControl)event.getCreatingObject()).setVisibility(bShow);
/*  4113:      */     }
/*  4114: 4740 */     return true;
/*  4115:      */   }
/*  4116:      */   
/*  4117:      */   public boolean displayCOMMTab(UIEvent event)
/*  4118:      */     throws MobileApplicationException
/*  4119:      */   {
/*  4120: 4745 */     MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager("COMMLOG");
/*  4121: 4746 */     MobileMboDataBean commdatabean = mgrDBMgr.getDataBean();
/*  4122: 4748 */     if (commdatabean.getErrorCount() == 0) {
/*  4123: 4749 */       ((AbstractMobileControl)event.getCreatingObject()).setVisibility(false);
/*  4124:      */     }
/*  4125: 4751 */     return true;
/*  4126:      */   }
/*  4127:      */   
/*  4128:      */   public boolean initcommlog(UIEvent event)
/*  4129:      */     throws MobileApplicationException
/*  4130:      */   {
/*  4131: 4756 */     MobileMboDataBean databean = ((TableControl)event.getCreatingObject()).getDataBean();
/*  4132: 4757 */     if (databean != null) {
/*  4133: 4759 */       databean.setErrorFilter();
/*  4134:      */     }
/*  4135: 4761 */     return true;
/*  4136:      */   }
/*  4137:      */   
/*  4138:      */   public boolean displayMRTab(UIEvent event)
/*  4139:      */     throws MobileApplicationException
/*  4140:      */   {
/*  4141: 4766 */     MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager("MR");
/*  4142: 4767 */     MobileMboDataBean mrdatabean = mgrDBMgr.getDataBean();
/*  4143: 4769 */     if (mrdatabean.count() > 0) {
/*  4144: 4770 */       ((AbstractMobileControl)event.getCreatingObject()).setVisibility(true);
/*  4145:      */     } else {
/*  4146: 4772 */       ((AbstractMobileControl)event.getCreatingObject()).setVisibility(false);
/*  4147:      */     }
/*  4148: 4774 */     return true;
/*  4149:      */   }
/*  4150:      */   
/*  4151:      */   public boolean initmr(UIEvent event)
/*  4152:      */     throws MobileApplicationException
/*  4153:      */   {
/*  4154: 4779 */     MobileMboDataBean allflagsBean = WOApp.getWpAllFlags();
/*  4155:      */     
/*  4156: 4781 */     MobileMboDataBean databean = ((TableControl)event.getCreatingObject()).getDataBean();
/*  4157: 4782 */     if (databean != null) {
/*  4158: 4784 */       if (allflagsBean.getValue("SHOWMRERRORSONLY").equals("1"))
/*  4159:      */       {
/*  4160: 4786 */         databean.setErrorFilter();
/*  4161:      */       }
/*  4162:      */       else
/*  4163:      */       {
/*  4164: 4790 */         databean.getQBE().reset();
/*  4165: 4791 */         databean.reset();
/*  4166:      */       }
/*  4167:      */     }
/*  4168: 4794 */     return true;
/*  4169:      */   }
/*  4170:      */   
/*  4171:      */   public boolean canmovemodify(UIEvent event)
/*  4172:      */     throws MobileApplicationException
/*  4173:      */   {
/*  4174: 4799 */     MobileMboDataBean wodatabean = UIUtil.getCurrentScreen().getDataBean();
/*  4175: 4801 */     if (UIUtil.getCurrentScreen().getPageGroup() != null)
/*  4176:      */     {
/*  4177: 4803 */       String curScreenId = UIUtil.getCurrentScreen().getPageGroup().getId();
/*  4178: 4804 */       if ((curScreenId.equalsIgnoreCase("assetgroup")) || (curScreenId.equalsIgnoreCase("locgroup")))
/*  4179:      */       {
/*  4180: 4806 */         ((AbstractMobileControl)event.getCreatingObject()).setVisibility(false);
/*  4181: 4807 */         return true;
/*  4182:      */       }
/*  4183:      */     }
/*  4184: 4810 */     if ((wodatabean != null) && ((wodatabean.getName().equals("ASSET")) || (wodatabean.getName().equals("LOCATIONS")))) {
/*  4185: 4811 */       wodatabean = ((PageControl)UIUtil.getCurrentScreen()).getLaunchingControl().getDataBean();
/*  4186:      */     }
/*  4187: 4815 */     if ((wodatabean != null) && ((wodatabean.getName().equals("TICKET")) || (wodatabean.getName().equals("TKMULTIASSETLOCCI"))))
/*  4188:      */     {
/*  4189: 4817 */       ((AbstractMobileControl)event.getCreatingObject()).setVisibility(false);
/*  4190: 4818 */       return true;
/*  4191:      */     }
/*  4192: 4821 */     if ((wodatabean != null) && (!wodatabean.getName().equals("WORKORDER"))) {
/*  4193: 4822 */       wodatabean = DataBeanCache.findDataBean("WORKORDER");
/*  4194:      */     }
/*  4195: 4824 */     if ((wodatabean != null) && (wodatabean.getName().equals("WORKORDER")))
/*  4196:      */     {
/*  4197: 4826 */       boolean bShow = true;
/*  4198:      */       
/*  4199:      */ 
/*  4200: 4829 */       MobileMboDataBean womulti = wodatabean.getDataBean("WOMULTIASSETLOCCI");
/*  4201: 4830 */       if ((womulti == null) || (womulti.count() == 0)) {
/*  4202: 4832 */         if (UIUtil.getCurrentScreen().getId().equals("woresults")) {
/*  4203: 4833 */           bShow = false;
/*  4204:      */         }
/*  4205:      */       }
/*  4206: 4836 */       AbstractMobileControl control = (AbstractMobileControl)event.getCreatingObject();
/*  4207:      */       
/*  4208: 4838 */       String origMaxStatus = ((WOApp)UIUtil.getApplication()).getInternalValue(wodatabean, "WOSTATUS", wodatabean.getValue("ORIGSTATUS"));
/*  4209: 4841 */       if ((origMaxStatus.equals("COMP")) || (origMaxStatus.equals("CLOSE"))) {
/*  4210: 4842 */         bShow = false;
/*  4211:      */       }
/*  4212: 4845 */       if ((wodatabean.getValue("WOISSWAP") != null) && (wodatabean.getValue("WOISSWAP").equals("1"))) {
/*  4213: 4850 */         if ((!control.getValue("event").equalsIgnoreCase("moveSwapAsset")) && (!((String)event.getValue()).equals("wolocspecs")) && (!((String)event.getValue()).equals("wocispecs"))) {
/*  4214: 4853 */           bShow = false;
/*  4215:      */         }
/*  4216:      */       }
/*  4217: 4856 */       control.setVisibility(bShow);
/*  4218:      */     }
/*  4219: 4858 */     return true;
/*  4220:      */   }
/*  4221:      */   
/*  4222:      */   public boolean woadhocdownloadAssetWO(UIEvent event)
/*  4223:      */     throws MobileApplicationException
/*  4224:      */   {
/*  4225: 4863 */     return downloadAdHocWO(event);
/*  4226:      */   }
/*  4227:      */   
/*  4228:      */   public boolean woadhocdownloadLocWO(UIEvent event)
/*  4229:      */     throws MobileApplicationException
/*  4230:      */   {
/*  4231: 4868 */     return downloadAdHocWO(event);
/*  4232:      */   }
/*  4233:      */   
/*  4234:      */   public boolean downloadAdHocWO(UIEvent event)
/*  4235:      */     throws MobileApplicationException
/*  4236:      */   {
/*  4237: 4873 */     AbstractMobileControl callingControl = (AbstractMobileControl)event.getCreatingObject();
/*  4238: 4874 */     MobileMboDataBean dataBean = callingControl.getDataBean();
/*  4239: 4875 */     MobileMbo mobileMbo = dataBean.getMobileMbo();
/*  4240: 4876 */     if ((dataBean.getName().equalsIgnoreCase("ASSET_WOS")) || (dataBean.getName().equalsIgnoreCase("LOC_WOS"))) {
/*  4241: 4878 */       dataBean = getCachedDataBean("WORKORDER");
/*  4242:      */     }
/*  4243: 4880 */     return downloadAdHocRecord(event, dataBean, mobileMbo.getId() + "");
/*  4244:      */   }
/*  4245:      */   
/*  4246:      */   public boolean woadhocdownloadAssetTK(UIEvent event)
/*  4247:      */     throws MobileApplicationException
/*  4248:      */   {
/*  4249: 4885 */     return downloadAdHocTK(event);
/*  4250:      */   }
/*  4251:      */   
/*  4252:      */   public boolean woadhocdownloadLocTK(UIEvent event)
/*  4253:      */     throws MobileApplicationException
/*  4254:      */   {
/*  4255: 4890 */     return downloadAdHocTK(event);
/*  4256:      */   }
/*  4257:      */   
/*  4258:      */   public boolean downloadAdHocTK(UIEvent event)
/*  4259:      */     throws MobileApplicationException
/*  4260:      */   {
/*  4261: 4895 */     AbstractMobileControl callingControl = (AbstractMobileControl)event.getCreatingObject();
/*  4262: 4896 */     MobileMboDataBean dataBean = callingControl.getDataBean();
/*  4263: 4897 */     MobileMbo mobileMbo = dataBean.getMobileMbo();
/*  4264: 4898 */     if ((dataBean.getName().equalsIgnoreCase("ASSET_TICKETS")) || (dataBean.getName().equalsIgnoreCase("LOC_TICKETS"))) {
/*  4265: 4900 */       dataBean = getCachedDataBean("TICKET");
/*  4266:      */     }
/*  4267: 4902 */     return downloadAdHocRecord(event, dataBean, mobileMbo.getId() + "");
/*  4268:      */   }
/*  4269:      */   
/*  4270:      */   public boolean initInvAvailability(UIEvent event)
/*  4271:      */     throws MobileApplicationException
/*  4272:      */   {
/*  4273: 4908 */     MobileMboDataBean databean = ((PageControl)event.getCreatingObject()).getDataBean();
/*  4274: 4909 */     refreshInvAvailability(event, databean);
/*  4275:      */     
/*  4276: 4911 */     return true;
/*  4277:      */   }
/*  4278:      */   
/*  4279:      */   public boolean refreshInvAvailability(UIEvent event)
/*  4280:      */     throws MobileApplicationException
/*  4281:      */   {
/*  4282: 4916 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/*  4283: 4917 */     refreshInvAvailability(event, databean);
/*  4284:      */     
/*  4285: 4919 */     return true;
/*  4286:      */   }
/*  4287:      */   
/*  4288:      */   public boolean refreshInvAvailability(UIEvent event, MobileMboDataBean databean)
/*  4289:      */     throws MobileApplicationException
/*  4290:      */   {
/*  4291: 4924 */     if (databean != null)
/*  4292:      */     {
/*  4293: 4928 */       if (databean.isFiltered())
/*  4294:      */       {
/*  4295: 4930 */         databean.getQBE().setQbeExactMatch(false);
/*  4296: 4931 */         databean.reset();
/*  4297: 4932 */         return true;
/*  4298:      */       }
/*  4299: 4934 */       databean.getQBE().reset();
/*  4300: 4935 */       databean.setOnline(true);
/*  4301: 4936 */       databean.getQBE().setQbeExactMatch(true);
/*  4302:      */       
/*  4303: 4938 */       MobileMboDataBean mrlinedatabean = DataBeanCache.findDataBean("MRLINE");
/*  4304:      */       
/*  4305: 4940 */       String internalLineType = ((WOApp)UIUtil.getApplication()).getInternalValue(databean, "MRLINETYPE", mrlinedatabean.getValue("LINETYPE"));
/*  4306: 4943 */       if (internalLineType.equals("ITEM")) {
/*  4307: 4944 */         databean.getQBE().setQBE("ITEMNUM", mrlinedatabean.getValue("ITEM"));
/*  4308: 4945 */       } else if (internalLineType.equals("TOOL")) {
/*  4309: 4946 */         databean.getQBE().setQBE("ITEMNUM", mrlinedatabean.getValue("TOOL"));
/*  4310:      */       }
/*  4311: 4948 */       databean.getQBE().setQBE("ITEMSETID", mrlinedatabean.getValue("ITEMSETID"));
/*  4312:      */       
/*  4313: 4950 */       databean.reset();
/*  4314:      */       
/*  4315:      */ 
/*  4316:      */ 
/*  4317:      */ 
/*  4318:      */ 
/*  4319:      */ 
/*  4320:      */ 
/*  4321: 4958 */       int count = databean.count();
/*  4322: 4959 */       for (int i = count - 1; i >= 0; i--) {
/*  4323: 4961 */         databean.setValue(i, "QTY", databean.getValue(i, "AVBLBALANCE"));
/*  4324:      */       }
/*  4325:      */     }
/*  4326: 4999 */     return true;
/*  4327:      */   }
/*  4328:      */   
/*  4329:      */   public boolean selectInvAvailability(UIEvent event)
/*  4330:      */     throws MobileApplicationException
/*  4331:      */   {
/*  4332: 5004 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/*  4333: 5005 */     MobileMboDataBean mrlinedatabean = DataBeanCache.findDataBean("MRLINE");
/*  4334: 5006 */     if (databean != null)
/*  4335:      */     {
/*  4336: 5008 */       mrlinedatabean.setValue("STORELOC", databean.getValue("LOCATION"));
/*  4337: 5009 */       mrlinedatabean.setValue("STORELOCSITE", databean.getValue("SITEID"));
/*  4338:      */     }
/*  4339: 5011 */     UIUtil.closePage();
/*  4340: 5012 */     return true;
/*  4341:      */   }
/*  4342:      */   
/*  4343:      */   public boolean setitemqbe(UIEvent event)
/*  4344:      */     throws MobileApplicationException
/*  4345:      */   {
/*  4346: 5018 */     MobileMboDataBean databean = ((PageControl)event.getCreatingObject()).getDataBean();
/*  4347: 5019 */     if (databean != null)
/*  4348:      */     {
/*  4349: 5021 */       String synValues = ((WOApp)UIUtil.getApplication()).getSynonymValues(databean, "ITEMTYPE", "ITEM");
/*  4350:      */       
/*  4351:      */ 
/*  4352: 5024 */       MobileMboDataBean parentDataBean = ((PageControl)event.getCreatingObject()).getLaunchingControl().getDataBean();
/*  4353: 5025 */       if (parentDataBean != null)
/*  4354:      */       {
/*  4355: 5028 */         ItemFilter filter = new ItemFilter(databean);
/*  4356: 5029 */         List statuses = ItemFilter.translateItemStatusName(parentDataBean, new String[] { "ACTIVE", "PENDOBS" });
/*  4357:      */         
/*  4358: 5031 */         filter.applyInventoryFilter("ITEMINVENTORY", statuses);
/*  4359:      */         
/*  4360: 5033 */         MobileMboQBE qbe = databean.getQBE();
/*  4361: 5034 */         qbe.reset();
/*  4362:      */         
/*  4363:      */ 
/*  4364:      */ 
/*  4365:      */ 
/*  4366: 5039 */         parentDataBean = parentDataBean.getParentBean();
/*  4367: 5040 */         if (parentDataBean != null) {
/*  4368: 5042 */           qbe.setLookupParameter("WORKORDER", "ORGID", parentDataBean.getValue("ORGID"));
/*  4369:      */         } else {
/*  4370: 5048 */           qbe.setLookupParameter("WORKORDER", "ORGID", "");
/*  4371:      */         }
/*  4372: 5051 */         qbe.setLookupParameter("MATUSETRANS", "STORELOC", "");
/*  4373: 5052 */         qbe.setLookupParameter("MATUSETRANS", "SITEID", "");
/*  4374: 5053 */         qbe.setLookupParameter("MATUSETRANS", "BINNUM", "");
/*  4375: 5054 */         qbe.setLookupParameter("MATUSETRANS", "LOTNUM", "");
/*  4376: 5055 */         qbe.setQBE("DISPLAY_IN_LOOKUP", "1");
/*  4377: 5056 */         qbe.setQBE("ITEMTYPE", synValues);
/*  4378:      */       }
/*  4379: 5061 */       databean.reset();
/*  4380:      */       
/*  4381: 5063 */       String pageId = ((PageControl)event.getCreatingObject()).getId();
/*  4382: 5064 */       if ("matlookup".equalsIgnoreCase(pageId))
/*  4383:      */       {
/*  4384: 5065 */         int count = databean.count();
/*  4385: 5067 */         for (int i = 0; i < count; i++) {
/*  4386: 5068 */           databean.getMobileMbo(i).setDoubleValue("QTY", 1.0D);
/*  4387:      */         }
/*  4388:      */       }
/*  4389:      */     }
/*  4390: 5072 */     return true;
/*  4391:      */   }
/*  4392:      */   
/*  4393:      */   public boolean canchangestatus(UIEvent event)
/*  4394:      */     throws MobileApplicationException
/*  4395:      */   {
/*  4396: 5097 */     MobileMboDataBean wodatabean = UIUtil.getCurrentScreen().getDataBean();
/*  4397: 5098 */     if ((wodatabean != null) && (!wodatabean.getName().equals("WORKORDER"))) {
/*  4398: 5099 */       wodatabean = DataBeanCache.findDataBean("WORKORDER");
/*  4399:      */     }
/*  4400: 5101 */     if ((wodatabean != null) && (wodatabean.getName().equals("WORKORDER")))
/*  4401:      */     {
/*  4402: 5103 */       boolean bShow = true;
/*  4403:      */       
/*  4404: 5105 */       String maxStatus = ((WOApp)UIUtil.getApplication()).getInternalValue(wodatabean, "WOSTATUS", wodatabean.getValue("STATUS"));
/*  4405: 5109 */       if ((maxStatus.equals("COMP")) || (maxStatus.equals("CLOSE")) || (maxStatus.equals("CAN"))) {
/*  4406: 5110 */         bShow = false;
/*  4407:      */       }
/*  4408: 5112 */       ((AbstractMobileControl)event.getCreatingObject()).setVisibility(bShow);
/*  4409:      */     }
/*  4410: 5114 */     return true;
/*  4411:      */   }
/*  4412:      */   
/*  4413:      */   public boolean canchangetaskstatus(UIEvent event)
/*  4414:      */     throws MobileApplicationException
/*  4415:      */   {
/*  4416: 5119 */     MobileMboDataBean wodatabean = UIUtil.getCurrentScreen().getDataBean();
/*  4417: 5120 */     if ((wodatabean != null) && (!wodatabean.getName().equals("WOTASKS"))) {
/*  4418: 5121 */       wodatabean = DataBeanCache.findDataBean("WOTASKS");
/*  4419:      */     }
/*  4420: 5123 */     if ((wodatabean != null) && (wodatabean.getName().equals("WOTASKS")))
/*  4421:      */     {
/*  4422: 5125 */       boolean bShow = true;
/*  4423:      */       
/*  4424: 5127 */       String maxStatus = ((WOApp)UIUtil.getApplication()).getInternalValue(wodatabean, "WOSTATUS", wodatabean.getValue("STATUS"));
/*  4425: 5130 */       if ((maxStatus.equals("COMP")) || (maxStatus.equals("CLOSE")) || (maxStatus.equals("CAN"))) {
/*  4426: 5131 */         bShow = false;
/*  4427:      */       }
/*  4428: 5133 */       ((AbstractMobileControl)event.getCreatingObject()).setVisibility(bShow);
/*  4429:      */     }
/*  4430: 5135 */     return true;
/*  4431:      */   }
/*  4432:      */   
/*  4433:      */   public boolean cancapturesignature(UIEvent event)
/*  4434:      */     throws MobileApplicationException
/*  4435:      */   {
/*  4436: 5140 */     MobileMboDataBean wodatabean = UIUtil.getCurrentScreen().getDataBean();
/*  4437: 5141 */     if ((wodatabean != null) && (!wodatabean.getName().equals("WORKORDER"))) {
/*  4438: 5142 */       wodatabean = DataBeanCache.findDataBean("WORKORDER");
/*  4439:      */     }
/*  4440: 5144 */     if ((wodatabean != null) && (wodatabean.getName().equals("WORKORDER")))
/*  4441:      */     {
/*  4442: 5146 */       boolean bShow = true;
/*  4443:      */       
/*  4444: 5148 */       String maxStatus = ((WOApp)UIUtil.getApplication()).getInternalValue(wodatabean, "WOSTATUS", wodatabean.getValue("STATUS"));
/*  4445: 5151 */       if (maxStatus.equals("CLOSE")) {
/*  4446: 5152 */         bShow = false;
/*  4447:      */       }
/*  4448: 5154 */       ((AbstractMobileControl)event.getCreatingObject()).setVisibility(bShow);
/*  4449:      */     }
/*  4450: 5156 */     return true;
/*  4451:      */   }
/*  4452:      */   
/*  4453:      */   public boolean initWOAssetPage(UIEvent event)
/*  4454:      */     throws MobileApplicationException
/*  4455:      */   {
/*  4456: 5162 */     MobileMboDataBean databean = ((PageControl)event.getCreatingObject()).getDataBean();
/*  4457: 5163 */     if (databean != null)
/*  4458:      */     {
/*  4459: 5165 */       String fieldname = "ASSETNUM";
/*  4460:      */       
/*  4461: 5167 */       MobileMboDataBean srcdatabean = UIUtil.getCurrentScreen().getDataBean();
/*  4462:      */       
/*  4463:      */ 
/*  4464:      */ 
/*  4465: 5171 */       String pagegroup = null;
/*  4466: 5172 */       if (UIUtil.getCurrentScreen().getPageGroup() != null) {
/*  4467: 5173 */         pagegroup = UIUtil.getCurrentScreen().getPageGroup().getDataBean().getName();
/*  4468:      */       }
/*  4469: 5174 */       if ((pagegroup == null) || (!pagegroup.equalsIgnoreCase("ASSET")))
/*  4470:      */       {
/*  4471: 5176 */         databean.getQBE().reset();
/*  4472: 5177 */         databean.getQBE().setQbeExactMatch(true);
/*  4473: 5179 */         if (srcdatabean.getValue(fieldname) == "") {
/*  4474: 5180 */           databean.getQBE().setQBE("ASSETNUM", "~NULL~");
/*  4475:      */         } else {
/*  4476: 5182 */           databean.getQBE().setQBE("ASSETNUM", srcdatabean.getValue(fieldname));
/*  4477:      */         }
/*  4478: 5183 */         databean.getQBE().setQBE("SITEID", srcdatabean.getValue("SITEID"));
/*  4479: 5184 */         databean.reset();
/*  4480: 5185 */         if (databean.getMobileMbo(0) != null) {
/*  4481: 5186 */           databean.setCurrentPosition(0);
/*  4482:      */         }
/*  4483:      */       }
/*  4484:      */     }
/*  4485: 5190 */     return true;
/*  4486:      */   }
/*  4487:      */   
/*  4488:      */   public boolean initWOLocPage(UIEvent event)
/*  4489:      */     throws MobileApplicationException
/*  4490:      */   {
/*  4491: 5196 */     MobileMboDataBean databean = ((PageControl)event.getCreatingObject()).getDataBean();
/*  4492: 5197 */     if (databean != null)
/*  4493:      */     {
/*  4494: 5199 */       String fieldname = "LOCATION";
/*  4495:      */       
/*  4496: 5201 */       MobileMboDataBean srcdatabean = UIUtil.getCurrentScreen().getDataBean();
/*  4497:      */       
/*  4498:      */ 
/*  4499:      */ 
/*  4500: 5205 */       String pagegroup = null;
/*  4501: 5206 */       if (UIUtil.getCurrentScreen().getPageGroup() != null) {
/*  4502: 5207 */         pagegroup = UIUtil.getCurrentScreen().getPageGroup().getDataBean().getName();
/*  4503:      */       }
/*  4504: 5208 */       if ((pagegroup == null) || (!pagegroup.equalsIgnoreCase("LOCATIONS")))
/*  4505:      */       {
/*  4506: 5210 */         databean.getQBE().reset();
/*  4507: 5211 */         databean.getQBE().setQbeExactMatch(true);
/*  4508: 5213 */         if (srcdatabean.getValue(fieldname) == "") {
/*  4509: 5214 */           databean.getQBE().setQBE("LOCATION", "~NULL~");
/*  4510:      */         } else {
/*  4511: 5216 */           databean.getQBE().setQBE("LOCATION", srcdatabean.getValue(fieldname));
/*  4512:      */         }
/*  4513: 5217 */         databean.getQBE().setQBE("SITEID", srcdatabean.getValue("SITEID"));
/*  4514: 5218 */         databean.reset();
/*  4515: 5219 */         if (databean.getMobileMbo(0) != null) {
/*  4516: 5220 */           databean.setCurrentPosition(0);
/*  4517:      */         }
/*  4518:      */       }
/*  4519:      */     }
/*  4520: 5224 */     return true;
/*  4521:      */   }
/*  4522:      */   
/*  4523:      */   public boolean toggleShowMRErrors(UIEvent event)
/*  4524:      */     throws MobileApplicationException
/*  4525:      */   {
/*  4526: 5229 */     MobileMboDataBean tableBean = DataBeanCache.findDataBean("MR");
/*  4527: 5230 */     tableBean.getDataBeanManager().save();
/*  4528:      */     
/*  4529: 5232 */     MobileMboDataBean allflagsBean = WOApp.getWpAllFlags();
/*  4530: 5233 */     if (allflagsBean == null) {
/*  4531: 5234 */       return true;
/*  4532:      */     }
/*  4533: 5236 */     String sValue = (String)event.getValue();
/*  4534: 5237 */     boolean showshowerrors = false;
/*  4535: 5238 */     if ((sValue != null) && (sValue.equalsIgnoreCase("true"))) {
/*  4536: 5239 */       showshowerrors = true;
/*  4537:      */     }
/*  4538: 5241 */     if (showshowerrors)
/*  4539:      */     {
/*  4540: 5243 */       tableBean.setErrorFilter();
/*  4541: 5244 */       allflagsBean.setValue("SHOWMRERRORSONLY", "1");
/*  4542:      */     }
/*  4543:      */     else
/*  4544:      */     {
/*  4545: 5248 */       tableBean.getQBE().reset();
/*  4546: 5249 */       tableBean.reset();
/*  4547: 5250 */       allflagsBean.setValue("SHOWMRERRORSONLY", "0");
/*  4548:      */     }
/*  4549: 5253 */     allflagsBean.getDataBeanManager().save();
/*  4550: 5254 */     tableBean.reset();
/*  4551:      */     
/*  4552: 5256 */     return true;
/*  4553:      */   }
/*  4554:      */   
/*  4555:      */   public boolean gotoerrorpage(UIEvent event)
/*  4556:      */     throws MobileApplicationException
/*  4557:      */   {
/*  4558: 5261 */     AbstractMobileControl callingControl = (AbstractMobileControl)event.getCreatingObject();
/*  4559: 5262 */     if (callingControl.getStringValue("targettabid").equals("woresultsT6"))
/*  4560:      */     {
/*  4561: 5264 */       MobileMboDataBean allflagsBean = WOApp.getWpAllFlags();
/*  4562: 5265 */       allflagsBean.setValue("SHOWMRERRORSONLY", "1");
/*  4563: 5266 */       allflagsBean.getDataBeanManager().save();
/*  4564:      */     }
/*  4565: 5269 */     callingControl.getDataBean().setErrorFilter();
/*  4566: 5270 */     UIUtil.gotoPage((String)event.getValue(), (AbstractMobileControl)event.getCreatingObject());
/*  4567: 5271 */     UIEvent uievent = new UIEvent(this, "gototab", null, callingControl.getStringValue("targettabid"));
/*  4568: 5272 */     UIUtil.getCurrentScreen().sendEventDown(uievent);
/*  4569: 5273 */     return true;
/*  4570:      */   }
/*  4571:      */   
/*  4572:      */   public boolean iswobased(UIEvent event)
/*  4573:      */     throws MobileApplicationException
/*  4574:      */   {
/*  4575: 5279 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/*  4576: 5280 */     if (UIUtil.getCurrentScreen().getPageGroup() != null)
/*  4577:      */     {
/*  4578: 5282 */       String curScreenId = UIUtil.getCurrentScreen().getPageGroup().getId();
/*  4579: 5283 */       if ((curScreenId.equalsIgnoreCase("assetgroup")) || (curScreenId.equalsIgnoreCase("locgroup")))
/*  4580:      */       {
/*  4581: 5285 */         ((AbstractMobileControl)event.getCreatingObject()).setVisibility(false);
/*  4582: 5286 */         return true;
/*  4583:      */       }
/*  4584:      */     }
/*  4585: 5289 */     if ((databean != null) && ((databean.getName().equals("ASSET")) || (databean.getName().equals("LOCATIONS")))) {
/*  4586: 5290 */       databean = ((PageControl)UIUtil.getCurrentScreen()).getLaunchingControl().getDataBean();
/*  4587:      */     }
/*  4588: 5293 */     if ((databean != null) && ((databean.getName().equals("TICKET")) || (databean.getName().equals("TKMULTIASSETLOCCI"))))
/*  4589:      */     {
/*  4590: 5295 */       ((AbstractMobileControl)event.getCreatingObject()).setVisibility(false);
/*  4591: 5296 */       return true;
/*  4592:      */     }
/*  4593: 5299 */     return true;
/*  4594:      */   }
/*  4595:      */   
/*  4596:      */   public boolean isworkorder(UIEvent event)
/*  4597:      */     throws MobileApplicationException
/*  4598:      */   {
/*  4599: 5304 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/*  4600: 5305 */     if (databean != null)
/*  4601:      */     {
/*  4602: 5307 */       boolean bShow = false;
/*  4603: 5308 */       String woclass = ((WOApp)UIUtil.getApplication()).getInternalValue(databean, "WOCLASS", databean.getValue("CLASS"));
/*  4604: 5310 */       if ((woclass.equals("WORKORDER")) || (woclass.equals("ACTIVITY")) || (woclass.equals("CHANGE")) || (woclass.equals("RELEASE")))
/*  4605:      */       {
/*  4606: 5313 */         bShow = true;
/*  4607:      */         
/*  4608:      */ 
/*  4609: 5316 */         setWorklistRecordBean(event, null);
/*  4610:      */       }
/*  4611: 5319 */       ((AbstractMobileControl)event.getCreatingObject()).setVisibility(bShow);
/*  4612:      */     }
/*  4613: 5321 */     return true;
/*  4614:      */   }
/*  4615:      */   
/*  4616:      */   public boolean ischange(UIEvent event)
/*  4617:      */     throws MobileApplicationException
/*  4618:      */   {
/*  4619: 5326 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/*  4620: 5328 */     if (databean != null)
/*  4621:      */     {
/*  4622: 5330 */       boolean bShow = false;
/*  4623: 5331 */       String woclass = ((WOApp)UIUtil.getApplication()).getInternalValue(databean, "WOCLASS", databean.getValue("WOCLASS"));
/*  4624: 5332 */       if (woclass.equals("CHANGE")) {
/*  4625: 5334 */         bShow = true;
/*  4626:      */       }
/*  4627: 5337 */       ((AbstractMobileControl)event.getCreatingObject()).setVisibility(bShow);
/*  4628: 5341 */       if ((event.getCreatingObject() instanceof InputControl))
/*  4629:      */       {
/*  4630: 5343 */         InputControl ic = (InputControl)event.getCreatingObject();
/*  4631: 5344 */         if ((ic.isRequired()) && (!bShow)) {
/*  4632: 5346 */           ic.setRequired(bShow);
/*  4633:      */         }
/*  4634:      */       }
/*  4635:      */     }
/*  4636: 5350 */     return true;
/*  4637:      */   }
/*  4638:      */   
/*  4639:      */   public boolean ischangeorrelease(UIEvent event)
/*  4640:      */     throws MobileApplicationException
/*  4641:      */   {
/*  4642: 5355 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/*  4643: 5357 */     if (databean != null)
/*  4644:      */     {
/*  4645: 5359 */       if (databean.getName().equalsIgnoreCase("AREASAFFECTED")) {
/*  4646: 5360 */         databean = databean.getParentBean();
/*  4647:      */       }
/*  4648: 5362 */       boolean bShow = false;
/*  4649: 5363 */       String woclass = ((WOApp)UIUtil.getApplication()).getInternalValue(databean, "WOCLASS", databean.getValue("WOCLASS"));
/*  4650: 5364 */       if ((woclass.equals("CHANGE")) || (woclass.equals("RELEASE"))) {
/*  4651: 5366 */         bShow = true;
/*  4652:      */       }
/*  4653: 5369 */       ((AbstractMobileControl)event.getCreatingObject()).setVisibility(bShow);
/*  4654:      */     }
/*  4655: 5371 */     return true;
/*  4656:      */   }
/*  4657:      */   
/*  4658:      */   public boolean iswooractivity(UIEvent event)
/*  4659:      */     throws MobileApplicationException
/*  4660:      */   {
/*  4661: 5376 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/*  4662: 5378 */     if (databean != null)
/*  4663:      */     {
/*  4664: 5380 */       boolean bShow = false;
/*  4665: 5381 */       String woclass = ((WOApp)UIUtil.getApplication()).getInternalValue(databean, "WOCLASS", databean.getValue("WOCLASS"));
/*  4666: 5382 */       if ((woclass.equals("WORKORDER")) || (woclass.equals("ACTIVITY"))) {
/*  4667: 5384 */         bShow = true;
/*  4668:      */       }
/*  4669: 5387 */       ((AbstractMobileControl)event.getCreatingObject()).setVisibility(bShow);
/*  4670: 5391 */       if ((event.getCreatingObject() instanceof InputControl))
/*  4671:      */       {
/*  4672: 5393 */         InputControl ic = (InputControl)event.getCreatingObject();
/*  4673: 5394 */         if ((ic.isRequired()) && (!bShow)) {
/*  4674: 5396 */           ic.setRequired(bShow);
/*  4675:      */         }
/*  4676:      */       }
/*  4677:      */     }
/*  4678: 5400 */     return true;
/*  4679:      */   }
/*  4680:      */   
/*  4681:      */   public boolean isrelease(UIEvent event)
/*  4682:      */     throws MobileApplicationException
/*  4683:      */   {
/*  4684: 5405 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/*  4685: 5407 */     if (databean != null)
/*  4686:      */     {
/*  4687: 5409 */       boolean bShow = false;
/*  4688: 5410 */       String woclass = ((WOApp)UIUtil.getApplication()).getInternalValue(databean, "WOCLASS", databean.getValue("WOCLASS"));
/*  4689: 5411 */       if (woclass.equals("RELEASE")) {
/*  4690: 5413 */         bShow = true;
/*  4691:      */       }
/*  4692: 5416 */       ((AbstractMobileControl)event.getCreatingObject()).setVisibility(bShow);
/*  4693: 5420 */       if ((event.getCreatingObject() instanceof InputControl))
/*  4694:      */       {
/*  4695: 5422 */         InputControl ic = (InputControl)event.getCreatingObject();
/*  4696: 5423 */         if ((ic.isRequired()) && (!bShow)) {
/*  4697: 5425 */           ic.setRequired(bShow);
/*  4698:      */         }
/*  4699:      */       }
/*  4700:      */     }
/*  4701: 5429 */     return true;
/*  4702:      */   }
/*  4703:      */   
/*  4704:      */   public boolean isticket(UIEvent event)
/*  4705:      */     throws MobileApplicationException
/*  4706:      */   {
/*  4707: 5434 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/*  4708: 5436 */     if (databean != null)
/*  4709:      */     {
/*  4710: 5438 */       boolean bShow = false;
/*  4711: 5439 */       String tkclass = ((WOApp)UIUtil.getApplication()).getInternalValue(databean, "TKCLASS", databean.getValue("CLASS"));
/*  4712: 5440 */       if ((tkclass.equals("INCIDENT")) || (tkclass.equals("PROBLEM")) || (tkclass.equals("SR")))
/*  4713:      */       {
/*  4714: 5443 */         bShow = true;
/*  4715:      */         
/*  4716:      */ 
/*  4717: 5446 */         setWorklistRecordBean(event, null);
/*  4718:      */       }
/*  4719: 5449 */       ((AbstractMobileControl)event.getCreatingObject()).setVisibility(bShow);
/*  4720:      */     }
/*  4721: 5451 */     return true;
/*  4722:      */   }
/*  4723:      */   
/*  4724:      */   public MobileMboDataBean getWorklistRecordBean(UIEvent event)
/*  4725:      */     throws MobileApplicationException
/*  4726:      */   {
/*  4727: 5456 */     boolean qbeByKeyField = false;
/*  4728:      */     
/*  4729: 5458 */     String mobileMboName = "";
/*  4730:      */     
/*  4731: 5460 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/*  4732:      */     
/*  4733:      */ 
/*  4734:      */ 
/*  4735: 5464 */     MobileMbo mobileMbo = databean.getMobileMbo();
/*  4736: 5465 */     if (mobileMbo != null)
/*  4737:      */     {
/*  4738: 5466 */       String recId = mobileMbo.getValue("_RECID");
/*  4739: 5468 */       if ((recId == null) || (recId.equalsIgnoreCase(""))) {
/*  4740: 5469 */         qbeByKeyField = true;
/*  4741:      */       }
/*  4742: 5472 */       String recClass = "";
/*  4743: 5473 */       if ((databean.getName().equalsIgnoreCase("WORKORDER")) || (databean.getName().equalsIgnoreCase("WOCHILDREN"))) {
/*  4744: 5475 */         recClass = databean.getValue("WOCLASS");
/*  4745: 5476 */       } else if (databean.getName().equalsIgnoreCase("TICKET")) {
/*  4746: 5477 */         recClass = databean.getValue("CLASS");
/*  4747:      */       } else {
/*  4748: 5479 */         recClass = databean.getValue("CLASS");
/*  4749:      */       }
/*  4750: 5481 */       String woclass = ((WOApp)UIUtil.getApplication()).getInternalValue(databean, "WOCLASS", recClass);
/*  4751:      */       
/*  4752: 5483 */       String tkclass = ((WOApp)UIUtil.getApplication()).getInternalValue(databean, "TKCLASS", recClass);
/*  4753: 5486 */       if ((woclass.equalsIgnoreCase("WORKORDER")) || (woclass.equalsIgnoreCase("CHANGE")) || (woclass.equalsIgnoreCase("ACTIVITY")) || (woclass.equalsIgnoreCase("RELEASE"))) {
/*  4754: 5490 */         mobileMboName = "WORKORDER";
/*  4755: 5491 */       } else if ((tkclass.equalsIgnoreCase("SR")) || (tkclass.equalsIgnoreCase("INCIDENT")) || (tkclass.equalsIgnoreCase("PROBLEM"))) {
/*  4756: 5494 */         mobileMboName = "TICKET";
/*  4757:      */       }
/*  4758: 5497 */       MobileMboDataBean recordBean = null;
/*  4759: 5499 */       if (qbeByKeyField)
/*  4760:      */       {
/*  4761: 5501 */         MobileMboDataBeanManager mgr = new MobileMboDataBeanManager(mobileMboName);
/*  4762: 5502 */         recordBean = mgr.getDataBean();
/*  4763:      */         
/*  4764: 5504 */         recordBean.getQBE().reset();
/*  4765: 5505 */         recordBean.getQBE().setQbeExactMatch(true);
/*  4766: 5507 */         if (mobileMboName.equalsIgnoreCase("WORKORDER"))
/*  4767:      */         {
/*  4768: 5508 */           recordBean.getQBE().setQBE("WONUM", databean.getMobileMbo().getValue("WONUM"));
/*  4769: 5509 */           recordBean.getQBE().setQBE("WOCLASS", databean.getMobileMbo().getValue("WOCLASS"));
/*  4770:      */         }
/*  4771: 5510 */         else if (mobileMboName.equalsIgnoreCase("TICKET"))
/*  4772:      */         {
/*  4773: 5511 */           recordBean.getQBE().setQBE("TICKETID", databean.getMobileMbo().getValue("TICKETID"));
/*  4774: 5512 */           recordBean.getQBE().setQBE("CLASS", databean.getMobileMbo().getValue("CLASS"));
/*  4775:      */         }
/*  4776: 5514 */         recordBean.reset();
/*  4777: 5515 */         recordBean.setCurrentPosition(0);
/*  4778:      */       }
/*  4779:      */       else
/*  4780:      */       {
/*  4781: 5518 */         MobileMboDataBeanManager mgr = new MobileMboDataBeanManager(mobileMboName);
/*  4782: 5519 */         recordBean = mgr.getDataBean();
/*  4783: 5520 */         recordBean.getQBE().reset();
/*  4784: 5521 */         recordBean.getQBE().setQbeExactMatch(true);
/*  4785: 5522 */         recordBean.getQBE().setQBE("_ID", recId);
/*  4786: 5523 */         recordBean.reset();
/*  4787: 5524 */         recordBean.setCurrentPosition(0);
/*  4788:      */       }
/*  4789: 5527 */       return recordBean;
/*  4790:      */     }
/*  4791: 5529 */     return null;
/*  4792:      */   }
/*  4793:      */   
/*  4794:      */   public MobileMboDataBean setWorklistRecordBean(UIEvent event, MobileMboDataBean databean)
/*  4795:      */     throws MobileApplicationException
/*  4796:      */   {
/*  4797: 5535 */     boolean qbeByKeyField = false;
/*  4798:      */     
/*  4799: 5537 */     String mobileMboName = "";
/*  4800: 5539 */     if (databean == null) {
/*  4801: 5540 */       databean = UIUtil.getCurrentScreen().getDataBean();
/*  4802:      */     }
/*  4803: 5544 */     MobileMbo mobileMbo = databean.getMobileMbo();
/*  4804: 5545 */     if (mobileMbo != null)
/*  4805:      */     {
/*  4806: 5546 */       String recId = mobileMbo.getValue("_RECID");
/*  4807: 5548 */       if ((recId == null) || (recId.equalsIgnoreCase(""))) {
/*  4808: 5549 */         qbeByKeyField = true;
/*  4809:      */       }
/*  4810: 5552 */       String recClass = "";
/*  4811: 5553 */       if ((databean.getName().equalsIgnoreCase("WORKORDER")) || (databean.getName().equalsIgnoreCase("WOCHILDREN")) || (databean.getName().equalsIgnoreCase("WOACTIVITY"))) {
/*  4812: 5555 */         recClass = databean.getValue("WOCLASS");
/*  4813: 5556 */       } else if (databean.getName().equalsIgnoreCase("TICKET")) {
/*  4814: 5557 */         recClass = databean.getValue("CLASS");
/*  4815:      */       } else {
/*  4816: 5559 */         recClass = databean.getValue("CLASS");
/*  4817:      */       }
/*  4818: 5561 */       String woclass = ((WOApp)UIUtil.getApplication()).getInternalValue(databean, "WOCLASS", recClass);
/*  4819: 5562 */       String tkclass = ((WOApp)UIUtil.getApplication()).getInternalValue(databean, "TKCLASS", recClass);
/*  4820: 5564 */       if ((woclass.equalsIgnoreCase("WORKORDER")) || (woclass.equalsIgnoreCase("CHANGE")) || (woclass.equalsIgnoreCase("ACTIVITY")) || (woclass.equalsIgnoreCase("RELEASE"))) {
/*  4821: 5566 */         mobileMboName = "WORKORDER";
/*  4822: 5567 */       } else if ((tkclass.equalsIgnoreCase("SR")) || (tkclass.equalsIgnoreCase("INCIDENT")) || (tkclass.equalsIgnoreCase("PROBLEM"))) {
/*  4823: 5568 */         mobileMboName = "TICKET";
/*  4824:      */       }
/*  4825: 5571 */       MobileMboDataBean recordBean = getCachedDataBean(mobileMboName);
/*  4826: 5573 */       if (qbeByKeyField)
/*  4827:      */       {
/*  4828: 5574 */         recordBean.getQBE().reset();
/*  4829: 5575 */         recordBean.getQBE().setQbeExactMatch(true);
/*  4830: 5577 */         if (mobileMboName.equalsIgnoreCase("WORKORDER"))
/*  4831:      */         {
/*  4832: 5578 */           recordBean.getQBE().setQBE("WONUM", databean.getMobileMbo().getValue("WONUM"));
/*  4833: 5579 */           recordBean.getQBE().setQBE("WOCLASS", databean.getMobileMbo().getValue("WOCLASS"));
/*  4834:      */         }
/*  4835: 5580 */         else if (mobileMboName.equalsIgnoreCase("TICKET"))
/*  4836:      */         {
/*  4837: 5581 */           recordBean.getQBE().setQBE("TICKETID", databean.getMobileMbo().getValue("TICKETID"));
/*  4838: 5582 */           recordBean.getQBE().setQBE("CLASS", databean.getMobileMbo().getValue("CLASS"));
/*  4839:      */         }
/*  4840: 5585 */         recordBean.reset();
/*  4841: 5586 */         recordBean.setCurrentPosition(0);
/*  4842:      */       }
/*  4843: 5587 */       else if ((!recordBean.getValue("_ID").equals(recId)) || (recordBean.count() != 1))
/*  4844:      */       {
/*  4845: 5588 */         recordBean.getQBE().reset();
/*  4846: 5589 */         recordBean.getQBE().setQbeExactMatch(true);
/*  4847: 5590 */         recordBean.getQBE().setQBE("_ID", recId);
/*  4848: 5591 */         recordBean.reset();
/*  4849: 5592 */         recordBean.setCurrentPosition(0);
/*  4850:      */       }
/*  4851: 5594 */       return recordBean;
/*  4852:      */     }
/*  4853: 5596 */     return null;
/*  4854:      */   }
/*  4855:      */   
/*  4856:      */   public boolean gotoworklistmainpage(UIEvent event)
/*  4857:      */     throws MobileApplicationException
/*  4858:      */   {
/*  4859: 5602 */     String mobileMboName = setWorklistRecordBean(event, null).getName();
/*  4860: 5603 */     String pageToShow = null;
/*  4861: 5605 */     if (mobileMboName.equalsIgnoreCase("WORKORDER")) {
/*  4862: 5606 */       pageToShow = "womain";
/*  4863:      */     } else {
/*  4864: 5608 */       pageToShow = "ticketmain";
/*  4865:      */     }
/*  4866: 5610 */     if (pageToShow != null) {
/*  4867: 5611 */       UIUtil.showPage(pageToShow);
/*  4868:      */     }
/*  4869: 5613 */     return true;
/*  4870:      */   }
/*  4871:      */   
/*  4872:      */   public boolean gotoworklistview(UIEvent event, MobileMboDataBean databean)
/*  4873:      */     throws MobileApplicationException
/*  4874:      */   {
/*  4875: 5618 */     setWorklistRecordBean(event, databean);
/*  4876: 5619 */     String sMobileMboName = UIUtil.getCurrentScreen().getDataBean().getName();
/*  4877: 5620 */     String sCurrentRecClass = null;
/*  4878: 5621 */     if (sMobileMboName.equalsIgnoreCase("WORKORDER")) {
/*  4879: 5622 */       sCurrentRecClass = UIUtil.getCurrentScreen().getDataBean().getValue("WOCLASS");
/*  4880: 5623 */     } else if (sMobileMboName.equalsIgnoreCase("TICKET")) {
/*  4881: 5624 */       sCurrentRecClass = UIUtil.getCurrentScreen().getDataBean().getValue("CLASS");
/*  4882:      */     }
/*  4883: 5626 */     if (sCurrentRecClass == null) {
/*  4884: 5628 */       if (UIUtil.getCurrentScreen().getDataBean().getParentBean() != null)
/*  4885:      */       {
/*  4886: 5630 */         sMobileMboName = UIUtil.getCurrentScreen().getDataBean().getParentBean().getName();
/*  4887: 5631 */         if (sMobileMboName.equalsIgnoreCase("WORKORDER")) {
/*  4888: 5632 */           sCurrentRecClass = UIUtil.getCurrentScreen().getDataBean().getParentBean().getValue("WOCLASS");
/*  4889: 5633 */         } else if (sMobileMboName.equalsIgnoreCase("TICKET")) {
/*  4890: 5634 */           sCurrentRecClass = UIUtil.getCurrentScreen().getDataBean().getParentBean().getValue("CLASS");
/*  4891:      */         }
/*  4892:      */       }
/*  4893:      */     }
/*  4894: 5639 */     String recClass = "";
/*  4895: 5640 */     if (databean.getName().equalsIgnoreCase("WORKORDER")) {
/*  4896: 5641 */       recClass = databean.getValue("WOCLASS");
/*  4897: 5642 */     } else if (databean.getName().equalsIgnoreCase("TICKET")) {
/*  4898: 5643 */       recClass = databean.getValue("CLASS");
/*  4899:      */     } else {
/*  4900: 5645 */       recClass = databean.getValue("CLASS");
/*  4901:      */     }
/*  4902: 5647 */     if ((sCurrentRecClass == null) || (sCurrentRecClass.equalsIgnoreCase(recClass))) {
/*  4903: 5648 */       return true;
/*  4904:      */     }
/*  4905: 5655 */     String sCurrentPage = UIUtil.getCurrentScreen().getId();
/*  4906: 5656 */     String sNextPage = null;
/*  4907: 5657 */     String sCurrentTab = null;
/*  4908: 5658 */     TabGroupControl tgc = UIUtil.getTabGroup(UIUtil.getCurrentScreen());
/*  4909: 5659 */     if (tgc != null) {
/*  4910: 5660 */       sCurrentTab = tgc.getCurrentTab().getId();
/*  4911:      */     }
/*  4912: 5662 */     sCurrentPage = sCurrentPage.toLowerCase();
/*  4913: 5663 */     if (sCurrentTab != null) {
/*  4914: 5664 */       sCurrentPage = sCurrentPage + "^" + sCurrentTab;
/*  4915:      */     }
/*  4916: 5667 */     Hashtable ht = WOApp.getHtPageTabMap();
/*  4917: 5668 */     Enumeration i = ht.keys();
/*  4918: 5669 */     while (i.hasMoreElements())
/*  4919:      */     {
/*  4920: 5671 */       String sKey = (String)i.nextElement();
/*  4921: 5672 */       String sValue = (String)ht.get(sKey);
/*  4922: 5673 */       if (sValue.equalsIgnoreCase(sCurrentPage))
/*  4923:      */       {
/*  4924: 5675 */         StringTokenizer st = new StringTokenizer(sKey, "^");
/*  4925:      */         
/*  4926: 5677 */         String pagedesc = st.nextToken();
/*  4927: 5678 */         pagedesc = st.nextToken();
/*  4928: 5681 */         if (ht.containsKey(recClass.toLowerCase() + "^" + pagedesc))
/*  4929:      */         {
/*  4930: 5684 */           sNextPage = (String)ht.get(recClass.toLowerCase() + "^" + pagedesc); break;
/*  4931:      */         }
/*  4932: 5689 */         sNextPage = (String)ht.get(recClass.toLowerCase() + "^" + "main");
/*  4933:      */         
/*  4934: 5691 */         break;
/*  4935:      */       }
/*  4936:      */     }
/*  4937: 5695 */     String sNewPage = null;
/*  4938: 5696 */     String sNewTab = null;
/*  4939: 5698 */     if (sNextPage != null)
/*  4940:      */     {
/*  4941: 5700 */       StringTokenizer st = new StringTokenizer(sNextPage, "^");
/*  4942: 5701 */       if (st.hasMoreElements())
/*  4943:      */       {
/*  4944: 5703 */         sNewPage = st.nextToken();
/*  4945: 5704 */         if (st.hasMoreElements()) {
/*  4946: 5705 */           sNewTab = st.nextToken();
/*  4947:      */         }
/*  4948:      */       }
/*  4949:      */       else
/*  4950:      */       {
/*  4951: 5709 */         sNewPage = sNextPage;
/*  4952:      */       }
/*  4953:      */     }
/*  4954: 5713 */     if (sNewPage != null)
/*  4955:      */     {
/*  4956: 5715 */       UIUtil.showPage(sNewPage);
/*  4957: 5716 */       if (sNewTab != null)
/*  4958:      */       {
/*  4959: 5718 */         UIEvent uievent = new UIEvent(this, "gototab", null, sNewTab);
/*  4960: 5719 */         UIUtil.getCurrentScreen().sendEventDown(uievent);
/*  4961:      */       }
/*  4962:      */     }
/*  4963: 5723 */     return true;
/*  4964:      */   }
/*  4965:      */   
/*  4966:      */   public boolean showMainPage(UIEvent event, String recordclass)
/*  4967:      */     throws MobileApplicationException
/*  4968:      */   {
/*  4969: 5728 */     String sPage = null;
/*  4970: 5729 */     String sTab = null;
/*  4971:      */     
/*  4972:      */ 
/*  4973: 5732 */     Hashtable ht = WOApp.getHtPageTabMap();
/*  4974: 5733 */     if (ht.containsKey(recordclass.toLowerCase() + "^" + "main"))
/*  4975:      */     {
/*  4976: 5735 */       sPage = (String)ht.get(recordclass.toLowerCase() + "^" + "main");
/*  4977: 5736 */       StringTokenizer st = new StringTokenizer(sPage, "^");
/*  4978: 5737 */       if (st.hasMoreElements())
/*  4979:      */       {
/*  4980: 5739 */         sPage = st.nextToken();
/*  4981: 5740 */         if (st.hasMoreElements()) {
/*  4982: 5741 */           sTab = st.nextToken();
/*  4983:      */         }
/*  4984:      */       }
/*  4985: 5744 */       if (sPage != null)
/*  4986:      */       {
/*  4987: 5748 */         UIUtil.gotoPage(sPage, (AbstractMobileControl)event.getCreatingObject());
/*  4988: 5749 */         if (sTab != null)
/*  4989:      */         {
/*  4990: 5751 */           UIEvent uievent = new UIEvent(this, "gototab", null, sTab);
/*  4991: 5752 */           UIUtil.getCurrentScreen().sendEventDown(uievent);
/*  4992:      */         }
/*  4993:      */       }
/*  4994:      */     }
/*  4995: 5757 */     return true;
/*  4996:      */   }
/*  4997:      */   
/*  4998:      */   public static MobileMboDataBean getCachedDataBean(String dataBeanName)
/*  4999:      */     throws MobileApplicationException
/*  5000:      */   {
/*  5001: 5762 */     MobileMboDataBean dataBean = DataBeanCache.findDataBean(dataBeanName);
/*  5002: 5763 */     if (dataBean == null)
/*  5003:      */     {
/*  5004: 5765 */       MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager(dataBeanName);
/*  5005: 5766 */       dataBean = mgrDBMgr.getDataBean();
/*  5006:      */       
/*  5007:      */ 
/*  5008:      */ 
/*  5009:      */ 
/*  5010:      */ 
/*  5011:      */ 
/*  5012:      */ 
/*  5013:      */ 
/*  5014:      */ 
/*  5015: 5776 */       DataBeanCache.cacheDataBean(dataBeanName, new DataBeanCacheItem(dataBeanName, dataBeanName, dataBean));
/*  5016:      */     }
/*  5017: 5779 */     return dataBean;
/*  5018:      */   }
/*  5019:      */   
/*  5020:      */   public boolean deletenew(UIEvent event)
/*  5021:      */     throws MobileApplicationException
/*  5022:      */   {
/*  5023: 5785 */     if (!((AbstractMobileControl)event.getCreatingObject()).getDataBean().getName().equalsIgnoreCase("WORKLIST")) {
/*  5024: 5786 */       super.deletenew(event);
/*  5025:      */     }
/*  5026: 5788 */     if (event.getMsgResponse().equals("-1")) {
/*  5027: 5790 */       return super.deletenew(event);
/*  5028:      */     }
/*  5029: 5792 */     if (event.getMsgResponse().equals("1"))
/*  5030:      */     {
/*  5031: 5794 */       MobileMboDataBean dataBean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*  5032: 5795 */       if (dataBean != null) {
/*  5033: 5797 */         if ((event.getCreatingObject() instanceof AbstractMobileControl))
/*  5034:      */         {
/*  5035: 5799 */           MobileMboDataBean worklistBean = DataBeanCache.findDataBean("WORKLIST");
/*  5036: 5800 */           MobileMboDataBean mboDataBean = ((MobileWOAppEventHandler)UIUtil.getAppEventHandler()).setWorklistRecordBean(null, worklistBean);
/*  5037: 5802 */           if (mboDataBean != null)
/*  5038:      */           {
/*  5039: 5804 */             mboDataBean.delete();
/*  5040: 5805 */             mboDataBean.getDataBeanManager().save();
/*  5041:      */           }
/*  5042: 5811 */           dataBean.reset();
/*  5043: 5812 */           UIUtil.refreshCurrentScreen();
/*  5044:      */         }
/*  5045:      */       }
/*  5046:      */     }
/*  5047: 5816 */     return true;
/*  5048:      */   }
/*  5049:      */   
/*  5050:      */   public boolean undochanges(UIEvent event)
/*  5051:      */     throws MobileApplicationException
/*  5052:      */   {
/*  5053: 5822 */     if (!((AbstractMobileControl)event.getCreatingObject()).getDataBean().getName().equalsIgnoreCase("WORKLIST")) {
/*  5054: 5823 */       super.undochanges(event);
/*  5055:      */     }
/*  5056: 5825 */     if (event.getMsgResponse().equals("-1")) {
/*  5057: 5827 */       return super.undochanges(event);
/*  5058:      */     }
/*  5059: 5829 */     if (event.getMsgResponse().equals("1"))
/*  5060:      */     {
/*  5061: 5833 */       MobileMboDataBean dataBean = setWorklistRecordBean(event, null);
/*  5062: 5834 */       if (dataBean != null) {
/*  5063: 5836 */         if ((event.getCreatingObject() instanceof AbstractMobileControl))
/*  5064:      */         {
/*  5065: 5838 */           dataBean.undoChanges();
/*  5066: 5839 */           UIUtil.refreshCurrentScreen();
/*  5067:      */         }
/*  5068:      */       }
/*  5069:      */     }
/*  5070: 5843 */     return true;
/*  5071:      */   }
/*  5072:      */   
/*  5073:      */   public boolean submit(UIEvent event)
/*  5074:      */     throws MobileApplicationException
/*  5075:      */   {
/*  5076: 5849 */     MobileMboDataBean woDataBean = UIUtil.getCurrentScreen().getDataBean();
/*  5077: 5850 */     calcWoDsStatusBeforeSendSrv(event, woDataBean.getMobileMbo());
/*  5078: 5855 */     if (!((AbstractMobileControl)event.getCreatingObject()).getDataBean().getName().equalsIgnoreCase("WORKLIST")) {
/*  5079: 5856 */       super.submit(event);
/*  5080:      */     }
/*  5081: 5858 */     if ((event.getCreatingObject() instanceof AbstractMobileControl))
/*  5082:      */     {
/*  5083: 5862 */       final MobileMboDataBean dataBean = setWorklistRecordBean(event, null);
/*  5084: 5863 */       if (dataBean != null)
/*  5085:      */       {
/*  5086: 5866 */         final String wonum = dataBean.getValue("WONUM");
/*  5087: 5867 */         final boolean isParentWO = (!dataBean.getMobileMbo().isNull("WOCLASS")) && (dataBean.getValue("PARENT").equals(""));
/*  5088:      */         
/*  5089: 5869 */         new AsyncEventHandlerSupport()
/*  5090:      */         {
/*  5091:      */           public boolean doRealWok(UIEvent event)
/*  5092:      */             throws MobileApplicationException
/*  5093:      */           {
/*  5094: 5872 */             updateProgressBar("submitdata", null, event);
/*  5095: 5873 */             dataBean.done();
/*  5096: 5874 */             return true;
/*  5097:      */           }
/*  5098:      */           
/*  5099:      */           public void postRealWork(UIEvent event)
/*  5100:      */             throws MobileApplicationException
/*  5101:      */           {
/*  5102: 5879 */             if (isParentWO)
/*  5103:      */             {
/*  5104: 5882 */               MobileMboQBE backupQBE = new MobileMboQBE();
/*  5105: 5883 */               MobileMboQBE currentQBE = dataBean.getQBE();
/*  5106: 5884 */               Enumeration en = currentQBE.getQBEAttributes();
/*  5107: 5885 */               while (en.hasMoreElements())
/*  5108:      */               {
/*  5109: 5887 */                 String key = (String)en.nextElement();
/*  5110: 5888 */                 String value = currentQBE.getQBE(key);
/*  5111: 5889 */                 backupQBE.setQBE(key, value);
/*  5112:      */               }
/*  5113: 5891 */               backupQBE.setQbeExactMatch(currentQBE.isQbeExactMatch());
/*  5114:      */               
/*  5115: 5893 */               currentQBE.reset();
/*  5116: 5894 */               currentQBE.setQBE("PARENT", wonum);
/*  5117: 5895 */               currentQBE.setQBE("_DONE", "0");
/*  5118: 5896 */               currentQBE.setQBE("_ERR", "0");
/*  5119: 5897 */               dataBean.reset();
/*  5120: 5898 */               int count = dataBean.count();
/*  5121: 5899 */               while (count > 0)
/*  5122:      */               {
/*  5123: 5901 */                 dataBean.done();
/*  5124: 5902 */                 count--;
/*  5125:      */               }
/*  5126: 5906 */               currentQBE = dataBean.getQBE();
/*  5127: 5907 */               en = backupQBE.getQBEAttributes();
/*  5128: 5908 */               while (en.hasMoreElements())
/*  5129:      */               {
/*  5130: 5910 */                 String key = (String)en.nextElement();
/*  5131: 5911 */                 String value = currentQBE.getQBE(key);
/*  5132: 5912 */                 backupQBE.setQBE(key, value);
/*  5133:      */               }
/*  5134: 5914 */               currentQBE.setQbeExactMatch(backupQBE.isQbeExactMatch());
/*  5135: 5915 */               dataBean.reset();
/*  5136:      */             }
/*  5137: 5917 */             UIUtil.refreshCurrentScreen();
/*  5138:      */           }
/*  5139: 5917 */         }.handleInBackground(event);
/*  5140:      */       }
/*  5141:      */     }
/*  5142: 5923 */     return true;
/*  5143:      */   }
/*  5144:      */   
/*  5145:      */   public boolean sendback(UIEvent event)
/*  5146:      */     throws MobileApplicationException
/*  5147:      */   {
/*  5148: 5929 */     if (!((AbstractMobileControl)event.getCreatingObject()).getDataBean().getName().equalsIgnoreCase("WORKLIST"))
/*  5149:      */     {
/*  5150: 5930 */       super.sendback(event);
/*  5151: 5931 */       return true;
/*  5152:      */     }
/*  5153: 5934 */     if ((event.getCreatingObject() instanceof AbstractMobileControl))
/*  5154:      */     {
/*  5155: 5938 */       final MobileMboDataBean dataBean = setWorklistRecordBean(event, null);
/*  5156: 5939 */       if (dataBean != null)
/*  5157:      */       {
/*  5158: 5941 */         new AsyncEventHandlerSupport()
/*  5159:      */         {
/*  5160:      */           public boolean doRealWok(UIEvent event)
/*  5161:      */             throws MobileApplicationException
/*  5162:      */           {
/*  5163: 5944 */             super.updateProgressBar("processdatainprogress", null, event);
/*  5164: 5945 */             dataBean.giveup();
/*  5165: 5946 */             return true;
/*  5166:      */           }
/*  5167:      */           
/*  5168:      */           public void postRealWork(UIEvent event)
/*  5169:      */             throws MobileApplicationException
/*  5170:      */           {}
/*  5171: 5946 */         }.handleInBackground(event);
/*  5172:      */         
/*  5173:      */ 
/*  5174:      */ 
/*  5175:      */ 
/*  5176:      */ 
/*  5177: 5952 */         return true;
/*  5178:      */       }
/*  5179:      */     }
/*  5180: 5956 */     return true;
/*  5181:      */   }
/*  5182:      */   
/*  5183:      */   public boolean insertsr(UIEvent event)
/*  5184:      */     throws MobileApplicationException
/*  5185:      */   {
/*  5186: 5963 */     if (UIUtil.checkESignature(event, getCachedDataBean("TICKET")))
/*  5187:      */     {
/*  5188: 5965 */       insertticket(event, "SR");
/*  5189: 5966 */       return showMainPage(event, "SR");
/*  5190:      */     }
/*  5191: 5970 */     event.setEventErrored();
/*  5192: 5971 */     return true;
/*  5193:      */   }
/*  5194:      */   
/*  5195:      */   public boolean insertincident(UIEvent event)
/*  5196:      */     throws MobileApplicationException
/*  5197:      */   {
/*  5198: 5980 */     if (UIUtil.checkESignature(event, getCachedDataBean("TICKET")))
/*  5199:      */     {
/*  5200: 5982 */       insertticket(event, "INCIDENT");
/*  5201: 5983 */       return showMainPage(event, "INCIDENT");
/*  5202:      */     }
/*  5203: 5987 */     event.setEventErrored();
/*  5204: 5988 */     return true;
/*  5205:      */   }
/*  5206:      */   
/*  5207:      */   public boolean insertproblem(UIEvent event)
/*  5208:      */     throws MobileApplicationException
/*  5209:      */   {
/*  5210: 5997 */     if (UIUtil.checkESignature(event, getCachedDataBean("TICKET")))
/*  5211:      */     {
/*  5212: 5999 */       insertticket(event, "PROBLEM");
/*  5213: 6000 */       return showMainPage(event, "PROBLEM");
/*  5214:      */     }
/*  5215: 6004 */     event.setEventErrored();
/*  5216: 6005 */     return true;
/*  5217:      */   }
/*  5218:      */   
/*  5219:      */   public boolean insertwo(UIEvent event)
/*  5220:      */     throws MobileApplicationException
/*  5221:      */   {
/*  5222: 6013 */     if (UIUtil.checkESignature(event, getCachedDataBean("WORKORDER")))
/*  5223:      */     {
/*  5224: 6015 */       insertworkorder(event, "WORKORDER");
/*  5225: 6016 */       return showMainPage(event, "WORKORDER");
/*  5226:      */     }
/*  5227: 6020 */     event.setEventErrored();
/*  5228: 6021 */     return true;
/*  5229:      */   }
/*  5230:      */   
/*  5231:      */   public boolean insertchange(UIEvent event)
/*  5232:      */     throws MobileApplicationException
/*  5233:      */   {
/*  5234: 6031 */     if (UIUtil.checkESignature(event, getCachedDataBean("WORKORDER")))
/*  5235:      */     {
/*  5236: 6033 */       insertworkorder(event, "CHANGE");
/*  5237: 6034 */       return showMainPage(event, "CHANGE");
/*  5238:      */     }
/*  5239: 6038 */     event.setEventErrored();
/*  5240: 6039 */     return true;
/*  5241:      */   }
/*  5242:      */   
/*  5243:      */   public boolean insertrelease(UIEvent event)
/*  5244:      */     throws MobileApplicationException
/*  5245:      */   {
/*  5246: 6048 */     if (UIUtil.checkESignature(event, getCachedDataBean("WORKORDER")))
/*  5247:      */     {
/*  5248: 6050 */       insertworkorder(event, "RELEASE");
/*  5249: 6051 */       return showMainPage(event, "RELEASE");
/*  5250:      */     }
/*  5251: 6055 */     event.setEventErrored();
/*  5252: 6056 */     return true;
/*  5253:      */   }
/*  5254:      */   
/*  5255:      */   public boolean canchangetkstatus(UIEvent event)
/*  5256:      */     throws MobileApplicationException
/*  5257:      */   {
/*  5258: 6062 */     MobileMboDataBean tkdatabean = UIUtil.getCurrentScreen().getDataBean();
/*  5259: 6063 */     if ((tkdatabean != null) && (!tkdatabean.getName().equals("TICKET"))) {
/*  5260: 6064 */       tkdatabean = DataBeanCache.findDataBean("TICKET");
/*  5261:      */     }
/*  5262: 6066 */     if ((tkdatabean != null) && (tkdatabean.getName().equals("TICKET")))
/*  5263:      */     {
/*  5264: 6068 */       boolean bShow = true;
/*  5265:      */       
/*  5266:      */ 
/*  5267:      */ 
/*  5268:      */ 
/*  5269:      */ 
/*  5270:      */ 
/*  5271:      */ 
/*  5272: 6076 */       ((AbstractMobileControl)event.getCreatingObject()).setVisibility(bShow);
/*  5273:      */     }
/*  5274: 6078 */     return true;
/*  5275:      */   }
/*  5276:      */   
/*  5277:      */   public boolean changetkstatus(UIEvent event)
/*  5278:      */     throws MobileApplicationException
/*  5279:      */   {
/*  5280: 6084 */     MobileMboDataBean databean = getCachedDataBean("TICKET");
/*  5281:      */     
/*  5282:      */ 
/*  5283: 6087 */     String tkclass = ((WOApp)UIUtil.getApplication()).getInternalValue(databean, "TKCLASS", databean.getValue("CLASS"));
/*  5284:      */     
/*  5285: 6089 */     String changestatuspage = "";
/*  5286: 6090 */     if (tkclass.equalsIgnoreCase("SR")) {
/*  5287: 6091 */       changestatuspage = "srchangestatus";
/*  5288: 6092 */     } else if (tkclass.equalsIgnoreCase("INCIDENT")) {
/*  5289: 6093 */       changestatuspage = "incidentchangestatus";
/*  5290: 6094 */     } else if (tkclass.equalsIgnoreCase("PROBLEM")) {
/*  5291: 6095 */       changestatuspage = "problemchangestatus";
/*  5292:      */     }
/*  5293: 6097 */     if (changestatuspage != null) {
/*  5294: 6098 */       UIUtil.gotoPage(changestatuspage, (AbstractMobileControl)event.getCreatingObject());
/*  5295:      */     }
/*  5296: 6100 */     return true;
/*  5297:      */   }
/*  5298:      */   
/*  5299:      */   public boolean canchangeactstatus(UIEvent event)
/*  5300:      */     throws MobileApplicationException
/*  5301:      */   {
/*  5302: 6105 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/*  5303: 6106 */     if ((databean != null) && (!databean.getName().equals("WOACTIVITY"))) {
/*  5304: 6107 */       databean = DataBeanCache.findDataBean("WOACTIVITY");
/*  5305:      */     }
/*  5306: 6109 */     if ((databean != null) && (databean.getName().equals("WOACTIVITY")))
/*  5307:      */     {
/*  5308: 6111 */       boolean bShow = true;
/*  5309:      */       
/*  5310: 6113 */       String maxStatus = ((WOApp)UIUtil.getApplication()).getInternalValue(databean, "WOSTATUS", databean.getValue("STATUS"));
/*  5311: 6117 */       if ((maxStatus.equals("COMP")) || (maxStatus.equals("CLOSE")) || (maxStatus.equals("CAN"))) {
/*  5312: 6118 */         bShow = false;
/*  5313:      */       }
/*  5314: 6120 */       ((AbstractMobileControl)event.getCreatingObject()).setVisibility(bShow);
/*  5315:      */     }
/*  5316: 6122 */     return true;
/*  5317:      */   }
/*  5318:      */   
/*  5319:      */   public boolean caninsertactivity(UIEvent event)
/*  5320:      */     throws MobileApplicationException
/*  5321:      */   {
/*  5322: 6127 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/*  5323: 6129 */     if ((databean != null) && (databean.getName().equals("TICKET")))
/*  5324:      */     {
/*  5325: 6131 */       boolean bShow = true;
/*  5326: 6132 */       if (databean.getValue("HISTORYFLAG").equals("1")) {
/*  5327: 6133 */         bShow = false;
/*  5328:      */       }
/*  5329: 6135 */       ((AbstractMobileControl)event.getCreatingObject()).setVisibility(bShow);
/*  5330:      */     }
/*  5331: 6137 */     return true;
/*  5332:      */   }
/*  5333:      */   
/*  5334:      */   public boolean insertactivity(UIEvent event)
/*  5335:      */     throws MobileApplicationException
/*  5336:      */   {
/*  5337: 6143 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/*  5338: 6144 */     if (databean != null) {
/*  5339: 6146 */       if (databean.getName().equals("WOACTIVITY"))
/*  5340:      */       {
/*  5341: 6148 */         Date createDate = databean.getCurrentTime();
/*  5342:      */         
/*  5343:      */ 
/*  5344: 6151 */         String msg = AutoKeyGenerator.generateKey("WORKORDER", "WONUM");
/*  5345:      */         
/*  5346: 6153 */         databean.insert();
/*  5347:      */         
/*  5348: 6155 */         databean.setValue("WONUM", msg);
/*  5349: 6156 */         databean.setValue("STATUS", ((WOApp)UIUtil.getApplication()).getDefaultValue(databean, "WOSTATUS", "WAPPR"));
/*  5350:      */         
/*  5351: 6158 */         databean.setValue("WOCLASS", ((WOApp)UIUtil.getApplication()).getDefaultValue(databean, "WOCLASS", "ACTIVITY"));
/*  5352:      */         
/*  5353: 6160 */         databean.setValue("ESTDUR", "0");
/*  5354: 6161 */         databean.getMobileMbo().setDateValue("STATUSDATE", createDate);
/*  5355: 6162 */         databean.getMobileMbo().setDateValue("REPORTDATE", createDate);
/*  5356: 6163 */         databean.getMobileMbo().setDateValue("CHANGEDATE", createDate);
/*  5357: 6164 */         databean.getMobileMbo().setValue("WOACCEPTSCHARGES", "1");
/*  5358: 6165 */         databean.getMobileMbo().setValue("HISTORYFLAG", "0");
/*  5359: 6166 */         databean.getMobileMbo().setReadOnly("MEASUREMENTVALUE", true);
/*  5360: 6167 */         databean.getMobileMbo().setReadOnly("MEASUREDATE", true);
/*  5361:      */       }
/*  5362:      */     }
/*  5363: 6170 */     UIUtil.refreshCurrentScreen();
/*  5364: 6171 */     return true;
/*  5365:      */   }
/*  5366:      */   
/*  5367:      */   public boolean candeleteactivity(UIEvent event)
/*  5368:      */     throws MobileApplicationException
/*  5369:      */   {
/*  5370: 6176 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/*  5371: 6178 */     if (databean != null)
/*  5372:      */     {
/*  5373: 6180 */       boolean bShow = false;
/*  5374: 6181 */       if ((databean.getMobileMbo() == null) || (databean.getMobileMbo().isNew())) {
/*  5375: 6182 */         bShow = true;
/*  5376:      */       }
/*  5377: 6184 */       ((AbstractMobileControl)event.getCreatingObject()).setVisibility(bShow);
/*  5378:      */     }
/*  5379: 6186 */     return true;
/*  5380:      */   }
/*  5381:      */   
/*  5382:      */   public boolean deleteactivity(UIEvent event)
/*  5383:      */     throws MobileApplicationException
/*  5384:      */   {
/*  5385: 6191 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/*  5386: 6192 */     if (databean != null) {
/*  5387: 6194 */       if (databean.getMobileMbo().isNew())
/*  5388:      */       {
/*  5389: 6196 */         databean.delete();
/*  5390: 6197 */         databean.getDataBeanManager().save();
/*  5391: 6198 */         databean.reset();
/*  5392:      */         
/*  5393: 6200 */         UIUtil.closePage();
/*  5394:      */       }
/*  5395:      */     }
/*  5396: 6203 */     return true;
/*  5397:      */   }
/*  5398:      */   
/*  5399:      */   public boolean caneditactivity(UIEvent event)
/*  5400:      */     throws MobileApplicationException
/*  5401:      */   {
/*  5402: 6208 */     ((AbstractMobileControl)event.getCreatingObject()).setVisibility(!WOApp.isActivityAlsoWO());
/*  5403:      */     
/*  5404: 6210 */     return true;
/*  5405:      */   }
/*  5406:      */   
/*  5407:      */   public boolean activityiswo(UIEvent event)
/*  5408:      */     throws MobileApplicationException
/*  5409:      */   {
/*  5410: 6216 */     ((AbstractMobileControl)event.getCreatingObject()).setVisibility(!WOApp.isActivityAlsoWO());
/*  5411:      */     
/*  5412: 6218 */     return true;
/*  5413:      */   }
/*  5414:      */   
/*  5415:      */   public boolean activitynotwo(UIEvent event)
/*  5416:      */     throws MobileApplicationException
/*  5417:      */   {
/*  5418: 6224 */     ((AbstractMobileControl)event.getCreatingObject()).setVisibility(WOApp.isActivityAlsoWO());
/*  5419:      */     
/*  5420: 6226 */     return true;
/*  5421:      */   }
/*  5422:      */   
/*  5423:      */   public boolean candownloadactivity(UIEvent event)
/*  5424:      */     throws MobileApplicationException
/*  5425:      */   {
/*  5426: 6232 */     AbstractMobileControl callingControl = (AbstractMobileControl)event.getCreatingObject();
/*  5427: 6233 */     MobileMboDataBean dataBean = callingControl.getDataBean();
/*  5428: 6234 */     boolean cangoto = true;
/*  5429: 6235 */     if ((dataBean.getMobileMbo().isNew()) || (dataBean.getMobileMbo().isModified())) {
/*  5430: 6236 */       cangoto = false;
/*  5431:      */     }
/*  5432: 6238 */     ((AbstractMobileControl)event.getCreatingObject()).setVisibility(cangoto);
/*  5433:      */     
/*  5434: 6240 */     return true;
/*  5435:      */   }
/*  5436:      */   
/*  5437:      */   public boolean adhocdownloadwoctivity(UIEvent event)
/*  5438:      */     throws MobileApplicationException
/*  5439:      */   {
/*  5440: 6245 */     AbstractMobileControl callingControl = (AbstractMobileControl)event.getCreatingObject();
/*  5441: 6246 */     MobileMboDataBean dataBean = callingControl.getDataBean();
/*  5442: 6247 */     MobileMbo mobileMbo = dataBean.getMobileMbo();
/*  5443:      */     
/*  5444: 6249 */     return downloadAdHocRecord(event, dataBean, mobileMbo.getValue("WORKORDERID"));
/*  5445:      */   }
/*  5446:      */   
/*  5447:      */   public boolean gotowo(UIEvent event)
/*  5448:      */     throws MobileApplicationException
/*  5449:      */   {
/*  5450: 6255 */     AbstractMobileControl callingControl = (AbstractMobileControl)event.getCreatingObject();
/*  5451: 6256 */     MobileMboDataBean dataBean = callingControl.getDataBean();
/*  5452: 6257 */     if (dataBean == null) {
/*  5453: 6258 */       return true;
/*  5454:      */     }
/*  5455: 6260 */     String dataname = "WORKORDER";
/*  5456: 6261 */     MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager(dataname);
/*  5457: 6262 */     MobileMboDataBean bean = mgrDBMgr.getDataBean();
/*  5458: 6263 */     bean.getQBE().reset();
/*  5459: 6264 */     bean.getQBE().setQbeExactMatch(true);
/*  5460: 6265 */     bean.getQBE().setQBE("WONUM", dataBean.getValue("WONUM"));
/*  5461: 6266 */     bean.getQBE().setQBE("SITEID", dataBean.getValue("SITEID"));
/*  5462: 6267 */     bean.reset();
/*  5463: 6268 */     if (bean.getMobileMbo(0) != null)
/*  5464:      */     {
/*  5465: 6270 */       gotoworklistview(event, bean);
/*  5466: 6271 */       DataBeanCache.rebuild();
/*  5467: 6272 */       UIUtil.refreshCurrentScreen();
/*  5468:      */     }
/*  5469: 6275 */     return true;
/*  5470:      */   }
/*  5471:      */   
/*  5472:      */   public boolean gotocreatecommpage(UIEvent event)
/*  5473:      */     throws MobileApplicationException
/*  5474:      */   {
/*  5475: 6281 */     MobileMboDataBean databean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*  5476:      */     
/*  5477: 6283 */     String mobileOwnerTable = databean.getValue("MOBILEOWNERTABLE");
/*  5478:      */     
/*  5479: 6285 */     String pageToShow = null;
/*  5480: 6287 */     if (mobileOwnerTable.equalsIgnoreCase("WORKORDER")) {
/*  5481: 6288 */       pageToShow = "createcomm";
/*  5482:      */     } else {
/*  5483: 6290 */       pageToShow = "createtkcomm";
/*  5484:      */     }
/*  5485: 6293 */     MobileMboDataBean tkWoBean = DataBeanCache.getDataBean(mobileOwnerTable, mobileOwnerTable);
/*  5486: 6294 */     tkWoBean.getQBE().reset();
/*  5487: 6295 */     tkWoBean.getQBE().setQBE("_ID", "" + databean.getMobileMbo().getLongValue("OWNERID"));
/*  5488: 6296 */     tkWoBean.reset();
/*  5489: 6298 */     if (pageToShow != null) {
/*  5490: 6299 */       UIUtil.showPage(pageToShow);
/*  5491:      */     }
/*  5492: 6301 */     return true;
/*  5493:      */   }
/*  5494:      */   
/*  5495:      */   public boolean canedittask(UIEvent event)
/*  5496:      */     throws MobileApplicationException
/*  5497:      */   {
/*  5498: 6306 */     ((AbstractMobileControl)event.getCreatingObject()).setVisibility(!WOApp.isTaskAlsoWO());
/*  5499:      */     
/*  5500: 6308 */     return true;
/*  5501:      */   }
/*  5502:      */   
/*  5503:      */   public boolean adhocdownloadrelrec(UIEvent event)
/*  5504:      */     throws MobileApplicationException
/*  5505:      */   {
/*  5506: 6313 */     AbstractMobileControl callingControl = (AbstractMobileControl)event.getCreatingObject();
/*  5507: 6314 */     MobileMboDataBean dataBean = callingControl.getDataBean();
/*  5508: 6315 */     MobileMbo mobileMbo = dataBean.getMobileMbo();
/*  5509:      */     
/*  5510: 6317 */     return downloadAdHocRecord(event, dataBean, mobileMbo.getValue("RELATEDRECKEYID"));
/*  5511:      */   }
/*  5512:      */   
/*  5513:      */   public boolean gotorelrec(UIEvent event)
/*  5514:      */     throws MobileApplicationException
/*  5515:      */   {
/*  5516: 6322 */     AbstractMobileControl callingControl = (AbstractMobileControl)event.getCreatingObject();
/*  5517: 6323 */     MobileMboDataBean dataBean = callingControl.getDataBean();
/*  5518: 6324 */     if (dataBean == null) {
/*  5519: 6325 */       return true;
/*  5520:      */     }
/*  5521: 6327 */     String dataname = "WORKORDER";
/*  5522: 6328 */     if ((dataBean.getName().equalsIgnoreCase("WORELTICKETS")) || (dataBean.getName().equalsIgnoreCase("TKRELTICKETS"))) {
/*  5523: 6331 */       dataname = "TICKET";
/*  5524:      */     }
/*  5525: 6334 */     MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager(dataname);
/*  5526: 6335 */     MobileMboDataBean bean = mgrDBMgr.getDataBean();
/*  5527: 6336 */     bean.getQBE().reset();
/*  5528: 6337 */     bean.getQBE().setQbeExactMatch(true);
/*  5529:      */     
/*  5530: 6339 */     bean.getQBE().setQBE("_ID", dataBean.getMobileMbo().getValue("RELATEDRECKEYID"));
/*  5531: 6340 */     bean.reset();
/*  5532: 6341 */     if (bean.getMobileMbo(0) != null)
/*  5533:      */     {
/*  5534: 6343 */       gotoworklistview(event, bean);
/*  5535: 6344 */       DataBeanCache.rebuild();
/*  5536: 6345 */       UIUtil.refreshCurrentScreen();
/*  5537:      */     }
/*  5538: 6348 */     return true;
/*  5539:      */   }
/*  5540:      */   
/*  5541:      */   public boolean downloadable(UIEvent event)
/*  5542:      */     throws MobileApplicationException
/*  5543:      */   {
/*  5544: 6353 */     MobileMboDataBean dataBean = ((ButtonControl)event.getCreatingObject()).getDataBean();
/*  5545: 6354 */     MobileMboDataBean bean = null;
/*  5546: 6355 */     if ((dataBean.getName().equalsIgnoreCase("ASSET_TICKETS")) || (dataBean.getName().equalsIgnoreCase("LOC_TICKETS")))
/*  5547:      */     {
/*  5548: 6358 */       MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager("TICKET");
/*  5549: 6359 */       bean = mgrDBMgr.getDataBean();
/*  5550: 6360 */       bean.getQBE().reset();
/*  5551: 6361 */       bean.getQBE().setQbeExactMatch(true);
/*  5552: 6362 */       bean.getQBE().setQBE("TICKETID", dataBean.getMobileMbo().getValue("TICKETID"));
/*  5553: 6363 */       bean.getQBE().setQBE("CLASS", dataBean.getMobileMbo().getValue("CLASS"));
/*  5554: 6364 */       bean.reset();
/*  5555:      */     }
/*  5556: 6365 */     else if ((dataBean.getName().equalsIgnoreCase("ASSET_WOS")) || (dataBean.getName().equalsIgnoreCase("LOC_WOS")))
/*  5557:      */     {
/*  5558: 6368 */       MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager("WORKORDER");
/*  5559: 6369 */       bean = mgrDBMgr.getDataBean();
/*  5560: 6370 */       bean.getQBE().reset();
/*  5561: 6371 */       bean.getQBE().setQbeExactMatch(true);
/*  5562: 6372 */       bean.getQBE().setQBE("WONUM", dataBean.getMobileMbo().getValue("WONUM"));
/*  5563: 6373 */       bean.getQBE().setQBE("SITEID", dataBean.getMobileMbo().getValue("SITEID"));
/*  5564: 6374 */       bean.reset();
/*  5565:      */     }
/*  5566: 6376 */     if ((bean != null) && (bean.getMobileMbo(0) != null)) {
/*  5567: 6377 */       ((AbstractMobileControl)event.getCreatingObject()).setVisibility(false);
/*  5568:      */     } else {
/*  5569: 6379 */       ((AbstractMobileControl)event.getCreatingObject()).setVisibility(true);
/*  5570:      */     }
/*  5571: 6381 */     return true;
/*  5572:      */   }
/*  5573:      */   
/*  5574:      */   public boolean togglerelrecbutton(UIEvent event)
/*  5575:      */     throws MobileApplicationException
/*  5576:      */   {
/*  5577: 6386 */     MobileMboDataBean dataBean = ((StateControl)event.getCreatingObject()).getDataBean();
/*  5578: 6387 */     if (dataBean == null) {
/*  5579: 6388 */       return true;
/*  5580:      */     }
/*  5581: 6390 */     boolean recordondevice = false;
/*  5582: 6391 */     String dataname = "WORKORDER";
/*  5583: 6392 */     if ((dataBean.getName().equalsIgnoreCase("WORELTICKETS")) || (dataBean.getName().equalsIgnoreCase("TKRELTICKETS"))) {
/*  5584: 6395 */       dataname = "TICKET";
/*  5585:      */     }
/*  5586: 6398 */     MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager(dataname);
/*  5587: 6399 */     MobileMboDataBean bean = mgrDBMgr.getDataBean();
/*  5588: 6400 */     bean.getQBE().reset();
/*  5589: 6401 */     bean.getQBE().setQbeExactMatch(true);
/*  5590: 6405 */     if (dataname.equals("WORKORDER"))
/*  5591:      */     {
/*  5592: 6406 */       bean.getQBE().setQBE("WONUM", dataBean.getMobileMbo().getValue("RELATEDRECWONUM"));
/*  5593: 6407 */       bean.getQBE().setQBE("WOCLASS", dataBean.getMobileMbo().getValue("RELATEDRECWOCLASS"));
/*  5594:      */     }
/*  5595:      */     else
/*  5596:      */     {
/*  5597: 6409 */       bean.getQBE().setQBE("TICKETID", dataBean.getMobileMbo().getValue("RELATEDRECKEY"));
/*  5598: 6410 */       bean.getQBE().setQBE("CLASS", dataBean.getMobileMbo().getValue("RELATEDRECWOCLASS"));
/*  5599:      */     }
/*  5600: 6414 */     bean.reset();
/*  5601: 6415 */     if (bean.getMobileMbo(0) != null) {
/*  5602: 6417 */       recordondevice = true;
/*  5603:      */     }
/*  5604: 6420 */     ((AbstractMobileControl)event.getCreatingObject()).setVisibility(true);
/*  5605:      */     
/*  5606: 6422 */     StateControl state = (StateControl)event.getCreatingObject();
/*  5607: 6423 */     if (recordondevice)
/*  5608:      */     {
/*  5609: 6425 */       state.setNewState("gotorelrecA");
/*  5610: 6426 */       state.setNewState("gotorelrecB");
/*  5611: 6427 */       state.setNewState("gotorelrecC");
/*  5612: 6428 */       state.setNewState("gotorelrecD");
/*  5613:      */     }
/*  5614:      */     else
/*  5615:      */     {
/*  5616: 6432 */       state.setNewState("adhocrelrecA");
/*  5617: 6433 */       state.setNewState("adhocrelrecB");
/*  5618: 6434 */       state.setNewState("adhocrelrecC");
/*  5619: 6435 */       state.setNewState("adhocrelrecD");
/*  5620:      */     }
/*  5621: 6438 */     return true;
/*  5622:      */   }
/*  5623:      */   
/*  5624:      */   public boolean selectrelwovalues(UIEvent event)
/*  5625:      */     throws MobileApplicationException
/*  5626:      */   {
/*  5627: 6443 */     MobileMboDataBean ludatabean = UIUtil.getCurrentScreen().getDataBean();
/*  5628:      */     
/*  5629:      */ 
/*  5630: 6446 */     Vector ludatabeanVector = ludatabean.getSelection();
/*  5631:      */     
/*  5632: 6448 */     MobileMboDataBean databean = ((PageControl)UIUtil.getCurrentScreen()).getLaunchingControl().getDataBean();
/*  5633: 6449 */     String relatedset = "WORELWOS";
/*  5634: 6450 */     if (databean.getName().equalsIgnoreCase("TICKET")) {
/*  5635: 6451 */       relatedset = "TKRELWOS";
/*  5636:      */     }
/*  5637: 6453 */     MobileMboDataBean reldatabean = databean.getDataBean(relatedset);
/*  5638: 6455 */     if (UIUtil.checkESignature(event, databean, "RELATEREC"))
/*  5639:      */     {
/*  5640: 6458 */       for (int i = 0; i < ludatabeanVector.size(); i++)
/*  5641:      */       {
/*  5642: 6461 */         if ((databean.getName().equalsIgnoreCase("WORKORDER")) && (databean.getValue("WONUM").equalsIgnoreCase(((MobileMbo)ludatabeanVector.get(i)).getValue("WONUM"))) && (databean.getValue("WOCLASS").equalsIgnoreCase(((MobileMbo)ludatabeanVector.get(i)).getValue("WOCLASS"))) && (databean.getValue("ORGID").equalsIgnoreCase(((MobileMbo)ludatabeanVector.get(i)).getValue("ORGID"))) && (databean.getValue("SITEID").equalsIgnoreCase(((MobileMbo)ludatabeanVector.get(i)).getValue("SITEID"))))
/*  5643:      */         {
/*  5644: 6467 */           UIUtil.showInfoMessageBox(MobileMessageGenerator.generate("NoOwnParent", new Object[] { databean.getValue("WONUM") }));
/*  5645: 6468 */           return true;
/*  5646:      */         }
/*  5647: 6472 */         int relwocount = reldatabean.count();
/*  5648: 6473 */         for (int b = 0; b < relwocount; b++) {
/*  5649: 6475 */           if ((((MobileMbo)ludatabeanVector.get(i)).getValue("WONUM").equalsIgnoreCase(reldatabean.getMobileMbo(b).getValue("RELATEDRECWONUM"))) && (((MobileMbo)ludatabeanVector.get(i)).getValue("WOCLASS").equalsIgnoreCase(reldatabean.getMobileMbo(b).getValue("RELATEDRECWOCLASS"))) && (((MobileMbo)ludatabeanVector.get(i)).getValue("ORGID").equalsIgnoreCase(reldatabean.getMobileMbo(b).getValue("RELATEDRECORGID"))) && (((MobileMbo)ludatabeanVector.get(i)).getValue("SITEID").equalsIgnoreCase(reldatabean.getMobileMbo(b).getValue("RELATEDRECSITEID"))))
/*  5650:      */           {
/*  5651: 6480 */             UIUtil.showInfoMessageBox(MobileMessageGenerator.generate("woalreadyrelated", new Object[] { ((MobileMbo)ludatabeanVector.get(i)).getValue("WONUM") }));
/*  5652: 6481 */             return true;
/*  5653:      */           }
/*  5654:      */         }
/*  5655:      */       }
/*  5656: 6487 */       for (int i = 0; i < ludatabeanVector.size(); i++)
/*  5657:      */       {
/*  5658: 6497 */         if (databean.getName().equalsIgnoreCase("WORKORDER")) {
/*  5659: 6500 */           ((WOApp)UIUtil.getApplication()).addRelatedRecordToWO(databean.getMobileMbo(), (MobileMbo)ludatabeanVector.get(i), "WORKORDER");
/*  5660:      */         } else {
/*  5661: 6505 */           ((WOApp)UIUtil.getApplication()).addRelatedRecordToTK(databean.getMobileMbo(), (MobileMbo)ludatabeanVector.get(i), "WORKORDER");
/*  5662:      */         }
/*  5663: 6516 */         if (databean.getName().equalsIgnoreCase("WORKORDER")) {
/*  5664: 6519 */           ((WOApp)UIUtil.getApplication()).addRelatedRecordToWO((MobileMbo)ludatabeanVector.get(i), databean.getMobileMbo(), "WORKORDER");
/*  5665:      */         } else {
/*  5666: 6524 */           ((WOApp)UIUtil.getApplication()).addRelatedRecordToWO((MobileMbo)ludatabeanVector.get(i), databean.getMobileMbo(), "TICKET");
/*  5667:      */         }
/*  5668:      */       }
/*  5669: 6528 */       databean.setValue("_MODIFIED", "1");
/*  5670: 6529 */       databean.getDataBeanManager().save();
/*  5671: 6530 */       UIUtil.getApplication().removeCurrentScreen(true);
/*  5672:      */     }
/*  5673:      */     else
/*  5674:      */     {
/*  5675: 6534 */       event.setEventErrored();
/*  5676:      */     }
/*  5677: 6537 */     return true;
/*  5678:      */   }
/*  5679:      */   
/*  5680:      */   public boolean selectreltkvalues(UIEvent event)
/*  5681:      */     throws MobileApplicationException
/*  5682:      */   {
/*  5683: 6542 */     MobileMboDataBean ludatabean = UIUtil.getCurrentScreen().getDataBean();
/*  5684:      */     
/*  5685:      */ 
/*  5686: 6545 */     Vector ludatabeanVector = ludatabean.getSelection();
/*  5687:      */     
/*  5688: 6547 */     MobileMboDataBean databean = ((PageControl)UIUtil.getCurrentScreen()).getLaunchingControl().getDataBean();
/*  5689: 6548 */     String relatedset = "WORELTICKETS";
/*  5690: 6549 */     if (databean.getName().equalsIgnoreCase("TICKET")) {
/*  5691: 6550 */       relatedset = "TKRELTICKETS";
/*  5692:      */     }
/*  5693: 6552 */     MobileMboDataBean reldatabean = databean.getDataBean(relatedset);
/*  5694: 6554 */     if (UIUtil.checkESignature(event, databean, "RELATEREC"))
/*  5695:      */     {
/*  5696: 6557 */       for (int i = 0; i < ludatabeanVector.size(); i++)
/*  5697:      */       {
/*  5698: 6560 */         if ((databean.getName().equalsIgnoreCase("TICKET")) && (databean.getValue("TICKETID").equalsIgnoreCase(((MobileMbo)ludatabeanVector.get(i)).getValue("TICKETID"))) && (databean.getValue("CLASS").equalsIgnoreCase(((MobileMbo)ludatabeanVector.get(i)).getValue("CLASS"))) && (databean.getValue("ORGID").equalsIgnoreCase(((MobileMbo)ludatabeanVector.get(i)).getValue("ORGID"))) && (databean.getValue("SITEID").equalsIgnoreCase(((MobileMbo)ludatabeanVector.get(i)).getValue("SITEID"))))
/*  5699:      */         {
/*  5700: 6566 */           UIUtil.showInfoMessageBox(MobileMessageGenerator.generate("NoOwnParent", new Object[] { databean.getValue("TICKETID") }));
/*  5701: 6567 */           return true;
/*  5702:      */         }
/*  5703: 6571 */         int relwocount = reldatabean.count();
/*  5704: 6572 */         for (int b = 0; b < relwocount; b++) {
/*  5705: 6574 */           if ((((MobileMbo)ludatabeanVector.get(i)).getValue("TICKETID").equalsIgnoreCase(reldatabean.getMobileMbo(b).getValue("RELATEDRECKEY"))) && (((MobileMbo)ludatabeanVector.get(i)).getValue("CLASS").equalsIgnoreCase(reldatabean.getMobileMbo(b).getValue("RELATEDRECCLASS"))) && (((MobileMbo)ludatabeanVector.get(i)).getValue("ORGID").equalsIgnoreCase(reldatabean.getMobileMbo(b).getValue("RELATEDRECORGID"))) && (((MobileMbo)ludatabeanVector.get(i)).getValue("SITEID").equalsIgnoreCase(reldatabean.getMobileMbo(b).getValue("RELATEDRECSITEID"))))
/*  5706:      */           {
/*  5707: 6579 */             UIUtil.showInfoMessageBox(MobileMessageGenerator.generate("tkalreadyrelated", new Object[] { ((MobileMbo)ludatabeanVector.get(i)).getValue("TICKETID") }));
/*  5708: 6580 */             return true;
/*  5709:      */           }
/*  5710:      */         }
/*  5711:      */       }
/*  5712: 6587 */       for (int i = 0; i < ludatabeanVector.size(); i++)
/*  5713:      */       {
/*  5714: 6597 */         if (databean.getName().equalsIgnoreCase("WORKORDER")) {
/*  5715: 6600 */           ((WOApp)UIUtil.getApplication()).addRelatedRecordToWO(databean.getMobileMbo(), (MobileMbo)ludatabeanVector.get(i), "TICKET");
/*  5716:      */         } else {
/*  5717: 6605 */           ((WOApp)UIUtil.getApplication()).addRelatedRecordToTK(databean.getMobileMbo(), (MobileMbo)ludatabeanVector.get(i), "TICKET");
/*  5718:      */         }
/*  5719: 6616 */         if (databean.getName().equalsIgnoreCase("WORKORDER")) {
/*  5720: 6619 */           ((WOApp)UIUtil.getApplication()).addRelatedRecordToTK((MobileMbo)ludatabeanVector.get(i), databean.getMobileMbo(), "WORKORDER");
/*  5721:      */         } else {
/*  5722: 6624 */           ((WOApp)UIUtil.getApplication()).addRelatedRecordToTK((MobileMbo)ludatabeanVector.get(i), databean.getMobileMbo(), "TICKET");
/*  5723:      */         }
/*  5724:      */       }
/*  5725: 6628 */       databean.setValue("_MODIFIED", "1");
/*  5726: 6629 */       databean.getDataBeanManager().save();
/*  5727: 6630 */       UIUtil.getApplication().removeCurrentScreen(true);
/*  5728:      */     }
/*  5729:      */     else
/*  5730:      */     {
/*  5731: 6634 */       event.setEventErrored();
/*  5732:      */     }
/*  5733: 6637 */     return true;
/*  5734:      */   }
/*  5735:      */   
/*  5736:      */   public boolean candeleterelatedrecord(UIEvent event)
/*  5737:      */     throws MobileApplicationException
/*  5738:      */   {
/*  5739: 6642 */     MobileMboDataBean wodatabean = UIUtil.getCurrentScreen().getDataBean();
/*  5740:      */     
/*  5741: 6644 */     boolean bShow = false;
/*  5742: 6645 */     if (wodatabean.getMobileMbo() != null)
/*  5743:      */     {
/*  5744: 6647 */       MobileMboDataBean parentdatabean = wodatabean.getParentBean();
/*  5745: 6648 */       if (wodatabean.getMobileMbo().isNew()) {
/*  5746: 6649 */         bShow = true;
/*  5747:      */       }
/*  5748: 6652 */       if ((parentdatabean.getValue("ORIGRECORDID").equals(wodatabean.getMobileMbo().getValue("RELATEDRECWONUM"))) && (parentdatabean.getValue("ORIGRECORDCLASS").equals(wodatabean.getMobileMbo().getValue("RELATEDRECWOCLASS")))) {
/*  5749: 6654 */         bShow = false;
/*  5750:      */       }
/*  5751: 6658 */       if ((parentdatabean.getValue("ORIGRECORDID").equals(wodatabean.getMobileMbo().getValue("RELATEDRECKEY"))) && (parentdatabean.getValue("ORIGRECORDCLASS").equals(wodatabean.getMobileMbo().getValue("RELATEDRECCLASS")))) {
/*  5752: 6660 */         bShow = false;
/*  5753:      */       }
/*  5754:      */     }
/*  5755: 6662 */     ((AbstractMobileControl)event.getCreatingObject()).setVisibility(bShow);
/*  5756:      */     
/*  5757: 6664 */     return true;
/*  5758:      */   }
/*  5759:      */   
/*  5760:      */   public boolean deleterelatedrecord(UIEvent event)
/*  5761:      */     throws MobileApplicationException
/*  5762:      */   {
/*  5763: 6669 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/*  5764: 6670 */     if (databean != null) {
/*  5765: 6672 */       if (databean.getMobileMbo().isNew())
/*  5766:      */       {
/*  5767: 6674 */         MobileMbo mbo = databean.getMobileMbo();
/*  5768:      */         
/*  5769:      */ 
/*  5770:      */ 
/*  5771:      */ 
/*  5772: 6679 */         boolean recIsWO = false;
/*  5773: 6680 */         if ((mbo.getName().equalsIgnoreCase("WORELWOS")) || (mbo.getName().equalsIgnoreCase("WORELTICKETS"))) {
/*  5774: 6681 */           recIsWO = true;
/*  5775:      */         }
/*  5776: 6683 */         boolean relrecIsWO = false;
/*  5777: 6684 */         if (!mbo.getValue("RELATEDRECWOCLASS").equalsIgnoreCase("")) {
/*  5778: 6685 */           relrecIsWO = true;
/*  5779:      */         }
/*  5780: 6687 */         String dataname = "";
/*  5781: 6688 */         if (recIsWO)
/*  5782:      */         {
/*  5783: 6690 */           if (relrecIsWO) {
/*  5784: 6691 */             dataname = "WORELWOS";
/*  5785:      */           } else {
/*  5786: 6693 */             dataname = "TKRELWOS";
/*  5787:      */           }
/*  5788:      */         }
/*  5789: 6697 */         else if (relrecIsWO) {
/*  5790: 6698 */           dataname = "WORELTICKETS";
/*  5791:      */         } else {
/*  5792: 6700 */           dataname = "TKRELTICKETS";
/*  5793:      */         }
/*  5794: 6704 */         MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager(dataname);
/*  5795: 6705 */         MobileMboDataBean bean = mgrDBMgr.getDataBean();
/*  5796: 6706 */         bean.getQBE().reset();
/*  5797: 6707 */         bean.getQBE().setQbeExactMatch(true);
/*  5798: 6708 */         if (relrecIsWO)
/*  5799:      */         {
/*  5800: 6710 */           bean.getQBE().setQBE("RECORDKEY", mbo.getValue("RELATEDRECWONUM"));
/*  5801: 6711 */           bean.getQBE().setQBE("CLASS", mbo.getValue("RELATEDRECWOCLASS"));
/*  5802: 6712 */           bean.getQBE().setQBE("ORGID", mbo.getValue("RELATEDRECORGID"));
/*  5803: 6713 */           bean.getQBE().setQBE("SITEID", mbo.getValue("RELATEDRECSITEID"));
/*  5804:      */         }
/*  5805:      */         else
/*  5806:      */         {
/*  5807: 6717 */           bean.getQBE().setQBE("RECORDKEY", mbo.getValue("RELATEDRECKEY"));
/*  5808: 6718 */           bean.getQBE().setQBE("CLASS", mbo.getValue("RELATEDRECCLASS"));
/*  5809: 6719 */           bean.getQBE().setQBE("ORGID", mbo.getValue("RELATEDRECORGID"));
/*  5810: 6720 */           bean.getQBE().setQBE("SITEID", mbo.getValue("RELATEDRECSITEID"));
/*  5811:      */         }
/*  5812: 6722 */         bean.reset();
/*  5813: 6723 */         if (bean.getMobileMbo(0) != null)
/*  5814:      */         {
/*  5815: 6725 */           bean.getMobileMbo(0).delete();
/*  5816: 6726 */           bean.getDataBeanManager().save();
/*  5817:      */         }
/*  5818: 6730 */         databean.delete();
/*  5819: 6731 */         databean.getDataBeanManager().save();
/*  5820: 6732 */         databean.reset();
/*  5821:      */         
/*  5822: 6734 */         UIUtil.closePage();
/*  5823:      */       }
/*  5824:      */     }
/*  5825: 6737 */     return true;
/*  5826:      */   }
/*  5827:      */   
/*  5828:      */   public boolean canAddRelatedRecord(UIEvent event)
/*  5829:      */     throws MobileApplicationException
/*  5830:      */   {
/*  5831: 6744 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/*  5832: 6746 */     if (databean != null)
/*  5833:      */     {
/*  5834: 6748 */       boolean bShow = true;
/*  5835: 6749 */       if ((databean.getMobileMbo() == null) || (databean.getMobileMbo().isNew())) {
/*  5836: 6750 */         bShow = false;
/*  5837:      */       }
/*  5838: 6752 */       ((AbstractMobileControl)event.getCreatingObject()).setVisibility(bShow);
/*  5839:      */     }
/*  5840: 6754 */     return true;
/*  5841:      */   }
/*  5842:      */   
/*  5843:      */   public boolean candeleterelatedasset(UIEvent event)
/*  5844:      */     throws MobileApplicationException
/*  5845:      */   {
/*  5846: 6759 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/*  5847: 6761 */     if (databean != null)
/*  5848:      */     {
/*  5849: 6763 */       boolean bShow = false;
/*  5850: 6764 */       if ((databean.getMobileMbo() == null) || (databean.getMobileMbo().isNew())) {
/*  5851: 6765 */         bShow = true;
/*  5852:      */       }
/*  5853: 6767 */       ((AbstractMobileControl)event.getCreatingObject()).setVisibility(bShow);
/*  5854:      */     }
/*  5855: 6769 */     return true;
/*  5856:      */   }
/*  5857:      */   
/*  5858:      */   public boolean deleterelatedasset(UIEvent event)
/*  5859:      */     throws MobileApplicationException
/*  5860:      */   {
/*  5861: 6774 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/*  5862: 6775 */     if (databean != null)
/*  5863:      */     {
/*  5864: 6777 */       databean.delete();
/*  5865: 6778 */       databean.getDataBeanManager().save();
/*  5866: 6779 */       UIUtil.closePage();
/*  5867:      */     }
/*  5868: 6782 */     return true;
/*  5869:      */   }
/*  5870:      */   
/*  5871:      */   public boolean downloadAdHocRecord(UIEvent event, MobileMboDataBean dataBean, String _id)
/*  5872:      */     throws MobileApplicationException
/*  5873:      */   {
/*  5874: 6788 */     if (event.getMsgResponse().equals("-1"))
/*  5875:      */     {
/*  5876: 6790 */       UIUtil.showOKCANCELMessageBox(event, MobileMessageGenerator.generate("adhocdownload", null));
/*  5877: 6791 */       return true;
/*  5878:      */     }
/*  5879: 6793 */     if (event.getMsgResponse().equals("1")) {
/*  5880: 6795 */       switch (event.getThreadStatus())
/*  5881:      */       {
/*  5882:      */       case -1: 
/*  5883: 6798 */         UIUtil.startWorkerThread(this, event);
/*  5884: 6799 */         break;
/*  5885:      */       case 1: 
/*  5886: 6810 */         String dataname = "WORKORDER";
/*  5887: 6811 */         if ((dataBean.getName().equalsIgnoreCase("WORELTICKETS")) || (dataBean.getName().equalsIgnoreCase("TKRELTICKETS")) || (dataBean.getName().equalsIgnoreCase("ASSET_WOS")) || (dataBean.getName().equalsIgnoreCase("ASSET_TICKETS")) || (dataBean.getName().equalsIgnoreCase("LOC_WOS")) || (dataBean.getName().equalsIgnoreCase("LOC_TICKETS")) || (dataBean.getName().equalsIgnoreCase("TICKET"))) {
/*  5888: 6820 */           dataname = "TICKET";
/*  5889:      */         }
/*  5890: 6823 */         UIUtil.getApplication().downloadAdHocMobileMbo(event.getProgressObserver(), dataname, "", _id);
/*  5891:      */         
/*  5892:      */ 
/*  5893: 6826 */         break;
/*  5894:      */       case 2: 
/*  5895: 6840 */         String dataname = "WORKORDER";
/*  5896: 6841 */         if ((dataBean.getName().equalsIgnoreCase("WORELTICKETS")) || (dataBean.getName().equalsIgnoreCase("TKRELTICKETS")) || (dataBean.getName().equalsIgnoreCase("ASSET_WOS")) || (dataBean.getName().equalsIgnoreCase("ASSET_TICKETS")) || (dataBean.getName().equalsIgnoreCase("LOC_WOS")) || (dataBean.getName().equalsIgnoreCase("LOC_TICKETS")) || (dataBean.getName().equalsIgnoreCase("TICKET"))) {
/*  5897: 6850 */           dataname = "TICKET";
/*  5898:      */         }
/*  5899: 6853 */         MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager(dataname);
/*  5900: 6854 */         MobileMboDataBean bean = mgrDBMgr.getDataBean();
/*  5901: 6855 */         bean.getQBE().reset();
/*  5902: 6856 */         bean.getQBE().setQbeExactMatch(true);
/*  5903: 6857 */         bean.getQBE().setQBE("_ID", _id);
/*  5904: 6858 */         bean.reset();
/*  5905: 6859 */         MobileMbo mbo = bean.getMobileMbo(0);
/*  5906: 6860 */         if (mbo != null)
/*  5907:      */         {
/*  5908: 6862 */           MobileMboDataBean worklistBean = DataBeanCache.findDataBean("WORKLIST");
/*  5909: 6863 */           ((WOApp)UIUtil.getApplication()).copyMboToWorkList(worklistBean, bean, mbo);
/*  5910:      */           
/*  5911: 6865 */           worklistBean.getDataBeanManager().save();
/*  5912:      */           
/*  5913:      */ 
/*  5914: 6868 */           setWorklistRecordBean(event, bean);
/*  5915: 6869 */           String pageToShow = "womain";
/*  5916: 6870 */           if (dataname.equalsIgnoreCase("TICKET")) {
/*  5917: 6871 */             pageToShow = "ticketmain";
/*  5918:      */           }
/*  5919: 6872 */           UIUtil.showPage(pageToShow);
/*  5920:      */         }
/*  5921: 6873 */         break;
/*  5922:      */       case 0: 
/*  5923: 6877 */         UIUtil.refreshCurrentScreen();
/*  5924: 6878 */         break;
/*  5925:      */       case 3: 
/*  5926: 6880 */         UIUtil.refreshCurrentScreen();
/*  5927: 6881 */         UIUtil.showExceptionMessage(event.getException(), null, 0);
/*  5928:      */       }
/*  5929:      */     }
/*  5930: 6885 */     return true;
/*  5931:      */   }
/*  5932:      */   
/*  5933:      */   public boolean initAllClasses(UIEvent event)
/*  5934:      */     throws MobileApplicationException
/*  5935:      */   {
/*  5936: 6891 */     String[] allStatusesMbos = { "WOCLASS", "TKCLASS" };
/*  5937: 6892 */     return initAllValues(event, allStatusesMbos);
/*  5938:      */   }
/*  5939:      */   
/*  5940:      */   public boolean initAllStatuses(UIEvent event)
/*  5941:      */     throws MobileApplicationException
/*  5942:      */   {
/*  5943: 6899 */     String[] allStatusesMbos = { "SRSTATUS", "PROBLEMSTATUS", "INCIDENTSTATUS", "WOSTATUS" };
/*  5944: 6900 */     return initAllValues(event, allStatusesMbos);
/*  5945:      */   }
/*  5946:      */   
/*  5947:      */   public boolean gotoslapage(UIEvent event)
/*  5948:      */     throws MobileApplicationException
/*  5949:      */   {
/*  5950: 6905 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/*  5951: 6906 */     if ((databean != null) && (databean.getName().equals("WORKLIST")))
/*  5952:      */     {
/*  5953: 6909 */       databean = setWorklistRecordBean(event, null);
/*  5954:      */       
/*  5955: 6911 */       String page = "displayslainfo";
/*  5956: 6912 */       if (databean.getName().equals("TICKET")) {
/*  5957: 6913 */         page = "tkdisplayslainfo";
/*  5958:      */       }
/*  5959: 6915 */       UIUtil.gotoPage(page, (AbstractMobileControl)event.getCreatingObject());
/*  5960:      */     }
/*  5961: 6917 */     return true;
/*  5962:      */   }
/*  5963:      */   
/*  5964:      */   public boolean relatedassetchanged(UIEvent event)
/*  5965:      */     throws MobileApplicationException
/*  5966:      */   {
/*  5967: 6923 */     MobileMboDataBean databean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*  5968: 6924 */     if (databean != null) {
/*  5969: 6926 */       if (event.getValue() != null)
/*  5970:      */       {
/*  5971: 6929 */         MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager("ASSET");
/*  5972: 6930 */         MobileMboDataBean assetBean = mgrDBMgr.getDataBean();
/*  5973: 6931 */         assetBean.getQBE().reset();
/*  5974: 6932 */         assetBean.getQBE().setQbeExactMatch(true);
/*  5975:      */         
/*  5976: 6934 */         assetBean.getQBE().setQBE("SITEID", databean.getValue("SITEID"));
/*  5977: 6935 */         assetBean.getQBE().setQBE("ASSETNUM", (String)event.getValue());
/*  5978: 6936 */         assetBean.reset();
/*  5979: 6937 */         int count = assetBean.count();
/*  5980: 6938 */         if (count == 1)
/*  5981:      */         {
/*  5982: 6940 */           databean.setValue("LOCATION", assetBean.getMobileMbo(0).getValue("LOCATION"));
/*  5983: 6941 */           databean.setValue("ASSET_DESCRIPTION", assetBean.getMobileMbo(0).getValue("DESCRIPTION"));
/*  5984: 6942 */           databean.setValue("ASSETPRIORITY", assetBean.getMobileMbo(0).getValue("PRIORITY"));
/*  5985: 6943 */           databean.setValue("ASSETTYPE", assetBean.getMobileMbo(0).getValue("ASSETTYPE"));
/*  5986: 6945 */           if (!databean.getValue("LOCATION").equals(""))
/*  5987:      */           {
/*  5988: 6947 */             mgrDBMgr = new MobileMboDataBeanManager("LOCATIONS");
/*  5989: 6948 */             MobileMboDataBean locBean = mgrDBMgr.getDataBean();
/*  5990: 6949 */             locBean.getQBE().reset();
/*  5991: 6950 */             locBean.getQBE().setQbeExactMatch(true);
/*  5992:      */             
/*  5993: 6952 */             locBean.getQBE().setQBE("SITEID", databean.getValue("SITEID"));
/*  5994: 6953 */             locBean.getQBE().setQBE("LOCATION", databean.getValue("LOCATION"));
/*  5995: 6954 */             locBean.reset();
/*  5996: 6955 */             count = locBean.count();
/*  5997: 6956 */             if (count == 1)
/*  5998:      */             {
/*  5999: 6958 */               databean.setValue("LOCATION_DESCRIPTION", locBean.getMobileMbo(0).getValue("DESCRIPTION"));
/*  6000: 6959 */               databean.setValue("LOCPRIORITY", locBean.getMobileMbo(0).getValue("LOCPRIORITY"));
/*  6001: 6960 */               databean.setValue("LOCTYPE", locBean.getMobileMbo(0).getValue("TYPE"));
/*  6002:      */             }
/*  6003:      */           }
/*  6004:      */         }
/*  6005:      */       }
/*  6006:      */     }
/*  6007: 6966 */     return true;
/*  6008:      */   }
/*  6009:      */   
/*  6010:      */   public boolean relatedlocassetchanged(UIEvent event)
/*  6011:      */     throws MobileApplicationException
/*  6012:      */   {
/*  6013: 6972 */     MobileMboDataBean databean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*  6014: 6973 */     if (databean != null) {
/*  6015: 6975 */       if (event.getValue() != null)
/*  6016:      */       {
/*  6017: 6978 */         MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager("LOCATIONS");
/*  6018: 6979 */         MobileMboDataBean locBean = mgrDBMgr.getDataBean();
/*  6019: 6980 */         locBean.getQBE().reset();
/*  6020: 6981 */         locBean.getQBE().setQbeExactMatch(true);
/*  6021:      */         
/*  6022: 6983 */         locBean.getQBE().setQBE("SITEID", databean.getValue("SITEID"));
/*  6023: 6984 */         locBean.getQBE().setQBE("LOCATION", (String)event.getValue());
/*  6024: 6985 */         locBean.reset();
/*  6025: 6986 */         int count = locBean.count();
/*  6026: 6987 */         if (count == 1)
/*  6027:      */         {
/*  6028: 6989 */           databean.setValue("LOCATION_DESCRIPTION", locBean.getMobileMbo(0).getValue("DESCRIPTION"));
/*  6029: 6990 */           databean.setValue("LOCPRIORITY", locBean.getMobileMbo(0).getValue("LOCPRIORITY"));
/*  6030: 6991 */           databean.setValue("LOCTYPE", locBean.getMobileMbo(0).getValue("TYPE"));
/*  6031:      */         }
/*  6032:      */       }
/*  6033:      */     }
/*  6034: 6995 */     return true;
/*  6035:      */   }
/*  6036:      */   
/*  6037:      */   public boolean validaterelatedasset(UIEvent event)
/*  6038:      */     throws MobileApplicationException
/*  6039:      */   {
/*  6040: 7005 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/*  6041: 7006 */     if (UIUtil.checkESignature(event, databean, "RELATEASET"))
/*  6042:      */     {
/*  6043: 7008 */       if ((databean.getValue("ASSETNUM").equals("")) && (databean.getValue("LOCATION").equals("")))
/*  6044:      */       {
/*  6045: 7010 */         UIUtil.showInfoMessageBox(MobileMessageGenerator.generate("NeedAssetOrLocation", null));
/*  6046: 7011 */         event.setEventErrored();
/*  6047: 7012 */         return true;
/*  6048:      */       }
/*  6049: 7014 */       databean.getDataBeanManager().save();
/*  6050:      */     }
/*  6051:      */     else
/*  6052:      */     {
/*  6053: 7018 */       event.setEventErrored();
/*  6054:      */     }
/*  6055: 7021 */     return true;
/*  6056:      */   }
/*  6057:      */   
/*  6058:      */   public boolean selectsiteid(UIEvent event)
/*  6059:      */     throws MobileApplicationException
/*  6060:      */   {
/*  6061: 7026 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/*  6062: 7027 */     MobileMboDataBean mainrecDatabean = ((PageControl)UIUtil.getCurrentScreen()).getLaunchingControl().getDataBean();
/*  6063:      */     
/*  6064: 7029 */     mainrecDatabean.setValue("SITEID", databean.getValue("SITEID"));
/*  6065: 7030 */     mainrecDatabean.setValue("ORGID", databean.getValue("ORGID"));
/*  6066: 7031 */     UIUtil.cancelPage();
/*  6067:      */     
/*  6068: 7033 */     return true;
/*  6069:      */   }
/*  6070:      */   
/*  6071:      */   public boolean markalldone(UIEvent event)
/*  6072:      */     throws MobileApplicationException
/*  6073:      */   {
/*  6074: 7047 */     MobileMboDataBean woDataBean = getCachedDataBean("WORKORDER");
/*  6075: 7049 */     for (int i = 0; i < woDataBean.count(); i++)
/*  6076:      */     {
/*  6077: 7051 */       MobileMbo mbo = woDataBean.getMobileMbo(i);
/*  6078: 7052 */       if ((mbo.getBooleanValue("PLUSCWOSTSALREADYCALC_NP") != true) && (mbo.isModified()))
/*  6079:      */       {
/*  6080: 7056 */         calcWoDsStatusBeforeSendSrv(event, mbo);
/*  6081: 7057 */         mbo.setBooleanValue("PLUSCWOSTSALREADYCALC_NP", true, false);
/*  6082: 7058 */         mbo.resetDependents();
/*  6083:      */       }
/*  6084:      */     }
/*  6085: 7064 */     if (event.getMsgResponse().equals("-1"))
/*  6086:      */     {
/*  6087: 7066 */       String msg = MobileMessageGenerator.generate("markalldone", new Object[0]);
/*  6088: 7067 */       UIUtil.showOKCANCELMessageBox(event, msg);
/*  6089: 7068 */       return true;
/*  6090:      */     }
/*  6091: 7070 */     if (event.getMsgResponse().equals("1")) {
/*  6092: 7072 */       switch (event.getThreadStatus())
/*  6093:      */       {
/*  6094:      */       case -1: 
/*  6095: 7075 */         UIUtil.startWorkerThread(this, event);
/*  6096: 7076 */         break;
/*  6097:      */       case 1: 
/*  6098: 7079 */         MobileMboDataBean wodatabean = getCachedDataBean("WORKORDER");
/*  6099: 7080 */         MobileMboDataBean tkdatabean = getCachedDataBean("TICKET");
/*  6100:      */         
/*  6101: 7082 */         int count1 = wodatabean.getModifiedCount();
/*  6102: 7083 */         int count2 = tkdatabean.getModifiedCount();
/*  6103: 7085 */         if ((count1 > 0) || (count2 > 0))
/*  6104:      */         {
/*  6105: 7087 */           ProgressObserver observer = event.getProgressObserver();
/*  6106: 7088 */           if (observer != null)
/*  6107:      */           {
/*  6108: 7090 */             String msg = MobileMessageGenerator.generate("markalldoneprogress", new Object[0]);
/*  6109: 7091 */             observer.setWorkProgressMessage(msg);
/*  6110:      */           }
/*  6111: 7094 */           if (count1 > 0) {
/*  6112: 7095 */             wodatabean.doneAll();
/*  6113:      */           }
/*  6114: 7096 */           if (count2 > 0) {
/*  6115: 7097 */             tkdatabean.doneAll();
/*  6116:      */           }
/*  6117:      */         }
/*  6118:      */       case 2: 
/*  6119: 7101 */         UIUtil.refreshCurrentScreen();
/*  6120: 7102 */         break;
/*  6121:      */       case 0: 
/*  6122: 7104 */         UIUtil.refreshCurrentScreen();
/*  6123: 7105 */         break;
/*  6124:      */       case 3: 
/*  6125: 7107 */         UIUtil.refreshCurrentScreen();
/*  6126: 7108 */         UIUtil.showExceptionMessage(event.getException(), null, 0);
/*  6127:      */       }
/*  6128:      */     }
/*  6129: 7113 */     return true;
/*  6130:      */   }
/*  6131:      */   
/*  6132:      */   public boolean initservicegrouplookup(UIEvent event)
/*  6133:      */     throws MobileApplicationException
/*  6134:      */   {
/*  6135: 7118 */     MobileMboDataBean databean = ((PageControl)event.getCreatingObject()).getDataBean();
/*  6136: 7119 */     databean.getQBE().setQBE("PARENT", "~NULL~");
/*  6137: 7120 */     databean.reset();
/*  6138:      */     
/*  6139: 7122 */     return false;
/*  6140:      */   }
/*  6141:      */   
/*  6142:      */   public boolean validateservicegroup(UIEvent event)
/*  6143:      */     throws MobileApplicationException
/*  6144:      */   {
/*  6145: 7127 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/*  6146: 7128 */     if (databean.getName().equalsIgnoreCase("COMMODITIES")) {
/*  6147: 7129 */       databean = ((PageControl)UIUtil.getCurrentScreen()).getLaunchingControl().getDataBean();
/*  6148:      */     }
/*  6149: 7131 */     if (databean.getName().equalsIgnoreCase("TICKET"))
/*  6150:      */     {
/*  6151: 7133 */       databean.setValue("COMMODITY", "");
/*  6152: 7134 */       UIUtil.refreshCurrentScreen();
/*  6153:      */     }
/*  6154: 7137 */     return false;
/*  6155:      */   }
/*  6156:      */   
/*  6157:      */   public boolean initservicelookup(UIEvent event)
/*  6158:      */     throws MobileApplicationException
/*  6159:      */   {
/*  6160: 7142 */     MobileMboDataBean tkdatabean = UIUtil.getCurrentScreen().getDataBean();
/*  6161: 7143 */     MobileMboDataBean databean = ((PageControl)event.getCreatingObject()).getDataBean();
/*  6162: 7145 */     if (tkdatabean.getValue("COMMODITYGROUP").equalsIgnoreCase("")) {
/*  6163: 7146 */       databean.getQBE().setQBE("PARENT", "!=~NULL~");
/*  6164:      */     } else {
/*  6165: 7148 */       databean.getQBE().setQBE("PARENT", "=" + tkdatabean.getValue("COMMODITYGROUP"));
/*  6166:      */     }
/*  6167: 7150 */     databean.reset();
/*  6168:      */     
/*  6169: 7152 */     return false;
/*  6170:      */   }
/*  6171:      */   
/*  6172:      */   public boolean validateservice(UIEvent event)
/*  6173:      */     throws MobileApplicationException
/*  6174:      */   {
/*  6175: 7157 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/*  6176: 7158 */     if (databean.getName().equalsIgnoreCase("COMMODITIES")) {
/*  6177: 7159 */       databean = ((PageControl)UIUtil.getCurrentScreen()).getLaunchingControl().getDataBean();
/*  6178:      */     }
/*  6179: 7161 */     String sValue = (String)event.getValue();
/*  6180: 7162 */     if ((sValue != null) && (!sValue.equals("")))
/*  6181:      */     {
/*  6182: 7164 */       MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager("COMMODITIES");
/*  6183: 7165 */       MobileMboDataBean comdatabean = mgrDBMgr.getDataBean();
/*  6184: 7166 */       comdatabean.getQBE().reset();
/*  6185: 7167 */       comdatabean.getQBE().setQbeExactMatch(true);
/*  6186:      */       
/*  6187: 7169 */       comdatabean.getQBE().setQBE("COMMODITY", sValue);
/*  6188: 7170 */       comdatabean.reset();
/*  6189: 7171 */       if (comdatabean.getMobileMbo(0) != null)
/*  6190:      */       {
/*  6191: 7173 */         databean.setValue("COMMODITYGROUP", comdatabean.getValue(0, "PARENT"));
/*  6192: 7174 */         UIUtil.refreshCurrentScreen();
/*  6193:      */       }
/*  6194:      */     }
/*  6195: 7177 */     return false;
/*  6196:      */   }
/*  6197:      */   
/*  6198:      */   public boolean insertrelasset(UIEvent event)
/*  6199:      */     throws MobileApplicationException
/*  6200:      */   {
/*  6201: 7182 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/*  6202: 7183 */     if (databean != null) {
/*  6203: 7185 */       databean.insert();
/*  6204:      */     }
/*  6205: 7188 */     UIUtil.refreshCurrentScreen();
/*  6206: 7189 */     return true;
/*  6207:      */   }
/*  6208:      */   
/*  6209:      */   public boolean actualenablebc(UIEvent event)
/*  6210:      */     throws MobileApplicationException
/*  6211:      */   {
/*  6212: 7195 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/*  6213: 7196 */     if ((databean != null) && (databean.getName().equals("WORKLIST"))) {
/*  6214: 7199 */       databean = setWorklistRecordBean(event, null);
/*  6215:      */     }
/*  6216: 7201 */     boolean enabled = false;
/*  6217: 7203 */     if ((databean != null) && ((databean.getName().equals("WORKORDER")) || (databean.getName().equals("TICKET")))) {
/*  6218: 7205 */       if (databean.getName().equals("WORKORDER")) {
/*  6219: 7206 */         enabled = canEnterActualsOnWO(databean);
/*  6220: 7207 */       } else if (databean.getName().equals("TICKET")) {
/*  6221: 7208 */         enabled = canEnterActualsOnTicket(databean);
/*  6222:      */       }
/*  6223:      */     }
/*  6224: 7211 */     ((TableControl)event.getCreatingObject()).setBarcodeEnabled(enabled);
/*  6225: 7212 */     return true;
/*  6226:      */   }
/*  6227:      */   
/*  6228:      */   public boolean createPrimaryMultiEntry(UIEvent event)
/*  6229:      */     throws MobileApplicationException
/*  6230:      */   {
/*  6231: 7219 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/*  6232:      */     
/*  6233: 7221 */     String beanName = "WOMULTIASSETLOCCI";
/*  6234: 7222 */     if ("TICKET".equalsIgnoreCase(databean.getName())) {
/*  6235: 7224 */       beanName = "TKMULTIASSETLOCCI";
/*  6236:      */     }
/*  6237: 7226 */     MobileMboDataBean multidatabean = databean.getDataBean(beanName);
/*  6238:      */     
/*  6239: 7228 */     String assetNum = databean.getValue("ASSETNUM");
/*  6240: 7229 */     String location = databean.getValue("LOCATION");
/*  6241: 7230 */     String ciNum = databean.getValue("CINUM");
/*  6242:      */     
/*  6243: 7232 */     MobileMboQBE qbe = multidatabean.getQBE();
/*  6244: 7233 */     qbe.reset();
/*  6245: 7234 */     qbe.setQBE("ISPRIMARY", "1");
/*  6246: 7235 */     multidatabean.reset();
/*  6247:      */     
/*  6248:      */ 
/*  6249:      */ 
/*  6250:      */ 
/*  6251: 7240 */     boolean toBeInsertedState = databean.getMobileMbo().isToBeInserted();
/*  6252: 7241 */     boolean toBeUpdatedState = databean.getMobileMbo().isToBeUpdated();
/*  6253: 7242 */     boolean toBeDeletedState = databean.getMobileMbo().isToBeDeleted();
/*  6254: 7244 */     if ((!UIUtil.isNull(assetNum)) || (!UIUtil.isNull(location)) || (!UIUtil.isNull(ciNum)))
/*  6255:      */     {
/*  6256: 7246 */       setMultiDataBeanFields(multidatabean, databean);
/*  6257:      */       
/*  6258:      */ 
/*  6259: 7249 */       databean.getMobileMbo().setToBeInserted(toBeInsertedState);
/*  6260: 7250 */       databean.getMobileMbo().setToBeDeleted(toBeDeletedState);
/*  6261: 7251 */       databean.getMobileMbo().setToBeUpdated(toBeUpdatedState);
/*  6262:      */       
/*  6263: 7253 */       qbe.reset();
/*  6264:      */     }
/*  6265: 7256 */     return true;
/*  6266:      */   }
/*  6267:      */   
/*  6268:      */   private void setMultiDataBeanFields(MobileMboDataBean multidatabean, MobileMboDataBean databean)
/*  6269:      */     throws MobileApplicationException
/*  6270:      */   {
/*  6271: 7263 */     if (multidatabean.count() == 0)
/*  6272:      */     {
/*  6273: 7265 */       multidatabean.getQBE().reset();
/*  6274: 7266 */       multidatabean.reset();
/*  6275: 7267 */       multidatabean.insert();
/*  6276:      */       
/*  6277: 7269 */       String recordKeyField = "WONUM";
/*  6278: 7270 */       String recordClassField = "WOCLASS";
/*  6279: 7271 */       boolean isTicket = false;
/*  6280: 7272 */       if ("TICKET".equalsIgnoreCase(databean.getName()))
/*  6281:      */       {
/*  6282: 7274 */         isTicket = true;
/*  6283: 7275 */         recordKeyField = "TICKETID";
/*  6284: 7276 */         recordClassField = "CLASS";
/*  6285:      */       }
/*  6286: 7279 */       long uid = UIUtil.getApplication().getUniqueNumber(multidatabean.getName(), "_" + multidatabean.getName());
/*  6287: 7280 */       multidatabean.setValue("MULTIID", String.valueOf(uid));
/*  6288:      */       
/*  6289: 7282 */       multidatabean.setValue("RECORDKEY", databean.getValue(recordKeyField));
/*  6290: 7283 */       multidatabean.setValue("RECORDCLASS", databean.getValue(recordClassField));
/*  6291: 7284 */       multidatabean.setValue("SITEID", databean.getValue("SITEID"));
/*  6292: 7285 */       multidatabean.setValue("ORGID", databean.getValue("ORGID"));
/*  6293: 7286 */       if (!isTicket)
/*  6294:      */       {
/*  6295: 7288 */         multidatabean.setValue("WORKSITEID", databean.getValue("SITEID"));
/*  6296: 7289 */         multidatabean.setValue("WORKORGID", databean.getValue("ORGID"));
/*  6297:      */       }
/*  6298: 7291 */       multidatabean.setValue("ASSETNUM", databean.getValue("ASSETNUM"));
/*  6299: 7292 */       multidatabean.setValue("LOCATION", databean.getValue("LOCATION"));
/*  6300: 7293 */       multidatabean.setValue("CINUM", databean.getValue("CINUM"));
/*  6301: 7294 */       multidatabean.setValue("TARGETDESC", databean.getValue("TARGETDESC"));
/*  6302: 7295 */       multidatabean.setValue("TARGETDESC_LONGDESCRIPTION", databean.getValue("TARGETDESC_LONGDESCRIPTION"));
/*  6303: 7296 */       multidatabean.setValue("ISPRIMARY", "1");
/*  6304:      */       
/*  6305:      */ 
/*  6306: 7299 */       MobileMboDataBean assetBean = DataBeanCache.getDataBean("ASSET", "ASSET");
/*  6307: 7300 */       if (assetBean != null)
/*  6308:      */       {
/*  6309: 7303 */         int currentPos = assetBean.getCurrentPosition();
/*  6310: 7304 */         MobileMboQBE qbe = assetBean.getQBE();
/*  6311: 7305 */         qbe.saveState();
/*  6312: 7306 */         qbe.setQBE("ASSETNUM", databean.getValue("ASSETNUM"));
/*  6313: 7307 */         qbe.setQBE("SITEID", databean.getValue("SITEID"));
/*  6314: 7308 */         assetBean.reset();
/*  6315:      */         
/*  6316: 7310 */         MobileMbo assetmbo = assetBean.getMobileMbo(0);
/*  6317: 7311 */         qbe.restoreState();
/*  6318: 7312 */         assetBean.reset();
/*  6319: 7313 */         assetBean.setCurrentPosition(currentPos);
/*  6320: 7314 */         if (assetmbo != null) {
/*  6321: 7316 */           LinearAssetEventHandler.setMultiLinearFields(multidatabean, assetmbo);
/*  6322:      */         }
/*  6323:      */       }
/*  6324: 7323 */       multidatabean.getDataBeanManager().save();
/*  6325:      */     }
/*  6326: 7328 */     else if (multidatabean.count() != 0)
/*  6327:      */     {
/*  6328: 7330 */       multidatabean.setValue("ASSETNUM", databean.getValue("ASSETNUM"));
/*  6329: 7331 */       multidatabean.setValue("LOCATION", databean.getValue("LOCATION"));
/*  6330: 7332 */       multidatabean.setValue("CINUM", databean.getValue("CINUM"));
/*  6331: 7333 */       multidatabean.setValue("TARGETDESC", databean.getValue("TARGETDESC"));
/*  6332: 7334 */       multidatabean.setValue("TARGETDESC_LONGDESCRIPTION", databean.getValue("TARGETDESC_LONGDESCRIPTION"));
/*  6333: 7335 */       multidatabean.getDataBeanManager().save();
/*  6334:      */     }
/*  6335:      */   }
/*  6336:      */   
/*  6337:      */   public boolean moveSwapAsset(UIEvent event)
/*  6338:      */     throws MobileApplicationException
/*  6339:      */   {
/*  6340: 7343 */     AbstractMobileControl callingControl = (AbstractMobileControl)event.getCreatingObject();
/*  6341: 7344 */     MobileMboDataBean woBean = callingControl.getDataBean();
/*  6342: 7347 */     if (!woBean.getName().equals("WORKORDER")) {
/*  6343: 7348 */       woBean = DataBeanCache.findDataBean("WORKORDER");
/*  6344:      */     }
/*  6345: 7350 */     String moveSwapPage = "womoveasset_details";
/*  6346: 7352 */     if ((woBean.getValue("WOISSWAP") != null) && (woBean.getValue("WOISSWAP").equals("1"))) {
/*  6347: 7353 */       moveSwapPage = "woswapasset_details";
/*  6348:      */     }
/*  6349: 7355 */     UIUtil.gotoPage(moveSwapPage, (AbstractMobileControl)event.getCreatingObject());
/*  6350:      */     
/*  6351: 7357 */     return true;
/*  6352:      */   }
/*  6353:      */   
/*  6354:      */   public boolean moveSwapAssetfromChildren(UIEvent event)
/*  6355:      */     throws MobileApplicationException
/*  6356:      */   {
/*  6357: 7363 */     MobileMboDataBean woChildrenBean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*  6358: 7364 */     MobileMboDataBean woBean = DataBeanCache.getDataBean("WORKORDER_CHILDREN", "WORKORDER");
/*  6359: 7365 */     if (woBean != null)
/*  6360:      */     {
/*  6361: 7367 */       woBean.getQBE().setQBE("WONUM", woChildrenBean.getValue("WONUM"));
/*  6362: 7368 */       woBean.getQBE().setQBE("SITEID", woChildrenBean.getValue("SITEID"));
/*  6363: 7369 */       woBean.reset();
/*  6364:      */       
/*  6365: 7371 */       String moveSwapPage = "womoveassetfromchild";
/*  6366: 7373 */       if ((woBean.getValue("WOISSWAP") != null) && (woBean.getValue("WOISSWAP").equals("1"))) {
/*  6367: 7374 */         moveSwapPage = "woswapassetfromchild";
/*  6368:      */       }
/*  6369: 7376 */       UIUtil.gotoPage(moveSwapPage, (AbstractMobileControl)event.getCreatingObject());
/*  6370:      */     }
/*  6371: 7379 */     return true;
/*  6372:      */   }
/*  6373:      */   
/*  6374:      */   public boolean filter(UIEvent event)
/*  6375:      */     throws MobileApplicationException
/*  6376:      */   {
/*  6377: 7385 */     AbstractMobileControl ctrl = (AbstractMobileControl)event.getCreatingObject();
/*  6378: 7386 */     MobileMboDataBean dataBean = ctrl.getDataBean();
/*  6379: 7389 */     if ("wofilter".equalsIgnoreCase(ctrl.getPage().getId())) {
/*  6380: 7391 */       if (dataBean.getQBE().getQBE("ASSETNUM") != null) {
/*  6381: 7392 */         setMultiAssetFilter(dataBean);
/*  6382:      */       }
/*  6383:      */     }
/*  6384: 7395 */     if (dataBean != null)
/*  6385:      */     {
/*  6386: 7397 */       dataBean.reset();
/*  6387: 7398 */       dataBean.setFiltered(true);
/*  6388: 7399 */       dataBean.getMobileMbo(0);
/*  6389:      */     }
/*  6390: 7401 */     return closepage(event);
/*  6391:      */   }
/*  6392:      */   
/*  6393:      */   private void setMultiAssetFilter(MobileMboDataBean dataBean)
/*  6394:      */     throws MobileApplicationException
/*  6395:      */   {
/*  6396: 7407 */     String woList = "";
/*  6397:      */     
/*  6398:      */ 
/*  6399: 7410 */     String woAsset = getWOListByMultiAsset("ASSETNUM", dataBean.getQBE().getQBE("ASSETNUM"));
/*  6400:      */     
/*  6401:      */ 
/*  6402: 7413 */     String woReplacement = getWOListByMultiAsset("REPLACEASSETNUM", dataBean.getQBE().getQBE("ASSETNUM"));
/*  6403:      */     
/*  6404: 7415 */     woList = woAsset;
/*  6405: 7418 */     if ((!woAsset.equals("")) && (!woReplacement.equals(""))) {
/*  6406: 7419 */       woList = woList + ",";
/*  6407:      */     }
/*  6408: 7421 */     woList = woList + woReplacement;
/*  6409: 7424 */     if (dataBean.getQBE().getQBE("RECORDID") != null) {
/*  6410: 7425 */       woList = woList + "," + dataBean.getQBE().getQBE("RECORDID");
/*  6411:      */     }
/*  6412: 7430 */     if (!woList.equals(""))
/*  6413:      */     {
/*  6414: 7432 */       dataBean.getQBE().setQBE("RECORDID", woList);
/*  6415: 7433 */       dataBean.getQBE().setQBE("ASSETNUM", "");
/*  6416:      */     }
/*  6417:      */   }
/*  6418:      */   
/*  6419:      */   private String getWOListByMultiAsset(String fieldName, String assetNum)
/*  6420:      */     throws MobileApplicationException
/*  6421:      */   {
/*  6422: 7442 */     StringBuffer ret = new StringBuffer();
/*  6423:      */     
/*  6424: 7444 */     MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager("WOMULTIASSETLOCCI");
/*  6425: 7445 */     MobileMboDataBean multiBean = mgrDBMgr.getDataBean();
/*  6426: 7446 */     multiBean.getQBE().reset();
/*  6427: 7447 */     multiBean.getQBE().setQbeExactMatch(true);
/*  6428:      */     
/*  6429: 7449 */     multiBean.getQBE().setQBE(fieldName, assetNum);
/*  6430: 7450 */     multiBean.reset();
/*  6431: 7452 */     for (int i = 0; i < multiBean.count(); i++) {
/*  6432: 7453 */       ret.append(multiBean.getValue(i, "RECORDKEY")).append(",");
/*  6433:      */     }
/*  6434: 7456 */     if (ret.length() > 0) {
/*  6435: 7457 */       ret.deleteCharAt(ret.length() - 1);
/*  6436:      */     }
/*  6437: 7460 */     return ret.toString();
/*  6438:      */   }
/*  6439:      */   
/*  6440:      */   public boolean gotoSpecsPage(UIEvent event)
/*  6441:      */     throws MobileApplicationException
/*  6442:      */   {
/*  6443: 7467 */     String page = ((AbstractMobileControl)event.getCreatingObject()).getPage().getId();
/*  6444: 7468 */     if ((page.equals("womain")) || (page.equals("woresults")))
/*  6445:      */     {
/*  6446: 7471 */       MobileMboDataBean multiBean = DataBeanCache.findDataBean("WOMULTI");
/*  6447:      */       
/*  6448:      */ 
/*  6449: 7474 */       MobileMboDataBean woBean = DataBeanCache.findDataBean("WORKORDER");
/*  6450: 7477 */       if (multiBean == null) {
/*  6451: 7479 */         if (woBean != null)
/*  6452:      */         {
/*  6453: 7482 */           multiBean = woBean.getDataBean("WOMULTIASSETLOCCI");
/*  6454: 7483 */           DataBeanCache.cacheDataBean("WOMULTI", multiBean);
/*  6455:      */         }
/*  6456:      */       }
/*  6457:      */     }
/*  6458: 7488 */     return gotopage(event);
/*  6459:      */   }
/*  6460:      */   
/*  6461:      */   public boolean canSubmit(UIEvent event)
/*  6462:      */     throws MobileApplicationException
/*  6463:      */   {
/*  6464: 7495 */     MobileMboDataBean databean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*  6465: 7497 */     if (!databean.getValue("PARENT").trim().equals(""))
/*  6466:      */     {
/*  6467: 7502 */       MobileMboDataBean parent = new MobileMboDataBeanManager("WORKLIST").getDataBean();
/*  6468: 7503 */       MobileMboQBE qbe = parent.getQBE();
/*  6469: 7504 */       qbe.setQBE("RECORDID", databean.getValue("PARENT"));
/*  6470: 7505 */       qbe.setQBE("CLASS", databean.getValue("CLASS"));
/*  6471: 7506 */       qbe.setQBE("_NEW", "1");
/*  6472: 7507 */       qbe.setQbeExactMatch(true);
/*  6473: 7508 */       parent.reset();
/*  6474:      */       
/*  6475: 7510 */       boolean parentExistsAndIsNew = parent.count() > 0;
/*  6476:      */       
/*  6477: 7512 */       ((AbstractMobileControl)event.getCreatingObject()).setVisibility(!parentExistsAndIsNew);
/*  6478:      */     }
/*  6479: 7514 */     return true;
/*  6480:      */   }
/*  6481:      */   
/*  6482:      */   public boolean openTicketAndCommunication(UIEvent event)
/*  6483:      */     throws MobileApplicationException
/*  6484:      */   {
/*  6485: 7525 */     PageControl ticketPage = (PageControl)UIUtil.getCurrentScreen();
/*  6486: 7526 */     UIEvent newEvent = new UIEvent(ticketPage, "initpage", "createtkcomm", "");
/*  6487: 7527 */     UIUtil.sendEvent(newEvent);
/*  6488: 7528 */     return false;
/*  6489:      */   }
/*  6490:      */   
/*  6491:      */   private boolean processPopUpMenuDisplay(UIEvent event, boolean hideIfNullOrNotDownloaded)
/*  6492:      */     throws MobileApplicationException
/*  6493:      */   {
/*  6494: 7536 */     MobileMboDataBean dataBean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*  6495: 7537 */     if (dataBean == null) {
/*  6496: 7538 */       return true;
/*  6497:      */     }
/*  6498: 7540 */     String dataname = "WORKORDER";
/*  6499: 7541 */     if ((dataBean.getName().equalsIgnoreCase("WORELTICKETS")) || (dataBean.getName().equalsIgnoreCase("TKRELTICKETS"))) {
/*  6500: 7544 */       dataname = "TICKET";
/*  6501:      */     }
/*  6502: 7547 */     MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager(dataname);
/*  6503: 7548 */     MobileMboDataBean bean = mgrDBMgr.getDataBean();
/*  6504: 7549 */     bean.getQBE().reset();
/*  6505: 7550 */     bean.getQBE().setQbeExactMatch(true);
/*  6506: 7551 */     bean.getQBE().setQBE("_ID", dataBean.getMobileMbo().getValue("RELATEDRECKEYID"));
/*  6507: 7552 */     bean.reset();
/*  6508: 7553 */     if (bean.getMobileMbo(0) == null)
/*  6509:      */     {
/*  6510: 7556 */       ((AbstractMobileControl)event.getCreatingObject()).setVisibility(!hideIfNullOrNotDownloaded);
/*  6511: 7557 */       return true;
/*  6512:      */     }
/*  6513: 7561 */     boolean isNull = false;
/*  6514: 7562 */     String currentFieldName = ((AbstractMobileControl)event.getCreatingObject()).getValue("dataattribute");
/*  6515: 7563 */     String currentValue = dataBean.getValue(currentFieldName);
/*  6516: 7564 */     if ((currentValue == null) || (currentValue.length() == 0)) {
/*  6517: 7566 */       isNull = true;
/*  6518:      */     }
/*  6519: 7569 */     if (isNull) {
/*  6520: 7571 */       ((AbstractMobileControl)event.getCreatingObject()).setVisibility(!hideIfNullOrNotDownloaded);
/*  6521:      */     } else {
/*  6522: 7575 */       ((AbstractMobileControl)event.getCreatingObject()).setVisibility(hideIfNullOrNotDownloaded);
/*  6523:      */     }
/*  6524: 7579 */     return true;
/*  6525:      */   }
/*  6526:      */   
/*  6527:      */   private WOApp getApp()
/*  6528:      */   {
/*  6529: 7584 */     return (WOApp)UIUtil.getApplication();
/*  6530:      */   }
/*  6531:      */   
/*  6532:      */   public boolean workTypeFilterLookup(UIEvent event)
/*  6533:      */     throws MobileApplicationException
/*  6534:      */   {
/*  6535: 7590 */     MobileMboDataBean creatingObjDataBean = DataBeanCache.findDataBean("WORKLIST");
/*  6536: 7591 */     MobileMboDataBean databean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*  6537: 7592 */     if (databean != null)
/*  6538:      */     {
/*  6539: 7593 */       String orgid = creatingObjDataBean.getValue("ORGID");
/*  6540: 7594 */       if (!"".equals(orgid)) {
/*  6541: 7595 */         databean.getQBE().setQBE("ORGID", orgid);
/*  6542:      */       }
/*  6543: 7598 */       if (creatingObjDataBean.getQBE().getQBEData("CLASS") != null)
/*  6544:      */       {
/*  6545: 7599 */         String woclass = creatingObjDataBean.getQBE().getQBEData("CLASS").getValue();
/*  6546: 7600 */         if (!"".equals(woclass)) {
/*  6547: 7601 */           databean.getQBE().setQBE("WOCLASS", woclass);
/*  6548:      */         }
/*  6549:      */       }
/*  6550:      */     }
/*  6551: 7605 */     return true;
/*  6552:      */   }
/*  6553:      */   
/*  6554:      */   public boolean pluscinsertwods(UIEvent event)
/*  6555:      */     throws MobileApplicationException
/*  6556:      */   {
/*  6557: 7619 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/*  6558: 7621 */     if ((databean != null) && 
/*  6559: 7622 */       (databean.getName().equals("PLUSCWODS")))
/*  6560:      */     {
/*  6561: 7623 */       databean.insert();
/*  6562: 7624 */       MobileMboDataBean wodatabean = DataBeanCache.findDataBean("WORKORDER");
/*  6563: 7625 */       MobileMbo woMbo = wodatabean.getMobileMbo();
/*  6564: 7626 */       databean.setValue("ASSETNUM", woMbo.getValue("ASSETNUM"));
/*  6565: 7627 */       UIUtil.refreshCurrentScreen();
/*  6566: 7628 */       return true;
/*  6567:      */     }
/*  6568: 7632 */     return false;
/*  6569:      */   }
/*  6570:      */   
/*  6571:      */   public boolean plusccopydsplanstowo(UIEvent event)
/*  6572:      */     throws MobileApplicationException
/*  6573:      */   {
/*  6574: 7647 */     MobileMboDataBean pluscwodsDataBean = ((PageControl)UIUtil.getCurrentScreen()).getLaunchingControl().getDataBean();
/*  6575: 7648 */     MobileMboDataBean woDataBean = pluscwodsDataBean.getParentBean();
/*  6576: 7649 */     MobileMbo woMbo = woDataBean.getMobileMbo();
/*  6577:      */     
/*  6578: 7651 */     woMbo.setValue("PLUSCISMOBILE", "1");
/*  6579: 7653 */     if ((pluscwodsDataBean != null) && (pluscwodsDataBean.getName().equals("PLUSCWODS")))
/*  6580:      */     {
/*  6581: 7657 */       MobileMboDataBeanManager plusdsplanDBMgr = new MobileMboDataBeanManager("PLUSDSPLAN");
/*  6582: 7658 */       MobileMboDataBean plusdsplanDataBean = plusdsplanDBMgr.getDataBean();
/*  6583: 7659 */       plusdsplanDataBean.getQBE().reset();
/*  6584: 7660 */       plusdsplanDataBean.getQBE().setQbeExactMatch(true);
/*  6585: 7661 */       plusdsplanDataBean.getQBE().setQBE("DSPLANNUM", (String)event.getValue());
/*  6586: 7662 */       plusdsplanDataBean.reset();
/*  6587: 7664 */       if (plusdsplanDataBean.count() == 0) {
/*  6588: 7665 */         return true;
/*  6589:      */       }
/*  6590: 7669 */       MobileMbo plusdsplanMbo = plusdsplanDataBean.getMobileMbo(0);
/*  6591: 7670 */       pluscwodsDataBean.setValue("SITEID", woMbo.getValue("SITEID"), false);
/*  6592: 7671 */       pluscwodsDataBean.setValue("WONUM", woMbo.getValue("WONUM"), false);
/*  6593:      */       
/*  6594: 7673 */       pluscwodsDataBean.setValue("DSPLANNUM", plusdsplanMbo.getValue("DSPLANNUM"));
/*  6595: 7674 */       pluscwodsDataBean.setValue("DESCRIPTION", plusdsplanMbo.getValue("DESCRIPTION"));
/*  6596:      */       
/*  6597: 7676 */       pluscwodsDataBean.setValue("DESCRIPTION_LONGDESCRIPTION", plusdsplanMbo.getValue("DESCRIPTION_LONGDESCRIPTION"), false);
/*  6598: 7677 */       pluscwodsDataBean.setValue("REVISIONNUM", plusdsplanMbo.getValue("REVISIONNUM"));
/*  6599:      */       
/*  6600: 7679 */       pluscwodsDataBean.setValue("ISADDED", "1");
/*  6601: 7680 */       pluscwodsDataBean.setValue("ADDINGTOWO", "1");
/*  6602:      */       
/*  6603:      */ 
/*  6604: 7683 */       pluscwodsDataBean.setValue("WODSNUM", "-" + UIUtil.getApplication().getNextAutoNumber("PLUSCWODS"));
/*  6605:      */       
/*  6606:      */ 
/*  6607: 7686 */       pluscwodsDataBean.setValue("PLUSCWODSID", "-" + UIUtil.getApplication().getNextAutoNumber("PLUSCWODS"));
/*  6608:      */       
/*  6609:      */ 
/*  6610:      */ 
/*  6611:      */ 
/*  6612:      */ 
/*  6613:      */ 
/*  6614:      */ 
/*  6615:      */ 
/*  6616: 7695 */       pluscwodsDataBean.setValue("CONFIDLEVEL", plusdsplanMbo.getValue("CONFIDLEVEL"), false);
/*  6617: 7696 */       pluscwodsDataBean.setValue("GBMETHOD", plusdsplanMbo.getValue("GBMETHOD"), false);
/*  6618: 7697 */       pluscwodsDataBean.setValue("GUARDBAND", plusdsplanMbo.getValue("GUARDBAND"), false);
/*  6619: 7698 */       pluscwodsDataBean.setValue("KFACTOR", plusdsplanMbo.getValue("KFACTOR"), false);
/*  6620: 7699 */       pluscwodsDataBean.setValue("SYSTEMID", plusdsplanMbo.getValue("SYSTEMID"), false);
/*  6621: 7700 */       pluscwodsDataBean.setValue("SYSTEMIDDESC", plusdsplanMbo.getValue("SYSTEMIDDESC"), false);
/*  6622: 7701 */       pluscwodsDataBean.setValue("SYSTEMIDDESC_LONGDESCRIPTION", plusdsplanMbo.getValue("SYSTEMIDDESC_LONGDESCRIPTION"), false);
/*  6623: 7702 */       pluscwodsDataBean.setValue("UNCERTFREQ", plusdsplanMbo.getValue("UNCERTFREQ"), false);
/*  6624: 7703 */       pluscwodsDataBean.setValue("UNCERTUNITS", plusdsplanMbo.getValue("UNCERTUNITS"), false);
/*  6625:      */       
/*  6626:      */ 
/*  6627:      */ 
/*  6628:      */ 
/*  6629:      */ 
/*  6630:      */ 
/*  6631: 7710 */       MobileMboDataBeanManager instrDBMgr = new MobileMboDataBeanManager("PLUSCDSINSTR");
/*  6632: 7711 */       MobileMboDataBean pluscdsinstrDataBean = instrDBMgr.getDataBean();
/*  6633: 7712 */       pluscdsinstrDataBean.getQBE().reset();
/*  6634: 7713 */       pluscdsinstrDataBean.getQBE().setQbeExactMatch(true);
/*  6635: 7714 */       pluscdsinstrDataBean.getQBE().setQBE("DSPLANNUM", plusdsplanMbo.getValue("DSPLANNUM"));
/*  6636: 7715 */       pluscdsinstrDataBean.getQBE().setQBE("REVISIONNUM", plusdsplanMbo.getValue("REVISIONNUM"));
/*  6637: 7716 */       pluscdsinstrDataBean.reset();
/*  6638: 7718 */       if (pluscdsinstrDataBean.count() != 0)
/*  6639:      */       {
/*  6640: 7720 */         MobileMboDataBean pluscwodsinstrDataBean = pluscwodsDataBean.getDataBean("PLUSCWODSINSTR");
/*  6641: 7724 */         while (pluscwodsinstrDataBean.count() > 0) {
/*  6642: 7725 */           pluscwodsinstrDataBean.remove();
/*  6643:      */         }
/*  6644: 7729 */         int iloop = 0;
/*  6645:      */         MobileMbo pluscdsinstrMbo;
/*  6646: 7730 */         while ((pluscdsinstrMbo = pluscdsinstrDataBean.getMobileMbo(iloop)) != null)
/*  6647:      */         {
/*  6648: 7731 */           pluscwodsinstrDataBean.insert();
/*  6649: 7732 */           pluscwodsinstrDataBean.setValue("WONUM", woMbo.getValue("WONUM"), false);
/*  6650:      */           
/*  6651:      */ 
/*  6652: 7735 */           pluscwodsinstrDataBean.setValue("PLUSCWODSINSTRID", "-" + UIUtil.getApplication().getNextAutoNumber("PLUSCWODSINSTR"));
/*  6653:      */           
/*  6654:      */ 
/*  6655: 7738 */           pluscwodsinstrDataBean.setValue("WODSNUM", pluscwodsDataBean.getValue("WODSNUM"));
/*  6656:      */           
/*  6657: 7740 */           pluscwodsinstrDataBean.setValue("SITEID", woMbo.getValue("SITEID"), false);
/*  6658: 7741 */           pluscwodsinstrDataBean.setValue("ASSETNUM", woMbo.getValue("ASSETNUM"), false);
/*  6659: 7742 */           pluscwodsinstrDataBean.setValue("ALLOWPOINTINSERTS", pluscdsinstrMbo.getValue("ALLOWPOINTINSERTS"), false);
/*  6660: 7743 */           pluscwodsinstrDataBean.setValue("DESCRIPTION", pluscdsinstrMbo.getValue("DESCRIPTION"), false);
/*  6661: 7744 */           pluscwodsinstrDataBean.setValue("DESCRIPTION_LONGDESCRIPTION", pluscdsinstrMbo.getValue("DESCRIPTION_LONGDESCRIPTION"), false);
/*  6662: 7745 */           pluscwodsinstrDataBean.setValue("DSPLANNUM", pluscdsinstrMbo.getValue("DSPLANNUM"), false);
/*  6663: 7746 */           pluscwodsinstrDataBean.setValue("INPUTRANGE", pluscdsinstrMbo.getValue("INPUTRANGE"), false);
/*  6664: 7747 */           pluscwodsinstrDataBean.setValue("INPUTPRECISION", pluscdsinstrMbo.getValue("INPUTPRECISION"), false);
/*  6665: 7748 */           pluscwodsinstrDataBean.setValue("INSTRCALRANGEEU", pluscdsinstrMbo.getValue("INSTRCALRANGEEU"), false);
/*  6666: 7749 */           pluscwodsinstrDataBean.setValue("INSTRCALRANGEFROM", pluscdsinstrMbo.getValue("INSTRCALRANGEFROM"), false);
/*  6667: 7750 */           pluscwodsinstrDataBean.setValue("INSTRCALRANGETO", pluscdsinstrMbo.getValue("INSTRCALRANGETO"), false);
/*  6668: 7751 */           pluscwodsinstrDataBean.setValue("INSTROUTRANGEEU", pluscdsinstrMbo.getValue("INSTROUTRANGEEU"), false);
/*  6669: 7752 */           pluscwodsinstrDataBean.setValue("INSTROUTRANGEFROM", pluscdsinstrMbo.getValue("INSTROUTRANGEFROM"), false);
/*  6670: 7753 */           pluscwodsinstrDataBean.setValue("INSTROUTRANGETO", pluscdsinstrMbo.getValue("INSTROUTRANGETO"), false);
/*  6671: 7754 */           pluscwodsinstrDataBean.setValue("INSTRSEQ", pluscdsinstrMbo.getValue("INSTRSEQ"), false);
/*  6672: 7755 */           pluscwodsinstrDataBean.setValue("NOADJMADECHOICE1", pluscdsinstrMbo.getValue("NOADJMADECHOICE1"), false);
/*  6673: 7756 */           pluscwodsinstrDataBean.setValue("NOADJMADECHOICE2", pluscdsinstrMbo.getValue("NOADJMADECHOICE2"), false);
/*  6674: 7757 */           pluscwodsinstrDataBean.setValue("NOADJMADECHOICE3", pluscdsinstrMbo.getValue("NOADJMADECHOICE3"), false);
/*  6675: 7758 */           pluscwodsinstrDataBean.setValue("NOADJMADECHOICE4", pluscdsinstrMbo.getValue("NOADJMADECHOICE4"), false);
/*  6676: 7759 */           pluscwodsinstrDataBean.setValue("OUTPUTRANGE", pluscdsinstrMbo.getValue("OUTPUTRANGE"), false);
/*  6677: 7760 */           pluscwodsinstrDataBean.setValue("OUTPUTPRECISION", pluscdsinstrMbo.getValue("OUTPUTPRECISION"), false);
/*  6678: 7761 */           pluscwodsinstrDataBean.setValue("PLANTYPE", pluscdsinstrMbo.getValue("PLANTYPE"), false);
/*  6679: 7762 */           pluscwodsinstrDataBean.setValue("PROCESSEU", pluscdsinstrMbo.getValue("PROCESSEU"), false);
/*  6680: 7763 */           pluscwodsinstrDataBean.setValue("PROCESSEUFACTOR", pluscdsinstrMbo.getValue("PROCESSEUFACTOR"), false);
/*  6681: 7764 */           pluscwodsinstrDataBean.setValue("RON1LOWERVALUE", pluscdsinstrMbo.getValue("RON1LOWERVALUE"), false);
/*  6682: 7765 */           pluscwodsinstrDataBean.setValue("RON1TYPE", pluscdsinstrMbo.getValue("RON1TYPE"), false);
/*  6683: 7766 */           pluscwodsinstrDataBean.setValue("RON1UPPERVALUE", pluscdsinstrMbo.getValue("RON1UPPERVALUE"), false);
/*  6684: 7767 */           pluscwodsinstrDataBean.setValue("TOL1LOWERVALUE", pluscdsinstrMbo.getValue("TOL1LOWERVALUE"), false);
/*  6685: 7768 */           pluscwodsinstrDataBean.setValue("TOL1TYPE", pluscdsinstrMbo.getValue("TOL1TYPE"), false);
/*  6686: 7769 */           pluscwodsinstrDataBean.setValue("TOL1UPPERVALUE", pluscdsinstrMbo.getValue("TOL1UPPERVALUE"), false);
/*  6687: 7770 */           pluscwodsinstrDataBean.setValue("TOL1STATUS", pluscdsinstrMbo.getValue("TOL1STATUS"), false);
/*  6688: 7771 */           pluscwodsinstrDataBean.setValue("TOL2LOWERVALUE", pluscdsinstrMbo.getValue("TOL2LOWERVALUE"), false);
/*  6689: 7772 */           pluscwodsinstrDataBean.setValue("TOL2TYPE", pluscdsinstrMbo.getValue("TOL2TYPE"), false);
/*  6690: 7773 */           pluscwodsinstrDataBean.setValue("TOL2UPPERVALUE", pluscdsinstrMbo.getValue("TOL2UPPERVALUE"), false);
/*  6691: 7774 */           pluscwodsinstrDataBean.setValue("TOL2STATUS", pluscdsinstrMbo.getValue("TOL2STATUS"), false);
/*  6692: 7775 */           pluscwodsinstrDataBean.setValue("TOL3LOWERVALUE", pluscdsinstrMbo.getValue("TOL3LOWERVALUE"), false);
/*  6693: 7776 */           pluscwodsinstrDataBean.setValue("TOL3TYPE", pluscdsinstrMbo.getValue("TOL3TYPE"), false);
/*  6694: 7777 */           pluscwodsinstrDataBean.setValue("TOL3UPPERVALUE", pluscdsinstrMbo.getValue("TOL3UPPERVALUE"), false);
/*  6695: 7778 */           pluscwodsinstrDataBean.setValue("TOL3STATUS", pluscdsinstrMbo.getValue("TOL3STATUS"), false);
/*  6696: 7779 */           pluscwodsinstrDataBean.setValue("TOL4LOWERVALUE", pluscdsinstrMbo.getValue("TOL4LOWERVALUE"), false);
/*  6697: 7780 */           pluscwodsinstrDataBean.setValue("TOL4TYPE", pluscdsinstrMbo.getValue("TOL4TYPE"), false);
/*  6698: 7781 */           pluscwodsinstrDataBean.setValue("TOL4UPPERVALUE", pluscdsinstrMbo.getValue("TOL4UPPERVALUE"), false);
/*  6699: 7782 */           pluscwodsinstrDataBean.setValue("TOL4STATUS", pluscdsinstrMbo.getValue("TOL4STATUS"), false);
/*  6700: 7783 */           pluscwodsinstrDataBean.setValue("CLIPLIMITS", pluscdsinstrMbo.getValue("CLIPLIMITS"), false);
/*  6701: 7784 */           pluscwodsinstrDataBean.setValue("ASSETFUNCTION", pluscdsinstrMbo.getValue("ASSETFUNCTION"), false);
/*  6702: 7785 */           pluscwodsinstrDataBean.setValue("SQUAREROOT", pluscdsinstrMbo.getValue("SQUAREROOT"), false);
/*  6703:      */           
/*  6704: 7787 */           pluscwodsinstrDataBean.setValue("TOL1SUMEU", pluscdsinstrMbo.getValue("TOL1SUMEU"), false);
/*  6705: 7788 */           pluscwodsinstrDataBean.setValue("TOL2SUMEU", pluscdsinstrMbo.getValue("TOL2SUMEU"), false);
/*  6706: 7789 */           pluscwodsinstrDataBean.setValue("TOL3SUMEU", pluscdsinstrMbo.getValue("TOL3SUMEU"), false);
/*  6707: 7790 */           pluscwodsinstrDataBean.setValue("TOL4SUMEU", pluscdsinstrMbo.getValue("TOL4SUMEU"), false);
/*  6708: 7791 */           pluscwodsinstrDataBean.setValue("TOL1SUMSPAN", pluscdsinstrMbo.getValue("TOL1SUMSPAN"), false);
/*  6709: 7792 */           pluscwodsinstrDataBean.setValue("TOL2SUMSPAN", pluscdsinstrMbo.getValue("TOL2SUMSPAN"), false);
/*  6710: 7793 */           pluscwodsinstrDataBean.setValue("TOL3SUMSPAN", pluscdsinstrMbo.getValue("TOL3SUMSPAN"), false);
/*  6711: 7794 */           pluscwodsinstrDataBean.setValue("TOL4SUMSPAN", pluscdsinstrMbo.getValue("TOL4SUMSPAN"), false);
/*  6712: 7795 */           pluscwodsinstrDataBean.setValue("TOL1SUMURV", pluscdsinstrMbo.getValue("TOL1SUMURV"), false);
/*  6713: 7796 */           pluscwodsinstrDataBean.setValue("TOL2SUMURV", pluscdsinstrMbo.getValue("TOL2SUMURV"), false);
/*  6714: 7797 */           pluscwodsinstrDataBean.setValue("TOL3SUMURV", pluscdsinstrMbo.getValue("TOL3SUMURV"), false);
/*  6715: 7798 */           pluscwodsinstrDataBean.setValue("TOL4SUMURV", pluscdsinstrMbo.getValue("TOL4SUMURV"), false);
/*  6716: 7799 */           pluscwodsinstrDataBean.setValue("TOL1SUMREAD", pluscdsinstrMbo.getValue("TOL1SUMREAD"), false);
/*  6717: 7800 */           pluscwodsinstrDataBean.setValue("TOL2SUMREAD", pluscdsinstrMbo.getValue("TOL2SUMREAD"), false);
/*  6718: 7801 */           pluscwodsinstrDataBean.setValue("TOL3SUMREAD", pluscdsinstrMbo.getValue("TOL3SUMREAD"), false);
/*  6719: 7802 */           pluscwodsinstrDataBean.setValue("TOL4SUMREAD", pluscdsinstrMbo.getValue("TOL4SUMREAD"), false);
/*  6720: 7803 */           pluscwodsinstrDataBean.setValue("TOL1SUMDIRECTION", pluscdsinstrMbo.getValue("TOL1SUMDIRECTION"), false);
/*  6721: 7804 */           pluscwodsinstrDataBean.setValue("TOL2SUMDIRECTION", pluscdsinstrMbo.getValue("TOL2SUMDIRECTION"), false);
/*  6722: 7805 */           pluscwodsinstrDataBean.setValue("TOL3SUMDIRECTION", pluscdsinstrMbo.getValue("TOL3SUMDIRECTION"), false);
/*  6723: 7806 */           pluscwodsinstrDataBean.setValue("TOL4SUMDIRECTION", pluscdsinstrMbo.getValue("TOL4SUMDIRECTION"), false);
/*  6724: 7807 */           pluscwodsinstrDataBean.setValue("TOL1NOADJLIMIT", pluscdsinstrMbo.getValue("TOL1NOADJLIMIT"), false);
/*  6725: 7808 */           pluscwodsinstrDataBean.setValue("TOL1DESCRIPTION", pluscdsinstrMbo.getValue("TOL1DESCRIPTION"), false);
/*  6726: 7809 */           pluscwodsinstrDataBean.setValue("TOL2NOADJLIMIT", pluscdsinstrMbo.getValue("TOL2NOADJLIMIT"), false);
/*  6727: 7810 */           pluscwodsinstrDataBean.setValue("TOL2DESCRIPTION", pluscdsinstrMbo.getValue("TOL2DESCRIPTION"), false);
/*  6728: 7811 */           pluscwodsinstrDataBean.setValue("TOL3NOADJLIMIT", pluscdsinstrMbo.getValue("TOL3NOADJLIMIT"), false);
/*  6729: 7812 */           pluscwodsinstrDataBean.setValue("TOL3DESCRIPTION", pluscdsinstrMbo.getValue("TOL3DESCRIPTION"), false);
/*  6730: 7813 */           pluscwodsinstrDataBean.setValue("TOL4NOADJLIMIT", pluscdsinstrMbo.getValue("TOL4NOADJLIMIT"), false);
/*  6731: 7814 */           pluscwodsinstrDataBean.setValue("TOL4DESCRIPTION", pluscdsinstrMbo.getValue("TOL4DESCRIPTION"), false);
/*  6732: 7815 */           pluscwodsinstrDataBean.setValue("REVISIONNUM", pluscdsinstrMbo.getValue("REVISIONNUM"), false);
/*  6733: 7816 */           pluscwodsinstrDataBean.setValue("CALPOINT", pluscdsinstrMbo.getValue("CALPOINT"), false);
/*  6734: 7817 */           pluscwodsinstrDataBean.setValue("CALFUNCTION", pluscdsinstrMbo.getValue("CALFUNCTION"), false);
/*  6735: 7818 */           pluscwodsinstrDataBean.setValue("CALDYNAMIC", pluscdsinstrMbo.getValue("CALDYNAMIC"), false);
/*  6736: 7819 */           pluscwodsinstrDataBean.setValue("NONLINEAR", pluscdsinstrMbo.getValue("NONLINEAR"), false);
/*  6737: 7820 */           pluscwodsinstrDataBean.setValue("REPEATABLE", pluscdsinstrMbo.getValue("REPEATABLE"), false);
/*  6738: 7821 */           pluscwodsinstrDataBean.setValue("MANUAL", pluscdsinstrMbo.getValue("MANUAL"), false);
/*  6739: 7822 */           pluscwodsinstrDataBean.setValue("SQUARED", pluscdsinstrMbo.getValue("SQUARED"), false);
/*  6740: 7823 */           pluscwodsinstrDataBean.setValue("CLIPLIMITSIN", pluscdsinstrMbo.getValue("CLIPLIMITSIN"), false);
/*  6741:      */           
/*  6742:      */ 
/*  6743:      */ 
/*  6744:      */ 
/*  6745:      */ 
/*  6746:      */ 
/*  6747:      */ 
/*  6748:      */ 
/*  6749: 7832 */           pluscwodsinstrDataBean.setValue("CONFIDLEVEL", pluscdsinstrMbo.getValue("CONFIDLEVEL"), false);
/*  6750: 7833 */           pluscwodsinstrDataBean.setValue("GBFROM1", pluscdsinstrMbo.getValue("GBFROM1"), false);
/*  6751: 7834 */           pluscwodsinstrDataBean.setValue("GBFROM2", pluscdsinstrMbo.getValue("GBFROM2"), false);
/*  6752: 7835 */           pluscwodsinstrDataBean.setValue("GBFROM3", pluscdsinstrMbo.getValue("GBFROM3"), false);
/*  6753: 7836 */           pluscwodsinstrDataBean.setValue("GBFROM4", pluscdsinstrMbo.getValue("GBFROM4"), false);
/*  6754: 7837 */           pluscwodsinstrDataBean.setValue("GBMETHOD", pluscdsinstrMbo.getValue("GBMETHOD"), false);
/*  6755: 7838 */           pluscwodsinstrDataBean.setValue("GBSUMDIRECTION1", pluscdsinstrMbo.getValue("GBSUMDIRECTION1"), false);
/*  6756: 7839 */           pluscwodsinstrDataBean.setValue("GBSUMDIRECTION2", pluscdsinstrMbo.getValue("GBSUMDIRECTION2"), false);
/*  6757: 7840 */           pluscwodsinstrDataBean.setValue("GBSUMDIRECTION3", pluscdsinstrMbo.getValue("GBSUMDIRECTION2"), false);
/*  6758: 7841 */           pluscwodsinstrDataBean.setValue("GBSUMDIRECTION4", pluscdsinstrMbo.getValue("GBSUMDIRECTION3"), false);
/*  6759: 7842 */           pluscwodsinstrDataBean.setValue("GBTO1", pluscdsinstrMbo.getValue("GBTO1"), false);
/*  6760: 7843 */           pluscwodsinstrDataBean.setValue("GBTO2", pluscdsinstrMbo.getValue("GBTO2"), false);
/*  6761: 7844 */           pluscwodsinstrDataBean.setValue("GBTO3", pluscdsinstrMbo.getValue("GBTO3"), false);
/*  6762: 7845 */           pluscwodsinstrDataBean.setValue("GBTO4", pluscdsinstrMbo.getValue("GBTO4"), false);
/*  6763: 7846 */           pluscwodsinstrDataBean.setValue("GUARDBAND", pluscdsinstrMbo.getValue("GUARDBAND"), false);
/*  6764: 7847 */           pluscwodsinstrDataBean.setValue("KFACTOR", pluscdsinstrMbo.getValue("KFACTOR"), false);
/*  6765: 7848 */           pluscwodsinstrDataBean.setValue("UNCERTFREQ", pluscdsinstrMbo.getValue("UNCERTFREQ"), false);
/*  6766: 7849 */           pluscwodsinstrDataBean.setValue("UNCERTUNITS", pluscdsinstrMbo.getValue("UNCERTUNITS"), false);
/*  6767:      */           
/*  6768:      */ 
/*  6769:      */ 
/*  6770:      */ 
/*  6771:      */ 
/*  6772: 7855 */           copyInstrToInstr1(pluscwodsDataBean, pluscwodsinstrDataBean);
/*  6773:      */           
/*  6774: 7857 */           iloop++;
/*  6775:      */           
/*  6776:      */ 
/*  6777:      */ 
/*  6778: 7861 */           MobileMboDataBeanManager pointsDBMgr = new MobileMboDataBeanManager("PLUSCDSPOINT");
/*  6779: 7862 */           MobileMboDataBean pluscdsinstrpointsDataBean = pointsDBMgr.getDataBean();
/*  6780: 7863 */           pluscdsinstrpointsDataBean.getQBE().reset();
/*  6781: 7864 */           pluscdsinstrpointsDataBean.getQBE().setQbeExactMatch(true);
/*  6782: 7865 */           pluscdsinstrpointsDataBean.getQBE().setQBE("DSPLANNUM", pluscdsinstrMbo.getValue("DSPLANNUM"));
/*  6783: 7866 */           pluscdsinstrpointsDataBean.getQBE().setQBE("INSTRSEQ", pluscdsinstrMbo.getValue("INSTRSEQ"));
/*  6784: 7867 */           pluscdsinstrpointsDataBean.getQBE().setQBE("REVISIONNUM", pluscdsinstrMbo.getValue("REVISIONNUM"));
/*  6785: 7868 */           pluscdsinstrpointsDataBean.reset();
/*  6786:      */           
/*  6787: 7870 */           MobileMbo dsConfigMbo = plusdsplanDataBean.getDataBean("PLUSCDSCONFIG").getMobileMbo();
/*  6788: 7871 */           long configNumRepeats = dsConfigMbo.getLongValue("REPEATVALUE");
/*  6789:      */           
/*  6790: 7873 */           boolean repeat = pluscwodsinstrDataBean.getValue("REPEATABLE") == "1";
/*  6791:      */           long numRepeats;
/*  6792:      */           long numRepeats;
/*  6793: 7875 */           if (repeat) {
/*  6794: 7876 */             numRepeats = configNumRepeats;
/*  6795:      */           } else {
/*  6796: 7878 */             numRepeats = 1L;
/*  6797:      */           }
/*  6798: 7881 */           if (pluscdsinstrpointsDataBean.count() != 0)
/*  6799:      */           {
/*  6800: 7883 */             MobileMboDataBean pluscwodsinstrpointsDataBean = pluscwodsinstrDataBean.getDataBean("PLUSCWODSPOINT");
/*  6801:      */             
/*  6802: 7885 */             int ploop = 0;
/*  6803:      */             MobileMbo pluscdsinstrpointsMbo;
/*  6804: 7886 */             while ((pluscdsinstrpointsMbo = pluscdsinstrpointsDataBean.getMobileMbo(ploop)) != null)
/*  6805:      */             {
/*  6806: 7889 */               for (int i = 0; i < numRepeats; i++) {
/*  6807: 7890 */                 createWoCalPoint(woMbo, pluscwodsinstrDataBean, pluscdsinstrMbo, pluscwodsinstrpointsDataBean, pluscdsinstrpointsMbo, false);
/*  6808:      */               }
/*  6809: 7896 */               if (repeat) {
/*  6810: 7897 */                 createWoCalPoint(woMbo, pluscwodsinstrDataBean, pluscdsinstrMbo, pluscwodsinstrpointsDataBean, pluscdsinstrpointsMbo, true);
/*  6811:      */               }
/*  6812: 7903 */               ploop++;
/*  6813:      */             }
/*  6814:      */           }
/*  6815:      */         }
/*  6816:      */       }
/*  6817:      */     }
/*  6818: 7910 */     return true;
/*  6819:      */   }
/*  6820:      */   
/*  6821:      */   private void copyInstrToInstr1(MobileMboDataBean pluscwodsDataBean, MobileMboDataBean pluscwodsinstrDataBean)
/*  6822:      */     throws MobileApplicationException
/*  6823:      */   {
/*  6824: 7923 */     MobileMboDataBean pluscwodsinstr1DataBean = pluscwodsDataBean.getDataBean("PLUSCWODSINSTR1");
/*  6825: 7924 */     pluscwodsinstr1DataBean.insert();
/*  6826:      */     
/*  6827: 7926 */     pluscwodsinstr1DataBean.setValue("PLUSCWODSINSTRID", pluscwodsinstrDataBean.getValue("PLUSCWODSINSTRID"));
/*  6828: 7927 */     pluscwodsinstr1DataBean.setValue("ORGID", pluscwodsinstrDataBean.getValue("ORGID"));
/*  6829: 7928 */     pluscwodsinstr1DataBean.setValue("SITEID", pluscwodsinstrDataBean.getValue("SITEID"));
/*  6830: 7929 */     pluscwodsinstr1DataBean.setValue("ASSETFUNCTION", pluscwodsinstrDataBean.getValue("ASSETFUNCTION"));
/*  6831: 7930 */     pluscwodsinstr1DataBean.setValue("PLANTYPE", pluscwodsinstrDataBean.getValue("PLANTYPE"));
/*  6832: 7931 */     pluscwodsinstr1DataBean.setValue("RON1TYPE", pluscwodsinstrDataBean.getValue("RON1TYPE"));
/*  6833: 7932 */     pluscwodsinstr1DataBean.setValue("DSPLANNUM", pluscwodsinstrDataBean.getValue("DSPLANNUM"));
/*  6834: 7933 */     pluscwodsinstr1DataBean.setValue("WONUM", pluscwodsinstrDataBean.getValue("WONUM"));
/*  6835:      */     
/*  6836: 7935 */     pluscwodsinstr1DataBean.setValue("WODSNUM", pluscwodsinstrDataBean.getValue("WODSNUM"));
/*  6837: 7936 */     pluscwodsinstr1DataBean.setValue("REVISIONNUM", pluscwodsinstrDataBean.getValue("REVISIONNUM"));
/*  6838: 7937 */     pluscwodsinstr1DataBean.setValue("INSTRSEQ", pluscwodsinstrDataBean.getValue("INSTRSEQ"));
/*  6839: 7938 */     pluscwodsinstr1DataBean.setValue("DESCRIPTION", pluscwodsinstrDataBean.getValue("DESCRIPTION"));
/*  6840:      */   }
/*  6841:      */   
/*  6842:      */   private void createWoCalPoint(MobileMbo woMbo, MobileMboDataBean pluscwodsinstrDataBean, MobileMbo pluscdsinstrMbo, MobileMboDataBean pluscwodsinstrpointsDataBean, MobileMbo pluscdsinstrpointsMbo, boolean isAverage)
/*  6843:      */     throws MobileApplicationException
/*  6844:      */   {
/*  6845: 7956 */     pluscwodsinstrpointsDataBean.insert();
/*  6846: 7957 */     pluscwodsinstrpointsDataBean.setValue("WONUM", woMbo.getValue("WONUM"), false);
/*  6847:      */     
/*  6848:      */ 
/*  6849: 7960 */     pluscwodsinstrpointsDataBean.setValue("PLUSCWODSPOINTID", "-" + UIUtil.getApplication().getNextAutoNumber(pluscwodsinstrpointsDataBean.getName()));
/*  6850:      */     
/*  6851: 7962 */     pluscwodsinstrpointsDataBean.setValue("WODSNUM", pluscwodsinstrDataBean.getValue("WODSNUM"));
/*  6852:      */     
/*  6853: 7964 */     pluscwodsinstrpointsDataBean.setValue("SITEID", woMbo.getValue("SITEID"), false);
/*  6854: 7965 */     pluscwodsinstrpointsDataBean.setValue("DSPLANNUM", pluscdsinstrpointsMbo.getValue("DSPLANNUM"), false);
/*  6855: 7966 */     pluscwodsinstrpointsDataBean.setValue("INPUTPERCENT", pluscdsinstrpointsMbo.getValue("INPUTPERCENT"), false);
/*  6856: 7967 */     pluscwodsinstrpointsDataBean.setValue("INPUTVALUE", pluscdsinstrpointsMbo.getValue("INPUTVALUE"), false);
/*  6857: 7968 */     pluscwodsinstrpointsDataBean.setValue("INSTRSEQ", pluscdsinstrpointsMbo.getValue("INSTRSEQ"), false);
/*  6858: 7969 */     pluscwodsinstrpointsDataBean.setValue("OUTPUTVALUE", pluscdsinstrpointsMbo.getValue("OUTPUTVALUE"), false);
/*  6859: 7970 */     pluscwodsinstrpointsDataBean.setValue("PLANTYPE", pluscdsinstrpointsMbo.getValue("PLANTYPE"), false);
/*  6860: 7971 */     pluscwodsinstrpointsDataBean.setValue("POINT", pluscdsinstrpointsMbo.getValue("POINT"), false);
/*  6861: 7972 */     pluscwodsinstrpointsDataBean.setValue("POINTDESCRIPTION", pluscdsinstrpointsMbo.getValue("POINTDESCRIPTION"), false);
/*  6862: 7973 */     pluscwodsinstrpointsDataBean.setValue("RON1LOWER", pluscdsinstrpointsMbo.getValue("RON1LOWER"), false);
/*  6863: 7974 */     pluscwodsinstrpointsDataBean.setValue("RON1UPPER", pluscdsinstrpointsMbo.getValue("RON1UPPER"), false);
/*  6864: 7975 */     pluscwodsinstrpointsDataBean.setValue("SETPOINTACTION", pluscdsinstrpointsMbo.getValue("SETPOINTACTION"), false);
/*  6865: 7976 */     pluscwodsinstrpointsDataBean.setValue("SETPOINTVALUE", pluscdsinstrpointsMbo.getValue("SETPOINTVALUE"), false);
/*  6866: 7977 */     pluscwodsinstrpointsDataBean.setValue("DIRECTION", pluscdsinstrpointsMbo.getValue("DIRECTION"), false);
/*  6867: 7978 */     pluscwodsinstrpointsDataBean.setValue("REVISIONNUM", pluscdsinstrpointsMbo.getValue("REVISIONNUM"), false);
/*  6868: 7979 */     pluscwodsinstrpointsDataBean.setValue("ASSETFUNCTION", pluscwodsinstrDataBean.getValue("ASSETFUNCTION"), false);
/*  6869: 7980 */     pluscwodsinstrpointsDataBean.setValue("CALPOINT", pluscwodsinstrDataBean.getValue("CALPOINT"), false);
/*  6870: 7981 */     pluscwodsinstrpointsDataBean.setValue("CALFUNCTION", pluscwodsinstrDataBean.getValue("CALFUNCTION"), false);
/*  6871: 7982 */     pluscwodsinstrpointsDataBean.setValue("CALDYNAMIC", pluscwodsinstrDataBean.getValue("CALDYNAMIC"), false);
/*  6872: 7983 */     pluscwodsinstrpointsDataBean.setValue("ISAVERAGE", isAverage ? "1" : "0", false);
/*  6873: 7985 */     if (pluscwodsinstrDataBean.getValue("PLANTYPE").equalsIgnoreCase("ANALOG"))
/*  6874:      */     {
/*  6875: 7986 */       pluscwodsinstrpointsDataBean.setValue("INSTROUTRANGEEU", pluscdsinstrMbo.getValue("INSTROUTRANGEEU"), false);
/*  6876:      */     }
/*  6877: 7987 */     else if (pluscwodsinstrDataBean.getValue("PLANTYPE").equalsIgnoreCase("DISCRETE"))
/*  6878:      */     {
/*  6879: 7988 */       pluscwodsinstrpointsDataBean.setValue("INSTROUTRANGEEU", "", false);
/*  6880: 7989 */       pluscwodsinstrpointsDataBean.setValue("INSTRCALRANGEEUD", pluscdsinstrMbo.getValue("INSTRCALRANGEEU"), false);
/*  6881:      */     }
/*  6882: 7991 */     pluscwodsinstrpointsDataBean.setValue("INSTRCALRANGEEUA", pluscdsinstrMbo.getValue("INSTRCALRANGEEU"), false);
/*  6883: 7992 */     pluscwodsinstrpointsDataBean.setValue("INSTRASSETEU", pluscdsinstrMbo.getValue("INSTROUTRANGEEU"), false);
/*  6884: 7993 */     pluscwodsinstrpointsDataBean.setValue("PROCESSEU", pluscdsinstrMbo.getValue("PROCESSEU"), false);
/*  6885: 7994 */     pluscwodsinstrpointsDataBean.setValue("ISADDED", "1", false);
/*  6886:      */     
/*  6887:      */ 
/*  6888: 7997 */     pluscwodsinstrpointsDataBean.setValue("SETPOINTADJ", pluscdsinstrpointsMbo.getValue("SETPOINTADJ"), false);
/*  6889: 8000 */     if (pluscdsinstrMbo.getBooleanValue("NONLINEAR"))
/*  6890:      */     {
/*  6891: 8001 */       pluscwodsinstrpointsDataBean.setValue("ASFOUNDINPUT", pluscdsinstrpointsMbo.getValue("INPUTVALUE"), false);
/*  6892: 8002 */       pluscwodsinstrpointsDataBean.setValue("ASLEFTINPUT", pluscdsinstrpointsMbo.getValue("INPUTVALUE"), false);
/*  6893:      */     }
/*  6894: 8009 */     if ((pluscdsinstrMbo.getBooleanValue("MANUAL")) || (pluscdsinstrMbo.getBooleanValue("NONLINEAR"))) {
/*  6895: 8011 */       for (int i = 1; i <= 4; i++)
/*  6896:      */       {
/*  6897: 8013 */         String[] asFoundLeft = { "ASFOUND", "ASLEFT" };
/*  6898: 8014 */         for (int j = 0; j < asFoundLeft.length; j++)
/*  6899:      */         {
/*  6900: 8015 */           String prefix = asFoundLeft[j];
/*  6901:      */           
/*  6902: 8017 */           pluscwodsinstrpointsDataBean.setValue(prefix + "TOL" + i + "LOWER", pluscdsinstrpointsMbo.getValue("TOL" + i + "LOWER"), false);
/*  6903: 8018 */           pluscwodsinstrpointsDataBean.setValue(prefix + "TOL" + i + "UPPER", pluscdsinstrpointsMbo.getValue("TOL" + i + "UPPER"), false);
/*  6904:      */           
/*  6905: 8020 */           pluscwodsinstrpointsDataBean.setValue(prefix + "TOL" + i + "LW_ORIG", pluscdsinstrpointsMbo.getValue("TOL" + i + "LOWER"), false);
/*  6906: 8021 */           pluscwodsinstrpointsDataBean.setValue(prefix + "TOL" + i + "UP_ORIG", pluscdsinstrpointsMbo.getValue("TOL" + i + "UPPER"), false);
/*  6907:      */         }
/*  6908:      */       }
/*  6909:      */     }
/*  6910:      */   }
/*  6911:      */   
/*  6912:      */   public boolean plusccanattachdatasheet(UIEvent event)
/*  6913:      */     throws MobileApplicationException
/*  6914:      */   {
/*  6915: 8037 */     MobileMboDataBean wodatabean = UIUtil.getCurrentScreen().getDataBean().getParentBean();
/*  6916: 8038 */     if ((wodatabean != null) && (wodatabean.getMobileMbo() != null) && (wodatabean.getName().equals("WORKORDER")))
/*  6917:      */     {
/*  6918: 8039 */       boolean bShow = false;
/*  6919:      */       
/*  6920: 8041 */       String status = wodatabean.getValue("STATUS");
/*  6921: 8042 */       String intStatus = pluscGetWoInternalStatus(status, wodatabean);
/*  6922: 8043 */       if ((intStatus.equals("WAPPR")) || (intStatus.equals("WSCH"))) {
/*  6923: 8044 */         bShow = true;
/*  6924:      */       }
/*  6925: 8046 */       ((AbstractMobileControl)event.getCreatingObject()).setVisibility(bShow);
/*  6926:      */     }
/*  6927: 8048 */     return true;
/*  6928:      */   }
/*  6929:      */   
/*  6930:      */   public String pluscGetWoInternalStatus(String externalStatus, MobileMboDataBean woDataBean)
/*  6931:      */     throws MobileApplicationException
/*  6932:      */   {
/*  6933: 8059 */     return ((WOApp)UIUtil.getApplication()).getInternalValue(woDataBean, "WOSTATUS", externalStatus);
/*  6934:      */   }
/*  6935:      */   
/*  6936:      */   public boolean pluscselectstatusvalues(UIEvent event)
/*  6937:      */     throws MobileApplicationException
/*  6938:      */   {
/*  6939: 8072 */     setQbeValues("PLUSDSPLAN_STATUS.STATUS", "VALUE");
/*  6940: 8073 */     UIUtil.getApplication().removeCurrentScreen(true);
/*  6941: 8074 */     return true;
/*  6942:      */   }
/*  6943:      */   
/*  6944:      */   public boolean pluscdscalselectasfoundstatusvalues(UIEvent event)
/*  6945:      */     throws MobileApplicationException
/*  6946:      */   {
/*  6947: 8087 */     setQbeValues("PLUSCWODSINSTR.ASFOUNDCALSTATUS", "VALUE");
/*  6948:      */     
/*  6949: 8089 */     UIUtil.getApplication().removeCurrentScreen(true);
/*  6950: 8090 */     return true;
/*  6951:      */   }
/*  6952:      */   
/*  6953:      */   public boolean pluscdscalselectasleftstatusvalues(UIEvent event)
/*  6954:      */     throws MobileApplicationException
/*  6955:      */   {
/*  6956: 8102 */     setQbeValues("PLUSCWODSINSTR.ASLEFTCALSTATUS", "VALUE");
/*  6957:      */     
/*  6958: 8104 */     UIUtil.getApplication().removeCurrentScreen(true);
/*  6959: 8105 */     return true;
/*  6960:      */   }
/*  6961:      */   
/*  6962:      */   public boolean pluscselectfromengunitvalues(UIEvent event)
/*  6963:      */     throws MobileApplicationException
/*  6964:      */   {
/*  6965: 8117 */     setQbeValues("PLUSCWODSINSTR.INSTRCALRANGEEU", "VALUE");
/*  6966:      */     
/*  6967: 8119 */     UIUtil.getApplication().removeCurrentScreen(true);
/*  6968: 8120 */     return true;
/*  6969:      */   }
/*  6970:      */   
/*  6971:      */   public boolean pluscselecttoengunitvalues(UIEvent event)
/*  6972:      */     throws MobileApplicationException
/*  6973:      */   {
/*  6974: 8133 */     setQbeValues("PLUSCWODSINSTR.INSTROUTRANGEEU", "VALUE");
/*  6975:      */     
/*  6976: 8135 */     UIUtil.getApplication().removeCurrentScreen(true);
/*  6977: 8136 */     return true;
/*  6978:      */   }
/*  6979:      */   
/*  6980:      */   public boolean pluscselectdsplannumvalues(UIEvent event)
/*  6981:      */     throws MobileApplicationException
/*  6982:      */   {
/*  6983: 8148 */     setQbeValues("DSPLANNUM", "DSPLANNUM");
/*  6984:      */     
/*  6985: 8150 */     UIUtil.getApplication().removeCurrentScreen(true);
/*  6986: 8151 */     return true;
/*  6987:      */   }
/*  6988:      */   
/*  6989:      */   private Vector pluscscan4Parents(UIEvent inEvent)
/*  6990:      */     throws MobileApplicationException
/*  6991:      */   {
/*  6992: 8159 */     AbstractMobileControl calledControl = (AbstractMobileControl)inEvent.getCreatingObject();
/*  6993: 8160 */     MobileMboDataBean curDataBean = calledControl.getDataBean();
/*  6994: 8161 */     curDataBean.dataExists(curDataBean.count() - 1);
/*  6995: 8162 */     MobileMboDataBeanManager mgr = new MobileMboDataBeanManager(calledControl.getDataBean().getName());
/*  6996: 8163 */     MobileMboDataBean tempDataBean = mgr.getDataBean();
/*  6997: 8164 */     Vector parentVector = new Vector();
/*  6998: 8165 */     for (int i = 0; i < curDataBean.count(); i++) {
/*  6999: 8166 */       if (curDataBean.setCurrentPosition(i))
/*  7000:      */       {
/*  7001: 8167 */         TreeNodeData beanLocator = null;
/*  7002: 8168 */         if (curDataBean.getMobileMbo().isNull("PARENT"))
/*  7003:      */         {
/*  7004: 8169 */           beanLocator = new TreeNodeData(curDataBean.getCurrentPosition(), curDataBean.getName(), curDataBean.getValue("DSPLANNUM"), true);
/*  7005: 8170 */           beanLocator.setChildDataBean(curDataBean);
/*  7006: 8171 */           beanLocator.setDisplayPanel(calledControl.createDataPanel(calledControl, curDataBean.getValue("DSPLANNUM") + " " + curDataBean.getValue("DESCRIPTION"), null, "plusctree1", curDataBean, beanLocator));
/*  7007:      */           
/*  7008: 8173 */           parentVector.add(beanLocator);
/*  7009:      */         }
/*  7010:      */         else
/*  7011:      */         {
/*  7012: 8175 */           tempDataBean.getQBE().setQBE("DSPLANNUM", curDataBean.getValue("DSPLANNUM"));
/*  7013: 8176 */           tempDataBean.getQBE().setQBE("SITEID", curDataBean.getValue("SITEID"));
/*  7014: 8177 */           tempDataBean.reset();
/*  7015: 8178 */           if (!tempDataBean.dataExists(0))
/*  7016:      */           {
/*  7017: 8179 */             beanLocator = new TreeNodeData(curDataBean.getCurrentPosition(), curDataBean.getName(), curDataBean.getValue("DSPLANNUM"), true);
/*  7018:      */             
/*  7019: 8181 */             beanLocator.setChildDataBean(curDataBean);
/*  7020: 8182 */             beanLocator.setDisplayPanel(calledControl.createDataPanel(calledControl, curDataBean.getValue("DSPLANNUM") + " " + curDataBean.getValue("DESCRIPTION"), null, "plusctree1", curDataBean, beanLocator));
/*  7021:      */             
/*  7022: 8184 */             parentVector.add(beanLocator);
/*  7023:      */           }
/*  7024:      */           else
/*  7025:      */           {
/*  7026: 8186 */             beanLocator = new TreeNodeData(curDataBean.getCurrentPosition(), curDataBean.getName(), curDataBean.getValue("DSPLANNUM") + "" + "", false, true);
/*  7027:      */             
/*  7028: 8188 */             parentVector.add(beanLocator);
/*  7029:      */           }
/*  7030:      */         }
/*  7031:      */       }
/*  7032:      */     }
/*  7033: 8193 */     return parentVector;
/*  7034:      */   }
/*  7035:      */   
/*  7036:      */   private Vector pluscscan4Children(UIEvent inEvent)
/*  7037:      */     throws MobileApplicationException
/*  7038:      */   {
/*  7039: 8205 */     TreeNodeData inTreeNode = (TreeNodeData)inEvent.getValue();
/*  7040: 8206 */     Vector childVector = new Vector();
/*  7041: 8208 */     if (inTreeNode.getType().equalsIgnoreCase("PLUSCWODS"))
/*  7042:      */     {
/*  7043: 8210 */       AbstractMobileControl calledControl = (AbstractMobileControl)inEvent.getCreatingObject();
/*  7044: 8211 */       MobileMboDataBean childDataBean = null;
/*  7045: 8212 */       MobileMboDataBean inDataBean = inTreeNode.getChildDataBean();
/*  7046: 8213 */       if (inDataBean != null) {
/*  7047: 8214 */         inDataBean.setCurrentPosition(inTreeNode.getIndex());
/*  7048:      */       }
/*  7049: 8217 */       childDataBean = inDataBean.getDataBean("PLUSCWODSINSTR");
/*  7050: 8218 */       childDataBean.reset();
/*  7051: 8219 */       childDataBean.dataExists(childDataBean.count() - 1);
/*  7052: 8221 */       for (int i = 0; i < childDataBean.count(); i++)
/*  7053:      */       {
/*  7054: 8222 */         TreeNodeData beanLocator = null;
/*  7055: 8223 */         if (childDataBean.setCurrentPosition(i))
/*  7056:      */         {
/*  7057: 8224 */           beanLocator = new TreeNodeData(childDataBean.getCurrentPosition(), childDataBean.getName(), inDataBean.getValue("DSPLANNUM"), false);
/*  7058:      */           
/*  7059: 8226 */           beanLocator.setChildDataBean(childDataBean);
/*  7060:      */           
/*  7061: 8228 */           beanLocator.setDisplayPanel(calledControl.createDataPanel(calledControl, childDataBean.getValue("ASSETFUNCTION") + " " + childDataBean.getValue("DESCRIPTION"), null, "plusctree2", childDataBean, beanLocator));
/*  7062:      */           
/*  7063:      */ 
/*  7064: 8231 */           childVector.add(beanLocator);
/*  7065:      */         }
/*  7066:      */       }
/*  7067: 8234 */       if (inDataBean != null) {
/*  7068: 8235 */         inDataBean.setCurrentPosition(inTreeNode.getIndex());
/*  7069:      */       }
/*  7070:      */     }
/*  7071: 8238 */     else if (inTreeNode.getType().equalsIgnoreCase("PLUSCWODSINSTR"))
/*  7072:      */     {
/*  7073: 8240 */       AbstractMobileControl calledControl = (AbstractMobileControl)inEvent.getCreatingObject();
/*  7074: 8241 */       MobileMboDataBean childDataBean = null;
/*  7075: 8242 */       MobileMboDataBean inDataBean = inTreeNode.getChildDataBean();
/*  7076: 8243 */       if (inDataBean != null) {
/*  7077: 8244 */         inDataBean.setCurrentPosition(inTreeNode.getIndex());
/*  7078:      */       }
/*  7079: 8250 */       childDataBean = inDataBean.getDataBean("PLUSCWODSPOINT");
/*  7080: 8251 */       childDataBean.getQBE().setQbeExactMatch(true);
/*  7081: 8252 */       childDataBean.getQBE().setQBE("ISAVERAGE", "0");
/*  7082: 8253 */       childDataBean.reset();
/*  7083: 8254 */       childDataBean.dataExists(childDataBean.count() - 1);
/*  7084: 8256 */       for (int i = 0; i < childDataBean.count(); i++)
/*  7085:      */       {
/*  7086: 8257 */         TreeNodeData beanLocator = null;
/*  7087: 8258 */         if (childDataBean.setCurrentPosition(i))
/*  7088:      */         {
/*  7089: 8259 */           beanLocator = new TreeNodeData(childDataBean.getCurrentPosition(), childDataBean.getName(), inDataBean.getValue("DSPLANNUM"), false);
/*  7090:      */           
/*  7091: 8261 */           beanLocator.setChildDataBean(childDataBean);
/*  7092: 8262 */           beanLocator.setHasChildren(false);
/*  7093: 8263 */           beanLocator.setDisplayPanel(calledControl.createDataPanel(calledControl, childDataBean.getValue("POINT") + " " + childDataBean.getValue("POINTDESCRIPTION"), null, "plusctree3", childDataBean, beanLocator));
/*  7094:      */           
/*  7095: 8265 */           childVector.add(beanLocator);
/*  7096:      */         }
/*  7097:      */       }
/*  7098: 8268 */       if (inDataBean != null) {
/*  7099: 8269 */         inDataBean.setCurrentPosition(inTreeNode.getIndex());
/*  7100:      */       }
/*  7101:      */     }
/*  7102: 8274 */     return childVector;
/*  7103:      */   }
/*  7104:      */   
/*  7105:      */   private void pluscscansettreedsdata(UIEvent event)
/*  7106:      */     throws MobileApplicationException
/*  7107:      */   {
/*  7108: 8285 */     TreeNodeData selectedTreeNode = (TreeNodeData)event.getValue();
/*  7109:      */     
/*  7110: 8287 */     MobileMboDataBean curDataBean = selectedTreeNode.getChildDataBean();
/*  7111: 8288 */     curDataBean.setCurrentPosition(selectedTreeNode.getIndex());
/*  7112: 8290 */     if (selectedTreeNode.getType().equals("PLUSCWODSINSTR"))
/*  7113:      */     {
/*  7114: 8291 */       MobileMboDataBean DSParentDataBean = curDataBean.getParentBean();
/*  7115: 8292 */       DSParentDataBean.getDataBean("PLUSCWODSINSTR").setCurrentPosition(selectedTreeNode.getIndex());
/*  7116:      */       
/*  7117:      */ 
/*  7118:      */ 
/*  7119: 8296 */       this.currentWODSIndex = ((int)curDataBean.getMobileMbo().getOwner().getLongValue("PLUSCWODSID"));
/*  7120: 8297 */       this.currentAFIndex = ((int)curDataBean.getMobileMbo().getLongValue("PLUSCWODSINSTRID"));
/*  7121:      */     }
/*  7122: 8298 */     else if (selectedTreeNode.getType().equals("PLUSCWODSPOINT"))
/*  7123:      */     {
/*  7124: 8299 */       MobileMboDataBean DSParentDataBean = curDataBean.getParentBean();
/*  7125: 8300 */       DSParentDataBean.getDataBean("PLUSCWODSPOINT").setCurrentPosition(selectedTreeNode.getIndex());
/*  7126:      */       
/*  7127:      */ 
/*  7128:      */ 
/*  7129:      */ 
/*  7130: 8305 */       this.currentWODSIndex = ((int)curDataBean.getMobileMbo().getOwner().getOwner().getLongValue("PLUSCWODSID"));
/*  7131: 8306 */       this.currentCPIndex = ((int)curDataBean.getMobileMbo().getLongValue("PLUSCWODSPOINTID"));
/*  7132: 8307 */       this.currentAFIndex = ((int)curDataBean.getMobileMbo().getOwner().getLongValue("PLUSCWODSINSTRID"));
/*  7133:      */     }
/*  7134: 8308 */     else if (selectedTreeNode.getType().equals("PLUSCWODS"))
/*  7135:      */     {
/*  7136: 8310 */       this.currentWODSIndex = ((int)curDataBean.getMobileMbo().getLongValue("PLUSCWODSID"));
/*  7137:      */     }
/*  7138: 8314 */     MobileMboDataBean plancWoDsDataBean = DataBeanCache.getDataBean("PLUSCWODS", "PLUSCWODS");
/*  7139: 8315 */     setWODsPosition(plancWoDsDataBean);
/*  7140:      */     
/*  7141: 8317 */     MobileMboDataBean plancWoDsInstDataBean = DataBeanCache.getDataBean("PLUSCWODSINSTR", "PLUSCWODSINSTR");
/*  7142: 8318 */     setInstrPosition(plancWoDsInstDataBean);
/*  7143:      */     
/*  7144: 8320 */     MobileMboDataBean plancWoDsPointDataBean = DataBeanCache.getDataBean("PLUSCWODSPOINT", "PLUSCWODSPOINT");
/*  7145: 8321 */     setPointPosition(plancWoDsPointDataBean);
/*  7146:      */   }
/*  7147:      */   
/*  7148:      */   private void setWODsPosition(MobileMboDataBean woDsDataBean)
/*  7149:      */     throws MobileApplicationException
/*  7150:      */   {
/*  7151: 8327 */     for (int i = 0; i < woDsDataBean.count(); i++)
/*  7152:      */     {
/*  7153: 8328 */       MobileMbo current = woDsDataBean.getMobileMbo(i);
/*  7154: 8329 */       if (current.getLongValue("PLUSCWODSID") == this.currentWODSIndex)
/*  7155:      */       {
/*  7156: 8330 */         woDsDataBean.setCurrentPosition(i);
/*  7157: 8331 */         return;
/*  7158:      */       }
/*  7159:      */     }
/*  7160: 8334 */     woDsDataBean.setCurrentPosition(0);
/*  7161:      */   }
/*  7162:      */   
/*  7163:      */   public boolean pluscselectwoengunitvalues(UIEvent event)
/*  7164:      */     throws MobileApplicationException
/*  7165:      */   {
/*  7166: 8347 */     setQbeValues("PLUSCFREQUNIT", "VALUE");
/*  7167:      */     
/*  7168: 8349 */     UIUtil.getApplication().removeCurrentScreen(true);
/*  7169: 8350 */     return true;
/*  7170:      */   }
/*  7171:      */   
/*  7172:      */   private void setInstrPosition(MobileMboDataBean instrDataBean)
/*  7173:      */     throws MobileApplicationException
/*  7174:      */   {
/*  7175: 8355 */     for (int i = 0; i < instrDataBean.count(); i++)
/*  7176:      */     {
/*  7177: 8356 */       MobileMbo current = instrDataBean.getMobileMbo(i);
/*  7178: 8357 */       if (current.getLongValue("PLUSCWODSINSTRID") == this.currentAFIndex)
/*  7179:      */       {
/*  7180: 8358 */         instrDataBean.setCurrentPosition(i);
/*  7181: 8359 */         return;
/*  7182:      */       }
/*  7183:      */     }
/*  7184: 8362 */     instrDataBean.setCurrentPosition(0);
/*  7185:      */   }
/*  7186:      */   
/*  7187:      */   private void setPointPosition(MobileMboDataBean pointDataBean)
/*  7188:      */     throws MobileApplicationException
/*  7189:      */   {
/*  7190: 8367 */     for (int i = 0; i < pointDataBean.count(); i++)
/*  7191:      */     {
/*  7192: 8368 */       MobileMbo current = pointDataBean.getMobileMbo(i);
/*  7193: 8369 */       if (current.getLongValue("PLUSCWODSPOINTID") == this.currentCPIndex)
/*  7194:      */       {
/*  7195: 8370 */         pointDataBean.setCurrentPosition(i);
/*  7196: 8371 */         return;
/*  7197:      */       }
/*  7198:      */     }
/*  7199: 8374 */     pointDataBean.setCurrentPosition(0);
/*  7200:      */   }
/*  7201:      */   
/*  7202:      */   public boolean pluscselectwodsplannum(UIEvent event)
/*  7203:      */     throws MobileApplicationException
/*  7204:      */   {
/*  7205: 8387 */     setQbeValues("PLUSCPLUSCWODS.DSPLANNUM", "DSPLANNUM");
/*  7206:      */     
/*  7207: 8389 */     UIUtil.getApplication().removeCurrentScreen(true);
/*  7208: 8390 */     return true;
/*  7209:      */   }
/*  7210:      */   
/*  7211:      */   public boolean pluscselectafnumvalues(UIEvent event)
/*  7212:      */     throws MobileApplicationException
/*  7213:      */   {
/*  7214: 8404 */     setQbeValues("ASSETFUNCTION", "ASSETFUNCTION");
/*  7215:      */     
/*  7216: 8406 */     UIUtil.getApplication().removeCurrentScreen(true);
/*  7217: 8407 */     return true;
/*  7218:      */   }
/*  7219:      */   
/*  7220:      */   public boolean pluscdsafcalselectasfoundstatusvalues(UIEvent event)
/*  7221:      */     throws MobileApplicationException
/*  7222:      */   {
/*  7223: 8421 */     setQbeValues("ASFOUNDCALSTATUS", "VALUE");
/*  7224: 8422 */     UIUtil.getApplication().removeCurrentScreen(true);
/*  7225: 8423 */     return true;
/*  7226:      */   }
/*  7227:      */   
/*  7228:      */   public boolean pluscdsafcalselectasleftstatusvalues(UIEvent event)
/*  7229:      */     throws MobileApplicationException
/*  7230:      */   {
/*  7231: 8437 */     setQbeValues("ASLEFTCALSTATUS", "VALUE");
/*  7232: 8438 */     UIUtil.getApplication().removeCurrentScreen(true);
/*  7233: 8439 */     return true;
/*  7234:      */   }
/*  7235:      */   
/*  7236:      */   public boolean pluscsetpointactionvalues(UIEvent event)
/*  7237:      */     throws MobileApplicationException
/*  7238:      */   {
/*  7239: 8451 */     setQbeValues("SETPOINTACTION", "VALUE");
/*  7240: 8452 */     UIUtil.getApplication().removeCurrentScreen(true);
/*  7241: 8453 */     return true;
/*  7242:      */   }
/*  7243:      */   
/*  7244:      */   public boolean pluscafselectfromengunitvalues(UIEvent event)
/*  7245:      */     throws MobileApplicationException
/*  7246:      */   {
/*  7247: 8465 */     setQbeValues("INSTRCALRANGEEU", "VALUE");
/*  7248: 8466 */     UIUtil.getApplication().removeCurrentScreen(true);
/*  7249: 8467 */     return true;
/*  7250:      */   }
/*  7251:      */   
/*  7252:      */   public boolean pluscafselecttoengunitvalues(UIEvent event)
/*  7253:      */     throws MobileApplicationException
/*  7254:      */   {
/*  7255: 8479 */     setQbeValues("INSTROUTRANGEEU", "VALUE");
/*  7256: 8480 */     UIUtil.getApplication().removeCurrentScreen(true);
/*  7257: 8481 */     return true;
/*  7258:      */   }
/*  7259:      */   
/*  7260:      */   public boolean pluscfailrowstyle(UIEvent event)
/*  7261:      */     throws MobileApplicationException
/*  7262:      */   {
/*  7263: 8495 */     setFailDSStatusSet();
/*  7264: 8496 */     setPassDSStatusSet();
/*  7265: 8497 */     String asFoundCalStatus = "";
/*  7266: 8498 */     String asLeftCalStatus = "";
/*  7267:      */     
/*  7268: 8500 */     MobileMboDataBean instrDataBean = DataBeanCache.getDataBean("PLUSCWODSINSTR", "PLUSCWODSINSTR");
/*  7269: 8502 */     if (((AbstractMobileControl)event.getCreatingObject()).getId().equalsIgnoreCase("pluscdsinstrpointsresultstbl")) {
/*  7270: 8503 */       instrDataBean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean().getDataBean("PLUSCWODSPOINTRLT");
/*  7271:      */     }
/*  7272: 8506 */     String passStatus = getDSPassStatus(instrDataBean);
/*  7273: 8507 */     MobileMbo instrMbo = instrDataBean.getMobileMbo(instrDataBean.getCurrentPosition());
/*  7274:      */     
/*  7275: 8509 */     String pluscautostatusMaxVar = ((WOApp)UIUtil.getApplication()).getMaxVar(instrDataBean, "PLUSCAUTOSTATUS");
/*  7276: 8510 */     boolean pluscautostatus = pluscautostatusMaxVar.equalsIgnoreCase("1");
/*  7277: 8512 */     if (pluscautostatus)
/*  7278:      */     {
/*  7279: 8513 */       boolean bTolStatusDefined = false;
/*  7280: 8514 */       boolean bSkipAsFound = false;
/*  7281: 8515 */       boolean bSkipAsLeft = false;
/*  7282: 8516 */       int iAsFoundStatusSet = 0;
/*  7283: 8517 */       int iAsLeftStatusSet = 0;
/*  7284:      */       
/*  7285: 8519 */       String status1 = null;
/*  7286: 8520 */       String status2 = null;
/*  7287: 8521 */       String status3 = null;
/*  7288: 8522 */       String status4 = null;
/*  7289: 8524 */       if (!instrMbo.isNull("TOL1STATUS"))
/*  7290:      */       {
/*  7291: 8526 */         bTolStatusDefined = true;
/*  7292:      */         
/*  7293: 8528 */         boolean bCheckTol1 = !instrMbo.isNull("TOL1STATUS");
/*  7294: 8529 */         boolean bCheckTol2 = !instrMbo.isNull("TOL2STATUS");
/*  7295: 8530 */         boolean bCheckTol3 = !instrMbo.isNull("TOL3STATUS");
/*  7296: 8531 */         boolean bCheckTol4 = !instrMbo.isNull("TOL4STATUS");
/*  7297:      */         
/*  7298: 8533 */         status1 = instrMbo.getValue("TOL1STATUS");
/*  7299: 8534 */         status2 = instrMbo.getValue("TOL2STATUS");
/*  7300: 8535 */         status3 = instrMbo.getValue("TOL3STATUS");
/*  7301: 8536 */         status4 = instrMbo.getValue("TOL4STATUS");
/*  7302:      */         
/*  7303:      */ 
/*  7304:      */ 
/*  7305:      */ 
/*  7306:      */ 
/*  7307:      */ 
/*  7308:      */ 
/*  7309:      */ 
/*  7310:      */ 
/*  7311: 8546 */         MobileMbo pointMbo = null;
/*  7312: 8547 */         MobileMboDataBean pointDataBean = null;
/*  7313: 8548 */         pointDataBean = instrDataBean.getDataBean("PLUSCWODSPOINT");
/*  7314:      */         
/*  7315: 8550 */         pointDataBean.reset();
/*  7316: 8551 */         int iloop = 0;
/*  7317: 8552 */         while (((pointMbo = pointDataBean.getMobileMbo(iloop)) != null) && ((!bSkipAsFound) || (!bSkipAsLeft)))
/*  7318:      */         {
/*  7319: 8553 */           if (!bSkipAsFound)
/*  7320:      */           {
/*  7321: 8556 */             if ((bCheckTol1) && (pointMbo.isNull("ASFOUNDERROR1"))) {
/*  7322: 8557 */               bSkipAsFound = true;
/*  7323:      */             }
/*  7324: 8558 */             if ((bCheckTol2) && (pointMbo.isNull("ASFOUNDERROR2"))) {
/*  7325: 8559 */               bSkipAsFound = true;
/*  7326:      */             }
/*  7327: 8560 */             if ((bCheckTol3) && (pointMbo.isNull("ASFOUNDERROR3"))) {
/*  7328: 8561 */               bSkipAsFound = true;
/*  7329:      */             }
/*  7330: 8562 */             if ((bCheckTol4) && (pointMbo.isNull("ASFOUNDERROR4"))) {
/*  7331: 8563 */               bSkipAsFound = true;
/*  7332:      */             }
/*  7333:      */           }
/*  7334: 8566 */           if (!bSkipAsLeft)
/*  7335:      */           {
/*  7336: 8569 */             if ((bCheckTol1) && (pointMbo.isNull("ASLEFTERROR1"))) {
/*  7337: 8570 */               bSkipAsLeft = true;
/*  7338:      */             }
/*  7339: 8571 */             if ((bCheckTol2) && (pointMbo.isNull("ASLEFTERROR2"))) {
/*  7340: 8572 */               bSkipAsLeft = true;
/*  7341:      */             }
/*  7342: 8573 */             if ((bCheckTol3) && (pointMbo.isNull("ASLEFTERROR3"))) {
/*  7343: 8574 */               bSkipAsLeft = true;
/*  7344:      */             }
/*  7345: 8575 */             if ((bCheckTol4) && (pointMbo.isNull("ASLEFTERROR4"))) {
/*  7346: 8576 */               bSkipAsLeft = true;
/*  7347:      */             }
/*  7348:      */           }
/*  7349: 8579 */           if ((bSkipAsFound) && (bSkipAsLeft))
/*  7350:      */           {
/*  7351: 8580 */             iloop++;
/*  7352:      */           }
/*  7353:      */           else
/*  7354:      */           {
/*  7355: 8584 */             if (!bSkipAsFound)
/*  7356:      */             {
/*  7357: 8588 */               if ((bCheckTol1) && (iAsFoundStatusSet < 1) && (PlusCToolKitTOCommon.getDouble(pointMbo.getValue("ASFOUNDERROR1"), Locale.US) != 0.0D)) {
/*  7358: 8589 */                 iAsFoundStatusSet = 1;
/*  7359:      */               }
/*  7360: 8590 */               if ((bCheckTol2) && (iAsFoundStatusSet < 2) && (PlusCToolKitTOCommon.getDouble(pointMbo.getValue("ASFOUNDERROR2"), Locale.US) != 0.0D)) {
/*  7361: 8591 */                 iAsFoundStatusSet = 2;
/*  7362:      */               }
/*  7363: 8592 */               if ((bCheckTol3) && (iAsFoundStatusSet < 3) && (PlusCToolKitTOCommon.getDouble(pointMbo.getValue("ASFOUNDERROR3"), Locale.US) != 0.0D)) {
/*  7364: 8593 */                 iAsFoundStatusSet = 3;
/*  7365:      */               }
/*  7366: 8594 */               if ((bCheckTol4) && (iAsFoundStatusSet < 4) && (PlusCToolKitTOCommon.getDouble(pointMbo.getValue("ASFOUNDERROR4"), Locale.US) != 0.0D)) {
/*  7367: 8595 */                 iAsFoundStatusSet = 4;
/*  7368:      */               }
/*  7369:      */             }
/*  7370: 8598 */             if (!bSkipAsLeft)
/*  7371:      */             {
/*  7372: 8601 */               if ((bCheckTol1) && (iAsLeftStatusSet < 1) && (PlusCToolKitTOCommon.getDouble(pointMbo.getValue("ASLEFTERROR1"), Locale.US) != 0.0D)) {
/*  7373: 8602 */                 iAsLeftStatusSet = 1;
/*  7374:      */               }
/*  7375: 8603 */               if ((bCheckTol2) && (iAsLeftStatusSet < 2) && (PlusCToolKitTOCommon.getDouble(pointMbo.getValue("ASLEFTERROR2"), Locale.US) != 0.0D)) {
/*  7376: 8604 */                 iAsLeftStatusSet = 2;
/*  7377:      */               }
/*  7378: 8605 */               if ((bCheckTol3) && (iAsLeftStatusSet < 3) && (PlusCToolKitTOCommon.getDouble(pointMbo.getValue("ASLEFTERROR3"), Locale.US) != 0.0D)) {
/*  7379: 8606 */                 iAsLeftStatusSet = 3;
/*  7380:      */               }
/*  7381: 8607 */               if ((bCheckTol4) && (iAsLeftStatusSet < 4) && (PlusCToolKitTOCommon.getDouble(pointMbo.getValue("ASLEFTERROR4"), Locale.US) != 0.0D)) {
/*  7382: 8608 */                 iAsLeftStatusSet = 4;
/*  7383:      */               }
/*  7384:      */             }
/*  7385: 8610 */             iloop++;
/*  7386:      */           }
/*  7387:      */         }
/*  7388:      */       }
/*  7389: 8616 */       if ((bTolStatusDefined) && ((!bSkipAsFound) || (!bSkipAsLeft)))
/*  7390:      */       {
/*  7391: 8617 */         if (!bSkipAsFound) {
/*  7392: 8618 */           if (iAsFoundStatusSet == 1) {
/*  7393: 8619 */             instrMbo.setValue("ASFOUNDCALSTATUS", status1, false);
/*  7394: 8620 */           } else if (iAsFoundStatusSet == 2) {
/*  7395: 8621 */             instrMbo.setValue("ASFOUNDCALSTATUS", status2, false);
/*  7396: 8622 */           } else if (iAsFoundStatusSet == 3) {
/*  7397: 8623 */             instrMbo.setValue("ASFOUNDCALSTATUS", status3, false);
/*  7398: 8624 */           } else if (iAsFoundStatusSet == 4) {
/*  7399: 8625 */             instrMbo.setValue("ASFOUNDCALSTATUS", status4, false);
/*  7400:      */           } else {
/*  7401: 8627 */             instrMbo.setValue("ASFOUNDCALSTATUS", passStatus, false);
/*  7402:      */           }
/*  7403:      */         }
/*  7404: 8630 */         if (!bSkipAsLeft) {
/*  7405: 8631 */           if (iAsLeftStatusSet == 1) {
/*  7406: 8632 */             instrMbo.setValue("ASLEFTCALSTATUS", status1, false);
/*  7407: 8633 */           } else if (iAsLeftStatusSet == 2) {
/*  7408: 8634 */             instrMbo.setValue("ASLEFTCALSTATUS", status2, false);
/*  7409: 8635 */           } else if (iAsLeftStatusSet == 3) {
/*  7410: 8636 */             instrMbo.setValue("ASLEFTCALSTATUS", status3, false);
/*  7411: 8637 */           } else if (iAsLeftStatusSet == 4) {
/*  7412: 8638 */             instrMbo.setValue("ASLEFTCALSTATUS", status4, false);
/*  7413:      */           } else {
/*  7414: 8640 */             instrMbo.setValue("ASLEFTCALSTATUS", passStatus, false);
/*  7415:      */           }
/*  7416:      */         }
/*  7417:      */       }
/*  7418:      */     }
/*  7419: 8646 */     asFoundCalStatus = pluscgetinstrstatus(instrDataBean, instrMbo, "ASFOUNDCALSTATUS");
/*  7420: 8647 */     asLeftCalStatus = pluscgetinstrstatus(instrDataBean, instrMbo, "ASLEFTCALSTATUS");
/*  7421:      */     
/*  7422:      */ 
/*  7423: 8650 */     int foundLeft = this.failDSStatusSet.contains(asLeftCalStatus) ? 3 : this.failDSStatusSet.contains(asFoundCalStatus) ? 1 : this.failDSStatusSet.contains(asLeftCalStatus) ? 2 : 0;
/*  7424: 8653 */     switch (foundLeft)
/*  7425:      */     {
/*  7426:      */     case 1: 
/*  7427: 8655 */       event.setValue(StyleManager.getStyle("rowincomplete.table", null));
/*  7428: 8656 */       break;
/*  7429:      */     case 3: 
/*  7430: 8658 */       event.setValue(StyleManager.getStyle("rowincomplete.table", null));
/*  7431: 8659 */       break;
/*  7432:      */     case 2: 
/*  7433: 8661 */       event.setValue(StyleManager.getStyle("rowincomplete.table", null));
/*  7434: 8662 */       break;
/*  7435:      */     case 0: 
/*  7436: 8677 */       if (instrMbo.isModified()) {
/*  7437: 8678 */         event.setValue(StyleManager.getStyle("rowmodified.table", null));
/*  7438:      */       } else {
/*  7439: 8680 */         event.setValue(StyleManager.getDefaultStyle());
/*  7440:      */       }
/*  7441: 8682 */       break;
/*  7442:      */     }
/*  7443: 8687 */     return true;
/*  7444:      */   }
/*  7445:      */   
/*  7446:      */   public boolean pluscfailtextstyle(UIEvent event)
/*  7447:      */     throws MobileApplicationException
/*  7448:      */   {
/*  7449: 8703 */     pluscdspckenterdsdata(event);
/*  7450:      */     
/*  7451: 8705 */     TextboxControl thisControl = (TextboxControl)event.getCreatingObject();
/*  7452: 8706 */     ControlData data = thisControl.getControlData();
/*  7453: 8707 */     String dataAttribute = data.getValue("dataattribute");
/*  7454:      */     
/*  7455: 8709 */     String calStatus = pluscgetcalstatus(dataAttribute);
/*  7456: 8711 */     if (calStatus.equals("FAIL")) {
/*  7457: 8712 */       thisControl.setTextFontColor(StyleManager.getStyle("rowincomplete.table", null).getFgColor());
/*  7458:      */     }
/*  7459: 8715 */     return false;
/*  7460:      */   }
/*  7461:      */   
/*  7462:      */   public boolean pluscselectcpnumvalues(UIEvent event)
/*  7463:      */     throws MobileApplicationException
/*  7464:      */   {
/*  7465: 8728 */     setQbeValues("POINT", "POINT");
/*  7466: 8729 */     UIUtil.getApplication().removeCurrentScreen(true);
/*  7467: 8730 */     return true;
/*  7468:      */   }
/*  7469:      */   
/*  7470:      */   private boolean calculateValues(UIEvent event)
/*  7471:      */     throws MobileApplicationException
/*  7472:      */   {
/*  7473: 8745 */     System.out.println("######### CALCULATE #########");
/*  7474: 8746 */     MobileMboDataBean pointDatabean = UIUtil.getCurrentScreen().getDataBean();
/*  7475: 8747 */     MobileMbo currentMobileMbo = getCurrentMobileMbo();
/*  7476: 8748 */     MobileMbo instr = pluscgetinstrmboforpoint(currentMobileMbo);
/*  7477: 8749 */     TextboxControl eventSource = (TextboxControl)event.getCreatingObject();
/*  7478: 8750 */     String fieldName = eventSource.getControlData().getValue("dataattribute");
/*  7479:      */     
/*  7480:      */ 
/*  7481:      */ 
/*  7482:      */ 
/*  7483:      */ 
/*  7484:      */ 
/*  7485: 8757 */     String prefix = fieldName.startsWith("ASFOUND") ? "ASFOUND" : "ASLEFT";
/*  7486: 8763 */     if (pluscValidateNumber(event, eventSource.getControlValue()))
/*  7487:      */     {
/*  7488: 8766 */       setMboValueFromEvent(event, currentMobileMbo);
/*  7489: 8774 */       if (fieldName.endsWith("SETPOINT"))
/*  7490:      */       {
/*  7491: 8775 */         int inputmfr = 0;
/*  7492: 8776 */         if ((instr.getValue("INPUTPRECISION") != null) && (!instr.getValue("INPUTPRECISION").equalsIgnoreCase(""))) {
/*  7493: 8777 */           inputmfr = Integer.parseInt(instr.getValue("INPUTPRECISION"));
/*  7494:      */         }
/*  7495: 8779 */         currentMobileMbo.setValue(fieldName, PlusCToolKitTOCommon.formatDouble(fieldName, (String)event.getValue(), inputmfr, Locale.getDefault()));
/*  7496:      */       }
/*  7497: 8783 */       PlusCDSCalculation calc = buildPlusCDSCalculation(currentMobileMbo.getValue("dsplannum"));
/*  7498: 8784 */       PlusCMboRemote currentCopy = convertMboToPlusCMbo(currentMobileMbo, event);
/*  7499: 8786 */       if (isRepeatGroupElement(currentMobileMbo, instr))
/*  7500:      */       {
/*  7501: 8787 */         currentMobileMbo = doCalculateAveragesAndStdDevs(currentMobileMbo, instr, pointDatabean, fieldName, event);
/*  7502: 8788 */         currentCopy = convertMboToPlusCMbo(currentMobileMbo, event);
/*  7503:      */       }
/*  7504: 8791 */       if ((fieldName.startsWith("ASFOUNDINPUT")) || (fieldName.startsWith("ASLEFTINPUT")) || (fieldName.equalsIgnoreCase("OUTPUTVALUE")))
/*  7505:      */       {
/*  7506: 8794 */         if (isInputWithinRange(event, eventSource, currentMobileMbo, instr))
/*  7507:      */         {
/*  7508: 8796 */           updateTolValues(fieldName, currentCopy, instr, calc);
/*  7509: 8799 */           if ((!currentMobileMbo.isNull(prefix + "OUTPUT")) && (!currentMobileMbo.isNull(prefix + "INPUT")))
/*  7510:      */           {
/*  7511: 8800 */             calc.doUpdateErrorValues(currentCopy, prefix, true);
/*  7512:      */           }
/*  7513:      */           else
/*  7514:      */           {
/*  7515: 8802 */             currentMobileMbo.setValue(prefix + "ERROR1", "", false);
/*  7516: 8803 */             currentMobileMbo.setValue(prefix + "ERROR2", "", false);
/*  7517: 8804 */             currentMobileMbo.setValue(prefix + "ERROR3", "", false);
/*  7518: 8805 */             currentMobileMbo.setValue(prefix + "ERROR4", "", false);
/*  7519:      */           }
/*  7520:      */         }
/*  7521:      */       }
/*  7522: 8810 */       else if ((fieldName.equalsIgnoreCase("ASFOUNDOUTPUT")) || (fieldName.equalsIgnoreCase("ASLEFTOUTPUT")))
/*  7523:      */       {
/*  7524: 8813 */         if ((!currentMobileMbo.isNull(prefix + "INPUT")) && (!currentMobileMbo.isNull(prefix + "OUTPUT")))
/*  7525:      */         {
/*  7526: 8815 */           updateTolValues(prefix + "INPUT", currentCopy, instr, calc);
/*  7527: 8816 */           calc.doUpdateErrorValues(currentCopy, prefix, true);
/*  7528:      */         }
/*  7529:      */         else
/*  7530:      */         {
/*  7531: 8819 */           currentMobileMbo.setValue(prefix + "ERROR1", "", false);
/*  7532: 8820 */           currentMobileMbo.setValue(prefix + "ERROR2", "", false);
/*  7533: 8821 */           currentMobileMbo.setValue(prefix + "ERROR3", "", false);
/*  7534: 8822 */           currentMobileMbo.setValue(prefix + "ERROR4", "", false);
/*  7535:      */         }
/*  7536:      */       }
/*  7537: 8828 */       else if (fieldName.endsWith("SETPOINT"))
/*  7538:      */       {
/*  7539: 8830 */         updateTolValues(prefix + "SETPOINT", currentCopy, instr, calc);
/*  7540: 8831 */         calc.doUpdateErrorValues(currentCopy, prefix, true);
/*  7541:      */       }
/*  7542: 8835 */       convertPlusCMboToMbo(currentMobileMbo, currentCopy);
/*  7543:      */       
/*  7544:      */ 
/*  7545: 8838 */       UIUtil.getApplication().updateMobileMbo("PLUSCWODSPOINT", currentMobileMbo);
/*  7546:      */     }
/*  7547: 8841 */     UIUtil.refreshCurrentScreen();
/*  7548:      */     
/*  7549: 8843 */     return pluscshowexceededmessage(currentMobileMbo, event, fieldName);
/*  7550:      */   }
/*  7551:      */   
/*  7552:      */   private boolean afterUpdateMeasuredValues(UIEvent event)
/*  7553:      */     throws MobileApplicationException
/*  7554:      */   {
/*  7555: 8850 */     boolean retval = true;
/*  7556: 8851 */     boolean warnMaxWar = false;
/*  7557:      */     
/*  7558:      */ 
/*  7559:      */ 
/*  7560: 8855 */     String response = event.getMsgResponse();
/*  7561: 8856 */     if (response.equals("-1")) {
/*  7562: 8857 */       warnMaxWar = isShowingWarnChangeMeasuredValue(event);
/*  7563:      */     }
/*  7564: 8859 */     if ((response.equals("1")) || (!warnMaxWar))
/*  7565:      */     {
/*  7566: 8860 */       retval = calculateValues(event);
/*  7567:      */       
/*  7568: 8862 */       updateDsRequiredFlag(event);
/*  7569:      */     }
/*  7570: 8868 */     return retval;
/*  7571:      */   }
/*  7572:      */   
/*  7573:      */   private boolean isShowingWarnChangeMeasuredValue(UIEvent event)
/*  7574:      */     throws MobileApplicationException
/*  7575:      */   {
/*  7576: 8873 */     MobileMboDataBean pointDatabean = UIUtil.getCurrentScreen().getDataBean();
/*  7577: 8874 */     MobileMbo pointMbo = getCurrentMobileMbo();
/*  7578: 8875 */     MobileMboDataBean instrDataBean = pluscgetinstrbeanforpoint(pointMbo);
/*  7579: 8876 */     MobileMbo instrMbo = instrDataBean.getMobileMbo();
/*  7580:      */     
/*  7581: 8878 */     PlusCWODsInstrDelegate instr = new PlusCMobileWODsInstrDelegate(new MobileMboAdapter(instrMbo, instrDataBean));
/*  7582:      */     
/*  7583: 8880 */     PlusCWODsPointDelegate point = new PlusCMobileWODsPointDelegate(new MobileMboAdapter(pointMbo, pointDatabean), instr);
/*  7584:      */     try
/*  7585:      */     {
/*  7586: 8884 */       TextboxControl eventSource = (TextboxControl)event.getCreatingObject();
/*  7587: 8885 */       String fieldName = eventSource.getControlData().getValue("dataattribute");
/*  7588: 8886 */       if (point.warnChangeMeasuredValue(fieldName, pointMbo.getValue(fieldName), (String)event.getValue()))
/*  7589:      */       {
/*  7590: 8891 */         String msg = MobileMessageGenerator.generate("pluscwt_DataAlreadyEntered", null);
/*  7591:      */         
/*  7592: 8893 */         UIUtil.showMessageBox(msg, "question", 1, event);
/*  7593:      */         
/*  7594:      */ 
/*  7595: 8896 */         return true;
/*  7596:      */       }
/*  7597:      */     }
/*  7598:      */     catch (Exception e)
/*  7599:      */     {
/*  7600: 8900 */       MobileMboAdapter.wrapException(e);
/*  7601:      */     }
/*  7602: 8901 */     return false;
/*  7603:      */   }
/*  7604:      */   
/*  7605:      */   public void setFailDSStatusSet()
/*  7606:      */   {
/*  7607: 8911 */     this.failDSStatusSet = new HashSet();
/*  7608: 8912 */     this.failDSStatusSet.add("BROKEN");
/*  7609: 8913 */     this.failDSStatusSet.add("MISSING");
/*  7610: 8914 */     this.failDSStatusSet.add("OLIM");
/*  7611: 8915 */     this.failDSStatusSet.add("FAIL");
/*  7612:      */   }
/*  7613:      */   
/*  7614:      */   public void setPassDSStatusSet()
/*  7615:      */   {
/*  7616: 8924 */     this.passDSStatusSet = new HashSet();
/*  7617: 8925 */     this.passDSStatusSet.add("PASS");
/*  7618:      */   }
/*  7619:      */   
/*  7620:      */   public void setDSRowStatus(HashMap afMap, HashMap alMap, MobileMboDataBean wodsDataBean, MobileMbo wodsMbo)
/*  7621:      */     throws MobileApplicationException
/*  7622:      */   {
/*  7623: 8947 */     HashMap localAFMap = new HashMap();
/*  7624: 8948 */     HashMap localALMap = new HashMap();
/*  7625:      */     
/*  7626:      */ 
/*  7627: 8951 */     setFailDSStatusSet();
/*  7628: 8952 */     setPassDSStatusSet();
/*  7629:      */     
/*  7630: 8954 */     setFailSynonymDSStatusSet();
/*  7631: 8955 */     String asFoundCalStatus = "";
/*  7632: 8956 */     String asLeftCalStatus = "";
/*  7633:      */     
/*  7634:      */ 
/*  7635:      */ 
/*  7636:      */ 
/*  7637:      */ 
/*  7638: 8962 */     wodsDataBean = wodsDataBean != null ? wodsDataBean : DataBeanCache.getDataBean("PLUSCWODS", "PLUSCWODS");
/*  7639: 8964 */     if (wodsMbo == null) {
/*  7640: 8965 */       wodsMbo = wodsDataBean.getMobileMbo(wodsDataBean.getCurrentPosition());
/*  7641:      */     }
/*  7642: 8974 */     localAFMap = afMap == null ? new HashMap() : afMap;
/*  7643: 8975 */     localALMap = alMap == null ? new HashMap() : alMap;
/*  7644: 8976 */     boolean bSkipAsFound = afMap == null;
/*  7645: 8977 */     boolean bSkipAsLeft = alMap == null;
/*  7646: 8978 */     Iterator afIt = localAFMap.keySet().iterator();
/*  7647: 8979 */     Iterator alIt = localALMap.keySet().iterator();
/*  7648: 8981 */     if (afMap != null)
/*  7649:      */     {
/*  7650: 8982 */       bSkipAsFound = afMap.containsValue("FAIL");
/*  7651: 8983 */       asFoundCalStatus = (String)afMap.get("FAIL");
/*  7652:      */     }
/*  7653: 8986 */     if (alMap != null)
/*  7654:      */     {
/*  7655: 8987 */       bSkipAsLeft = alMap.containsValue("FAIL");
/*  7656: 8988 */       asLeftCalStatus = (String)alMap.get("FAIL");
/*  7657:      */     }
/*  7658: 8991 */     while (((afIt.hasNext()) && (!bSkipAsFound)) || ((alIt.hasNext()) && (!bSkipAsLeft)))
/*  7659:      */     {
/*  7660: 8993 */       if ((afIt.hasNext()) && (!bSkipAsFound))
/*  7661:      */       {
/*  7662: 8994 */         asFoundCalStatus = (String)afMap.get(afIt.next());
/*  7663: 8996 */         if (this.failSynonymDSStatusSet.contains(asFoundCalStatus)) {
/*  7664: 8997 */           bSkipAsFound = true;
/*  7665:      */         }
/*  7666:      */       }
/*  7667: 9001 */       if ((alIt.hasNext()) && (!bSkipAsLeft))
/*  7668:      */       {
/*  7669: 9002 */         asLeftCalStatus = (String)alMap.get(alIt.next());
/*  7670: 9004 */         if (this.failSynonymDSStatusSet.contains(asLeftCalStatus)) {
/*  7671: 9005 */           bSkipAsLeft = true;
/*  7672:      */         }
/*  7673:      */       }
/*  7674:      */     }
/*  7675: 9032 */     String asfndStsOrgnlValue = ((WOApp)UIUtil.getApplication()).getInternalValue(wodsDataBean, "PLUSCCALSTATUS", wodsMbo.getValue("ASFOUNDCALSTATUS"));
/*  7676: 9035 */     if (asFoundCalStatus == null) {
/*  7677: 9036 */       asFoundCalStatus = "";
/*  7678:      */     }
/*  7679: 9039 */     if ((asFoundCalStatus.equals("")) && ((asfndStsOrgnlValue.equalsIgnoreCase("BROKEN")) || (asfndStsOrgnlValue.equalsIgnoreCase("MISSING")))) {
/*  7680: 9040 */       asFoundCalStatus = asfndStsOrgnlValue;
/*  7681:      */     }
/*  7682: 9044 */     String aslftStsOrgnlValue = ((WOApp)UIUtil.getApplication()).getInternalValue(wodsDataBean, "PLUSCCALSTATUS", wodsMbo.getValue("ASLEFTCALSTATUS"));
/*  7683: 9050 */     if (asLeftCalStatus == null) {
/*  7684: 9051 */       asLeftCalStatus = "";
/*  7685:      */     }
/*  7686: 9053 */     if ((asLeftCalStatus.equals("")) && ((aslftStsOrgnlValue.equalsIgnoreCase("BROKEN")) || (aslftStsOrgnlValue.equalsIgnoreCase("MISSING")))) {
/*  7687: 9054 */       asLeftCalStatus = aslftStsOrgnlValue;
/*  7688:      */     }
/*  7689: 9057 */     wodsMbo.setValue("ASFOUNDCALSTATUS", asFoundCalStatus, false);
/*  7690: 9058 */     wodsMbo.setValue("ASLEFTCALSTATUS", asLeftCalStatus, false);
/*  7691:      */     
/*  7692: 9060 */     PlusCWODsDelegate woDs = new PlusCMobileWODsDelegate(new MobileMboAdapter(wodsMbo, wodsDataBean));
/*  7693:      */     try
/*  7694:      */     {
/*  7695: 9063 */       woDs.setValueInOptionalLoopPartDSs("ASFOUNDCALSTATUS", asFoundCalStatus, 2L);
/*  7696: 9064 */       woDs.setValueInOptionalLoopPartDSs("ASLEFTCALSTATUS", asLeftCalStatus, 2L);
/*  7697:      */     }
/*  7698:      */     catch (Exception e)
/*  7699:      */     {
/*  7700: 9066 */       MobileMboAdapter.wrapException(e);
/*  7701:      */     }
/*  7702: 9085 */     DataBeanCacheItem item = new DataBeanCacheItem("PLUSCWODS", "PLUSCWODS", wodsDataBean);
/*  7703: 9086 */     DataBeanCache.cacheDataBean("PLUSCWODS", item);
/*  7704:      */   }
/*  7705:      */   
/*  7706:      */   public String getDSFailStatus(MobileMboDataBean baseDataBean)
/*  7707:      */     throws MobileApplicationException
/*  7708:      */   {
/*  7709: 9097 */     return ((WOApp)UIUtil.getApplication()).getDefaultValue(baseDataBean, "PLUSCCALSTATUS", "FAIL");
/*  7710:      */   }
/*  7711:      */   
/*  7712:      */   public String getDSPassStatus(MobileMboDataBean baseDataBean)
/*  7713:      */     throws MobileApplicationException
/*  7714:      */   {
/*  7715: 9108 */     return ((WOApp)UIUtil.getApplication()).getDefaultValue(baseDataBean, "PLUSCCALSTATUS", "PASS");
/*  7716:      */   }
/*  7717:      */   
/*  7718:      */   private MobileMbo getCurrentMobileMbo()
/*  7719:      */     throws MobileApplicationException
/*  7720:      */   {
/*  7721: 9113 */     MobileMboDataBean currentDataBean = UIUtil.getCurrentScreen().getDataBean();
/*  7722: 9114 */     MobileMbo screenMbo = currentDataBean.getMobileMbo();
/*  7723: 9115 */     return screenMbo;
/*  7724:      */   }
/*  7725:      */   
/*  7726:      */   private boolean pluscdspckenterdsdata(UIEvent event)
/*  7727:      */     throws MobileApplicationException
/*  7728:      */   {
/*  7729: 9122 */     MobileMboDataBean woDataBean = pluscgetcurrentwoset();
/*  7730: 9123 */     String woStatus = pluscGetWoInternalStatus(woDataBean.getValue("STATUS"), woDataBean);
/*  7731: 9124 */     if ((event.getCreatingObject() instanceof AbstractMobileControl)) {
/*  7732: 9125 */       if ((!UIUtil.getApplication().isSigOption("PLUSCENTERDS")) || (woStatus.equalsIgnoreCase("WAPPR"))) {
/*  7733: 9126 */         ((AbstractMobileControl)event.getCreatingObject()).setReadonly(true);
/*  7734:      */       } else {
/*  7735: 9129 */         ((AbstractMobileControl)event.getCreatingObject()).setReadonly(false);
/*  7736:      */       }
/*  7737:      */     }
/*  7738: 9133 */     return true;
/*  7739:      */   }
/*  7740:      */   
/*  7741:      */   public MobileMboDataBean pluscgetcurrentwoset()
/*  7742:      */     throws MobileApplicationException
/*  7743:      */   {
/*  7744: 9145 */     MobileMboDataBean woDataBean = DataBeanCache.getDataBean("WORKORDER", "WORKORDER");
/*  7745: 9146 */     return woDataBean;
/*  7746:      */   }
/*  7747:      */   
/*  7748:      */   public String pluscgetcalstatus(String fieldName)
/*  7749:      */     throws MobileApplicationException
/*  7750:      */   {
/*  7751: 9161 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/*  7752: 9162 */     String calStatus = ((WOApp)UIUtil.getApplication()).getInternalValue(databean, "PLUSCCALSTATUS", databean.getValue(fieldName));
/*  7753: 9163 */     return calStatus;
/*  7754:      */   }
/*  7755:      */   
/*  7756:      */   public boolean pluscsetaflabel(UIEvent event)
/*  7757:      */     throws MobileApplicationException
/*  7758:      */   {
/*  7759: 9169 */     String actualPoistion = new Integer(UIUtil.getCurrentScreen().getDataBean().getCurrentPosition()).toString();
/*  7760:      */     
/*  7761: 9171 */     LabelControl label = (LabelControl)event.getCreatingObject();
/*  7762: 9172 */     label.generateLabel(actualPoistion, "", "");
/*  7763: 9173 */     return true;
/*  7764:      */   }
/*  7765:      */   
/*  7766:      */   private void updateDsRequiredFlag(UIEvent event)
/*  7767:      */     throws MobileApplicationException
/*  7768:      */   {
/*  7769: 9179 */     String value = (String)event.getValue();
/*  7770: 9180 */     boolean cleared = (value == null) || (value.equals(""));
/*  7771:      */     
/*  7772: 9182 */     MobileMboDataBean woDsDataBean = DataBeanCache.getDataBean("PLUSCWODS", "PLUSCWODS");
/*  7773: 9183 */     MobileMbo woDsMbo = woDsDataBean.getMobileMbo();
/*  7774: 9184 */     PlusCWODsDelegate woDs = new PlusCMobileWODsDelegate(new MobileMboAdapter(woDsMbo, woDsDataBean));
/*  7775:      */     try
/*  7776:      */     {
/*  7777: 9186 */       woDs.setDSRequiredStatus(cleared);
/*  7778:      */     }
/*  7779:      */     catch (Exception e)
/*  7780:      */     {
/*  7781: 9187 */       MobileMboAdapter.wrapException(e);
/*  7782:      */     }
/*  7783:      */   }
/*  7784:      */   
/*  7785:      */   public MobileMboDataBean pluscgetinstrbeanforpoint(MobileMbo pointMbo)
/*  7786:      */     throws MobileApplicationException
/*  7787:      */   {
/*  7788: 9201 */     return pluscgetcleaninstrdatabean(pointMbo, true);
/*  7789:      */   }
/*  7790:      */   
/*  7791:      */   public MobileMboDataBean pluscgetcleaninstrdatabean(MobileMbo referenceMbo, boolean validateSeq)
/*  7792:      */     throws MobileApplicationException
/*  7793:      */   {
/*  7794: 9216 */     MobileMboDataBeanManager instrmgr = new MobileMboDataBeanManager("PLUSCWODSINSTR");
/*  7795: 9217 */     MobileMboDataBean instrBean = instrmgr.getDataBean();
/*  7796: 9218 */     instrBean.getQBE().reset();
/*  7797: 9219 */     instrBean.getQBE().setQbeExactMatch(true);
/*  7798: 9220 */     instrBean.getQBE().setQBE("DSPLANNUM", referenceMbo.getValue("DSPLANNUM"));
/*  7799: 9221 */     instrBean.getQBE().setQBE("SITEID", referenceMbo.getValue("SITEID"));
/*  7800: 9222 */     instrBean.getQBE().setQBE("REVISIONNUM", referenceMbo.getValue("REVISIONNUM"));
/*  7801: 9223 */     instrBean.getQBE().setQBE("WONUM", referenceMbo.getValue("WONUM"));
/*  7802:      */     
/*  7803: 9225 */     instrBean.getQBE().setQBE("WODSNUM", referenceMbo.getValue("WODSNUM"));
/*  7804: 9226 */     if (validateSeq) {
/*  7805: 9227 */       instrBean.getQBE().setQBE("INSTRSEQ", referenceMbo.getValue("INSTRSEQ"));
/*  7806:      */     }
/*  7807: 9229 */     instrBean.reset();
/*  7808:      */     
/*  7809: 9231 */     return instrBean;
/*  7810:      */   }
/*  7811:      */   
/*  7812:      */   public MobileMbo pluscgetinstrmboforpoint(MobileMbo pointMbo)
/*  7813:      */     throws MobileApplicationException
/*  7814:      */   {
/*  7815: 9245 */     MobileMboDataBean instrDataBean = pluscgetinstrbeanforpoint(pointMbo);
/*  7816: 9246 */     MobileMbo instrMbo = instrDataBean.getMobileMbo();
/*  7817: 9247 */     return instrMbo;
/*  7818:      */   }
/*  7819:      */   
/*  7820:      */   public boolean pluscValidateNumber(UIEvent event, String value)
/*  7821:      */     throws MobileApplicationException
/*  7822:      */   {
/*  7823:      */     try
/*  7824:      */     {
/*  7825: 9263 */       if ((value != null) && (!value.equalsIgnoreCase(""))) {
/*  7826: 9266 */         Double.parseDouble(value.replace(',', '.'));
/*  7827:      */       }
/*  7828:      */     }
/*  7829:      */     catch (NumberFormatException ex)
/*  7830:      */     {
/*  7831: 9271 */       throw new MobileApplicationException("invalidnumber");
/*  7832:      */     }
/*  7833: 9274 */     return true;
/*  7834:      */   }
/*  7835:      */   
/*  7836:      */   public void setFailSynonymDSStatusSet()
/*  7837:      */     throws MobileApplicationException
/*  7838:      */   {
/*  7839: 9285 */     MobileMboDataBeanManager statusmgr = new MobileMboDataBeanManager("PLUSCCALSTATUS");
/*  7840: 9286 */     MobileMboDataBean statusBean = statusmgr.getDataBean();
/*  7841:      */     
/*  7842: 9288 */     this.failSynonymDSStatusSet = new HashSet();
/*  7843:      */     
/*  7844: 9290 */     int i = 0;
/*  7845: 9291 */     MobileMbo statusMbo = null;
/*  7846: 9293 */     while (i < statusBean.count())
/*  7847:      */     {
/*  7848: 9295 */       statusMbo = statusBean.getMobileMbo(i);
/*  7849: 9296 */       String status = statusMbo != null ? statusMbo.getValue("MAXVALUE") : "";
/*  7850: 9297 */       if (!status.equalsIgnoreCase("PASS")) {
/*  7851: 9298 */         this.failSynonymDSStatusSet.add(status);
/*  7852:      */       }
/*  7853: 9300 */       i++;
/*  7854:      */     }
/*  7855:      */   }
/*  7856:      */   
/*  7857:      */   private boolean setAnalogDiscreteReadOnlyField(UIEvent event)
/*  7858:      */     throws MobileApplicationException
/*  7859:      */   {
/*  7860: 9315 */     boolean labelChange = pluscupdatetoolbarlabel(event);
/*  7861:      */     
/*  7862:      */ 
/*  7863:      */ 
/*  7864:      */ 
/*  7865:      */ 
/*  7866: 9321 */     return setPointReadOnlyFields(event);
/*  7867:      */   }
/*  7868:      */   
/*  7869:      */   public boolean pluscupdatetoolbarlabel(UIEvent event)
/*  7870:      */     throws MobileApplicationException
/*  7871:      */   {
/*  7872: 9335 */     AbstractMobileControl thisPage = UIUtil.getCurrentScreen();
/*  7873: 9336 */     MobileMboDataBean databean = thisPage.getDataBean();
/*  7874: 9338 */     if (databean == null) {
/*  7875: 9339 */       databean = DataBeanCache.findDataBean("PLUSCWODS").getDataBean("PLUSCWODSINSTR").getDataBean("PLUSCWODSPOINT");
/*  7876:      */     }
/*  7877: 9342 */     pluscgotonextrecord(databean, thisPage, event);
/*  7878:      */     
/*  7879:      */ 
/*  7880:      */ 
/*  7881:      */ 
/*  7882:      */ 
/*  7883:      */ 
/*  7884: 9349 */     String pageId = ((PageControl)event.getCreatingObject()).getControlData().getValue("id");
/*  7885: 9350 */     if ((!pageId.equalsIgnoreCase("pluscasfoundvaluespage")) && (!pageId.equalsIgnoreCase("pluscasleftvaluespage"))) {
/*  7886: 9351 */       return false;
/*  7887:      */     }
/*  7888: 9354 */     String[] params = { Integer.toString(databean.getCurrentPosition() + 1), Integer.toString(databean.count()) };
/*  7889: 9355 */     String label = MobileMessageGenerator.generate("pluscwt_PageNumber", params);
/*  7890: 9356 */     PageControl pageControl = (PageControl)thisPage;
/*  7891: 9357 */     AbstractMobileControl toolBar = pageControl.getToolBar();
/*  7892: 9358 */     Iterator iterator = toolBar.getChildren();
/*  7893: 9359 */     if (iterator != null) {
/*  7894: 9360 */       while (iterator.hasNext())
/*  7895:      */       {
/*  7896: 9361 */         AbstractMobileControl child = (AbstractMobileControl)iterator.next();
/*  7897: 9362 */         if (child.getId().equalsIgnoreCase("pluscafpgtabletbar_left"))
/*  7898:      */         {
/*  7899: 9363 */           Iterator iterator1 = child.getChildren();
/*  7900: 9364 */           if (iterator1 != null) {
/*  7901: 9365 */             while (iterator1.hasNext())
/*  7902:      */             {
/*  7903: 9366 */               AbstractMobileControl child1 = (AbstractMobileControl)iterator1.next();
/*  7904: 9367 */               if (child1.getId().equalsIgnoreCase("pluscdialogbar_label1"))
/*  7905:      */               {
/*  7906: 9368 */                 AbstractMobileControl ctrl = child1;
/*  7907: 9369 */                 ctrl.getControlData().putValue("label", label);
/*  7908: 9377 */                 if ((ctrl instanceof LabelControl))
/*  7909:      */                 {
/*  7910: 9378 */                   LabelControl labelControl = (LabelControl)ctrl;
/*  7911: 9379 */                   labelControl.setTextValueOnWidget(label);
/*  7912:      */                 }
/*  7913:      */               }
/*  7914:      */             }
/*  7915:      */           }
/*  7916:      */         }
/*  7917:      */       }
/*  7918:      */     }
/*  7919: 9388 */     return true;
/*  7920:      */   }
/*  7921:      */   
/*  7922:      */   private void pluscgotonextrecord(MobileMboDataBean databean, AbstractMobileControl thisPage, UIEvent event)
/*  7923:      */     throws MobileApplicationException
/*  7924:      */   {
/*  7925: 9404 */     Integer dataBeanCurrentPosition = new Integer(databean.getCurrentPosition());
/*  7926: 9406 */     if (dataBeanCurrentPosition.intValue() < 0) {
/*  7927: 9407 */       ((PageControl)thisPage).nextrec(event);
/*  7928:      */     }
/*  7929:      */   }
/*  7930:      */   
/*  7931:      */   protected boolean setPointReadOnlyFields(UIEvent event)
/*  7932:      */     throws MobileApplicationException
/*  7933:      */   {
/*  7934: 9419 */     AbstractMobileControl thisPage = UIUtil.getCurrentScreen();
/*  7935: 9420 */     MobileMboDataBean databean = thisPage.getDataBean();
/*  7936: 9422 */     if (databean == null) {
/*  7937: 9423 */       databean = DataBeanCache.findDataBean("PLUSCWODS").getDataBean("PLUSCWODSINSTR").getDataBean("PLUSCWODSPOINT");
/*  7938:      */     }
/*  7939: 9426 */     MobileMbo pointMbo = databean.getMobileMbo();
/*  7940:      */     
/*  7941: 9428 */     setInstrAsOwner(pointMbo);
/*  7942: 9430 */     if (databean != null)
/*  7943:      */     {
/*  7944: 9432 */       String pageType = "";
/*  7945: 9433 */       String pageId = UIUtil.getCurrentScreen().getControlData().getValue("id");
/*  7946: 9434 */       if ((pageId.equalsIgnoreCase("pluscasfoundvaluespage")) || (pageId.equalsIgnoreCase("pluscdcasfoundvaluespage")) || (pageId.equalsIgnoreCase("pluscfcasfoundvaluespage"))) {
/*  7947: 9435 */         pageType = "ASFOUNDPAGE";
/*  7948:      */       } else {
/*  7949: 9437 */         pageType = "ASLEFTPAGE";
/*  7950:      */       }
/*  7951: 9440 */       String planType = getPlanTypeForPoint(databean);
/*  7952:      */       
/*  7953: 9442 */       String[] allFields = null;
/*  7954:      */       
/*  7955:      */ 
/*  7956: 9445 */       allFields = new String[] { "ASFOUNDINPUT", "ASFOUNDOUTPUT", "ASLEFTINPUT", "ASLEFTOUTPUT", "ASFOUNDSETPOINT", "ASLEFTSETPOINT", "SETPOINTACTION", "SETPOINTVALUE", "INPUTVALUE", "OUTPUTVALUE", "ASFOUNDPASS", "ASFOUNDFAIL", "ASLEFTPASS", "ASLEFTFAIL" };
/*  7957:      */       
/*  7958:      */ 
/*  7959:      */ 
/*  7960:      */ 
/*  7961:      */ 
/*  7962:      */ 
/*  7963:      */ 
/*  7964:      */ 
/*  7965: 9454 */       setPlusCFieldsReadOnly(thisPage, databean, allFields, false);
/*  7966:      */       
/*  7967:      */ 
/*  7968: 9457 */       String[] readOnlyFieldsArray = getReadOnlyFieldNames(pointMbo, pageType, planType);
/*  7969: 9458 */       setPlusCFieldsReadOnly(thisPage, databean, readOnlyFieldsArray, true);
/*  7970: 9460 */       if (pointMbo.getOwner().getBooleanValue("NONLINEAR"))
/*  7971:      */       {
/*  7972: 9461 */         String[] NonLinearFields = { "ASFOUNDINPUT", "ASLEFTINPUT" };
/*  7973: 9462 */         setPlusCFieldsReadOnly(thisPage, databean, NonLinearFields, true);
/*  7974:      */       }
/*  7975: 9467 */       adjustFocus((PageControl)event.getCreatingObject(), pageType, planType);
/*  7976:      */     }
/*  7977: 9471 */     pluscsetcurrentinstrposition(pointMbo);
/*  7978:      */     
/*  7979: 9473 */     return true;
/*  7980:      */   }
/*  7981:      */   
/*  7982:      */   public void setInstrAsOwner(MobileMbo referenceMbo)
/*  7983:      */     throws MobileApplicationException
/*  7984:      */   {
/*  7985: 9484 */     MobileMboDataBean instrBean = pluscgetcleaninstrdatabean(referenceMbo, true);
/*  7986: 9485 */     MobileMbo instrMbo = instrBean.getMobileMbo();
/*  7987: 9486 */     referenceMbo.setOwner(instrMbo);
/*  7988:      */   }
/*  7989:      */   
/*  7990:      */   public boolean pluscinsertcp(UIEvent event)
/*  7991:      */     throws MobileApplicationException
/*  7992:      */   {
/*  7993: 9502 */     UIUtil.gotoPageNoSave("plusccpmain", (AbstractMobileControl)event.getCreatingObject());
/*  7994:      */     
/*  7995: 9504 */     pluscchangeview(event, true, false, "CALPOINT");
/*  7996:      */     
/*  7997: 9506 */     MobileMboDataBean pointDataBean = UIUtil.getCurrentScreen().getDataBean();
/*  7998: 9507 */     MobileMbo pointMbo = pointDataBean.getMobileMbo(0);
/*  7999: 9508 */     MobileMboDataBean instrdatabean = pluscgetcleaninstrdatabean(pointMbo, true);
/*  8000: 9509 */     MobileMbo instrMbo = instrdatabean.getMobileMbo();
/*  8001: 9512 */     if ((pointDataBean != null) && 
/*  8002: 9513 */       (pointDataBean.getName().equals("PLUSCWODSPOINT")))
/*  8003:      */     {
/*  8004: 9514 */       pointDataBean.insert();
/*  8005: 9515 */       pointDataBean.setValue("DSPLANNUM", instrMbo.getValue("DSPLANNUM"), false);
/*  8006: 9516 */       pointDataBean.setValue("SITEID", instrMbo.getValue("SITEID"), false);
/*  8007: 9517 */       pointDataBean.setValue("INSTRSEQ", instrMbo.getValue("INSTRSEQ"), false);
/*  8008: 9518 */       pointDataBean.setValue("REVISIONNUM", instrMbo.getValue("REVISIONNUM"), false);
/*  8009: 9519 */       pointDataBean.setValue("WONUM", instrMbo.getValue("WONUM"), false);
/*  8010:      */       
/*  8011: 9521 */       pointDataBean.setValue("WODSNUM", instrMbo.getValue("WODSNUM"), false);
/*  8012: 9522 */       pointDataBean.setValue("INSTRUMENTDESC", instrMbo.getValue("DESCRIPTION"), false);
/*  8013: 9523 */       pointDataBean.setValue("ISADDED", "0", false);
/*  8014: 9524 */       pointDataBean.setValue("PLANTYPE", instrMbo.getValue("PLANTYPE"), false);
/*  8015: 9525 */       pointDataBean.setValue("INSTRUMENTFUNCTION", instrMbo.getValue("ASSETFUNCTION"), false);
/*  8016: 9526 */       pointDataBean.setValue("CALPOINT", instrMbo.getValue("CALPOINT"), false);
/*  8017: 9527 */       pointDataBean.setValue("CALFUNCTION", instrMbo.getValue("CALFUNCTION"), false);
/*  8018: 9528 */       pointDataBean.setValue("CALDYNAMIC", instrMbo.getValue("CALDYNAMIC"), false);
/*  8019: 9536 */       if (pluscgetplantype().equalsIgnoreCase("ANALOG"))
/*  8020:      */       {
/*  8021: 9537 */         pointDataBean.setValue("INSTROUTRANGEEU", instrMbo.getValue("INSTROUTRANGEEU"), false);
/*  8022: 9538 */         pointDataBean.setValue("INSTRASSETEU", instrMbo.getValue("INSTROUTRANGEEU"), false);
/*  8023: 9539 */         pointDataBean.setValue("INSTRCALRANGEEUA", instrMbo.getValue("INSTRCALRANGEEU"), false);
/*  8024: 9540 */         pointDataBean.setValue("TOLERANCEEU", instrMbo.getValue("INSTROUTRANGEEU"), false);
/*  8025:      */       }
/*  8026: 9541 */       else if (pluscgetplantype().equalsIgnoreCase("DISCRETE"))
/*  8027:      */       {
/*  8028: 9542 */         pointDataBean.setValue("INSTROUTRANGEEU", "", false);
/*  8029: 9543 */         pointDataBean.setValue("INSTRCALRANGEEUD", instrMbo.getValue("INSTRCALRANGEEU"), false);
/*  8030: 9544 */         pointDataBean.setValue("INSTRASSETEU", instrMbo.getValue("INSTRCALRANGEEU"), false);
/*  8031: 9545 */         pointDataBean.setValue("TOLERANCEEU", instrMbo.getValue("INSTRCALRANGEEU"), false);
/*  8032:      */       }
/*  8033: 9548 */       markParentsModified(pointDataBean);
/*  8034:      */       
/*  8035: 9550 */       setPointReadOnlyFields(new UIEvent(UIUtil.getCurrentScreen(), event.getEventName(), event.getTargetID(), null));
/*  8036:      */       
/*  8037: 9552 */       UIUtil.refreshCurrentScreen();
/*  8038:      */       
/*  8039: 9554 */       return true;
/*  8040:      */     }
/*  8041: 9559 */     return true;
/*  8042:      */   }
/*  8043:      */   
/*  8044:      */   public void pluscchangeview(UIEvent event, boolean forceLoop, boolean forcedLoop, String pointType)
/*  8045:      */     throws MobileApplicationException
/*  8046:      */   {
/*  8047: 9597 */     HashSet notUpdatedLoop = new HashSet();
/*  8048: 9598 */     notUpdatedLoop.add("pluscasfoundvaluespage");
/*  8049: 9599 */     notUpdatedLoop.add("pluscasleftvaluespage");
/*  8050: 9600 */     notUpdatedLoop.add("pluscdscpinstrpointsresultsT1");
/*  8051:      */     
/*  8052:      */ 
/*  8053: 9603 */     notUpdatedLoop.add("pluscafdetailsS1r2ac1a1");
/*  8054:      */     
/*  8055:      */ 
/*  8056:      */ 
/*  8057: 9607 */     AbstractMobileControl callingControl = (AbstractMobileControl)event.getCreatingObject();
/*  8058: 9608 */     String controlId = callingControl.getControlData().getValue("id");
/*  8059:      */     
/*  8060: 9610 */     pluscsetcachedpointbean();
/*  8061:      */     
/*  8062: 9612 */     MobileMboDataBean pointDataBean = DataBeanCache.getDataBean("PLUSCWODSPOINT", "PLUSCWODSPOINT");
/*  8063:      */     
/*  8064: 9614 */     MobileMboDataBean woDSDataBean = DataBeanCache.getDataBean("PLUSCWODS", "PLUSCWODS");
/*  8065:      */     
/*  8066: 9616 */     MobileMbo woDSMbo = woDSDataBean.getMobileMbo();
/*  8067:      */     boolean viewAsLoop;
/*  8068:      */     boolean viewAsLoop;
/*  8069: 9619 */     if (forceLoop) {
/*  8070: 9620 */       viewAsLoop = forcedLoop;
/*  8071:      */     } else {
/*  8072: 9622 */       viewAsLoop = woDSMbo.getBooleanValue("VIEWASLOOP");
/*  8073:      */     }
/*  8074: 9629 */     if (controlId.equalsIgnoreCase("pluscbtchangeview")) {
/*  8075: 9630 */       viewAsLoop = !viewAsLoop;
/*  8076:      */     }
/*  8077: 9643 */     if ((!notUpdatedLoop.contains(controlId)) && (woDSMbo.getBooleanValue("VIEWASLOOP") != viewAsLoop)) {
/*  8078: 9644 */       woDSMbo.setBooleanValue("VIEWASLOOP", viewAsLoop);
/*  8079:      */     }
/*  8080: 9651 */     MobileMboDataBean currentafDataBean = woDSDataBean.getDataBean("PLUSCWODSINSTR");
/*  8081: 9652 */     MobileMbo pointMbo = null;
/*  8082:      */     
/*  8083:      */ 
/*  8084: 9655 */     MobileMboOrder mboOrder = new MobileMboOrder();
/*  8085: 9656 */     mboOrder.setOrder("INSTRSEQ", true);
/*  8086:      */     
/*  8087: 9658 */     mboOrder.setOrder("POINT", true);
/*  8088:      */     
/*  8089: 9660 */     mboOrder.setOrder("PLUSCWODSPOINTID", true);
/*  8090: 9661 */     if (!viewAsLoop)
/*  8091:      */     {
/*  8092: 9664 */       int currentafPos = getInstrPosition(currentafDataBean);
/*  8093: 9665 */       MobileMbo currentaftmbo = currentafDataBean.getMobileMbo(currentafPos != -1 ? currentafPos : 0);
/*  8094: 9666 */       MobileMboDataBean afDataBean = pluscgetcleaninstrdatabean(currentaftmbo, true);
/*  8095: 9667 */       pointDataBean = afDataBean.getDataBean("PLUSCWODSPOINT");
/*  8096:      */       
/*  8097: 9669 */       pointDataBean.setOrder(mboOrder);
/*  8098: 9670 */       pointDataBean.getQBE().setQBE(pointType, "1");
/*  8099: 9671 */       pointDataBean.getQBE().setQBE("ISAVERAGE", "0");
/*  8100: 9672 */       pointDataBean.reset();
/*  8101:      */     }
/*  8102:      */     else
/*  8103:      */     {
/*  8104: 9677 */       String dsplannum = woDSMbo.getValue("DSPLANNUM");
/*  8105: 9678 */       String siteid = woDSMbo.getValue("SITEID");
/*  8106: 9679 */       String revisionnum = woDSMbo.getValue("REVISIONNUM");
/*  8107: 9680 */       String wonum = woDSMbo.getValue("WONUM");
/*  8108:      */       
/*  8109: 9682 */       String wodsnum = woDSMbo.getValue("WODSNUM");
/*  8110:      */       
/*  8111: 9684 */       MobileMboDataBeanManager pointmgr = new MobileMboDataBeanManager("PLUSCWODSPOINT");
/*  8112: 9685 */       pointDataBean = pointmgr.getDataBean();
/*  8113:      */       
/*  8114: 9687 */       pointDataBean.getQBE().reset();
/*  8115: 9688 */       pointDataBean.getQBE().setQbeExactMatch(true);
/*  8116: 9689 */       pointDataBean.getQBE().setQBE("DSPLANNUM", dsplannum);
/*  8117: 9690 */       pointDataBean.getQBE().setQBE("SITEID", siteid);
/*  8118: 9691 */       pointDataBean.getQBE().setQBE("REVISIONNUM", revisionnum);
/*  8119: 9692 */       pointDataBean.getQBE().setQBE("WONUM", wonum);
/*  8120:      */       
/*  8121: 9694 */       pointDataBean.getQBE().setQBE("WODSNUM", wodsnum);
/*  8122: 9695 */       pointDataBean.getQBE().setQBE(pointType, "1");
/*  8123: 9696 */       pointDataBean.getQBE().setQBE("ISAVERAGE", "0");
/*  8124:      */       
/*  8125:      */ 
/*  8126: 9699 */       pointDataBean.setOrder(mboOrder);
/*  8127:      */       
/*  8128: 9701 */       pointDataBean.reset();
/*  8129: 9702 */       int size = pointDataBean.count();
/*  8130: 9704 */       if (size > 0)
/*  8131:      */       {
/*  8132: 9706 */         MobileMboDataBean instrBean = pluscgetcleaninstrdatabean(pointDataBean.getMobileMbo(), true);
/*  8133: 9707 */         pointDataBean.setParentBean(instrBean);
/*  8134: 9708 */         for (int i = 0; i <= size; i++)
/*  8135:      */         {
/*  8136: 9709 */           pointDataBean.setCurrentPosition(i);
/*  8137: 9710 */           pointMbo = pointDataBean.getMobileMbo();
/*  8138: 9711 */           MobileMbo instrMbo = instrBean.getMobileMbo();
/*  8139: 9712 */           pointMbo.setOwner(instrMbo);
/*  8140:      */         }
/*  8141:      */       }
/*  8142:      */     }
/*  8143: 9718 */     if (controlId.equalsIgnoreCase("pluscdsinstrpointsresultsT1")) {
/*  8144: 9719 */       pluscclearpointdatabean(pointDataBean);
/*  8145:      */     }
/*  8146: 9727 */     String lauchingControl = ((PageControl)UIUtil.getCurrentScreen()).getLaunchingControl().getId();
/*  8147: 9729 */     if (lauchingControl.equalsIgnoreCase("pluscdscpdetailmenu1"))
/*  8148:      */     {
/*  8149: 9730 */       pointDataBean.setCurrentPosition(0);
/*  8150:      */     }
/*  8151:      */     else
/*  8152:      */     {
/*  8153: 9733 */       setPointPosition(pointDataBean);
/*  8154: 9734 */       setInstrPosition(currentafDataBean);
/*  8155:      */     }
/*  8156: 9737 */     plusccachepointbean(pointDataBean);
/*  8157:      */   }
/*  8158:      */   
/*  8159:      */   public void pluscsetcachedpointbean()
/*  8160:      */     throws MobileApplicationException
/*  8161:      */   {
/*  8162: 9750 */     AbstractMobileControl thisPage = UIUtil.getCurrentScreen();
/*  8163: 9751 */     AbstractMobileControl ancestorControl = ((PageControl)thisPage).getLaunchingControl();
/*  8164: 9753 */     if (ancestorControl.getId().equalsIgnoreCase("womain"))
/*  8165:      */     {
/*  8166: 9754 */       MobileMboDataBean databean = thisPage.getDataBean();
/*  8167:      */       
/*  8168:      */ 
/*  8169:      */ 
/*  8170: 9758 */       MobileMboDataBean pointDatabean = databean.getDataBean("PLUSCWODSLOOPPOINTS");
/*  8171:      */       
/*  8172:      */ 
/*  8173: 9761 */       setPointPosition(pointDatabean);
/*  8174: 9762 */       DataBeanCacheItem item = new DataBeanCacheItem("PLUSCWODSPOINT", "PLUSCWODSPOINT", pointDatabean);
/*  8175: 9763 */       DataBeanCache.cacheDataBean("PLUSCWODSPOINT", item);
/*  8176:      */     }
/*  8177:      */   }
/*  8178:      */   
/*  8179:      */   private int getInstrPosition(MobileMboDataBean instrDataBean)
/*  8180:      */     throws MobileApplicationException
/*  8181:      */   {
/*  8182: 9769 */     for (int i = 0; i < instrDataBean.count(); i++) {
/*  8183: 9770 */       if (instrDataBean.getMobileMbo(i).getLongValue("PLUSCWODSINSTRID") == this.currentAFIndex) {
/*  8184: 9771 */         return i;
/*  8185:      */       }
/*  8186:      */     }
/*  8187: 9774 */     return 0;
/*  8188:      */   }
/*  8189:      */   
/*  8190:      */   protected void setMboValueFromEvent(UIEvent event, MobileMbo mobileMbo)
/*  8191:      */     throws MobileApplicationException
/*  8192:      */   {
/*  8193: 9787 */     TextboxControl eventSource = (TextboxControl)event.getCreatingObject();
/*  8194: 9788 */     String fieldName = eventSource.getControlData().getValue("dataattribute");
/*  8195:      */     
/*  8196: 9790 */     mobileMbo.setValue(fieldName, eventSource.getControlValue());
/*  8197:      */   }
/*  8198:      */   
/*  8199:      */   private String pluscgetplantype()
/*  8200:      */     throws MobileApplicationException
/*  8201:      */   {
/*  8202: 9802 */     MobileMboDataBean pointDataBean = UIUtil.getCurrentScreen().getDataBean();
/*  8203: 9803 */     MobileMbo pointMbo = pointDataBean.getMobileMbo();
/*  8204: 9804 */     String planType = null;
/*  8205:      */     
/*  8206: 9806 */     MobileMbo instrMbo = pluscgetinstrmboforpoint(pointMbo);
/*  8207:      */     
/*  8208: 9808 */     String analogPlantype = ((WOApp)UIUtil.getApplication()).getInternalValue(pointDataBean, "PLUSCDSPLANTYPE", "ANALOG");
/*  8209: 9809 */     String discretePlantype = ((WOApp)UIUtil.getApplication()).getInternalValue(pointDataBean, "PLUSCDSPLANTYPE", "DISCRETE");
/*  8210: 9811 */     if (instrMbo.getValue("PLANTYPE").equalsIgnoreCase(analogPlantype)) {
/*  8211: 9812 */       planType = "ANALOG";
/*  8212: 9813 */     } else if (instrMbo.getValue("PLANTYPE").equalsIgnoreCase(discretePlantype)) {
/*  8213: 9814 */       planType = "DISCRETE";
/*  8214:      */     }
/*  8215: 9817 */     return planType;
/*  8216:      */   }
/*  8217:      */   
/*  8218:      */   private void pluscclearpointdatabean(MobileMboDataBean dataBean)
/*  8219:      */     throws MobileApplicationException
/*  8220:      */   {
/*  8221: 9832 */     Set doNotDeleteAfter = new HashSet();
/*  8222:      */     
/*  8223:      */ 
/*  8224: 9835 */     int size = dataBean.count();
/*  8225: 9836 */     HashMap pointMap = new HashMap();
/*  8226: 9839 */     for (int i = 0; i <= size; i++)
/*  8227:      */     {
/*  8228: 9843 */       MobileMbo pointMbo = dataBean.getMobileMbo(i);
/*  8229: 9845 */       if (pointMbo != null)
/*  8230:      */       {
/*  8231: 9847 */         Integer z = (Integer)pointMap.get(pointMbo.getValue("POINT"));
/*  8232: 9849 */         if (z == null) {
/*  8233: 9850 */           pointMap.put(pointMbo.getValue("POINT"), new Integer(1));
/*  8234:      */         } else {
/*  8235: 9852 */           pointMap.put(pointMbo.getValue("POINT"), new Integer(z.intValue() + 1));
/*  8236:      */         }
/*  8237:      */       }
/*  8238:      */     }
/*  8239: 9859 */     for (i = 0; i <= size; i++)
/*  8240:      */     {
/*  8241: 9861 */       dataBean.setCurrentPosition(i);
/*  8242: 9862 */       MobileMbo pointMbo = dataBean.getMobileMbo();
/*  8243: 9864 */       if (pointMbo != null) {
/*  8244: 9866 */         if ((((Integer)pointMap.get(pointMbo.getValue("POINT"))).intValue() > 1) && (pointMbo.isNew())) {
/*  8245: 9867 */           if (!doNotDeleteAfter.contains(pointMbo.getValue("POINT").toUpperCase())) {
/*  8246: 9868 */             dataBean.delete();
/*  8247:      */           } else {
/*  8248: 9870 */             doNotDeleteAfter.add(pointMbo.getValue("POINT"));
/*  8249:      */           }
/*  8250:      */         }
/*  8251:      */       }
/*  8252:      */     }
/*  8253: 9877 */     dataBean.getDataBeanManager().save();
/*  8254: 9878 */     dataBean.reset();
/*  8255:      */   }
/*  8256:      */   
/*  8257:      */   private void markParentsModified(MobileMboDataBean dataBean)
/*  8258:      */     throws MobileApplicationException
/*  8259:      */   {
/*  8260: 9889 */     MobileMbo thisMobileMbo = dataBean.getMobileMbo(dataBean.getCurrentPosition());
/*  8261:      */     
/*  8262: 9891 */     UIUtil.getApplication().updateMobileMbo("PLUSCWODSPOINT", thisMobileMbo);
/*  8263: 9893 */     if (thisMobileMbo.isModified())
/*  8264:      */     {
/*  8265: 9895 */       PlusCWODsPointDelegate woDsPoint = new PlusCMobileWODsPointDelegate(new MobileMboAdapter(thisMobileMbo, dataBean), null);
/*  8266:      */       try
/*  8267:      */       {
/*  8268: 9898 */         PlusCWODsInstrDelegate woDsInstr = woDsPoint.getInstrDelegate();
/*  8269: 9899 */         MobileMboAdapter instrMbo = (MobileMboAdapter)((PlusCMobileWODsInstrDelegate)woDsInstr).getThisMbo();
/*  8270:      */         
/*  8271: 9901 */         PlusCWODsDelegate woDs = woDsInstr.getDsDelegate();
/*  8272: 9902 */         MobileMboAdapter dsMbo = (MobileMboAdapter)((PlusCMobileWODsDelegate)woDs).getThisMbo();
/*  8273:      */         
/*  8274: 9904 */         instrMbo.getMbo().setBooleanValue("_MODIFIED", true);
/*  8275: 9905 */         instrMbo.getDatabean().getDataBeanManager().save();
/*  8276:      */         
/*  8277: 9907 */         dsMbo.getMbo().setBooleanValue("_MODIFIED", true);
/*  8278: 9908 */         dsMbo.getDatabean().getDataBeanManager().save();
/*  8279:      */         
/*  8280: 9910 */         MobileMboDataBean wo = DataBeanCache.getDataBean("WORKORDER", "WORKORDER");
/*  8281: 9911 */         wo.getMobileMbo().setBooleanValue("_MODIFIED", true);
/*  8282: 9912 */         wo.getDataBeanManager().save();
/*  8283:      */       }
/*  8284:      */       catch (Exception e)
/*  8285:      */       {
/*  8286: 9914 */         MobileMboAdapter.wrapException(e);
/*  8287:      */       }
/*  8288:      */     }
/*  8289:      */   }
/*  8290:      */   
/*  8291:      */   public boolean pluscInsertFunDynChk(UIEvent event, String insertPageId, String pointType)
/*  8292:      */     throws MobileApplicationException
/*  8293:      */   {
/*  8294: 9929 */     UIUtil.gotoPageNoSave(insertPageId, (AbstractMobileControl)event.getCreatingObject());
/*  8295:      */     
/*  8296: 9931 */     pluscchangeview(event, true, false, pointType);
/*  8297:      */     
/*  8298: 9933 */     MobileMboDataBean pointDataBean = UIUtil.getCurrentScreen().getDataBean();
/*  8299: 9934 */     MobileMbo pointMbo = pointDataBean.getMobileMbo(0);
/*  8300: 9935 */     MobileMboDataBean instrdatabean = pluscgetcleaninstrdatabean(pointMbo, true);
/*  8301: 9936 */     MobileMbo instrMbo = instrdatabean.getMobileMbo();
/*  8302: 9938 */     if ((pointDataBean != null) && 
/*  8303: 9939 */       (pointDataBean.getName().equals("PLUSCWODSPOINT")))
/*  8304:      */     {
/*  8305: 9940 */       pointDataBean.insert();
/*  8306: 9941 */       pointDataBean.setValue("DSPLANNUM", instrMbo.getValue("DSPLANNUM"), false);
/*  8307: 9942 */       pointDataBean.setValue("SITEID", instrMbo.getValue("SITEID"), false);
/*  8308: 9943 */       pointDataBean.setValue("INSTRSEQ", instrMbo.getValue("INSTRSEQ"), false);
/*  8309: 9944 */       pointDataBean.setValue("REVISIONNUM", instrMbo.getValue("REVISIONNUM"), false);
/*  8310: 9945 */       pointDataBean.setValue("WONUM", instrMbo.getValue("WONUM"), false);
/*  8311: 9946 */       pointDataBean.setValue("WODSNUM", instrMbo.getValue("WODSNUM"), false);
/*  8312: 9947 */       pointDataBean.setValue("INSTRUMENTDESC", instrMbo.getValue("DESCRIPTION"), false);
/*  8313: 9948 */       pointDataBean.setValue("ISADDED", "0", false);
/*  8314: 9949 */       pointDataBean.setValue("PLANTYPE", instrMbo.getValue("PLANTYPE"), false);
/*  8315: 9950 */       pointDataBean.setValue("INSTRUMENTFUNCTION", instrMbo.getValue("ASSETFUNCTION"), false);
/*  8316: 9951 */       pointDataBean.setValue("CALPOINT", instrMbo.getValue("CALPOINT"), false);
/*  8317: 9952 */       pointDataBean.setValue("CALFUNCTION", instrMbo.getValue("CALFUNCTION"), false);
/*  8318: 9953 */       pointDataBean.setValue("CALDYNAMIC", instrMbo.getValue("CALDYNAMIC"), false);
/*  8319:      */       
/*  8320: 9955 */       markParentsModified(pointDataBean);
/*  8321:      */       
/*  8322: 9957 */       setPointReadOnlyFields(new UIEvent(UIUtil.getCurrentScreen(), event.getEventName(), event.getTargetID(), null));
/*  8323:      */       
/*  8324: 9959 */       UIUtil.refreshCurrentScreen();
/*  8325:      */       
/*  8326: 9961 */       return true;
/*  8327:      */     }
/*  8328: 9966 */     return true;
/*  8329:      */   }
/*  8330:      */   
/*  8331:      */   public boolean pluscsetinvisible(UIEvent event)
/*  8332:      */     throws MobileApplicationException
/*  8333:      */   {
/*  8334: 9981 */     ((AbstractMobileControl)event.getCreatingObject()).setVisibility(false);
/*  8335: 9982 */     return true;
/*  8336:      */   }
/*  8337:      */   
/*  8338:      */   public boolean pluscrefresh(UIEvent event)
/*  8339:      */     throws MobileApplicationException
/*  8340:      */   {
/*  8341:10009 */     return true;
/*  8342:      */   }
/*  8343:      */   
/*  8344:      */   public boolean pluscinitcppage(UIEvent event)
/*  8345:      */     throws MobileApplicationException
/*  8346:      */   {
/*  8347:10028 */     if (DataBeanCache.findDataBean("PLUSCWODSPOINT") == null) {
/*  8348:10029 */       pluscsetcachedpointbean();
/*  8349:      */     }
/*  8350:10035 */     return setAnalogDiscreteReadOnlyField(event);
/*  8351:      */   }
/*  8352:      */   
/*  8353:      */   public boolean pluscgotoaftab(UIEvent event)
/*  8354:      */     throws MobileApplicationException
/*  8355:      */   {
/*  8356:10052 */     AbstractMobileControl thisPage = UIUtil.getCurrentScreen();
/*  8357:10053 */     AbstractMobileControl callingControl = (AbstractMobileControl)event.getCreatingObject();
/*  8358:      */     
/*  8359:      */ 
/*  8360:10056 */     MobileMboDataBean pointDataBean = callingControl.getDataBean();
/*  8361:10057 */     MobileMbo pointMobileMbo = pointDataBean.getMobileMbo(pointDataBean.getCurrentPosition());
/*  8362:      */     
/*  8363:      */ 
/*  8364:      */ 
/*  8365:      */ 
/*  8366:      */ 
/*  8367:10063 */     pluscFilterAfCpDataBean(true, "PLUSCWODSINSTR", pointMobileMbo.getValue("DSPLANNUM"), pointMobileMbo.getValue("SITEID"), pointMobileMbo.getValue("INSTRSEQ"), pointMobileMbo.getValue("REVISIONNUM"), pointMobileMbo.getValue("WONUM"), null, pointMobileMbo.getValue("WODSNUM"));
/*  8368:      */     
/*  8369:      */ 
/*  8370:      */ 
/*  8371:      */ 
/*  8372:      */ 
/*  8373:      */ 
/*  8374:      */ 
/*  8375:      */ 
/*  8376:10072 */     UIUtil.gotoPage("pluscdsassetfunctions", callingControl);
/*  8377:      */     
/*  8378:      */ 
/*  8379:10075 */     UIEvent uievent = new UIEvent(this, "gototab", null, callingControl.getStringValue("targettabid"));
/*  8380:10076 */     thisPage.sendEventDown(uievent);
/*  8381:      */     
/*  8382:10078 */     return true;
/*  8383:      */   }
/*  8384:      */   
/*  8385:      */   private void pluscFilterAfCpDataBean(boolean setInstrSeq, String mboName, String dsplannum, String siteid, String instrseq, String revisionum, String wonum, String pointType, String wodsnum)
/*  8386:      */     throws MobileApplicationException
/*  8387:      */   {
/*  8388:10098 */     MobileMboDataBean woDataBean = DataBeanCache.getDataBean("PLUSCWODS", "PLUSCWODS");
/*  8389:      */     
/*  8390:      */ 
/*  8391:      */ 
/*  8392:      */ 
/*  8393:10103 */     MobileMboDataBean mboDataBean = null;
/*  8394:10105 */     if (mboName.equalsIgnoreCase("PLUSCWODSINSTR"))
/*  8395:      */     {
/*  8396:10106 */       mboDataBean = pluscgetcleaninstrdatabean(woDataBean.getMobileMbo(), false);
/*  8397:      */     }
/*  8398:      */     else
/*  8399:      */     {
/*  8400:10108 */       mboDataBean = woDataBean.getDataBean("PLUSCWODSLOOPPOINTS");
/*  8401:      */       
/*  8402:10110 */       mboDataBean.getQBE().reset();
/*  8403:10111 */       mboDataBean.getQBE().setQBE("DSPLANNUM", dsplannum);
/*  8404:10112 */       mboDataBean.getQBE().setQBE("SITEID", siteid);
/*  8405:10114 */       if (setInstrSeq) {
/*  8406:10115 */         mboDataBean.getQBE().setQBE("INSTRSEQ", instrseq);
/*  8407:      */       }
/*  8408:10118 */       mboDataBean.getQBE().setQBE("REVISIONNUM", revisionum);
/*  8409:10119 */       mboDataBean.getQBE().setQBE("WONUM", wonum);
/*  8410:      */       
/*  8411:      */ 
/*  8412:10122 */       mboDataBean.getQBE().setQBE("WODSNUM", wodsnum);
/*  8413:      */       
/*  8414:10124 */       mboDataBean.getQBE().setQBE(pointType, "1");
/*  8415:10125 */       mboDataBean.getQBE().setQBE("ISAVERAGE", "0");
/*  8416:      */       
/*  8417:10127 */       mboDataBean.reset();
/*  8418:      */     }
/*  8419:10129 */     DataBeanCacheItem item = new DataBeanCacheItem(mboName, mboName, mboDataBean);
/*  8420:10130 */     DataBeanCache.cacheDataBean(mboName, item);
/*  8421:      */   }
/*  8422:      */   
/*  8423:      */   private boolean pluscGotoAsFoundPageFromCPTab(UIEvent event)
/*  8424:      */     throws MobileApplicationException
/*  8425:      */   {
/*  8426:10139 */     return pluscGotoPageFromCPTab(event, "pluscasfoundvaluespage");
/*  8427:      */   }
/*  8428:      */   
/*  8429:      */   private boolean pluscGotoAsLeftPageFromCPTab(UIEvent event)
/*  8430:      */     throws MobileApplicationException
/*  8431:      */   {
/*  8432:10148 */     return pluscGotoPageFromCPTab(event, "pluscasleftvaluespage");
/*  8433:      */   }
/*  8434:      */   
/*  8435:      */   private boolean pluscGotoFcAsFoundPageFromCPTab(UIEvent event)
/*  8436:      */     throws MobileApplicationException
/*  8437:      */   {
/*  8438:10157 */     return pluscGotoPageFromCPTab(event, "pluscfcasfoundvaluespage");
/*  8439:      */   }
/*  8440:      */   
/*  8441:      */   private boolean pluscGotoFcAsLeftPageFromCPTab(UIEvent event)
/*  8442:      */     throws MobileApplicationException
/*  8443:      */   {
/*  8444:10166 */     return pluscGotoPageFromCPTab(event, "pluscfcasleftvaluespage");
/*  8445:      */   }
/*  8446:      */   
/*  8447:      */   private boolean pluscGotoPageFromCPTab(UIEvent event, String pageId)
/*  8448:      */     throws MobileApplicationException
/*  8449:      */   {
/*  8450:10186 */     AbstractMobileControl callingControl = (AbstractMobileControl)event.getCreatingObject();
/*  8451:      */     
/*  8452:10188 */     MobileMboDataBean pointDataBean = DataBeanCache.getDataBean("PLUSCWODSPOINT", "PLUSCWODSPOINT");
/*  8453:10189 */     MobileMbo pointMbo = pointDataBean.getMobileMbo();
/*  8454:      */     
/*  8455:      */ 
/*  8456:      */ 
/*  8457:10193 */     this.currentCPIndex = ((int)pointMbo.getLongValue("PLUSCWODSPOINTID"));
/*  8458:10194 */     MobileMbo instrMbo = pluscgetinstrmboforpoint(pointMbo);
/*  8459:      */     
/*  8460:      */ 
/*  8461:      */ 
/*  8462:      */ 
/*  8463:      */ 
/*  8464:      */ 
/*  8465:      */ 
/*  8466:      */ 
/*  8467:      */ 
/*  8468:10204 */     this.currentAFIndex = ((int)instrMbo.getLongValue("PLUSCWODSINSTRID"));
/*  8469:      */     
/*  8470:      */ 
/*  8471:      */ 
/*  8472:      */ 
/*  8473:10209 */     UIUtil.gotoPage(pageId, callingControl);
/*  8474:      */     
/*  8475:10211 */     return true;
/*  8476:      */   }
/*  8477:      */   
/*  8478:      */   private boolean pluscGotoDcAsFoundPageFromCPTab(UIEvent event)
/*  8479:      */     throws MobileApplicationException
/*  8480:      */   {
/*  8481:10220 */     return pluscGotoPageFromCPTab(event, "pluscdcasfoundvaluespage");
/*  8482:      */   }
/*  8483:      */   
/*  8484:      */   private boolean pluscGotoDcAsLeftPageFromCPTab(UIEvent event)
/*  8485:      */     throws MobileApplicationException
/*  8486:      */   {
/*  8487:10229 */     return pluscGotoPageFromCPTab(event, "pluscdcasleftvaluespage");
/*  8488:      */   }
/*  8489:      */   
/*  8490:      */   public boolean pluscinitdstab(UIEvent event)
/*  8491:      */     throws MobileApplicationException
/*  8492:      */   {
/*  8493:10243 */     AbstractMobileControl callingControl = (AbstractMobileControl)event.getCreatingObject();
/*  8494:10244 */     UIUtil.gotoPage("pluscdsresults", callingControl);
/*  8495:10245 */     return true;
/*  8496:      */   }
/*  8497:      */   
/*  8498:      */   public boolean pluscinitdshierarchytab(UIEvent event)
/*  8499:      */     throws MobileApplicationException
/*  8500:      */   {
/*  8501:10260 */     AbstractMobileControl callingControl = (AbstractMobileControl)event.getCreatingObject();
/*  8502:10261 */     goToTab(callingControl, "pluscdsresults", "dshierarchytab");
/*  8503:10262 */     return true;
/*  8504:      */   }
/*  8505:      */   
/*  8506:      */   public boolean pluscGOTOpluscdsafresultsT1(UIEvent event)
/*  8507:      */     throws MobileApplicationException
/*  8508:      */   {
/*  8509:10268 */     AbstractMobileControl callingControl = (AbstractMobileControl)event.getCreatingObject();
/*  8510:10269 */     goToTab(callingControl, "pluscdsassetfunctions", "pluscdsafresultsT1");
/*  8511:10270 */     return true;
/*  8512:      */   }
/*  8513:      */   
/*  8514:      */   public void goToTab(AbstractMobileControl callingControl, String pageId, String tabId)
/*  8515:      */     throws MobileApplicationException
/*  8516:      */   {
/*  8517:10282 */     UIUtil.gotoPage(pageId, callingControl);
/*  8518:10283 */     UIEvent uievent = new UIEvent(this, "gototab", null, tabId);
/*  8519:10284 */     UIUtil.getCurrentScreen().sendEventDown(uievent);
/*  8520:      */   }
/*  8521:      */   
/*  8522:      */   public boolean pluscnextrec(UIEvent event)
/*  8523:      */     throws MobileApplicationException
/*  8524:      */   {
/*  8525:10307 */     String pageId = ((PageControl)UIUtil.getCurrentScreen()).getControlData().getValue("id");
/*  8526:      */     String asLeftValuesPageId;
/*  8527:      */     String asLeftValuesPageId;
/*  8528:10309 */     if ((pageId.equalsIgnoreCase("pluscfcasfoundvaluespage")) || (pageId.equalsIgnoreCase("pluscfcasleftvaluespage")))
/*  8529:      */     {
/*  8530:10310 */       asLeftValuesPageId = "pluscfcasleftvaluespage";
/*  8531:      */     }
/*  8532:      */     else
/*  8533:      */     {
/*  8534:      */       String asLeftValuesPageId;
/*  8535:10311 */       if ((pageId.equalsIgnoreCase("pluscdcasfoundvaluespage")) || (pageId.equalsIgnoreCase("pluscdcasleftvaluespage"))) {
/*  8536:10312 */         asLeftValuesPageId = "pluscdcasleftvaluespage";
/*  8537:      */       } else {
/*  8538:10314 */         asLeftValuesPageId = "pluscasleftvaluespage";
/*  8539:      */       }
/*  8540:      */     }
/*  8541:10316 */     PageControl thisPage = (PageControl)UIUtil.getCurrentScreen();
/*  8542:10317 */     MobileMboDataBean dataBean = thisPage.getDataBean();
/*  8543:      */     
/*  8544:10319 */     MobileMbo thisMobileMbo = dataBean.getMobileMbo(dataBean.getCurrentPosition());
/*  8545:      */     
/*  8546:10321 */     UIUtil.getApplication().updateMobileMbo("PLUSCWODSPOINT", thisMobileMbo);
/*  8547:10322 */     int nextPosition = dataBean.getCurrentPosition() + 1;
/*  8548:      */     
/*  8549:      */ 
/*  8550:10325 */     markParentsModified(dataBean);
/*  8551:10327 */     if ((nextPosition >= 0) && (nextPosition >= dataBean.count()))
/*  8552:      */     {
/*  8553:10330 */       if (pageId.equalsIgnoreCase(asLeftValuesPageId))
/*  8554:      */       {
/*  8555:10332 */         UIUtil.getApplication().removeCurrentScreen(true);
/*  8556:      */         
/*  8557:10334 */         MobileMboDataBean woDsDataBean = DataBeanCache.findDataBean("PLUSCWODS");
/*  8558:      */         
/*  8559:10336 */         MobileMboDataBean woDsInstrDataBean = pluscgetcleaninstrdatabean(woDsDataBean.getMobileMbo(), false);
/*  8560:10337 */         DataBeanCache.cacheDataBean("PLUSCWODSINSTR", woDsInstrDataBean);
/*  8561:      */         
/*  8562:10339 */         UIUtil.refreshCurrentScreen();
/*  8563:      */         
/*  8564:10341 */         return true;
/*  8565:      */       }
/*  8566:10348 */       UIUtil.refreshCurrentScreen();
/*  8567:      */       
/*  8568:      */ 
/*  8569:10351 */       MobileMboDataBean woDsDataBean = DataBeanCache.findDataBean("PLUSCWODS");
/*  8570:10352 */       if (woDsDataBean != null) {
/*  8571:10353 */         this.currentWODSIndex = ((int)woDsDataBean.getMobileMbo().getLongValue("PLUSCWODSID"));
/*  8572:      */       }
/*  8573:10357 */       UIUtil.getApplication().removeCurrentScreen(true);
/*  8574:      */       
/*  8575:      */ 
/*  8576:10360 */       woDsDataBean = DataBeanCache.findDataBean("PLUSCWODS");
/*  8577:10361 */       if (woDsDataBean != null) {
/*  8578:10362 */         setWODsPosition(woDsDataBean);
/*  8579:      */       }
/*  8580:10366 */       MobileMboDataBean woDsInstrDataBean = pluscgetcleaninstrdatabean(woDsDataBean.getMobileMbo(), false);
/*  8581:10367 */       DataBeanCache.cacheDataBean("PLUSCWODSINSTR", woDsInstrDataBean);
/*  8582:      */       
/*  8583:10369 */       UIUtil.gotoPage(asLeftValuesPageId, thisPage);
/*  8584:10370 */       thisPage = (PageControl)UIUtil.getCurrentScreen();
/*  8585:10371 */       dataBean = thisPage.getDataBean();
/*  8586:10372 */       dataBean.setCurrentPosition(0);
/*  8587:10373 */       UIUtil.refreshCurrentScreen();
/*  8588:10374 */       return true;
/*  8589:      */     }
/*  8590:10378 */     return thisPage.nextrec(event);
/*  8591:      */   }
/*  8592:      */   
/*  8593:      */   public boolean pluscinitchangeviewCalpoint(UIEvent event)
/*  8594:      */     throws MobileApplicationException
/*  8595:      */   {
/*  8596:10385 */     return pluscinitchangeview(event, "CALPOINT");
/*  8597:      */   }
/*  8598:      */   
/*  8599:      */   public boolean pluscinitchangeviewCalfunction(UIEvent event)
/*  8600:      */     throws MobileApplicationException
/*  8601:      */   {
/*  8602:10389 */     return pluscinitchangeview(event, "CALFUNCTION");
/*  8603:      */   }
/*  8604:      */   
/*  8605:      */   public boolean pluscinitchangeviewCaldynamic(UIEvent event)
/*  8606:      */     throws MobileApplicationException
/*  8607:      */   {
/*  8608:10393 */     return pluscinitchangeview(event, "CALDYNAMIC");
/*  8609:      */   }
/*  8610:      */   
/*  8611:      */   public boolean pluscinitchangeview(UIEvent event, String pointType)
/*  8612:      */     throws MobileApplicationException
/*  8613:      */   {
/*  8614:10407 */     AbstractMobileControl callingControl = (AbstractMobileControl)event.getCreatingObject();
/*  8615:10408 */     String controlId = callingControl.getControlData().getValue("id");
/*  8616:10409 */     boolean isvaluepage = false;
/*  8617:10410 */     if ((controlId.equalsIgnoreCase("pluscasfoundvaluespage")) || (controlId.equalsIgnoreCase("pluscasleftvaluespage"))) {
/*  8618:10411 */       isvaluepage = true;
/*  8619:      */     }
/*  8620:10414 */     MobileMboDataBean woDSDataBean = DataBeanCache.getDataBean("PLUSCWODS", "PLUSCWODS");
/*  8621:10415 */     MobileMboDataBean pointLoopDataBean = woDSDataBean.getDataBean("PLUSCWODSLOOPPOINTS");
/*  8622:10416 */     MobileMboDataBean currentPointDataBean = DataBeanCache.getDataBean("PLUSCWODSPOINT", "PLUSCWODSPOINT");
/*  8623:      */     
/*  8624:      */ 
/*  8625:10419 */     String dsplannum = woDSDataBean.getMobileMbo().getValue("DSPLANNUM");
/*  8626:10420 */     String siteid = woDSDataBean.getMobileMbo().getValue("SITEID");
/*  8627:10421 */     String revisionnum = woDSDataBean.getMobileMbo().getValue("REVISIONNUM");
/*  8628:10422 */     String wonum = woDSDataBean.getMobileMbo().getValue("WONUM");
/*  8629:10423 */     String wodsnum = woDSDataBean.getMobileMbo().getValue("WODSNUM");
/*  8630:10424 */     MobileMboDataBean dataBean = pluscgetpointsfords(dsplannum, siteid, revisionnum, wonum, wodsnum);
/*  8631:      */     
/*  8632:      */ 
/*  8633:10427 */     boolean loopActivated = (dataBean.count() == pointLoopDataBean.count()) && (pointLoopDataBean.count() == currentPointDataBean.count());
/*  8634:10428 */     boolean forceLoop = (isvaluepage) && (loopActivated);
/*  8635:      */     
/*  8636:      */ 
/*  8637:10431 */     MobileMbo currentPointMbo = currentPointDataBean.getMobileMbo();
/*  8638:10432 */     if (currentPointMbo != null)
/*  8639:      */     {
/*  8640:10433 */       pluscsetcurrentinstrposition(currentPointMbo);
/*  8641:10434 */       pluscchangeview(event, forceLoop, forceLoop, pointType);
/*  8642:      */     }
/*  8643:10437 */     return true;
/*  8644:      */   }
/*  8645:      */   
/*  8646:      */   public MobileMboDataBean pluscgetpointsfords(String dsplannum, String siteid, String revisionnum, String wonum, String wodsnum)
/*  8647:      */     throws MobileApplicationException
/*  8648:      */   {
/*  8649:10457 */     MobileMboDataBeanManager pointmgr = new MobileMboDataBeanManager("PLUSCWODSPOINT");
/*  8650:10458 */     MobileMboDataBean pointBean = pointmgr.getDataBean();
/*  8651:      */     
/*  8652:10460 */     pointBean.getQBE().reset();
/*  8653:10461 */     pointBean.getQBE().setQbeExactMatch(true);
/*  8654:10462 */     pointBean.getQBE().setQBE("DSPLANNUM", dsplannum);
/*  8655:10463 */     pointBean.getQBE().setQBE("SITEID", siteid);
/*  8656:10464 */     pointBean.getQBE().setQBE("REVISIONNUM", revisionnum);
/*  8657:10465 */     pointBean.getQBE().setQBE("WONUM", wonum);
/*  8658:      */     
/*  8659:10467 */     pointBean.getQBE().setQBE("WODSNUM", wodsnum);
/*  8660:10468 */     pointBean.reset();
/*  8661:      */     
/*  8662:10470 */     return pointBean;
/*  8663:      */   }
/*  8664:      */   
/*  8665:      */   public boolean pluscdisplaychangeview(UIEvent event)
/*  8666:      */     throws MobileApplicationException
/*  8667:      */   {
/*  8668:10486 */     AbstractMobileControl callingControl = (AbstractMobileControl)event.getCreatingObject();
/*  8669:      */     
/*  8670:10488 */     HashMap instrAFStatusMap = new HashMap();
/*  8671:10489 */     HashMap instrALStatusMap = new HashMap();
/*  8672:10490 */     String alStatus = "";
/*  8673:10491 */     String afStatus = "";
/*  8674:10492 */     boolean canSetAF = true;
/*  8675:10493 */     boolean canSetAL = true;
/*  8676:10496 */     if (callingControl.getId().equalsIgnoreCase("pluscdsinstrpointsresultsT1"))
/*  8677:      */     {
/*  8678:10497 */       MobileMboDataBean pointDataBean = callingControl.getDataBean();
/*  8679:10498 */       MobileMbo pointMbo = pointDataBean.getMobileMbo(0);
/*  8680:10499 */       String dsplannum = pointMbo.getValue("DSPLANNUM");
/*  8681:10500 */       String siteid = pointMbo.getValue("SITEID");
/*  8682:10501 */       String revisionnum = pointMbo.getValue("REVISIONNUM");
/*  8683:10502 */       String wonum = pointMbo.getValue("WONUM");
/*  8684:      */       
/*  8685:10504 */       String wodsnum = pointMbo.getValue("WODSNUM");
/*  8686:      */       
/*  8687:10506 */       MobileMboDataBean dataBean = pluscgetpointsfords(dsplannum, siteid, revisionnum, wonum, wodsnum);
/*  8688:      */       
/*  8689:10508 */       int i = 0;
/*  8690:10509 */       while (i < dataBean.count())
/*  8691:      */       {
/*  8692:10510 */         dataBean.setCurrentPosition(i);
/*  8693:10511 */         MobileMboDataBean instrDataBean = dataBean.getDataBean("PLUSCWODSPOINTRLT");
/*  8694:      */         
/*  8695:      */ 
/*  8696:      */ 
/*  8697:      */ 
/*  8698:      */ 
/*  8699:      */ 
/*  8700:      */ 
/*  8701:      */ 
/*  8702:10520 */         afStatus = ((WOApp)UIUtil.getApplication()).getInternalValue(dataBean, "PLUSCCALSTATUS", instrDataBean.getMobileMbo().getValue("ASFOUNDCALSTATUS"));
/*  8703:10521 */         alStatus = ((WOApp)UIUtil.getApplication()).getInternalValue(dataBean, "PLUSCCALSTATUS", instrDataBean.getMobileMbo().getValue("ASLEFTCALSTATUS"));
/*  8704:10522 */         instrAFStatusMap.put(afStatus, afStatus);
/*  8705:10523 */         instrALStatusMap.put(alStatus, alStatus);
/*  8706:10524 */         canSetAF = !afStatus.equalsIgnoreCase("");
/*  8707:10525 */         canSetAL = !alStatus.equalsIgnoreCase("");
/*  8708:10526 */         i++;
/*  8709:      */       }
/*  8710:10528 */       setDSRowStatus(canSetAF ? instrAFStatusMap : null, canSetAL ? instrALStatusMap : null, null, null);
/*  8711:      */     }
/*  8712:10531 */     return true;
/*  8713:      */   }
/*  8714:      */   
/*  8715:      */   public boolean pluscdochangeview(UIEvent event)
/*  8716:      */     throws MobileApplicationException
/*  8717:      */   {
/*  8718:10544 */     String currentScreen = UIUtil.getCurrentScreen().getId();
/*  8719:      */     String pointType;
/*  8720:      */     String pointType;
/*  8721:10546 */     if (currentScreen.equals("pluscdscalpoints"))
/*  8722:      */     {
/*  8723:10547 */       pointType = "CALPOINT";
/*  8724:      */     }
/*  8725:      */     else
/*  8726:      */     {
/*  8727:      */       String pointType;
/*  8728:10548 */       if (currentScreen.equals("pluscdsfc"))
/*  8729:      */       {
/*  8730:10549 */         pointType = "CALFUNCTION";
/*  8731:      */       }
/*  8732:      */       else
/*  8733:      */       {
/*  8734:      */         String pointType;
/*  8735:10550 */         if (currentScreen.equals("pluscdsdc")) {
/*  8736:10551 */           pointType = "CALDYNAMIC";
/*  8737:      */         } else {
/*  8738:10553 */           pointType = "CALPOINT";
/*  8739:      */         }
/*  8740:      */       }
/*  8741:      */     }
/*  8742:10557 */     MobileMbo woMbo = pluscgetcurrentwombo();
/*  8743:      */     
/*  8744:      */ 
/*  8745:      */ 
/*  8746:10561 */     pluscchangeview(event, false, false, pointType);
/*  8747:10562 */     UIUtil.refreshCurrentScreen();
/*  8748:      */     
/*  8749:      */ 
/*  8750:10565 */     return true;
/*  8751:      */   }
/*  8752:      */   
/*  8753:      */   public MobileMbo pluscgetcurrentwombo()
/*  8754:      */     throws MobileApplicationException
/*  8755:      */   {
/*  8756:10578 */     MobileMboDataBean woDataBean = pluscgetcurrentwoset();
/*  8757:10579 */     MobileMbo woMbo = woDataBean.getMobileMbo(woDataBean.getCurrentPosition());
/*  8758:10580 */     return woMbo;
/*  8759:      */   }
/*  8760:      */   
/*  8761:      */   public boolean pluscsetaddpointvisibility(UIEvent event)
/*  8762:      */     throws MobileApplicationException
/*  8763:      */   {
/*  8764:10597 */     MobileMboDataBean pointDataBean = UIUtil.getCurrentScreen().getDataBean();
/*  8765:10598 */     MobileMbo pointMbo = pointDataBean.getMobileMbo(pointDataBean.getCurrentPosition());
/*  8766:10599 */     MobileMbo instrMbo = pluscgetinstrmboforpoint(pointMbo);
/*  8767:10600 */     MobileMboDataBean woDataBean = pluscgetcurrentwoset();
/*  8768:10601 */     String status = woDataBean.getValue("STATUS");
/*  8769:10602 */     String intStatus = pluscGetWoInternalStatus(status, woDataBean);
/*  8770:10604 */     if ((!instrMbo.getBooleanValue("ALLOWPOINTINSERTS")) || (!intStatus.equalsIgnoreCase("APPR"))) {
/*  8771:10605 */       return pluscsetinvisible(event);
/*  8772:      */     }
/*  8773:10608 */     return false;
/*  8774:      */   }
/*  8775:      */   
/*  8776:      */   public boolean pluscshowchangeviewbutton(UIEvent event)
/*  8777:      */     throws MobileApplicationException
/*  8778:      */   {
/*  8779:10622 */     AbstractMobileControl thiscontrol = (AbstractMobileControl)event.getCreatingObject();
/*  8780:10623 */     AbstractMobileControl parentcontrol = thiscontrol.getParentControl();
/*  8781:10624 */     AbstractMobileControl tabparentcontrol = parentcontrol.getParentControl().getParentControl();
/*  8782:10625 */     MobileMbo woMbo = pluscgetcurrentwombo();
/*  8783:10629 */     if ((tabparentcontrol != null) && ((tabparentcontrol.getId().equalsIgnoreCase("pluscdsassetfunctions")) || (tabparentcontrol.getId().equalsIgnoreCase("pluscdsafresultstbl")))) {
/*  8784:10633 */       return pluscsetinvisible(event);
/*  8785:      */     }
/*  8786:10635 */     return true;
/*  8787:      */   }
/*  8788:      */   
/*  8789:      */   public boolean pluscinitcp(UIEvent event)
/*  8790:      */     throws MobileApplicationException
/*  8791:      */   {
/*  8792:10642 */     return true;
/*  8793:      */   }
/*  8794:      */   
/*  8795:      */   public boolean pluscsetinputoutputeditable(UIEvent event)
/*  8796:      */     throws MobileApplicationException
/*  8797:      */   {
/*  8798:10657 */     AbstractMobileControl currentControl = (AbstractMobileControl)event.getCreatingObject();
/*  8799:10658 */     boolean readonly = false;
/*  8800:10660 */     if ((!plusccaneditasfoundasleftfields()) || (pluscgetplantype().equalsIgnoreCase("DISCRETE"))) {
/*  8801:10661 */       readonly = true;
/*  8802:      */     }
/*  8803:10664 */     currentControl.setReadonly(readonly);
/*  8804:      */     
/*  8805:10666 */     return true;
/*  8806:      */   }
/*  8807:      */   
/*  8808:      */   public boolean plusccaneditasfoundasleftfields()
/*  8809:      */     throws MobileApplicationException
/*  8810:      */   {
/*  8811:10671 */     return (canEditAsFoundAsLeftInStatus()) && (canEditAssetFunction());
/*  8812:      */   }
/*  8813:      */   
/*  8814:      */   public boolean canEditAsFoundAsLeftInStatus()
/*  8815:      */     throws MobileApplicationException
/*  8816:      */   {
/*  8817:10684 */     MobileMboDataBean woDataBean = DataBeanCache.getDataBean("WORKORDER", "WORKORDER");
/*  8818:10685 */     MobileMbo woMbo = woDataBean.getMobileMbo(woDataBean.getCurrentPosition());
/*  8819:10688 */     if (!UIUtil.getApplication().isOptionAuthorized("PLUSCENTERDS")) {
/*  8820:10689 */       return false;
/*  8821:      */     }
/*  8822:10692 */     MobileMbo editsetMbo = null;
/*  8823:10693 */     HashMap statusMap = new HashMap();
/*  8824:      */     
/*  8825:10695 */     MobileMboDataBean editsetDataBean = DataBeanCache.getDataBean("WPEDITSETTING", "WPEDITSETTING");
/*  8826:10696 */     editsetDataBean.getQBE().setQbeExactMatch(true);
/*  8827:10697 */     editsetDataBean.getQBE().setQBE("ORGID", woMbo.getValue("ORGID"));
/*  8828:10698 */     editsetDataBean.reset();
/*  8829:10699 */     int size = editsetDataBean.count();
/*  8830:10701 */     for (int i = 0; i <= size; i++)
/*  8831:      */     {
/*  8832:10703 */       editsetDataBean.setCurrentPosition(i);
/*  8833:10704 */       editsetMbo = editsetDataBean.getMobileMbo();
/*  8834:10705 */       statusMap.put(editsetMbo.getValue("STATUS"), editsetMbo.getValue("PLUSCEDITAFAL"));
/*  8835:      */     }
/*  8836:10708 */     String woStatus = ((WOApp)UIUtil.getApplication()).getInternalValue(woDataBean, "WOSTATUS", woMbo.getValue("STATUS"));
/*  8837:      */     
/*  8838:      */ 
/*  8839:10711 */     String canEdit = (String)statusMap.get(woStatus);
/*  8840:10712 */     boolean caneditasfoundasleft = (canEdit != null) && (canEdit.equals("1"));
/*  8841:10713 */     return caneditasfoundasleft;
/*  8842:      */   }
/*  8843:      */   
/*  8844:      */   public boolean pluscsetunitseditable(UIEvent event)
/*  8845:      */     throws MobileApplicationException
/*  8846:      */   {
/*  8847:10728 */     AbstractMobileControl currentControl = (AbstractMobileControl)event.getCreatingObject();
/*  8848:10729 */     boolean readonly = true;
/*  8849:      */     
/*  8850:10731 */     currentControl.setReadonly(readonly);
/*  8851:      */     
/*  8852:10733 */     return true;
/*  8853:      */   }
/*  8854:      */   
/*  8855:      */   public boolean pluscsetsetpointeditable(UIEvent event)
/*  8856:      */     throws MobileApplicationException
/*  8857:      */   {
/*  8858:10744 */     pluscformatnumber(event);
/*  8859:      */     
/*  8860:      */ 
/*  8861:      */ 
/*  8862:      */ 
/*  8863:10749 */     return true;
/*  8864:      */   }
/*  8865:      */   
/*  8866:      */   public boolean pluscformatnumber(UIEvent event)
/*  8867:      */     throws MobileApplicationException
/*  8868:      */   {
/*  8869:10765 */     MobileMboDataBean pointDataBean = UIUtil.getCurrentScreen().getDataBean();
/*  8870:10766 */     MobileMbo pointMbo = pointDataBean.getMobileMbo(pointDataBean.getCurrentPosition());
/*  8871:10767 */     MobileMbo instrMbo = pluscgetinstrmboforpoint(pointMbo);
/*  8872:10768 */     TextboxControl eventSource = (TextboxControl)event.getCreatingObject();
/*  8873:10769 */     String fieldName = eventSource.getControlData().getValue("dataattribute");
/*  8874:      */     
/*  8875:10771 */     int inputmfr = 0;
/*  8876:10772 */     int outputmfr = 0;
/*  8877:10774 */     if ((instrMbo.getValue("INPUTPRECISION") != null) && (!instrMbo.getValue("INPUTPRECISION").equalsIgnoreCase(""))) {
/*  8878:10775 */       inputmfr = Integer.parseInt(instrMbo.getValue("INPUTPRECISION"));
/*  8879:      */     }
/*  8880:10786 */     if ((instrMbo.getValue("OUTPUTPRECISION") != null) && (!instrMbo.getValue("OUTPUTPRECISION").equalsIgnoreCase(""))) {
/*  8881:10787 */       outputmfr = Integer.parseInt(instrMbo.getValue("OUTPUTPRECISION"));
/*  8882:      */     }
/*  8883:10798 */     String formatedValue = "";
/*  8884:10799 */     if (!pointMbo.getValue(fieldName).equalsIgnoreCase("")) {
/*  8885:10804 */       if ((fieldName.indexOf("INPUT") != -1) || (fieldName.indexOf("SETPOINT") != -1)) {
/*  8886:10806 */         formatedValue = PlusCToolKitTOCommon.formatDouble(fieldName, pointMbo.getValue(fieldName), inputmfr, Locale.getDefault());
/*  8887:      */       } else {
/*  8888:10809 */         formatedValue = PlusCToolKitTOCommon.formatDouble(fieldName, pointMbo.getValue(fieldName), outputmfr, Locale.getDefault());
/*  8889:      */       }
/*  8890:      */     }
/*  8891:10813 */     pointMbo.setValue(fieldName, formatedValue);
/*  8892:      */     
/*  8893:      */ 
/*  8894:      */ 
/*  8895:10817 */     return false;
/*  8896:      */   }
/*  8897:      */   
/*  8898:      */   public boolean pluscsetsetpointactioneditable(UIEvent event)
/*  8899:      */     throws MobileApplicationException
/*  8900:      */   {
/*  8901:10832 */     AbstractMobileControl currentControl = (AbstractMobileControl)event.getCreatingObject();
/*  8902:10833 */     boolean readonly = false;
/*  8903:10835 */     if ((!plusccaneditasfoundasleftfields()) || (pluscgetplantype().equalsIgnoreCase("ANALOG"))) {
/*  8904:10836 */       readonly = true;
/*  8905:      */     }
/*  8906:10839 */     currentControl.setReadonly(readonly);
/*  8907:10840 */     return true;
/*  8908:      */   }
/*  8909:      */   
/*  8910:      */   private boolean displayAsLeftInput(UIEvent event)
/*  8911:      */     throws MobileApplicationException
/*  8912:      */   {
/*  8913:10852 */     pluscformatnumber(event);
/*  8914:      */     
/*  8915:10854 */     return true;
/*  8916:      */   }
/*  8917:      */   
/*  8918:      */   public boolean pluscdsselectfromengunitvalues(UIEvent event)
/*  8919:      */     throws MobileApplicationException
/*  8920:      */   {
/*  8921:10867 */     setQbeValues("PLUSCDSINSTR.INSTRCALRANGEEU", "VALUE");
/*  8922:      */     
/*  8923:10869 */     UIUtil.getApplication().removeCurrentScreen(true);
/*  8924:10870 */     return true;
/*  8925:      */   }
/*  8926:      */   
/*  8927:      */   public boolean pluscdsselecttoengunitvalues(UIEvent event)
/*  8928:      */     throws MobileApplicationException
/*  8929:      */   {
/*  8930:10883 */     setQbeValues("PLUSCDSINSTR.INSTROUTRANGEEU", "VALUE");
/*  8931:      */     
/*  8932:10885 */     UIUtil.getApplication().removeCurrentScreen(true);
/*  8933:10886 */     return true;
/*  8934:      */   }
/*  8935:      */   
/*  8936:      */   public boolean pluscdsselectstatusvalues(UIEvent event)
/*  8937:      */     throws MobileApplicationException
/*  8938:      */   {
/*  8939:10900 */     setQbeValues("STATUS", "VALUE");
/*  8940:10901 */     UIUtil.getApplication().removeCurrentScreen(true);
/*  8941:10902 */     return true;
/*  8942:      */   }
/*  8943:      */   
/*  8944:      */   public boolean pluscinitWOAssetPage(UIEvent event)
/*  8945:      */     throws MobileApplicationException
/*  8946:      */   {
/*  8947:10917 */     AbstractMobileControl thisPage = UIUtil.getCurrentScreen();
/*  8948:10918 */     AbstractMobileControl ancestorControl = ((PageControl)thisPage).getLaunchingControl();
/*  8949:10920 */     if (ancestorControl.getId().equalsIgnoreCase("pluscdsresultsT1s2r1c1l1"))
/*  8950:      */     {
/*  8951:10924 */       MobileMboDataBean databean = ((PageControl)event.getCreatingObject()).getDataBean();
/*  8952:10925 */       if (databean != null)
/*  8953:      */       {
/*  8954:10926 */         String fieldname = "ASSETNUM";
/*  8955:      */         
/*  8956:      */ 
/*  8957:10929 */         MobileMboDataBean srcdatabean = UIUtil.getCurrentScreen().getDataBean();
/*  8958:      */         
/*  8959:10931 */         databean.getQBE().reset();
/*  8960:10932 */         databean.getQBE().setQbeExactMatch(true);
/*  8961:10934 */         if (srcdatabean.getValue(fieldname) == "") {
/*  8962:10935 */           databean.getQBE().setQBE("ASSETNUM", "~NULL~");
/*  8963:      */         } else {
/*  8964:10937 */           databean.getQBE().setQBE("ASSETNUM", srcdatabean.getValue(fieldname));
/*  8965:      */         }
/*  8966:10938 */         databean.getQBE().setQBE("SITEID", srcdatabean.getValue("SITEID"));
/*  8967:10939 */         databean.reset();
/*  8968:10940 */         if (databean.getMobileMbo(0) != null) {
/*  8969:10941 */           databean.setCurrentPosition(0);
/*  8970:      */         }
/*  8971:      */       }
/*  8972:10945 */       return true;
/*  8973:      */     }
/*  8974:10947 */     return initWOAssetPage(event);
/*  8975:      */   }
/*  8976:      */   
/*  8977:      */   public boolean pluscinitdsstatus(UIEvent event)
/*  8978:      */     throws MobileApplicationException
/*  8979:      */   {
/*  8980:10962 */     String[] readOnlyFields = { "ASFOUNDCALSTATUS", "ASFOUNDCOMMENTS", "ASLEFTCALSTATUS", "ASLEFTCOMMENTS", "ASFOUNDCOMMENTS_LONGDESCRIPTION", "ASLEFTCOMMENTS_LONGDESCRIPTION" };
/*  8981:      */     
/*  8982:      */ 
/*  8983:      */ 
/*  8984:10966 */     MobileMboDataBean dsStatusDataBean = DataBeanCache.getDataBean("PLUSCWODS", "PLUSCWODS");
/*  8985:      */     
/*  8986:      */ 
/*  8987:10969 */     calcWoDsStatusWithoutSend(event, dsStatusDataBean, null);
/*  8988:      */     
/*  8989:      */ 
/*  8990:      */ 
/*  8991:      */ 
/*  8992:      */ 
/*  8993:      */ 
/*  8994:      */ 
/*  8995:      */ 
/*  8996:      */ 
/*  8997:      */ 
/*  8998:      */ 
/*  8999:      */ 
/*  9000:      */ 
/*  9001:      */ 
/*  9002:      */ 
/*  9003:      */ 
/*  9004:10986 */     boolean state = false;
/*  9005:10988 */     if (!plusccaneditasfoundasleftfields()) {
/*  9006:10990 */       state = true;
/*  9007:      */     }
/*  9008:10993 */     setPlusCFieldsReadOnly(UIUtil.getCurrentScreen(), dsStatusDataBean, readOnlyFields, state);
/*  9009:      */     
/*  9010:      */ 
/*  9011:10996 */     return true;
/*  9012:      */   }
/*  9013:      */   
/*  9014:      */   protected void calcWoDsStatusWithoutSend(UIEvent event, MobileMboDataBean wodsBean, String instrSeq)
/*  9015:      */     throws MobileApplicationException
/*  9016:      */   {
/*  9017:11003 */     boolean calculateDsStatus = true;
/*  9018:11004 */     MobileMbo dsMbo = wodsBean.getMobileMbo(wodsBean.getCurrentPosition());
/*  9019:11005 */     MobileMboDataBeanManager instrmgrDsPoints = new MobileMboDataBeanManager("PLUSCWODSPOINT");
/*  9020:11006 */     MobileMboDataBean instrPointBean = instrmgrDsPoints.getDataBean();
/*  9021:      */     
/*  9022:11008 */     instrPointBean.getQBE().reset();
/*  9023:11009 */     instrPointBean.getQBE().setQbeExactMatch(true);
/*  9024:11010 */     instrPointBean.getQBE().setQBE("DSPLANNUM", dsMbo.getValue("DSPLANNUM"));
/*  9025:11011 */     instrPointBean.getQBE().setQBE("SITEID", dsMbo.getValue("SITEID"));
/*  9026:11012 */     instrPointBean.getQBE().setQBE("REVISIONNUM", dsMbo.getValue("REVISIONNUM"));
/*  9027:11014 */     if ((instrSeq != null) && (!instrSeq.equalsIgnoreCase("")))
/*  9028:      */     {
/*  9029:11015 */       instrPointBean.getQBE().setQBE("INSTRSEQ", instrSeq);
/*  9030:11016 */       calculateDsStatus = false;
/*  9031:      */     }
/*  9032:11019 */     instrPointBean.getQBE().setQBE("WONUM", dsMbo.getValue("WONUM"));
/*  9033:      */     
/*  9034:      */ 
/*  9035:11022 */     instrPointBean.getQBE().setQBE("WODSNUM", dsMbo.getValue("WODSNUM"));
/*  9036:      */     
/*  9037:11024 */     instrPointBean.reset();
/*  9038:      */     
/*  9039:      */ 
/*  9040:      */ 
/*  9041:      */ 
/*  9042:11029 */     pluscupdatedsstatus(instrPointBean, wodsBean, dsMbo, event, calculateDsStatus);
/*  9043:      */     
/*  9044:      */ 
/*  9045:      */ 
/*  9046:      */ 
/*  9047:11034 */     UIUtil.getApplication().updateMobileMbo(dsMbo.getName(), dsMbo);
/*  9048:      */   }
/*  9049:      */   
/*  9050:      */   public void pluscupdatedsstatus(MobileMboDataBean pointsDataBean, MobileMboDataBean woDSBean, MobileMbo woDsMbo, UIEvent event, boolean calculateDSStatus)
/*  9051:      */     throws MobileApplicationException
/*  9052:      */   {
/*  9053:11054 */     HashMap instrAFStatusMap = new HashMap();
/*  9054:11055 */     HashMap instrALStatusMap = new HashMap();
/*  9055:11056 */     HashMap instrSeqs = new HashMap();
/*  9056:11057 */     String alStatus = "";
/*  9057:11058 */     String afStatus = "";
/*  9058:11059 */     boolean canSetAF = true;
/*  9059:11060 */     boolean canSetAL = true;
/*  9060:11061 */     MobileMboDataBean instrDataBean = null;
/*  9061:11062 */     MobileMbo instrMbo = null;
/*  9062:11063 */     int i = 0;
/*  9063:      */     
/*  9064:11065 */     int count = pointsDataBean.count();
/*  9065:11066 */     while (i < count)
/*  9066:      */     {
/*  9067:11069 */       MobileMbo mboPoint = pointsDataBean.getMobileMbo(i);
/*  9068:11070 */       String instrFunct = mboPoint.getValue("INSTRSEQ");
/*  9069:11072 */       if (instrSeqs.get(instrFunct) == null)
/*  9070:      */       {
/*  9071:11073 */         instrDataBean = pluscgetinstrbeanforpoint(mboPoint);
/*  9072:11074 */         instrSeqs.put(instrFunct, instrFunct);
/*  9073:      */       }
/*  9074:11084 */       instrMbo = pluscupdateinstrstatus(event, instrDataBean, pointsDataBean);
/*  9075:11103 */       if (instrMbo.getBooleanValue("CALDYNAMIC"))
/*  9076:      */       {
/*  9077:11105 */         UIUtil.getApplication().updateMobileMbo(instrMbo.getName(), instrMbo);
/*  9078:11106 */         i++;
/*  9079:      */       }
/*  9080:      */       else
/*  9081:      */       {
/*  9082:11112 */         afStatus = instrMbo.getValue("ASFOUNDCALSTATUS");
/*  9083:11113 */         alStatus = instrMbo.getValue("ASLEFTCALSTATUS");
/*  9084:      */         
/*  9085:      */ 
/*  9086:      */ 
/*  9087:11117 */         instrAFStatusMap.put(afStatus, afStatus);
/*  9088:11118 */         instrALStatusMap.put(alStatus, alStatus);
/*  9089:11119 */         canSetAF = !afStatus.equalsIgnoreCase("");
/*  9090:11120 */         canSetAL = !alStatus.equalsIgnoreCase("");
/*  9091:      */         
/*  9092:      */ 
/*  9093:11123 */         UIUtil.getApplication().updateMobileMbo(instrMbo.getName(), instrMbo);
/*  9094:      */         
/*  9095:11125 */         i++;
/*  9096:      */       }
/*  9097:      */     }
/*  9098:11127 */     if (calculateDSStatus) {
/*  9099:11127 */       setDSRowStatus(canSetAF ? instrAFStatusMap : null, canSetAL ? instrALStatusMap : null, woDSBean, woDsMbo);
/*  9100:      */     }
/*  9101:      */   }
/*  9102:      */   
/*  9103:      */   public boolean pluscerrorrowstyle(UIEvent event)
/*  9104:      */     throws MobileApplicationException
/*  9105:      */   {
/*  9106:11144 */     MobileMboDataBean pointDataBean = DataBeanCache.getDataBean("PLUSCWODSPOINT", "PLUSCWODSPOINT");
/*  9107:11145 */     MobileMbo pointMbo = pointDataBean.getMobileMbo(pointDataBean.getCurrentPosition());
/*  9108:      */     
/*  9109:11147 */     PlusCMobileWODsPointDelegate woDsPoint = new PlusCMobileWODsPointDelegate(new MobileMboAdapter(pointMbo, pointDataBean), null);
/*  9110:11148 */     boolean hasErrors = false;
/*  9111:      */     try
/*  9112:      */     {
/*  9113:11151 */       hasErrors = woDsPoint.hasErrors();
/*  9114:      */     }
/*  9115:      */     catch (Exception e)
/*  9116:      */     {
/*  9117:11153 */       MobileMboAdapter.wrapException(e);
/*  9118:      */     }
/*  9119:11156 */     pluscfailrowstyle(event);
/*  9120:11158 */     if (hasErrors) {
/*  9121:11159 */       event.setValue(StyleManager.getStyle("rowincomplete.table", null));
/*  9122:11166 */     } else if (pointMbo.isModified()) {
/*  9123:11167 */       event.setValue(StyleManager.getStyle("rowmodified.table", null));
/*  9124:      */     } else {
/*  9125:11169 */       event.setValue(StyleManager.getDefaultStyle());
/*  9126:      */     }
/*  9127:11172 */     return true;
/*  9128:      */   }
/*  9129:      */   
/*  9130:      */   public boolean pluscdsfailrowstyle(UIEvent event)
/*  9131:      */     throws MobileApplicationException
/*  9132:      */   {
/*  9133:11185 */     AbstractMobileControl thisControl = (AbstractMobileControl)event.getCreatingObject();
/*  9134:11186 */     MobileMbo wodsMbo = thisControl.getDataBean().getMobileMbo(thisControl.getDataBean().getCurrentPosition());
/*  9135:11187 */     int howToSet = wodsMbo.isModified() ? 1 : 2;
/*  9136:11189 */     if ((pluscgetcalstatus("ASLEFTCALSTATUS").equalsIgnoreCase("FAIL")) || (pluscgetcalstatus("ASFOUNDCALSTATUS").equalsIgnoreCase("FAIL"))) {
/*  9137:11190 */       event.setValue(StyleManager.getStyle("rowincomplete.table", null));
/*  9138:      */     } else {
/*  9139:11193 */       switch (howToSet)
/*  9140:      */       {
/*  9141:      */       case 1: 
/*  9142:11195 */         event.setValue(StyleManager.getStyle("rowmodified.table", null));
/*  9143:11196 */         break;
/*  9144:      */       case 2: 
/*  9145:11198 */         event.setValue(StyleManager.getDefaultStyle());
/*  9146:11199 */         break;
/*  9147:      */       }
/*  9148:      */     }
/*  9149:11206 */     return true;
/*  9150:      */   }
/*  9151:      */   
/*  9152:      */   public boolean pluscnoadjmade(UIEvent event)
/*  9153:      */     throws MobileApplicationException
/*  9154:      */   {
/*  9155:11219 */     MobileMbo woMbo = pluscgetcurrentwombo();
/*  9156:11220 */     boolean noAdjMade = new Boolean((String)event.getValue()).booleanValue();
/*  9157:      */     
/*  9158:11222 */     MobileMboDataBean pluscwodsinstrDataBean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*  9159:11223 */     MobileMbo pluscwodsinstrMbo = pluscwodsinstrDataBean.getMobileMbo(pluscwodsinstrDataBean.getCurrentPosition());
/*  9160:      */     
/*  9161:      */ 
/*  9162:11226 */     DataBeanCache.getDataBean("PLUSCWODSPOINT", "PLUSCWODSPOINT").getDataBeanManager().save();
/*  9163:      */     
/*  9164:11228 */     MobileMboDataBean pluscwodsinstrpointsDataBean = null;
/*  9165:      */     
/*  9166:11230 */     PlusCWODsInstrDelegate woDsInstr = new PlusCMobileWODsInstrDelegate(new MobileMboAdapter(pluscwodsinstrMbo, pluscwodsinstrDataBean));
/*  9167:      */     try
/*  9168:      */     {
/*  9169:11232 */       pluscwodsinstrpointsDataBean = ((MobileMboSetAdapter)woDsInstr.getWODsPointSet(false)).getDataBean();
/*  9170:      */     }
/*  9171:      */     catch (Exception e)
/*  9172:      */     {
/*  9173:11233 */       MobileMboAdapter.wrapException(e);
/*  9174:      */     }
/*  9175:11236 */     pluscvalidatenoadjmade(noAdjMade, woDsInstr, event);
/*  9176:      */     
/*  9177:11238 */     int ploop = 0;
/*  9178:11240 */     if (noAdjMade)
/*  9179:      */     {
/*  9180:11243 */       woMbo.setValue("PLUSCISMOBILE", "1");
/*  9181:      */       
/*  9182:      */ 
/*  9183:      */ 
/*  9184:11247 */       String[] noAdjMadeReadOnlyFields = { "ASFOUNDINPUT", "ASFOUNDOUTPUT", "ASFOUNDSETPOINT", "ASLEFTINPUT", "ASLEFTOUTPUT", "ASLEFTSETPOINT" };
/*  9185:      */       MobileMbo pluscwodsinstrpointsMbo;
/*  9186:11249 */       while ((pluscwodsinstrpointsMbo = pluscwodsinstrpointsDataBean.getMobileMbo(ploop)) != null)
/*  9187:      */       {
/*  9188:11250 */         pluscwodsinstrpointsMbo.setValue("ASLEFTINPUT", pluscwodsinstrpointsMbo.getValue("ASFOUNDINPUT"), false);
/*  9189:11251 */         pluscwodsinstrpointsMbo.setValue("ASLINPUTSTDDEV", pluscwodsinstrpointsMbo.getValue("ASFINPUTSTDDEV"), false);
/*  9190:11252 */         pluscwodsinstrpointsMbo.setValue("ASLEFTOUTPUT", pluscwodsinstrpointsMbo.getValue("ASFOUNDOUTPUT"), false);
/*  9191:11253 */         pluscwodsinstrpointsMbo.setValue("ASLOUTPUTSTDDEV", pluscwodsinstrpointsMbo.getValue("ASFOUTPUTSTDDEV"), false);
/*  9192:11254 */         pluscwodsinstrpointsMbo.setValue("ASLEFTSETPOINT", pluscwodsinstrpointsMbo.getValue("ASFOUNDSETPOINT"), false);
/*  9193:11255 */         pluscwodsinstrpointsMbo.setValue("ASLSETPTSTDDEV", pluscwodsinstrpointsMbo.getValue("ASFSETPTSTDDEV"), false);
/*  9194:11256 */         pluscwodsinstrpointsMbo.setValue("ASLEFTOUTERROR", pluscwodsinstrpointsMbo.getValue("ASFOUNDOUTERROR"), false);
/*  9195:11257 */         pluscwodsinstrpointsMbo.setValue("ASLEFTPROERROR", pluscwodsinstrpointsMbo.getValue("ASFOUNDPROERROR"), false);
/*  9196:11259 */         for (int i = 1; i < 5; i++)
/*  9197:      */         {
/*  9198:11260 */           pluscwodsinstrpointsMbo.setValue("ASLEFTTOL" + i + "LOWER", pluscwodsinstrpointsMbo.getValue("ASFOUNDTOL" + i + "LOWER"), false);
/*  9199:11261 */           pluscwodsinstrpointsMbo.setValue("ASLEFTTOL" + i + "UPPER", pluscwodsinstrpointsMbo.getValue("ASFOUNDTOL" + i + "UPPER"), false);
/*  9200:11262 */           pluscwodsinstrpointsMbo.setValue("ASLEFTERROR" + i, pluscwodsinstrpointsMbo.getValue("ASFOUNDERROR" + i), false);
/*  9201:      */         }
/*  9202:11266 */         UIUtil.getApplication().updateMobileMbo("PLUSCWODSPOINT", pluscwodsinstrpointsMbo);
/*  9203:      */         
/*  9204:      */ 
/*  9205:11269 */         setMobileMboFieldsReadOnly(pluscwodsinstrpointsMbo, noAdjMadeReadOnlyFields, true);
/*  9206:      */         
/*  9207:11271 */         ploop++;
/*  9208:      */       }
/*  9209:      */     }
/*  9210:      */     else
/*  9211:      */     {
/*  9212:11276 */       woMbo.setValue("PLUSCISMOBILE", "0");
/*  9213:      */       
/*  9214:      */ 
/*  9215:      */ 
/*  9216:11280 */       String[] analogPointEditableFields = { "ASFOUNDINPUT", "ASLEFTINPUT", "ASFOUNDOUTPUT", "ASLEFTOUTPUT" };
/*  9217:11281 */       String[] discretePointEditableFields = { "ASFOUNDSETPOINT", "ASLEFTSETPOINT" };
/*  9218:      */       MobileMbo pluscwodsinstrpointsMbo;
/*  9219:11283 */       while ((pluscwodsinstrpointsMbo = pluscwodsinstrpointsDataBean.getMobileMbo(ploop)) != null)
/*  9220:      */       {
/*  9221:11285 */         pluscwodsinstrpointsMbo.setValue("ASLEFTINPUT", "", false);
/*  9222:11286 */         pluscwodsinstrpointsMbo.setValue("ASLEFTOUTPUT", "", false);
/*  9223:11287 */         pluscwodsinstrpointsMbo.setValue("ASLEFTSETPOINT", "", false);
/*  9224:11288 */         pluscwodsinstrpointsMbo.setValue("ASLINPUTSTDDEV", "", false);
/*  9225:11289 */         pluscwodsinstrpointsMbo.setValue("ASLOUTPUTSTDDEV", "", false);
/*  9226:11290 */         pluscwodsinstrpointsMbo.setValue("ASLSETPTSTDDEV", "", false);
/*  9227:11291 */         pluscwodsinstrpointsMbo.setValue("ASLEFTOUTERROR", "", false);
/*  9228:11292 */         pluscwodsinstrpointsMbo.setValue("ASLEFTPROERROR", "", false);
/*  9229:11294 */         for (int i = 1; i < 5; i++)
/*  9230:      */         {
/*  9231:11295 */           pluscwodsinstrpointsMbo.setValue("ASLEFTTOL" + i + "LOWER", "", false);
/*  9232:11296 */           pluscwodsinstrpointsMbo.setValue("ASLEFTTOL" + i + "UPPER", "", false);
/*  9233:11297 */           pluscwodsinstrpointsMbo.setValue("ASLEFTERROR" + i, "", false);
/*  9234:      */         }
/*  9235:11300 */         if (pluscwodsinstrpointsMbo.getValue("PLANTYPE").equalsIgnoreCase("ANALOG")) {
/*  9236:11301 */           setMobileMboFieldsReadOnly(pluscwodsinstrMbo, analogPointEditableFields, false);
/*  9237:      */         }
/*  9238:11302 */         if (pluscwodsinstrpointsMbo.getValue("PLANTYPE").equalsIgnoreCase("DISCRETE")) {
/*  9239:11303 */           setMobileMboFieldsReadOnly(pluscwodsinstrMbo, discretePointEditableFields, false);
/*  9240:      */         }
/*  9241:11306 */         UIUtil.getApplication().updateMobileMbo("PLUSCWODSPOINT", pluscwodsinstrpointsMbo);
/*  9242:      */         
/*  9243:11308 */         ploop++;
/*  9244:      */       }
/*  9245:      */     }
/*  9246:11312 */     pluscwodsinstrMbo.setBooleanValue("NOADJMADE", noAdjMade, false);
/*  9247:      */     
/*  9248:      */ 
/*  9249:11315 */     MobileMboDataBean cachedPointBean = DataBeanCache.getDataBean("PLUSCWODSPOINT", "PLUSCWODSPOINT");
/*  9250:11316 */     int cachedPosition = cachedPointBean.getCurrentPosition();
/*  9251:11317 */     DataBeanCache.getDataBean("PLUSCWODSPOINT", "PLUSCWODSPOINT").reset();
/*  9252:11318 */     cachedPointBean.setCurrentPosition(cachedPosition);
/*  9253:      */     
/*  9254:11320 */     pluscupdateinstrstatus(event, pluscwodsinstrDataBean, cachedPointBean);
/*  9255:      */     
/*  9256:      */ 
/*  9257:11323 */     UIUtil.getApplication().updateMobileMbo("PLUSCWODSINSTR", pluscwodsinstrMbo);
/*  9258:      */     
/*  9259:11325 */     pluscupdatedsstatus(cachedPointBean, DataBeanCache.getDataBean("PLUSCWODS", "PLUSCWODS"), null, event, true);
/*  9260:      */     
/*  9261:11327 */     return true;
/*  9262:      */   }
/*  9263:      */   
/*  9264:      */   public boolean pluscsaveclose(UIEvent event)
/*  9265:      */     throws MobileApplicationException
/*  9266:      */   {
/*  9267:11334 */     PageControl thisPage = (PageControl)UIUtil.getCurrentScreen();
/*  9268:      */     
/*  9269:11336 */     MobileMboDataBean dataBean = thisPage.getDataBean();
/*  9270:      */     
/*  9271:11338 */     markParentsModified(dataBean);
/*  9272:      */     
/*  9273:      */ 
/*  9274:      */ 
/*  9275:      */ 
/*  9276:      */ 
/*  9277:      */ 
/*  9278:      */ 
/*  9279:      */ 
/*  9280:11347 */     UIUtil.refreshCurrentScreen();
/*  9281:11348 */     UIUtil.getApplication().removeCurrentScreen(true);
/*  9282:      */     
/*  9283:11350 */     MobileMboDataBean instrBean = pluscgetcleaninstrdatabean(dataBean.getMobileMbo(), false);
/*  9284:11351 */     DataBeanCacheItem item = new DataBeanCacheItem("PLUSCWODSINSTR", "PLUSCWODSINSTR", instrBean);
/*  9285:11352 */     DataBeanCache.cacheDataBean("PLUSCWODSINSTR", item);
/*  9286:      */     
/*  9287:      */ 
/*  9288:11355 */     return true;
/*  9289:      */   }
/*  9290:      */   
/*  9291:      */   private boolean displayAsLeftOutput(UIEvent event)
/*  9292:      */     throws MobileApplicationException
/*  9293:      */   {
/*  9294:11373 */     pluscformatnumber(event);
/*  9295:      */     
/*  9296:11375 */     return true;
/*  9297:      */   }
/*  9298:      */   
/*  9299:      */   private boolean validateLocation(UIEvent event)
/*  9300:      */     throws MobileApplicationException
/*  9301:      */   {
/*  9302:11384 */     MobileMboDataBean dataBean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*  9303:11385 */     MobileMbo woMbo = dataBean.getMobileMbo();
/*  9304:      */     
/*  9305:      */ 
/*  9306:11388 */     woMbo.setValue("LOCATION", (String)event.getValue());
/*  9307:      */     
/*  9308:11390 */     PlusCWODelegate wo = new PlusCMobileWODelegate(new MobileMboAdapter(woMbo, dataBean));
/*  9309:      */     try
/*  9310:      */     {
/*  9311:11393 */       wo.copyLoopFlagFromLocation();
/*  9312:      */     }
/*  9313:      */     catch (Exception e)
/*  9314:      */     {
/*  9315:11395 */       MobileMboAdapter.wrapException(e);
/*  9316:      */     }
/*  9317:11397 */     return true;
/*  9318:      */   }
/*  9319:      */   
/*  9320:      */   private boolean initWODsDetails(UIEvent event)
/*  9321:      */     throws MobileApplicationException
/*  9322:      */   {
/*  9323:11408 */     setDSUncertReadOnlyFields(event);
/*  9324:11409 */     return woDsApplyRequiredRules();
/*  9325:      */   }
/*  9326:      */   
/*  9327:      */   protected void setDSUncertReadOnlyFields(UIEvent event)
/*  9328:      */     throws MobileApplicationException
/*  9329:      */   {
/*  9330:11413 */     if ((event.getCreatingObject() instanceof AbstractMobileControl))
/*  9331:      */     {
/*  9332:11414 */       MobileMbo woDS = ((AbstractMobileControl)event.getCreatingObject()).getDataBean().getMobileMbo();
/*  9333:11415 */       if (woDS != null)
/*  9334:      */       {
/*  9335:11416 */         String[] fields = DS_UNCERTAINTY_FIELDS;
/*  9336:11417 */         setUncertReadOnlyFields(woDS, fields);
/*  9337:      */       }
/*  9338:      */     }
/*  9339:      */   }
/*  9340:      */   
/*  9341:      */   protected void setInstrUncertReadOnlyFields(UIEvent event)
/*  9342:      */     throws MobileApplicationException
/*  9343:      */   {
/*  9344:11423 */     if ((event.getCreatingObject() instanceof AbstractMobileControl))
/*  9345:      */     {
/*  9346:11424 */       MobileMbo woInstr = ((AbstractMobileControl)event.getCreatingObject()).getDataBean().getMobileMbo();
/*  9347:11425 */       if (woInstr != null)
/*  9348:      */       {
/*  9349:11426 */         String[] fields = INSTR_UNCERTAINTY_FIELDS;
/*  9350:11427 */         setUncertReadOnlyFields(woInstr, fields);
/*  9351:      */       }
/*  9352:      */     }
/*  9353:      */   }
/*  9354:      */   
/*  9355:      */   protected boolean woDsApplyRequiredRules()
/*  9356:      */     throws MobileApplicationException
/*  9357:      */   {
/*  9358:11438 */     MobileMboDataBean woDsDataBean = DataBeanCache.getDataBean("PLUSCWODS", "PLUSCWODS");
/*  9359:11439 */     PlusCWODsSetDelegate woDsSet = new PlusCMobileWODsSetDelegate(new MobileMboSetAdapter(woDsDataBean));
/*  9360:      */     try
/*  9361:      */     {
/*  9362:11441 */       woDsSet.applyRequiredRules(false);
/*  9363:      */     }
/*  9364:      */     catch (Exception e)
/*  9365:      */     {
/*  9366:11442 */       MobileMboAdapter.wrapException(e);
/*  9367:      */     }
/*  9368:11444 */     return true;
/*  9369:      */   }
/*  9370:      */   
/*  9371:      */   private void setUncertReadOnlyFields(MobileMbo woMbo, String[] fields)
/*  9372:      */     throws MobileApplicationException
/*  9373:      */   {
/*  9374:11448 */     MobileMboDataBean woDataBean = pluscgetcurrentwoset();
/*  9375:11449 */     String woStatus = pluscGetWoInternalStatus(woDataBean.getValue("STATUS"), woDataBean);
/*  9376:11450 */     if ((!woStatus.equalsIgnoreCase("COMP")) && (!woStatus.equalsIgnoreCase("CLOSE"))) {
/*  9377:11451 */       for (int i = 0; i < fields.length; i++) {
/*  9378:11452 */         woMbo.setReadOnly(fields[i], false);
/*  9379:      */       }
/*  9380:      */     } else {
/*  9381:11455 */       for (int i = 0; i < fields.length; i++) {
/*  9382:11456 */         woMbo.setReadOnly(fields[i], true);
/*  9383:      */       }
/*  9384:      */     }
/*  9385:      */   }
/*  9386:      */   
/*  9387:      */   public boolean pluscgotoaftabFromDSTree(UIEvent event)
/*  9388:      */     throws MobileApplicationException
/*  9389:      */   {
/*  9390:11463 */     AbstractMobileControl thisPage = UIUtil.getCurrentScreen();
/*  9391:      */     
/*  9392:11465 */     UIUtil.gotoPage("pluscdsassetfunctions", thisPage);
/*  9393:11466 */     return true;
/*  9394:      */   }
/*  9395:      */   
/*  9396:      */   private boolean displayAfCalPointsMenu(UIEvent event)
/*  9397:      */     throws MobileApplicationException
/*  9398:      */   {
/*  9399:11471 */     MobileMboDataBean woDsInstrDataBean = DataBeanCache.getDataBean("PLUSCWODSINSTR", "PLUSCWODSINSTR");
/*  9400:      */     
/*  9401:      */ 
/*  9402:11474 */     MobileMbo woDsInstrMbo = woDsInstrDataBean.getMobileMbo();
/*  9403:      */     
/*  9404:11476 */     PlusCWODsInstrDelegate woDsInstr = new PlusCMobileWODsInstrDelegate(new MobileMboAdapter(woDsInstrMbo, woDsInstrDataBean));
/*  9405:      */     try
/*  9406:      */     {
/*  9407:11479 */       boolean hasCalPoints = woDsInstr.hasCalPoints();
/*  9408:      */       
/*  9409:11481 */       ((AbstractMobileControl)event.getCreatingObject()).setVisibility(hasCalPoints);
/*  9410:      */     }
/*  9411:      */     catch (Exception e)
/*  9412:      */     {
/*  9413:11483 */       MobileMboAdapter.wrapException(e);
/*  9414:      */     }
/*  9415:11485 */     return true;
/*  9416:      */   }
/*  9417:      */   
/*  9418:      */   private boolean displayAfFuncChecksMenu(UIEvent event)
/*  9419:      */     throws MobileApplicationException
/*  9420:      */   {
/*  9421:11492 */     MobileMboDataBean woDsInstrDataBean = DataBeanCache.getDataBean("PLUSCWODSINSTR", "PLUSCWODSINSTR");
/*  9422:      */     
/*  9423:      */ 
/*  9424:11495 */     MobileMbo woDsInstrMbo = woDsInstrDataBean.getMobileMbo();
/*  9425:      */     
/*  9426:11497 */     PlusCWODsInstrDelegate woDsInstr = new PlusCMobileWODsInstrDelegate(new MobileMboAdapter(woDsInstrMbo, woDsInstrDataBean));
/*  9427:      */     try
/*  9428:      */     {
/*  9429:11500 */       boolean hasFuncChecks = woDsInstr.hasFunctionChecks();
/*  9430:      */       
/*  9431:11502 */       ((AbstractMobileControl)event.getCreatingObject()).setVisibility(hasFuncChecks);
/*  9432:      */     }
/*  9433:      */     catch (Exception e)
/*  9434:      */     {
/*  9435:11504 */       MobileMboAdapter.wrapException(e);
/*  9436:      */     }
/*  9437:11506 */     return true;
/*  9438:      */   }
/*  9439:      */   
/*  9440:      */   private boolean displayAfDynChecksMenu(UIEvent event)
/*  9441:      */     throws MobileApplicationException
/*  9442:      */   {
/*  9443:11511 */     MobileMboDataBean woDsInstrDataBean = DataBeanCache.getDataBean("PLUSCWODSINSTR", "PLUSCWODSINSTR");
/*  9444:      */     
/*  9445:      */ 
/*  9446:11514 */     MobileMbo woDsInstrMbo = woDsInstrDataBean.getMobileMbo();
/*  9447:      */     
/*  9448:11516 */     PlusCWODsInstrDelegate woDsInstr = new PlusCMobileWODsInstrDelegate(new MobileMboAdapter(woDsInstrMbo, woDsInstrDataBean));
/*  9449:      */     try
/*  9450:      */     {
/*  9451:11519 */       boolean hasDynChecks = woDsInstr.hasDynamicChecks();
/*  9452:      */       
/*  9453:11521 */       ((AbstractMobileControl)event.getCreatingObject()).setVisibility(hasDynChecks);
/*  9454:      */     }
/*  9455:      */     catch (Exception e)
/*  9456:      */     {
/*  9457:11523 */       MobileMboAdapter.wrapException(e);
/*  9458:      */     }
/*  9459:11525 */     return true;
/*  9460:      */   }
/*  9461:      */   
/*  9462:      */   private boolean displayDsCalPointsMenu(UIEvent event)
/*  9463:      */     throws MobileApplicationException
/*  9464:      */   {
/*  9465:11530 */     AbstractMobileControl callingControl = (AbstractMobileControl)event.getCreatingObject();
/*  9466:11531 */     MobileMboDataBean woDsDataBean = callingControl.getDataBean();
/*  9467:11532 */     MobileMbo woDsMbo = woDsDataBean.getMobileMbo();
/*  9468:      */     
/*  9469:11534 */     PlusCWODsDelegate woDs = new PlusCMobileWODsDelegate(new MobileMboAdapter(woDsMbo, woDsDataBean));
/*  9470:      */     try
/*  9471:      */     {
/*  9472:11537 */       boolean hasCalPoints = woDs.hasCalPoints();
/*  9473:      */       
/*  9474:11539 */       ((AbstractMobileControl)event.getCreatingObject()).setVisibility(hasCalPoints);
/*  9475:      */     }
/*  9476:      */     catch (Exception e)
/*  9477:      */     {
/*  9478:11541 */       MobileMboAdapter.wrapException(e);
/*  9479:      */     }
/*  9480:11543 */     return true;
/*  9481:      */   }
/*  9482:      */   
/*  9483:      */   private boolean displayDsFuncChecksMenu(UIEvent event)
/*  9484:      */     throws MobileApplicationException
/*  9485:      */   {
/*  9486:11548 */     AbstractMobileControl callingControl = (AbstractMobileControl)event.getCreatingObject();
/*  9487:11549 */     MobileMboDataBean woDsDataBean = callingControl.getDataBean();
/*  9488:11550 */     MobileMbo woDsMbo = woDsDataBean.getMobileMbo();
/*  9489:      */     
/*  9490:11552 */     PlusCWODsDelegate woDs = new PlusCMobileWODsDelegate(new MobileMboAdapter(woDsMbo, woDsDataBean));
/*  9491:      */     try
/*  9492:      */     {
/*  9493:11555 */       boolean hasFuncChecks = woDs.hasFunctionChecks();
/*  9494:      */       
/*  9495:11557 */       ((AbstractMobileControl)event.getCreatingObject()).setVisibility(hasFuncChecks);
/*  9496:      */     }
/*  9497:      */     catch (Exception e)
/*  9498:      */     {
/*  9499:11559 */       MobileMboAdapter.wrapException(e);
/*  9500:      */     }
/*  9501:11561 */     return true;
/*  9502:      */   }
/*  9503:      */   
/*  9504:      */   private boolean displayDsDynChecksMenu(UIEvent event)
/*  9505:      */     throws MobileApplicationException
/*  9506:      */   {
/*  9507:11566 */     AbstractMobileControl callingControl = (AbstractMobileControl)event.getCreatingObject();
/*  9508:11567 */     MobileMboDataBean woDsDataBean = callingControl.getDataBean();
/*  9509:11568 */     MobileMbo woDsMbo = woDsDataBean.getMobileMbo();
/*  9510:      */     
/*  9511:11570 */     PlusCWODsDelegate woDs = new PlusCMobileWODsDelegate(new MobileMboAdapter(woDsMbo, woDsDataBean));
/*  9512:      */     try
/*  9513:      */     {
/*  9514:11573 */       boolean hasDynChecks = woDs.hasDynamicChecks();
/*  9515:      */       
/*  9516:11575 */       ((AbstractMobileControl)event.getCreatingObject()).setVisibility(hasDynChecks);
/*  9517:      */     }
/*  9518:      */     catch (Exception e)
/*  9519:      */     {
/*  9520:11577 */       MobileMboAdapter.wrapException(e);
/*  9521:      */     }
/*  9522:11579 */     return true;
/*  9523:      */   }
/*  9524:      */   
/*  9525:      */   public boolean pluscgotocptabFromAfList(UIEvent event)
/*  9526:      */     throws MobileApplicationException
/*  9527:      */   {
/*  9528:11583 */     return goToPointTabFromAfList(event, "pluscdscalpoints", "CALPOINT");
/*  9529:      */   }
/*  9530:      */   
/*  9531:      */   public boolean pluscgotofctabFromAfList(UIEvent event)
/*  9532:      */     throws MobileApplicationException
/*  9533:      */   {
/*  9534:11587 */     return goToPointTabFromAfList(event, "pluscdsfc", "CALFUNCTION");
/*  9535:      */   }
/*  9536:      */   
/*  9537:      */   public boolean pluscgotodctabFromAfList(UIEvent event)
/*  9538:      */     throws MobileApplicationException
/*  9539:      */   {
/*  9540:11591 */     return goToPointTabFromAfList(event, "pluscdsdc", "CALDYNAMIC");
/*  9541:      */   }
/*  9542:      */   
/*  9543:      */   public boolean goToPointTabFromAfList(UIEvent event, String pageId, String pointType)
/*  9544:      */     throws MobileApplicationException
/*  9545:      */   {
/*  9546:11603 */     AbstractMobileControl callingControl = (AbstractMobileControl)event.getCreatingObject();
/*  9547:      */     
/*  9548:      */ 
/*  9549:11606 */     MobileMboDataBean dataBean = callingControl.getDataBean();
/*  9550:11607 */     MobileMbo mobileMbo = dataBean.getMobileMbo();
/*  9551:11608 */     int currentPos = dataBean.getCurrentPosition();
/*  9552:      */     
/*  9553:      */ 
/*  9554:11611 */     DataBeanCache.findDataBean("PLUSCWODS").getMobileMbo().setBooleanValue("VIEWASLOOP", false);
/*  9555:      */     
/*  9556:      */ 
/*  9557:      */ 
/*  9558:      */ 
/*  9559:      */ 
/*  9560:11617 */     pluscFilterAfCpDataBean(true, "PLUSCWODSPOINT", mobileMbo.getValue("DSPLANNUM"), mobileMbo.getValue("SITEID"), mobileMbo.getValue("INSTRSEQ"), mobileMbo.getValue("REVISIONNUM"), mobileMbo.getValue("WONUM"), pointType, mobileMbo.getValue("WODSNUM"));
/*  9561:      */     
/*  9562:      */ 
/*  9563:      */ 
/*  9564:      */ 
/*  9565:11622 */     DataBeanCache.getDataBean("PLUSCWODSINSTR", "PLUSCWODSINSTR").setCurrentPosition(currentPos);
/*  9566:11623 */     this.currentAFIndex = ((int)mobileMbo.getLongValue("PLUSCWODSINSTRID"));
/*  9567:      */     
/*  9568:      */ 
/*  9569:11626 */     goToTab(callingControl, pageId, callingControl.getStringValue("targettabid"));
/*  9570:      */     
/*  9571:11628 */     return true;
/*  9572:      */   }
/*  9573:      */   
/*  9574:      */   public boolean pluscgotocptabFromAfTree(UIEvent event)
/*  9575:      */     throws MobileApplicationException
/*  9576:      */   {
/*  9577:11632 */     return goToPointTabFromAfTree(event, "pluscdscalpoints", "CALPOINT");
/*  9578:      */   }
/*  9579:      */   
/*  9580:      */   public boolean pluscgotofctabFromAfTree(UIEvent event)
/*  9581:      */     throws MobileApplicationException
/*  9582:      */   {
/*  9583:11636 */     return goToPointTabFromAfTree(event, "pluscdsfc", "CALFUNCTION");
/*  9584:      */   }
/*  9585:      */   
/*  9586:      */   public boolean pluscgotodctabFromAfTree(UIEvent event)
/*  9587:      */     throws MobileApplicationException
/*  9588:      */   {
/*  9589:11640 */     return goToPointTabFromAfTree(event, "pluscdsdc", "CALDYNAMIC");
/*  9590:      */   }
/*  9591:      */   
/*  9592:      */   public boolean goToPointTabFromAfTree(UIEvent event, String pageId, String pointType)
/*  9593:      */     throws MobileApplicationException
/*  9594:      */   {
/*  9595:11652 */     AbstractMobileControl callingControl = (AbstractMobileControl)event.getCreatingObject();
/*  9596:      */     
/*  9597:      */ 
/*  9598:      */ 
/*  9599:      */ 
/*  9600:      */ 
/*  9601:11658 */     MobileMboDataBean dataBean = callingControl.getDataBean();
/*  9602:11659 */     MobileMboDataBean curDataBean = dataBean.getDataBean("PLUSCWODSINSTR");
/*  9603:      */     
/*  9604:      */ 
/*  9605:11662 */     DataBeanCacheItem indexCacheItem = new DataBeanCacheItem("PLUSCWODSINSTR", "PLUSCWODSINSTR", curDataBean);
/*  9606:11663 */     DataBeanCache.cacheDataBean("PLUSCWODSINSTR", indexCacheItem);
/*  9607:      */     
/*  9608:11665 */     int currentPos = curDataBean.getCurrentPosition();
/*  9609:11666 */     MobileMbo mobileMbo = curDataBean.getMobileMbo(currentPos);
/*  9610:      */     
/*  9611:      */ 
/*  9612:11669 */     dataBean.getMobileMbo().setBooleanValue("VIEWASLOOP", false);
/*  9613:      */     
/*  9614:      */ 
/*  9615:      */ 
/*  9616:      */ 
/*  9617:      */ 
/*  9618:11675 */     pluscFilterAfCpDataBean(true, "PLUSCWODSPOINT", mobileMbo.getValue("DSPLANNUM"), mobileMbo.getValue("SITEID"), mobileMbo.getValue("INSTRSEQ"), mobileMbo.getValue("REVISIONNUM"), mobileMbo.getValue("WONUM"), pointType, mobileMbo.getValue("WODSNUM"));
/*  9619:      */     
/*  9620:      */ 
/*  9621:      */ 
/*  9622:      */ 
/*  9623:      */ 
/*  9624:11681 */     goToTab(callingControl, pageId, callingControl.getStringValue("targettabid"));
/*  9625:      */     
/*  9626:11683 */     DataBeanCache.getDataBean("PLUSCWODSINSTR", "PLUSCWODSINSTR").setCurrentPosition(currentPos);
/*  9627:      */     
/*  9628:11685 */     return true;
/*  9629:      */   }
/*  9630:      */   
/*  9631:      */   public boolean pluscgotocptabFromDsList(UIEvent event)
/*  9632:      */     throws MobileApplicationException
/*  9633:      */   {
/*  9634:11689 */     return goToPointTabFromDsList(event, "pluscdscalpoints", "CALPOINT");
/*  9635:      */   }
/*  9636:      */   
/*  9637:      */   public boolean pluscgotofctabFromDsList(UIEvent event)
/*  9638:      */     throws MobileApplicationException
/*  9639:      */   {
/*  9640:11693 */     return goToPointTabFromDsList(event, "pluscdsfc", "CALFUNCTION");
/*  9641:      */   }
/*  9642:      */   
/*  9643:      */   public boolean pluscgotodctabFromDsList(UIEvent event)
/*  9644:      */     throws MobileApplicationException
/*  9645:      */   {
/*  9646:11697 */     return goToPointTabFromDsList(event, "pluscdsdc", "CALDYNAMIC");
/*  9647:      */   }
/*  9648:      */   
/*  9649:      */   public boolean goToPointTabFromDsList(UIEvent event, String pageId, String pointType)
/*  9650:      */     throws MobileApplicationException
/*  9651:      */   {
/*  9652:11709 */     AbstractMobileControl callingControl = (AbstractMobileControl)event.getCreatingObject();
/*  9653:      */     
/*  9654:      */ 
/*  9655:11712 */     MobileMboDataBean dataBean = callingControl.getDataBean();
/*  9656:      */     
/*  9657:      */ 
/*  9658:      */ 
/*  9659:11716 */     MobileMboDataBean curDataBean = dataBean.getDataBean("PLUSCWODSINSTR");
/*  9660:11717 */     DataBeanCacheItem item = new DataBeanCacheItem("PLUSCWODSINSTR", "PLUSCWODSINSTR", curDataBean);
/*  9661:11718 */     DataBeanCache.cacheDataBean("PLUSCWODSINSTR", item);
/*  9662:      */     
/*  9663:11720 */     MobileMboDataBean pointDataBean = curDataBean.getDataBean("PLUSCWODSPOINT");
/*  9664:11721 */     item = new DataBeanCacheItem("PLUSCWODSPOINT", "PLUSCWODSPOINT", pointDataBean);
/*  9665:11722 */     DataBeanCache.cacheDataBean("PLUSCWODSPOINT", item);
/*  9666:      */     
/*  9667:      */ 
/*  9668:11725 */     dataBean.getMobileMbo().setBooleanValue("VIEWASLOOP", true);
/*  9669:      */     
/*  9670:      */ 
/*  9671:11728 */     goToTab(callingControl, pageId, callingControl.getStringValue("targettabid"));
/*  9672:      */     
/*  9673:11730 */     pluscchangeview(event, true, true, pointType);
/*  9674:11731 */     UIUtil.refreshCurrentScreen();
/*  9675:      */     
/*  9676:11733 */     return true;
/*  9677:      */   }
/*  9678:      */   
/*  9679:      */   private boolean displaydslist(UIEvent event)
/*  9680:      */     throws MobileApplicationException
/*  9681:      */   {
/*  9682:11738 */     return woDsApplyRequiredRules();
/*  9683:      */   }
/*  9684:      */   
/*  9685:      */   private boolean afterUpdateFunctionCheck(UIEvent event)
/*  9686:      */     throws MobileApplicationException
/*  9687:      */   {
/*  9688:11744 */     AbstractMobileControl callingControl = (AbstractMobileControl)event.getCreatingObject();
/*  9689:11745 */     MobileMboDataBean woDsPointDataBean = callingControl.getDataBean();
/*  9690:11746 */     MobileMbo woDsPointMbo = woDsPointDataBean.getMobileMbo();
/*  9691:      */     
/*  9692:11748 */     String fieldName = callingControl.getControlData().getValue("dataattribute");
/*  9693:11749 */     String value = (String)event.getValue();
/*  9694:      */     
/*  9695:11751 */     PlusCMobileWODsPointDelegate woDsPoint = new PlusCMobileWODsPointDelegate(new MobileMboAdapter(woDsPointMbo, woDsPointDataBean), null);
/*  9696:      */     try
/*  9697:      */     {
/*  9698:11754 */       woDsPoint.setFunctionCheckPass(fieldName, Boolean.valueOf(value).booleanValue());
/*  9699:      */     }
/*  9700:      */     catch (Exception e)
/*  9701:      */     {
/*  9702:11756 */       MobileMboAdapter.wrapException(e);
/*  9703:      */     }
/*  9704:11758 */     pluscupdatedsstatus(UIUtil.getCurrentScreen().getDataBean(), DataBeanCache.getDataBean("PLUSCWODS", "PLUSCWODS"), null, event, true);
/*  9705:      */     
/*  9706:11760 */     return true;
/*  9707:      */   }
/*  9708:      */   
/*  9709:      */   private boolean validateDynCheckInput(UIEvent event)
/*  9710:      */     throws MobileApplicationException
/*  9711:      */   {
/*  9712:11765 */     pluscValidateNumber(event, (String)event.getValue());
/*  9713:11766 */     return true;
/*  9714:      */   }
/*  9715:      */   
/*  9716:      */   private boolean displayCpAveragesMenu(UIEvent event)
/*  9717:      */     throws MobileApplicationException
/*  9718:      */   {
/*  9719:11771 */     AbstractMobileControl callingControl = (AbstractMobileControl)event.getCreatingObject();
/*  9720:11772 */     MobileMboDataBean woDsPointDataBean = callingControl.getDataBean();
/*  9721:11773 */     MobileMbo woDsPointMbo = woDsPointDataBean.getMobileMbo();
/*  9722:      */     
/*  9723:11775 */     PlusCMobileWODsPointDelegate woDsPoint = new PlusCMobileWODsPointDelegate(new MobileMboAdapter(woDsPointMbo, woDsPointDataBean), null);
/*  9724:      */     try
/*  9725:      */     {
/*  9726:11779 */       boolean isRepeatable = woDsPoint.isRepeatable();
/*  9727:11780 */       ((AbstractMobileControl)event.getCreatingObject()).setVisibility(isRepeatable);
/*  9728:      */     }
/*  9729:      */     catch (Exception e)
/*  9730:      */     {
/*  9731:11782 */       MobileMboAdapter.wrapException(e);
/*  9732:      */     }
/*  9733:11784 */     return true;
/*  9734:      */   }
/*  9735:      */   
/*  9736:      */   private boolean pluscGotoAsFoundAveragesPage(UIEvent event)
/*  9737:      */     throws MobileApplicationException
/*  9738:      */   {
/*  9739:11789 */     UIEventHandler averagesHandler = UIHandlerManager.getInstance().getUIHandler("PlusCMobRepeatabilityEventHandler");
/*  9740:11790 */     averagesHandler.performEvent(event);
/*  9741:11791 */     return true;
/*  9742:      */   }
/*  9743:      */   
/*  9744:      */   private boolean pluscGotoAsLeftAveragesPage(UIEvent event)
/*  9745:      */     throws MobileApplicationException
/*  9746:      */   {
/*  9747:11797 */     UIEventHandler averagesHandler = UIHandlerManager.getInstance().getUIHandler("PlusCMobRepeatabilityEventHandler");
/*  9748:11798 */     averagesHandler.performEvent(event);
/*  9749:11799 */     return true;
/*  9750:      */   }
/*  9751:      */   
/*  9752:      */   private boolean initResponsePage(UIEvent event)
/*  9753:      */     throws MobileApplicationException
/*  9754:      */   {
/*  9755:11805 */     AbstractMobileControl callingControl = (AbstractMobileControl)event.getCreatingObject();
/*  9756:11806 */     MobileMboDataBean woDsPointDataBean = callingControl.getDataBean();
/*  9757:11807 */     MobileMbo woDsPointMbo = woDsPointDataBean.getMobileMbo();
/*  9758:      */     
/*  9759:      */ 
/*  9760:      */ 
/*  9761:      */ 
/*  9762:      */ 
/*  9763:      */ 
/*  9764:      */ 
/*  9765:11815 */     setPointUncertReadOnlyFields(woDsPointMbo);
/*  9766:      */     
/*  9767:11817 */     boolean responseReadOnly = !woDsPointMbo.getBooleanValue("ISAVERAGE");
/*  9768:      */     
/*  9769:      */ 
/*  9770:11820 */     woDsPointMbo.setReadOnly("ASFOUNDRESPONSE", responseReadOnly);
/*  9771:11821 */     woDsPointMbo.setReadOnly("ASFOUNDRESPONSEEU", responseReadOnly);
/*  9772:11822 */     woDsPointMbo.setReadOnly("ASLEFTRESPONSE", responseReadOnly);
/*  9773:11823 */     woDsPointMbo.setReadOnly("ASLEFTRESPONSEEU", responseReadOnly);
/*  9774:      */     
/*  9775:11825 */     return true;
/*  9776:      */   }
/*  9777:      */   
/*  9778:      */   protected void setPointUncertReadOnlyFields(MobileMbo woPoint)
/*  9779:      */     throws MobileApplicationException
/*  9780:      */   {
/*  9781:11829 */     String[] fields = POINT_UNCERTAINTY_FIELDS;
/*  9782:11830 */     boolean isNoAdjMade = false;
/*  9783:11832 */     if (woPoint != null)
/*  9784:      */     {
/*  9785:11834 */       MobileMbo instrMbo = pluscgetinstrmboforpoint(woPoint);
/*  9786:11836 */       if (instrMbo != null) {
/*  9787:11837 */         isNoAdjMade = instrMbo.getBooleanValue("NOADJMADE");
/*  9788:      */       }
/*  9789:11839 */       if ((canEditAsFoundAsLeftInStatus()) && (canEditAssetFunction()) && (!isNoAdjMade)) {
/*  9790:11841 */         for (int i = 0; i < fields.length; i++) {
/*  9791:11843 */           woPoint.setReadOnly(fields[i], false);
/*  9792:      */         }
/*  9793:      */       } else {
/*  9794:11848 */         for (int i = 0; i < fields.length; i++) {
/*  9795:11850 */           woPoint.setReadOnly(fields[i], true);
/*  9796:      */         }
/*  9797:      */       }
/*  9798:      */     }
/*  9799:      */   }
/*  9800:      */   
/*  9801:      */   protected boolean canEditAssetFunction()
/*  9802:      */     throws MobileApplicationException
/*  9803:      */   {
/*  9804:11859 */     MobileMboDataBean pointBean = UIUtil.getCurrentScreen().getDataBean();
/*  9805:11860 */     String mobReadOnly = ((WOApp)UIUtil.getApplication()).getMaxVar(pointBean, "PLUSCMOBREADONLY");
/*  9806:11861 */     boolean completedAfReadOnly = mobReadOnly.equals("1");
/*  9807:11864 */     if (!completedAfReadOnly) {
/*  9808:11864 */       return true;
/*  9809:      */     }
/*  9810:11866 */     PlusCWODsPointDelegate pointDel = new PlusCMobileWODsPointDelegate(new MobileMboAdapter(pointBean.getMobileMbo(), pointBean), null);
/*  9811:11867 */     boolean allValuesEntered = false;
/*  9812:      */     try
/*  9813:      */     {
/*  9814:11869 */       PlusCWODsInstrDelegate woDsInstr = pointDel.getInstrDelegate();
/*  9815:11870 */       allValuesEntered = woDsInstr.isAllEntered();
/*  9816:      */     }
/*  9817:      */     catch (Exception e)
/*  9818:      */     {
/*  9819:11871 */       MobileMboAdapter.wrapException(e);
/*  9820:      */     }
/*  9821:11873 */     return !allValuesEntered;
/*  9822:      */   }
/*  9823:      */   
/*  9824:      */   public boolean pluscValidateAssociatedTool(UIEvent event)
/*  9825:      */     throws MobileApplicationException
/*  9826:      */   {
/*  9827:11883 */     boolean hasAssociatedTool = false;
/*  9828:      */     
/*  9829:11885 */     AbstractMobileControl callingControl = (AbstractMobileControl)event.getCreatingObject();
/*  9830:11886 */     MobileMboDataBean dataBean = callingControl.getDataBean();
/*  9831:      */     
/*  9832:11888 */     PlusCWODelegate wo = new PlusCMobileWODelegate(new MobileMboAdapter(dataBean.getMobileMbo(), dataBean));
/*  9833:      */     try
/*  9834:      */     {
/*  9835:11891 */       hasAssociatedTool = wo.hasAssociatedTool();
/*  9836:      */     }
/*  9837:      */     catch (Exception e)
/*  9838:      */     {
/*  9839:11893 */       MobileMboAdapter.wrapException(e);
/*  9840:      */     }
/*  9841:11895 */     String desiredMaxStatus = pluscGetWoInternalStatus((String)event.getValue(), dataBean);
/*  9842:11896 */     String workTypeCal = getWorktypeCal(dataBean);
/*  9843:11897 */     String workType = getWorkType(dataBean.getMobileMbo());
/*  9844:11899 */     if (((desiredMaxStatus.equals("COMP")) || (desiredMaxStatus.equals("CLOSE"))) && (!hasAssociatedTool) && (workType.equalsIgnoreCase(workTypeCal)) && (dataBean.getDataBean("PLUSCWODS").count() > 0))
/*  9845:      */     {
/*  9846:11903 */       int toolValidation = Integer.parseInt(((WOApp)UIUtil.getApplication()).getMaxVar(dataBean, "PLUSCVALTOOL"));
/*  9847:11906 */       switch (toolValidation)
/*  9848:      */       {
/*  9849:      */       case 0: 
/*  9850:      */         break;
/*  9851:      */       case 1: 
/*  9852:11910 */         String msg = MobileMessageGenerator.generate("pluscwt_ToolNotEntered", null);
/*  9853:11911 */         UIUtil.showInfoMessageBox(msg);
/*  9854:11912 */         break;
/*  9855:      */       case 2: 
/*  9856:      */       default: 
/*  9857:11915 */         throw new MobileApplicationException("pluscwt_ToolNotEntered");
/*  9858:      */       }
/*  9859:      */     }
/*  9860:11920 */     return true;
/*  9861:      */   }
/*  9862:      */   
/*  9863:      */   private boolean validateInsertWODS(UIEvent event)
/*  9864:      */     throws MobileApplicationException
/*  9865:      */   {
/*  9866:11925 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/*  9867:11927 */     if (databean.getMobileMbo().isNull("DSPLANNUM")) {
/*  9868:11928 */       databean.delete();
/*  9869:      */     }
/*  9870:11931 */     return true;
/*  9871:      */   }
/*  9872:      */   
/*  9873:      */   private boolean displaydspage(UIEvent event)
/*  9874:      */     throws MobileApplicationException
/*  9875:      */   {
/*  9876:11935 */     UIUtil.getCurrentScreen().registerBean("PLUSCWODS", true);
/*  9877:11936 */     return true;
/*  9878:      */   }
/*  9879:      */   
/*  9880:      */   private boolean pluscWODsInstrNoAdjMadeDisplayEvent(UIEvent event)
/*  9881:      */     throws MobileApplicationException
/*  9882:      */   {
/*  9883:11941 */     MobileMboDataBean instrDataBean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*  9884:11943 */     if (pluscWODsInstrIsNoAdjMadeReadOnly(instrDataBean.getMobileMbo())) {
/*  9885:11944 */       instrDataBean.getMobileMbo().setReadOnly("NOADJMADE", true);
/*  9886:      */     } else {
/*  9887:11946 */       instrDataBean.getMobileMbo().setReadOnly("NOADJMADE", false);
/*  9888:      */     }
/*  9889:11948 */     return true;
/*  9890:      */   }
/*  9891:      */   
/*  9892:      */   private boolean pluscWODsInstrNoAdjMadeInitEvent(UIEvent event)
/*  9893:      */     throws MobileApplicationException
/*  9894:      */   {
/*  9895:11953 */     setInstrUncertReadOnlyFields(event);
/*  9896:11954 */     MobileMboDataBean instrDataBean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*  9897:11955 */     for (int i = 0; i < instrDataBean.count(); i++)
/*  9898:      */     {
/*  9899:11956 */       MobileMbo instrMbo = instrDataBean.getMobileMbo(i);
/*  9900:11957 */       if (pluscWODsInstrIsNoAdjMadeReadOnly(instrMbo)) {
/*  9901:11958 */         instrMbo.setReadOnly("NOADJMADE", true);
/*  9902:      */       } else {
/*  9903:11960 */         instrMbo.setReadOnly("NOADJMADE", false);
/*  9904:      */       }
/*  9905:      */     }
/*  9906:11963 */     return true;
/*  9907:      */   }
/*  9908:      */   
/*  9909:      */   private boolean pluscWODsInstrIsNoAdjMadeReadOnly(MobileMbo instrMbo)
/*  9910:      */     throws MobileApplicationException
/*  9911:      */   {
/*  9912:11970 */     boolean bOkToEditAsFoundAsLeft = plusccaneditasfoundasleftfields();
/*  9913:11972 */     if (instrMbo.getBooleanValue("CALPOINT"))
/*  9914:      */     {
/*  9915:11973 */       if ((instrMbo.isNull("NOADJMADECHOICE1")) && (instrMbo.isNull("NOADJMADECHOICE2")) && (instrMbo.isNull("NOADJMADECHOICE3")) && (instrMbo.isNull("NOADJMADECHOICE4"))) {
/*  9916:11977 */         return true;
/*  9917:      */       }
/*  9918:11979 */       if ((!bOkToEditAsFoundAsLeft) || ((!instrMbo.isNull("NOADJMADECHOICE1")) && (!instrMbo.getBooleanValue("NOADJMADECHOICE1")) && (!instrMbo.isNull("NOADJMADECHOICE2")) && (!instrMbo.getBooleanValue("NOADJMADECHOICE2")) && (!instrMbo.isNull("NOADJMADECHOICE3")) && (!instrMbo.getBooleanValue("NOADJMADECHOICE3")) && (!instrMbo.isNull("NOADJMADECHOICE4")) && (!instrMbo.getBooleanValue("NOADJMADECHOICE4")))) {
/*  9919:11987 */         return true;
/*  9920:      */       }
/*  9921:      */     }
/*  9922:11990 */     else if (!bOkToEditAsFoundAsLeft)
/*  9923:      */     {
/*  9924:11991 */       return true;
/*  9925:      */     }
/*  9926:11994 */     return false;
/*  9927:      */   }
/*  9928:      */   
/*  9929:      */   private boolean plusCDSRequiredValidate(UIEvent event)
/*  9930:      */     throws MobileApplicationException
/*  9931:      */   {
/*  9932:11999 */     MobileMboDataBean woDSDataBean = UIUtil.getCurrentScreen().getDataBean();
/*  9933:      */     
/*  9934:12001 */     boolean hasRequired = false;
/*  9935:12002 */     for (int i = 0; (i < woDSDataBean.count()) && (!hasRequired); i++) {
/*  9936:12003 */       if (woDSDataBean.getMobileMbo(i).getBooleanValue("REQUIRED"))
/*  9937:      */       {
/*  9938:12004 */         boolean newCheck = Boolean.valueOf((String)event.getValue()).booleanValue();
/*  9939:12005 */         String selWODSNum = ((CheckboxControl)event.getCreatingObject()).getDataBean().getMobileMbo().getValue("WODSNUM");
/*  9940:12006 */         String targetWODSNum = woDSDataBean.getMobileMbo(i).getValue("WODSNUM");
/*  9941:12007 */         if ((newCheck) || (!selWODSNum.equals(targetWODSNum))) {
/*  9942:12008 */           hasRequired = true;
/*  9943:      */         }
/*  9944:      */       }
/*  9945:      */     }
/*  9946:12013 */     if (!hasRequired) {
/*  9947:12014 */       throw new MobileApplicationException("pluscdsonerequired");
/*  9948:      */     }
/*  9949:12017 */     return true;
/*  9950:      */   }
/*  9951:      */   
/*  9952:      */   private boolean pluscGotoAsFoundPageFromCPTree(UIEvent event)
/*  9953:      */     throws MobileApplicationException
/*  9954:      */   {
/*  9955:12027 */     AbstractMobileControl callingControl = (AbstractMobileControl)event.getCreatingObject();
/*  9956:12028 */     MobileMboDataBean dataBean = callingControl.getDataBean();
/*  9957:12029 */     MobileMboDataBean instrBean = dataBean.getDataBean("PLUSCWODSINSTR");
/*  9958:12030 */     MobileMbo instr = instrBean.getMobileMbo();
/*  9959:      */     
/*  9960:12032 */     String pageId = instr.getBooleanValue("CALDYNAMIC") ? "pluscdcasfoundvaluespage" : instr.getBooleanValue("CALFUNCTION") ? "pluscfcasfoundvaluespage" : instr.getBooleanValue("CALPOINT") ? "pluscasfoundvaluespage" : null;
/*  9961:      */     
/*  9962:      */ 
/*  9963:      */ 
/*  9964:      */ 
/*  9965:12037 */     UIUtil.gotoPage(pageId, callingControl);
/*  9966:      */     
/*  9967:12039 */     return true;
/*  9968:      */   }
/*  9969:      */   
/*  9970:      */   private boolean pluscGotoAsLeftPageFromCPTree(UIEvent event)
/*  9971:      */     throws MobileApplicationException
/*  9972:      */   {
/*  9973:12049 */     AbstractMobileControl callingControl = (AbstractMobileControl)event.getCreatingObject();
/*  9974:12050 */     MobileMboDataBean dataBean = callingControl.getDataBean();
/*  9975:12051 */     MobileMboDataBean instrBean = dataBean.getDataBean("PLUSCWODSINSTR");
/*  9976:12052 */     MobileMbo instr = instrBean.getMobileMbo();
/*  9977:      */     
/*  9978:12054 */     String pageId = instr.getBooleanValue("CALDYNAMIC") ? "pluscdcasleftvaluespage" : instr.getBooleanValue("CALFUNCTION") ? "pluscfcasleftvaluespage" : instr.getBooleanValue("CALPOINT") ? "pluscasleftvaluespage" : null;
/*  9979:      */     
/*  9980:      */ 
/*  9981:      */ 
/*  9982:      */ 
/*  9983:12059 */     UIUtil.gotoPage(pageId, callingControl);
/*  9984:      */     
/*  9985:12061 */     return true;
/*  9986:      */   }
/*  9987:      */   
/*  9988:      */   private boolean pluscGotoDetailsPageFromCPTree(UIEvent event)
/*  9989:      */     throws MobileApplicationException
/*  9990:      */   {
/*  9991:12071 */     AbstractMobileControl callingControl = (AbstractMobileControl)event.getCreatingObject();
/*  9992:12072 */     MobileMboDataBean dataBean = callingControl.getDataBean();
/*  9993:12073 */     MobileMboDataBean instrBean = dataBean.getDataBean("PLUSCWODSINSTR");
/*  9994:12074 */     MobileMbo instr = instrBean.getMobileMbo();
/*  9995:      */     
/*  9996:12076 */     String pageId = instr.getBooleanValue("CALDYNAMIC") ? "pluscdcdetails" : instr.getBooleanValue("CALFUNCTION") ? "pluscfcdetails" : instr.getBooleanValue("CALPOINT") ? "plusccpdetails" : null;
/*  9997:      */     
/*  9998:      */ 
/*  9999:      */ 
/* 10000:      */ 
/* 10001:12081 */     UIUtil.gotoPage(pageId, callingControl);
/* 10002:      */     
/* 10003:12083 */     return true;
/* 10004:      */   }
/* 10005:      */   
/* 10006:      */   private boolean pluscWODsAsfAslStatusEvent(UIEvent event)
/* 10007:      */     throws MobileApplicationException
/* 10008:      */   {
/* 10009:12089 */     MobileMboDataBean databean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/* 10010:12090 */     TextboxControl eventSource = (TextboxControl)event.getCreatingObject();
/* 10011:      */     
/* 10012:      */ 
/* 10013:      */ 
/* 10014:      */ 
/* 10015:      */ 
/* 10016:      */ 
/* 10017:      */ 
/* 10018:      */ 
/* 10019:      */ 
/* 10020:12100 */     MobileMboDataBean woDsDataBean = DataBeanCache.getDataBean("PLUSCWODS", "PLUSCWODS");
/* 10021:      */     
/* 10022:12102 */     MobileMbo woDsMbo = woDsDataBean.getMobileMbo();
/* 10023:      */     
/* 10024:12104 */     String fieldName = eventSource.getControlData().getValue("dataattribute");
/* 10025:12105 */     String originalValue = woDsMbo.getValue(fieldName);
/* 10026:      */     
/* 10027:12107 */     String statusValue = "";
/* 10028:12108 */     if (event.getValue() == null) {
/* 10029:12109 */       return false;
/* 10030:      */     }
/* 10031:12113 */     if (event.getValue().toString().equalsIgnoreCase(originalValue)) {
/* 10032:12114 */       return false;
/* 10033:      */     }
/* 10034:12117 */     if (!event.getValue().toString().equals("")) {
/* 10035:12118 */       statusValue = ((WOApp)UIUtil.getApplication()).getInternalValue(databean, "PLUSCCALSTATUS", event.getValue().toString().toUpperCase());
/* 10036:      */     }
/* 10037:12120 */     PlusCMobileWODsDelegate woDs = new PlusCMobileWODsDelegate(new MobileMboAdapter(woDsMbo, woDsDataBean));
/* 10038:12121 */     boolean asFfieldFilled = true;
/* 10039:12122 */     boolean brkormiss = false;
/* 10040:12124 */     if ((statusValue.equalsIgnoreCase("BROKEN")) || (statusValue.equalsIgnoreCase("MISSING")))
/* 10041:      */     {
/* 10042:12125 */       brkormiss = true;
/* 10043:      */       try
/* 10044:      */       {
/* 10045:12128 */         String prefix = fieldName.substring(0, fieldName.indexOf("CALSTATUS"));
/* 10046:12129 */         asFfieldFilled = woDs.isAllEntered(prefix);
/* 10047:      */       }
/* 10048:      */       catch (Exception e)
/* 10049:      */       {
/* 10050:12130 */         MobileMboAdapter.wrapException(e);
/* 10051:      */       }
/* 10052:      */     }
/* 10053:12133 */     String pluscautostatusMaxVar = ((WOApp)UIUtil.getApplication()).getMaxVar(woDsDataBean, "PLUSCAUTOSTATUS");
/* 10054:12134 */     boolean pluscautostatus = pluscautostatusMaxVar.equals("1");
/* 10055:12136 */     if (((pluscautostatus) && (asFfieldFilled) && (brkormiss)) || ((pluscautostatus) && (statusValue.equals(""))) || ((pluscautostatus) && (!brkormiss))) {
/* 10056:12138 */       throw new MobileApplicationException("pluscwodsstatusbrokenormissing");
/* 10057:      */     }
/* 10058:12141 */     return false;
/* 10059:      */   }
/* 10060:      */   
/* 10061:      */   private boolean pluscInitAFStatusEvent(UIEvent event)
/* 10062:      */     throws MobileApplicationException
/* 10063:      */   {
/* 10064:12147 */     MobileMboDataBean dsStatusDataBean = UIUtil.getCurrentScreen().getDataBean();
/* 10065:12148 */     int pos = DataBeanCache.getDataBean("PLUSCWODSINSTR", "PLUSCWODSINSTR").getCurrentPosition();
/* 10066:12149 */     MobileMbo afMbo = DataBeanCache.getDataBean("PLUSCWODSINSTR", "PLUSCWODSINSTR").getMobileMbo(pos);
/* 10067:12150 */     calcWoDsStatusWithoutSend(event, dsStatusDataBean, afMbo.getValue("INSTRSEQ"));
/* 10068:12151 */     DataBeanCache.getDataBean("PLUSCWODSINSTR", "PLUSCWODSINSTR").reset();
/* 10069:      */     
/* 10070:12153 */     DataBeanCache.getDataBean("PLUSCWODSINSTR", "PLUSCWODSINSTR").setCurrentPosition(pos);
/* 10071:12154 */     return true;
/* 10072:      */   }
/* 10073:      */   
/* 10074:      */   protected void calcWoDsStatusBeforeSendSrv(UIEvent event, MobileMbo woMbo)
/* 10075:      */     throws MobileApplicationException
/* 10076:      */   {
/* 10077:12162 */     MobileMboDataBeanManager instrmgrWoDs = new MobileMboDataBeanManager("PLUSCWODS");
/* 10078:12163 */     MobileMboDataBean wodsBean = instrmgrWoDs.getDataBean();
/* 10079:      */     
/* 10080:12165 */     wodsBean.getQBE().reset();
/* 10081:12166 */     wodsBean.getQBE().setQbeExactMatch(true);
/* 10082:12167 */     wodsBean.getQBE().setQBE("SITEID", woMbo.getValue("SITEID"));
/* 10083:12168 */     wodsBean.getQBE().setQBE("WONUM", woMbo.getValue("WONUM"));
/* 10084:      */     
/* 10085:12170 */     wodsBean.reset();
/* 10086:12171 */     int count = wodsBean.count();
/* 10087:12172 */     for (int i = 0; i < count; i++)
/* 10088:      */     {
/* 10089:12173 */       MobileMbo dsMbo = wodsBean.getMobileMbo(i);
/* 10090:12174 */       MobileMboDataBeanManager instrmgrDsPoints = new MobileMboDataBeanManager("PLUSCWODSPOINT");
/* 10091:12175 */       MobileMboDataBean instrPointBean = instrmgrDsPoints.getDataBean();
/* 10092:      */       
/* 10093:12177 */       instrPointBean.getQBE().reset();
/* 10094:12178 */       instrPointBean.getQBE().setQbeExactMatch(true);
/* 10095:12179 */       instrPointBean.getQBE().setQBE("DSPLANNUM", dsMbo.getValue("DSPLANNUM"));
/* 10096:12180 */       instrPointBean.getQBE().setQBE("SITEID", dsMbo.getValue("SITEID"));
/* 10097:12181 */       instrPointBean.getQBE().setQBE("REVISIONNUM", dsMbo.getValue("REVISIONNUM"));
/* 10098:      */       
/* 10099:12183 */       instrPointBean.getQBE().setQBE("WONUM", dsMbo.getValue("WONUM"));
/* 10100:      */       
/* 10101:      */ 
/* 10102:12186 */       instrPointBean.getQBE().setQBE("WODSNUM", dsMbo.getValue("WODSNUM"));
/* 10103:      */       
/* 10104:12188 */       instrPointBean.reset();
/* 10105:      */       
/* 10106:      */ 
/* 10107:12191 */       pluscupdatedsstatus(instrPointBean, wodsBean, dsMbo, event, true);
/* 10108:      */       
/* 10109:      */ 
/* 10110:12194 */       UIUtil.getApplication().updateMobileMbo(dsMbo.getName(), dsMbo);
/* 10111:      */     }
/* 10112:      */   }
/* 10113:      */   
/* 10114:      */   public static String pluscgetinstrstatus(MobileMboDataBean databean, MobileMbo instrMbo, String fieldName)
/* 10115:      */     throws MobileApplicationException
/* 10116:      */   {
/* 10117:12213 */     databean = databean == null ? DataBeanCache.getDataBean("PLUSCWODSINSTR", "PLUSCWODSINSTR") : databean;
/* 10118:12214 */     instrMbo = instrMbo == null ? databean.getMobileMbo(databean.getCurrentPosition()) : instrMbo;
/* 10119:      */     
/* 10120:      */ 
/* 10121:      */ 
/* 10122:      */ 
/* 10123:      */ 
/* 10124:      */ 
/* 10125:12221 */     String calStatus = instrMbo.getValue(fieldName);
/* 10126:12223 */     if (!calStatus.equalsIgnoreCase("")) {
/* 10127:12224 */       calStatus = ((WOApp)UIUtil.getApplication()).getInternalValue(databean, "PLUSCCALSTATUS", instrMbo.getValue(fieldName));
/* 10128:      */     }
/* 10129:12227 */     return calStatus;
/* 10130:      */   }
/* 10131:      */   
/* 10132:      */   private boolean isRepeatGroupElement(MobileMbo woDsPointMbo, MobileMbo woDsInstrMbo)
/* 10133:      */     throws MobileApplicationException
/* 10134:      */   {
/* 10135:12247 */     return (woDsInstrMbo.getBooleanValue("REPEATABLE")) && (!woDsPointMbo.getBooleanValue("ISAVERAGE")) && (woDsPointMbo.getBooleanValue("ISADDED"));
/* 10136:      */   }
/* 10137:      */   
/* 10138:      */   private PlusCDSCalculation buildPlusCDSCalculation(String dsPlanNum)
/* 10139:      */     throws MobileApplicationException
/* 10140:      */   {
/* 10141:12263 */     HashMap dsConfigMap = new HashMap();
/* 10142:12264 */     MobileMboDataBean pluscdsDataBean = pluscgetplusdsplan(dsPlanNum);
/* 10143:12265 */     MobileMboDataBean pluscdsconfigDataBean = pluscdsDataBean.getDataBean("PLUSCDSCONFIG");
/* 10144:12266 */     MobileMbo pluscdsconfigMbo = pluscdsconfigDataBean.getMobileMbo(0);
/* 10145:12267 */     String[] destAttrNames = pluscdsconfigDataBean.getMobileMboInfo().getAttributeNames();
/* 10146:12283 */     for (int l = 0; l < destAttrNames.length; l++)
/* 10147:      */     {
/* 10148:12284 */       String attributename = destAttrNames[l];
/* 10149:12285 */       dsConfigMap.put(attributename, pluscdsconfigMbo.getValue(attributename));
/* 10150:      */     }
/* 10151:12288 */     PlusCDSCalculation calc = new PlusCDSCalculation(dsConfigMap);
/* 10152:12289 */     return calc;
/* 10153:      */   }
/* 10154:      */   
/* 10155:      */   private void updateTolValues(String fieldName, PlusCMboRemote point, MobileMbo instr, PlusCDSCalculation calc)
/* 10156:      */     throws MobileApplicationException
/* 10157:      */   {
/* 10158:12301 */     if ((instr.getBooleanValue("MANUAL")) || ((instr.getBooleanValue("NONLINEAR")) && (!fieldName.equalsIgnoreCase("OUTPUTVALUE")))) {
/* 10159:12303 */       return;
/* 10160:      */     }
/* 10161:12307 */     calc.doUpdateTolValues(point, fieldName);
/* 10162:      */   }
/* 10163:      */   
/* 10164:      */   private PlusCMboRemote[] convertMboToPlusCMbo(MobileMbo[] mbos, UIEvent event)
/* 10165:      */     throws MobileApplicationException
/* 10166:      */   {
/* 10167:12324 */     PlusCMboRemote[] retval = new PlusCMboRemote[mbos.length];
/* 10168:12326 */     for (int i = 0; i < mbos.length; i++) {
/* 10169:12327 */       retval[i] = convertMboToPlusCMbo(mbos[i], event);
/* 10170:      */     }
/* 10171:12330 */     return retval;
/* 10172:      */   }
/* 10173:      */   
/* 10174:      */   private PlusCMboRemote convertMboToPlusCMbo(MobileMbo mbo, UIEvent event)
/* 10175:      */     throws MobileApplicationException
/* 10176:      */   {
/* 10177:12345 */     MobileMbo owner = mbo;
/* 10178:      */     
/* 10179:12347 */     PlusCMboRemote plusCMboRemote = null;
/* 10180:12348 */     String name = owner.getName();
/* 10181:      */     try
/* 10182:      */     {
/* 10183:12351 */       if (name.equalsIgnoreCase("PLUSCWODSPOINT")) {
/* 10184:12352 */         plusCMboRemote = PlusCToolKitTOMobile.createTO(owner, PlusCWODSPointTO.class);
/* 10185:12353 */       } else if (name.equalsIgnoreCase("PLUSCWODSINSTR")) {
/* 10186:12354 */         plusCMboRemote = PlusCToolKitTOMobile.createTO(owner, PlusCWODSInstrTO.class);
/* 10187:12355 */       } else if ((name.equalsIgnoreCase("PLUSCWODS")) || (name.equalsIgnoreCase("PLUSCWODSLOOPPOINTS"))) {
/* 10188:12356 */         plusCMboRemote = PlusCToolKitTOMobile.createTO(owner, PlusCWODSTO.class);
/* 10189:      */       } else {
/* 10190:12358 */         throw new RuntimeException("Not suitable class for " + name);
/* 10191:      */       }
/* 10192:12361 */       owner = owner.getOwner();
/* 10193:12362 */       while ((owner != null) && (owner.getName().startsWith("PLUSC")))
/* 10194:      */       {
/* 10195:12364 */         name = owner.getName();
/* 10196:12366 */         if (name.equalsIgnoreCase("PLUSCWODSPOINT"))
/* 10197:      */         {
/* 10198:12367 */           PlusCWODSPointTO pointTO = (PlusCWODSPointTO)PlusCToolKitTOMobile.createTO(owner, PlusCWODSPointTO.class);
/* 10199:12368 */           plusCMboRemote.setPlusCWODSPointTO(pointTO);
/* 10200:      */         }
/* 10201:12370 */         else if (name.equalsIgnoreCase("PLUSCWODSINSTR"))
/* 10202:      */         {
/* 10203:12371 */           PlusCWODSInstrTO instrTO = (PlusCWODSInstrTO)PlusCToolKitTOMobile.createTO(owner, PlusCWODSInstrTO.class);
/* 10204:12372 */           plusCMboRemote.setPlusCWODSInstrTO(instrTO);
/* 10205:      */         }
/* 10206:12374 */         else if (name.equalsIgnoreCase("PLUSCWODS"))
/* 10207:      */         {
/* 10208:12375 */           PlusCWODSTO planTO = (PlusCWODSTO)PlusCToolKitTOMobile.createTO(owner, PlusCWODSTO.class);
/* 10209:12376 */           plusCMboRemote.setPlusCWODSTO(planTO);
/* 10210:      */         }
/* 10211:      */         else
/* 10212:      */         {
/* 10213:12378 */           throw new RuntimeException("Not suitable class for " + name);
/* 10214:      */         }
/* 10215:12380 */         owner = owner.getOwner();
/* 10216:      */       }
/* 10217:      */     }
/* 10218:      */     catch (Exception e)
/* 10219:      */     {
/* 10220:12384 */       throw new MobileApplicationException(e);
/* 10221:      */     }
/* 10222:12387 */     plusCMboRemote.setLocale(Locale.getDefault());
/* 10223:      */     
/* 10224:12389 */     TextboxControl eventSource = (TextboxControl)event.getCreatingObject();
/* 10225:12390 */     String fieldName = eventSource.getControlData().getValue("dataattribute");
/* 10226:12391 */     plusCMboRemote.setFieldName(fieldName);
/* 10227:      */     
/* 10228:      */ 
/* 10229:      */ 
/* 10230:      */ 
/* 10231:      */ 
/* 10232:12397 */     return plusCMboRemote;
/* 10233:      */   }
/* 10234:      */   
/* 10235:      */   private void convertPlusCMboToMbo(MobileMbo target, PlusCMboRemote source)
/* 10236:      */     throws MobileApplicationException
/* 10237:      */   {
/* 10238:      */     try
/* 10239:      */     {
/* 10240:12402 */       PlusCToolKitTOMobile.setMboValues(target, source, false);
/* 10241:12403 */       source.clearAllChangedFieldsSets();
/* 10242:      */     }
/* 10243:      */     catch (Exception e)
/* 10244:      */     {
/* 10245:12405 */       throw new MobileApplicationException(e);
/* 10246:      */     }
/* 10247:      */   }
/* 10248:      */   
/* 10249:      */   private boolean isInputWithinRange(UIEvent event, TextboxControl eventSource, MobileMbo currentMobileMbo, MobileMbo instr)
/* 10250:      */     throws MobileApplicationException
/* 10251:      */   {
/* 10252:12422 */     String strValue = eventSource.getControlValue();
/* 10253:12423 */     String fieldTitle = eventSource.getTitle();
/* 10254:12425 */     if ((strValue == null) || (strValue.equals("")) || (currentMobileMbo.isNull("RON1LOWER")) || (currentMobileMbo.isNull("RON1UPPER"))) {
/* 10255:12427 */       return true;
/* 10256:      */     }
/* 10257:12431 */     double value = PlusCToolKitTOCommon.getDouble(strValue, Locale.US);
/* 10258:      */     
/* 10259:      */ 
/* 10260:      */ 
/* 10261:12435 */     double ron1lower = PlusCToolKitTOCommon.getDouble(currentMobileMbo.getValue("RON1LOWER"), Locale.US);
/* 10262:      */     
/* 10263:      */ 
/* 10264:12438 */     double ron1upper = PlusCToolKitTOCommon.getDouble(currentMobileMbo.getValue("RON1UPPER"), Locale.US);
/* 10265:12439 */     double rightRon1Lower = ron1lower;
/* 10266:12440 */     double rightRon1Upper = ron1upper;
/* 10267:12442 */     if (ron1lower - ron1upper > 0.0D)
/* 10268:      */     {
/* 10269:12443 */       rightRon1Lower = ron1upper;
/* 10270:12444 */       rightRon1Upper = ron1lower;
/* 10271:      */     }
/* 10272:12447 */     if ((value < rightRon1Lower) || (value > rightRon1Upper))
/* 10273:      */     {
/* 10274:12450 */       Object[] params = { fieldTitle, strValue, currentMobileMbo.getValue("RON1LOWER"), currentMobileMbo.getValue("RON1UPPER") };
/* 10275:12451 */       throw new MobileApplicationException("pluscStandardInputOutOfRange", params);
/* 10276:      */     }
/* 10277:12457 */     if (instr.getBooleanValue("CLIPLIMITSIN"))
/* 10278:      */     {
/* 10279:12459 */       double instrCalRangeFrom = PlusCToolKitTOCommon.getDouble(instr.getValue("INSTRCALRANGEFROM"), Locale.US);
/* 10280:12460 */       double instrCalRangeTo = PlusCToolKitTOCommon.getDouble(instr.getValue("INSTRCALRANGETO"), Locale.US);
/* 10281:      */       
/* 10282:12462 */       double lowerRangeLimit = instrCalRangeFrom <= instrCalRangeTo ? instrCalRangeFrom : instrCalRangeTo;
/* 10283:12463 */       double upperRangeLimit = instrCalRangeFrom > instrCalRangeTo ? instrCalRangeFrom : instrCalRangeTo;
/* 10284:12465 */       if ((value < lowerRangeLimit) || (value > upperRangeLimit))
/* 10285:      */       {
/* 10286:12468 */         Object[] params = { fieldTitle, strValue, instr.getValue("INSTRCALRANGEFROM"), instr.getValue("INSTRCALRANGETO") };
/* 10287:      */         
/* 10288:      */ 
/* 10289:      */ 
/* 10290:      */ 
/* 10291:12473 */         throw new MobileApplicationException("plusdsplan_PlusStandardInputOutOfRange", params);
/* 10292:      */       }
/* 10293:      */     }
/* 10294:12479 */     return true;
/* 10295:      */   }
/* 10296:      */   
/* 10297:      */   protected MobileMbo doCalculateAveragesAndStdDevs(MobileMbo woDsPointMbo, MobileMbo instr, MobileMboDataBean pointDatabean, String fieldName, UIEvent event)
/* 10298:      */     throws MobileApplicationException
/* 10299:      */   {
/* 10300:      */     try
/* 10301:      */     {
/* 10302:12500 */       PlusCMobileWODsPointDelegate woDsPoint = new PlusCMobileWODsPointDelegate(new MobileMboAdapter(woDsPointMbo, pointDatabean), null);
/* 10303:      */       
/* 10304:      */ 
/* 10305:12503 */       MobileMbo[] groupPoints = PlusCMobUtil.mboAdapterToMobileMboArray(woDsPoint.getGroupPoints());
/* 10306:12504 */       PlusCMboRemote[] groupPointsTO = convertMboToPlusCMbo(groupPoints, event);
/* 10307:      */       
/* 10308:      */ 
/* 10309:      */ 
/* 10310:12508 */       MobileMbo groupAveragePoint = ((MobileMboAdapter)woDsPoint.getGroupAveragePoint()).getMbo();
/* 10311:12509 */       groupAveragePoint.setOwner(instr);
/* 10312:12510 */       PlusCMboRemote groupAveragePointTO = convertMboToPlusCMbo(groupAveragePoint, event);
/* 10313:      */       
/* 10314:      */ 
/* 10315:      */ 
/* 10316:12514 */       PlusCDSCalculation calc = buildPlusCDSCalculation(groupAveragePointTO.getString("dsplannum"));
/* 10317:12515 */       calc.calculateAveragesAndStdDevs(groupPointsTO, groupAveragePointTO, fieldName);
/* 10318:      */       
/* 10319:      */ 
/* 10320:      */ 
/* 10321:12519 */       convertPlusCMboToMbo(groupAveragePoint, groupAveragePointTO);
/* 10322:      */       
/* 10323:      */ 
/* 10324:      */ 
/* 10325:      */ 
/* 10326:12524 */       UIUtil.getApplication().updateMobileMbo("PLUSCWODSPOINT", groupAveragePoint);
/* 10327:      */       
/* 10328:12526 */       return groupAveragePoint;
/* 10329:      */     }
/* 10330:      */     catch (Exception e)
/* 10331:      */     {
/* 10332:12528 */       MobileMboAdapter.wrapException(e);
/* 10333:      */     }
/* 10334:12530 */     return null;
/* 10335:      */   }
/* 10336:      */   
/* 10337:      */   public boolean pluscshowexceededmessage(MobileMbo pointMbo, UIEvent event, String fieldName)
/* 10338:      */     throws MobileApplicationException
/* 10339:      */   {
/* 10340:12546 */     boolean[] hasError = pluscpointhaserrors(pointMbo);
/* 10341:      */     
/* 10342:12548 */     String msgKey = null;
/* 10343:12550 */     if ((hasError[0] != 0) && (fieldName.startsWith("ASFOUND"))) {
/* 10344:12551 */       msgKey = "plusdsplan_PlusCPointAFTol";
/* 10345:12552 */     } else if ((hasError[1] != 0) && (fieldName.startsWith("ASLEFT"))) {
/* 10346:12553 */       msgKey = "plusdsplan_PlusCPointALTol";
/* 10347:      */     }
/* 10348:12556 */     if (msgKey != null)
/* 10349:      */     {
/* 10350:12557 */       String msg = MobileMessageGenerator.generate(msgKey, null);
/* 10351:12558 */       UIUtil.showMessageBoxControl("pluscdescbox", msg, event);
/* 10352:      */     }
/* 10353:12561 */     return true;
/* 10354:      */   }
/* 10355:      */   
/* 10356:      */   public void setPlusCFieldsReadOnly(AbstractMobileControl page, MobileMboDataBean dataBean, String[] names, boolean state)
/* 10357:      */     throws MobileApplicationException
/* 10358:      */   {
/* 10359:12570 */     MobileMbo thisMbo = null;
/* 10360:12571 */     thisMbo = dataBean.getMobileMbo() == null ? dataBean.getMobileMbo(0) : dataBean.getMobileMbo();
/* 10361:      */     
/* 10362:12573 */     setMobileMboFieldsReadOnly(thisMbo, names, state);
/* 10363:12574 */     setScreenFieldsReadOnly(page, names, state);
/* 10364:      */   }
/* 10365:      */   
/* 10366:      */   private boolean adjustFocus(AbstractMobileControl control, String pageType, String plantype)
/* 10367:      */   {
/* 10368:      */     String attributePrefix;
/* 10369:      */     String attributePrefix;
/* 10370:12591 */     if (pageType.equalsIgnoreCase("ASFOUNDPAGE")) {
/* 10371:12592 */       attributePrefix = "ASFOUND";
/* 10372:      */     } else {
/* 10373:12594 */       attributePrefix = "ASLEFT";
/* 10374:      */     }
/* 10375:      */     String attributeSuffix;
/* 10376:      */     String attributeSuffix;
/* 10377:12597 */     if (plantype.equalsIgnoreCase("ANALOG")) {
/* 10378:12598 */       attributeSuffix = "INPUT";
/* 10379:      */     } else {
/* 10380:12600 */       attributeSuffix = "SETPOINT";
/* 10381:      */     }
/* 10382:12603 */     String attributeName = attributePrefix + attributeSuffix;
/* 10383:      */     
/* 10384:12605 */     AbstractMobileControl c = PlusCMobUtil.getControlByAttribute(control, attributeName);
/* 10385:12606 */     if (c != null) {
/* 10386:12607 */       ((TextboxControl)c).setFocus();
/* 10387:      */     }
/* 10388:12610 */     return false;
/* 10389:      */   }
/* 10390:      */   
/* 10391:      */   public String getPlanTypeForPoint(MobileMboDataBean dataBean)
/* 10392:      */     throws MobileApplicationException
/* 10393:      */   {
/* 10394:12622 */     MobileMbo thisMbo = null;
/* 10395:12623 */     thisMbo = dataBean.getMobileMbo() == null ? dataBean.getMobileMbo(0) : dataBean.getMobileMbo();
/* 10396:12624 */     return thisMbo.getValue("PLANTYPE");
/* 10397:      */   }
/* 10398:      */   
/* 10399:      */   public void pluscsetcurrentinstrposition(MobileMbo pointMbo)
/* 10400:      */     throws MobileApplicationException
/* 10401:      */   {
/* 10402:12639 */     String instrSeq = pointMbo.getValue("INSTRSEQ");
/* 10403:12640 */     MobileMboDataBean instrDataBean = DataBeanCache.getDataBean("PLUSCWODSINSTR", "PLUSCWODSINSTR");
/* 10404:12641 */     for (int i = 0; i < instrDataBean.count(); i++) {
/* 10405:12642 */       if (instrDataBean.getMobileMbo(i).getValue("INSTRSEQ").equalsIgnoreCase(instrSeq)) {
/* 10406:12643 */         instrDataBean.setCurrentPosition(i);
/* 10407:      */       }
/* 10408:      */     }
/* 10409:      */   }
/* 10410:      */   
/* 10411:      */   protected String[] getReadOnlyFieldNames(MobileMbo pointMbo, String pageType, String planType)
/* 10412:      */     throws MobileApplicationException
/* 10413:      */   {
/* 10414:12662 */     MobileMbo instr = pointMbo.getOwner();
/* 10415:12663 */     boolean isNoAdjMade = instr.getBooleanValue("NOADJMADE");
/* 10416:12664 */     boolean canEditAsFoundAsLeft = plusccaneditasfoundasleftfields();
/* 10417:      */     
/* 10418:12666 */     boolean newTechPointEditable = true;
/* 10419:      */     
/* 10420:      */ 
/* 10421:      */ 
/* 10422:      */ 
/* 10423:      */ 
/* 10424:      */ 
/* 10425:      */ 
/* 10426:      */ 
/* 10427:      */ 
/* 10428:      */ 
/* 10429:      */ 
/* 10430:12678 */     Set readOnlyFields = new HashSet();
/* 10431:12683 */     if (pointMbo.getBooleanValue("CALPOINT"))
/* 10432:      */     {
/* 10433:12685 */       if ((planType.equalsIgnoreCase("DISCRETE")) || (isNoAdjMade) || (!canEditAsFoundAsLeft))
/* 10434:      */       {
/* 10435:12687 */         if ((pageType.equalsIgnoreCase("ASFOUNDPAGE")) || (isNoAdjMade) || (!canEditAsFoundAsLeft)) {
/* 10436:12688 */           readOnlyFields.addAll(Arrays.asList(new String[] { "ASFOUNDINPUT", "ASFOUNDOUTPUT" }));
/* 10437:      */         }
/* 10438:12691 */         if ((pageType.equalsIgnoreCase("ASLEFTPAGE")) || (isNoAdjMade) || (!canEditAsFoundAsLeft)) {
/* 10439:12692 */           readOnlyFields.addAll(Arrays.asList(new String[] { "ASLEFTINPUT", "ASLEFTOUTPUT" }));
/* 10440:      */         }
/* 10441:12696 */         if (((!pointMbo.getBooleanValue("SETPOINTADJ")) || (isNoAdjMade) || (!canEditAsFoundAsLeft)) && (!pointMbo.isNew())) {
/* 10442:12697 */           readOnlyFields.addAll(Arrays.asList(new String[] { "SETPOINTVALUE" }));
/* 10443:      */         }
/* 10444:12704 */         if ((pageType.equalsIgnoreCase("ASFOUNDPAGE")) && (!canEditAsFoundAsLeft)) {
/* 10445:12705 */           readOnlyFields.addAll(Arrays.asList(new String[] { "ASFOUNDSETPOINT" }));
/* 10446:      */         }
/* 10447:12708 */         if ((pageType.equalsIgnoreCase("ASLEFTPAGE")) && (!canEditAsFoundAsLeft)) {
/* 10448:12709 */           readOnlyFields.addAll(Arrays.asList(new String[] { "ASLEFTSETPOINT" }));
/* 10449:      */         }
/* 10450:12716 */         if ((pointMbo.getBooleanValue("ISADDED")) || (!newTechPointEditable)) {
/* 10451:12717 */           readOnlyFields.addAll(Arrays.asList(new String[] { "SETPOINTACTION", "SETPOINTVALUE" }));
/* 10452:      */         }
/* 10453:12722 */         readOnlyFields.addAll(Arrays.asList(new String[] { "INPUTVALUE", "OUTPUTVALUE" }));
/* 10454:      */       }
/* 10455:12727 */       if ((planType.equalsIgnoreCase("ANALOG")) || (isNoAdjMade))
/* 10456:      */       {
/* 10457:12729 */         if ((pageType.equalsIgnoreCase("ASFOUNDPAGE")) || (isNoAdjMade) || (!canEditAsFoundAsLeft)) {
/* 10458:12730 */           readOnlyFields.addAll(Arrays.asList(new String[] { "ASFOUNDSETPOINT" }));
/* 10459:      */         }
/* 10460:12733 */         if ((pageType.equalsIgnoreCase("ASLEFTPAGE")) || (isNoAdjMade) || (!canEditAsFoundAsLeft)) {
/* 10461:12734 */           readOnlyFields.addAll(Arrays.asList(new String[] { "ASLEFTSETPOINT" }));
/* 10462:      */         }
/* 10463:12741 */         readOnlyFields.addAll(Arrays.asList(new String[] { "SETPOINTACTION", "SETPOINTVALUE" }));
/* 10464:12744 */         if ((pointMbo.getBooleanValue("ISADDED")) || (!newTechPointEditable)) {
/* 10465:12745 */           readOnlyFields.addAll(Arrays.asList(new String[] { "INPUTVALUE", "OUTPUTVALUE" }));
/* 10466:      */         }
/* 10467:      */       }
/* 10468:12750 */       readOnlyFields.addAll(Arrays.asList(new String[] { "INSTRUMENTFUNCTION", "INSTRCALRANGEEUA", "INSTROUTRANGEEU" }));
/* 10469:      */     }
/* 10470:12753 */     else if (pointMbo.getBooleanValue("CALFUNCTION"))
/* 10471:      */     {
/* 10472:12755 */       if ((isNoAdjMade) || (!canEditAsFoundAsLeft))
/* 10473:      */       {
/* 10474:12757 */         if (pageType.equalsIgnoreCase("ASFOUNDPAGE")) {
/* 10475:12758 */           readOnlyFields.addAll(Arrays.asList(new String[] { "ASFOUNDPASS", "ASFOUNDFAIL" }));
/* 10476:      */         }
/* 10477:12761 */         if (pageType.equalsIgnoreCase("ASLEFTPAGE")) {
/* 10478:12762 */           readOnlyFields.addAll(Arrays.asList(new String[] { "ASLEFTPASS", "ASLEFTFAIL" }));
/* 10479:      */         }
/* 10480:      */       }
/* 10481:      */     }
/* 10482:12766 */     else if (pointMbo.getBooleanValue("CALDYNAMIC"))
/* 10483:      */     {
/* 10484:12768 */       if ((isNoAdjMade) || (!canEditAsFoundAsLeft))
/* 10485:      */       {
/* 10486:12770 */         if (pageType.equalsIgnoreCase("ASFOUNDPAGE")) {
/* 10487:12771 */           readOnlyFields.addAll(Arrays.asList(new String[] { "ASFOUNDINPUT", "ASFOUNDUNIT" }));
/* 10488:      */         }
/* 10489:12774 */         if (pageType.equalsIgnoreCase("ASLEFTPAGE")) {
/* 10490:12775 */           readOnlyFields.addAll(Arrays.asList(new String[] { "ASLEFTINPUT", "ASLEFTUNIT" }));
/* 10491:      */         }
/* 10492:      */       }
/* 10493:      */     }
/* 10494:12781 */     return (String[])readOnlyFields.toArray(new String[0]);
/* 10495:      */   }
/* 10496:      */   
/* 10497:      */   private void plusccachepointbean(MobileMboDataBean pointDataBean)
/* 10498:      */     throws MobileApplicationException
/* 10499:      */   {
/* 10500:12792 */     DataBeanCacheItem item = new DataBeanCacheItem("PLUSCWODSPOINT", "PLUSCWODSPOINT", pointDataBean);
/* 10501:12793 */     DataBeanCache.cacheDataBean("PLUSCWODSPOINT", item);
/* 10502:      */   }
/* 10503:      */   
/* 10504:      */   public MobileMbo pluscupdateinstrstatus(UIEvent event, MobileMboDataBean instrDataBean, MobileMboDataBean pointDataBean)
/* 10505:      */     throws MobileApplicationException
/* 10506:      */   {
/* 10507:12829 */     MobileMbo currentPointMbo = ((AbstractMobileControl)event.getCreatingObject()).getDataBean().getMobileMbo();
/* 10508:12830 */     setFailDSStatusSet();
/* 10509:12831 */     setPassDSStatusSet();
/* 10510:12832 */     boolean pointMboModified = false;
/* 10511:12834 */     if (((AbstractMobileControl)event.getCreatingObject()).getId().equalsIgnoreCase("pluscdsinstrpointsresultstbl"))
/* 10512:      */     {
/* 10513:12836 */       pointMboModified = currentPointMbo.getRDO().getBooleanValue("_MODIFIED");
/* 10514:12837 */       instrDataBean = pluscgetinstrbeanforpoint(currentPointMbo);
/* 10515:      */     }
/* 10516:12840 */     String passStatus = getDSPassStatus(instrDataBean);
/* 10517:12841 */     MobileMbo instrMbo = instrDataBean.getMobileMbo(instrDataBean.getCurrentPosition());
/* 10518:12843 */     if (pointMboModified)
/* 10519:      */     {
/* 10520:12845 */       MobileMboDataBean cachedInstrDataBean = getCachedDataBean("PLUSCWODSINSTR");
/* 10521:12846 */       int i = 0;
/* 10522:      */       MobileMbo cachedInstrMbo;
/* 10523:12848 */       while ((cachedInstrMbo = cachedInstrDataBean.getMobileMbo(i)) != null)
/* 10524:      */       {
/* 10525:12849 */         if ((cachedInstrMbo.getValue("WONUM").equalsIgnoreCase(currentPointMbo.getValue("WONUM"))) && (cachedInstrMbo.getValue("INSTRSEQ").equalsIgnoreCase(currentPointMbo.getValue("INSTRSEQ"))) && (cachedInstrMbo.getValue("DSPLANNUM").equalsIgnoreCase(currentPointMbo.getValue("DSPLANNUM"))) && (cachedInstrMbo.getValue("WODSPLAN").equalsIgnoreCase(currentPointMbo.getValue("WODSPLAN"))) && (cachedInstrMbo.getValue("REVISIONNUM").equalsIgnoreCase(currentPointMbo.getValue("REVISIONNUM"))) && (cachedInstrMbo.getValue("SITEID").equalsIgnoreCase(currentPointMbo.getValue("SITEID"))))
/* 10526:      */         {
/* 10527:12856 */           String currentFieldValue = cachedInstrMbo.getValue("ASFOUNDCOMMENTS");
/* 10528:12857 */           cachedInstrMbo.setValue("ASFOUNDCOMMENTS", (currentFieldValue == null ? "" : currentFieldValue) + 1, false);
/* 10529:12858 */           cachedInstrMbo.setValue("ASFOUNDCOMMENTS", currentFieldValue, false);
/* 10530:      */         }
/* 10531:12860 */         i++;
/* 10532:      */       }
/* 10533:      */     }
/* 10534:12864 */     String pluscautostatusMaxVar = ((WOApp)UIUtil.getApplication()).getMaxVar(instrDataBean, "PLUSCAUTOSTATUS");
/* 10535:12865 */     boolean pluscautostatus = pluscautostatusMaxVar.equalsIgnoreCase("1");
/* 10536:12867 */     if (pluscautostatus)
/* 10537:      */     {
/* 10538:12868 */       boolean bTolStatusDefined = false;
/* 10539:12869 */       boolean bSkipAsFound = false;
/* 10540:12870 */       boolean bSkipAsLeft = false;
/* 10541:12871 */       int iAsFoundStatusSet = 0;
/* 10542:12872 */       int iAsLeftStatusSet = 0;
/* 10543:      */       
/* 10544:12874 */       String status1 = null;
/* 10545:12875 */       String status2 = null;
/* 10546:12876 */       String status3 = null;
/* 10547:12877 */       String status4 = null;
/* 10548:12881 */       if (instrMbo.getBooleanValue("CALPOINT"))
/* 10549:      */       {
/* 10550:12883 */         if (!instrMbo.isNull("TOL1STATUS"))
/* 10551:      */         {
/* 10552:12885 */           bTolStatusDefined = true;
/* 10553:      */           
/* 10554:12887 */           boolean bCheckTol1 = !instrMbo.isNull("TOL1STATUS");
/* 10555:12888 */           boolean bCheckTol2 = !instrMbo.isNull("TOL2STATUS");
/* 10556:12889 */           boolean bCheckTol3 = !instrMbo.isNull("TOL3STATUS");
/* 10557:12890 */           boolean bCheckTol4 = !instrMbo.isNull("TOL4STATUS");
/* 10558:      */           
/* 10559:12892 */           status1 = instrMbo.getValue("TOL1STATUS");
/* 10560:12893 */           status2 = instrMbo.getValue("TOL2STATUS");
/* 10561:12894 */           status3 = instrMbo.getValue("TOL3STATUS");
/* 10562:12895 */           status4 = instrMbo.getValue("TOL4STATUS");
/* 10563:      */           
/* 10564:      */ 
/* 10565:      */ 
/* 10566:      */ 
/* 10567:      */ 
/* 10568:      */ 
/* 10569:      */ 
/* 10570:      */ 
/* 10571:      */ 
/* 10572:12905 */           MobileMbo pointMbo = null;
/* 10573:      */           
/* 10574:      */ 
/* 10575:      */ 
/* 10576:      */ 
/* 10577:12910 */           int iloop = 0;
/* 10578:12911 */           while (((pointMbo = pointDataBean.getMobileMbo(iloop)) != null) && ((!bSkipAsFound) || (!bSkipAsLeft)))
/* 10579:      */           {
/* 10580:12914 */             PlusCWODsPointDelegate pointDel = new PlusCMobileWODsPointDelegate(new MobileMboAdapter(pointMbo, pointDataBean), null);
/* 10581:      */             try
/* 10582:      */             {
/* 10583:12916 */               pointMbo = ((MobileMboAdapter)pointDel.getGroupAveragePoint()).getMbo();
/* 10584:      */             }
/* 10585:      */             catch (Exception e)
/* 10586:      */             {
/* 10587:12917 */               MobileMboAdapter.wrapException(e);
/* 10588:      */             }
/* 10589:12920 */             if ((!pointMbo.getValue("WODSNUM").equals(instrMbo.getValue("WODSNUM"))) || (!pointMbo.getValue("INSTRSEQ").equals(instrMbo.getValue("INSTRSEQ"))))
/* 10590:      */             {
/* 10591:12922 */               iloop++;
/* 10592:      */             }
/* 10593:      */             else
/* 10594:      */             {
/* 10595:12926 */               if (!bSkipAsFound)
/* 10596:      */               {
/* 10597:12929 */                 if ((bCheckTol1) && (pointMbo.isNull("ASFOUNDERROR1"))) {
/* 10598:12930 */                   bSkipAsFound = true;
/* 10599:      */                 }
/* 10600:12931 */                 if ((bCheckTol2) && (pointMbo.isNull("ASFOUNDERROR2"))) {
/* 10601:12932 */                   bSkipAsFound = true;
/* 10602:      */                 }
/* 10603:12933 */                 if ((bCheckTol3) && (pointMbo.isNull("ASFOUNDERROR3"))) {
/* 10604:12934 */                   bSkipAsFound = true;
/* 10605:      */                 }
/* 10606:12935 */                 if ((bCheckTol4) && (pointMbo.isNull("ASFOUNDERROR4"))) {
/* 10607:12936 */                   bSkipAsFound = true;
/* 10608:      */                 }
/* 10609:      */               }
/* 10610:12939 */               if (!bSkipAsLeft)
/* 10611:      */               {
/* 10612:12942 */                 if ((bCheckTol1) && (pointMbo.isNull("ASLEFTERROR1"))) {
/* 10613:12943 */                   bSkipAsLeft = true;
/* 10614:      */                 }
/* 10615:12944 */                 if ((bCheckTol2) && (pointMbo.isNull("ASLEFTERROR2"))) {
/* 10616:12945 */                   bSkipAsLeft = true;
/* 10617:      */                 }
/* 10618:12946 */                 if ((bCheckTol3) && (pointMbo.isNull("ASLEFTERROR3"))) {
/* 10619:12947 */                   bSkipAsLeft = true;
/* 10620:      */                 }
/* 10621:12948 */                 if ((bCheckTol4) && (pointMbo.isNull("ASLEFTERROR4"))) {
/* 10622:12949 */                   bSkipAsLeft = true;
/* 10623:      */                 }
/* 10624:      */               }
/* 10625:12952 */               if ((bSkipAsFound) && (bSkipAsLeft))
/* 10626:      */               {
/* 10627:12953 */                 iloop++;
/* 10628:      */               }
/* 10629:      */               else
/* 10630:      */               {
/* 10631:12957 */                 if (!bSkipAsFound)
/* 10632:      */                 {
/* 10633:12961 */                   if ((bCheckTol1) && (iAsFoundStatusSet < 1) && (PlusCToolKitTOCommon.getDouble(pointMbo.getValue("ASFOUNDERROR1"), Locale.US) != 0.0D)) {
/* 10634:12962 */                     iAsFoundStatusSet = 1;
/* 10635:      */                   }
/* 10636:12963 */                   if ((bCheckTol2) && (iAsFoundStatusSet < 2) && (PlusCToolKitTOCommon.getDouble(pointMbo.getValue("ASFOUNDERROR2"), Locale.US) != 0.0D)) {
/* 10637:12964 */                     iAsFoundStatusSet = 2;
/* 10638:      */                   }
/* 10639:12965 */                   if ((bCheckTol3) && (iAsFoundStatusSet < 3) && (PlusCToolKitTOCommon.getDouble(pointMbo.getValue("ASFOUNDERROR3"), Locale.US) != 0.0D)) {
/* 10640:12966 */                     iAsFoundStatusSet = 3;
/* 10641:      */                   }
/* 10642:12967 */                   if ((bCheckTol4) && (iAsFoundStatusSet < 4) && (PlusCToolKitTOCommon.getDouble(pointMbo.getValue("ASFOUNDERROR4"), Locale.US) != 0.0D)) {
/* 10643:12968 */                     iAsFoundStatusSet = 4;
/* 10644:      */                   }
/* 10645:      */                 }
/* 10646:12971 */                 if (!bSkipAsLeft)
/* 10647:      */                 {
/* 10648:12974 */                   if ((bCheckTol1) && (iAsLeftStatusSet < 1) && (PlusCToolKitTOCommon.getDouble(pointMbo.getValue("ASLEFTERROR1"), Locale.US) != 0.0D)) {
/* 10649:12975 */                     iAsLeftStatusSet = 1;
/* 10650:      */                   }
/* 10651:12976 */                   if ((bCheckTol2) && (iAsLeftStatusSet < 2) && (PlusCToolKitTOCommon.getDouble(pointMbo.getValue("ASLEFTERROR2"), Locale.US) != 0.0D)) {
/* 10652:12977 */                     iAsLeftStatusSet = 2;
/* 10653:      */                   }
/* 10654:12978 */                   if ((bCheckTol3) && (iAsLeftStatusSet < 3) && (PlusCToolKitTOCommon.getDouble(pointMbo.getValue("ASLEFTERROR3"), Locale.US) != 0.0D)) {
/* 10655:12979 */                     iAsLeftStatusSet = 3;
/* 10656:      */                   }
/* 10657:12980 */                   if ((bCheckTol4) && (iAsLeftStatusSet < 4) && (PlusCToolKitTOCommon.getDouble(pointMbo.getValue("ASLEFTERROR4"), Locale.US) != 0.0D)) {
/* 10658:12981 */                     iAsLeftStatusSet = 4;
/* 10659:      */                   }
/* 10660:      */                 }
/* 10661:12984 */                 iloop++;
/* 10662:      */               }
/* 10663:      */             }
/* 10664:      */           }
/* 10665:      */         }
/* 10666:12991 */         if (bTolStatusDefined)
/* 10667:      */         {
/* 10668:12992 */           if (!bSkipAsFound)
/* 10669:      */           {
/* 10670:12993 */             if (iAsFoundStatusSet == 1) {
/* 10671:12994 */               instrMbo.setValue("ASFOUNDCALSTATUS", status1, false);
/* 10672:12995 */             } else if (iAsFoundStatusSet == 2) {
/* 10673:12996 */               instrMbo.setValue("ASFOUNDCALSTATUS", status2, false);
/* 10674:12997 */             } else if (iAsFoundStatusSet == 3) {
/* 10675:12998 */               instrMbo.setValue("ASFOUNDCALSTATUS", status3, false);
/* 10676:12999 */             } else if (iAsFoundStatusSet == 4) {
/* 10677:13000 */               instrMbo.setValue("ASFOUNDCALSTATUS", status4, false);
/* 10678:      */             } else {
/* 10679:13002 */               instrMbo.setValue("ASFOUNDCALSTATUS", passStatus, false);
/* 10680:      */             }
/* 10681:      */           }
/* 10682:      */           else {
/* 10683:13004 */             instrMbo.setValue("ASFOUNDCALSTATUS", "", false);
/* 10684:      */           }
/* 10685:13007 */           if (!bSkipAsLeft)
/* 10686:      */           {
/* 10687:13008 */             if (iAsLeftStatusSet == 1) {
/* 10688:13009 */               instrMbo.setValue("ASLEFTCALSTATUS", status1, false);
/* 10689:13010 */             } else if (iAsLeftStatusSet == 2) {
/* 10690:13011 */               instrMbo.setValue("ASLEFTCALSTATUS", status2, false);
/* 10691:13012 */             } else if (iAsLeftStatusSet == 3) {
/* 10692:13013 */               instrMbo.setValue("ASLEFTCALSTATUS", status3, false);
/* 10693:13014 */             } else if (iAsLeftStatusSet == 4) {
/* 10694:13015 */               instrMbo.setValue("ASLEFTCALSTATUS", status4, false);
/* 10695:      */             } else {
/* 10696:13017 */               instrMbo.setValue("ASLEFTCALSTATUS", passStatus, false);
/* 10697:      */             }
/* 10698:      */           }
/* 10699:      */           else {
/* 10700:13019 */             instrMbo.setValue("ASLEFTCALSTATUS", "", false);
/* 10701:      */           }
/* 10702:      */         }
/* 10703:      */       }
/* 10704:13023 */       else if (instrMbo.getBooleanValue("CALFUNCTION"))
/* 10705:      */       {
/* 10706:13025 */         boolean allAsFoundEntered = true;
/* 10707:13026 */         boolean allAsLeftEntered = true;
/* 10708:      */         
/* 10709:13028 */         String asFoundStatus = null;
/* 10710:13029 */         String asLeftStatus = null;
/* 10711:      */         
/* 10712:      */ 
/* 10713:13032 */         MobileMbo point = null;
/* 10714:      */         
/* 10715:      */ 
/* 10716:      */ 
/* 10717:      */ 
/* 10718:13037 */         int iloop = 0;
/* 10719:13038 */         while (((point = pointDataBean.getMobileMbo(iloop)) != null) && ((!bSkipAsFound) || (!bSkipAsLeft))) {
/* 10720:13041 */           if ((!point.getValue("WODSNUM").equals(instrMbo.getValue("WODSNUM"))) || (!point.getValue("INSTRSEQ").equals(instrMbo.getValue("INSTRSEQ"))))
/* 10721:      */           {
/* 10722:13043 */             iloop++;
/* 10723:      */           }
/* 10724:      */           else
/* 10725:      */           {
/* 10726:13048 */             if (((point.isNull("ASFOUNDPASS")) || (!point.getBooleanValue("ASFOUNDPASS"))) && ((point.isNull("ASFOUNDFAIL")) || (!point.getBooleanValue("ASFOUNDFAIL"))))
/* 10727:      */             {
/* 10728:13051 */               allAsFoundEntered = false;
/* 10729:13052 */               asFoundStatus = null;
/* 10730:      */             }
/* 10731:13056 */             if (((point.isNull("ASLEFTPASS")) || (!point.getBooleanValue("ASLEFTPASS"))) && ((point.isNull("ASLEFTFAIL")) || (!point.getBooleanValue("ASLEFTFAIL"))))
/* 10732:      */             {
/* 10733:13059 */               allAsLeftEntered = false;
/* 10734:13060 */               asLeftStatus = null;
/* 10735:      */             }
/* 10736:13063 */             boolean asFoundFail = point.isNull("ASFOUNDFAIL") ? false : point.getBooleanValue("ASFOUNDFAIL");
/* 10737:13065 */             if ((asFoundFail) && 
/* 10738:13066 */               (allAsFoundEntered)) {
/* 10739:13067 */               asFoundStatus = ((WOApp)UIUtil.getApplication()).getDefaultValue(pointDataBean, "PLUSCCALSTATUS", "FAIL");
/* 10740:      */             }
/* 10741:13071 */             boolean asLeftFail = point.isNull("ASLEFTFAIL") ? false : point.getBooleanValue("ASLEFTFAIL");
/* 10742:13073 */             if ((asLeftFail) && 
/* 10743:13074 */               (allAsLeftEntered)) {
/* 10744:13075 */               asLeftStatus = ((WOApp)UIUtil.getApplication()).getDefaultValue(pointDataBean, "PLUSCCALSTATUS", "FAIL");
/* 10745:      */             }
/* 10746:13079 */             iloop++;
/* 10747:      */           }
/* 10748:      */         }
/* 10749:13082 */         if ((allAsFoundEntered) && (asFoundStatus == null)) {
/* 10750:13083 */           asFoundStatus = ((WOApp)UIUtil.getApplication()).getDefaultValue(pointDataBean, "PLUSCCALSTATUS", "PASS");
/* 10751:      */         }
/* 10752:13085 */         if ((allAsLeftEntered) && (asLeftStatus == null)) {
/* 10753:13086 */           asLeftStatus = ((WOApp)UIUtil.getApplication()).getDefaultValue(pointDataBean, "PLUSCCALSTATUS", "PASS");
/* 10754:      */         }
/* 10755:13089 */         if (asFoundStatus != null) {
/* 10756:13090 */           instrMbo.setValue("ASFOUNDCALSTATUS", asFoundStatus, false);
/* 10757:13092 */         } else if (bSkipAsFound) {
/* 10758:13093 */           instrMbo.setValue("ASFOUNDCALSTATUS", null, false);
/* 10759:      */         }
/* 10760:13096 */         if (asLeftStatus != null) {
/* 10761:13097 */           instrMbo.setValue("ASLEFTCALSTATUS", asLeftStatus, false);
/* 10762:13099 */         } else if (bSkipAsLeft) {
/* 10763:13100 */           instrMbo.setValue("ASLEFTCALSTATUS", null, false);
/* 10764:      */         }
/* 10765:      */       }
/* 10766:      */     }
/* 10767:13111 */     return instrMbo;
/* 10768:      */   }
/* 10769:      */   
/* 10770:      */   public void pluscvalidatenoadjmade(boolean noAdjMade, PlusCWODsInstrDelegate woDsInstr, UIEvent event)
/* 10771:      */     throws MobileApplicationException
/* 10772:      */   {
/* 10773:13128 */     if (noAdjMade)
/* 10774:      */     {
/* 10775:      */       try
/* 10776:      */       {
/* 10777:13130 */         if (woDsInstr.meetsNoAdjustmentConditions())
/* 10778:      */         {
/* 10779:13135 */           String msg = MobileMessageGenerator.generate("plusdsplan_NoAdjMadeYes", null);
/* 10780:13136 */           UIUtil.showMessageBoxControl("pluscinvalidnumber", msg, event);
/* 10781:      */         }
/* 10782:      */       }
/* 10783:      */       catch (Exception e)
/* 10784:      */       {
/* 10785:13138 */         MobileMboAdapter.wrapException(e);
/* 10786:      */       }
/* 10787:      */     }
/* 10788:      */     else
/* 10789:      */     {
/* 10790:13143 */       String msg = MobileMessageGenerator.generate("plusdsplan_NoAdjMadeNo", null);
/* 10791:13144 */       UIUtil.showMessageBoxControl("pluscinvalidnumber", msg, event);
/* 10792:      */     }
/* 10793:      */   }
/* 10794:      */   
/* 10795:      */   protected void setMobileMboFieldsReadOnly(MobileMbo mbo, String[] names, boolean state)
/* 10796:      */   {
/* 10797:13161 */     for (int i = 0; i < names.length; i++) {
/* 10798:13162 */       mbo.setReadOnly(names[i], state);
/* 10799:      */     }
/* 10800:      */   }
/* 10801:      */   
/* 10802:      */   private String getWorktypeCal(MobileMboDataBean dataBean)
/* 10803:      */     throws MobileApplicationException
/* 10804:      */   {
/* 10805:13170 */     String externalWorktype = ((WOApp)UIUtil.getApplication()).getMaxVar(dataBean, "PLUSCWORKTYPECAL");
/* 10806:13171 */     String translatedWorktype = ((WOApp)UIUtil.getApplication()).getExternalValue(dataBean, "PLUSCWORKTYPE", externalWorktype);
/* 10807:13172 */     return translatedWorktype;
/* 10808:      */   }
/* 10809:      */   
/* 10810:      */   public String getWorkType(MobileMbo woMbo)
/* 10811:      */     throws MobileApplicationException
/* 10812:      */   {
/* 10813:13183 */     MobileMboDataBean workTypeBean = DataBeanCache.getDataBean("WORKTYPE", "WORKTYPE");
/* 10814:13185 */     for (int i = 0; i < workTypeBean.count(); i++)
/* 10815:      */     {
/* 10816:13186 */       MobileMbo current = workTypeBean.getMobileMbo(i);
/* 10817:13187 */       if (PlusCMobUtil.mboEquals(current, woMbo, new String[] { "WORKTYPE", "ORGID" })) {
/* 10818:13188 */         return current.getValue("TYPE");
/* 10819:      */       }
/* 10820:      */     }
/* 10821:13192 */     return "";
/* 10822:      */   }
/* 10823:      */   
/* 10824:      */   public MobileMboDataBean pluscgetplusdsplan(String dsplannum)
/* 10825:      */     throws MobileApplicationException
/* 10826:      */   {
/* 10827:13206 */     MobileMboDataBeanManager plusdsplanDBMgr = new MobileMboDataBeanManager("PLUSDSPLAN");
/* 10828:13207 */     MobileMboDataBean plusdsplanDataBean = plusdsplanDBMgr.getDataBean();
/* 10829:13208 */     plusdsplanDataBean.getQBE().reset();
/* 10830:13209 */     plusdsplanDataBean.getQBE().setQbeExactMatch(true);
/* 10831:13210 */     plusdsplanDataBean.getQBE().setQBE("DSPLANNUM", dsplannum);
/* 10832:13211 */     plusdsplanDataBean.reset();
/* 10833:      */     
/* 10834:13213 */     return plusdsplanDataBean;
/* 10835:      */   }
/* 10836:      */   
/* 10837:      */   public boolean[] pluscpointhaserrors(MobileMbo pointMbo)
/* 10838:      */     throws MobileApplicationException
/* 10839:      */   {
/* 10840:13229 */     String fieldName = "";
/* 10841:      */     
/* 10842:13231 */     int iloop = 1;
/* 10843:13232 */     int zloop = 0;
/* 10844:13233 */     boolean[] hasError = { false, false };
/* 10845:      */     
/* 10846:13235 */     String[] possibleErrors = { "ASFOUNDERROR", "ASLEFTERROR" };
/* 10847:13237 */     for (zloop = 0; zloop <= 1; zloop++) {
/* 10848:13239 */       for (iloop = 1; iloop <= 4; iloop++)
/* 10849:      */       {
/* 10850:13242 */         fieldName = possibleErrors[zloop] + iloop;
/* 10851:13243 */         double errorValue = PlusCToolKitTOCommon.getDouble(pointMbo.getValue(fieldName), Locale.US);
/* 10852:13244 */         if ((!pointMbo.isNull(fieldName)) && (errorValue != 0.0D)) {
/* 10853:13245 */           hasError[zloop] = true;
/* 10854:      */         }
/* 10855:      */       }
/* 10856:      */     }
/* 10857:13252 */     return hasError;
/* 10858:      */   }
/* 10859:      */   
/* 10860:      */   protected void setScreenFieldsReadOnly(AbstractMobileControl page, String[] names, boolean state)
/* 10861:      */   {
/* 10862:13265 */     for (int i = 0; i < names.length; i++)
/* 10863:      */     {
/* 10864:13266 */       AbstractMobileControl control = PlusCMobUtil.getControlByAttribute(page, names[i]);
/* 10865:13267 */       if (control != null) {
/* 10866:13268 */         control.setReadonly(state);
/* 10867:      */       }
/* 10868:      */     }
/* 10869:      */   }
/* 10870:      */   
/* 10871:      */   protected void setCurrentScreenDataSrc(String dataSrcName)
/* 10872:      */   {
/* 10873:13274 */     ControlData controlData = UIUtil.getCurrentScreen().getControlData();
/* 10874:13275 */     controlData.putValue("datasrcname", dataSrcName);
/* 10875:13276 */     UIUtil.getCurrentScreen().setControlData(controlData);
/* 10876:      */   }
/* 10877:      */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.mobilewo.MobileWOAppEventHandler
 * JD-Core Version:    0.7.0.1
 */