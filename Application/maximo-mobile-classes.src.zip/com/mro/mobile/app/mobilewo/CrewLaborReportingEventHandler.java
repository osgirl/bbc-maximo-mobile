/*   1:    */ package com.mro.mobile.app.mobilewo;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.app.CurrentTimeProvider;
/*   5:    */ import com.mro.mobile.app.DefaultMobileMboDataFormatter;
/*   6:    */ import com.mro.mobile.mbo.MobileMbo;
/*   7:    */ import com.mro.mobile.mbo.MobileMboQBE;
/*   8:    */ import com.mro.mobile.ui.DataBeanCache;
/*   9:    */ import com.mro.mobile.ui.MobileMboDataBean;
/*  10:    */ import com.mro.mobile.ui.MobileMboDataBeanManager;
/*  11:    */ import com.mro.mobile.ui.event.UIEvent;
/*  12:    */ import com.mro.mobile.ui.res.UIUtil;
/*  13:    */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*  14:    */ import com.mro.mobile.ui.res.controls.DropDownControl;
/*  15:    */ import com.mro.mobile.ui.res.controls.LinkControl;
/*  16:    */ import com.mro.mobile.ui.res.controls.LookupControl;
/*  17:    */ import com.mro.mobile.ui.res.controls.TextboxControl;
/*  18:    */ import com.mro.mobileapp.WOApp;
/*  19:    */ import java.util.Calendar;
/*  20:    */ import java.util.Date;
/*  21:    */ import java.util.Locale;
/*  22:    */ import java.util.TimeZone;
/*  23:    */ 
/*  24:    */ public class CrewLaborReportingEventHandler
/*  25:    */   extends BulkLaborReportingLabTransEventHandler
/*  26:    */ {
/*  27:    */   public boolean performEvent(UIEvent event)
/*  28:    */     throws MobileApplicationException
/*  29:    */   {
/*  30: 41 */     if (event == null) {
/*  31: 42 */       return super.performEvent(event);
/*  32:    */     }
/*  33: 44 */     String eventName = event.getEventName();
/*  34: 46 */     if (eventName.equalsIgnoreCase("initCrewReportPage")) {
/*  35: 47 */       return initCrewReportPage(event);
/*  36:    */     }
/*  37: 48 */     if (eventName.equalsIgnoreCase("validateCrewLabTransRecordClass")) {
/*  38: 49 */       return validateCrewLabTransRecordClass(event);
/*  39:    */     }
/*  40: 50 */     if (eventName.equalsIgnoreCase("validateCrewLabTransRecord")) {
/*  41: 51 */       return validateCrewLabTransRecord(event);
/*  42:    */     }
/*  43: 52 */     if (eventName.equalsIgnoreCase("saveclose")) {
/*  44: 53 */       return validateCrewReportPage(event);
/*  45:    */     }
/*  46: 54 */     if (eventName.equalsIgnoreCase("displayworklist")) {
/*  47: 55 */       return displayWorkList(event);
/*  48:    */     }
/*  49: 56 */     if (eventName.equalsIgnoreCase("currentCrewExists")) {
/*  50: 57 */       return currentCrewExists(event);
/*  51:    */     }
/*  52: 58 */     if (eventName.equalsIgnoreCase("insertcrewlabtrans")) {
/*  53: 60 */       insertcrewlabactual(event);
/*  54: 61 */     } else if (eventName.equalsIgnoreCase("insertcrewlabtranswo")) {
/*  55: 62 */       insertcrewlabactualwo(event);
/*  56:    */     }
/*  57: 64 */     return super.performEvent(event);
/*  58:    */   }
/*  59:    */   
/*  60:    */   protected boolean displayWorkList(UIEvent event)
/*  61:    */     throws MobileApplicationException
/*  62:    */   {
/*  63: 68 */     MobileMboDataBean databean = ((LookupControl)event.getCreatingObject()).getDataBean();
/*  64: 69 */     MobileMboDataBean crewReportBean = DataBeanCache.getDataBean("CREWREPORTINFO", "CREWREPORTINFO");
/*  65: 70 */     String recordclass = crewReportBean.getValue("RECORDCLASS");
/*  66:    */     
/*  67: 72 */     databean.getQBE().setQbeExactMatch(true);
/*  68: 73 */     databean.getQBE().setQBE("HISTORYFLAG", "0");
/*  69:    */     
/*  70:    */ 
/*  71: 76 */     String status = null;
/*  72: 77 */     status = ((WOApp)UIUtil.getApplication()).getExternalValue(crewReportBean, "WOSTATUS", "WAPPR");
/*  73:    */     
/*  74: 79 */     databean.getQBE().setQBE("STATUS", "!=" + status);
/*  75: 80 */     databean.getQBE().setQBE("CLASS", recordclass);
/*  76:    */     
/*  77: 82 */     databean.setInternalQBE("SITEID", "!=~NULL~");
/*  78: 83 */     databean.reset();
/*  79: 84 */     return true;
/*  80:    */   }
/*  81:    */   
/*  82:    */   protected boolean validateCrewReportPage(UIEvent event)
/*  83:    */     throws MobileApplicationException
/*  84:    */   {
/*  85: 88 */     doPageValidation(event);
/*  86: 89 */     if (!event.errorOccured()) {
/*  87: 90 */       reportLaborForCurrentCrew(event);
/*  88:    */     }
/*  89: 92 */     return false;
/*  90:    */   }
/*  91:    */   
/*  92:    */   private void reportLaborForCurrentCrew(UIEvent event)
/*  93:    */     throws MobileApplicationException
/*  94:    */   {
/*  95: 96 */     MobileMboDataBean currentCrewBean = DataBeanCache.getDataBean("CURRENTCREW", "CURRENTCREW");
/*  96: 97 */     MobileMboDataBean crewReportBean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*  97: 98 */     if (isCrewReportingForWO(crewReportBean))
/*  98:    */     {
/*  99: 99 */       MobileMboDataBean woBean = new MobileMboDataBeanManager("WORKORDER").getDataBean();
/* 100:100 */       woBean.getQBE().setQBE("WONUM", crewReportBean.getValue("RECORD"));
/* 101:101 */       woBean.getQBE().setQBE("SITEID", crewReportBean.getValue("SITEID"));
/* 102:102 */       woBean.reset();
/* 103:103 */       if (woBean.getMobileMbo(0) != null)
/* 104:    */       {
/* 105:106 */         MobileMboDataBean woLabTransBean = woBean.getDataBean("WOLABTRANS");
/* 106:107 */         if (woLabTransBean == null) {
/* 107:108 */           woLabTransBean = DataBeanCache.findDataBean("WOLABTRANS");
/* 108:    */         }
/* 109:110 */         if (woLabTransBean == null) {
/* 110:112 */           return;
/* 111:    */         }
/* 112:117 */         int count = currentCrewBean.count();
/* 113:118 */         for (int i = 0; i < count; i++)
/* 114:    */         {
/* 115:119 */           MobileMbo crewMember = currentCrewBean.getMobileMbo(i);
/* 116:120 */           boolean setLastInserted = false;
/* 117:121 */           if (i == count - 1) {
/* 118:123 */             setLastInserted = true;
/* 119:    */           }
/* 120:126 */           createWOLabTrans(crewMember, woLabTransBean, crewReportBean, setLastInserted);
/* 121:    */         }
/* 122:128 */         woBean.getDataBeanManager().save();
/* 123:    */       }
/* 124:    */     }
/* 125:    */     else
/* 126:    */     {
/* 127:131 */       MobileMboDataBean tkBean = new MobileMboDataBeanManager("TICKET").getDataBean();
/* 128:132 */       tkBean.getQBE().setQBE("TICKETID", crewReportBean.getValue("RECORD"));
/* 129:133 */       tkBean.getQBE().setQBE("CLASS", crewReportBean.getValue("RECORDCLASS"));
/* 130:134 */       tkBean.reset();
/* 131:135 */       if (tkBean.getMobileMbo(0) != null)
/* 132:    */       {
/* 133:138 */         int count = currentCrewBean.count();
/* 134:139 */         for (int i = 0; i < count; i++)
/* 135:    */         {
/* 136:140 */           MobileMbo crewMember = currentCrewBean.getMobileMbo(i);
/* 137:141 */           boolean setLastInserted = false;
/* 138:142 */           if (i == count - 1) {
/* 139:144 */             setLastInserted = true;
/* 140:    */           }
/* 141:146 */           createTKLabTrans(crewMember, tkBean.getDataBean("TKLABTRANS"), crewReportBean, setLastInserted);
/* 142:    */         }
/* 143:148 */         tkBean.getDataBeanManager().save();
/* 144:    */       }
/* 145:    */     }
/* 146:    */   }
/* 147:    */   
/* 148:    */   private void createWOLabTrans(MobileMbo crewMember, MobileMboDataBean woLabTransBean, MobileMboDataBean crewReportBean, boolean isLastInserted)
/* 149:    */     throws MobileApplicationException
/* 150:    */   {
/* 151:156 */     String[] crewMemberValues = { "LABORCODE", "CRAFT", "SKILLLEVEL", "CONTRACTNUM", "VENDOR" };
/* 152:157 */     String[] crewReportBeanValues = { "SITEID", "ORGID", "REGULARHRS", "PREMIUMPAYCODE", "PREMIUMPAYHOURS", "TRANSTYPE", "ACTUALSTASKID" };
/* 153:158 */     boolean autoApprove = isAutoApproveConf(crewMember, woLabTransBean);
/* 154:    */     
/* 155:160 */     woLabTransBean.insert();
/* 156:161 */     woLabTransBean.getMobileMbo().setBooleanValue("GENAPPRSERVRECEIPT", autoApprove);
/* 157:162 */     for (int i = 0; i < crewMemberValues.length; i++) {
/* 158:163 */       woLabTransBean.setValue(crewMemberValues[i], crewMember.getValue(crewMemberValues[i]));
/* 159:    */     }
/* 160:165 */     for (int i = 0; i < crewReportBeanValues.length; i++) {
/* 161:166 */       woLabTransBean.setValue(crewReportBeanValues[i], crewReportBean.getValue(crewReportBeanValues[i]));
/* 162:    */     }
/* 163:168 */     woLabTransBean.setValue("WOCLASS", crewReportBean.getValue("RECORDCLASS"));
/* 164:169 */     woLabTransBean.setValue("REFWO", crewReportBean.getValue("RECORD"));
/* 165:    */     
/* 166:171 */     woLabTransBean.getMobileMbo().setBooleanValue("ISLASTINSERTED", isLastInserted);
/* 167:172 */     setDateTimeFields(woLabTransBean, crewReportBean);
/* 168:173 */     woLabTransBean.markComplete();
/* 169:174 */     MobileMboDataBean labTrans = DataBeanCache.getDataBean("LABTRANS", "LABTRANS");
/* 170:175 */     copyTkWOLabTransValues(labTrans, woLabTransBean, 5);
/* 171:176 */     labTrans.getDataBeanManager().save();
/* 172:    */   }
/* 173:    */   
/* 174:    */   private void setDateTimeFields(MobileMboDataBean labTransBean, MobileMboDataBean crewReportBean)
/* 175:    */     throws MobileApplicationException
/* 176:    */   {
/* 177:180 */     String date = "";
/* 178:181 */     String time = "";
/* 179:182 */     String dateTime = crewReportBean.getValue("STARTDATETIME");
/* 180:183 */     if (!dateTime.equals(""))
/* 181:    */     {
/* 182:184 */       date = dateTime.substring(0, dateTime.indexOf(" "));
/* 183:185 */       time = dateTime.substring(dateTime.indexOf(" ") + 1);
/* 184:    */     }
/* 185:187 */     labTransBean.setValue("STARTDATE", date);
/* 186:188 */     labTransBean.setValue("STARTTIME", time);
/* 187:189 */     dateTime = crewReportBean.getValue("FINISHDATETIME");
/* 188:190 */     if (!dateTime.equals(""))
/* 189:    */     {
/* 190:191 */       date = dateTime.substring(0, dateTime.indexOf(" "));
/* 191:192 */       time = dateTime.substring(dateTime.indexOf(" ") + 1);
/* 192:    */     }
/* 193:194 */     labTransBean.setValue("FINISHDATE", date);
/* 194:195 */     labTransBean.setValue("FINISHTIME", time);
/* 195:    */   }
/* 196:    */   
/* 197:    */   private void createTKLabTrans(MobileMbo crewMember, MobileMboDataBean tkLabTransBean, MobileMboDataBean crewReportBean, boolean isLastInserted)
/* 198:    */     throws MobileApplicationException
/* 199:    */   {
/* 200:201 */     String[] crewMemberValues = { "LABORCODE", "CRAFT", "SKILLLEVEL", "CONTRACTNUM", "VENDOR" };
/* 201:202 */     String[] crewReportBeanValues = { "SITEID", "ORGID", "REGULARHRS", "PREMIUMPAYCODE", "PREMIUMPAYHOURS", "TRANSTYPE" };
/* 202:203 */     boolean autoApprove = isAutoApproveConf(crewMember, tkLabTransBean);
/* 203:    */     
/* 204:205 */     tkLabTransBean.insert();
/* 205:206 */     tkLabTransBean.getMobileMbo().setBooleanValue("GENAPPRSERVRECEIPT", autoApprove);
/* 206:207 */     for (int i = 0; i < crewMemberValues.length; i++) {
/* 207:208 */       tkLabTransBean.setValue(crewMemberValues[i], crewMember.getValue(crewMemberValues[i]));
/* 208:    */     }
/* 209:210 */     for (int i = 0; i < crewReportBeanValues.length; i++) {
/* 210:211 */       tkLabTransBean.setValue(crewReportBeanValues[i], crewReportBean.getValue(crewReportBeanValues[i]));
/* 211:    */     }
/* 212:213 */     tkLabTransBean.setValue("TICKETCLASS", crewReportBean.getValue("RECORDCLASS"));
/* 213:214 */     tkLabTransBean.setValue("TICKETID", crewReportBean.getValue("RECORD"));
/* 214:215 */     tkLabTransBean.setValue("ACTIVITY", crewReportBean.getValue("ACTUALSTASKID"));
/* 215:    */     
/* 216:217 */     tkLabTransBean.getMobileMbo().setBooleanValue("ISLASTINSERTED", isLastInserted);
/* 217:218 */     setDateTimeFields(tkLabTransBean, crewReportBean);
/* 218:219 */     tkLabTransBean.markComplete();
/* 219:220 */     MobileMboDataBean labTrans = DataBeanCache.getDataBean("LABTRANS", "LABTRANS");
/* 220:221 */     copyTkWOLabTransValues(labTrans, tkLabTransBean, 6);
/* 221:222 */     labTrans.getDataBeanManager().save();
/* 222:    */   }
/* 223:    */   
/* 224:    */   private boolean isCrewReportingForWO(MobileMboDataBean crewReportBean)
/* 225:    */     throws MobileApplicationException
/* 226:    */   {
/* 227:226 */     String recordClass = ((WOApp)UIUtil.getApplication()).getInternalValue(crewReportBean, "WOCLASS", crewReportBean.getValue("RECORDCLASS"));
/* 228:    */     
/* 229:    */ 
/* 230:    */ 
/* 231:    */ 
/* 232:231 */     return (recordClass != null) && (!"".equals(recordClass));
/* 233:    */   }
/* 234:    */   
/* 235:    */   private boolean isAutoApproveConf(MobileMbo crewMember, MobileMboDataBean woLabTransBean)
/* 236:    */     throws MobileApplicationException
/* 237:    */   {
/* 238:    */     String autoApprove;
/* 239:    */     String autoApprove;
/* 240:236 */     if (!crewMember.getValue("VENDOR").equals("")) {
/* 241:237 */       autoApprove = ((WOApp)UIUtil.getApplication()).getMaxVar(woLabTransBean, "LR_APPR_IN_LABOR");
/* 242:    */     } else {
/* 243:239 */       autoApprove = ((WOApp)UIUtil.getApplication()).getMaxVar(woLabTransBean, "LR_APPR_OUT_LABOR");
/* 244:    */     }
/* 245:241 */     return (autoApprove != null) && (autoApprove.equals("1"));
/* 246:    */   }
/* 247:    */   
/* 248:    */   private void doPageValidation(UIEvent event)
/* 249:    */     throws MobileApplicationException
/* 250:    */   {
/* 251:245 */     if (!validateRequiredFields(event))
/* 252:    */     {
/* 253:246 */       event.setEventErrored();
/* 254:247 */       return;
/* 255:    */     }
/* 256:249 */     MobileMboDataBean crewReportBean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/* 257:250 */     if (isCrewReportingForWO(crewReportBean)) {
/* 258:251 */       validateCharges(crewReportBean);
/* 259:    */     }
/* 260:253 */     validateHours(crewReportBean);
/* 261:    */   }
/* 262:    */   
/* 263:    */   private void validateCharges(MobileMboDataBean crewReportBean)
/* 264:    */     throws MobileApplicationException
/* 265:    */   {
/* 266:257 */     MobileMboDataBean woBean = new MobileMboDataBeanManager("WORKORDER").getDataBean();
/* 267:258 */     woBean.getQBE().setQBE("WONUM", crewReportBean.getValue("RECORD"));
/* 268:259 */     woBean.getQBE().setQBE("SITEID", crewReportBean.getValue("SITEID"));
/* 269:260 */     woBean.reset();
/* 270:261 */     if (woBean.getMobileMbo(0) != null) {
/* 271:262 */       if (crewReportBean.getValue("ACTUALSTASKID").equals(""))
/* 272:    */       {
/* 273:263 */         if (woBean.getValue("WOACCEPTSCHARGES").equals("0")) {
/* 274:264 */           throw new MobileApplicationException("WOAcceptsChargesNo");
/* 275:    */         }
/* 276:    */       }
/* 277:    */       else
/* 278:    */       {
/* 279:267 */         MobileMboDataBean wotasks = woBean.getDataBean("WOTASKS");
/* 280:268 */         for (int i = 0; i < wotasks.count(); i++) {
/* 281:269 */           if (wotasks.getMobileMbo(i).getValue("TASKID").equals(crewReportBean.getValue("ACTUALSTASKID")))
/* 282:    */           {
/* 283:270 */             if (!wotasks.getMobileMbo(i).getValue("WOACCEPTSCHARGES").equals("0")) {
/* 284:    */               break;
/* 285:    */             }
/* 286:271 */             throw new MobileApplicationException("TaskAcceptsChargesNo");
/* 287:    */           }
/* 288:    */         }
/* 289:    */       }
/* 290:    */     }
/* 291:    */   }
/* 292:    */   
/* 293:    */   private boolean validateRequiredFields(UIEvent event)
/* 294:    */   {
/* 295:281 */     return ((LinkControl)event.getCreatingObject()).getPage().checkRequiredFields();
/* 296:    */   }
/* 297:    */   
/* 298:    */   private void validateHours(MobileMboDataBean crewReportBean)
/* 299:    */     throws MobileApplicationException
/* 300:    */   {
/* 301:285 */     Date start = crewReportBean.getMobileMbo().getDateValue("STARTDATETIME");
/* 302:286 */     Date finish = crewReportBean.getMobileMbo().getDateValue("FINISHDATETIME");
/* 303:    */     
/* 304:    */ 
/* 305:    */ 
/* 306:290 */     double totalHours = DefaultMobileMboDataFormatter.durationToDouble(crewReportBean.getValue("REGULARHRS"));
/* 307:291 */     if ((totalHours > 0.0D) && 
/* 308:292 */       (start != null) && (finish != null))
/* 309:    */     {
/* 310:293 */       double calHours = WOApp.calculateHours(start, finish);
/* 311:294 */       if (totalHours > calHours) {
/* 312:295 */         throw new MobileApplicationException("toomanyhours");
/* 313:    */       }
/* 314:    */     }
/* 315:    */   }
/* 316:    */   
/* 317:    */   protected boolean validateCrewLabTransRecord(UIEvent event)
/* 318:    */     throws MobileApplicationException
/* 319:    */   {
/* 320:302 */     MobileMboDataBean crewReportingInfo = ((TextboxControl)event.getCreatingObject()).getDataBean();
/* 321:303 */     MobileMboDataBean worklistdatabean = DataBeanCache.getDataBean("WORKLIST", "WORKLIST");
/* 322:304 */     if ((event.getValue() != null) && (event.getValue().toString().length() > 0))
/* 323:    */     {
/* 324:306 */       boolean recordExistsInWorklist = checkRecordInWorklist((String)event.getValue(), worklistdatabean);
/* 325:307 */       if (!recordExistsInWorklist) {
/* 326:308 */         throw new MobileApplicationException("invalidrecord");
/* 327:    */       }
/* 328:    */     }
/* 329:312 */     String record = worklistdatabean.getValue("RECORDID");
/* 330:313 */     String recordclass = worklistdatabean.getValue("CLASS");
/* 331:314 */     crewReportingInfo.setValue("RECORD", record);
/* 332:315 */     crewReportingInfo.setValue("RECORDCLASS", recordclass);
/* 333:316 */     if (isWorkorder(((WOApp)UIUtil.getApplication()).getInternalValue(worklistdatabean, "WOCLASS", worklistdatabean.getValue("CLASS"))))
/* 334:    */     {
/* 335:317 */       crewReportingInfo.setValue("ORGID", worklistdatabean.getValue("ORGID"));
/* 336:318 */       crewReportingInfo.setValue("SITEID", worklistdatabean.getValue("SITEID"));
/* 337:    */       
/* 338:320 */       super.setWOTasksVisibility(true);
/* 339:321 */       Object o = event.getValue();
/* 340:322 */       if ((o != null) && ((o instanceof String))) {
/* 341:323 */         super.copyWOTasks(crewReportingInfo, (String)o);
/* 342:    */       } else {
/* 343:325 */         super.copyWOTasks(crewReportingInfo, null);
/* 344:    */       }
/* 345:    */     }
/* 346:329 */     UIUtil.refreshCurrentScreen();
/* 347:330 */     return false;
/* 348:    */   }
/* 349:    */   
/* 350:    */   protected boolean validateCrewLabTransRecordClass(UIEvent event)
/* 351:    */     throws MobileApplicationException
/* 352:    */   {
/* 353:335 */     MobileMboDataBean crewReportInfo = ((DropDownControl)event.getCreatingObject()).getDataBean();
/* 354:336 */     crewReportInfo.setValue("RECORDCLASS", event.getValue().toString());
/* 355:337 */     crewReportInfo.setValue("RECORD", "");
/* 356:    */     
/* 357:339 */     DropDownControl control = (DropDownControl)event.getCreatingObject();
/* 358:340 */     setWOTasksVisibility(false);
/* 359:341 */     String value = control.getSelectedItemText();
/* 360:342 */     if (isWorkorder(((WOApp)UIUtil.getApplication()).getInternalValue(crewReportInfo, "WOCLASS", value)))
/* 361:    */     {
/* 362:343 */       setWOTasksVisibility(true);
/* 363:344 */       deleteAllFromDataBean(getDataBean("LABTRANSWOTASKS", "ORGID", "!=~NULL~"));
/* 364:    */     }
/* 365:346 */     return true;
/* 366:    */   }
/* 367:    */   
/* 368:    */   protected boolean initCrewReportPage(UIEvent event)
/* 369:    */     throws MobileApplicationException
/* 370:    */   {
/* 371:350 */     MobileMboDataBean crewInfo = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/* 372:352 */     for (int i = 0; i < crewInfo.count(); i++) {
/* 373:353 */       crewInfo.deleteLocal(i);
/* 374:    */     }
/* 375:355 */     crewInfo.insert();
/* 376:356 */     crewInfo.getDataBeanManager().save();
/* 377:357 */     super.createRecordClassList(new String[] { "WORKLIST" }, new String[] { "CLASS" });
/* 378:358 */     return true;
/* 379:    */   }
/* 380:    */   
/* 381:    */   protected boolean cleanUpPage(UIEvent event)
/* 382:    */     throws MobileApplicationException
/* 383:    */   {
/* 384:362 */     MobileMboDataBean crewInfo = UIUtil.getCurrentScreen().getDataBean();
/* 385:363 */     if (crewInfo != null)
/* 386:    */     {
/* 387:365 */       for (int i = 0; i < crewInfo.count(); i++) {
/* 388:366 */         crewInfo.deleteLocal(i);
/* 389:    */       }
/* 390:368 */       crewInfo.getDataBeanManager().save();
/* 391:    */     }
/* 392:370 */     return true;
/* 393:    */   }
/* 394:    */   
/* 395:    */   protected boolean currentCrewExists(UIEvent event)
/* 396:    */     throws MobileApplicationException
/* 397:    */   {
/* 398:374 */     super.canenterlabtrans(event);
/* 399:375 */     LinkControl crewLink = (LinkControl)event.getCreatingObject();
/* 400:376 */     if (crewLink.isVisible())
/* 401:    */     {
/* 402:378 */       MobileMboDataBean wodatabean = UIUtil.getCurrentScreen().getDataBean();
/* 403:379 */       String currentStatus = ((WOApp)UIUtil.getApplication()).getInternalValue(wodatabean, "WOSTATUS", wodatabean.getValue("STATUS"));
/* 404:380 */       MobileMboDataBean currentCrew = DataBeanCache.getDataBean("CURRENTCREW", "CURRENTCREW");
/* 405:381 */       crewLink.setVisibility((currentCrew != null) && (currentCrew.count() > 0) && (!"WAPPR".equals(currentStatus)));
/* 406:    */     }
/* 407:383 */     return true;
/* 408:    */   }
/* 409:    */   
/* 410:    */   protected boolean insertcrewlabactualwo(UIEvent event)
/* 411:    */     throws MobileApplicationException
/* 412:    */   {
/* 413:397 */     MobileMboDataBean woDataBean = DataBeanCache.findDataBean("WORKORDER");
/* 414:    */     
/* 415:399 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/* 416:400 */     if (databean != null)
/* 417:    */     {
/* 418:401 */       databean.setValue("RECORDCLASS", woDataBean.getValue("WOCLASS"));
/* 419:402 */       databean.setValue("RECORD", woDataBean.getValue("WONUM"));
/* 420:    */     }
/* 421:405 */     if (isWorkorder(((WOApp)UIUtil.getApplication()).getInternalValue(woDataBean, "WOCLASS", woDataBean.getValue("WOCLASS"))))
/* 422:    */     {
/* 423:406 */       databean.setValue("ORGID", woDataBean.getValue("ORGID"));
/* 424:407 */       databean.setValue("SITEID", woDataBean.getValue("SITEID"));
/* 425:    */       
/* 426:409 */       super.setWOTasksVisibility(true);
/* 427:410 */       super.copyWOTasks(databean, woDataBean.getValue("WONUM"));
/* 428:    */     }
/* 429:412 */     insertcrewlabactual(event);
/* 430:413 */     return true;
/* 431:    */   }
/* 432:    */   
/* 433:    */   protected boolean insertcrewlabactual(UIEvent event)
/* 434:    */     throws MobileApplicationException
/* 435:    */   {
/* 436:427 */     setHasChangedSinceLastTotalsDisplay(true);
/* 437:428 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/* 438:429 */     if (databean != null)
/* 439:    */     {
/* 440:434 */       Calendar currentCalendar = Calendar.getInstance();
/* 441:435 */       currentCalendar.setTime(CurrentTimeProvider.getInstance().getCurrentTime());
/* 442:436 */       currentCalendar.set(13, 0);
/* 443:437 */       currentCalendar.set(14, 0);
/* 444:438 */       long currentTime = currentCalendar.getTimeInMillis();
/* 445:    */       
/* 446:440 */       databean.setValue("STARTDATETIME", DefaultMobileMboDataFormatter.dateTimeToString(new Date(currentTime), Locale.getDefault(), TimeZone.getDefault()));
/* 447:441 */       databean.setValue("TRANSTYPE", ((WOApp)UIUtil.getApplication()).getDefaultValue(databean, "LTTYPE", "WORK"));
/* 448:    */     }
/* 449:443 */     UIUtil.refreshCurrentScreen();
/* 450:444 */     return true;
/* 451:    */   }
/* 452:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.mobilewo.CrewLaborReportingEventHandler
 * JD-Core Version:    0.7.0.1
 */