/*    1:     */ package com.mro.mobile.app.mobilewo;
/*    2:     */ 
/*    3:     */ import com.mro.mobile.MobileApplicationException;
/*    4:     */ import com.mro.mobile.MobileMessageGenerator;
/*    5:     */ import com.mro.mobile.app.BasicMobileDeviceUIApplication;
/*    6:     */ import com.mro.mobile.app.DefaultMobileMboDataFormatter;
/*    7:     */ import com.mro.mobile.mbo.MobileMbo;
/*    8:     */ import com.mro.mobile.mbo.MobileMboOrder;
/*    9:     */ import com.mro.mobile.mbo.MobileMboQBE;
/*   10:     */ import com.mro.mobile.persist.RDO;
/*   11:     */ import com.mro.mobile.ui.DataBeanCache;
/*   12:     */ import com.mro.mobile.ui.MobileMboDataBean;
/*   13:     */ import com.mro.mobile.ui.MobileMboDataBeanManager;
/*   14:     */ import com.mro.mobile.ui.event.UIEvent;
/*   15:     */ import com.mro.mobile.ui.res.UIUtil;
/*   16:     */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*   17:     */ import com.mro.mobile.ui.res.controls.LinkControl;
/*   18:     */ import com.mro.mobile.ui.res.controls.LookupControl;
/*   19:     */ import com.mro.mobile.ui.res.controls.PageControl;
/*   20:     */ import com.mro.mobile.ui.res.controls.TextboxControl;
/*   21:     */ import com.mro.mobileapp.WOApp;
/*   22:     */ import java.util.Calendar;
/*   23:     */ import java.util.Date;
/*   24:     */ import java.util.HashMap;
/*   25:     */ import java.util.Map;
/*   26:     */ 
/*   27:     */ public class BulkLaborReportingLabTransEventHandler
/*   28:     */   extends WOLabTransEventHandler
/*   29:     */ {
/*   30:  45 */   private boolean enteringAnotherLabTrans = false;
/*   31:  46 */   private boolean hasNew = false;
/*   32:     */   public static final int COPYING_WOLABTRANS = 1;
/*   33:     */   public static final int COPYING_TKLABTRANS = 2;
/*   34:     */   public static final int ENTERING_ANOTHER_LABTRANS = 3;
/*   35:     */   public static final int INSERTING_LABTRANS = 4;
/*   36:     */   public static final int COPYING_SINGLE_WOLABTRANS = 5;
/*   37:     */   public static final int COPYING_SINGLE_TKLABTRANS = 6;
/*   38:     */   
/*   39:     */   public boolean performEvent(UIEvent event)
/*   40:     */     throws MobileApplicationException
/*   41:     */   {
/*   42:  56 */     if (event == null) {
/*   43:  56 */       return false;
/*   44:     */     }
/*   45:  58 */     String eventId = event.getEventName();
/*   46:  60 */     if (eventId.equalsIgnoreCase("canenterlabtrans")) {
/*   47:  61 */       return canenterlabtrans(event);
/*   48:     */     }
/*   49:  64 */     if (eventId.equalsIgnoreCase("refreshlaborreporting")) {
/*   50:  65 */       return refreshLaborReporting(event);
/*   51:     */     }
/*   52:  67 */     if (eventId.equalsIgnoreCase("validatelabtranspage")) {
/*   53:  69 */       return validateLabTransPage(event);
/*   54:     */     }
/*   55:  71 */     if (eventId.equalsIgnoreCase("validatelabtransrecordclass")) {
/*   56:  72 */       return validateLabTransRecordClass(event);
/*   57:     */     }
/*   58:  74 */     if (eventId.equalsIgnoreCase("validatelabtransrecord")) {
/*   59:  75 */       return validateLabtransRecord(event);
/*   60:     */     }
/*   61:  77 */     if (eventId.equalsIgnoreCase("insertlabtrans")) {
/*   62:  79 */       return insertlabactual(event);
/*   63:     */     }
/*   64:  81 */     if (eventId.equalsIgnoreCase("enteranotherlabtrans")) {
/*   65:  83 */       return enterAnotherLabTrans(event);
/*   66:     */     }
/*   67:  85 */     if (eventId.equalsIgnoreCase("displaywotask")) {
/*   68:  86 */       return displayWOTask(event);
/*   69:     */     }
/*   70:  88 */     if (eventId.equalsIgnoreCase("initwotask")) {
/*   71:  89 */       return initWOTask(event);
/*   72:     */     }
/*   73:  91 */     if (eventId.equalsIgnoreCase("canenteranotherlabtrans")) {
/*   74:  93 */       return canenterAnotherLabTrans(event);
/*   75:     */     }
/*   76:  95 */     if (eventId.equalsIgnoreCase("displayworklist")) {
/*   77:  96 */       return displayWorkList(event);
/*   78:     */     }
/*   79:  98 */     if (eventId.equalsIgnoreCase("totalssumarycalc")) {
/*   80:  99 */       return totalsSumaryCalc(event);
/*   81:     */     }
/*   82: 101 */     if (eventId.equalsIgnoreCase("displaytotalsumary"))
/*   83:     */     {
/*   84: 102 */       if (isHasChangedSinceLastTotalsDisplay()) {
/*   85: 103 */         return totalsSumaryCalc(event);
/*   86:     */       }
/*   87: 105 */       return true;
/*   88:     */     }
/*   89: 108 */     if (eventId.equals("editlabtrans")) {
/*   90: 109 */       return editLabTrans(event);
/*   91:     */     }
/*   92: 111 */     if (eventId.equalsIgnoreCase("deleteactual")) {
/*   93: 112 */       return deleteActual(event);
/*   94:     */     }
/*   95: 113 */     if (eventId.equalsIgnoreCase("candeleteactual")) {
/*   96: 114 */       return canDeleteActual(event);
/*   97:     */     }
/*   98: 115 */     if (eventId.equalsIgnoreCase("cancelpage")) {
/*   99: 116 */       return cancelPage(event);
/*  100:     */     }
/*  101: 117 */     if (eventId.equalsIgnoreCase("saveclose")) {
/*  102: 118 */       return saveClose(event);
/*  103:     */     }
/*  104: 120 */     if (eventId.equalsIgnoreCase("save")) {
/*  105: 121 */       return save(event);
/*  106:     */     }
/*  107: 124 */     if (eventId.equalsIgnoreCase("initlaborreportingpage")) {
/*  108: 126 */       return initLaborReportingPage(event);
/*  109:     */     }
/*  110: 128 */     return super.performEvent(event);
/*  111:     */   }
/*  112:     */   
/*  113:     */   public boolean initLaborReportingPage(UIEvent event)
/*  114:     */     throws MobileApplicationException
/*  115:     */   {
/*  116: 135 */     setHasChangedSinceLastTotalsDisplay(true);
/*  117: 136 */     MobileMboDataBean labTransBean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*  118: 137 */     setHasNewValue(labTransBean);
/*  119: 138 */     return true;
/*  120:     */   }
/*  121:     */   
/*  122:     */   public boolean save(UIEvent event)
/*  123:     */     throws MobileApplicationException
/*  124:     */   {
/*  125: 145 */     MobileMboDataBean dataBean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*  126: 146 */     PageControl p = (PageControl)UIUtil.getCurrentScreen();
/*  127: 148 */     if (dataBean != null) {
/*  128: 150 */       if (p.getId().equals("labtrans_details"))
/*  129:     */       {
/*  130: 152 */         String sigoption = p.getStringValue("esignature");
/*  131: 153 */         if (dataBean.getMobileMbo().isToBeInserted())
/*  132:     */         {
/*  133: 155 */           String insertSigOption = p.getStringValue("insertesigoption");
/*  134: 156 */           if (insertSigOption != null) {
/*  135: 158 */             sigoption = sigoption + "," + insertSigOption;
/*  136:     */           }
/*  137:     */         }
/*  138: 162 */         if (UIUtil.checkESignatureWithSave(UIUtil.getApplication().getUserEvent(), dataBean, sigoption))
/*  139:     */         {
/*  140: 165 */           validateLabTransPage(event);
/*  141: 166 */           return true;
/*  142:     */         }
/*  143: 170 */         event.setEventErrored();
/*  144: 171 */         return true;
/*  145:     */       }
/*  146:     */     }
/*  147: 175 */     return false;
/*  148:     */   }
/*  149:     */   
/*  150:     */   protected boolean canenterlabtrans(UIEvent event)
/*  151:     */     throws MobileApplicationException
/*  152:     */   {
/*  153: 181 */     MobileMboDataBean dataBean = DataBeanCache.getDataBean("WORKLIST", "WORKLIST");
/*  154: 182 */     int count = dataBean.count();
/*  155: 183 */     int validCount = 0;
/*  156: 184 */     String wappr = ((WOApp)UIUtil.getApplication()).getExternalValue(dataBean, "WOSTATUS", "WAPPR");
/*  157: 187 */     for (int i = 0; i < count; i++) {
/*  158: 190 */       if ((!dataBean.getValue(i, "STATUS").equals(wappr)) && (dataBean.getValue(i, "SITEID") != null) && (dataBean.getValue(i, "SITEID").length() > 0)) {
/*  159: 193 */         validCount++;
/*  160:     */       }
/*  161:     */     }
/*  162: 198 */     if (validCount > 0) {
/*  163: 200 */       ((AbstractMobileControl)event.getCreatingObject()).setVisibility(true);
/*  164:     */     } else {
/*  165: 204 */       ((AbstractMobileControl)event.getCreatingObject()).setVisibility(false);
/*  166:     */     }
/*  167: 207 */     return true;
/*  168:     */   }
/*  169:     */   
/*  170:     */   private boolean refreshLaborReporting(UIEvent event)
/*  171:     */     throws MobileApplicationException
/*  172:     */   {
/*  173: 214 */     MobileMboDataBean databean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*  174:     */     
/*  175: 216 */     setHasNewValue(databean);
/*  176:     */     
/*  177: 218 */     return true;
/*  178:     */   }
/*  179:     */   
/*  180:     */   private void setHasNewValue(MobileMboDataBean labTransDataBean)
/*  181:     */     throws MobileApplicationException
/*  182:     */   {
/*  183: 225 */     this.hasNew = false;
/*  184: 226 */     int count = labTransDataBean.count();
/*  185: 228 */     for (int i = 0; i < count; i++) {
/*  186: 230 */       if ("1".equalsIgnoreCase(labTransDataBean.getValue(i, "ISNEW"))) {
/*  187: 232 */         this.hasNew = true;
/*  188:     */       }
/*  189:     */     }
/*  190:     */   }
/*  191:     */   
/*  192:     */   private boolean cancelPage(UIEvent event)
/*  193:     */     throws MobileApplicationException
/*  194:     */   {
/*  195: 238 */     if (this.enteringAnotherLabTrans)
/*  196:     */     {
/*  197: 240 */       this.enteringAnotherLabTrans = false;
/*  198: 241 */       MobileMboDataBean databean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*  199: 242 */       databean.deleteLocal();
/*  200: 243 */       databean.getDataBeanManager().save();
/*  201:     */     }
/*  202: 246 */     super.performEvent(event);
/*  203: 247 */     return false;
/*  204:     */   }
/*  205:     */   
/*  206:     */   private boolean saveClose(UIEvent event)
/*  207:     */     throws MobileApplicationException
/*  208:     */   {
/*  209: 251 */     this.enteringAnotherLabTrans = false;
/*  210:     */     
/*  211: 253 */     super.performEvent(event);
/*  212: 254 */     return false;
/*  213:     */   }
/*  214:     */   
/*  215:     */   private boolean canDeleteActual(UIEvent event)
/*  216:     */     throws MobileApplicationException
/*  217:     */   {
/*  218: 265 */     boolean canDelete = false;
/*  219: 266 */     if ("1".equalsIgnoreCase(((AbstractMobileControl)event.getCreatingObject()).getDataBean().getValue("ISNEW"))) {
/*  220: 267 */       canDelete = true;
/*  221:     */     }
/*  222: 269 */     ((AbstractMobileControl)event.getCreatingObject()).setVisibility(canDelete);
/*  223: 270 */     return true;
/*  224:     */   }
/*  225:     */   
/*  226:     */   private boolean deleteActual(UIEvent event)
/*  227:     */     throws MobileApplicationException
/*  228:     */   {
/*  229: 274 */     MobileMboDataBean labtransDataBean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*  230:     */     
/*  231: 276 */     String beanName = null;
/*  232: 277 */     if (isWorkorder(((WOApp)UIUtil.getApplication()).getInternalValue(labtransDataBean, "WOCLASS", labtransDataBean.getValue("RECORDCLASS")))) {
/*  233: 279 */       beanName = "WOLABTRANS";
/*  234: 281 */     } else if (isTicket(((WOApp)UIUtil.getApplication()).getInternalValue(labtransDataBean, "TKCLASS", labtransDataBean.getValue("RECORDCLASS")))) {
/*  235: 283 */       beanName = "TKLABTRANS";
/*  236:     */     }
/*  237: 285 */     MobileMboDataBean woLabtransDataBean = getDataBean(beanName, "_ID", labtransDataBean.getValue("ORIGINALRECORDID"));
/*  238: 286 */     woLabtransDataBean.delete();
/*  239: 287 */     woLabtransDataBean.getDataBeanManager().save();
/*  240:     */     
/*  241: 289 */     return true;
/*  242:     */   }
/*  243:     */   
/*  244:     */   private boolean initWOTask(UIEvent event)
/*  245:     */     throws MobileApplicationException
/*  246:     */   {
/*  247: 293 */     MobileMboDataBean labtrans = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*  248: 294 */     MobileMbo labtransMbo = labtrans.getMobileMbo();
/*  249: 295 */     if ((labtransMbo != null) && (labtransMbo.getValue("ACTUALSTASKID").length() > 0))
/*  250:     */     {
/*  251: 297 */       MobileMboDataBean labtransWoTasks = getDataBean("LABTRANSWOTASKS");
/*  252: 298 */       deleteAllFromDataBean(labtransWoTasks);
/*  253: 299 */       labtransWoTasks.insert();
/*  254: 300 */       MobileMbo labtransWOTaskMbo = labtransWoTasks.getMobileMbo(labtransWoTasks.getCurrentPosition());
/*  255: 301 */       labtransWOTaskMbo.setValue("SITEID", labtransMbo.getValue("SITEID"));
/*  256: 302 */       labtransWOTaskMbo.setValue("ORGID", labtransMbo.getValue("ORGID"));
/*  257: 303 */       labtransWOTaskMbo.setValue("DISPLAYWONUM", labtransMbo.getValue("RECORD"));
/*  258: 304 */       labtransWOTaskMbo.setValue("TASKID", labtransMbo.getValue("ACTUALSTASKID"));
/*  259: 305 */       labtransWOTaskMbo.setValue("WONUM", labtransMbo.getValue("RECORD"));
/*  260: 306 */       labtransWoTasks.getDataBeanManager().save();
/*  261:     */     }
/*  262: 308 */     return true;
/*  263:     */   }
/*  264:     */   
/*  265:     */   private boolean editLabTrans(UIEvent event)
/*  266:     */     throws MobileApplicationException
/*  267:     */   {
/*  268: 315 */     setHasChangedSinceLastTotalsDisplay(true);
/*  269:     */     
/*  270: 317 */     MobileMboDataBean dataBean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*  271: 318 */     String labTransBeanName = "";
/*  272: 319 */     String recordBeanName = "";
/*  273: 320 */     String labTransIdFieldName = "";
/*  274: 321 */     String recordIdFieldName = "";
/*  275: 322 */     String targetPage = "";
/*  276: 325 */     if ((dataBean.getValue("REFWO") != null) && (dataBean.getValue("REFWO").length() > 0))
/*  277:     */     {
/*  278: 327 */       labTransBeanName = "WOLABTRANS";
/*  279: 328 */       recordBeanName = "WORKORDER";
/*  280: 329 */       labTransIdFieldName = "REFWO";
/*  281: 330 */       recordIdFieldName = "WONUM";
/*  282: 331 */       targetPage = "wolabtrans_details";
/*  283:     */     }
/*  284:     */     else
/*  285:     */     {
/*  286: 336 */       labTransBeanName = "TKLABTRANS";
/*  287: 337 */       recordBeanName = "TICKET";
/*  288: 338 */       labTransIdFieldName = "TICKETID";
/*  289: 339 */       recordIdFieldName = "TICKETID";
/*  290: 340 */       targetPage = "tklabtrans_details";
/*  291:     */     }
/*  292: 344 */     MobileMboDataBean woTkLabTransBean = DataBeanCache.getDataBean(labTransBeanName, labTransBeanName);
/*  293: 345 */     String[] values = { dataBean.getValue("RECORD"), dataBean.getValue("SITEID"), dataBean.getValue("ORIGINALRECORDID") };
/*  294: 346 */     String[] fieldNames = { labTransIdFieldName, "SITEID", "_ID" };
/*  295: 347 */     setDataBeanCorrectPosition(woTkLabTransBean, values, fieldNames);
/*  296:     */     
/*  297:     */ 
/*  298:     */ 
/*  299: 351 */     MobileMboDataBean woTkBean = DataBeanCache.getDataBean(recordBeanName, recordBeanName);
/*  300: 352 */     values = new String[] { dataBean.getValue("RECORD"), dataBean.getValue("SITEID") };
/*  301: 353 */     fieldNames = new String[] { recordIdFieldName, "SITEID" };
/*  302: 354 */     setDataBeanCorrectPosition(woTkBean, values, fieldNames);
/*  303:     */     
/*  304: 356 */     woTkLabTransBean.setParentBean(woTkBean);
/*  305: 357 */     UIUtil.gotoPage(targetPage, (AbstractMobileControl)event.getCreatingObject());
/*  306:     */     
/*  307: 359 */     return true;
/*  308:     */   }
/*  309:     */   
/*  310:     */   private void setDataBeanCorrectPosition(MobileMboDataBean woLabTransbean, String[] values, String[] fieldNames)
/*  311:     */     throws MobileApplicationException
/*  312:     */   {
/*  313: 366 */     int count = woLabTransbean.count();
/*  314: 367 */     for (int i = 0; i < count; i++) {
/*  315: 369 */       if (isAtCorrectPosition(woLabTransbean, values, fieldNames, i))
/*  316:     */       {
/*  317: 371 */         woLabTransbean.setCurrentPosition(i);
/*  318: 372 */         break;
/*  319:     */       }
/*  320:     */     }
/*  321:     */   }
/*  322:     */   
/*  323:     */   private boolean isAtCorrectPosition(MobileMboDataBean dataBean, String[] values, String[] fieldNames, int index)
/*  324:     */     throws MobileApplicationException
/*  325:     */   {
/*  326: 381 */     boolean result = true;
/*  327: 382 */     for (int i = 0; i < values.length; i++) {
/*  328: 384 */       if (!dataBean.getValue(index, fieldNames[i]).equals(values[i]))
/*  329:     */       {
/*  330: 386 */         result = false;
/*  331: 387 */         break;
/*  332:     */       }
/*  333:     */     }
/*  334: 390 */     return result;
/*  335:     */   }
/*  336:     */   
/*  337:     */   private boolean totalsSumaryCalc(UIEvent event)
/*  338:     */     throws MobileApplicationException
/*  339:     */   {
/*  340: 401 */     setHasChangedSinceLastTotalsDisplay(false);
/*  341: 402 */     MobileMboDataBean totalhoursdatabean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*  342:     */     
/*  343:     */ 
/*  344: 405 */     String personId = getDataBean("PERSON").getValue("PERSONID");
/*  345: 406 */     String laborCode = "";
/*  346: 409 */     if (event.getValue() == null)
/*  347:     */     {
/*  348: 411 */       MobileMboDataBean labor = getDataBean("LABOR", "PERSONID", personId);
/*  349: 412 */       if (labor.count() > 0) {
/*  350: 413 */         laborCode = labor.getValue("LABORCODE");
/*  351:     */       }
/*  352:     */     }
/*  353:     */     else
/*  354:     */     {
/*  355: 418 */       laborCode = (String)event.getValue();
/*  356:     */     }
/*  357: 421 */     MobileMboDataBean labtransdatabean = getDataBean("LABTRANS", "LABORCODE", laborCode);
/*  358:     */     
/*  359: 423 */     int size = labtransdatabean.count();
/*  360:     */     
/*  361: 425 */     double regHours = 0.0D;
/*  362: 426 */     double regHoursThisWeek = 0.0D;
/*  363: 427 */     double regHoursShift = 0.0D;
/*  364: 428 */     double premHours = 0.0D;
/*  365: 429 */     double premHoursShift = 0.0D;
/*  366: 430 */     double premHoursThisWeek = 0.0D;
/*  367: 431 */     double totalHours = 0.0D;
/*  368: 432 */     double totalHoursShift = 0.0D;
/*  369: 433 */     double totalHoursThisWeek = 0.0D;
/*  370:     */     
/*  371:     */ 
/*  372: 436 */     MobileMboDataBean persondatabean = getDataBean("SHIFTPERSON", "PERSONID", personId);
/*  373:     */     
/*  374: 438 */     MobileMboDataBean shiftpatterndaydatabean = getDataBean("SHIFTPATTERNDAY", new String[] { "SHIFTNUM", "ORGID" }, new String[] { persondatabean.getValue("PRIMARYSHIFTNUM"), labtransdatabean.getValue("ORGID") });
/*  375:     */     
/*  376:     */ 
/*  377: 441 */     MobileMboDataBean shiftdatabean = getDataBean("SHIFT", new String[] { "SHIFTNUM", "ORGID" }, new String[] { persondatabean.getValue("PRIMARYSHIFTNUM"), labtransdatabean.getValue("ORGID") });
/*  378:     */     
/*  379:     */ 
/*  380: 444 */     int firstDayOfWeek = getShiftFirstDay(shiftdatabean);
/*  381: 446 */     for (int count = 0; count < size; count++)
/*  382:     */     {
/*  383: 447 */       labtransdatabean.setCurrentPosition(count);
/*  384:     */       
/*  385: 449 */       String hours = labtransdatabean.getValue("REGULARHRS");
/*  386: 450 */       double value = DefaultMobileMboDataFormatter.durationToDouble(hours);
/*  387: 452 */       if ((hours.length() > 0) && (value > 0.0D))
/*  388:     */       {
/*  389: 453 */         regHours += value;
/*  390: 454 */         totalHours += value;
/*  391: 455 */         double shiftHours = calcShiftHour(shiftpatterndaydatabean, labtransdatabean.getMobileMbo(), "REGULARHRS");
/*  392: 456 */         regHoursShift += shiftHours;
/*  393: 457 */         totalHoursShift += shiftHours;
/*  394: 458 */         if (isThisWeek(labtransdatabean.getMobileMbo().getDateValue("STARTDATE"), firstDayOfWeek))
/*  395:     */         {
/*  396: 459 */           regHoursThisWeek += value;
/*  397: 460 */           totalHoursThisWeek += value;
/*  398:     */         }
/*  399:     */       }
/*  400: 463 */       hours = labtransdatabean.getValue("PREMIUMPAYHOURS");
/*  401: 464 */       value = DefaultMobileMboDataFormatter.durationToDouble(hours);
/*  402: 465 */       if ((hours.length() > 0) && (value > 0.0D))
/*  403:     */       {
/*  404: 466 */         premHours += value;
/*  405: 467 */         totalHours += value;
/*  406: 468 */         double shiftHours = calcShiftHour(shiftpatterndaydatabean, labtransdatabean.getMobileMbo(), "PREMIUMPAYHOURS");
/*  407: 469 */         premHoursShift += shiftHours;
/*  408: 470 */         totalHoursShift += shiftHours;
/*  409: 471 */         if (isThisWeek(labtransdatabean.getMobileMbo().getDateValue("STARTDATE"), firstDayOfWeek))
/*  410:     */         {
/*  411: 472 */           premHoursThisWeek += value;
/*  412: 473 */           totalHoursThisWeek += value;
/*  413:     */         }
/*  414:     */       }
/*  415:     */     }
/*  416: 478 */     if (totalhoursdatabean.count() == 0) {
/*  417: 479 */       totalhoursdatabean.insert();
/*  418:     */     }
/*  419: 482 */     totalhoursdatabean.setValue("LABORCODE", laborCode);
/*  420: 483 */     totalhoursdatabean.setValue("TOTALHOURS", DefaultMobileMboDataFormatter.doubleToDuration(totalHours));
/*  421: 484 */     totalhoursdatabean.setValue("TOTALHOURSTHISWEEK", DefaultMobileMboDataFormatter.doubleToDuration(totalHoursThisWeek));
/*  422: 485 */     totalhoursdatabean.setValue("REGHOURS", DefaultMobileMboDataFormatter.doubleToDuration(regHours));
/*  423: 486 */     totalhoursdatabean.setValue("REGHOURSTHISWEEK", DefaultMobileMboDataFormatter.doubleToDuration(regHoursThisWeek));
/*  424: 487 */     totalhoursdatabean.setValue("PREMIUMHOURS", DefaultMobileMboDataFormatter.doubleToDuration(premHours));
/*  425: 488 */     totalhoursdatabean.setValue("PREMHOURSTHISWEEK", DefaultMobileMboDataFormatter.doubleToDuration(premHoursThisWeek));
/*  426: 489 */     totalhoursdatabean.setValue("TOTALHOURSSHIFT", DefaultMobileMboDataFormatter.doubleToDuration(totalHoursShift));
/*  427: 490 */     totalhoursdatabean.setValue("REGHOURSSHIFT", DefaultMobileMboDataFormatter.doubleToDuration(regHoursShift));
/*  428: 491 */     totalhoursdatabean.setValue("PREMHOURSSHIFT", DefaultMobileMboDataFormatter.doubleToDuration(premHoursShift));
/*  429:     */     
/*  430: 493 */     return true;
/*  431:     */   }
/*  432:     */   
/*  433:     */   private int getShiftFirstDay(MobileMboDataBean shiftdatabean)
/*  434:     */     throws MobileApplicationException
/*  435:     */   {
/*  436: 503 */     String startDay = shiftdatabean.getValue("STARTDAY");
/*  437:     */     
/*  438:     */ 
/*  439:     */ 
/*  440: 507 */     startDay = ((WOApp)UIUtil.getApplication()).getInternalValue(shiftdatabean, "DAYNAME", startDay);
/*  441: 511 */     if ("01".equals(startDay)) {
/*  442: 513 */       return 1;
/*  443:     */     }
/*  444: 515 */     if ("02".equals(startDay)) {
/*  445: 517 */       return 2;
/*  446:     */     }
/*  447: 519 */     if ("03".equals(startDay)) {
/*  448: 521 */       return 3;
/*  449:     */     }
/*  450: 523 */     if ("04".equals(startDay)) {
/*  451: 525 */       return 4;
/*  452:     */     }
/*  453: 527 */     if ("05".equals(startDay)) {
/*  454: 529 */       return 5;
/*  455:     */     }
/*  456: 531 */     if ("06".equals(startDay)) {
/*  457: 533 */       return 6;
/*  458:     */     }
/*  459: 535 */     if ("07".equals(startDay)) {
/*  460: 537 */       return 7;
/*  461:     */     }
/*  462: 539 */     return 0;
/*  463:     */   }
/*  464:     */   
/*  465:     */   private double calcShiftHour(MobileMboDataBean shiftpatterndaydatabean, MobileMbo labtransmbo, String shiftHoursAttribute)
/*  466:     */     throws MobileApplicationException
/*  467:     */   {
/*  468: 552 */     double retvalue = 0.0D;
/*  469:     */     
/*  470: 554 */     Date labtransStartDate = labtransmbo.getDateValue("STARTDATE");
/*  471: 555 */     Date labtransFinishDate = labtransmbo.getDateValue("FINISHDATE");
/*  472:     */     
/*  473: 557 */     int howManyDays = 0;
/*  474: 560 */     if ((labtransStartDate != null) && (labtransFinishDate != null) && (labtransStartDate.before(labtransFinishDate)))
/*  475:     */     {
/*  476: 562 */       Calendar startDateCal = Calendar.getInstance();
/*  477: 563 */       startDateCal.setTime(labtransStartDate);
/*  478: 564 */       Calendar finishDateCal = Calendar.getInstance();
/*  479: 565 */       finishDateCal.setTime(labtransFinishDate);
/*  480:     */       
/*  481:     */ 
/*  482: 568 */       howManyDays = (int)((finishDateCal.getTimeInMillis() - startDateCal.getTimeInMillis()) / 86400000L) + 1;
/*  483:     */     }
/*  484: 571 */     long[] labtransStartTime = new long[howManyDays];
/*  485: 572 */     long[] labtransFinishTime = new long[howManyDays];
/*  486: 573 */     String daysOfWeek = null;
/*  487: 574 */     for (int count = 0; count < howManyDays; count++)
/*  488:     */     {
/*  489: 576 */       if (count == 0)
/*  490:     */       {
/*  491: 577 */         if (!labtransmbo.getValue("STARTTIME").equals("")) {
/*  492: 578 */           labtransStartTime[count] = Long.parseLong(labtransmbo.getValue("STARTTIME"));
/*  493:     */         } else {
/*  494: 580 */           labtransStartTime[count] = 0L;
/*  495:     */         }
/*  496: 582 */         Calendar daysOfWeekCal = Calendar.getInstance();
/*  497: 583 */         daysOfWeekCal.setTimeInMillis(Long.parseLong(labtransmbo.getValue("STARTDATE")));
/*  498: 584 */         daysOfWeek = "0" + daysOfWeekCal.get(7);
/*  499:     */       }
/*  500: 588 */       else if (count > 0)
/*  501:     */       {
/*  502: 589 */         labtransStartTime[count] = 0L;
/*  503: 590 */         Calendar daysOfWeekCal = Calendar.getInstance();
/*  504:     */         
/*  505: 592 */         daysOfWeekCal.setTimeInMillis(Long.parseLong(labtransmbo.getValue("STARTDATE")) + count * 86400000L);
/*  506: 593 */         daysOfWeek = daysOfWeek + ",0" + daysOfWeekCal.get(7);
/*  507:     */       }
/*  508: 596 */       if (count < howManyDays - 1) {
/*  509: 597 */         labtransFinishTime[count] = setCalendarLastHourOfADay(labtransStartTime[count]);
/*  510: 600 */       } else if ((count == howManyDays - 1) && (labtransFinishDate != null) && (!labtransmbo.getValue("FINISHTIME").equals(""))) {
/*  511: 601 */         labtransFinishTime[count] = Long.parseLong(labtransmbo.getValue("FINISHTIME"));
/*  512:     */       } else {
/*  513: 603 */         labtransFinishTime[count] = 0L;
/*  514:     */       }
/*  515:     */     }
/*  516: 607 */     String shiftnum = shiftpatterndaydatabean.getValue("SHIFTNUM");
/*  517: 608 */     shiftpatterndaydatabean.reset();
/*  518: 609 */     shiftpatterndaydatabean.getQBE().setQbeExactMatch(true);
/*  519: 610 */     shiftpatterndaydatabean.getQBE().setQBE("SHIFTNUM", shiftnum);
/*  520: 611 */     shiftpatterndaydatabean.getQBE().setQBE("PATTERNDAYSEQ", daysOfWeek);
/*  521: 612 */     shiftpatterndaydatabean.getQBE().setQBE("ORGID", labtransmbo.getValue("ORGID"));
/*  522: 613 */     MobileMboOrder order = new MobileMboOrder();
/*  523: 614 */     order.setOrder("PATTERNDAYSEQ", true);
/*  524: 615 */     shiftpatterndaydatabean.setOrder(order);
/*  525: 616 */     shiftpatterndaydatabean.reset();
/*  526: 617 */     for (int count = 0; (count < howManyDays) && (count < shiftpatterndaydatabean.count()); count++)
/*  527:     */     {
/*  528: 618 */       MobileMbo mbo = shiftpatterndaydatabean.getMobileMbo(count);
/*  529: 619 */       String shiftStartTime = mbo.getValue("STARTTIME");
/*  530: 620 */       String shiftEndTime = mbo.getValue("ENDTIME");
/*  531: 621 */       long shiftStartTimeLong = 0L;
/*  532: 622 */       if (!shiftStartTime.equals("")) {
/*  533: 623 */         shiftStartTimeLong = Long.parseLong(shiftStartTime);
/*  534:     */       }
/*  535: 626 */       long shiftEndTimeLong = 0L;
/*  536: 627 */       if (!shiftEndTime.equals("")) {
/*  537: 628 */         shiftEndTimeLong = Long.parseLong(shiftEndTime);
/*  538:     */       }
/*  539: 630 */       Calendar cal = Calendar.getInstance();
/*  540: 631 */       cal.setTimeInMillis(labtransStartTime[count]);
/*  541: 632 */       cal.setTimeInMillis(shiftStartTimeLong);
/*  542: 634 */       if ((labtransStartTime[count] >= shiftStartTimeLong) && (labtransFinishTime[count] <= shiftEndTimeLong))
/*  543:     */       {
/*  544: 636 */         retvalue = (labtransFinishTime[count] - labtransStartTime[count]) / 3600000.0D;
/*  545:     */       }
/*  546: 639 */       else if ((labtransStartTime[count] >= shiftStartTimeLong) && (labtransStartTime[count] <= shiftEndTimeLong))
/*  547:     */       {
/*  548: 640 */         long partialReturnLong = shiftEndTimeLong - labtransStartTime[count];
/*  549:     */         
/*  550: 642 */         retvalue += retvalue += partialReturnLong / 3600000.0D;
/*  551:     */       }
/*  552: 645 */       else if (labtransStartTime[count] < shiftEndTimeLong)
/*  553:     */       {
/*  554: 649 */         if ((labtransFinishTime[count] < shiftStartTimeLong) && (labtransFinishTime[count] <= shiftEndTimeLong) && (labtransFinishTime[count] > shiftStartTimeLong))
/*  555:     */         {
/*  556: 650 */           long partialReturnLong = labtransFinishTime[count] - shiftStartTimeLong;
/*  557:     */           
/*  558: 652 */           retvalue += partialReturnLong / 3600000.0D;
/*  559:     */         }
/*  560: 655 */         else if ((labtransFinishTime[count] > shiftEndTimeLong) && (labtransStartTime[count] < shiftEndTimeLong))
/*  561:     */         {
/*  562: 656 */           long partialReturnLong = shiftEndTimeLong - shiftStartTimeLong;
/*  563:     */           
/*  564: 658 */           retvalue += partialReturnLong / 3600000.0D;
/*  565:     */         }
/*  566:     */       }
/*  567:     */     }
/*  568: 661 */     return retvalue;
/*  569:     */   }
/*  570:     */   
/*  571:     */   private long setCalendarLastHourOfADay(long dateInMili)
/*  572:     */   {
/*  573: 669 */     Calendar calendar = Calendar.getInstance();
/*  574: 670 */     calendar.setTimeInMillis(dateInMili);
/*  575: 671 */     calendar.set(11, 24);
/*  576: 672 */     return calendar.getTimeInMillis() - 1L;
/*  577:     */   }
/*  578:     */   
/*  579:     */   private boolean isThisWeek(Date date, int firstDayOfWeek)
/*  580:     */   {
/*  581: 681 */     Calendar today = Calendar.getInstance();
/*  582: 682 */     Calendar calendar = Calendar.getInstance();
/*  583: 683 */     calendar.setTime(date);
/*  584: 684 */     calendar.setFirstDayOfWeek(firstDayOfWeek);
/*  585: 685 */     today.setFirstDayOfWeek(firstDayOfWeek);
/*  586: 686 */     if (calendar.get(3) == today.get(3)) {
/*  587: 687 */       return true;
/*  588:     */     }
/*  589: 689 */     return false;
/*  590:     */   }
/*  591:     */   
/*  592:     */   private boolean enterAnotherLabTrans(UIEvent event)
/*  593:     */     throws MobileApplicationException
/*  594:     */   {
/*  595: 695 */     setHasChangedSinceLastTotalsDisplay(true);
/*  596: 696 */     if (event.getMsgResponse().equals("-1"))
/*  597:     */     {
/*  598: 698 */       String msg = MobileMessageGenerator.generate("enteranotherlabtrans", new Object[0]);
/*  599: 699 */       UIUtil.showOKCANCELMessageBox(event, msg);
/*  600:     */     }
/*  601: 701 */     else if (event.getMsgResponse().equals("1"))
/*  602:     */     {
/*  603: 703 */       this.enteringAnotherLabTrans = true;
/*  604: 704 */       MobileMboDataBean labtransdatabean = ((LinkControl)event.getCreatingObject()).getDataBean();
/*  605:     */       
/*  606: 706 */       MobileMboDataBean lastInsertedDatabean = getDataBean("LABTRANS", "ISLASTINSERTED", "1");
/*  607: 707 */       copyTkWOLabTransValues(labtransdatabean, lastInsertedDatabean, 3);
/*  608: 708 */       labtransdatabean.setReadOnly(false);
/*  609:     */       
/*  610: 710 */       UIUtil.gotoPage("labtrans_details", (AbstractMobileControl)event.getCreatingObject());
/*  611:     */       
/*  612:     */ 
/*  613:     */ 
/*  614: 714 */       String[] getFromName = { "WORKLIST" };
/*  615: 715 */       String[] getFromColumnName = { "CLASS" };
/*  616: 716 */       createRecordClassList(getFromName, getFromColumnName);
/*  617:     */     }
/*  618: 719 */     return true;
/*  619:     */   }
/*  620:     */   
/*  621:     */   protected boolean validateLabtransRecord(UIEvent event)
/*  622:     */     throws MobileApplicationException
/*  623:     */   {
/*  624: 731 */     MobileMboDataBean labtransdatabean = ((TextboxControl)event.getCreatingObject()).getDataBean();
/*  625: 732 */     MobileMboDataBean worklistdatabean = DataBeanCache.getDataBean("WORKLIST", "WORKLIST");
/*  626: 733 */     MobileMbo mbo = labtransdatabean.getMobileMbo();
/*  627: 735 */     if ((event.getValue() != null) && (event.getValue().toString().length() > 0))
/*  628:     */     {
/*  629: 738 */       boolean recordExistsInWorklist = checkRecordInWorklist((String)event.getValue(), worklistdatabean);
/*  630: 739 */       if (!recordExistsInWorklist) {
/*  631: 741 */         throw new MobileApplicationException("invalidrecord");
/*  632:     */       }
/*  633: 744 */       String record = worklistdatabean.getValue("RECORDID");
/*  634: 745 */       String recordclass = worklistdatabean.getValue("CLASS");
/*  635: 746 */       labtransdatabean.setValue("RECORD", record);
/*  636: 747 */       labtransdatabean.setValue("RECORDCLASS", recordclass);
/*  637: 749 */       if (isTicket(((WOApp)UIUtil.getApplication()).getInternalValue(worklistdatabean, "TKCLASS", worklistdatabean.getValue("CLASS"))))
/*  638:     */       {
/*  639: 751 */         mbo.setValue("REFWO", "");
/*  640: 752 */         mbo.setValue("WOCLASS", "");
/*  641: 753 */         mbo.setValue("TICKETID", record);
/*  642: 754 */         mbo.setValue("TICKETCLASS", recordclass);
/*  643: 755 */         mbo.setValue("ORGID", worklistdatabean.getValue("ORGID"));
/*  644: 756 */         mbo.setValue("SITEID", worklistdatabean.getValue("SITEID"));
/*  645:     */       }
/*  646: 758 */       else if (isWorkorder(((WOApp)UIUtil.getApplication()).getInternalValue(worklistdatabean, "WOCLASS", worklistdatabean.getValue("CLASS"))))
/*  647:     */       {
/*  648: 760 */         mbo.setValue("TICKETID", "");
/*  649: 761 */         mbo.setValue("TICKETCLASS", "");
/*  650: 762 */         mbo.setValue("REFWO", record);
/*  651: 763 */         mbo.setValue("ORGID", worklistdatabean.getValue("ORGID"));
/*  652: 764 */         mbo.setValue("SITEID", worklistdatabean.getValue("SITEID"));
/*  653: 765 */         mbo.setValue("WOCLASS", recordclass);
/*  654:     */         
/*  655:     */ 
/*  656: 768 */         super.setWOTasksVisibility(true);
/*  657: 769 */         Object o = event.getValue();
/*  658: 770 */         if ((o != null) && ((o instanceof String))) {
/*  659: 771 */           copyWOTasks(labtransdatabean, (String)o);
/*  660:     */         } else {
/*  661: 773 */           copyWOTasks(labtransdatabean, null);
/*  662:     */         }
/*  663:     */       }
/*  664:     */     }
/*  665: 777 */     UIUtil.refreshCurrentScreen();
/*  666:     */     
/*  667: 779 */     return true;
/*  668:     */   }
/*  669:     */   
/*  670:     */   protected boolean checkRecordInWorklist(String value, MobileMboDataBean worklistdatabean)
/*  671:     */     throws MobileApplicationException
/*  672:     */   {
/*  673: 785 */     int count = worklistdatabean.count();
/*  674: 786 */     for (int i = 0; i < count; i++) {
/*  675: 788 */       if (value.equalsIgnoreCase(worklistdatabean.getValue(i, "RECORDID")))
/*  676:     */       {
/*  677: 790 */         if (worklistdatabean.getCurrentPosition() == -1) {
/*  678: 792 */           worklistdatabean.setCurrentPosition(i);
/*  679:     */         }
/*  680: 794 */         return true;
/*  681:     */       }
/*  682:     */     }
/*  683: 798 */     return false;
/*  684:     */   }
/*  685:     */   
/*  686:     */   protected boolean displayWOTask(UIEvent event)
/*  687:     */     throws MobileApplicationException
/*  688:     */   {
/*  689: 808 */     ((AbstractMobileControl)event.getCreatingObject()).setVisibility(isWOTasksVisible());
/*  690: 809 */     return true;
/*  691:     */   }
/*  692:     */   
/*  693:     */   protected void copyWOTasks(MobileMboDataBean labtrans, String wonum)
/*  694:     */     throws MobileApplicationException
/*  695:     */   {
/*  696: 818 */     String[] columnNames = { "DISPLAYWONUM", "SITEID", "ORGID", "TASKID" };
/*  697: 819 */     String[] keyValues = new String[4];
/*  698: 820 */     keyValues[0] = (wonum != null ? wonum : labtrans.getValue("RECORD"));
/*  699: 821 */     keyValues[1] = labtrans.getValue("SITEID");
/*  700: 822 */     keyValues[2] = labtrans.getValue("ORGID");
/*  701: 823 */     keyValues[3] = "!=~NULL~";
/*  702: 824 */     MobileMboDataBean wotasks = getDataBean("WOTASKS", columnNames, keyValues);
/*  703: 825 */     MobileMboDataBean labtransTasks = getDataBean("LABTRANSWOTASKS");
/*  704: 826 */     deleteAllFromDataBean(labtransTasks);
/*  705: 827 */     int count = wotasks.count();
/*  706: 828 */     for (int i = 0; i < count; i++)
/*  707:     */     {
/*  708: 830 */       labtransTasks.insert();
/*  709: 831 */       labtransTasks.setValue("SITEID", wotasks.getValue(i, "SITEID"));
/*  710: 832 */       labtransTasks.setValue("ORGID", wotasks.getValue(i, "ORGID"));
/*  711: 833 */       labtransTasks.setValue("DISPLAYWONUM", wotasks.getValue(i, "DISPLAYWONUM"));
/*  712: 834 */       labtransTasks.setValue("TASKID", wotasks.getValue(i, "TASKID"));
/*  713: 835 */       labtransTasks.setValue("WONUM", wotasks.getValue(i, "WONUM"));
/*  714:     */     }
/*  715: 837 */     labtransTasks.getDataBeanManager().save();
/*  716:     */   }
/*  717:     */   
/*  718:     */   private boolean validateLabTransRecordClass(UIEvent event)
/*  719:     */     throws MobileApplicationException
/*  720:     */   {
/*  721: 851 */     String recordClass = event.getValue().toString();
/*  722: 852 */     MobileMboDataBean labtransdatabean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*  723: 853 */     labtransdatabean.setValue("RECORDCLASS", recordClass);
/*  724: 854 */     labtransdatabean.setValue("RECORD", "");
/*  725: 856 */     if (recordClass.length() > 0) {
/*  726: 860 */       if (isWorkorder(((WOApp)UIUtil.getApplication()).getInternalValue(labtransdatabean, "WOCLASS", recordClass)))
/*  727:     */       {
/*  728: 862 */         setWOTasksVisibility(true);
/*  729: 863 */         deleteAllFromDataBean(getDataBean("LABTRANSWOTASKS", "ORGID", "!=~NULL~"));
/*  730: 864 */         return true;
/*  731:     */       }
/*  732:     */     }
/*  733: 867 */     setWOTasksVisibility(false);
/*  734: 868 */     return true;
/*  735:     */   }
/*  736:     */   
/*  737:     */   private boolean validateLabTransPage(UIEvent event)
/*  738:     */     throws MobileApplicationException
/*  739:     */   {
/*  740: 873 */     MobileMboDataBean labtrans = ((PageControl)event.getCreatingObject()).getDataBean();
/*  741: 875 */     if (labtrans.getMobileMbo().isReadOnly())
/*  742:     */     {
/*  743: 877 */       labtrans.getMobileMbo().setReadOnly(false);
/*  744: 878 */       return true;
/*  745:     */     }
/*  746: 884 */     if (!((PageControl)event.getCreatingObject()).checkRequiredFields())
/*  747:     */     {
/*  748: 886 */       event.setEventErrored();
/*  749: 887 */       return true;
/*  750:     */     }
/*  751: 890 */     if (isWorkorder(((WOApp)UIUtil.getApplication()).getInternalValue(labtrans, "WOCLASS", labtrans.getValue("RECORDCLASS"))))
/*  752:     */     {
/*  753: 892 */       labtrans.setParentBean(getDataBean("WORKORDER"));
/*  754:     */       
/*  755: 894 */       validatepage(event);
/*  756: 895 */       copyTkWOLabTransValues(getDataBean("WOLABTRANS"), labtrans, 4);
/*  757:     */     }
/*  758: 897 */     else if (isTicket(((WOApp)UIUtil.getApplication()).getInternalValue(labtrans, "TKCLASS", labtrans.getValue("RECORDCLASS"))))
/*  759:     */     {
/*  760: 899 */       labtrans.setParentBean(getDataBean("TICKET"));
/*  761:     */       
/*  762: 901 */       validatepage(event);
/*  763: 902 */       copyTkWOLabTransValues(getDataBean("TKLABTRANS"), labtrans, 4);
/*  764:     */     }
/*  765: 905 */     return true;
/*  766:     */   }
/*  767:     */   
/*  768:     */   public void copyTkWOLabTransValues(MobileMboDataBean copyTo, MobileMboDataBean copyFrom, int actionToBeDone)
/*  769:     */     throws MobileApplicationException
/*  770:     */   {
/*  771: 916 */     int size = copyFrom.count();
/*  772: 917 */     Map womap = new HashMap();
/*  773: 918 */     Map tkmap = new HashMap();
/*  774: 919 */     MobileMbo copyFromMbo = null;
/*  775: 922 */     if ((actionToBeDone == 4) || (actionToBeDone == 3) || (actionToBeDone == 5) || (actionToBeDone == 6))
/*  776:     */     {
/*  777: 926 */       size = 1;
/*  778: 927 */       copyFromMbo = copyFrom.getMobileMbo();
/*  779:     */     }
/*  780: 930 */     for (int count = 0; size > count; count++)
/*  781:     */     {
/*  782: 933 */       if ((copyFromMbo == null) || (count > 0)) {
/*  783: 934 */         copyFromMbo = copyFrom.getMobileMbo(count);
/*  784:     */       }
/*  785: 937 */       MobileMbo copyToMbo = null;
/*  786: 939 */       if ((actionToBeDone == 1) || (actionToBeDone == 5))
/*  787:     */       {
/*  788: 940 */         String key = copyFromMbo.getValue("REFWO");
/*  789: 941 */         if (!womap.containsKey(key)) {
/*  790: 942 */           if ("1".equals(copyFromMbo.getValue("ISTASK"))) {
/*  791: 943 */             womap.put(key, new Boolean(getDoneParentMbo("WOTASKS", key, "WONUM")));
/*  792:     */           } else {
/*  793: 945 */             womap.put(key, new Boolean(getDoneParentMbo("WORKORDER", key, "WONUM")));
/*  794:     */           }
/*  795:     */         }
/*  796: 949 */         if (((Boolean)womap.get(key)).booleanValue()) {
/*  797:     */           continue;
/*  798:     */         }
/*  799: 953 */         copyTo.insert();
/*  800: 954 */         int position = copyTo.getCurrentPosition();
/*  801: 955 */         copyToMbo = copyTo.getMobileMbo(position);
/*  802: 956 */         copyToMbo.setValue("ORIGINALRECORDID", copyFromMbo.getValue("_ID"));
/*  803: 957 */         copyToMbo.setValue("RECORD", key, true);
/*  804: 958 */         copyToMbo.setValue("RECORDCLASS", copyFromMbo.getValue("WOCLASS"));
/*  805: 959 */         copyToMbo.setValue("WOCLASS", copyFromMbo.getValue("WOCLASS"));
/*  806: 960 */         copyToMbo.setValue("ACTUALSTASKID", copyFromMbo.getValue("ACTUALSTASKID"));
/*  807: 961 */         copyToMbo.setValue("REFWO", copyFromMbo.getValue("REFWO"));
/*  808:     */         
/*  809: 963 */         copyToMbo.setValue("NAME", getLaborDisplayName(copyFromMbo.getValue("LABORCODE"), copyFromMbo.getValue("ORGID")));
/*  810:     */         
/*  811: 965 */         String value = copyFromMbo.isNew() ? "1" : "0";
/*  812: 966 */         copyToMbo.setValue("ISNEW", value);
/*  813: 967 */         copyToMbo.setValue("ISLASTINSERTED", copyFromMbo.getValue("ISLASTINSERTED"));
/*  814: 968 */         copyToMbo.setValue("GENAPPRSERVRECEIPT", copyFromMbo.getValue("GENAPPRSERVRECEIPT"));
/*  815:     */       }
/*  816: 971 */       else if ((actionToBeDone == 2) || (actionToBeDone == 6))
/*  817:     */       {
/*  818: 972 */         String key = copyFromMbo.getValue("TICKETID");
/*  819: 974 */         if (!tkmap.containsKey(key)) {
/*  820: 975 */           tkmap.put(key, new Boolean(getDoneParentMbo("TICKET", key, "TICKETID")));
/*  821:     */         }
/*  822: 978 */         if (((Boolean)tkmap.get(key)).booleanValue()) {
/*  823:     */           continue;
/*  824:     */         }
/*  825: 983 */         copyTo.insert();
/*  826: 984 */         int position = copyTo.getCurrentPosition();
/*  827: 985 */         copyToMbo = copyTo.getMobileMbo(position);
/*  828: 986 */         copyToMbo.setValue("ORIGINALRECORDID", copyFromMbo.getValue("_ID"));
/*  829: 987 */         copyToMbo.setValue("RECORD", key);
/*  830: 988 */         copyToMbo.setValue("RECORDCLASS", copyFromMbo.getValue("TICKETCLASS"));
/*  831:     */         
/*  832: 990 */         copyToMbo.setValue("NAME", getLaborDisplayName(copyFromMbo.getValue("LABORCODE"), copyFromMbo.getValue("ORGID")));
/*  833:     */         
/*  834: 992 */         String value = copyFromMbo.isNew() ? "1" : "0";
/*  835: 993 */         copyToMbo.setValue("ISNEW", value);
/*  836: 994 */         copyToMbo.setValue("ISLASTINSERTED", copyFromMbo.getValue("ISLASTINSERTED"));
/*  837: 995 */         copyToMbo.setValue("GENAPPRSERVRECEIPT", copyFromMbo.getValue("GENAPPRSERVRECEIPT"));
/*  838:     */       }
/*  839: 998 */       else if (actionToBeDone == 4)
/*  840:     */       {
/*  841: 999 */         copyFromMbo.setValue("ISNEW", "1");
/*  842:1000 */         copyTo = setParentID(copyTo, copyFrom);
/*  843:1001 */         copyTo.insert();
/*  844:1002 */         int position = copyTo.getCurrentPosition();
/*  845:1006 */         if (actionToBeDone == 4)
/*  846:     */         {
/*  847:1007 */           updateLastInsertedTkWoLabTrans();
/*  848:1008 */           copyFromMbo.setValue("ISLASTINSERTED", "1");
/*  849:     */         }
/*  850:1010 */         copyToMbo = copyTo.getMobileMbo(position);
/*  851:1011 */         copyToMbo.setValue("ISLASTINSERTED", "1");
/*  852:1012 */         copyFromMbo.setValue("ORIGINALRECORDID", copyToMbo.getValue("_ID"));
/*  853:     */         
/*  854:     */ 
/*  855:1015 */         String autoapprove = "0";
/*  856:     */         
/*  857:1017 */         autoapprove = ((WOApp)UIUtil.getApplication()).getMaxVar(copyFrom, "LR_APPR_OUT_LABOR");
/*  858:     */         
/*  859:1019 */         copyToMbo.setValue("GENAPPRSERVRECEIPT", autoapprove);
/*  860:     */       }
/*  861:1022 */       else if (actionToBeDone == 3)
/*  862:     */       {
/*  863:1025 */         copyTo.insert();
/*  864:1026 */         int position = copyTo.getCurrentPosition();
/*  865:1027 */         copyToMbo = copyTo.getMobileMbo(position);
/*  866:1028 */         copyToMbo.setValue("RECORD", copyFromMbo.getValue("RECORD"), true);
/*  867:1029 */         copyToMbo.setValue("RECORDCLASS", copyFromMbo.getValue("RECORDCLASS"));
/*  868:1030 */         copyToMbo.setValue("GENAPPRSERVRECEIPT", copyFromMbo.getValue("GENAPPRSERVRECEIPT"));
/*  869:     */       }
/*  870:1035 */       if (copyToMbo == null) {
/*  871:1037 */         throw new MobileApplicationException("invalidactiontobedone", new Object[] { "" + actionToBeDone });
/*  872:     */       }
/*  873:1040 */       if (copyFromMbo.isNew()) {
/*  874:1041 */         this.hasNew = true;
/*  875:     */       }
/*  876:1045 */       if (!copyFromMbo.getValue("REFWO").equals(""))
/*  877:     */       {
/*  878:1046 */         copyToMbo.setValue("REFWO", copyFromMbo.getValue("REFWO"));
/*  879:1047 */         copyToMbo.setValue("ACTUALSTASKID", copyFromMbo.getValue("ACTUALSTASKID"));
/*  880:1048 */         copyToMbo.setValue("WOCLASS", copyFromMbo.getValue("WOCLASS"));
/*  881:     */       }
/*  882:1050 */       if (!copyFromMbo.getValue("TICKETID").equals(""))
/*  883:     */       {
/*  884:1051 */         copyToMbo.setValue("TICKETID", copyFromMbo.getValue("TICKETID"));
/*  885:1052 */         copyToMbo.setValue("TICKETCLASS", copyFromMbo.getValue("TICKETCLASS"));
/*  886:     */       }
/*  887:1054 */       copyToMbo.setValue("SITEID", copyFromMbo.getValue("SITEID"));
/*  888:1055 */       copyToMbo.setValue("LABORCODE", copyFromMbo.getValue("LABORCODE"));
/*  889:1056 */       copyToMbo.setValue("ORGID", copyFromMbo.getValue("ORGID"));
/*  890:1057 */       copyToMbo.setValue("CONTRACTNUM", copyFromMbo.getValue("CONTRACTNUM"));
/*  891:1058 */       copyToMbo.setValue("CRAFT", copyFromMbo.getValue("CRAFT"));
/*  892:1059 */       copyToMbo.setValue("SKILLLEVEL", copyFromMbo.getValue("SKILLLEVEL"));
/*  893:1060 */       copyToMbo.setValue("VENDOR", copyFromMbo.getValue("VENDOR"));
/*  894:1061 */       copyToMbo.setValue("REVISIONNUM", copyFromMbo.getValue("REVISIONNUM"));
/*  895:1062 */       copyToMbo.setDateValue("STARTDATE", copyFromMbo.getDateValue("STARTDATE"), false);
/*  896:1063 */       copyToMbo.setValue("STARTTIME", copyFromMbo.getValue("STARTTIME"));
/*  897:1064 */       copyToMbo.setDateValue("FINISHDATE", copyFromMbo.getDateValue("FINISHDATE"), false);
/*  898:1065 */       copyToMbo.setValue("FINISHTIME", copyFromMbo.getValue("FINISHTIME"));
/*  899:1066 */       copyToMbo.setValue("REGULARHRS", copyFromMbo.getValue("REGULARHRS"));
/*  900:1067 */       copyToMbo.setValue("PREMIUMPAYCODE", copyFromMbo.getValue("PREMIUMPAYCODE"));
/*  901:1068 */       copyToMbo.setValue("PREMIUMPAYHOURS", copyFromMbo.getValue("PREMIUMPAYHOURS"));
/*  902:1069 */       copyToMbo.setValue("TIMERSTATUS", copyFromMbo.getValue("TIMERSTATUS"));
/*  903:1070 */       copyToMbo.setValue("TRANSTYPE", copyFromMbo.getValue("TRANSTYPE"));
/*  904:1071 */       copyToMbo.setValue("STARTDATETIME", copyFromMbo.getValue("STARTDATETIME"));
/*  905:1072 */       copyToMbo.setValue("FINISHDATETIME", copyFromMbo.getValue("FINISHDATETIME"));
/*  906:1075 */       if (!copyToMbo.getName().equals("LABTRANS")) {
/*  907:1077 */         copyFromMbo.setValue("NAME", getLaborDisplayName(copyFromMbo.getValue("LABORCODE"), copyFromMbo.getValue("ORGID")));
/*  908:     */       }
/*  909:1080 */       copyToMbo.setValue("_NEW", copyFromMbo.getValue("_NEW"));
/*  910:1082 */       if ("0".equals(copyFromMbo.getValue("_MODIFIED")))
/*  911:     */       {
/*  912:1083 */         copyToMbo.getRDO().setBinaryValue("_ATTRMODIFIED", null);
/*  913:1084 */         copyToMbo.getRDO().setBooleanValue("_MODIFIED", false);
/*  914:     */       }
/*  915:     */     }
/*  916:1088 */     copyFrom.getDataBeanManager().save();
/*  917:1089 */     copyTo.getDataBeanManager().save();
/*  918:     */   }
/*  919:     */   
/*  920:     */   private boolean getDoneParentMbo(String name, String key, String attribute)
/*  921:     */     throws MobileApplicationException
/*  922:     */   {
/*  923:1102 */     MobileMboDataBean databean = getDataBean(name, attribute, key);
/*  924:1103 */     return databean.count() == 0;
/*  925:     */   }
/*  926:     */   
/*  927:     */   private MobileMboDataBean setParentID(MobileMboDataBean copyTo, MobileMboDataBean copyFrom)
/*  928:     */     throws MobileApplicationException
/*  929:     */   {
/*  930:1114 */     MobileMbo copyFromMbo = copyFrom.getMobileMbo();
/*  931:1115 */     String id = null;
/*  932:1116 */     String name = null;
/*  933:1117 */     String clas = null;
/*  934:1118 */     String child = null;
/*  935:1119 */     if (isWorkorder(((WOApp)UIUtil.getApplication()).getInternalValue(copyFrom, "WOCLASS", copyFromMbo.getValue("RECORDCLASS"))))
/*  936:     */     {
/*  937:1120 */       id = "WONUM";
/*  938:1121 */       name = "WORKORDER";
/*  939:1122 */       clas = "WOCLASS";
/*  940:1123 */       child = "WOLABTRANS";
/*  941:     */     }
/*  942:1124 */     else if (isTicket(((WOApp)UIUtil.getApplication()).getInternalValue(copyFrom, "TKCLASS", copyFromMbo.getValue("RECORDCLASS"))))
/*  943:     */     {
/*  944:1125 */       id = "TICKETID";
/*  945:1126 */       name = "TICKET";
/*  946:1127 */       clas = "CLASS";
/*  947:1128 */       child = "TKLABTRANS";
/*  948:     */     }
/*  949:1130 */     MobileMboDataBeanManager mgr = new MobileMboDataBeanManager(name);
/*  950:1131 */     MobileMboDataBean databean = mgr.getDataBean();
/*  951:1132 */     MobileMboQBE QBE = databean.getQBE();
/*  952:     */     
/*  953:1134 */     QBE.setQBE(id, copyFromMbo.getValue("RECORD"));
/*  954:1135 */     QBE.setQBE(clas, copyFromMbo.getValue("RECORDCLASS"));
/*  955:1136 */     databean.reset();
/*  956:     */     
/*  957:1138 */     copyTo.setParentBean(databean);
/*  958:1139 */     databean.getDataBeanManager().save();
/*  959:1140 */     return databean.getDataBean(child);
/*  960:     */   }
/*  961:     */   
/*  962:     */   private boolean displayWorkList(UIEvent event)
/*  963:     */     throws MobileApplicationException
/*  964:     */   {
/*  965:1150 */     MobileMboDataBean databean = ((LookupControl)event.getCreatingObject()).getDataBean();
/*  966:1151 */     MobileMboDataBean parentdatabean = DataBeanCache.findDataBean("LABTRANS");
/*  967:1152 */     String recordclass = parentdatabean.getValue("RECORDCLASS");
/*  968:     */     
/*  969:1154 */     databean.getQBE().setQbeExactMatch(true);
/*  970:1155 */     databean.getQBE().setQBE("HISTORYFLAG", "0");
/*  971:     */     
/*  972:     */ 
/*  973:1158 */     String extWappr = ((WOApp)UIUtil.getApplication()).getExternalValue(databean, "WOSTATUS", "WAPPR");
/*  974:1159 */     databean.getQBE().setQBE("STATUS", "!=" + extWappr);
/*  975:1160 */     databean.getQBE().setQBE("CLASS", recordclass);
/*  976:     */     
/*  977:1162 */     databean.setInternalQBE("SITEID", "!=~NULL~");
/*  978:1163 */     databean.reset();
/*  979:1164 */     return true;
/*  980:     */   }
/*  981:     */   
/*  982:     */   private boolean canenterAnotherLabTrans(UIEvent event)
/*  983:     */     throws MobileApplicationException
/*  984:     */   {
/*  985:1172 */     ((LinkControl)event.getCreatingObject()).setVisibility(this.hasNew);
/*  986:1173 */     return true;
/*  987:     */   }
/*  988:     */   
/*  989:     */   private String getLaborDisplayName(String laborCode, String orgId)
/*  990:     */     throws MobileApplicationException
/*  991:     */   {
/*  992:1181 */     MobileMboDataBeanManager dmgr = new MobileMboDataBeanManager("LABORCRAFTRATE");
/*  993:1182 */     MobileMboDataBean dataBean = dmgr.getDataBean();
/*  994:1183 */     dataBean.getQBE().setQBE("LABORCODE", laborCode);
/*  995:1184 */     dataBean.getQBE().setQBE("ORGID", orgId);
/*  996:1185 */     dataBean.reset();
/*  997:1187 */     if (dataBean.count() > 0) {
/*  998:1189 */       return dataBean.getValue("LABOR_DISPLAYNAME");
/*  999:     */     }
/* 1000:1192 */     return "";
/* 1001:     */   }
/* 1002:     */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.mobilewo.BulkLaborReportingLabTransEventHandler
 * JD-Core Version:    0.7.0.1
 */