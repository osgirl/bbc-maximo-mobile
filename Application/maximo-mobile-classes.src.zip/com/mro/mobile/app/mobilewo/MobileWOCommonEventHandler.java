/*   1:    */ package com.mro.mobile.app.mobilewo;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.MobileMessageGenerator;
/*   5:    */ import com.mro.mobile.app.BasicMobileDeviceUIApplication;
/*   6:    */ import com.mro.mobile.app.DefaultEventHandler;
/*   7:    */ import com.mro.mobile.mbo.MobileMbo;
/*   8:    */ import com.mro.mobile.ui.DataBeanCache;
/*   9:    */ import com.mro.mobile.ui.MobileMboDataBean;
/*  10:    */ import com.mro.mobile.ui.MobileMboDataBeanManager;
/*  11:    */ import com.mro.mobile.ui.event.UIEvent;
/*  12:    */ import com.mro.mobile.ui.res.UIUtil;
/*  13:    */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*  14:    */ import com.mro.mobile.ui.res.controls.LookupControl;
/*  15:    */ import com.mro.mobile.ui.res.controls.PageControl;
/*  16:    */ import com.mro.mobile.ui.res.controls.TabControl;
/*  17:    */ import com.mro.mobile.ui.res.controls.TabGroupControl;
/*  18:    */ 
/*  19:    */ public class MobileWOCommonEventHandler
/*  20:    */   extends DefaultEventHandler
/*  21:    */ {
/*  22:    */   public boolean performEvent(UIEvent event)
/*  23:    */     throws MobileApplicationException
/*  24:    */   {
/*  25: 34 */     if (event == null) {
/*  26: 34 */       return false;
/*  27:    */     }
/*  28: 36 */     String eventId = event.getEventName();
/*  29: 38 */     if (eventId.equalsIgnoreCase("luconnect")) {
/*  30: 40 */       return luconnect(event);
/*  31:    */     }
/*  32: 43 */     return false;
/*  33:    */   }
/*  34:    */   
/*  35:    */   protected void saveLinearDetails()
/*  36:    */     throws MobileApplicationException
/*  37:    */   {
/*  38: 50 */     MobileMboDataBean dataBean = UIUtil.getCurrentScreen().getDataBean();
/*  39: 51 */     String multiBeanName = "WOMULTIASSETLOCCI";
/*  40: 52 */     String dataSrcName = "WOMULTI";
/*  41: 53 */     if (dataBean.getName().equalsIgnoreCase("TICKET"))
/*  42:    */     {
/*  43: 55 */       multiBeanName = "TKMULTIASSETLOCCI";
/*  44: 56 */       dataSrcName = "TKMULTI";
/*  45:    */     }
/*  46: 59 */     MobileMboDataBean multiBean = DataBeanCache.getDataBean(dataSrcName, multiBeanName);
/*  47: 60 */     if ((multiBean != null) && (multiBean.count() > 0)) {
/*  48: 62 */       multiBean.getDataBeanManager().save();
/*  49:    */     }
/*  50:    */   }
/*  51:    */   
/*  52:    */   public boolean luconnect(UIEvent event)
/*  53:    */     throws MobileApplicationException
/*  54:    */   {
/*  55: 68 */     if ((UIUtil.getCurrentScreen() instanceof LookupControl)) {
/*  56: 69 */       return false;
/*  57:    */     }
/*  58: 71 */     MobileMboDataBean dataBean = UIUtil.getCurrentScreen().getDataBean();
/*  59:    */     
/*  60: 73 */     TabGroupControl tgc = UIUtil.getTabGroup(UIUtil.getCurrentScreen());
/*  61: 74 */     if (tgc != null) {
/*  62: 77 */       dataBean = tgc.getCurrentTab().getDataBean();
/*  63:    */     }
/*  64: 80 */     if (dataBean != null) {
/*  65: 82 */       event.setSource(dataBean);
/*  66:    */     }
/*  67: 84 */     return false;
/*  68:    */   }
/*  69:    */   
/*  70:    */   public boolean done(UIEvent event)
/*  71:    */     throws MobileApplicationException
/*  72:    */   {
/*  73: 90 */     AbstractMobileControl page = ((AbstractMobileControl)event.getCreatingObject()).getPage();
/*  74: 91 */     if ((!page.checkRequiredFields()) || (!page.validateControl()))
/*  75:    */     {
/*  76: 92 */       event.setEventErrored();
/*  77: 93 */       return true;
/*  78:    */     }
/*  79: 96 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/*  80: 99 */     if (databean.getOwner() != null) {
/*  81:101 */       databean = databean.getParentBean();
/*  82:    */     }
/*  83:104 */     if (databean != null)
/*  84:    */     {
/*  85:107 */       String insertOptions = null;
/*  86:108 */       if (databean.getMobileMbo().isToBeInserted()) {
/*  87:110 */         insertOptions = page.getStringValue("insertesigoption");
/*  88:    */       }
/*  89:113 */       if (UIUtil.checkESignatureWithSave(UIUtil.getApplication().getUserEvent(), databean, insertOptions))
/*  90:    */       {
/*  91:114 */         new AsyncMobileWODoneDataBean(databean).handleInBackground(event);
/*  92:    */       }
/*  93:    */       else
/*  94:    */       {
/*  95:116 */         event.setEventErrored();
/*  96:117 */         return false;
/*  97:    */       }
/*  98:    */     }
/*  99:121 */     return true;
/* 100:    */   }
/* 101:    */   
/* 102:    */   public boolean nextrec(UIEvent event)
/* 103:    */     throws MobileApplicationException
/* 104:    */   {
/* 105:126 */     MobileMboDataBean dataBean = DataBeanCache.findDataBean("WORKLIST");
/* 106:127 */     if (dataBean != null) {
/* 107:129 */       if (((PageControl)UIUtil.getCurrentScreen()).sendSaveEvent())
/* 108:    */       {
/* 109:131 */         if (!dataBean.setCurrentPosition(dataBean.getCurrentPosition() + 1))
/* 110:    */         {
/* 111:133 */           UIUtil.showInfoMessageBox(MobileMessageGenerator.generate("lastrec", null));
/* 112:    */         }
/* 113:    */         else
/* 114:    */         {
/* 115:137 */           ((MobileWOAppEventHandler)UIUtil.getAppEventHandler()).gotoworklistview(event, dataBean);
/* 116:138 */           ((PageControl)UIUtil.getCurrentScreen()).clearBeanCache();
/* 117:    */         }
/* 118:140 */         UIUtil.refreshCurrentScreen();
/* 119:    */       }
/* 120:    */     }
/* 121:143 */     return true;
/* 122:    */   }
/* 123:    */   
/* 124:    */   public boolean prevrec(UIEvent event)
/* 125:    */     throws MobileApplicationException
/* 126:    */   {
/* 127:148 */     MobileMboDataBean dataBean = DataBeanCache.findDataBean("WORKLIST");
/* 128:149 */     if (dataBean != null) {
/* 129:151 */       if (((PageControl)UIUtil.getCurrentScreen()).sendSaveEvent())
/* 130:    */       {
/* 131:153 */         int row = dataBean.getCurrentPosition();
/* 132:154 */         if ((row == 0) || (!dataBean.setCurrentPosition(row - 1)))
/* 133:    */         {
/* 134:156 */           UIUtil.showInfoMessageBox(MobileMessageGenerator.generate("firstrec", null));
/* 135:    */         }
/* 136:    */         else
/* 137:    */         {
/* 138:160 */           ((MobileWOAppEventHandler)UIUtil.getAppEventHandler()).gotoworklistview(event, dataBean);
/* 139:161 */           ((PageControl)UIUtil.getCurrentScreen()).clearBeanCache();
/* 140:    */         }
/* 141:163 */         UIUtil.refreshCurrentScreen();
/* 142:    */       }
/* 143:    */     }
/* 144:166 */     return true;
/* 145:    */   }
/* 146:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.mobilewo.MobileWOCommonEventHandler
 * JD-Core Version:    0.7.0.1
 */