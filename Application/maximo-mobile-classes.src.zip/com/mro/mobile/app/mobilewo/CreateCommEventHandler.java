/*   1:    */ package com.mro.mobile.app.mobilewo;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.MobileMessageGenerator;
/*   5:    */ import com.mro.mobile.app.BasicMobileDeviceUIApplication;
/*   6:    */ import com.mro.mobile.mbo.MobileMbo;
/*   7:    */ import com.mro.mobile.mbo.MobileMboQBE;
/*   8:    */ import com.mro.mobile.ui.DataBeanCache;
/*   9:    */ import com.mro.mobile.ui.MobileMboDataBean;
/*  10:    */ import com.mro.mobile.ui.MobileMboDataBeanManager;
/*  11:    */ import com.mro.mobile.ui.MobileMboDataBeanQBE;
/*  12:    */ import com.mro.mobile.ui.event.UIEvent;
/*  13:    */ import com.mro.mobile.ui.res.UIUtil;
/*  14:    */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*  15:    */ import com.mro.mobile.ui.res.controls.PageControl;
/*  16:    */ import com.mro.mobile.ui.res.controls.TableControl;
/*  17:    */ import com.mro.mobileapp.WOApp;
/*  18:    */ import java.util.HashMap;
/*  19:    */ import java.util.Hashtable;
/*  20:    */ import java.util.Map;
/*  21:    */ import java.util.StringTokenizer;
/*  22:    */ 
/*  23:    */ public class CreateCommEventHandler
/*  24:    */   extends MobileWOCommonEventHandler
/*  25:    */ {
/*  26:    */   public boolean performEvent(UIEvent event)
/*  27:    */     throws MobileApplicationException
/*  28:    */   {
/*  29: 40 */     if (event == null) {
/*  30: 40 */       return false;
/*  31:    */     }
/*  32: 42 */     String eventId = event.getEventName();
/*  33: 44 */     if (eventId.equalsIgnoreCase("initpage")) {
/*  34: 46 */       return initpage(event);
/*  35:    */     }
/*  36: 48 */     if (eventId.equalsIgnoreCase("validatetemplateid")) {
/*  37: 50 */       return validatetemplateid(event);
/*  38:    */     }
/*  39: 52 */     if (eventId.equalsIgnoreCase("initcommtemplatelookup")) {
/*  40: 54 */       return initcommtemplatelookup(event);
/*  41:    */     }
/*  42: 56 */     if (eventId.equalsIgnoreCase("initrecipientsrole")) {
/*  43: 58 */       return initrecipientsrole(event);
/*  44:    */     }
/*  45: 60 */     if (eventId.equalsIgnoreCase("initrecipientspeople")) {
/*  46: 62 */       return initrecipientspeople(event);
/*  47:    */     }
/*  48: 64 */     if (eventId.equalsIgnoreCase("initrecipientsgroups")) {
/*  49: 66 */       return initrecipientsgroups(event);
/*  50:    */     }
/*  51: 68 */     if (eventId.equalsIgnoreCase("selectvalues")) {
/*  52: 70 */       return selectvalues(event);
/*  53:    */     }
/*  54: 72 */     if (eventId.equalsIgnoreCase("validateroles")) {
/*  55: 74 */       return validateroles(event);
/*  56:    */     }
/*  57: 76 */     if (eventId.equalsIgnoreCase("validatepeople")) {
/*  58: 78 */       return validatepeople(event);
/*  59:    */     }
/*  60: 80 */     if (eventId.equalsIgnoreCase("validategroups")) {
/*  61: 82 */       return validategroups(event);
/*  62:    */     }
/*  63: 84 */     if (eventId.equalsIgnoreCase("validateemails")) {
/*  64: 86 */       return validateemails(event);
/*  65:    */     }
/*  66: 88 */     if (eventId.equalsIgnoreCase("validatecommreceiptlist")) {
/*  67: 90 */       return validatecommreceiptlist(event);
/*  68:    */     }
/*  69: 92 */     if (eventId.equalsIgnoreCase("clearfiltervalues")) {
/*  70: 95 */       return clearfiltervalues(event);
/*  71:    */     }
/*  72: 97 */     if (eventId.equalsIgnoreCase("refreshrecipientsrole")) {
/*  73:100 */       return refreshrecipientsrole(event);
/*  74:    */     }
/*  75:103 */     if (eventId.equalsIgnoreCase("luconnect")) {
/*  76:106 */       if ((UIUtil.getCurrentScreen().getId().equals("recipientslookup")) && (((AbstractMobileControl)event.getCreatingObject()).getDataBean().getName().equals("MAXROLE"))) {
/*  77:109 */         ((AbstractMobileControl)event.getCreatingObject()).getDataBean().getQBE().reset();
/*  78:    */       }
/*  79:    */     }
/*  80:113 */     super.performEvent(event);
/*  81:    */     
/*  82:115 */     return false;
/*  83:    */   }
/*  84:    */   
/*  85:    */   private boolean refreshrecipientsrole(UIEvent event)
/*  86:    */     throws MobileApplicationException
/*  87:    */   {
/*  88:123 */     MobileMboDataBean commDataBean = UIUtil.getCurrentScreen().getDataBean();
/*  89:124 */     String ownertable = commDataBean.getValue("OWNERTABLE");
/*  90:    */     
/*  91:126 */     MobileMboDataBean rolesDataBean = ((TableControl)event.getCreatingObject()).getDataBean();
/*  92:    */     
/*  93:    */ 
/*  94:129 */     Map checkedRoles = new HashMap();
/*  95:    */     
/*  96:    */ 
/*  97:    */ 
/*  98:    */ 
/*  99:134 */     int pos = 0;
/* 100:135 */     StringBuffer roles = new StringBuffer();
/* 101:136 */     MobileMbo rolesMbo = rolesDataBean.getMobileMbo(0);
/* 102:137 */     while (rolesMbo != null)
/* 103:    */     {
/* 104:140 */       String objectname = rolesMbo.getValue("OBJECTNAME");
/* 105:141 */       if ((objectname == null) || (objectname.equals("")) || (objectname.equalsIgnoreCase(ownertable)))
/* 106:    */       {
/* 107:144 */         checkedRoles.put(rolesMbo.getValue("MAXROLE"), new boolean[] { rolesMbo.getBooleanValue("SENDTO"), rolesMbo.getBooleanValue("CC"), rolesMbo.getBooleanValue("BCC") });
/* 108:    */         
/* 109:    */ 
/* 110:    */ 
/* 111:148 */         roles.append(rolesMbo.getValue("TEMP_MAXROLE") + ",");
/* 112:    */       }
/* 113:150 */       rolesMbo = rolesDataBean.getMobileMbo(++pos);
/* 114:    */     }
/* 115:153 */     if (roles.length() > 0) {
/* 116:155 */       roles.deleteCharAt(roles.length() - 1);
/* 117:    */     } else {
/* 118:159 */       roles.append("~NULL~");
/* 119:    */     }
/* 120:162 */     roles.deleteCharAt(roles.length() - 1);
/* 121:163 */     rolesDataBean.getQBE().setQBE("TEMP_MAXROLE", roles.toString());
/* 122:164 */     rolesDataBean.reset();
/* 123:    */     
/* 124:    */ 
/* 125:    */ 
/* 126:    */ 
/* 127:169 */     boolean onlineStatus = rolesDataBean.isOnline();
/* 128:170 */     rolesDataBean.setOnline(false);
/* 129:    */     
/* 130:172 */     verifyRoles(rolesDataBean, ownertable, checkedRoles);
/* 131:173 */     rolesDataBean.setOnline(onlineStatus);
/* 132:    */     
/* 133:175 */     return true;
/* 134:    */   }
/* 135:    */   
/* 136:    */   protected boolean clearfiltervalues(UIEvent event)
/* 137:    */     throws MobileApplicationException
/* 138:    */   {
/* 139:181 */     AbstractMobileControl ctrl = (AbstractMobileControl)event.getCreatingObject();
/* 140:182 */     MobileMboDataBean dataBean = ctrl.getDataBean();
/* 141:183 */     if (dataBean != null)
/* 142:    */     {
/* 143:185 */       ((MobileMboDataBeanQBE)dataBean.getQBE()).restoreDefaultQBEValues(true);
/* 144:186 */       dataBean.reset();
/* 145:    */     }
/* 146:188 */     MobileMboDataBean commDataBean = DataBeanCache.getDataBean("COMMLOG", "COMMLOG");
/* 147:    */     
/* 148:190 */     String ownertable = commDataBean.getValue("OWNERTABLE");
/* 149:    */     
/* 150:192 */     MobileMboDataBean rolesDataBean = ((PageControl)UIUtil.getCurrentScreen()).getDataBean();
/* 151:193 */     rolesDataBean.reset();
/* 152:    */     
/* 153:195 */     int pos = 0;
/* 154:196 */     while (pos < rolesDataBean.count())
/* 155:    */     {
/* 156:197 */       String objectname = rolesDataBean.getMobileMbo(pos).getValue("OBJECTNAME");
/* 157:198 */       if ((objectname != null) && (!objectname.equals("")) && (!objectname.equalsIgnoreCase(ownertable)))
/* 158:    */       {
/* 159:199 */         rolesDataBean.remove(pos);
/* 160:200 */         pos--;
/* 161:    */       }
/* 162:202 */       pos++;
/* 163:    */     }
/* 164:205 */     UIUtil.refreshCurrentScreen();
/* 165:206 */     return true;
/* 166:    */   }
/* 167:    */   
/* 168:    */   public boolean initpage(UIEvent event)
/* 169:    */     throws MobileApplicationException
/* 170:    */   {
/* 171:216 */     Hashtable classOwnerTable = new Hashtable();
/* 172:    */     
/* 173:218 */     classOwnerTable.put("WORKORDER", "WORKORDER");
/* 174:219 */     classOwnerTable.put("ACTIVITY", "WOACTIVITY");
/* 175:220 */     classOwnerTable.put("CHANGE", "WOCHANGE");
/* 176:221 */     classOwnerTable.put("RELEASE", "WORELEASE");
/* 177:222 */     classOwnerTable.put("SR", "SR");
/* 178:223 */     classOwnerTable.put("INCIDENT", "INCIDENT");
/* 179:224 */     classOwnerTable.put("PROBLEM", "PROBLEM");
/* 180:    */     
/* 181:    */ 
/* 182:227 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/* 183:    */     
/* 184:229 */     MobileMboDataBean wodatabean = ((PageControl)UIUtil.getCurrentScreen()).getLaunchingControl().getDataBean();
/* 185:235 */     if ((!wodatabean.getName().equals("WORKORDER")) && (!wodatabean.getName().equals("TICKET")) && (!wodatabean.getName().equals("WORKLIST")))
/* 186:    */     {
/* 187:236 */       MobileMboDataBean parentBean = wodatabean.getParentBean();
/* 188:237 */       if ((parentBean != null) && ((parentBean.getName().equals("WORKORDER")) || (parentBean.getName().equals("TICKET")))) {
/* 189:238 */         wodatabean = parentBean;
/* 190:    */       }
/* 191:    */     }
/* 192:241 */     databean.insert();
/* 193:    */     
/* 194:243 */     databean.setValue("PENDING", "1");
/* 195:244 */     databean.setValue("CREATEBY", ((WOApp)UIUtil.getApplication()).getCurrentUser());
/* 196:245 */     databean.getMobileMbo().setDateValue("CREATEDATE", databean.getCurrentTime());
/* 197:    */     
/* 198:    */ 
/* 199:    */ 
/* 200:249 */     databean.getMobileMbo().setLongValue("OWNERID", wodatabean.getMobileMbo().getLongValue("_ID"));
/* 201:    */     
/* 202:251 */     databean.setValue("SITEID", wodatabean.getValue("SITEID"));
/* 203:252 */     databean.setValue("MOBILEOWNERTABLE", wodatabean.getName());
/* 204:253 */     databean.setValue("SENDFROM", ((WOApp)UIUtil.getApplication()).getCurrentUserEmail());
/* 205:    */     
/* 206:    */ 
/* 207:256 */     String className = null;
/* 208:258 */     if (wodatabean.getName().equals("WORKORDER")) {
/* 209:259 */       className = ((WOApp)UIUtil.getApplication()).getInternalValue(wodatabean, "WOCLASS", wodatabean.getValue("WOCLASS"));
/* 210:261 */     } else if (wodatabean.getName().equals("TICKET")) {
/* 211:262 */       className = ((WOApp)UIUtil.getApplication()).getInternalValue(wodatabean, "TKCLASS", wodatabean.getValue("CLASS"));
/* 212:    */     }
/* 213:266 */     String ownerTable = null;
/* 214:267 */     if (className != null) {
/* 215:269 */       ownerTable = (String)classOwnerTable.get(className);
/* 216:    */     }
/* 217:272 */     databean.setValue("OWNERTABLE", ownerTable != null ? ownerTable : className);
/* 218:    */     
/* 219:    */ 
/* 220:275 */     UIUtil.refreshCurrentScreen();
/* 221:    */     
/* 222:277 */     return true;
/* 223:    */   }
/* 224:    */   
/* 225:    */   public boolean validatetemplateid(UIEvent event)
/* 226:    */     throws MobileApplicationException
/* 227:    */   {
/* 228:282 */     if ((event.getValue() == null) || (event.getValue().equals(""))) {
/* 229:283 */       return true;
/* 230:    */     }
/* 231:286 */     MobileMboDataBean databean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/* 232:287 */     MobileMboDataBean worklistdatabean = DataBeanCache.findDataBean("WORKLIST");
/* 233:    */     
/* 234:289 */     MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager("COMMTEMPLATE");
/* 235:290 */     MobileMboDataBean commtmpltBean = mgrDBMgr.getDataBean();
/* 236:291 */     commtmpltBean.getQBE().setQBE("TEMPLATEID", (String)event.getValue());
/* 237:292 */     commtmpltBean.getQBE().setQBE("OBJECTNAME", worklistdatabean.getValue("CLASS"));
/* 238:293 */     if (commtmpltBean.getMobileMbo(0) == null) {
/* 239:295 */       throw new MobileApplicationException("invalidCommTemplate");
/* 240:    */     }
/* 241:300 */     databean.setValue("SENDTO", "");
/* 242:301 */     databean.setValue("CC", "");
/* 243:302 */     databean.setValue("BCC", "");
/* 244:303 */     databean.setValue("TOLISTROLE", "");
/* 245:304 */     databean.setValue("TOLISTPERSON", "");
/* 246:305 */     databean.setValue("TOLISTGROUP", "");
/* 247:306 */     databean.setValue("TOLISTEMAIL", "");
/* 248:307 */     databean.setValue("BCCLISTROLE", "");
/* 249:308 */     databean.setValue("BCCLISTPERSON", "");
/* 250:309 */     databean.setValue("BCCLISTGROUP", "");
/* 251:310 */     databean.setValue("BCCLISTEMAIL", "");
/* 252:311 */     databean.setValue("CCLISTROLE", "");
/* 253:312 */     databean.setValue("CCLISTPERSON", "");
/* 254:313 */     databean.setValue("CCLISTGROUP", "");
/* 255:314 */     databean.setValue("CCLISTEMAIL", "");
/* 256:    */     
/* 257:316 */     databean.setValue("SENDFROM", commtmpltBean.getMobileMbo(0).getValue("SENDFROM"));
/* 258:317 */     databean.setValue("REPLYTO", commtmpltBean.getMobileMbo(0).getValue("REPLYTO"));
/* 259:318 */     databean.setValue("SUBJECT", commtmpltBean.getMobileMbo(0).getValue("SUBJECT"));
/* 260:319 */     databean.setValue("MESSAGE", commtmpltBean.getMobileMbo(0).getValue("MESSAGE"));
/* 261:    */     
/* 262:321 */     String keyfield = "";
/* 263:322 */     String toListField = "";
/* 264:323 */     String ccListField = "";
/* 265:324 */     String bccListField = "";
/* 266:325 */     MobileMboDataBean bean = null;
/* 267:326 */     int count = 0;
/* 268:328 */     for (int loop = 0; loop < 4; loop++)
/* 269:    */     {
/* 270:330 */       if (loop == 0)
/* 271:    */       {
/* 272:332 */         bean = commtmpltBean.getDataBean(0, "SENDTOROLE");
/* 273:333 */         keyfield = "ROLEID";
/* 274:334 */         toListField = "TOLISTROLE";
/* 275:335 */         ccListField = "CCLISTROLE";
/* 276:336 */         bccListField = "BCCLISTROLE";
/* 277:    */       }
/* 278:338 */       else if (loop == 1)
/* 279:    */       {
/* 280:340 */         bean = commtmpltBean.getDataBean(0, "SENDTOPERSON");
/* 281:341 */         keyfield = "PERSONID";
/* 282:342 */         toListField = "TOLISTPERSON";
/* 283:343 */         ccListField = "CCLISTPERSON";
/* 284:344 */         bccListField = "BCCLISTPERSON";
/* 285:    */       }
/* 286:346 */       else if (loop == 2)
/* 287:    */       {
/* 288:348 */         bean = commtmpltBean.getDataBean(0, "SENDTOGROUP");
/* 289:349 */         keyfield = "GROUPID";
/* 290:350 */         toListField = "TOLISTGROUP";
/* 291:351 */         ccListField = "CCLISTGROUP";
/* 292:352 */         bccListField = "BCCLISTGROUP";
/* 293:    */       }
/* 294:354 */       else if (loop == 3)
/* 295:    */       {
/* 296:356 */         bean = commtmpltBean.getDataBean(0, "SENDTOEMAIL");
/* 297:357 */         keyfield = "SENDTOVALUE";
/* 298:358 */         toListField = "TOLISTEMAIL";
/* 299:359 */         ccListField = "CCLISTEMAIL";
/* 300:360 */         bccListField = "BCCLISTEMAIL";
/* 301:    */       }
/* 302:364 */       count = bean.count();
/* 303:365 */       for (int i = 0; i < count; i++) {
/* 304:367 */         if (bean.getMobileMbo(i).getBooleanValue("SENDTO")) {
/* 305:369 */           databean.setValue(toListField, addrecepient(databean.getValue(toListField), bean.getMobileMbo(i).getValue(keyfield)));
/* 306:373 */         } else if (bean.getMobileMbo(i).getBooleanValue("CC")) {
/* 307:375 */           databean.setValue(ccListField, addrecepient(databean.getValue(ccListField), bean.getMobileMbo(i).getValue(keyfield)));
/* 308:379 */         } else if (bean.getMobileMbo(i).getBooleanValue("BCC")) {
/* 309:381 */           databean.setValue(bccListField, addrecepient(databean.getValue(bccListField), bean.getMobileMbo(i).getValue(keyfield)));
/* 310:    */         }
/* 311:    */       }
/* 312:    */     }
/* 313:390 */     updateDisplayFields(databean);
/* 314:    */     
/* 315:    */ 
/* 316:393 */     return true;
/* 317:    */   }
/* 318:    */   
/* 319:    */   public boolean initcommtemplatelookup(UIEvent event)
/* 320:    */     throws MobileApplicationException
/* 321:    */   {
/* 322:398 */     MobileMboDataBean databean = ((PageControl)event.getCreatingObject()).getDataBean();
/* 323:    */     
/* 324:    */ 
/* 325:401 */     databean.getQBE().reset();
/* 326:402 */     databean.getQBE().setQBE("OBJECTNAME", databean.getParentBean().getValue("OWNERTABLE"));
/* 327:    */     
/* 328:404 */     return true;
/* 329:    */   }
/* 330:    */   
/* 331:    */   public boolean initrecipientsrole(UIEvent event)
/* 332:    */     throws MobileApplicationException
/* 333:    */   {
/* 334:414 */     MobileMboDataBean commDataBean = UIUtil.getCurrentScreen().getDataBean();
/* 335:    */     
/* 336:416 */     String ownertable = commDataBean.getValue("OWNERTABLE");
/* 337:    */     
/* 338:418 */     MobileMboDataBean rolesDataBean = ((TableControl)event.getCreatingObject()).getDataBean();
/* 339:419 */     rolesDataBean.reset();
/* 340:    */     
/* 341:    */ 
/* 342:    */ 
/* 343:    */ 
/* 344:    */ 
/* 345:425 */     int pos = 0;
/* 346:426 */     StringBuffer roles = new StringBuffer();
/* 347:427 */     MobileMbo rolesMbo = rolesDataBean.getMobileMbo(0);
/* 348:428 */     while (rolesMbo != null)
/* 349:    */     {
/* 350:430 */       String objectname = rolesMbo.getValue("OBJECTNAME");
/* 351:431 */       if ((objectname == null) || (objectname.equals("")) || (objectname.equalsIgnoreCase(ownertable))) {
/* 352:433 */         roles.append(rolesMbo.getValue("TEMP_MAXROLE") + ",");
/* 353:    */       }
/* 354:435 */       rolesMbo = rolesDataBean.getMobileMbo(++pos);
/* 355:    */     }
/* 356:438 */     if (roles.length() > 0) {
/* 357:440 */       roles.deleteCharAt(roles.length() - 1);
/* 358:    */     } else {
/* 359:444 */       roles.append("~NULL~");
/* 360:    */     }
/* 361:447 */     rolesDataBean.getQBE().setQBE("TEMP_MAXROLE", roles.toString());
/* 362:448 */     rolesDataBean.reset();
/* 363:    */     
/* 364:    */ 
/* 365:451 */     verifyRoles(rolesDataBean, ownertable, new HashMap());
/* 366:    */     
/* 367:453 */     return true;
/* 368:    */   }
/* 369:    */   
/* 370:    */   private void verifyRoles(MobileMboDataBean rolesDataBean, String ownertable, Map checkedRoles)
/* 371:    */     throws MobileApplicationException
/* 372:    */   {
/* 373:462 */     int pos = 0;
/* 374:463 */     MobileMbo rolesMbo = rolesDataBean.getMobileMbo(0);
/* 375:464 */     while (rolesMbo != null)
/* 376:    */     {
/* 377:466 */       String objectname = rolesMbo.getValue("OBJECTNAME");
/* 378:467 */       if ((objectname != null) && (!objectname.equals("")) && (!objectname.equalsIgnoreCase(ownertable)))
/* 379:    */       {
/* 380:469 */         rolesDataBean.remove(pos);
/* 381:470 */         rolesMbo = rolesDataBean.getMobileMbo(pos);
/* 382:    */       }
/* 383:    */       else
/* 384:    */       {
/* 385:472 */         boolean[] checks = (boolean[])checkedRoles.get(rolesMbo.getValue("MAXROLE"));
/* 386:473 */         if (checks != null)
/* 387:    */         {
/* 388:474 */           rolesMbo.setBooleanValue("SENDTO", checks[0]);
/* 389:475 */           rolesMbo.setBooleanValue("CC", checks[1]);
/* 390:476 */           rolesMbo.setBooleanValue("BCC", checks[2]);
/* 391:    */         }
/* 392:478 */         rolesMbo = rolesDataBean.getMobileMbo(++pos);
/* 393:    */       }
/* 394:    */     }
/* 395:    */   }
/* 396:    */   
/* 397:    */   public boolean initrecipientspeople(UIEvent event)
/* 398:    */     throws MobileApplicationException
/* 399:    */   {
/* 400:487 */     return true;
/* 401:    */   }
/* 402:    */   
/* 403:    */   public boolean initrecipientsgroups(UIEvent event)
/* 404:    */     throws MobileApplicationException
/* 405:    */   {
/* 406:492 */     return true;
/* 407:    */   }
/* 408:    */   
/* 409:    */   public boolean selectvalues(UIEvent event)
/* 410:    */     throws MobileApplicationException
/* 411:    */   {
/* 412:497 */     MobileMboDataBean commdatabean = DataBeanCache.findDataBean("COMMLOG");
/* 413:498 */     MobileMboDataBean roledatabean = DataBeanCache.findDataBean("COMMMAXROLE");
/* 414:499 */     MobileMboDataBean persondatabean = DataBeanCache.findDataBean("COMMEMAIL");
/* 415:500 */     MobileMboDataBean groupdatabean = DataBeanCache.findDataBean("COMMPERSONGROUP");
/* 416:501 */     MobileMboDataBean databean = null;
/* 417:502 */     String keyfield = "";
/* 418:503 */     String toListField = "";
/* 419:504 */     String ccListField = "";
/* 420:505 */     String bccListField = "";
/* 421:507 */     for (int loop = 0; loop < 3; loop++)
/* 422:    */     {
/* 423:509 */       if (loop == 0)
/* 424:    */       {
/* 425:511 */         databean = roledatabean;
/* 426:512 */         keyfield = "MAXROLE";
/* 427:513 */         toListField = "TOLISTROLE";
/* 428:514 */         ccListField = "CCLISTROLE";
/* 429:515 */         bccListField = "BCCLISTROLE";
/* 430:    */       }
/* 431:517 */       else if (loop == 1)
/* 432:    */       {
/* 433:519 */         databean = persondatabean;
/* 434:520 */         keyfield = "PERSONID";
/* 435:521 */         toListField = "TOLISTPERSON";
/* 436:522 */         ccListField = "CCLISTPERSON";
/* 437:523 */         bccListField = "BCCLISTPERSON";
/* 438:    */       }
/* 439:525 */       else if (loop == 2)
/* 440:    */       {
/* 441:527 */         databean = groupdatabean;
/* 442:528 */         keyfield = "PERSONGROUP";
/* 443:529 */         toListField = "TOLISTGROUP";
/* 444:530 */         ccListField = "CCLISTGROUP";
/* 445:531 */         bccListField = "BCCLISTGROUP";
/* 446:    */       }
/* 447:535 */       if (databean != null)
/* 448:    */       {
/* 449:537 */         int count = databean.count();
/* 450:538 */         for (int i = 0; i < count; i++)
/* 451:    */         {
/* 452:541 */           if (databean.getMobileMbo(i).getBooleanValue("SENDTO")) {
/* 453:543 */             commdatabean.setValue(toListField, addrecepient(commdatabean.getValue(toListField), databean.getMobileMbo(i).getValue(keyfield)));
/* 454:    */           }
/* 455:547 */           if (databean.getMobileMbo(i).getBooleanValue("CC")) {
/* 456:549 */             commdatabean.setValue(ccListField, addrecepient(commdatabean.getValue(ccListField), databean.getMobileMbo(i).getValue(keyfield)));
/* 457:    */           }
/* 458:553 */           if (databean.getMobileMbo(i).getBooleanValue("BCC")) {
/* 459:555 */             commdatabean.setValue(bccListField, addrecepient(commdatabean.getValue(bccListField), databean.getMobileMbo(i).getValue(keyfield)));
/* 460:    */           }
/* 461:    */         }
/* 462:    */       }
/* 463:    */     }
/* 464:563 */     updateDisplayFields(commdatabean);
/* 465:    */     
/* 466:565 */     UIUtil.getApplication().removeCurrentScreen(false);
/* 467:566 */     return true;
/* 468:    */   }
/* 469:    */   
/* 470:    */   private String addrecepient(String s, String v)
/* 471:    */     throws MobileApplicationException
/* 472:    */   {
/* 473:572 */     if (!duplicatesExist(s, v))
/* 474:    */     {
/* 475:574 */       if ((s != null) && (!s.equals(""))) {
/* 476:574 */         s = s + ",";
/* 477:    */       }
/* 478:575 */       s = s + v;
/* 479:    */     }
/* 480:578 */     return s;
/* 481:    */   }
/* 482:    */   
/* 483:    */   private boolean duplicatesExist(String list, String recipient)
/* 484:    */   {
/* 485:590 */     StringTokenizer st = new StringTokenizer(list, ",");
/* 486:591 */     while (st.hasMoreTokens())
/* 487:    */     {
/* 488:593 */       String id = st.nextToken();
/* 489:594 */       if (id.equals(recipient)) {
/* 490:596 */         return true;
/* 491:    */       }
/* 492:    */     }
/* 493:599 */     return false;
/* 494:    */   }
/* 495:    */   
/* 496:    */   private String createFieldValue(String role, String person, String group, String email)
/* 497:    */     throws MobileApplicationException
/* 498:    */   {
/* 499:604 */     String msg = "";
/* 500:605 */     if ((role != null) && (!role.equals("")))
/* 501:    */     {
/* 502:607 */       Object[] param = { role };
/* 503:608 */       msg = msg + MobileMessageGenerator.generate("commRoles", param);
/* 504:    */     }
/* 505:610 */     if (!msg.equals("")) {
/* 506:610 */       msg = msg + "  ";
/* 507:    */     }
/* 508:611 */     if ((person != null) && (!person.equals("")))
/* 509:    */     {
/* 510:613 */       Object[] param = { person };
/* 511:614 */       msg = msg + MobileMessageGenerator.generate("commPersons", param);
/* 512:    */     }
/* 513:616 */     if (!msg.equals("")) {
/* 514:616 */       msg = msg + "  ";
/* 515:    */     }
/* 516:617 */     if ((group != null) && (!group.equals("")))
/* 517:    */     {
/* 518:619 */       Object[] param = { group };
/* 519:620 */       msg = msg + MobileMessageGenerator.generate("commGroups", param);
/* 520:    */     }
/* 521:622 */     if (!msg.equals("")) {
/* 522:622 */       msg = msg + "  ";
/* 523:    */     }
/* 524:623 */     if ((email != null) && (!email.equals("")))
/* 525:    */     {
/* 526:625 */       Object[] param = { email };
/* 527:626 */       msg = msg + MobileMessageGenerator.generate("commEmails", param);
/* 528:    */     }
/* 529:629 */     return msg;
/* 530:    */   }
/* 531:    */   
/* 532:    */   public boolean validateroles(UIEvent event)
/* 533:    */     throws MobileApplicationException
/* 534:    */   {
/* 535:634 */     return validaterecipients(event, "MAXROLE");
/* 536:    */   }
/* 537:    */   
/* 538:    */   public boolean validatepeople(UIEvent event)
/* 539:    */     throws MobileApplicationException
/* 540:    */   {
/* 541:639 */     return validaterecipients(event, "EMAIL");
/* 542:    */   }
/* 543:    */   
/* 544:    */   public boolean validategroups(UIEvent event)
/* 545:    */     throws MobileApplicationException
/* 546:    */   {
/* 547:644 */     return validaterecipients(event, "PERSONGROUP");
/* 548:    */   }
/* 549:    */   
/* 550:    */   public boolean validateemails(UIEvent event)
/* 551:    */     throws MobileApplicationException
/* 552:    */   {
/* 553:649 */     return validaterecipients(event, "EMAILS");
/* 554:    */   }
/* 555:    */   
/* 556:    */   public boolean validaterecipients(UIEvent event, String dataset)
/* 557:    */     throws MobileApplicationException
/* 558:    */   {
/* 559:654 */     boolean bMobileMboValidate = true;
/* 560:656 */     if (dataset.equalsIgnoreCase("EMAILS")) {
/* 561:657 */       bMobileMboValidate = false;
/* 562:    */     }
/* 563:660 */     UIEvent userevent = UIUtil.getApplication().getUserEvent();
/* 564:661 */     if ((userevent != null) && (userevent.getEventName().equalsIgnoreCase("acceptvalue"))) {
/* 565:662 */       bMobileMboValidate = false;
/* 566:    */     }
/* 567:664 */     if (bMobileMboValidate) {
/* 568:666 */       if ((event.getValue() != null) && (!event.getValue().equals("")))
/* 569:    */       {
/* 570:668 */         String values = (String)event.getValue();
/* 571:669 */         StringTokenizer st = new StringTokenizer(values, ",");
/* 572:670 */         while (st.hasMoreTokens())
/* 573:    */         {
/* 574:672 */           String value = st.nextToken().trim();
/* 575:    */           
/* 576:674 */           MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager(dataset);
/* 577:675 */           MobileMboDataBean bean = mgrDBMgr.getDataBean();
/* 578:676 */           bean.getQBE().reset();
/* 579:677 */           bean.getQBE().setQbeExactMatch(true);
/* 580:679 */           if (dataset.equalsIgnoreCase("MAXROLE")) {
/* 581:681 */             bean.getQBE().setQBE("MAXROLE", value);
/* 582:683 */           } else if (dataset.equalsIgnoreCase("EMAIL")) {
/* 583:685 */             bean.getQBE().setQBE("PERSONID", value);
/* 584:687 */           } else if (dataset.equalsIgnoreCase("PERSONGROUP")) {
/* 585:689 */             bean.getQBE().setQBE("PERSONGROUP", value);
/* 586:    */           }
/* 587:692 */           if (bean.getMobileMbo(0) == null)
/* 588:    */           {
/* 589:694 */             UIUtil.popupPage("invalidrecipient", event);
/* 590:695 */             event.setEventErrored();
/* 591:696 */             return true;
/* 592:    */           }
/* 593:    */         }
/* 594:    */       }
/* 595:    */     }
/* 596:702 */     return true;
/* 597:    */   }
/* 598:    */   
/* 599:    */   public boolean validatecommreceiptlist(UIEvent event)
/* 600:    */     throws MobileApplicationException
/* 601:    */   {
/* 602:708 */     MobileMboDataBean commdatabean = DataBeanCache.findDataBean("COMMLOG");
/* 603:709 */     updateDisplayFields(commdatabean);
/* 604:    */     
/* 605:711 */     UIUtil.getApplication().removeCurrentScreen(false);
/* 606:712 */     return true;
/* 607:    */   }
/* 608:    */   
/* 609:    */   public boolean updateDisplayFields(MobileMboDataBean commdatabean)
/* 610:    */     throws MobileApplicationException
/* 611:    */   {
/* 612:717 */     String tolist = createFieldValue(commdatabean.getValue("TOLISTROLE"), commdatabean.getValue("TOLISTPERSON"), commdatabean.getValue("TOLISTGROUP"), commdatabean.getValue("TOLISTEMAIL"));
/* 613:    */     
/* 614:    */ 
/* 615:    */ 
/* 616:    */ 
/* 617:    */ 
/* 618:723 */     String cclist = createFieldValue(commdatabean.getValue("CCLISTROLE"), commdatabean.getValue("CCLISTPERSON"), commdatabean.getValue("CCLISTGROUP"), commdatabean.getValue("CCLISTEMAIL"));
/* 619:    */     
/* 620:    */ 
/* 621:    */ 
/* 622:    */ 
/* 623:    */ 
/* 624:729 */     String bcclist = createFieldValue(commdatabean.getValue("BCCLISTROLE"), commdatabean.getValue("BCCLISTPERSON"), commdatabean.getValue("BCCLISTGROUP"), commdatabean.getValue("BCCLISTEMAIL"));
/* 625:    */     
/* 626:    */ 
/* 627:    */ 
/* 628:    */ 
/* 629:    */ 
/* 630:735 */     commdatabean.setValue("SENDTO", tolist);
/* 631:736 */     commdatabean.setValue("CC", cclist);
/* 632:737 */     commdatabean.setValue("BCC", bcclist);
/* 633:    */     
/* 634:739 */     return true;
/* 635:    */   }
/* 636:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.mobilewo.CreateCommEventHandler
 * JD-Core Version:    0.7.0.1
 */