/*   1:    */ package com.mro.mobile.app.mobilewo;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.app.BasicMobileDeviceUIApplication;
/*   5:    */ import com.mro.mobile.app.DirectDownloadEventHandler;
/*   6:    */ import com.mro.mobile.mbo.MobileMbo;
/*   7:    */ import com.mro.mobile.mbo.MobileMboQBE;
/*   8:    */ import com.mro.mobile.persist.RDOException;
/*   9:    */ import com.mro.mobile.ui.DataBeanCache;
/*  10:    */ import com.mro.mobile.ui.MobileMboDataBean;
/*  11:    */ import com.mro.mobile.ui.MobileMboDataBeanManager;
/*  12:    */ import com.mro.mobile.ui.event.UIEvent;
/*  13:    */ import com.mro.mobile.ui.res.UIUtil;
/*  14:    */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*  15:    */ import com.mro.mobile.ui.res.controls.PageControl;
/*  16:    */ import com.mro.mobileapp.WOApp;
/*  17:    */ 
/*  18:    */ public class WODirectDownloadEventHandler
/*  19:    */   extends DirectDownloadEventHandler
/*  20:    */ {
/*  21:    */   protected boolean downloadRecord(UIEvent event)
/*  22:    */     throws MobileApplicationException
/*  23:    */   {
/*  24: 56 */     MobileMboDataBean databean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*  25: 57 */     MobileMbo mbo = databean.getMobileMbo();
/*  26:    */     
/*  27: 59 */     String recordId = getRecordID(mbo.getValue("RECORDKEY"), mbo.getValue("SITEID"));
/*  28:    */     
/*  29: 61 */     downloadAdHocRecord(event, getMobileMboName(), recordId);
/*  30: 64 */     if (event.getThreadStatus() == 2) {
/*  31: 66 */       ((WOApp)UIUtil.getApplication()).rebuildLabTrans();
/*  32:    */     }
/*  33: 69 */     return true;
/*  34:    */   }
/*  35:    */   
/*  36:    */   public void downloadAdHocRecord(UIEvent event, String dataname, String _id)
/*  37:    */     throws MobileApplicationException
/*  38:    */   {
/*  39: 92 */     switch (event.getThreadStatus())
/*  40:    */     {
/*  41:    */     case -1: 
/*  42: 96 */       UIUtil.startWorkerThread(this, event);
/*  43: 97 */       break;
/*  44:    */     case 1: 
/*  45:102 */       UIUtil.getApplication().downloadAdHocMobileMbo(event.getProgressObserver(), dataname, "", _id);
/*  46:103 */       break;
/*  47:    */     case 2: 
/*  48:107 */       copyRecordToWorkist(dataname, _id);
/*  49:    */       
/*  50:109 */       UIUtil.showPage(getMainPageId());
/*  51:    */       
/*  52:111 */       break;
/*  53:    */     case 0: 
/*  54:115 */       UIUtil.refreshCurrentScreen();
/*  55:116 */       break;
/*  56:    */     case 3: 
/*  57:120 */       UIUtil.refreshCurrentScreen();
/*  58:121 */       UIUtil.showExceptionMessage(event.getException(), null, 0);
/*  59:    */     }
/*  60:    */   }
/*  61:    */   
/*  62:    */   protected void copyRecordToWorkist(String dataname, String _id)
/*  63:    */     throws MobileApplicationException, RDOException
/*  64:    */   {
/*  65:138 */     MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager(dataname);
/*  66:139 */     MobileMboDataBean bean = mgrDBMgr.getDataBean();
/*  67:140 */     bean.getQBE().reset();
/*  68:141 */     bean.getQBE().setQbeExactMatch(true);
/*  69:142 */     bean.getQBE().setQBE("_ID", _id);
/*  70:143 */     bean.reset();
/*  71:144 */     MobileMbo mbo = bean.getMobileMbo(0);
/*  72:145 */     if (mbo != null)
/*  73:    */     {
/*  74:146 */       MobileMboDataBean worklistBean = DataBeanCache.findDataBean("WORKLIST");
/*  75:147 */       ((WOApp)UIUtil.getApplication()).copyMboToWorkList(worklistBean, bean, mbo);
/*  76:148 */       worklistBean.getDataBeanManager().save();
/*  77:    */       
/*  78:    */ 
/*  79:151 */       ((MobileWOAppEventHandler)UIUtil.getAppEventHandler()).setWorklistRecordBean(null, bean);
/*  80:    */     }
/*  81:    */   }
/*  82:    */   
/*  83:    */   protected void selectRecordType(UIEvent event)
/*  84:    */     throws MobileApplicationException
/*  85:    */   {
/*  86:164 */     PageControl page = (PageControl)event.getCreatingObject();
/*  87:165 */     MobileMboDataBean dataBean = page.getDataBean();
/*  88:166 */     String menuItemId = page.getLaunchingControl().getId();
/*  89:167 */     WOApp woapp = (WOApp)UIUtil.getApplication();
/*  90:169 */     if (menuItemId.equals("smItemWorkOrder"))
/*  91:    */     {
/*  92:171 */       setMobileMboName("WORKORDER");
/*  93:172 */       setRecordClass("WORKORDER");
/*  94:173 */       setInternalRecordClass(woapp.getDefaultValue(dataBean, "WOCLASS", "WORKORDER"));
/*  95:    */     }
/*  96:175 */     else if (menuItemId.equals("smItemServiceRequest"))
/*  97:    */     {
/*  98:177 */       setMobileMboName("TICKET");
/*  99:178 */       setRecordClass("SR");
/* 100:179 */       setInternalRecordClass(woapp.getDefaultValue(dataBean, "TKCLASS", "SR"));
/* 101:    */     }
/* 102:181 */     else if (menuItemId.equals("smItemIncident"))
/* 103:    */     {
/* 104:183 */       setMobileMboName("TICKET");
/* 105:184 */       setRecordClass("INCIDENT");
/* 106:185 */       setInternalRecordClass(woapp.getDefaultValue(dataBean, "TKCLASS", "INCIDENT"));
/* 107:    */     }
/* 108:187 */     else if (menuItemId.equals("smItemProblem"))
/* 109:    */     {
/* 110:189 */       setMobileMboName("TICKET");
/* 111:190 */       setRecordClass("PROBLEM");
/* 112:191 */       setInternalRecordClass(woapp.getDefaultValue(dataBean, "TKCLASS", "PROBLEM"));
/* 113:    */     }
/* 114:193 */     else if (menuItemId.equals("smItemChange"))
/* 115:    */     {
/* 116:195 */       setMobileMboName("WORKORDER");
/* 117:196 */       setRecordClass("CHANGE");
/* 118:197 */       setInternalRecordClass(woapp.getDefaultValue(dataBean, "WOCLASS", "CHANGE"));
/* 119:    */     }
/* 120:199 */     else if (menuItemId.equals("smItemRelease"))
/* 121:    */     {
/* 122:201 */       setMobileMboName("WORKORDER");
/* 123:202 */       setRecordClass("RELEASE");
/* 124:203 */       setInternalRecordClass(woapp.getDefaultValue(dataBean, "WOCLASS", "RELEASE"));
/* 125:    */     }
/* 126:207 */     if (getMobileMboName().equals("WORKORDER"))
/* 127:    */     {
/* 128:209 */       setLookupPageId("workorderlookup");
/* 129:210 */       setRecordClassAttribute("WOCLASS");
/* 130:211 */       setRecordKeyAttribute("WONUM");
/* 131:212 */       setMainPageId("womain");
/* 132:    */     }
/* 133:214 */     else if (getMobileMboName().equals("TICKET"))
/* 134:    */     {
/* 135:216 */       setLookupPageId("ticketlookup");
/* 136:217 */       setRecordClassAttribute("CLASS");
/* 137:218 */       setRecordKeyAttribute("TICKETID");
/* 138:219 */       setMainPageId("ticketmain");
/* 139:    */     }
/* 140:223 */     setAlreadyDownloadedMsgKey("alreadydownloaded");
/* 141:    */     
/* 142:225 */     setMboDescription(loadMboDescription(getMobileMboName(), getRecordClass()));
/* 143:    */     
/* 144:227 */     dataBean.setValue("MBO_DESCRIPTION", getMboDescription());
/* 145:    */   }
/* 146:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.mobilewo.WODirectDownloadEventHandler
 * JD-Core Version:    0.7.0.1
 */