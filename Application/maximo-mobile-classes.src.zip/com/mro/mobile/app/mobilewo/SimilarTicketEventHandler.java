/*   1:    */ package com.mro.mobile.app.mobilewo;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.MobileMessageGenerator;
/*   5:    */ import com.mro.mobile.mbo.MobileMbo;
/*   6:    */ import com.mro.mobile.mbo.MobileMboOrder;
/*   7:    */ import com.mro.mobile.mbo.MobileMboQBE;
/*   8:    */ import com.mro.mobile.ui.DataBeanCache;
/*   9:    */ import com.mro.mobile.ui.MobileMboDataBean;
/*  10:    */ import com.mro.mobile.ui.MobileMboDataBeanManager;
/*  11:    */ import com.mro.mobile.ui.event.UIEvent;
/*  12:    */ import com.mro.mobile.ui.res.ControlData;
/*  13:    */ import com.mro.mobile.ui.res.UIUtil;
/*  14:    */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*  15:    */ import com.mro.mobile.ui.res.controls.PageControl;
/*  16:    */ import com.mro.mobileapp.WOApp;
/*  17:    */ import java.util.HashMap;
/*  18:    */ import java.util.Map;
/*  19:    */ 
/*  20:    */ public class SimilarTicketEventHandler
/*  21:    */   extends MobileWOCommonEventHandler
/*  22:    */ {
/*  23:    */   public boolean performEvent(UIEvent event)
/*  24:    */     throws MobileApplicationException
/*  25:    */   {
/*  26: 38 */     if (event == null) {
/*  27: 38 */       return false;
/*  28:    */     }
/*  29: 40 */     String eventId = event.getEventName();
/*  30: 42 */     if (eventId.equalsIgnoreCase("initpage")) {
/*  31: 44 */       return initpage(event);
/*  32:    */     }
/*  33: 46 */     if (eventId.equalsIgnoreCase("refreshSimilarTickets")) {
/*  34: 48 */       return refreshSimilarTickets(event);
/*  35:    */     }
/*  36: 50 */     if (eventId.equalsIgnoreCase("makerelatedrecord")) {
/*  37: 52 */       return makerelatedrecord(event);
/*  38:    */     }
/*  39: 54 */     super.performEvent(event);
/*  40:    */     
/*  41: 56 */     return false;
/*  42:    */   }
/*  43:    */   
/*  44:    */   public boolean initpage(UIEvent event)
/*  45:    */     throws MobileApplicationException
/*  46:    */   {
/*  47: 62 */     MobileMboDataBean databean = ((PageControl)event.getCreatingObject()).getDataBean();
/*  48: 63 */     return doRefreshSimilarTickets(event, databean);
/*  49:    */   }
/*  50:    */   
/*  51:    */   public boolean refreshSimilarTickets(UIEvent event)
/*  52:    */     throws MobileApplicationException
/*  53:    */   {
/*  54: 68 */     MobileMboDataBean databean = ((PageControl)event.getCreatingObject()).getDataBean();
/*  55: 71 */     if ((databean != null) && (databean.isOnline()) && (databean.isFiltered())) {
/*  56: 73 */       return true;
/*  57:    */     }
/*  58: 76 */     return doRefreshSimilarTickets(event, databean);
/*  59:    */   }
/*  60:    */   
/*  61:    */   public boolean doRefreshSimilarTickets(UIEvent event, MobileMboDataBean databean)
/*  62:    */     throws MobileApplicationException
/*  63:    */   {
/*  64: 82 */     MobileMboDataBean tkdatabean = DataBeanCache.findDataBean("TICKET");
/*  65:    */     
/*  66:    */ 
/*  67:    */ 
/*  68:    */ 
/*  69:    */ 
/*  70: 88 */     String classStructId = "INVALID";
/*  71: 89 */     if ((tkdatabean.getValue("CLASSSTRUCTUREID") != null) && (tkdatabean.getValue("CLASSSTRUCTUREID").length() > 0)) {
/*  72: 91 */       classStructId = tkdatabean.getValue("CLASSSTRUCTUREID");
/*  73:    */     }
/*  74: 96 */     Map ticketuids = new HashMap();
/*  75: 97 */     String ticketuid = tkdatabean.getValue("TICKETUID");
/*  76: 98 */     ticketuids.put(ticketuid, ticketuid);
/*  77:100 */     if (databean == null) {
/*  78:101 */       return true;
/*  79:    */     }
/*  80:103 */     if (databean.isOnline())
/*  81:    */     {
/*  82:105 */       databean.getQBE().reset();
/*  83:106 */       databean.getQBE().setQbeExactMatch(true);
/*  84:107 */       databean.getQBE().setQBE("SIMILARTICKETTICKETID", ticketuid);
/*  85:108 */       databean.getQBE().setQBE("HISTORYFLAG", "");
/*  86:109 */       databean.getQBE().setQBE("CLASSSTRUCTUREID", "");
/*  87:110 */       databean.getQBE().setQBE("TICKETUID", "");
/*  88:    */       
/*  89:112 */       databean.getQBE().setQBE("ISGLOBAL", "0");
/*  90:    */     }
/*  91:    */     else
/*  92:    */     {
/*  93:116 */       MobileMboDataBean relrecdatabean = tkdatabean.getDataBean("TKRELTICKETS");
/*  94:117 */       int count = relrecdatabean.count();
/*  95:118 */       for (int i = 0; i < count; i++)
/*  96:    */       {
/*  97:120 */         String relatedreckeyid = relrecdatabean.getValue(i, "RELATEDRECKEYID");
/*  98:121 */         ticketuids.put(relatedreckeyid, relatedreckeyid);
/*  99:    */       }
/* 100:124 */       databean.getQBE().setQbeExactMatch(true);
/* 101:125 */       databean.getQBE().setQBE("SIMILARTICKETTICKETID", "");
/* 102:126 */       databean.getQBE().setQBE("HISTORYFLAG", "0");
/* 103:127 */       databean.getQBE().setQBE("CLASSSTRUCTUREID", classStructId);
/* 104:    */       
/* 105:    */ 
/* 106:130 */       databean.getQBE().setQBE("CLASS", tkdatabean.getValue("CLASS"));
/* 107:    */       
/* 108:132 */       databean.getQBE().setQBE("ISGLOBAL", "0");
/* 109:    */       
/* 110:    */ 
/* 111:    */ 
/* 112:136 */       databean.getOrder().setOrder("TICKETID", true);
/* 113:137 */       databean.getOrder().setOrder("CLASS", true);
/* 114:    */       
/* 115:    */ 
/* 116:140 */       databean.reset();
/* 117:141 */       int i = 0;
/* 118:142 */       MobileMbo mbo = databean.getMobileMbo(i);
/* 119:143 */       while (mbo != null)
/* 120:    */       {
/* 121:145 */         String tId = databean.getValue(i, "TICKETUID");
/* 122:146 */         if (ticketuids.containsKey(tId)) {
/* 123:148 */           databean.remove(i);
/* 124:    */         }
/* 125:150 */         mbo = databean.getMobileMbo(++i);
/* 126:    */       }
/* 127:    */     }
/* 128:155 */     return true;
/* 129:    */   }
/* 130:    */   
/* 131:    */   public boolean makerelatedrecord(UIEvent event)
/* 132:    */     throws MobileApplicationException
/* 133:    */   {
/* 134:160 */     MobileMboDataBean tkdatabean = DataBeanCache.findDataBean("TICKET");
/* 135:    */     
/* 136:162 */     MobileMboDataBean ludatabean = UIUtil.getCurrentScreen().getDataBean();
/* 137:163 */     if (ludatabean == null) {
/* 138:164 */       return true;
/* 139:    */     }
/* 140:166 */     MobileMboDataBean reldatabean = tkdatabean.getDataBean("TKRELTICKETS");
/* 141:168 */     if ((tkdatabean.getValue("TICKETID").equalsIgnoreCase(ludatabean.getValue("TICKETID"))) && (tkdatabean.getValue("CLASS").equalsIgnoreCase(ludatabean.getValue("CLASS"))) && (tkdatabean.getValue("ORGID").equalsIgnoreCase(ludatabean.getValue("ORGID"))) && (tkdatabean.getValue("SITEID").equalsIgnoreCase(ludatabean.getValue("SITEID"))))
/* 142:    */     {
/* 143:173 */       UIUtil.showInfoMessageBox(MobileMessageGenerator.generate("NoOwnParent", new Object[] { ludatabean.getValue("TICKETID") }));
/* 144:174 */       return true;
/* 145:    */     }
/* 146:178 */     int relwocount = reldatabean.count();
/* 147:179 */     for (int b = 0; b < relwocount; b++) {
/* 148:181 */       if ((ludatabean.getValue("TICKETID").equalsIgnoreCase(reldatabean.getMobileMbo(b).getValue("RELATEDRECKEY"))) && (ludatabean.getValue("CLASS").equalsIgnoreCase(reldatabean.getMobileMbo(b).getValue("RELATEDRECCLASS"))) && (ludatabean.getValue("ORGID").equalsIgnoreCase(reldatabean.getMobileMbo(b).getValue("RELATEDRECORGID"))) && (ludatabean.getValue("SITEID").equalsIgnoreCase(reldatabean.getMobileMbo(b).getValue("RELATEDRECSITEID"))))
/* 149:    */       {
/* 150:186 */         UIUtil.showInfoMessageBox(MobileMessageGenerator.generate("tkalreadyrelated", new Object[] { ludatabean.getValue("TICKETID") }));
/* 151:187 */         return true;
/* 152:    */       }
/* 153:    */     }
/* 154:192 */     AbstractMobileControl ctrl = (AbstractMobileControl)event.getCreatingObject();
/* 155:193 */     String optionName = ctrl.getControlData().getValue("sigoption");
/* 156:194 */     if (UIUtil.checkESignature(event, reldatabean, optionName))
/* 157:    */     {
/* 158:197 */       long relatedreckeyid = ludatabean.getMobileMbo().getLongValue("_ID");
/* 159:198 */       if (ludatabean.isOnline()) {
/* 160:199 */         relatedreckeyid = ludatabean.getMobileMbo().getLongValue("TICKETUID");
/* 161:    */       }
/* 162:201 */       ((WOApp)UIUtil.getApplication()).addRelatedRecToTK(tkdatabean.getValue("_ID"), tkdatabean.getValue("TICKETID"), tkdatabean.getValue("ORGID"), tkdatabean.getValue("SITEID"), tkdatabean.getValue("CLASS"), relatedreckeyid, "TICKET", "", ludatabean.getValue("TICKETID"), ludatabean.getValue("ORGID"), ludatabean.getValue("SITEID"), ludatabean.getValue("CLASS"));
/* 163:    */       
/* 164:    */ 
/* 165:    */ 
/* 166:    */ 
/* 167:    */ 
/* 168:    */ 
/* 169:    */ 
/* 170:    */ 
/* 171:    */ 
/* 172:    */ 
/* 173:    */ 
/* 174:    */ 
/* 175:    */ 
/* 176:    */ 
/* 177:216 */       String keyfield = "_ID";
/* 178:217 */       if (ludatabean.isOnline()) {
/* 179:218 */         keyfield = "TICKETUID";
/* 180:    */       }
/* 181:220 */       ((WOApp)UIUtil.getApplication()).addRelatedRecToTK(ludatabean.getValue(keyfield), ludatabean.getValue("TICKETID"), ludatabean.getValue("ORGID"), ludatabean.getValue("SITEID"), ludatabean.getValue("CLASS"), tkdatabean.getMobileMbo().getLongValue("_ID"), "TICKET", "", tkdatabean.getValue("TICKETID"), tkdatabean.getValue("ORGID"), tkdatabean.getValue("SITEID"), tkdatabean.getValue("CLASS"));
/* 182:    */       
/* 183:    */ 
/* 184:    */ 
/* 185:    */ 
/* 186:    */ 
/* 187:    */ 
/* 188:    */ 
/* 189:    */ 
/* 190:    */ 
/* 191:    */ 
/* 192:    */ 
/* 193:    */ 
/* 194:    */ 
/* 195:234 */       tkdatabean.getDataBeanManager().save();
/* 196:    */       
/* 197:236 */       UIUtil.showInfoMessageBox(MobileMessageGenerator.generate("tkrelationshipmade", new Object[] { ludatabean.getValue("TICKETID") }));
/* 198:    */       
/* 199:238 */       return true;
/* 200:    */     }
/* 201:241 */     event.setEventErrored();
/* 202:242 */     return false;
/* 203:    */   }
/* 204:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.mobilewo.SimilarTicketEventHandler
 * JD-Core Version:    0.7.0.1
 */