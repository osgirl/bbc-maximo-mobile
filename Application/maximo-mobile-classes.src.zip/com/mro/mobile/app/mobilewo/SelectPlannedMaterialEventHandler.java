/*   1:    */ package com.mro.mobile.app.mobilewo;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.MobileMessageGenerator;
/*   5:    */ import com.mro.mobile.app.BasicMobileDeviceUIApplication;
/*   6:    */ import com.mro.mobile.app.DefaultMobileMboDataFormatter;
/*   7:    */ import com.mro.mobile.mbo.MobileMbo;
/*   8:    */ import com.mro.mobile.mbo.MobileMboQBE;
/*   9:    */ import com.mro.mobile.ui.MobileMboDataBean;
/*  10:    */ import com.mro.mobile.ui.MobileMboDataBeanManager;
/*  11:    */ import com.mro.mobile.ui.event.UIEvent;
/*  12:    */ import com.mro.mobile.ui.res.UIUtil;
/*  13:    */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*  14:    */ import com.mro.mobile.ui.res.controls.PageControl;
/*  15:    */ import com.mro.mobileapp.WOApp;
/*  16:    */ 
/*  17:    */ public class SelectPlannedMaterialEventHandler
/*  18:    */   extends MobileWOCommonEventHandler
/*  19:    */ {
/*  20:    */   public boolean performEvent(UIEvent event)
/*  21:    */     throws MobileApplicationException
/*  22:    */   {
/*  23: 33 */     if (event == null) {
/*  24: 33 */       return false;
/*  25:    */     }
/*  26: 35 */     String eventId = event.getEventName();
/*  27: 37 */     if (eventId.equalsIgnoreCase("initpage")) {
/*  28: 39 */       return initpage(event);
/*  29:    */     }
/*  30: 41 */     if (eventId.equalsIgnoreCase("selectvalues")) {
/*  31: 43 */       return selectvalues(event);
/*  32:    */     }
/*  33: 45 */     if (eventId.equalsIgnoreCase("initassetspareparts")) {
/*  34: 47 */       return initassetspareparts(event);
/*  35:    */     }
/*  36: 49 */     if (eventId.equalsIgnoreCase("initresitemslookup")) {
/*  37: 51 */       return initresitemslookup(event);
/*  38:    */     }
/*  39: 53 */     if (eventId.equalsIgnoreCase("luconnect")) {
/*  40: 55 */       return luconnect(event);
/*  41:    */     }
/*  42: 58 */     if (eventId.equalsIgnoreCase("setDefaultQuantity")) {
/*  43: 60 */       return setDefaultQuantity(event);
/*  44:    */     }
/*  45: 63 */     super.performEvent(event);
/*  46:    */     
/*  47: 65 */     return false;
/*  48:    */   }
/*  49:    */   
/*  50:    */   protected boolean setDefaultQuantity(UIEvent event)
/*  51:    */     throws MobileApplicationException
/*  52:    */   {
/*  53: 71 */     MobileMboDataBean databean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*  54: 72 */     setDefaultQuantity(databean);
/*  55:    */     
/*  56: 74 */     return true;
/*  57:    */   }
/*  58:    */   
/*  59:    */   public boolean initpage(UIEvent event)
/*  60:    */     throws MobileApplicationException
/*  61:    */   {
/*  62: 80 */     MobileMboDataBean databean = ((PageControl)event.getCreatingObject()).getDataBean();
/*  63:    */     
/*  64: 82 */     int count = databean.count();
/*  65: 83 */     for (int i = 0; i < count; i++) {
/*  66: 85 */       if (!databean.getMobileMbo(i).getValue("LABORCODE").equals("")) {
/*  67: 86 */         databean.getMobileMbo(i).setValue("PLAN", databean.getMobileMbo(i).getValue("LABORCODE"));
/*  68:    */       } else {
/*  69: 88 */         databean.getMobileMbo(i).setValue("PLAN", databean.getMobileMbo(i).getValue("CRAFT") + " " + databean.getMobileMbo(i).getValue("SKILLLEVEL"));
/*  70:    */       }
/*  71:    */     }
/*  72: 92 */     return true;
/*  73:    */   }
/*  74:    */   
/*  75:    */   public boolean initresitemslookup(UIEvent event)
/*  76:    */     throws MobileApplicationException
/*  77:    */   {
/*  78: 97 */     MobileMboDataBean databean = ((PageControl)event.getCreatingObject()).getDataBean();
/*  79: 98 */     MobileMboDataBean wodatabean = databean.getParentBean();
/*  80:    */     
/*  81:    */ 
/*  82:    */ 
/*  83:102 */     String origMaxStatus = ((WOApp)UIUtil.getApplication()).getInternalValue(wodatabean, "WOSTATUS", wodatabean.getValue("ORIGSTATUS"));
/*  84:104 */     if (origMaxStatus.equalsIgnoreCase("WAPPR"))
/*  85:    */     {
/*  86:106 */       UIUtil.gotoPageNoSave("planmatlookup", UIUtil.getCurrentScreen());
/*  87:107 */       event.setEventErrored();
/*  88:    */     }
/*  89:    */     else
/*  90:    */     {
/*  91:110 */       setDefaultQuantity(databean);
/*  92:    */     }
/*  93:114 */     return true;
/*  94:    */   }
/*  95:    */   
/*  96:    */   public boolean selectvalues(UIEvent event)
/*  97:    */     throws MobileApplicationException
/*  98:    */   {
/*  99:121 */     String pageid = UIUtil.getCurrentScreen().getPage().getId();
/* 100:123 */     if (pageid.equalsIgnoreCase("matlookup")) {
/* 101:124 */       return selectmatvalues(event);
/* 102:    */     }
/* 103:126 */     if (pageid.equalsIgnoreCase("resitemslookup")) {
/* 104:127 */       return selectreservevalues(event);
/* 105:    */     }
/* 106:129 */     if (pageid.equalsIgnoreCase("assetsparepartslookup")) {
/* 107:130 */       return selectsparepartvalues(event);
/* 108:    */     }
/* 109:132 */     if (pageid.equalsIgnoreCase("planmatlookup")) {
/* 110:133 */       return selectplanmatvalues(event);
/* 111:    */     }
/* 112:135 */     return true;
/* 113:    */   }
/* 114:    */   
/* 115:    */   public boolean selectmatvalues(UIEvent event)
/* 116:    */     throws MobileApplicationException
/* 117:    */   {
/* 118:140 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/* 119:141 */     MobileMboDataBean mtdatabean = ((PageControl)UIUtil.getCurrentScreen()).getLaunchingControl().getDataBean();
/* 120:142 */     boolean incompleteRows = false;
/* 121:143 */     boolean atleastonerowcopied = false;
/* 122:    */     
/* 123:145 */     int count = databean.count();
/* 124:146 */     for (int i = 0; i < count; i++) {
/* 125:148 */       if (databean.getMobileMbo(i).isSelected())
/* 126:    */       {
/* 127:154 */         atleastonerowcopied = true;
/* 128:155 */         mtdatabean.insert();
/* 129:156 */         mtdatabean.setValue("ITEMSETID", databean.getMobileMbo(i).getValue("ITEMSETID"));
/* 130:157 */         mtdatabean.setValue("ITEMNUM", databean.getMobileMbo(i).getValue("ITEMNUM"));
/* 131:158 */         mtdatabean.setValue("DESCRIPTION", databean.getMobileMbo(i).getValue("DESCRIPTION"));
/* 132:159 */         mtdatabean.setValue("POSITIVEQUANTITY", databean.getMobileMbo(i).getValue("QTY"));
/* 133:160 */         mtdatabean.setValue("LINETYPE", ((WOApp)UIUtil.getApplication()).getDefaultValue(databean, "LINETYPE", "ITEM"));
/* 134:162 */         if (!iscompletemattransrow(mtdatabean))
/* 135:    */         {
/* 136:164 */           incompleteRows = true;
/* 137:165 */           mtdatabean.markIncomplete();
/* 138:    */         }
/* 139:    */       }
/* 140:    */     }
/* 141:170 */     if (!atleastonerowcopied)
/* 142:    */     {
/* 143:172 */       mtdatabean.getDataBeanManager().cancel();
/* 144:173 */       UIUtil.getApplication().removeCurrentScreen(true);
/* 145:174 */       return true;
/* 146:    */     }
/* 147:177 */     if (!UIUtil.checkESignature(event, mtdatabean, "MATACTUALS"))
/* 148:    */     {
/* 149:179 */       mtdatabean.getDataBeanManager().cancel();
/* 150:    */     }
/* 151:    */     else
/* 152:    */     {
/* 153:183 */       mtdatabean.getDataBeanManager().save();
/* 154:184 */       mtdatabean.reset();
/* 155:185 */       if (incompleteRows) {
/* 156:186 */         UIUtil.showInfoMessageBox(MobileMessageGenerator.generate("matactincomplete", new Object[0]));
/* 157:    */       }
/* 158:187 */       UIUtil.getApplication().removeCurrentScreen(true);
/* 159:    */     }
/* 160:189 */     return true;
/* 161:    */   }
/* 162:    */   
/* 163:    */   public boolean selectreservevalues(UIEvent event)
/* 164:    */     throws MobileApplicationException
/* 165:    */   {
/* 166:194 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/* 167:195 */     MobileMboDataBean mtdatabean = ((PageControl)UIUtil.getCurrentScreen()).getLaunchingControl().getDataBean();
/* 168:196 */     boolean incompleteRows = false;
/* 169:197 */     boolean atleastonerowcopied = false;
/* 170:    */     
/* 171:199 */     String issueType = ((WOApp)UIUtil.getApplication()).getDefaultValue(databean, "ISSUETYP", "ISSUE");
/* 172:    */     
/* 173:    */ 
/* 174:202 */     int count = databean.count();
/* 175:203 */     for (int i = 0; i < count; i++) {
/* 176:205 */       if (databean.getMobileMbo(i).isSelected())
/* 177:    */       {
/* 178:208 */         double qtyForIssue = databean.getMobileMbo(i).getDoubleValue("QTY");
/* 179:212 */         if (databean.getMobileMbo(i).getBooleanValue("ITEM_ROTATING"))
/* 180:    */         {
/* 181:214 */           for (int b = 0; b < qtyForIssue; b++)
/* 182:    */           {
/* 183:216 */             atleastonerowcopied = true;
/* 184:217 */             mtdatabean.insert();
/* 185:218 */             addMatUseFromInvReserve(databean, mtdatabean, i, issueType);
/* 186:219 */             mtdatabean.setValue("POSITIVEQUANTITY", "1.0");
/* 187:220 */             mtdatabean.setValue("LINETYPE", ((WOApp)UIUtil.getApplication()).getDefaultValue(databean, "LINETYPE", "ITEM"));
/* 188:221 */             if (!iscompletemattransrow(mtdatabean))
/* 189:    */             {
/* 190:223 */               incompleteRows = true;
/* 191:224 */               mtdatabean.markIncomplete();
/* 192:    */             }
/* 193:    */           }
/* 194:    */         }
/* 195:    */         else
/* 196:    */         {
/* 197:230 */           atleastonerowcopied = true;
/* 198:231 */           mtdatabean.insert();
/* 199:232 */           addMatUseFromInvReserve(databean, mtdatabean, i, issueType);
/* 200:233 */           mtdatabean.getMobileMbo().setDoubleValue("POSITIVEQUANTITY", qtyForIssue);
/* 201:234 */           mtdatabean.setValue("LINETYPE", ((WOApp)UIUtil.getApplication()).getDefaultValue(databean, "LINETYPE", "ITEM"));
/* 202:235 */           if (!iscompletemattransrow(mtdatabean))
/* 203:    */           {
/* 204:237 */             incompleteRows = true;
/* 205:238 */             mtdatabean.markIncomplete();
/* 206:    */           }
/* 207:    */         }
/* 208:    */       }
/* 209:    */     }
/* 210:244 */     if (!atleastonerowcopied)
/* 211:    */     {
/* 212:246 */       mtdatabean.getDataBeanManager().cancel();
/* 213:247 */       UIUtil.getApplication().removeCurrentScreen(true);
/* 214:248 */       return true;
/* 215:    */     }
/* 216:251 */     if (!UIUtil.checkESignature(event, mtdatabean, "MATACTUALS"))
/* 217:    */     {
/* 218:253 */       mtdatabean.getDataBeanManager().cancel();
/* 219:    */     }
/* 220:    */     else
/* 221:    */     {
/* 222:257 */       mtdatabean.getDataBeanManager().save();
/* 223:258 */       mtdatabean.reset();
/* 224:259 */       if (incompleteRows) {
/* 225:260 */         UIUtil.showInfoMessageBox(MobileMessageGenerator.generate("matactincomplete", new Object[0]));
/* 226:    */       }
/* 227:261 */       UIUtil.getApplication().removeCurrentScreen(true);
/* 228:    */     }
/* 229:263 */     return true;
/* 230:    */   }
/* 231:    */   
/* 232:    */   public boolean selectplanmatvalues(UIEvent event)
/* 233:    */     throws MobileApplicationException
/* 234:    */   {
/* 235:268 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/* 236:269 */     MobileMboDataBean wodatabean = databean.getParentBean();
/* 237:270 */     MobileMboDataBean mtdatabean = wodatabean.getDataBean("WOMATTRANS");
/* 238:271 */     boolean incompleteRows = false;
/* 239:272 */     boolean atleastonerowcopied = false;
/* 240:    */     
/* 241:274 */     String issueType = ((WOApp)UIUtil.getApplication()).getDefaultValue(databean, "ISSUETYP", "ISSUE");
/* 242:    */     
/* 243:    */ 
/* 244:277 */     int count = databean.count();
/* 245:278 */     for (int i = 0; i < count; i++) {
/* 246:280 */       if (databean.getMobileMbo(i).isSelected())
/* 247:    */       {
/* 248:282 */         String SqtyForIssue = databean.getMobileMbo(i).getValue("ITEMQTY");
/* 249:283 */         double qtyForIssue = DefaultMobileMboDataFormatter.stringToDouble(SqtyForIssue);
/* 250:    */         
/* 251:    */ 
/* 252:    */ 
/* 253:    */ 
/* 254:    */ 
/* 255:289 */         MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager("ITEM");
/* 256:290 */         MobileMboDataBean itemBean = mgrDBMgr.getDataBean();
/* 257:291 */         itemBean.getQBE().setQBE("ITEMNUM", databean.getMobileMbo(i).getValue("ITEMNUM"));
/* 258:292 */         itemBean.getQBE().setQBE("ITEMSETID", databean.getMobileMbo(i).getValue("ITEMSETID"));
/* 259:    */         
/* 260:    */ 
/* 261:295 */         itemBean.getQBE().setQBE("ITEMTYPE", ((WOApp)UIUtil.getApplication()).getExternalValue(itemBean, "ITEMTYPE", "ITEM"));
/* 262:296 */         itemBean.getQBE().setQBE("ROTATING", "1");
/* 263:    */         
/* 264:298 */         itemBean.reset();
/* 265:299 */         if (itemBean.getMobileMbo(0) != null)
/* 266:    */         {
/* 267:301 */           for (int b = 0; b < qtyForIssue; b++)
/* 268:    */           {
/* 269:303 */             atleastonerowcopied = true;
/* 270:304 */             mtdatabean.insert();
/* 271:305 */             addMatUseFromMaterialPlan(databean, mtdatabean, i, issueType);
/* 272:306 */             mtdatabean.setValue("POSITIVEQUANTITY", "1.0");
/* 273:307 */             mtdatabean.setValue("LINETYPE", ((WOApp)UIUtil.getApplication()).getDefaultValue(databean, "LINETYPE", "ITEM"));
/* 274:308 */             if (!iscompletemattransrow(mtdatabean))
/* 275:    */             {
/* 276:310 */               incompleteRows = true;
/* 277:311 */               mtdatabean.markIncomplete();
/* 278:    */             }
/* 279:    */           }
/* 280:    */         }
/* 281:    */         else
/* 282:    */         {
/* 283:317 */           atleastonerowcopied = true;
/* 284:318 */           mtdatabean.insert();
/* 285:319 */           addMatUseFromMaterialPlan(databean, mtdatabean, i, issueType);
/* 286:    */           
/* 287:321 */           mtdatabean.getMobileMbo().setDoubleValue("POSITIVEQUANTITY", qtyForIssue);
/* 288:322 */           mtdatabean.setValue("LINETYPE", ((WOApp)UIUtil.getApplication()).getDefaultValue(databean, "LINETYPE", "ITEM"));
/* 289:323 */           if (!iscompletemattransrow(mtdatabean))
/* 290:    */           {
/* 291:325 */             incompleteRows = true;
/* 292:326 */             mtdatabean.markIncomplete();
/* 293:    */           }
/* 294:    */         }
/* 295:    */       }
/* 296:    */     }
/* 297:332 */     if (!atleastonerowcopied)
/* 298:    */     {
/* 299:334 */       mtdatabean.getDataBeanManager().cancel();
/* 300:335 */       UIUtil.getApplication().removeCurrentScreen(true);
/* 301:336 */       return true;
/* 302:    */     }
/* 303:339 */     if (!UIUtil.checkESignature(event, mtdatabean, "MATACTUALS"))
/* 304:    */     {
/* 305:341 */       mtdatabean.getDataBeanManager().cancel();
/* 306:    */     }
/* 307:    */     else
/* 308:    */     {
/* 309:345 */       mtdatabean.getDataBeanManager().save();
/* 310:346 */       mtdatabean.reset();
/* 311:347 */       if (incompleteRows) {
/* 312:348 */         UIUtil.showInfoMessageBox(MobileMessageGenerator.generate("matactincomplete", new Object[0]));
/* 313:    */       }
/* 314:349 */       UIUtil.getApplication().removeCurrentScreen(true);
/* 315:    */     }
/* 316:351 */     return true;
/* 317:    */   }
/* 318:    */   
/* 319:    */   public void addMatUseFromInvReserve(MobileMboDataBean databean, MobileMboDataBean mtdatabean, int i, String issueType)
/* 320:    */     throws MobileApplicationException
/* 321:    */   {
/* 322:356 */     if (!databean.getMobileMbo(i).isNull("glaccount")) {
/* 323:358 */       mtdatabean.setValue("GLDEBITACCT", databean.getMobileMbo(i).getValue("GLACCOUNT"));
/* 324:    */     }
/* 325:361 */     mtdatabean.setValue("ISSUETYPE", issueType);
/* 326:362 */     mtdatabean.setValue("ITEMNUM", databean.getMobileMbo(i).getValue("ITEMNUM"));
/* 327:363 */     mtdatabean.setValue("ITEMSETID", databean.getMobileMbo(i).getValue("ITEMSETID"));
/* 328:364 */     mtdatabean.setValue("CONDITIONCODE", databean.getMobileMbo(i).getValue("CONDITIONCODE"));
/* 329:365 */     mtdatabean.setValue("SITEID", databean.getMobileMbo(i).getValue("STORELOCSITEID"));
/* 330:366 */     mtdatabean.setValue("TOSITEID", databean.getMobileMbo(i).getValue("SITEID"));
/* 331:367 */     mtdatabean.setValue("STORELOC", databean.getMobileMbo(i).getValue("LOCATION"));
/* 332:368 */     mtdatabean.setValue("REQUESTNUM", databean.getMobileMbo(i).getValue("REQUESTNUM"));
/* 333:369 */     mtdatabean.setValue("RESERVEDQTY", databean.getMobileMbo(i).getValue("RESERVEDQTY"));
/* 334:    */     
/* 335:371 */     mtdatabean.setValue("ACTUALSTASKID", databean.getMobileMbo(i).getValue("DISPLAYTASKID"));
/* 336:372 */     mtdatabean.setValue("ISSUETO", databean.getMobileMbo(i).getValue("ISSUETO"));
/* 337:376 */     if ((mtdatabean.getValue("ASSETNUM") == null) || (mtdatabean.getValue("ASSETNUM") == "")) {
/* 338:378 */       mtdatabean.setValue("ASSETNUM", databean.getMobileMbo(i).getValue("ASSETNUM"));
/* 339:    */     }
/* 340:381 */     mtdatabean.setValue("PONUM", databean.getMobileMbo(i).getValue("PONUM"));
/* 341:382 */     mtdatabean.setValue("POLINENUM", databean.getMobileMbo(i).getValue("POLINENUM"));
/* 342:383 */     mtdatabean.setValue("DESCRIPTION", databean.getMobileMbo(i).getValue("DESCRIPTION"));
/* 343:384 */     mtdatabean.setValue("MRNUM", databean.getMobileMbo(i).getValue("MRNUM"));
/* 344:385 */     mtdatabean.setValue("MRLINENUM", databean.getMobileMbo(i).getValue("MRLINENUM"));
/* 345:388 */     if ((!mtdatabean.getValue("SITEID").equals("")) && (!mtdatabean.getValue("STORELOC").equals("")) && (mtdatabean.getValue("BINNUM").equals("")))
/* 346:    */     {
/* 347:391 */       MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager("INVBALANCES");
/* 348:392 */       MobileMboDataBean balBean = mgrDBMgr.getDataBean();
/* 349:    */       
/* 350:394 */       balBean.getQBE().reset();
/* 351:395 */       balBean.getQBE().setQbeExactMatch(true);
/* 352:396 */       balBean.getQBE().setQBE("ITEMNUM", mtdatabean.getValue("ITEMNUM"));
/* 353:397 */       balBean.getQBE().setQBE("ITEMSETID", mtdatabean.getValue("ITEMSETID"));
/* 354:398 */       balBean.getQBE().setQBE("SITEID", mtdatabean.getValue("SITEID"));
/* 355:399 */       balBean.getQBE().setQBE("LOCATION", mtdatabean.getValue("STORELOC"));
/* 356:    */       
/* 357:401 */       MobileMbo balMbo = balBean.getMobileMbo(0);
/* 358:403 */       if (balMbo != null) {
/* 359:405 */         mtdatabean.setValue("BINNUM", balMbo.getValue("BINNUM"));
/* 360:    */       }
/* 361:    */     }
/* 362:    */   }
/* 363:    */   
/* 364:    */   public void addMatUseFromMaterialPlan(MobileMboDataBean databean, MobileMboDataBean mtdatabean, int i, String issueType)
/* 365:    */     throws MobileApplicationException
/* 366:    */   {
/* 367:412 */     if (!databean.getMobileMbo(i).isNull("glaccount")) {
/* 368:414 */       mtdatabean.setValue("GLDEBITACCT", databean.getMobileMbo(i).getValue("GLACCOUNT"));
/* 369:    */     }
/* 370:417 */     mtdatabean.setValue("ISSUETYPE", issueType);
/* 371:418 */     mtdatabean.setValue("ITEMNUM", databean.getMobileMbo(i).getValue("ITEMNUM"));
/* 372:419 */     mtdatabean.setValue("ITEMSETID", databean.getMobileMbo(i).getValue("ITEMSETID"));
/* 373:420 */     mtdatabean.setValue("CONDITIONCODE", databean.getMobileMbo(i).getValue("CONDITIONCODE"));
/* 374:421 */     mtdatabean.setValue("SITEID", databean.getMobileMbo(i).getValue("STORELOCSITE"));
/* 375:422 */     mtdatabean.setValue("STORELOC", databean.getMobileMbo(i).getValue("LOCATION"));
/* 376:423 */     mtdatabean.setValue("TOSITEID", databean.getMobileMbo(i).getValue("SITEID"));
/* 377:    */     
/* 378:    */ 
/* 379:    */ 
/* 380:427 */     mtdatabean.setValue("ACTUALSTASKID", databean.getMobileMbo(i).getValue("TASKID"));
/* 381:428 */     mtdatabean.setValue("ISSUETO", databean.getMobileMbo(i).getValue("ISSUETO"));
/* 382:430 */     if ((mtdatabean.getValue("ASSETNUM") == null) || (mtdatabean.getValue("ASSETNUM") == "")) {
/* 383:432 */       if (!mtdatabean.getParentBean().getValue("ASSETNUM").equals("")) {
/* 384:433 */         mtdatabean.setValue("ASSETNUM", mtdatabean.getParentBean().getValue("ASSETNUM"));
/* 385:    */       }
/* 386:    */     }
/* 387:438 */     mtdatabean.setValue("DESCRIPTION", databean.getMobileMbo(i).getValue("DESCRIPTION"));
/* 388:443 */     if ((!mtdatabean.getValue("SITEID").equals("")) && (!mtdatabean.getValue("STORELOC").equals("")) && (mtdatabean.getValue("BINNUM").equals("")))
/* 389:    */     {
/* 390:446 */       MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager("INVBALANCES");
/* 391:447 */       MobileMboDataBean balBean = mgrDBMgr.getDataBean();
/* 392:    */       
/* 393:449 */       balBean.getQBE().reset();
/* 394:450 */       balBean.getQBE().setQbeExactMatch(true);
/* 395:451 */       balBean.getQBE().setQBE("ITEMNUM", mtdatabean.getValue("ITEMNUM"));
/* 396:452 */       balBean.getQBE().setQBE("ITEMSETID", mtdatabean.getValue("ITEMSETID"));
/* 397:453 */       balBean.getQBE().setQBE("SITEID", mtdatabean.getValue("SITEID"));
/* 398:454 */       balBean.getQBE().setQBE("LOCATION", mtdatabean.getValue("STORELOC"));
/* 399:    */       
/* 400:456 */       MobileMbo balMbo = balBean.getMobileMbo(0);
/* 401:458 */       if (balMbo != null) {
/* 402:460 */         mtdatabean.setValue("BINNUM", balMbo.getValue("BINNUM"));
/* 403:    */       }
/* 404:    */     }
/* 405:    */   }
/* 406:    */   
/* 407:    */   public boolean initassetspareparts(UIEvent event)
/* 408:    */     throws MobileApplicationException
/* 409:    */   {
/* 410:467 */     MobileMboDataBean databean = ((PageControl)event.getCreatingObject()).getDataBean();
/* 411:468 */     MobileMboDataBean wodatabean = ((PageControl)UIUtil.getCurrentScreen()).getDataBean();
/* 412:469 */     if (wodatabean.getName().equals("WOCHILDREN")) {
/* 413:470 */       wodatabean = wodatabean.getParentBean();
/* 414:    */     }
/* 415:478 */     if (!wodatabean.getValue("ASSETNUM").equals("")) {
/* 416:480 */       databean.getQBE().setQBE("ASSETNUM", wodatabean.getValue("ASSETNUM"));
/* 417:    */     }
/* 418:483 */     if (!wodatabean.getValue("SITEID").equals("")) {
/* 419:485 */       databean.getQBE().setQBE("SITEID", wodatabean.getValue("SITEID"));
/* 420:    */     }
/* 421:488 */     databean.reset();
/* 422:492 */     for (int i = 0; i < databean.count(); i++) {
/* 423:493 */       databean.setValue(i, "QTY", databean.getValue(i, "QUANTITY"));
/* 424:    */     }
/* 425:496 */     return true;
/* 426:    */   }
/* 427:    */   
/* 428:    */   public boolean selectsparepartvalues(UIEvent event)
/* 429:    */     throws MobileApplicationException
/* 430:    */   {
/* 431:501 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/* 432:502 */     MobileMboDataBean mtdatabean = ((PageControl)UIUtil.getCurrentScreen()).getLaunchingControl().getDataBean();
/* 433:503 */     boolean incompleteRows = false;
/* 434:504 */     boolean atleastonerowcopied = false;
/* 435:    */     
/* 436:506 */     int count = databean.count();
/* 437:507 */     for (int i = 0; i < count; i++) {
/* 438:509 */       if (databean.getMobileMbo(i).isSelected())
/* 439:    */       {
/* 440:514 */         atleastonerowcopied = true;
/* 441:515 */         mtdatabean.insert();
/* 442:516 */         mtdatabean.setValue("ITEMSETID", databean.getMobileMbo(i).getValue("ITEMSETID"));
/* 443:517 */         mtdatabean.setValue("ITEMNUM", databean.getMobileMbo(i).getValue("ITEMNUM"));
/* 444:    */         
/* 445:519 */         mtdatabean.setValue("POSITIVEQUANTITY", databean.getMobileMbo(i).getValue("QTY"));
/* 446:520 */         mtdatabean.setValue("LINETYPE", ((WOApp)UIUtil.getApplication()).getDefaultValue(databean, "LINETYPE", "ITEM"));
/* 447:521 */         if (!iscompletemattransrow(mtdatabean))
/* 448:    */         {
/* 449:523 */           incompleteRows = true;
/* 450:524 */           mtdatabean.markIncomplete();
/* 451:    */         }
/* 452:    */       }
/* 453:    */     }
/* 454:529 */     if (!atleastonerowcopied)
/* 455:    */     {
/* 456:531 */       mtdatabean.getDataBeanManager().cancel();
/* 457:532 */       UIUtil.getApplication().removeCurrentScreen(true);
/* 458:533 */       return true;
/* 459:    */     }
/* 460:536 */     if (incompleteRows) {
/* 461:537 */       UIUtil.showInfoMessageBox(MobileMessageGenerator.generate("matactincomplete", new Object[0]));
/* 462:    */     }
/* 463:539 */     UIUtil.getApplication().removeCurrentScreen(true);
/* 464:540 */     return true;
/* 465:    */   }
/* 466:    */   
/* 467:    */   public boolean iscompletemattransrow(MobileMboDataBean databean)
/* 468:    */     throws MobileApplicationException
/* 469:    */   {
/* 470:547 */     MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager("INVBALANCES");
/* 471:548 */     MobileMboDataBean balBean = mgrDBMgr.getDataBean();
/* 472:    */     
/* 473:550 */     balBean.getQBE().reset();
/* 474:551 */     balBean.getQBE().setQbeExactMatch(true);
/* 475:552 */     balBean.getQBE().setQBE("SITEID", "~NULL~");
/* 476:553 */     balBean.getQBE().setQBE("LOCATION", "~NULL~");
/* 477:554 */     balBean.getQBE().setQBE("BINNUM", "~NULL~");
/* 478:555 */     balBean.getQBE().setQBE("LOTNUM", "~NULL~");
/* 479:556 */     balBean.getQBE().setQBE("CONDITIONCODE", "~NULL~");
/* 480:    */     
/* 481:558 */     balBean.getQBE().setQBE("ITEMNUM", databean.getValue("ITEMNUM"));
/* 482:559 */     balBean.getQBE().setQBE("ITEMSETID", databean.getValue("ITEMSETID"));
/* 483:561 */     if (!databean.getValue("SITEID").equals("")) {
/* 484:562 */       balBean.getQBE().setQBE("SITEID", databean.getValue("SITEID"));
/* 485:    */     }
/* 486:564 */     if (!databean.getValue("STORELOC").equals("")) {
/* 487:565 */       balBean.getQBE().setQBE("LOCATION", databean.getValue("STORELOC"));
/* 488:    */     }
/* 489:567 */     if (!databean.getValue("BINNUM").equals("")) {
/* 490:568 */       balBean.getQBE().setQBE("BINNUM", databean.getValue("BINNUM"));
/* 491:    */     }
/* 492:570 */     if (!databean.getValue("LOTNUM").equals("")) {
/* 493:571 */       balBean.getQBE().setQBE("LOTNUM", databean.getValue("LOTNUM"));
/* 494:    */     }
/* 495:573 */     if (!databean.getValue("CONDITIONCODE").equals("")) {
/* 496:574 */       balBean.getQBE().setQBE("CONDITIONCODE", databean.getValue("CONDITIONCODE"));
/* 497:    */     }
/* 498:576 */     MobileMbo balMbo = balBean.getMobileMbo(0);
/* 499:578 */     if (balMbo == null) {
/* 500:578 */       return false;
/* 501:    */     }
/* 502:582 */     mgrDBMgr = new MobileMboDataBeanManager("ITEM");
/* 503:583 */     MobileMboDataBean itemBean = mgrDBMgr.getDataBean();
/* 504:584 */     itemBean.getQBE().setQBE("ITEMNUM", databean.getValue("ITEMNUM"));
/* 505:585 */     itemBean.getQBE().setQBE("ITEMSETID", databean.getValue("ITEMSETID"));
/* 506:    */     
/* 507:    */ 
/* 508:588 */     itemBean.getQBE().setQBE("ITEMTYPE", ((WOApp)UIUtil.getApplication()).getExternalValue(itemBean, "ITEMTYPE", "TOOL"));
/* 509:589 */     if ((itemBean.getMobileMbo(0) != null) && (databean.getValue("ISSUETO").equals(""))) {
/* 510:590 */       return false;
/* 511:    */     }
/* 512:592 */     return true;
/* 513:    */   }
/* 514:    */   
/* 515:    */   protected void setDefaultQuantity(MobileMboDataBean databean)
/* 516:    */     throws MobileApplicationException
/* 517:    */   {
/* 518:604 */     for (int i = 0; i < databean.count(); i++) {
/* 519:607 */       databean.setValue(i, "QTY", databean.getValue(i, "RESERVEDQTY"));
/* 520:    */     }
/* 521:    */   }
/* 522:    */   
/* 523:    */   public boolean luconnect(UIEvent event)
/* 524:    */     throws MobileApplicationException
/* 525:    */   {
/* 526:620 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/* 527:    */     
/* 528:622 */     databean.setOnline(!databean.isOnline());
/* 529:623 */     databean.reset();
/* 530:    */     
/* 531:625 */     setDefaultQuantity(databean);
/* 532:    */     
/* 533:627 */     UIUtil.refreshScreen(UIUtil.getCurrentScreen(), event);
/* 534:    */     
/* 535:629 */     return true;
/* 536:    */   }
/* 537:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.mobilewo.SelectPlannedMaterialEventHandler
 * JD-Core Version:    0.7.0.1
 */