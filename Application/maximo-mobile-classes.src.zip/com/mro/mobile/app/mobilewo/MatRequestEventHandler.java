/*   1:    */ package com.mro.mobile.app.mobilewo;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.MobileMessageGenerator;
/*   5:    */ import com.mro.mobile.mbo.MobileMbo;
/*   6:    */ import com.mro.mobile.mbo.MobileMboQBE;
/*   7:    */ import com.mro.mobile.ui.AutoKeyGenerator;
/*   8:    */ import com.mro.mobile.ui.DataBeanCache;
/*   9:    */ import com.mro.mobile.ui.DataBeanCacheItem;
/*  10:    */ import com.mro.mobile.ui.MobileMboDataBean;
/*  11:    */ import com.mro.mobile.ui.MobileMboDataBeanManager;
/*  12:    */ import com.mro.mobile.ui.event.UIEvent;
/*  13:    */ import com.mro.mobile.ui.res.UIUtil;
/*  14:    */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*  15:    */ import com.mro.mobile.ui.res.controls.LookupControl;
/*  16:    */ import com.mro.mobile.ui.res.controls.PageControl;
/*  17:    */ import com.mro.mobile.ui.res.controls.TextboxControl;
/*  18:    */ import com.mro.mobileapp.WOApp;
/*  19:    */ import java.util.Date;
/*  20:    */ import java.util.List;
/*  21:    */ 
/*  22:    */ public class MatRequestEventHandler
/*  23:    */   extends MobileWOCommonEventHandler
/*  24:    */ {
/*  25:    */   public boolean performEvent(UIEvent event)
/*  26:    */     throws MobileApplicationException
/*  27:    */   {
/*  28: 46 */     if (event == null) {
/*  29: 46 */       return false;
/*  30:    */     }
/*  31: 48 */     String eventId = event.getEventName();
/*  32: 50 */     if (eventId.equalsIgnoreCase("initpage")) {
/*  33: 52 */       return initpage(event);
/*  34:    */     }
/*  35: 54 */     if (eventId.equalsIgnoreCase("filtermrlinetype")) {
/*  36: 56 */       return filtermrlinetype(event);
/*  37:    */     }
/*  38: 58 */     if (eventId.equalsIgnoreCase("mrlinetypechanged")) {
/*  39: 60 */       return mrlinetypechanged(event);
/*  40:    */     }
/*  41: 62 */     if (eventId.equalsIgnoreCase("validatestoreloc")) {
/*  42: 64 */       return validatestoreloc(event);
/*  43:    */     }
/*  44: 66 */     if (eventId.equalsIgnoreCase("validatevendor")) {
/*  45: 68 */       return validatevendor(event);
/*  46:    */     }
/*  47: 70 */     if (eventId.equalsIgnoreCase("validatecatalogcode")) {
/*  48: 72 */       return validatecatalogcode(event);
/*  49:    */     }
/*  50: 74 */     if (eventId.equalsIgnoreCase("validatemodelnum")) {
/*  51: 76 */       return validatemodelnum(event);
/*  52:    */     }
/*  53: 78 */     if (eventId.equalsIgnoreCase("validatemanufacturer")) {
/*  54: 80 */       return validatemanufacturer(event);
/*  55:    */     }
/*  56: 82 */     if (eventId.equalsIgnoreCase("validateitemnum")) {
/*  57: 84 */       return validateitemnum(event);
/*  58:    */     }
/*  59: 86 */     if (eventId.equalsIgnoreCase("validatetool")) {
/*  60: 88 */       return validatetool(event);
/*  61:    */     }
/*  62: 90 */     if (eventId.equalsIgnoreCase("validateservice")) {
/*  63: 92 */       return validateservice(event);
/*  64:    */     }
/*  65: 94 */     if (eventId.equalsIgnoreCase("canselectspareparts")) {
/*  66: 96 */       return canselectspareparts(event);
/*  67:    */     }
/*  68: 98 */     if (eventId.equalsIgnoreCase("candoitemavailability")) {
/*  69:100 */       return candoitemavailability(event);
/*  70:    */     }
/*  71:102 */     if (eventId.equalsIgnoreCase("lookupitemfield")) {
/*  72:104 */       return lookupitemfield(event);
/*  73:    */     }
/*  74:106 */     if (eventId.equalsIgnoreCase("displayitemfield")) {
/*  75:108 */       return displayitemfield(event);
/*  76:    */     }
/*  77:110 */     if (eventId.equalsIgnoreCase("displaytoolfield")) {
/*  78:112 */       return displaytoolfield(event);
/*  79:    */     }
/*  80:114 */     if (eventId.equalsIgnoreCase("displaystdservicefield")) {
/*  81:116 */       return displaystdservicefield(event);
/*  82:    */     }
/*  83:118 */     if (eventId.equalsIgnoreCase("displaydescfield")) {
/*  84:120 */       return displaydescfield(event);
/*  85:    */     }
/*  86:122 */     if (eventId.equalsIgnoreCase("initassetspareparts")) {
/*  87:124 */       return initassetspareparts(event);
/*  88:    */     }
/*  89:126 */     if (eventId.equalsIgnoreCase("selectsparepart")) {
/*  90:128 */       return selectsparepart(event);
/*  91:    */     }
/*  92:130 */     if (eventId.equalsIgnoreCase("validatrequireddate")) {
/*  93:132 */       return validatrequireddate(event);
/*  94:    */     }
/*  95:138 */     if (eventId.equalsIgnoreCase("lookup")) {
/*  96:140 */       return lookup(event);
/*  97:    */     }
/*  98:142 */     if (eventId.equalsIgnoreCase("updateRequireDateStatus")) {
/*  99:144 */       return updateRequireDateStatus(event);
/* 100:    */     }
/* 101:147 */     super.performEvent(event);
/* 102:    */     
/* 103:149 */     return false;
/* 104:    */   }
/* 105:    */   
/* 106:    */   public boolean updateRequireDateStatus(UIEvent event)
/* 107:    */     throws MobileApplicationException
/* 108:    */   {
/* 109:154 */     MobileMboDataBean mrlinedatabean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/* 110:    */     
/* 111:156 */     String externalRestype = (String)event.getValue();
/* 112:157 */     String restype = ((WOApp)UIUtil.getApplication()).getDefaultValue(mrlinedatabean, "DISPLAYRESTYPE", externalRestype);
/* 113:    */     
/* 114:159 */     boolean requireDateRequired = false;
/* 115:160 */     if ("AUTOMATIC".equalsIgnoreCase(restype)) {
/* 116:162 */       requireDateRequired = true;
/* 117:    */     }
/* 118:165 */     MobileMbo mboMR = mrlinedatabean.getOwner();
/* 119:166 */     mboMR.setRequired("REQUIREDDATE", requireDateRequired);
/* 120:    */     
/* 121:168 */     return true;
/* 122:    */   }
/* 123:    */   
/* 124:    */   public boolean initpage(UIEvent event)
/* 125:    */     throws MobileApplicationException
/* 126:    */   {
/* 127:173 */     MobileMboDataBean mrdatabean = ((PageControl)event.getCreatingObject()).getDataBean();
/* 128:174 */     mrdatabean.insert();
/* 129:175 */     MobileMboDataBean mrlinedatabean = mrdatabean.getDataBean("MRLINE");
/* 130:176 */     mrlinedatabean.insert();
/* 131:    */     
/* 132:178 */     DataBeanCache.cacheDataBean("MRLINE", new DataBeanCacheItem("MRLINE", "MR", "MRLINE", mrlinedatabean));
/* 133:    */     
/* 134:180 */     MobileMboDataBean wodatabean = ((PageControl)event.getCreatingObject()).getLaunchingControl().getDataBean();
/* 135:    */     
/* 136:    */ 
/* 137:183 */     mrdatabean.setValue("MRNUM", AutoKeyGenerator.generateKey("MR", "MRNUM"));
/* 138:184 */     Object[] param = { wodatabean.getValue("WONUM") };
/* 139:185 */     mrdatabean.setValue("DESCRIPTION", MobileMessageGenerator.generate("mrdescription", param));
/* 140:186 */     mrdatabean.getMobileMbo().setDateValue("REQUIREDDATE", mrdatabean.getCurrentTime());
/* 141:    */     
/* 142:188 */     mrdatabean.setValue("WONUM", wodatabean.getValue("WONUM"));
/* 143:189 */     mrdatabean.setValue("ASSETNUM", wodatabean.getValue("ASSETNUM"));
/* 144:190 */     mrdatabean.setValue("LOCATION", wodatabean.getValue("LOCATION"));
/* 145:    */     
/* 146:192 */     Date createDate = ((WOApp)UIUtil.getApplication()).getCurrentTime();
/* 147:193 */     mrdatabean.getMobileMbo().setDateValue("CREATEDATE", createDate);
/* 148:    */     
/* 149:195 */     mrlinedatabean.setValue("QTY", "1");
/* 150:196 */     mrlinedatabean.setValue("LINETYPE", ((WOApp)UIUtil.getApplication()).getDefaultValue(mrdatabean, "MRLINETYPE", "ITEM"));
/* 151:    */     
/* 152:198 */     mrlinedatabean.setValue("CONVERSION", "1");
/* 153:    */     
/* 154:200 */     String defaultRestype = ((WOApp)UIUtil.getApplication()).getExternalValue(mrdatabean, "DISPLAYRESTYPE", "AUTOMATIC");
/* 155:201 */     mrlinedatabean.setValue("RESTYPE", defaultRestype);
/* 156:    */     
/* 157:203 */     mrdatabean.getMobileMbo().setRequired("REQUIREDDATE", true);
/* 158:    */     
/* 159:205 */     mrlinetypechanged(event, true, mrlinedatabean.getValue("LINETYPE"));
/* 160:    */     
/* 161:207 */     UIUtil.refreshCurrentScreen();
/* 162:    */     
/* 163:209 */     return true;
/* 164:    */   }
/* 165:    */   
/* 166:    */   public boolean filtermrlinetype(UIEvent event)
/* 167:    */     throws MobileApplicationException
/* 168:    */   {
/* 169:214 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/* 170:215 */     if (databean != null)
/* 171:    */     {
/* 172:217 */       String allowsporder = ((WOApp)UIUtil.getApplication()).getMaxVar(databean, "ALLOWSPORDER");
/* 173:218 */       if (!allowsporder.equals("1"))
/* 174:    */       {
/* 175:220 */         MobileMboDataBean dropdownbean = (MobileMboDataBean)event.getValue();
/* 176:221 */         if (databean != null)
/* 177:    */         {
/* 178:223 */           dropdownbean.getQBE().setQbeExactMatch(true);
/* 179:224 */           dropdownbean.getQBE().setQBE("MAXVALUE", "!=SPORDER");
/* 180:225 */           dropdownbean.reset();
/* 181:    */         }
/* 182:    */       }
/* 183:    */     }
/* 184:229 */     return false;
/* 185:    */   }
/* 186:    */   
/* 187:    */   public boolean mrlinetypechanged(UIEvent event)
/* 188:    */     throws MobileApplicationException
/* 189:    */   {
/* 190:234 */     return mrlinetypechanged(event, false, (String)event.getValue());
/* 191:    */   }
/* 192:    */   
/* 193:    */   public boolean mrlinetypechanged(UIEvent event, boolean frominit, String lineType)
/* 194:    */     throws MobileApplicationException
/* 195:    */   {
/* 196:239 */     MobileMboDataBean databean = DataBeanCache.findDataBean("MRLINE");
/* 197:    */     
/* 198:241 */     databean.getMobileMbo().setReadOnly("CONVERSION", false);
/* 199:242 */     databean.setValue("CONVERSION", "1");
/* 200:244 */     if (!frominit)
/* 201:    */     {
/* 202:247 */       databean.setValue("ITEM", "");
/* 203:248 */       databean.setValue("TOOL", "");
/* 204:249 */       databean.setValue("SERVICE", "");
/* 205:250 */       databean.setValue("DESCRIPTION", "");
/* 206:251 */       databean.setValue("MANUFACTURER", "");
/* 207:252 */       databean.setValue("MODELNUM", "");
/* 208:253 */       databean.setValue("CATALOGCODE", "");
/* 209:254 */       databean.setValue("ORDERUNIT", "");
/* 210:255 */       databean.setValue("VENDOR", "");
/* 211:256 */       databean.setValue("STORELOC", "");
/* 212:    */     }
/* 213:259 */     String internalLineType = ((WOApp)UIUtil.getApplication()).getInternalValue(databean, "MRLINETYPE", lineType);
/* 214:262 */     if ((internalLineType.equalsIgnoreCase("SERVICE")) || (internalLineType.equalsIgnoreCase("STDSERVICE")))
/* 215:    */     {
/* 216:264 */       setDirectReq(databean, true);
/* 217:    */       
/* 218:266 */       databean.getMobileMbo().setReadOnly("ORDERUNIT", true);
/* 219:267 */       databean.getMobileMbo().setReadOnly("MODELNUM", true);
/* 220:268 */       databean.getMobileMbo().setReadOnly("MANUFACTURER", true);
/* 221:269 */       databean.getMobileMbo().setReadOnly("STORELOC", true);
/* 222:    */       
/* 223:271 */       databean.getMobileMbo().setRequired("CONVERSION", false);
/* 224:272 */       databean.getMobileMbo().setReadOnly("CONVERSION", true);
/* 225:274 */       if (internalLineType.equalsIgnoreCase("SERVICE"))
/* 226:    */       {
/* 227:276 */         databean.getMobileMbo().setRequired("ITEM", false);
/* 228:277 */         databean.getMobileMbo().setRequired("TOOL", false);
/* 229:278 */         databean.getMobileMbo().setRequired("SERVICE", false);
/* 230:279 */         databean.getMobileMbo().setRequired("DESCRIPTION", true);
/* 231:    */       }
/* 232:281 */       else if (internalLineType.equalsIgnoreCase("STDSERVICE"))
/* 233:    */       {
/* 234:283 */         databean.getMobileMbo().setRequired("ITEM", false);
/* 235:284 */         databean.getMobileMbo().setRequired("TOOL", false);
/* 236:285 */         databean.getMobileMbo().setRequired("SERVICE", true);
/* 237:286 */         databean.getMobileMbo().setRequired("DESCRIPTION", false);
/* 238:    */       }
/* 239:    */     }
/* 240:289 */     else if (internalLineType.equalsIgnoreCase("ITEM"))
/* 241:    */     {
/* 242:291 */       setDirectReq(databean, false);
/* 243:    */       
/* 244:293 */       databean.getMobileMbo().setReadOnly("ORDERUNIT", false);
/* 245:294 */       databean.getMobileMbo().setReadOnly("MODELNUM", false);
/* 246:295 */       databean.getMobileMbo().setReadOnly("MANUFACTURER", false);
/* 247:296 */       databean.getMobileMbo().setReadOnly("STORELOC", false);
/* 248:297 */       databean.getMobileMbo().setRequired("ITEM", true);
/* 249:298 */       databean.getMobileMbo().setRequired("TOOL", false);
/* 250:299 */       databean.getMobileMbo().setRequired("SERVICE", false);
/* 251:300 */       databean.getMobileMbo().setRequired("DESCRIPTION", false);
/* 252:    */       
/* 253:302 */       databean.getMobileMbo().setRequired("CONVERSION", true);
/* 254:303 */       databean.getMobileMbo().setReadOnly("CONVERSION", false);
/* 255:    */     }
/* 256:305 */     else if (internalLineType.equalsIgnoreCase("TOOL"))
/* 257:    */     {
/* 258:307 */       setDirectReq(databean, false);
/* 259:    */       
/* 260:309 */       databean.getMobileMbo().setReadOnly("ORDERUNIT", false);
/* 261:310 */       databean.getMobileMbo().setReadOnly("MODELNUM", false);
/* 262:311 */       databean.getMobileMbo().setReadOnly("MANUFACTURER", false);
/* 263:312 */       databean.getMobileMbo().setReadOnly("STORELOC", false);
/* 264:313 */       databean.getMobileMbo().setRequired("ITEM", false);
/* 265:314 */       databean.getMobileMbo().setRequired("TOOL", true);
/* 266:315 */       databean.getMobileMbo().setRequired("SERVICE", false);
/* 267:316 */       databean.getMobileMbo().setRequired("DESCRIPTION", false);
/* 268:    */       
/* 269:318 */       databean.getMobileMbo().setRequired("CONVERSION", true);
/* 270:319 */       databean.getMobileMbo().setReadOnly("CONVERSION", false);
/* 271:    */     }
/* 272:321 */     else if ((internalLineType.equalsIgnoreCase("MATERIAL")) || (internalLineType.equalsIgnoreCase("EXTERNAL")))
/* 273:    */     {
/* 274:323 */       setDirectReq(databean, true);
/* 275:    */       
/* 276:325 */       databean.getMobileMbo().setRequired("ITEM", false);
/* 277:326 */       databean.getMobileMbo().setRequired("TOOL", false);
/* 278:327 */       databean.getMobileMbo().setRequired("SERVICE", false);
/* 279:328 */       databean.getMobileMbo().setRequired("DESCRIPTION", true);
/* 280:    */       
/* 281:330 */       databean.getMobileMbo().setReadOnly("ORDERUNIT", false);
/* 282:331 */       databean.getMobileMbo().setReadOnly("MODELNUM", false);
/* 283:332 */       databean.getMobileMbo().setReadOnly("MANUFACTURER", false);
/* 284:333 */       databean.getMobileMbo().setReadOnly("STORELOC", false);
/* 285:    */       
/* 286:335 */       databean.getMobileMbo().setRequired("CONVERSION", false);
/* 287:336 */       databean.getMobileMbo().setReadOnly("CONVERSION", true);
/* 288:    */     }
/* 289:338 */     else if (internalLineType.equalsIgnoreCase("SPORDER"))
/* 290:    */     {
/* 291:340 */       setDirectReq(databean, true);
/* 292:    */       
/* 293:342 */       databean.getMobileMbo().setReadOnly("ORDERUNIT", false);
/* 294:343 */       databean.getMobileMbo().setReadOnly("STORELOC", false);
/* 295:    */       
/* 296:345 */       databean.getMobileMbo().setRequired("ITEM", false);
/* 297:346 */       databean.getMobileMbo().setRequired("TOOL", false);
/* 298:347 */       databean.getMobileMbo().setRequired("SERVICE", false);
/* 299:348 */       databean.getMobileMbo().setRequired("DESCRIPTION", false);
/* 300:    */       
/* 301:350 */       databean.getMobileMbo().setRequired("CONVERSION", false);
/* 302:351 */       databean.getMobileMbo().setReadOnly("CONVERSION", true);
/* 303:    */     }
/* 304:354 */     UIUtil.refreshCurrentScreen();
/* 305:    */     
/* 306:356 */     return false;
/* 307:    */   }
/* 308:    */   
/* 309:    */   private void setDirectReq(MobileMboDataBean databean, boolean diretreq)
/* 310:    */     throws MobileApplicationException
/* 311:    */   {
/* 312:361 */     if (diretreq)
/* 313:    */     {
/* 314:364 */       databean.getMobileMbo().setRequired("VENDOR", false);
/* 315:365 */       databean.getMobileMbo().setRequired("CATALOGCODE", false);
/* 316:366 */       databean.getMobileMbo().setRequired("MANUFACTURER", false);
/* 317:367 */       databean.getMobileMbo().setRequired("MODELNUM", false);
/* 318:368 */       databean.getMobileMbo().setRequired("STORELOC", false);
/* 319:369 */       databean.getMobileMbo().setRequired("ORDERUNIT", false);
/* 320:370 */       databean.getMobileMbo().setReadOnly("VENDOR", false);
/* 321:371 */       databean.getMobileMbo().setReadOnly("CATALOGCODE", false);
/* 322:372 */       databean.getMobileMbo().setReadOnly("MANUFACTURER", false);
/* 323:373 */       databean.getMobileMbo().setReadOnly("MODELNUM", false);
/* 324:374 */       databean.getMobileMbo().setReadOnly("STORELOC", false);
/* 325:375 */       databean.getMobileMbo().setReadOnly("ORDERUNIT", false);
/* 326:    */     }
/* 327:    */     else
/* 328:    */     {
/* 329:379 */       databean.getMobileMbo().setRequired("ORDERUNIT", true);
/* 330:    */     }
/* 331:    */   }
/* 332:    */   
/* 333:    */   public boolean validatestoreloc(UIEvent event)
/* 334:    */     throws MobileApplicationException
/* 335:    */   {
/* 336:394 */     if (event.getMsgResponse() == "0")
/* 337:    */     {
/* 338:396 */       event.setEventErrored();
/* 339:397 */       return true;
/* 340:    */     }
/* 341:400 */     boolean fromLookUp = false;
/* 342:402 */     if ((UIUtil.getCurrentScreen() instanceof LookupControl)) {
/* 343:403 */       fromLookUp = true;
/* 344:    */     }
/* 345:405 */     MobileMboDataBean databean = DataBeanCache.findDataBean("MRLINE");
/* 346:407 */     if ((event.getValue() == null) || (((String)event.getValue()).equals("")))
/* 347:    */     {
/* 348:409 */       databean.setValue("STORELOCSITE", "");
/* 349:410 */       return true;
/* 350:    */     }
/* 351:413 */     if (!fromLookUp)
/* 352:    */     {
/* 353:416 */       String siteid = databean.getValue("SITEID");
/* 354:417 */       String itemnum = databean.getValue("ITEM");
/* 355:418 */       String storeroom = (String)event.getValue();
/* 356:422 */       if ((event.getMsgResponse() == "-1") && (!isItemAvailableinStoreroom(siteid, itemnum, storeroom, false)))
/* 357:    */       {
/* 358:424 */         Object[] params = new Object[2];
/* 359:425 */         params[0] = itemnum;
/* 360:426 */         params[1] = storeroom;
/* 361:427 */         UIUtil.showMessageBox("nolocalinvinfoavailable", params, "warning", 12, event);
/* 362:428 */         event.setEventErrored();
/* 363:429 */         return true;
/* 364:    */       }
/* 365:433 */       WOApp.setStoreLocSiteForStoreroom(databean, (String)event.getValue(), "STORELOCSITE");
/* 366:    */     }
/* 367:436 */     databean.setValue("VENDOR", "");
/* 368:    */     
/* 369:438 */     return true;
/* 370:    */   }
/* 371:    */   
/* 372:    */   private boolean isItemAvailableinStoreroom(String siteid, String item, String storeroom, boolean isOnline)
/* 373:    */     throws MobileApplicationException
/* 374:    */   {
/* 375:448 */     MobileMboDataBeanManager inventoryMgr = new MobileMboDataBeanManager("INVENTORY");
/* 376:449 */     MobileMboDataBean inventoryDataBean = inventoryMgr.getDataBean();
/* 377:451 */     if (inventoryDataBean != null) {
/* 378:452 */       inventoryDataBean.setOnline(isOnline);
/* 379:    */     }
/* 380:455 */     inventoryDataBean.getQBE().setQbeExactMatch(true);
/* 381:456 */     if (!"".equals(item)) {
/* 382:457 */       inventoryDataBean.getQBE().setQBE("ITEMNUM", "=" + item);
/* 383:    */     }
/* 384:459 */     if (siteid != null) {
/* 385:460 */       inventoryDataBean.getQBE().setQBE("SITEID", "=" + siteid);
/* 386:    */     }
/* 387:462 */     inventoryDataBean.getQBE().setQBE("LOCATION", "=" + storeroom);
/* 388:463 */     inventoryDataBean.reset();
/* 389:464 */     if (inventoryDataBean.count() == 1) {
/* 390:465 */       return true;
/* 391:    */     }
/* 392:467 */     return false;
/* 393:    */   }
/* 394:    */   
/* 395:    */   public boolean validatevendor(UIEvent event)
/* 396:    */     throws MobileApplicationException
/* 397:    */   {
/* 398:475 */     if ((event.getValue() == null) || (((String)event.getValue()).equals(""))) {
/* 399:477 */       return true;
/* 400:    */     }
/* 401:480 */     MobileMboDataBean databean = DataBeanCache.findDataBean("MRLINE");
/* 402:481 */     databean.setValue("STORELOC", "");
/* 403:482 */     databean.setValue("STORELOCSITE", "");
/* 404:    */     
/* 405:484 */     return true;
/* 406:    */   }
/* 407:    */   
/* 408:    */   public boolean validatecatalogcode(UIEvent event)
/* 409:    */     throws MobileApplicationException
/* 410:    */   {
/* 411:489 */     return true;
/* 412:    */   }
/* 413:    */   
/* 414:    */   public boolean validatemodelnum(UIEvent event)
/* 415:    */     throws MobileApplicationException
/* 416:    */   {
/* 417:494 */     return true;
/* 418:    */   }
/* 419:    */   
/* 420:    */   public boolean validatemanufacturer(UIEvent event)
/* 421:    */     throws MobileApplicationException
/* 422:    */   {
/* 423:499 */     return true;
/* 424:    */   }
/* 425:    */   
/* 426:    */   public boolean validateitemnum(UIEvent event)
/* 427:    */     throws MobileApplicationException
/* 428:    */   {
/* 429:504 */     return validateItemOrTool(event, "ITEM");
/* 430:    */   }
/* 431:    */   
/* 432:    */   public boolean validatetool(UIEvent event)
/* 433:    */     throws MobileApplicationException
/* 434:    */   {
/* 435:509 */     return validateItemOrTool(event, "TOOL");
/* 436:    */   }
/* 437:    */   
/* 438:    */   public boolean validateItemOrTool(UIEvent event, String dataset)
/* 439:    */     throws MobileApplicationException
/* 440:    */   {
/* 441:514 */     boolean fromLookUp = false;
/* 442:515 */     boolean fromConnectedLookUp = false;
/* 443:517 */     if ((UIUtil.getCurrentScreen() instanceof LookupControl)) {
/* 444:518 */       fromLookUp = true;
/* 445:    */     }
/* 446:520 */     if (fromLookUp) {
/* 447:522 */       fromConnectedLookUp = UIUtil.getCurrentScreen().getDataBean().isOnline();
/* 448:    */     }
/* 449:526 */     MobileMboDataBean databean = DataBeanCache.findDataBean("MRLINE");
/* 450:528 */     if ((event.getValue() == null) || (((String)event.getValue()).equals("")))
/* 451:    */     {
/* 452:530 */       databean.setValue("ITEMSETID", "");
/* 453:531 */       databean.getMobileMbo().setReadOnly("STORELOC", false);
/* 454:532 */       return true;
/* 455:    */     }
/* 456:535 */     String internalLineType = getInternalLineType(databean);
/* 457:537 */     if (internalLineType.equals("SPORDER")) {
/* 458:538 */       return true;
/* 459:    */     }
/* 460:541 */     MobileMbo itemMbo = null;
/* 461:542 */     if ((fromLookUp) && (!fromConnectedLookUp))
/* 462:    */     {
/* 463:544 */       MobileMboDataBean itemdatabean = UIUtil.getCurrentScreen().getDataBean();
/* 464:545 */       itemMbo = itemdatabean.getMobileMbo(0);
/* 465:    */     }
/* 466:    */     else
/* 467:    */     {
/* 468:551 */       itemMbo = WOApp.setItemSetForItem(databean, dataset, (String)event.getValue(), "ITEMSETID");
/* 469:    */     }
/* 470:555 */     databean.getMobileMbo().setReadOnly("STORELOC", false);
/* 471:556 */     databean.setValue("STORELOC", "");
/* 472:558 */     if (itemMbo == null) {
/* 473:559 */       return true;
/* 474:    */     }
/* 475:561 */     databean.setValue("ORDERUNIT", itemMbo.getValue("ORDERUNIT"));
/* 476:    */     
/* 477:    */ 
/* 478:564 */     findAndSetStoreLoc(databean, (String)event.getValue());
/* 479:567 */     if (!databean.getValue("STORELOC").equals(""))
/* 480:    */     {
/* 481:569 */       MobileMboDataBean invBean = getInventoryDataBean();
/* 482:    */       
/* 483:571 */       invBean.getQBE().reset();
/* 484:572 */       invBean.getQBE().setQbeExactMatch(true);
/* 485:573 */       invBean.getQBE().setQBE("ITEMNUM", (String)event.getValue());
/* 486:574 */       invBean.getQBE().setQBE("SITEID", databean.getValue("SITEID"));
/* 487:575 */       invBean.getQBE().setQBE("LOCATION", databean.getValue("STORELOC"));
/* 488:576 */       invBean.reset();
/* 489:577 */       if (invBean.getMobileMbo(0) != null)
/* 490:    */       {
/* 491:579 */         databean.setValue("MANUFACTURER", invBean.getMobileMbo(0).getValue("MANUFACTURER"));
/* 492:580 */         databean.setValue("CATALOGCODE", invBean.getMobileMbo(0).getValue("CATALOGCODE"));
/* 493:581 */         databean.setValue("MODELNUM", invBean.getMobileMbo(0).getValue("MODELNUM"));
/* 494:582 */         databean.setValue("ORDERUNIT", invBean.getMobileMbo(0).getValue("ORDERUNIT"));
/* 495:    */       }
/* 496:    */     }
/* 497:    */     else
/* 498:    */     {
/* 499:587 */       databean.getMobileMbo().setReadOnly("STORELOC", true);
/* 500:    */     }
/* 501:590 */     return true;
/* 502:    */   }
/* 503:    */   
/* 504:    */   protected MobileMboDataBean getInventoryDataBean()
/* 505:    */     throws MobileApplicationException
/* 506:    */   {
/* 507:596 */     MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager("INVENTORY");
/* 508:597 */     MobileMboDataBean invBean = mgrDBMgr.getDataBean();
/* 509:598 */     return invBean;
/* 510:    */   }
/* 511:    */   
/* 512:    */   protected String getInternalLineType(MobileMboDataBean databean)
/* 513:    */     throws MobileApplicationException
/* 514:    */   {
/* 515:604 */     return ((WOApp)UIUtil.getApplication()).getInternalValue(databean, "MRLINETYPE", databean.getValue("LINETYPE"));
/* 516:    */   }
/* 517:    */   
/* 518:    */   protected boolean findAndSetStoreLoc(MobileMboDataBean mrline, String itemnum)
/* 519:    */     throws MobileApplicationException
/* 520:    */   {
/* 521:609 */     String defStore = WOApp.getDefStoreroom();
/* 522:610 */     String defStoreSite = WOApp.getStoreroomSite();
/* 523:612 */     if ((defStore != null) && (!defStore.equals(""))) {
/* 524:615 */       if (existStockedAndSet(mrline, itemnum, defStore, defStoreSite)) {
/* 525:617 */         return true;
/* 526:    */       }
/* 527:    */     }
/* 528:622 */     MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager("STOREROOMS");
/* 529:623 */     MobileMboDataBean srBean = mgrDBMgr.getDataBean();
/* 530:    */     
/* 531:625 */     srBean.getQBE().reset();
/* 532:    */     
/* 533:    */ 
/* 534:    */ 
/* 535:629 */     srBean.reset();
/* 536:630 */     int count = srBean.count();
/* 537:631 */     for (int i = 0; i < count; i++)
/* 538:    */     {
/* 539:633 */       MobileMbo srMbo = srBean.getMobileMbo(i);
/* 540:636 */       if (existStockedAndSet(mrline, itemnum, srMbo.getValue("LOCATION"), srMbo.getValue("SITEID"))) {
/* 541:638 */         return true;
/* 542:    */       }
/* 543:    */     }
/* 544:642 */     return false;
/* 545:    */   }
/* 546:    */   
/* 547:    */   private boolean existStockedAndSet(MobileMboDataBean mrline, String itemnum, String storeroom, String siteId)
/* 548:    */     throws MobileApplicationException
/* 549:    */   {
/* 550:648 */     MobileMboDataBean invBean = getInventoryDataBean();
/* 551:    */     
/* 552:650 */     invBean.getQBE().reset();
/* 553:651 */     invBean.getQBE().setQbeExactMatch(true);
/* 554:652 */     invBean.getQBE().setQBE("ITEMNUM", itemnum);
/* 555:653 */     invBean.getQBE().setQBE("LOCATION", storeroom);
/* 556:654 */     invBean.getQBE().setQBE("SITEID", siteId);
/* 557:655 */     invBean.reset();
/* 558:656 */     if (invBean.getMobileMbo(0) == null) {
/* 559:657 */       return false;
/* 560:    */     }
/* 561:661 */     String internalCategory = ((WOApp)UIUtil.getApplication()).getInternalValue(invBean, "CATEGORY", invBean.getMobileMbo(0).getValue("CATEGORY"));
/* 562:665 */     if (internalCategory.equalsIgnoreCase("STK"))
/* 563:    */     {
/* 564:668 */       mrline.setValue("STORELOCSITE", siteId);
/* 565:669 */       mrline.setValue("STORELOC", storeroom);
/* 566:670 */       return true;
/* 567:    */     }
/* 568:673 */     return false;
/* 569:    */   }
/* 570:    */   
/* 571:    */   public boolean validateservice(UIEvent event)
/* 572:    */     throws MobileApplicationException
/* 573:    */   {
/* 574:678 */     return true;
/* 575:    */   }
/* 576:    */   
/* 577:    */   public boolean canselectspareparts(UIEvent event)
/* 578:    */     throws MobileApplicationException
/* 579:    */   {
/* 580:698 */     MobileMboDataBean databean = DataBeanCache.findDataBean("MRLINE");
/* 581:699 */     MobileMboDataBean wodatabean = DataBeanCache.findDataBean("WORKORDER");
/* 582:    */     
/* 583:701 */     String internalLineType = getInternalLineType(databean);
/* 584:    */     
/* 585:    */ 
/* 586:704 */     boolean bShow = false;
/* 587:705 */     if ((internalLineType.equals("ITEM")) && (!wodatabean.getValue("ASSETNUM").equals(""))) {
/* 588:706 */       bShow = true;
/* 589:    */     }
/* 590:708 */     ((AbstractMobileControl)event.getCreatingObject()).setVisibility(bShow);
/* 591:    */     
/* 592:710 */     return true;
/* 593:    */   }
/* 594:    */   
/* 595:    */   public boolean candoitemavailability(UIEvent event)
/* 596:    */     throws MobileApplicationException
/* 597:    */   {
/* 598:715 */     MobileMboDataBean databean = DataBeanCache.findDataBean("MRLINE");
/* 599:    */     
/* 600:717 */     String internalLineType = getInternalLineType(databean);
/* 601:    */     
/* 602:    */ 
/* 603:720 */     boolean bShow = false;
/* 604:721 */     if ((internalLineType.equals("ITEM")) && (!databean.getValue("ITEM").equals(""))) {
/* 605:722 */       bShow = true;
/* 606:723 */     } else if ((internalLineType.equals("TOOL")) && (!databean.getValue("TOOL").equals(""))) {
/* 607:724 */       bShow = true;
/* 608:    */     }
/* 609:726 */     ((AbstractMobileControl)event.getCreatingObject()).setVisibility(bShow);
/* 610:    */     
/* 611:728 */     return true;
/* 612:    */   }
/* 613:    */   
/* 614:    */   public boolean lookupitemfield(UIEvent event)
/* 615:    */     throws MobileApplicationException
/* 616:    */   {
/* 617:733 */     MobileMboDataBean databean = DataBeanCache.findDataBean("MRLINE");
/* 618:    */     
/* 619:735 */     String internalLineType = getInternalLineType(databean);
/* 620:    */     
/* 621:    */ 
/* 622:738 */     String page = "";
/* 623:741 */     if (internalLineType.equalsIgnoreCase("ITEM"))
/* 624:    */     {
/* 625:743 */       page = "itemlookup";
/* 626:744 */       lookup(event);
/* 627:    */     }
/* 628:746 */     else if (internalLineType.equalsIgnoreCase("TOOL"))
/* 629:    */     {
/* 630:747 */       page = "toollookup";
/* 631:    */     }
/* 632:748 */     else if (internalLineType.equalsIgnoreCase("STDSERVICE"))
/* 633:    */     {
/* 634:749 */       page = "stdservicelookup";
/* 635:    */     }
/* 636:751 */     if (!page.equals("")) {
/* 637:752 */       UIUtil.gotoPageNoSave(page, ((AbstractMobileControl)event.getCreatingObject()).getParentControl().getParentControl().getParentControl());
/* 638:    */     }
/* 639:755 */     return true;
/* 640:    */   }
/* 641:    */   
/* 642:    */   public boolean details(UIEvent event)
/* 643:    */     throws MobileApplicationException
/* 644:    */   {
/* 645:766 */     return true;
/* 646:    */   }
/* 647:    */   
/* 648:    */   public boolean displayitemfield(UIEvent event)
/* 649:    */     throws MobileApplicationException
/* 650:    */   {
/* 651:771 */     MobileMboDataBean databean = DataBeanCache.findDataBean("MRLINE");
/* 652:772 */     if (databean == null) {
/* 653:773 */       return true;
/* 654:    */     }
/* 655:775 */     String internalLineType = getInternalLineType(databean);
/* 656:    */     
/* 657:    */ 
/* 658:778 */     boolean bShow = false;
/* 659:779 */     if (internalLineType.equals("ITEM")) {
/* 660:780 */       bShow = true;
/* 661:    */     }
/* 662:782 */     ((AbstractMobileControl)event.getCreatingObject()).setVisibility(bShow);
/* 663:    */     
/* 664:784 */     return true;
/* 665:    */   }
/* 666:    */   
/* 667:    */   public boolean displaytoolfield(UIEvent event)
/* 668:    */     throws MobileApplicationException
/* 669:    */   {
/* 670:789 */     MobileMboDataBean databean = DataBeanCache.findDataBean("MRLINE");
/* 671:790 */     if (databean == null) {
/* 672:791 */       return true;
/* 673:    */     }
/* 674:793 */     String internalLineType = getInternalLineType(databean);
/* 675:    */     
/* 676:    */ 
/* 677:796 */     boolean bShow = false;
/* 678:797 */     if (internalLineType.equals("TOOL")) {
/* 679:798 */       bShow = true;
/* 680:    */     }
/* 681:800 */     ((AbstractMobileControl)event.getCreatingObject()).setVisibility(bShow);
/* 682:    */     
/* 683:802 */     return true;
/* 684:    */   }
/* 685:    */   
/* 686:    */   public boolean displaystdservicefield(UIEvent event)
/* 687:    */     throws MobileApplicationException
/* 688:    */   {
/* 689:807 */     MobileMboDataBean databean = DataBeanCache.findDataBean("MRLINE");
/* 690:808 */     if (databean == null) {
/* 691:809 */       return true;
/* 692:    */     }
/* 693:811 */     String internalLineType = getInternalLineType(databean);
/* 694:    */     
/* 695:    */ 
/* 696:814 */     boolean bShow = false;
/* 697:815 */     if (internalLineType.equals("STDSERVICE")) {
/* 698:816 */       bShow = true;
/* 699:    */     }
/* 700:818 */     ((AbstractMobileControl)event.getCreatingObject()).setVisibility(bShow);
/* 701:    */     
/* 702:820 */     return true;
/* 703:    */   }
/* 704:    */   
/* 705:    */   public boolean displaydescfield(UIEvent event)
/* 706:    */     throws MobileApplicationException
/* 707:    */   {
/* 708:825 */     MobileMboDataBean databean = DataBeanCache.findDataBean("MRLINE");
/* 709:826 */     if (databean == null) {
/* 710:827 */       return true;
/* 711:    */     }
/* 712:829 */     String internalLineType = getInternalLineType(databean);
/* 713:    */     
/* 714:    */ 
/* 715:832 */     boolean bShow = true;
/* 716:833 */     if ((internalLineType.equals("ITEM")) || (internalLineType.equals("TOOL")) || (internalLineType.equals("STDSERVICE"))) {
/* 717:834 */       bShow = false;
/* 718:    */     }
/* 719:836 */     ((AbstractMobileControl)event.getCreatingObject()).setVisibility(bShow);
/* 720:    */     
/* 721:838 */     return true;
/* 722:    */   }
/* 723:    */   
/* 724:    */   public boolean initassetspareparts(UIEvent event)
/* 725:    */     throws MobileApplicationException
/* 726:    */   {
/* 727:843 */     MobileMboDataBean databean = ((PageControl)event.getCreatingObject()).getDataBean();
/* 728:844 */     MobileMboDataBean wodatabean = DataBeanCache.findDataBean("WORKORDER");
/* 729:847 */     if (wodatabean.getValue("ASSETNUM").equals("")) {
/* 730:848 */       databean.getQBE().setQBE("ASSETNUM", "~NULL~");
/* 731:    */     } else {
/* 732:850 */       databean.getQBE().setQBE("ASSETNUM", wodatabean.getValue("ASSETNUM"));
/* 733:    */     }
/* 734:852 */     databean.reset();
/* 735:    */     
/* 736:854 */     return true;
/* 737:    */   }
/* 738:    */   
/* 739:    */   public boolean selectsparepart(UIEvent event)
/* 740:    */     throws MobileApplicationException
/* 741:    */   {
/* 742:859 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/* 743:860 */     if (databean == null) {
/* 744:861 */       return true;
/* 745:    */     }
/* 746:863 */     String itemnum = databean.getMobileMbo().getValue("ITEMNUM");
/* 747:865 */     if (itemnum.equals("")) {
/* 748:866 */       return true;
/* 749:    */     }
/* 750:868 */     MobileMboDataBean mrlinedatabean = DataBeanCache.findDataBean("MRLINE");
/* 751:869 */     mrlinedatabean.setValue("ITEM", itemnum);
/* 752:    */     
/* 753:871 */     UIUtil.closePage();
/* 754:    */     
/* 755:873 */     return true;
/* 756:    */   }
/* 757:    */   
/* 758:    */   public boolean validatrequireddate(UIEvent event)
/* 759:    */     throws MobileApplicationException
/* 760:    */   {
/* 761:878 */     if ((event.getValue() == null) || (event.getValue().equals(""))) {
/* 762:879 */       return true;
/* 763:    */     }
/* 764:881 */     MobileMboDataBean databean = ((TextboxControl)event.getCreatingObject()).getDataBean();
/* 765:883 */     if (((Date)event.getValue()).before(databean.getCurrentTime()))
/* 766:    */     {
/* 767:885 */       String errorMsg = MobileMessageGenerator.generate("invalidrequireddate", null);
/* 768:886 */       UIUtil.showInfoMessageBox(errorMsg);
/* 769:    */     }
/* 770:890 */     return true;
/* 771:    */   }
/* 772:    */   
/* 773:    */   public boolean lookup(UIEvent event)
/* 774:    */     throws MobileApplicationException
/* 775:    */   {
/* 776:899 */     String fieldName = ((AbstractMobileControl)event.getCreatingObject()).getValue("dataattribute");
/* 777:901 */     if ((event.getEventName().equalsIgnoreCase("lookupitemfield")) || ((fieldName != null) && ((fieldName.equalsIgnoreCase("service")) || (fieldName.equalsIgnoreCase("tool")))))
/* 778:    */     {
/* 779:907 */       String inventoryBeanName = null;
/* 780:908 */       String itemorgBeanName = null;
/* 781:909 */       if ((fieldName != null) && (fieldName.equalsIgnoreCase("tool")))
/* 782:    */       {
/* 783:911 */         inventoryBeanName = "TOOLINVENTORY";
/* 784:912 */         itemorgBeanName = "TOOLITEMORGINFO";
/* 785:    */       }
/* 786:914 */       else if ((fieldName != null) && (fieldName.equalsIgnoreCase("service")))
/* 787:    */       {
/* 788:916 */         inventoryBeanName = null;
/* 789:917 */         itemorgBeanName = "SERVICEITEMORGINFO";
/* 790:    */       }
/* 791:    */       else
/* 792:    */       {
/* 793:921 */         inventoryBeanName = "ITEMINVENTORY";
/* 794:922 */         itemorgBeanName = "ITEMITEMORGINFO";
/* 795:    */       }
/* 796:925 */       MobileMboDataBean databean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/* 797:926 */       String mboName = ((AbstractMobileControl)event.getCreatingObject()).getValue("domain");
/* 798:927 */       if (event.getEventName().equalsIgnoreCase("lookupitemfield")) {
/* 799:928 */         mboName = "ITEM";
/* 800:    */       }
/* 801:930 */       MobileMbo mbo = databean.getMobileMbo();
/* 802:    */       
/* 803:932 */       MobileMboDataBean itembean = DataBeanCache.findDataBean(mboName);
/* 804:933 */       if (itembean == null)
/* 805:    */       {
/* 806:935 */         MobileMboDataBeanManager mgrbean = new MobileMboDataBeanManager(mboName);
/* 807:936 */         itembean = mgrbean.getDataBean();
/* 808:937 */         DataBeanCache.cacheDataBean(mboName, itembean);
/* 809:    */       }
/* 810:940 */       ItemFilter filter = new ItemFilter(itembean);
/* 811:941 */       List statusesItemOrg = ItemFilter.translateItemStatusName(databean, new String[] { "ACTIVE" });
/* 812:    */       
/* 813:943 */       String woorgid = mbo.getValue("ORGID");
/* 814:944 */       String storeloc = mbo.getValue("STORELOC");
/* 815:945 */       String siteid = mbo.getValue("SITEID");
/* 816:946 */       boolean stockedOnly = (storeloc != null) && (storeloc.length() > 0);
/* 817:947 */       if (inventoryBeanName == null)
/* 818:    */       {
/* 819:949 */         filter.applyItemOrgInfoFilter(itemorgBeanName, statusesItemOrg, woorgid);
/* 820:    */       }
/* 821:    */       else
/* 822:    */       {
/* 823:953 */         List statusesInv = ItemFilter.translateItemStatusName(databean, new String[] { "ACTIVE", "PENDOBS" });
/* 824:954 */         filter.applyItemOrgInfoFilter(itemorgBeanName, statusesItemOrg, stockedOnly, woorgid, inventoryBeanName, statusesInv);
/* 825:    */       }
/* 826:958 */       MobileMboQBE qbe = itembean.getQBE();
/* 827:959 */       qbe.reset();
/* 828:960 */       qbe.setQbeExactMatch(true);
/* 829:961 */       qbe.setLookupParameter("WORKORDER", "ORGID", woorgid);
/* 830:962 */       qbe.setLookupParameter("MATUSETRANS", "SITEID", siteid);
/* 831:963 */       qbe.setLookupParameter("MATUSETRANS", "STORELOC", storeloc);
/* 832:964 */       qbe.setLookupParameter("MATUSETRANS", "BINNUM", "");
/* 833:965 */       qbe.setLookupParameter("MATUSETRANS", "LOTNUM", "");
/* 834:966 */       qbe.setQBE("DISPLAY_IN_LOOKUP", "1");
/* 835:967 */       itembean.reset();
/* 836:    */     }
/* 837:971 */     return false;
/* 838:    */   }
/* 839:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.mobilewo.MatRequestEventHandler
 * JD-Core Version:    0.7.0.1
 */