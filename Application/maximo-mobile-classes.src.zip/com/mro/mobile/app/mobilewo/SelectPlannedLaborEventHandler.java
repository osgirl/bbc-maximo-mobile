/*   1:    */ package com.mro.mobile.app.mobilewo;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.MobileMessageGenerator;
/*   5:    */ import com.mro.mobile.app.BasicMobileDeviceUIApplication;
/*   6:    */ import com.mro.mobile.app.async.AsyncEventHandlerSupport;
/*   7:    */ import com.mro.mobile.mbo.MobileMbo;
/*   8:    */ import com.mro.mobile.mbo.MobileMboQBE;
/*   9:    */ import com.mro.mobile.persist.RDOException;
/*  10:    */ import com.mro.mobile.persist.RDOManager;
/*  11:    */ import com.mro.mobile.persist.RDORuntime;
/*  12:    */ import com.mro.mobile.persist.RDOTransactionManager;
/*  13:    */ import com.mro.mobile.ui.DataBeanCache;
/*  14:    */ import com.mro.mobile.ui.MobileMboDataBean;
/*  15:    */ import com.mro.mobile.ui.MobileMboDataBeanManager;
/*  16:    */ import com.mro.mobile.ui.event.UIEvent;
/*  17:    */ import com.mro.mobile.ui.res.UIUtil;
/*  18:    */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*  19:    */ import com.mro.mobile.ui.res.controls.PageControl;
/*  20:    */ import com.mro.mobileapp.WOApp;
/*  21:    */ import java.util.HashSet;
/*  22:    */ import java.util.Set;
/*  23:    */ 
/*  24:    */ public class SelectPlannedLaborEventHandler
/*  25:    */   extends MobileWOCommonEventHandler
/*  26:    */ {
/*  27:    */   public boolean performEvent(UIEvent event)
/*  28:    */     throws MobileApplicationException
/*  29:    */   {
/*  30: 38 */     if (event == null) {
/*  31: 38 */       return false;
/*  32:    */     }
/*  33: 40 */     String eventId = event.getEventName();
/*  34: 42 */     if (eventId.equalsIgnoreCase("initpage")) {
/*  35: 44 */       return initpage(event);
/*  36:    */     }
/*  37: 46 */     if (eventId.equalsIgnoreCase("refreshpage")) {
/*  38: 48 */       return refreshpage(event);
/*  39:    */     }
/*  40: 50 */     if (eventId.equalsIgnoreCase("selectvalues")) {
/*  41: 52 */       return selectvalues(event);
/*  42:    */     }
/*  43: 55 */     super.performEvent(event);
/*  44:    */     
/*  45: 57 */     return false;
/*  46:    */   }
/*  47:    */   
/*  48:    */   public boolean initpage(UIEvent event)
/*  49:    */     throws MobileApplicationException
/*  50:    */   {
/*  51: 64 */     MobileMboDataBean databean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*  52:    */     
/*  53: 66 */     int count = databean.count();
/*  54: 67 */     for (int i = 0; i < count; i++)
/*  55:    */     {
/*  56: 69 */       if (!databean.getMobileMbo(i).getValue("LABORCODE").equals("")) {
/*  57: 70 */         databean.getMobileMbo(i).setValue("PLAN", databean.getMobileMbo(i).getValue("LABORCODE"));
/*  58:    */       } else {
/*  59: 72 */         databean.getMobileMbo(i).setValue("PLAN", databean.getMobileMbo(i).getValue("CRAFT") + " " + databean.getMobileMbo(i).getValue("SKILLLEVEL"));
/*  60:    */       }
/*  61: 77 */       databean.setValue(i, "HOURS", databean.getValue(i, "LABORHRS"));
/*  62:    */     }
/*  63: 80 */     return true;
/*  64:    */   }
/*  65:    */   
/*  66:    */   public boolean refreshpage(UIEvent event)
/*  67:    */     throws MobileApplicationException
/*  68:    */   {
/*  69: 85 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/*  70:    */     
/*  71: 87 */     int count = databean.count();
/*  72: 88 */     for (int i = 0; i < count; i++)
/*  73:    */     {
/*  74: 90 */       if (!databean.getMobileMbo(i).getValue("LABORCODE").equals("")) {
/*  75: 91 */         databean.getMobileMbo(i).setValue("PLAN", databean.getMobileMbo(i).getValue("LABORCODE"));
/*  76:    */       } else {
/*  77: 93 */         databean.getMobileMbo(i).setValue("PLAN", databean.getMobileMbo(i).getValue("CRAFT") + " " + databean.getMobileMbo(i).getValue("SKILLLEVEL"));
/*  78:    */       }
/*  79: 97 */       databean.setValue(i, "HOURS", databean.getValue(i, "LABORHRS"));
/*  80:    */     }
/*  81:100 */     return true;
/*  82:    */   }
/*  83:    */   
/*  84:    */   public boolean selectvalues(UIEvent event)
/*  85:    */     throws MobileApplicationException
/*  86:    */   {
/*  87:107 */     String pageid = UIUtil.getCurrentScreen().getPage().getId();
/*  88:109 */     if (pageid.equalsIgnoreCase("plannedlaborlookup")) {
/*  89:110 */       return selectplannedlabor(event);
/*  90:    */     }
/*  91:111 */     if (pageid.equalsIgnoreCase("laborlookup")) {
/*  92:112 */       return selectlaborvalues(event);
/*  93:    */     }
/*  94:115 */     if (pageid.equalsIgnoreCase("laborcraftratelookup")) {
/*  95:116 */       return selectLaborCraftRate(event);
/*  96:    */     }
/*  97:118 */     return true;
/*  98:    */   }
/*  99:    */   
/* 100:    */   public boolean selectLaborCraftRate(UIEvent event)
/* 101:    */     throws MobileApplicationException
/* 102:    */   {
/* 103:123 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/* 104:124 */     MobileMboDataBean crewDefinitions = DataBeanCache.getDataBean("CURRENTCREW", "CURRENTCREW");
/* 105:125 */     MobileMboDataBean laborCraftRates = new MobileMboDataBeanManager("LABORCRAFTRATE").getDataBean();
/* 106:126 */     Set existingMembers = createCache(crewDefinitions);
/* 107:127 */     Set existingCraftRates = createCache(laborCraftRates);
/* 108:    */     
/* 109:129 */     String[] attributes = { "ORGID", "LABORCODE", "CRAFT", "SKILLLEVEL", "CONTRACTNUM", "VENDOR", "LABOR_DISPLAYNAME", "CRAFT_DESCRIPTION", "SKILLLEVEL_DESCRIPTION", "VENDOR_NAME" };
/* 110:139 */     for (int i = 0; i < databean.count(); i++)
/* 111:    */     {
/* 112:140 */       MobileMbo mobileMbo = databean.getMobileMbo(i);
/* 113:141 */       if ((mobileMbo.isSelected()) && (!isNewLaborPartOfCrew(existingMembers, mobileMbo)))
/* 114:    */       {
/* 115:142 */         crewDefinitions.insert();
/* 116:143 */         for (int j = 0; j < attributes.length; j++) {
/* 117:144 */           crewDefinitions.setValue(attributes[j], databean.getValue(i, attributes[j]));
/* 118:    */         }
/* 119:146 */         existingMembers.add(buildKey(mobileMbo));
/* 120:148 */         if (!existsLaborCraftRate(existingCraftRates, mobileMbo)) {
/* 121:149 */           createLaborCraftRateEntry(mobileMbo);
/* 122:    */         }
/* 123:    */       }
/* 124:    */     }
/* 125:153 */     UIUtil.getApplication().removeCurrentScreen(true);
/* 126:154 */     return true;
/* 127:    */   }
/* 128:    */   
/* 129:    */   private void createLaborCraftRateEntry(MobileMbo mobileMbo)
/* 130:    */     throws MobileApplicationException
/* 131:    */   {
/* 132:160 */     RDORuntime rdoRuntime = UIUtil.getApplication().getRDORuntime();
/* 133:    */     try
/* 134:    */     {
/* 135:162 */       rdoRuntime.getRDOTransactionManager().begin();
/* 136:163 */       rdoRuntime.getRDOManager().insert(mobileMbo.getName(), mobileMbo.getRDO());
/* 137:164 */       rdoRuntime.getRDOTransactionManager().commit();
/* 138:    */     }
/* 139:    */     catch (RDOException e)
/* 140:    */     {
/* 141:167 */       throw new MobileApplicationException(e.getMessage());
/* 142:    */     }
/* 143:    */   }
/* 144:    */   
/* 145:    */   private boolean existsLaborCraftRate(Set existingCraftRates, MobileMbo mobileMbo)
/* 146:    */     throws MobileApplicationException
/* 147:    */   {
/* 148:174 */     return existingCraftRates.contains(buildKey(mobileMbo));
/* 149:    */   }
/* 150:    */   
/* 151:    */   private Set createCache(MobileMboDataBean dataBean)
/* 152:    */     throws MobileApplicationException
/* 153:    */   {
/* 154:179 */     HashSet set = new HashSet();
/* 155:180 */     for (int i = 0; i < dataBean.count(); i++)
/* 156:    */     {
/* 157:181 */       MobileMbo mbo = dataBean.getMobileMbo(i);
/* 158:182 */       set.add(buildKey(mbo));
/* 159:    */     }
/* 160:184 */     return set;
/* 161:    */   }
/* 162:    */   
/* 163:    */   private boolean isNewLaborPartOfCrew(Set existing, MobileMbo mobileMbo)
/* 164:    */     throws MobileApplicationException
/* 165:    */   {
/* 166:190 */     return existing.contains(buildKey(mobileMbo));
/* 167:    */   }
/* 168:    */   
/* 169:    */   private String buildKey(MobileMbo mobileMbo)
/* 170:    */     throws MobileApplicationException
/* 171:    */   {
/* 172:195 */     return mobileMbo.getValue("ORGID") + "|" + mobileMbo.getValue("LABORCODE");
/* 173:    */   }
/* 174:    */   
/* 175:    */   public boolean selectplannedlabor(UIEvent event)
/* 176:    */     throws MobileApplicationException
/* 177:    */   {
/* 178:200 */     boolean incompleteRows = false;
/* 179:201 */     boolean errorRows = false;
/* 180:202 */     boolean atleastonerowcopied = false;
/* 181:    */     
/* 182:204 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/* 183:205 */     MobileMboDataBean wodatabean = databean.getParentBean();
/* 184:206 */     MobileMboDataBean ltdatabean = wodatabean.getDataBean("WOLABTRANS");
/* 185:    */     
/* 186:208 */     String mylaborcode = "";
/* 187:    */     
/* 188:210 */     int count = databean.count();
/* 189:211 */     for (int i = 0; i < count; i++) {
/* 190:213 */       if (databean.getMobileMbo(i).isSelected())
/* 191:    */       {
/* 192:221 */         MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager("LABORCRAFTRATE");
/* 193:222 */         MobileMboDataBean lcrBean = mgrDBMgr.getDataBean();
/* 194:223 */         lcrBean.getQBE().reset();
/* 195:224 */         lcrBean.getQBE().setQbeExactMatch(true);
/* 196:225 */         lcrBean.getQBE().setQBE("ORGID", databean.getMobileMbo(i).getValue("ORGID"));
/* 197:227 */         if (!databean.getMobileMbo(i).getValue("LABORCODE").equals("")) {
/* 198:228 */           lcrBean.getQBE().setQBE("LABORCODE", databean.getMobileMbo(i).getValue("LABORCODE"));
/* 199:    */         }
/* 200:230 */         if (!databean.getMobileMbo(i).getValue("CRAFT").equals("")) {
/* 201:231 */           lcrBean.getQBE().setQBE("CRAFT", databean.getMobileMbo(i).getValue("CRAFT"));
/* 202:    */         }
/* 203:233 */         if (!databean.getMobileMbo(i).getValue("SKILLLEVEL").equals("")) {
/* 204:234 */           lcrBean.getQBE().setQBE("SKILLLEVEL", databean.getMobileMbo(i).getValue("SKILLLEVEL"));
/* 205:    */         }
/* 206:236 */         if (!databean.getMobileMbo(i).getValue("VENDOR").equals("")) {
/* 207:237 */           lcrBean.getQBE().setQBE("VENDOR", databean.getMobileMbo(i).getValue("VENDOR"));
/* 208:    */         }
/* 209:239 */         if (!databean.getMobileMbo(i).getValue("CONTRACTNUM").equals("")) {
/* 210:240 */           lcrBean.getQBE().setQBE("CONTRACTNUM", databean.getMobileMbo(i).getValue("CONTRACTNUM"));
/* 211:    */         }
/* 212:242 */         lcrBean.reset();
/* 213:243 */         MobileMbo lcrMbo = lcrBean.getMobileMbo(0);
/* 214:244 */         if (lcrMbo == null)
/* 215:    */         {
/* 216:247 */           errorRows = true;
/* 217:    */         }
/* 218:250 */         else if (lcrBean.count() == 1)
/* 219:    */         {
/* 220:253 */           atleastonerowcopied = true;
/* 221:254 */           ltdatabean.insert();
/* 222:    */           
/* 223:256 */           ltdatabean.setValue("TRANSTYPE", ((WOApp)UIUtil.getApplication()).getDefaultValue(databean, "LTTYPE", "WORK"));
/* 224:    */           
/* 225:258 */           ltdatabean.setValue("ACTUALSTASKID", databean.getMobileMbo(i).getValue("TASKID"));
/* 226:259 */           ltdatabean.setValue("LABORCODE", lcrMbo.getValue("LABORCODE"));
/* 227:260 */           ltdatabean.setValue("CRAFT", lcrMbo.getValue("CRAFT"));
/* 228:261 */           ltdatabean.setValue("SKILLLEVEL", lcrMbo.getValue("SKILLLEVEL"));
/* 229:262 */           ltdatabean.setValue("VENDOR", lcrMbo.getValue("VENDOR"));
/* 230:263 */           ltdatabean.setValue("CONTRACTNUM", lcrMbo.getValue("CONTRACTNUM"));
/* 231:    */           
/* 232:    */ 
/* 233:266 */           ltdatabean.setValue("REGULARHRS", databean.getMobileMbo(i).getValue("HOURS"));
/* 234:    */           
/* 235:    */ 
/* 236:    */ 
/* 237:    */ 
/* 238:271 */           ltdatabean.getMobileMbo().setDateValue("STARTDATETIME", ltdatabean.getCurrentTime());
/* 239:272 */           String startdate = "";
/* 240:273 */           String starttime = "";
/* 241:274 */           String startdatetime = ltdatabean.getValue("STARTDATETIME");
/* 242:275 */           if (!startdatetime.equals(""))
/* 243:    */           {
/* 244:277 */             startdate = startdatetime.substring(0, startdatetime.indexOf(" "));
/* 245:278 */             starttime = startdatetime.substring(startdatetime.indexOf(" ") + 1);
/* 246:    */           }
/* 247:280 */           ltdatabean.setValue("STARTDATE", startdate);
/* 248:281 */           ltdatabean.setValue("STARTTIME", starttime);
/* 249:    */         }
/* 250:    */         else
/* 251:    */         {
/* 252:286 */           String laborcode = databean.getMobileMbo(i).getValue("LABORCODE");
/* 253:287 */           if (laborcode.equals(""))
/* 254:    */           {
/* 255:290 */             if (mylaborcode.equals("")) {
/* 256:292 */               mylaborcode = WOApp.getUsersLaborcode(wodatabean.getValue("ORGID"));
/* 257:    */             }
/* 258:295 */             mgrDBMgr = new MobileMboDataBeanManager("LABORCRAFTRATE");
/* 259:296 */             lcrBean = mgrDBMgr.getDataBean();
/* 260:297 */             lcrBean.getQBE().reset();
/* 261:298 */             lcrBean.getQBE().setQbeExactMatch(true);
/* 262:299 */             lcrBean.getQBE().setQBE("ORGID", databean.getMobileMbo(i).getValue("ORGID"));
/* 263:300 */             lcrBean.getQBE().setQBE("LABORCODE", mylaborcode);
/* 264:302 */             if (!databean.getMobileMbo(i).getValue("CRAFT").equals("")) {
/* 265:303 */               lcrBean.getQBE().setQBE("CRAFT", databean.getMobileMbo(i).getValue("CRAFT"));
/* 266:    */             }
/* 267:305 */             if (!databean.getMobileMbo(i).getValue("SKILLLEVEL").equals("")) {
/* 268:306 */               lcrBean.getQBE().setQBE("SKILLLEVEL", databean.getMobileMbo(i).getValue("SKILLLEVEL"));
/* 269:    */             }
/* 270:308 */             if (!databean.getMobileMbo(i).getValue("VENDOR").equals("")) {
/* 271:309 */               lcrBean.getQBE().setQBE("VENDOR", databean.getMobileMbo(i).getValue("VENDOR"));
/* 272:    */             }
/* 273:311 */             if (!databean.getMobileMbo(i).getValue("CONTRACTNUM").equals("")) {
/* 274:312 */               lcrBean.getQBE().setQBE("CONTRACTNUM", databean.getMobileMbo(i).getValue("CONTRACTNUM"));
/* 275:    */             }
/* 276:314 */             lcrBean.reset();
/* 277:315 */             lcrMbo = lcrBean.getMobileMbo(0);
/* 278:316 */             if (lcrMbo != null) {
/* 279:320 */               if (lcrBean.count() == 1)
/* 280:    */               {
/* 281:323 */                 ltdatabean.insert();
/* 282:    */                 
/* 283:325 */                 ltdatabean.setValue("TRANSTYPE", ((WOApp)UIUtil.getApplication()).getDefaultValue(databean, "LTTYPE", "WORK"));
/* 284:    */                 
/* 285:327 */                 atleastonerowcopied = true;
/* 286:328 */                 ltdatabean.setValue("ACTUALSTASKID", databean.getMobileMbo(i).getValue("TASKID"));
/* 287:329 */                 ltdatabean.setValue("LABORCODE", lcrMbo.getValue("LABORCODE"));
/* 288:330 */                 ltdatabean.setValue("CRAFT", lcrMbo.getValue("CRAFT"));
/* 289:331 */                 ltdatabean.setValue("SKILLLEVEL", lcrMbo.getValue("SKILLLEVEL"));
/* 290:332 */                 ltdatabean.setValue("VENDOR", lcrMbo.getValue("VENDOR"));
/* 291:333 */                 ltdatabean.setValue("CONTRACTNUM", lcrMbo.getValue("CONTRACTNUM"));
/* 292:334 */                 ltdatabean.setValue("REGULARHRS", databean.getMobileMbo(i).getValue("LABORHRS"));
/* 293:    */                 
/* 294:    */ 
/* 295:    */ 
/* 296:    */ 
/* 297:339 */                 ltdatabean.getMobileMbo().setDateValue("STARTDATETIME", ltdatabean.getCurrentTime());
/* 298:340 */                 String startdate = "";
/* 299:341 */                 String starttime = "";
/* 300:342 */                 String startdatetime = ltdatabean.getValue("STARTDATETIME");
/* 301:343 */                 if (!startdatetime.equals(""))
/* 302:    */                 {
/* 303:345 */                   startdate = startdatetime.substring(0, startdatetime.indexOf(" "));
/* 304:346 */                   starttime = startdatetime.substring(startdatetime.indexOf(" ") + 1);
/* 305:    */                 }
/* 306:348 */                 ltdatabean.setValue("STARTDATE", startdate);
/* 307:349 */                 ltdatabean.setValue("STARTTIME", starttime);
/* 308:    */                 
/* 309:351 */                 continue;
/* 310:    */               }
/* 311:    */             }
/* 312:354 */             laborcode = mylaborcode;
/* 313:    */           }
/* 314:    */           else
/* 315:    */           {
/* 316:358 */             atleastonerowcopied = true;
/* 317:359 */             ltdatabean.insert();
/* 318:    */             
/* 319:361 */             ltdatabean.setValue("TRANSTYPE", ((WOApp)UIUtil.getApplication()).getDefaultValue(databean, "LTTYPE", "WORK"));
/* 320:    */             
/* 321:363 */             ltdatabean.setValue("ACTUALSTASKID", databean.getMobileMbo(i).getValue("TASKID"));
/* 322:364 */             ltdatabean.setValue("LABORCODE", laborcode);
/* 323:365 */             ltdatabean.setValue("CRAFT", databean.getMobileMbo(i).getValue("CRAFT"));
/* 324:366 */             ltdatabean.setValue("SKILLLEVEL", databean.getMobileMbo(i).getValue("SKILLLEVEL"));
/* 325:367 */             ltdatabean.setValue("VENDOR", databean.getMobileMbo(i).getValue("VENDOR"));
/* 326:368 */             ltdatabean.setValue("CONTRACTNUM", databean.getMobileMbo(i).getValue("CONTRACTNUM"));
/* 327:369 */             ltdatabean.setValue("REGULARHRS", databean.getMobileMbo(i).getValue("LABORHRS"));
/* 328:    */             
/* 329:    */ 
/* 330:    */ 
/* 331:    */ 
/* 332:374 */             ltdatabean.getMobileMbo().setDateValue("STARTDATETIME", ltdatabean.getCurrentTime());
/* 333:375 */             String startdate = "";
/* 334:376 */             String starttime = "";
/* 335:377 */             String startdatetime = ltdatabean.getValue("STARTDATETIME");
/* 336:378 */             if (!startdatetime.equals(""))
/* 337:    */             {
/* 338:380 */               startdate = startdatetime.substring(0, startdatetime.indexOf(" "));
/* 339:381 */               starttime = startdatetime.substring(startdatetime.indexOf(" ") + 1);
/* 340:    */             }
/* 341:383 */             ltdatabean.setValue("STARTDATE", startdate);
/* 342:384 */             ltdatabean.setValue("STARTTIME", starttime);
/* 343:387 */             if (ltdatabean.getValue("LABORCODE").equals(""))
/* 344:    */             {
/* 345:389 */               incompleteRows = true;
/* 346:390 */               ltdatabean.markIncomplete();
/* 347:    */             }
/* 348:    */             else
/* 349:    */             {
/* 350:396 */               boolean complete = false;
/* 351:397 */               int lcrCount = lcrBean.count();
/* 352:398 */               for (int b = 0; b < lcrCount; b++)
/* 353:    */               {
/* 354:400 */                 lcrMbo = lcrBean.getMobileMbo(b);
/* 355:401 */                 if ((lcrMbo.getValue("CRAFT").equals(databean.getMobileMbo(i).getValue("CRAFT"))) && (lcrMbo.getValue("SKILLLEVEL").equals(databean.getMobileMbo(i).getValue("SKILLLEVEL"))) && (lcrMbo.getValue("VENDOR").equals(databean.getMobileMbo(i).getValue("VENDOR"))) && (lcrMbo.getValue("CONTRACTNUM").equals(databean.getMobileMbo(i).getValue("CONTRACTNUM"))))
/* 356:    */                 {
/* 357:407 */                   complete = true;
/* 358:408 */                   break;
/* 359:    */                 }
/* 360:    */               }
/* 361:411 */               if (!complete)
/* 362:    */               {
/* 363:415 */                 incompleteRows = true;
/* 364:416 */                 ltdatabean.markIncomplete();
/* 365:    */               }
/* 366:    */             }
/* 367:    */           }
/* 368:    */         }
/* 369:    */       }
/* 370:    */     }
/* 371:420 */     if (!atleastonerowcopied)
/* 372:    */     {
/* 373:422 */       ltdatabean.getDataBeanManager().cancel();
/* 374:423 */       UIUtil.getApplication().removeCurrentScreen(true);
/* 375:424 */       return true;
/* 376:    */     }
/* 377:427 */     if (!UIUtil.checkESignature(event, ltdatabean, "LABACTUALS"))
/* 378:    */     {
/* 379:429 */       ltdatabean.getDataBeanManager().cancel();
/* 380:    */     }
/* 381:    */     else
/* 382:    */     {
/* 383:433 */       ltdatabean.getDataBeanManager().save();
/* 384:435 */       if (incompleteRows) {
/* 385:437 */         UIUtil.showInfoMessageBox(MobileMessageGenerator.generate("labactincomplete", new Object[0]));
/* 386:    */       }
/* 387:440 */       if (errorRows) {
/* 388:442 */         UIUtil.showInfoMessageBox(MobileMessageGenerator.generate("invalidlcrrow", new Object[0]));
/* 389:    */       }
/* 390:445 */       UIUtil.getApplication().removeCurrentScreen(true);
/* 391:    */     }
/* 392:448 */     return true;
/* 393:    */   }
/* 394:    */   
/* 395:    */   public boolean selectlaborvalues(UIEvent event)
/* 396:    */     throws MobileApplicationException
/* 397:    */   {
/* 398:452 */     final MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/* 399:453 */     final MobileMboDataBean ltdatabean = ((PageControl)UIUtil.getCurrentScreen()).getLaunchingControl().getDataBean();
/* 400:454 */     new AsyncEventHandlerSupport()
/* 401:    */     {
/* 402:455 */       boolean atleastonerowcopied = false;
/* 403:    */       
/* 404:    */       public boolean doRealWok(UIEvent event)
/* 405:    */         throws MobileApplicationException
/* 406:    */       {
/* 407:458 */         super.updateProgressBar("processdatainprogress", null, event);
/* 408:459 */         int count = databean.count();
/* 409:460 */         for (int i = 0; i < count; i++) {
/* 410:461 */           if (databean.getMobileMbo(i).isSelected())
/* 411:    */           {
/* 412:466 */             if (databean.isOnline())
/* 413:    */             {
/* 414:469 */               MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager("LABORCRAFTRATE");
/* 415:470 */               MobileMboDataBean lcrBean = mgrDBMgr.getDataBean();
/* 416:471 */               lcrBean.getQBE().reset();
/* 417:472 */               lcrBean.getQBE().setQbeExactMatch(true);
/* 418:473 */               lcrBean.getQBE().setQBE("ORGID", databean.getValue("ORGID"));
/* 419:474 */               lcrBean.getQBE().setQBE("LABORCODE", databean.getValue("LABORCODE"));
/* 420:475 */               lcrBean.reset();
/* 421:476 */               int lcrCount = lcrBean.count();
/* 422:477 */               if (lcrCount == 0)
/* 423:    */               {
/* 424:482 */                 mgrDBMgr = new MobileMboDataBeanManager("LABOR");
/* 425:483 */                 MobileMboDataBean lbrBean = mgrDBMgr.getDataBean();
/* 426:484 */                 lbrBean.getQBE().reset();
/* 427:485 */                 lbrBean.setOnline(true);
/* 428:486 */                 lbrBean.getQBE().setQbeExactMatch(true);
/* 429:487 */                 lbrBean.getQBE().setQBE("ORGID", databean.getValue("ORGID"));
/* 430:488 */                 lbrBean.getQBE().setQBE("LABORCODE", databean.getValue("LABORCODE"));
/* 431:489 */                 if (lbrBean.getMobileMbo(0) != null) {
/* 432:491 */                   ((WOApp)UIUtil.getApplication()).downloadAdHocMobileMbo(event.getProgressObserver(), "LABOR", lbrBean.getMobileMbo(0).getValue("_ID"));
/* 433:    */                 }
/* 434:    */               }
/* 435:    */             }
/* 436:498 */             this.atleastonerowcopied = true;
/* 437:499 */             ltdatabean.insert();
/* 438:    */             
/* 439:    */ 
/* 440:502 */             MobileMbo ownerMbo = ltdatabean.getOwner();
/* 441:503 */             if (ownerMbo.getName().equalsIgnoreCase("TICKET")) {
/* 442:504 */               ltdatabean.setValue("TICKETCLASS", ownerMbo.getValue("CLASS"));
/* 443:    */             }
/* 444:507 */             ltdatabean.setValue("TRANSTYPE", ((WOApp)UIUtil.getApplication()).getDefaultValue(databean, "LTTYPE", "WORK"));
/* 445:508 */             ltdatabean.setValue("LABORCODE", databean.getMobileMbo(i).getValue("LABORCODE"));
/* 446:509 */             ltdatabean.setValue("CRAFT", databean.getMobileMbo(i).getValue("CRAFT"));
/* 447:510 */             ltdatabean.setValue("SKILLLEVEL", databean.getMobileMbo(i).getValue("SKILLLEVEL"));
/* 448:511 */             ltdatabean.setValue("VENDOR", databean.getMobileMbo(i).getValue("VENDOR"));
/* 449:512 */             ltdatabean.setValue("CONTRACTNUM", databean.getMobileMbo(i).getValue("CONTRACTNUM"));
/* 450:    */             
/* 451:    */ 
/* 452:    */ 
/* 453:    */ 
/* 454:    */ 
/* 455:518 */             ltdatabean.getMobileMbo().setDateValue("STARTDATETIME", ltdatabean.getCurrentTime());
/* 456:519 */             String startdate = "";
/* 457:520 */             String starttime = "";
/* 458:521 */             String startdatetime = ltdatabean.getValue("STARTDATETIME");
/* 459:522 */             if (!startdatetime.equals(""))
/* 460:    */             {
/* 461:523 */               startdate = startdatetime.substring(0, startdatetime.indexOf(" "));
/* 462:524 */               starttime = startdatetime.substring(startdatetime.indexOf(" ") + 1);
/* 463:    */             }
/* 464:526 */             ltdatabean.setValue("STARTDATE", startdate);
/* 465:527 */             ltdatabean.setValue("STARTTIME", starttime);
/* 466:    */           }
/* 467:    */         }
/* 468:530 */         return true;
/* 469:    */       }
/* 470:    */       
/* 471:    */       public void postRealWork(UIEvent event)
/* 472:    */         throws MobileApplicationException
/* 473:    */       {
/* 474:534 */         if (!this.atleastonerowcopied)
/* 475:    */         {
/* 476:535 */           ltdatabean.getDataBeanManager().cancel();
/* 477:536 */           UIUtil.getApplication().removeCurrentScreen(true);
/* 478:537 */           return;
/* 479:    */         }
/* 480:540 */         if (!UIUtil.checkESignature(event, ltdatabean, "LABACTUALS"))
/* 481:    */         {
/* 482:541 */           ltdatabean.getDataBeanManager().cancel();
/* 483:    */         }
/* 484:    */         else
/* 485:    */         {
/* 486:543 */           ltdatabean.getDataBeanManager().save();
/* 487:544 */           UIUtil.getApplication().removeCurrentScreen(true);
/* 488:    */         }
/* 489:546 */         UIUtil.refreshCurrentScreen();
/* 490:    */       }
/* 491:546 */     }.handleInBackground(event);
/* 492:    */     
/* 493:    */ 
/* 494:549 */     return true;
/* 495:    */   }
/* 496:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.mobilewo.SelectPlannedLaborEventHandler
 * JD-Core Version:    0.7.0.1
 */