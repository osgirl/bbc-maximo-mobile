/*  1:   */ package com.mro.mobile.app.mobilewo;
/*  2:   */ 
/*  3:   */ import com.mro.mobile.MobileApplicationException;
/*  4:   */ import com.mro.mobile.ui.event.UIEvent;
/*  5:   */ 
/*  6:   */ public class WOMultiEventHandler
/*  7:   */   extends MobileWOCommonEventHandler
/*  8:   */ {
/*  9:26 */   private MultiAssetLocCIUGenericHandler multiHandler = null;
/* 10:   */   
/* 11:   */   public WOMultiEventHandler()
/* 12:   */   {
/* 13:30 */     this.multiHandler = new MultiAssetLocCIUGenericHandler();
/* 14:31 */     this.multiHandler.setMasterDataBean("WORKORDER");
/* 15:32 */     this.multiHandler.setMultiBean("WOMULTIASSETLOCCI");
/* 16:33 */     this.multiHandler.setCachedMultiBean("WOMULTI");
/* 17:34 */     this.multiHandler.setRecordKeySourceField("WONUM");
/* 18:35 */     this.multiHandler.setRecordClassSourceField("WOCLASS");
/* 19:36 */     this.multiHandler.setDetailsPage("womulti_details");
/* 20:   */   }
/* 21:   */   
/* 22:   */   public boolean performEvent(UIEvent event)
/* 23:   */     throws MobileApplicationException
/* 24:   */   {
/* 25:41 */     if (event == null) {
/* 26:41 */       return false;
/* 27:   */     }
/* 28:43 */     String eventId = event.getEventName();
/* 29:45 */     if (eventId.equalsIgnoreCase("insertmulti")) {
/* 30:47 */       return this.multiHandler.insertmulti(event);
/* 31:   */     }
/* 32:49 */     if (eventId.equalsIgnoreCase("refreshmultitable")) {
/* 33:51 */       return this.multiHandler.refreshmultitable(event);
/* 34:   */     }
/* 35:53 */     if (eventId.equalsIgnoreCase("assetchanged")) {
/* 36:55 */       return this.multiHandler.assetchanged(event);
/* 37:   */     }
/* 38:64 */     if (eventId.equalsIgnoreCase("checkchangedvalues")) {
/* 39:66 */       return this.multiHandler.checkchangedvalues(event);
/* 40:   */     }
/* 41:68 */     if (eventId.equalsIgnoreCase("validateMulti")) {
/* 42:70 */       return this.multiHandler.validateMulti(event);
/* 43:   */     }
/* 44:72 */     if (eventId.equalsIgnoreCase("deletemulti")) {
/* 45:74 */       return this.multiHandler.deletemulti(event);
/* 46:   */     }
/* 47:76 */     if (eventId.equalsIgnoreCase("candeletemulti")) {
/* 48:78 */       return this.multiHandler.candeletemulti(event);
/* 49:   */     }
/* 50:80 */     if (eventId.equalsIgnoreCase("locationchanged")) {
/* 51:82 */       return this.multiHandler.locationchanged(event);
/* 52:   */     }
/* 53:84 */     if (eventId.equalsIgnoreCase("cichanged")) {
/* 54:86 */       return this.multiHandler.cichanged(event);
/* 55:   */     }
/* 56:88 */     if (eventId.equalsIgnoreCase("setActualProgressField")) {
/* 57:90 */       return this.multiHandler.setActualProgressField(event);
/* 58:   */     }
/* 59:98 */     return false;
/* 60:   */   }
/* 61:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.mobilewo.WOMultiEventHandler
 * JD-Core Version:    0.7.0.1
 */