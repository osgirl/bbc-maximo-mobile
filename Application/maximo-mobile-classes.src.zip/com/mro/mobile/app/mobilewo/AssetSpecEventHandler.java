/*  1:   */ package com.mro.mobile.app.mobilewo;
/*  2:   */ 
/*  3:   */ import com.mro.mobile.MobileApplicationException;
/*  4:   */ import com.mro.mobile.mbo.MobileMbo;
/*  5:   */ import com.mro.mobile.ui.MobileMboDataBean;
/*  6:   */ import com.mro.mobile.ui.MobileMboDataBeanManager;
/*  7:   */ import com.mro.mobile.ui.event.UIEvent;
/*  8:   */ import com.mro.mobile.ui.res.controls.PageControl;
/*  9:   */ 
/* 10:   */ public class AssetSpecEventHandler
/* 11:   */   extends MobileWOCommonEventHandler
/* 12:   */ {
/* 13:   */   public boolean performEvent(UIEvent event)
/* 14:   */     throws MobileApplicationException
/* 15:   */   {
/* 16:26 */     if (event == null) {
/* 17:26 */       return false;
/* 18:   */     }
/* 19:28 */     String eventId = event.getEventName();
/* 20:30 */     if (eventId.equalsIgnoreCase("prepSpecTable")) {
/* 21:32 */       return prepSpecTable(event);
/* 22:   */     }
/* 23:35 */     super.performEvent(event);
/* 24:   */     
/* 25:37 */     return false;
/* 26:   */   }
/* 27:   */   
/* 28:   */   public boolean prepSpecTable(UIEvent event)
/* 29:   */     throws MobileApplicationException
/* 30:   */   {
/* 31:43 */     MobileMboDataBean databean = ((PageControl)event.getCreatingObject()).getDataBean();
/* 32:46 */     for (int i = 0; i < databean.count(); i++) {
/* 33:49 */       if (!databean.getMobileMbo(i).getValue("DISPLAYVALUESET").equals("1"))
/* 34:   */       {
/* 35:51 */         if (!databean.getMobileMbo(i).getValue("ALNVALUE").equals("")) {
/* 36:52 */           databean.getMobileMbo(i).setValue("DISPLAYVALUE", databean.getMobileMbo(i).getValue("ALNVALUE"));
/* 37:53 */         } else if (!databean.getMobileMbo(i).getValue("NUMVALUE").equals("")) {
/* 38:54 */           databean.getMobileMbo(i).setValue("DISPLAYVALUE", databean.getMobileMbo(i).getValue("NUMVALUE"));
/* 39:55 */         } else if ((databean.getMobileMbo(i).getValue("ALNVALUE").equals("")) && (databean.getMobileMbo(i).getValue("NUMVALUE").equals(""))) {
/* 40:56 */           databean.getMobileMbo(i).setValue("DISPLAYVALUE", "");
/* 41:   */         }
/* 42:58 */         databean.getMobileMbo(i).setValue("DISPLAYVALUESET", "1");
/* 43:   */         
/* 44:60 */         databean.getMobileMbo(i).setValue("NEWVALUE", databean.getMobileMbo(i).getValue("DISPLAYVALUE"));
/* 45:   */       }
/* 46:   */     }
/* 47:63 */     databean.getDataBeanManager().save();
/* 48:64 */     return true;
/* 49:   */   }
/* 50:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.mobilewo.AssetSpecEventHandler
 * JD-Core Version:    0.7.0.1
 */