/*    1:     */ package com.mro.mobile.app.mobilewo;
/*    2:     */ 
/*    3:     */ import com.mro.mobile.MobileApplicationException;
/*    4:     */ import com.mro.mobile.MobileMessageGenerator;
/*    5:     */ import com.mro.mobile.app.DefaultMobileMboDataFormatter;
/*    6:     */ import com.mro.mobile.mbo.MobileMbo;
/*    7:     */ import com.mro.mobile.mbo.MobileMboQBE;
/*    8:     */ import com.mro.mobile.ui.DataBeanCache;
/*    9:     */ import com.mro.mobile.ui.MobileMboDataBean;
/*   10:     */ import com.mro.mobile.ui.MobileMboDataBeanManager;
/*   11:     */ import com.mro.mobile.ui.event.UIEvent;
/*   12:     */ import com.mro.mobile.ui.res.UIUtil;
/*   13:     */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*   14:     */ import com.mro.mobile.ui.res.controls.ButtonControl;
/*   15:     */ import com.mro.mobile.ui.res.controls.LookupControl;
/*   16:     */ import com.mro.mobile.ui.res.controls.PageControl;
/*   17:     */ import com.mro.mobile.ui.res.controls.StateControl;
/*   18:     */ import com.mro.mobile.ui.res.controls.TextboxControl;
/*   19:     */ import com.mro.mobile.ui.res.controls.utils.StyleManager;
/*   20:     */ import com.mro.mobileapp.WOApp;
/*   21:     */ import java.util.Iterator;
/*   22:     */ import java.util.Locale;
/*   23:     */ 
/*   24:     */ public class LinearAssetEventHandler
/*   25:     */   extends MobileWOCommonEventHandler
/*   26:     */ {
/*   27:  44 */   private boolean fromLookup = false;
/*   28:     */   
/*   29:     */   public boolean performEvent(UIEvent event)
/*   30:     */     throws MobileApplicationException
/*   31:     */   {
/*   32:  48 */     if (event == null) {
/*   33:  48 */       return false;
/*   34:     */     }
/*   35:  50 */     String eventId = event.getEventName();
/*   36:  52 */     if (eventId.equalsIgnoreCase("hasPrimaryLinearAssetWO")) {
/*   37:  54 */       return hasPrimaryLinearAssetWO(event);
/*   38:     */     }
/*   39:  56 */     if (eventId.equalsIgnoreCase("setWOLinearTab")) {
/*   40:  58 */       return setWOLinearTab(event);
/*   41:     */     }
/*   42:  60 */     if (eventId.equalsIgnoreCase("refreshWOLinearTab")) {
/*   43:  62 */       return refreshWOLinearTab(event);
/*   44:     */     }
/*   45:  64 */     if (eventId.equalsIgnoreCase("hasPrimaryLinearAssetTK")) {
/*   46:  66 */       return hasPrimaryLinearAssetTK(event);
/*   47:     */     }
/*   48:  68 */     if (eventId.equalsIgnoreCase("setTKLinearTab")) {
/*   49:  70 */       return setTKLinearTab(event);
/*   50:     */     }
/*   51:  72 */     if (eventId.equalsIgnoreCase("refreshTKLinearTab")) {
/*   52:  74 */       return refreshTKLinearTab(event);
/*   53:     */     }
/*   54:  76 */     if (eventId.equalsIgnoreCase("isLinearAssetMulti")) {
/*   55:  78 */       return isLinearAssetMulti(event);
/*   56:     */     }
/*   57:  80 */     if (eventId.equalsIgnoreCase("initassetfeaturelookup")) {
/*   58:  82 */       return initAssetFeatureLookup(event);
/*   59:     */     }
/*   60:  84 */     if (eventId.equalsIgnoreCase("isstartoffsetreadonly")) {
/*   61:  86 */       return isOffsetReadOnly(event, "START");
/*   62:     */     }
/*   63:  88 */     if (eventId.equalsIgnoreCase("isendoffsetreadonly")) {
/*   64:  90 */       return isOffsetReadOnly(event, "END");
/*   65:     */     }
/*   66:  92 */     if (eventId.equalsIgnoreCase("isstartmeasurereadonly")) {
/*   67:  94 */       return isMeasureReadOnly(event, "START");
/*   68:     */     }
/*   69:  96 */     if (eventId.equalsIgnoreCase("isendmeasurereadonly")) {
/*   70:  98 */       return isMeasureReadOnly(event, "END");
/*   71:     */     }
/*   72: 100 */     if (eventId.equalsIgnoreCase("checkstartfeaturelabel")) {
/*   73: 102 */       return checkFeatureLabel(event, "START");
/*   74:     */     }
/*   75: 104 */     if (eventId.equalsIgnoreCase("checkendfeaturelabel")) {
/*   76: 106 */       return checkFeatureLabel(event, "END");
/*   77:     */     }
/*   78: 108 */     if (eventId.equalsIgnoreCase("multiselect"))
/*   79:     */     {
/*   80: 110 */       this.fromLookup = true;
/*   81:     */     }
/*   82:     */     else
/*   83:     */     {
/*   84: 112 */       if (eventId.equalsIgnoreCase("calculatestartmeasure")) {
/*   85: 114 */         return calculateMeasure(event, "START");
/*   86:     */       }
/*   87: 116 */       if (eventId.equalsIgnoreCase("calculateendmeasure")) {
/*   88: 118 */         return calculateMeasure(event, "END");
/*   89:     */       }
/*   90: 120 */       if (eventId.equalsIgnoreCase("validatestartmeasure")) {
/*   91: 122 */         return validateMeasure(event, "START");
/*   92:     */       }
/*   93: 124 */       if (eventId.equalsIgnoreCase("validateendmeasure")) {
/*   94: 126 */         return validateMeasure(event, "END");
/*   95:     */       }
/*   96: 128 */       if (eventId.equalsIgnoreCase("checkheaderfeaturelabel")) {
/*   97: 130 */         return checkHeaderFeatureLabel(event);
/*   98:     */       }
/*   99: 132 */       if (eventId.equalsIgnoreCase("islinearasset")) {
/*  100: 134 */         return isLinearAsset(event);
/*  101:     */       }
/*  102: 136 */       if (eventId.equalsIgnoreCase("setprogresstab")) {
/*  103: 138 */         return setProgressTab(event);
/*  104:     */       }
/*  105: 140 */       if (eventId.equalsIgnoreCase("insertprogress")) {
/*  106: 142 */         return insertProgress(event);
/*  107:     */       }
/*  108: 144 */       if (eventId.equalsIgnoreCase("deleterecord")) {
/*  109: 146 */         return deleterecord(event);
/*  110:     */       }
/*  111: 149 */       if (eventId.equalsIgnoreCase("undeleterecord")) {
/*  112: 151 */         return undeleterecord(event);
/*  113:     */       }
/*  114: 154 */       if (eventId.equalsIgnoreCase("toggledeletebutton")) {
/*  115: 156 */         return toggledeletebutton(event);
/*  116:     */       }
/*  117: 159 */       if (eventId.equalsIgnoreCase("tablestylefordeletions")) {
/*  118: 161 */         return tablestylefordeletions(event);
/*  119:     */       }
/*  120:     */     }
/*  121: 165 */     return super.performEvent(event);
/*  122:     */   }
/*  123:     */   
/*  124:     */   protected boolean tablestylefordeletions(UIEvent event)
/*  125:     */     throws MobileApplicationException
/*  126:     */   {
/*  127: 177 */     AbstractMobileControl control = (AbstractMobileControl)event.getCreatingObject();
/*  128: 178 */     MobileMboDataBean databean = control.getDataBean();
/*  129: 180 */     if (databean.getMobileMbo().isDeleted()) {
/*  130: 182 */       event.setValue(StyleManager.getStyle("rowdeleted.table", null));
/*  131:     */     }
/*  132: 185 */     return true;
/*  133:     */   }
/*  134:     */   
/*  135:     */   protected boolean deleterecord(UIEvent event)
/*  136:     */     throws MobileApplicationException
/*  137:     */   {
/*  138: 197 */     AbstractMobileControl control = (AbstractMobileControl)event.getCreatingObject();
/*  139: 198 */     MobileMboDataBean databean = control.getDataBean();
/*  140:     */     
/*  141: 200 */     databean.setValue("_DELETED", "1");
/*  142:     */     
/*  143: 202 */     databean.getDataBeanManager().save();
/*  144: 203 */     UIUtil.refreshCurrentScreen();
/*  145:     */     
/*  146: 205 */     return true;
/*  147:     */   }
/*  148:     */   
/*  149:     */   protected boolean undeleterecord(UIEvent event)
/*  150:     */     throws MobileApplicationException
/*  151:     */   {
/*  152: 217 */     AbstractMobileControl control = (AbstractMobileControl)event.getCreatingObject();
/*  153: 218 */     MobileMboDataBean databean = control.getDataBean();
/*  154:     */     
/*  155: 220 */     databean.getMobileMbo().setReadOnly(false);
/*  156: 222 */     if (databean.getMobileMbo().isNew())
/*  157:     */     {
/*  158: 224 */       databean.getMobileMbo().setValue("_READONLY", "0", false);
/*  159: 225 */       databean.setValue("_DELETED", "0");
/*  160:     */     }
/*  161:     */     else
/*  162:     */     {
/*  163: 229 */       databean.undoChanges();
/*  164:     */     }
/*  165: 232 */     databean.getDataBeanManager().save();
/*  166:     */     
/*  167: 234 */     UIUtil.refreshCurrentScreen();
/*  168:     */     
/*  169: 236 */     return true;
/*  170:     */   }
/*  171:     */   
/*  172:     */   protected boolean toggledeletebutton(UIEvent event)
/*  173:     */     throws MobileApplicationException
/*  174:     */   {
/*  175: 249 */     StateControl state = (StateControl)event.getCreatingObject();
/*  176: 250 */     MobileMboDataBean databean = state.getDataBean();
/*  177:     */     
/*  178: 252 */     String btnDelete = null;
/*  179: 253 */     String btnUndelete = null;
/*  180: 254 */     Iterator buttons = state.getChildren();
/*  181: 255 */     while (buttons.hasNext())
/*  182:     */     {
/*  183: 257 */       ButtonControl button = (ButtonControl)buttons.next();
/*  184: 258 */       String buttonId = button.getId();
/*  185: 259 */       if (buttonId.toLowerCase().endsWith("_delete")) {
/*  186: 261 */         btnDelete = buttonId;
/*  187: 263 */       } else if (buttonId.toLowerCase().endsWith("_undelete")) {
/*  188: 265 */         btnUndelete = buttonId;
/*  189:     */       }
/*  190:     */     }
/*  191: 269 */     if (!databean.getMobileMbo().isDeleted()) {
/*  192: 271 */       state.setNewState(btnDelete);
/*  193:     */     } else {
/*  194: 275 */       state.setNewState(btnUndelete);
/*  195:     */     }
/*  196: 278 */     return true;
/*  197:     */   }
/*  198:     */   
/*  199:     */   protected boolean hasPrimaryLinearAssetWO(UIEvent event)
/*  200:     */     throws MobileApplicationException
/*  201:     */   {
/*  202: 292 */     MobileMboDataBean dataBean = UIUtil.getCurrentScreen().getDataBean();
/*  203: 294 */     if (isWorkOrderOrSR(dataBean))
/*  204:     */     {
/*  205: 297 */       MobileMboDataBean woAsset = dataBean.getDataBean("WOASSET");
/*  206: 298 */       if ((woAsset != null) && (dataBean.getValue("ASSETNUM") != null) && (!dataBean.getValue("ASSETNUM").equals("")))
/*  207:     */       {
/*  208: 300 */         if (dataBean.getValue("ASSETNUM").equalsIgnoreCase(woAsset.getValue("ASSETNUM")))
/*  209:     */         {
/*  210: 302 */           ((AbstractMobileControl)event.getCreatingObject()).setVisibility("1".equals(woAsset.getValue("ISLINEAR")));
/*  211: 303 */           return true;
/*  212:     */         }
/*  213: 309 */         MobileMboDataBean assetBean = DataBeanCache.getDataBean("ASSET", "ASSET");
/*  214: 310 */         if (assetBean != null)
/*  215:     */         {
/*  216: 313 */           int currentPos = assetBean.getCurrentPosition();
/*  217: 314 */           MobileMboQBE qbe = assetBean.getQBE();
/*  218: 315 */           qbe.saveState();
/*  219: 316 */           qbe.setQBE("ASSETNUM", dataBean.getValue("ASSETNUM"));
/*  220: 317 */           qbe.setQBE("SITEID", dataBean.getValue("SITEID"));
/*  221: 318 */           assetBean.reset();
/*  222: 319 */           MobileMbo assetMbo = assetBean.getMobileMbo(0);
/*  223: 320 */           qbe.restoreState();
/*  224: 321 */           assetBean.reset();
/*  225: 322 */           assetBean.setCurrentPosition(currentPos);
/*  226: 323 */           if ((assetMbo != null) && (assetMbo.getBooleanValue("ISLINEAR")))
/*  227:     */           {
/*  228: 326 */             if (dataBean.getDataBean("WOMULTIASSETLOCCI").count() == 0)
/*  229:     */             {
/*  230: 328 */               ((AbstractMobileControl)event.getCreatingObject()).setVisibility(false);
/*  231: 329 */               UIUtil.showInfoMessageBox(MobileMessageGenerator.generate("pleasesave", null));
/*  232:     */             }
/*  233:     */             else
/*  234:     */             {
/*  235: 334 */               ((AbstractMobileControl)event.getCreatingObject()).setVisibility(true);
/*  236:     */             }
/*  237: 336 */             return true;
/*  238:     */           }
/*  239:     */         }
/*  240:     */       }
/*  241:     */     }
/*  242: 342 */     ((AbstractMobileControl)event.getCreatingObject()).setVisibility(false);
/*  243: 343 */     return true;
/*  244:     */   }
/*  245:     */   
/*  246:     */   protected boolean hasPrimaryLinearAssetTK(UIEvent event)
/*  247:     */     throws MobileApplicationException
/*  248:     */   {
/*  249: 357 */     MobileMboDataBean dataBean = UIUtil.getCurrentScreen().getDataBean();
/*  250: 359 */     if (isWorkOrderOrSR(dataBean))
/*  251:     */     {
/*  252: 362 */       MobileMboDataBean tkAsset = dataBean.getDataBean("TKASSET");
/*  253: 363 */       if ((tkAsset != null) && (dataBean.getValue("ASSETNUM") != null) && (!dataBean.getValue("ASSETNUM").equals("")))
/*  254:     */       {
/*  255: 365 */         if (dataBean.getValue("ASSETNUM").equalsIgnoreCase(tkAsset.getValue("ASSETNUM")))
/*  256:     */         {
/*  257: 367 */           ((AbstractMobileControl)event.getCreatingObject()).setVisibility("1".equals(tkAsset.getValue("ISLINEAR")));
/*  258: 368 */           return true;
/*  259:     */         }
/*  260: 374 */         MobileMboDataBean assetBean = DataBeanCache.getDataBean("ASSET", "ASSET");
/*  261: 375 */         if (assetBean != null)
/*  262:     */         {
/*  263: 378 */           int currentPos = assetBean.getCurrentPosition();
/*  264: 379 */           MobileMboQBE qbe = assetBean.getQBE();
/*  265: 380 */           qbe.saveState();
/*  266: 381 */           qbe.setQBE("ASSETNUM", dataBean.getValue("ASSETNUM"));
/*  267: 382 */           qbe.setQBE("SITEID", dataBean.getValue("ASSETSITEID"));
/*  268: 383 */           assetBean.reset();
/*  269: 384 */           MobileMbo assetMbo = assetBean.getMobileMbo(0);
/*  270: 385 */           qbe.restoreState();
/*  271: 386 */           assetBean.reset();
/*  272: 387 */           assetBean.setCurrentPosition(currentPos);
/*  273: 388 */           if ((assetMbo != null) && (assetMbo.getBooleanValue("ISLINEAR")))
/*  274:     */           {
/*  275: 391 */             if (dataBean.getDataBean("TKMULTIASSETLOCCI").count() == 0)
/*  276:     */             {
/*  277: 393 */               ((AbstractMobileControl)event.getCreatingObject()).setVisibility(false);
/*  278: 394 */               UIUtil.showInfoMessageBox(MobileMessageGenerator.generate("pleasesave", null));
/*  279:     */             }
/*  280:     */             else
/*  281:     */             {
/*  282: 399 */               ((AbstractMobileControl)event.getCreatingObject()).setVisibility(true);
/*  283:     */             }
/*  284: 401 */             return true;
/*  285:     */           }
/*  286:     */         }
/*  287:     */       }
/*  288:     */     }
/*  289: 407 */     ((AbstractMobileControl)event.getCreatingObject()).setVisibility(false);
/*  290: 408 */     return true;
/*  291:     */   }
/*  292:     */   
/*  293:     */   protected boolean setWOLinearTab(UIEvent event)
/*  294:     */     throws MobileApplicationException
/*  295:     */   {
/*  296: 421 */     MobileMboDataBean woBean = UIUtil.getCurrentScreen().getDataBean();
/*  297:     */     
/*  298: 423 */     MobileMboDataBean multiBean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*  299: 424 */     if (multiBean != null)
/*  300:     */     {
/*  301: 426 */       multiBean.getQBE().reset();
/*  302: 427 */       multiBean.getQBE().setQBE("RECORDKEY", woBean.getValue("WONUM"));
/*  303: 428 */       multiBean.getQBE().setQBE("RECORDCLASS", woBean.getValue("WOCLASS"));
/*  304: 429 */       multiBean.getQBE().setQBE("WORKSITEID", woBean.getValue("SITEID"));
/*  305: 430 */       multiBean.getQBE().setQBE("ISPRIMARY", "1");
/*  306: 431 */       multiBean.reset();
/*  307:     */     }
/*  308: 433 */     return true;
/*  309:     */   }
/*  310:     */   
/*  311:     */   protected boolean setTKLinearTab(UIEvent event)
/*  312:     */     throws MobileApplicationException
/*  313:     */   {
/*  314: 447 */     MobileMboDataBean tkBean = UIUtil.getCurrentScreen().getDataBean();
/*  315:     */     
/*  316: 449 */     MobileMboDataBean multiBean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*  317: 450 */     if (multiBean != null)
/*  318:     */     {
/*  319: 452 */       multiBean.getQBE().reset();
/*  320: 453 */       multiBean.getQBE().setQBE("RECORDKEY", tkBean.getValue("TICKETID"));
/*  321: 454 */       multiBean.getQBE().setQBE("RECORDCLASS", tkBean.getValue("CLASS"));
/*  322: 455 */       multiBean.getQBE().setQBE("SITEID", tkBean.getValue("SITEID"));
/*  323: 456 */       multiBean.getQBE().setQBE("ISPRIMARY", "1");
/*  324: 457 */       multiBean.reset();
/*  325:     */     }
/*  326: 459 */     return true;
/*  327:     */   }
/*  328:     */   
/*  329:     */   protected boolean refreshWOLinearTab(UIEvent event)
/*  330:     */     throws MobileApplicationException
/*  331:     */   {
/*  332: 472 */     MobileMboDataBean woBean = UIUtil.getCurrentScreen().getDataBean();
/*  333:     */     
/*  334: 474 */     MobileMboDataBean multiBean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*  335: 477 */     if ((woBean != null) && (multiBean != null) && (!woBean.getValue("WONUM").equalsIgnoreCase(multiBean.getValue("RECORDKEY")))) {
/*  336: 479 */       setWOLinearTab(event);
/*  337:     */     }
/*  338: 481 */     return true;
/*  339:     */   }
/*  340:     */   
/*  341:     */   protected boolean refreshTKLinearTab(UIEvent event)
/*  342:     */     throws MobileApplicationException
/*  343:     */   {
/*  344: 494 */     MobileMboDataBean tkBean = UIUtil.getCurrentScreen().getDataBean();
/*  345:     */     
/*  346: 496 */     MobileMboDataBean multiBean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*  347: 499 */     if ((tkBean != null) && (multiBean != null) && (!tkBean.getValue("TICKETID").equalsIgnoreCase(multiBean.getValue("RECORDKEY")))) {
/*  348: 501 */       setTKLinearTab(event);
/*  349:     */     }
/*  350: 503 */     return true;
/*  351:     */   }
/*  352:     */   
/*  353:     */   protected boolean isLinearAssetMulti(UIEvent event)
/*  354:     */     throws MobileApplicationException
/*  355:     */   {
/*  356: 517 */     MobileMboDataBean dataBean = UIUtil.getCurrentScreen().getDataBean();
/*  357: 519 */     if (isWorkOrderOrSR(dataBean))
/*  358:     */     {
/*  359: 522 */       MobileMboDataBean multiAsset = dataBean.getDataBean("MULTIASSET");
/*  360: 523 */       if ((multiAsset != null) && (dataBean.getValue("ASSETNUM") != null) && (!dataBean.getValue("ASSETNUM").equals("")))
/*  361:     */       {
/*  362: 525 */         if (dataBean.getValue("ASSETNUM").equalsIgnoreCase(multiAsset.getValue("ASSETNUM")))
/*  363:     */         {
/*  364: 527 */           ((AbstractMobileControl)event.getCreatingObject()).setVisibility("1".equals(multiAsset.getValue("ISLINEAR")));
/*  365: 528 */           return true;
/*  366:     */         }
/*  367: 534 */         MobileMboDataBean assetBean = DataBeanCache.getDataBean("ASSET", "ASSET");
/*  368: 535 */         if (assetBean != null)
/*  369:     */         {
/*  370: 538 */           int currentPos = assetBean.getCurrentPosition();
/*  371: 539 */           MobileMboQBE qbe = assetBean.getQBE();
/*  372: 540 */           qbe.saveState();
/*  373: 541 */           qbe.setQBE("ASSETNUM", dataBean.getValue("ASSETNUM"));
/*  374: 542 */           qbe.setQBE("SITEID", dataBean.getValue("SITEID"));
/*  375: 543 */           assetBean.reset();
/*  376: 544 */           MobileMbo assetMbo = assetBean.getMobileMbo(0);
/*  377: 545 */           qbe.restoreState();
/*  378: 546 */           assetBean.reset();
/*  379: 547 */           assetBean.setCurrentPosition(currentPos);
/*  380: 548 */           if (assetMbo != null)
/*  381:     */           {
/*  382: 550 */             ((AbstractMobileControl)event.getCreatingObject()).setVisibility(assetMbo.getBooleanValue("ISLINEAR"));
/*  383: 551 */             return true;
/*  384:     */           }
/*  385:     */         }
/*  386:     */       }
/*  387:     */     }
/*  388: 557 */     ((AbstractMobileControl)event.getCreatingObject()).setVisibility(false);
/*  389: 558 */     return true;
/*  390:     */   }
/*  391:     */   
/*  392:     */   protected boolean initAssetFeatureLookup(UIEvent event)
/*  393:     */     throws MobileApplicationException
/*  394:     */   {
/*  395: 572 */     MobileMboDataBean dataBean = ((PageControl)event.getCreatingObject()).getLaunchingControl().getPage().getDataBean();
/*  396:     */     
/*  397: 574 */     MobileMboDataBean lookupDataBean = ((LookupControl)event.getCreatingObject()).getDataBean();
/*  398: 575 */     if ((dataBean != null) && (lookupDataBean != null))
/*  399:     */     {
/*  400: 578 */       lookupDataBean.getQBE().reset();
/*  401: 579 */       lookupDataBean.getQBE().setQbeExactMatch(true);
/*  402: 580 */       lookupDataBean.getQBE().setQBE("ASSETNUM", dataBean.getValue("ASSETNUM"));
/*  403: 581 */       lookupDataBean.getQBE().setQBE("SITEID", dataBean.getValue("SITEID"));
/*  404: 582 */       lookupDataBean.getQBE().setQBE("ISLINEARREF", "1");
/*  405:     */     }
/*  406: 585 */     lookupDataBean.reset();
/*  407: 586 */     return true;
/*  408:     */   }
/*  409:     */   
/*  410:     */   protected boolean isOffsetReadOnly(UIEvent event, String prefix)
/*  411:     */     throws MobileApplicationException
/*  412:     */   {
/*  413: 601 */     MobileMboDataBean multiBean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*  414: 602 */     if (multiBean != null) {
/*  415: 604 */       if ((multiBean.getValue(prefix + "FEATURELABEL") != null) && (multiBean.getValue(prefix + "FEATURELABEL").length() > 0))
/*  416:     */       {
/*  417: 607 */         ((AbstractMobileControl)event.getCreatingObject()).setReadonly(false);
/*  418: 608 */         return true;
/*  419:     */       }
/*  420:     */     }
/*  421: 611 */     ((AbstractMobileControl)event.getCreatingObject()).setReadonly(true);
/*  422:     */     
/*  423: 613 */     return true;
/*  424:     */   }
/*  425:     */   
/*  426:     */   protected boolean isMeasureReadOnly(UIEvent event, String prefix)
/*  427:     */     throws MobileApplicationException
/*  428:     */   {
/*  429: 627 */     MobileMboDataBean multiBean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*  430: 628 */     if (multiBean != null) {
/*  431: 630 */       if ((multiBean.getValue(prefix + "FEATURELABEL") != null) && (multiBean.getValue(prefix + "FEATURELABEL").length() > 0))
/*  432:     */       {
/*  433: 633 */         ((AbstractMobileControl)event.getCreatingObject()).setReadonly(true);
/*  434: 634 */         return true;
/*  435:     */       }
/*  436:     */     }
/*  437: 637 */     ((AbstractMobileControl)event.getCreatingObject()).setReadonly(false);
/*  438:     */     
/*  439: 639 */     return true;
/*  440:     */   }
/*  441:     */   
/*  442:     */   protected boolean checkHeaderFeatureLabel(UIEvent event)
/*  443:     */     throws MobileApplicationException
/*  444:     */   {
/*  445: 653 */     MobileMboDataBean multiBean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*  446: 654 */     String feature = (String)event.getValue();
/*  447: 655 */     if (multiBean != null) {
/*  448: 657 */       if ((feature != null) && (!feature.equals("")))
/*  449:     */       {
/*  450: 659 */         if (this.fromLookup)
/*  451:     */         {
/*  452: 663 */           this.fromLookup = false;
/*  453: 664 */           return true;
/*  454:     */         }
/*  455: 669 */         MobileMboDataBean assetFeatureBean = new MobileMboDataBeanManager("ASSETFEATURE").getDataBean();
/*  456: 670 */         int currentPos = assetFeatureBean.getCurrentPosition();
/*  457: 671 */         MobileMboQBE qbe = assetFeatureBean.getQBE();
/*  458: 672 */         qbe.saveState();
/*  459:     */         
/*  460: 674 */         qbe.setQBE("FEATURE", feature);
/*  461: 675 */         qbe.setQBE("ASSETNUM", multiBean.getValue("ASSETNUM"));
/*  462: 676 */         qbe.setQBE("SITEID", multiBean.getValue("SITEID"));
/*  463: 677 */         qbe.setQBE("ISLINEARREF", "1");
/*  464:     */         
/*  465: 679 */         assetFeatureBean.reset();
/*  466:     */         
/*  467: 681 */         MobileMbo assetFeatureMbo = assetFeatureBean.getMobileMbo(0);
/*  468: 682 */         boolean hasOnlyOneMbo = assetFeatureBean.getMobileMbo(1) == null;
/*  469: 683 */         qbe.restoreState();
/*  470: 684 */         assetFeatureBean.reset();
/*  471: 685 */         assetFeatureBean.setCurrentPosition(currentPos);
/*  472: 686 */         if (assetFeatureMbo != null)
/*  473:     */         {
/*  474: 688 */           if (hasOnlyOneMbo)
/*  475:     */           {
/*  476: 690 */             multiBean.setValue("STARTOFFSET", assetFeatureMbo.getValue("STARTOFFSET"));
/*  477: 691 */             multiBean.setValue("STARTMEASURE", assetFeatureMbo.getValue("STARTMEASURE"));
/*  478: 692 */             multiBean.setValue("ENDOFFSET", assetFeatureMbo.getValue("ENDOFFSET"));
/*  479: 693 */             multiBean.setValue("ENDMEASURE", assetFeatureMbo.getValue("ENDMEASURE"));
/*  480: 694 */             multiBean.setValue("STARTASSETFEATUREID", assetFeatureMbo.getValue("ASSETFEATUREID"));
/*  481: 695 */             multiBean.setValue("ENDASSETFEATUREID", assetFeatureMbo.getValue("ASSETFEATUREID"));
/*  482:     */           }
/*  483:     */           else
/*  484:     */           {
/*  485: 700 */             if (event.getMsgResponse().equals("-1"))
/*  486:     */             {
/*  487: 702 */               UIUtil.showOKCANCELMessageBox(event, MobileMessageGenerator.generate("morethanonevalue", null));
/*  488:     */               
/*  489: 704 */               event.setEventErrored();
/*  490: 705 */               return true;
/*  491:     */             }
/*  492: 707 */             if (event.getMsgResponse().equals("1"))
/*  493:     */             {
/*  494: 710 */               multiBean.setValue("FEATURE", "");
/*  495: 711 */               event.setEventErrored();
/*  496: 712 */               ((TextboxControl)event.getCreatingObject()).lookup(event);
/*  497: 713 */               return true;
/*  498:     */             }
/*  499: 715 */             if (event.getMsgResponse().equals("2")) {
/*  500: 717 */               event.setEventErrored();
/*  501:     */             }
/*  502:     */           }
/*  503:     */         }
/*  504:     */         else {
/*  505: 725 */           multiBean.setValue("FEATURELABEL", "");
/*  506:     */         }
/*  507:     */       }
/*  508:     */       else
/*  509:     */       {
/*  510: 732 */         multiBean.setValue("FEATURELABEL", "");
/*  511:     */         
/*  512: 734 */         MobileMboDataBean assetBean = DataBeanCache.getDataBean("ASSET", "ASSET");
/*  513: 735 */         int assetCurrentPos = assetBean.getCurrentPosition();
/*  514:     */         
/*  515: 737 */         MobileMboQBE qbe = assetBean.getQBE();
/*  516: 738 */         qbe.saveState();
/*  517: 739 */         qbe.setQBE("ASSETNUM", multiBean.getValue("ASSETNUM"));
/*  518: 740 */         qbe.setQBE("SITEID", multiBean.getValue("SITEID"));
/*  519: 741 */         assetBean.reset();
/*  520:     */         
/*  521: 743 */         MobileMbo assetMbo = assetBean.getMobileMbo(0);
/*  522: 744 */         if (assetMbo != null)
/*  523:     */         {
/*  524: 746 */           multiBean.setValue("STARTMEASURE", assetMbo.getValue("STARTMEASURE"));
/*  525: 747 */           multiBean.setValue("ENDMEASURE", assetMbo.getValue("ENDMEASURE"));
/*  526:     */         }
/*  527: 749 */         qbe.restoreState();
/*  528: 750 */         assetBean.reset();
/*  529: 751 */         assetBean.setCurrentPosition(assetCurrentPos);
/*  530:     */       }
/*  531:     */     }
/*  532: 754 */     return true;
/*  533:     */   }
/*  534:     */   
/*  535:     */   protected boolean checkFeatureLabel(UIEvent event, String prefix)
/*  536:     */     throws MobileApplicationException
/*  537:     */   {
/*  538: 769 */     MobileMboDataBean multiBean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*  539: 770 */     String featureLabel = (String)event.getValue();
/*  540: 771 */     if (multiBean != null)
/*  541:     */     {
/*  542: 773 */       if ((featureLabel != null) && (!featureLabel.equals("")))
/*  543:     */       {
/*  544: 775 */         if (this.fromLookup)
/*  545:     */         {
/*  546: 779 */           this.fromLookup = false;
/*  547: 780 */           return true;
/*  548:     */         }
/*  549: 783 */         MobileMboDataBean assetFeatureBean = DataBeanCache.getDataBean("ASSETFEATURE", "ASSETFEATURE");
/*  550: 784 */         int currentPos = assetFeatureBean.getCurrentPosition();
/*  551:     */         
/*  552: 786 */         MobileMboQBE qbe = assetFeatureBean.getQBE();
/*  553: 787 */         qbe.saveState();
/*  554:     */         
/*  555: 789 */         qbe.setQBE("LABEL", featureLabel);
/*  556: 790 */         qbe.setQBE("ASSETNUM", multiBean.getValue("ASSETNUM"));
/*  557: 791 */         qbe.setQBE("SITEID", multiBean.getValue("SITEID"));
/*  558: 792 */         qbe.setQBE("ISLINEARREF", "1");
/*  559: 793 */         assetFeatureBean.reset();
/*  560:     */         
/*  561: 795 */         MobileMbo assetFeatureMbo1 = assetFeatureBean.getMobileMbo(0);
/*  562: 796 */         MobileMbo assetFeatureMbo2 = assetFeatureBean.getMobileMbo(1);
/*  563: 797 */         qbe.restoreState();
/*  564: 798 */         assetFeatureBean.reset();
/*  565: 799 */         assetFeatureBean.setCurrentPosition(currentPos);
/*  566: 801 */         if (assetFeatureMbo1 != null)
/*  567:     */         {
/*  568: 803 */           if (assetFeatureMbo2 == null)
/*  569:     */           {
/*  570: 805 */             multiBean.setValue(prefix + "OFFSET", assetFeatureMbo1.getValue(prefix + "OFFSET"));
/*  571: 806 */             multiBean.setValue(prefix + "MEASURE", assetFeatureMbo1.getValue(prefix + "MEASURE"));
/*  572: 807 */             multiBean.setValue(prefix + "ASSETFEATUREID", assetFeatureMbo1.getValue("ASSETFEATUREID"));
/*  573:     */           }
/*  574:     */           else
/*  575:     */           {
/*  576: 812 */             if (event.getMsgResponse().equals("-1"))
/*  577:     */             {
/*  578: 814 */               UIUtil.showOKCANCELMessageBox(event, MobileMessageGenerator.generate("morethanonevalue", null));
/*  579: 815 */               return true;
/*  580:     */             }
/*  581: 817 */             if (event.getMsgResponse().equals("1"))
/*  582:     */             {
/*  583: 819 */               ((TextboxControl)event.getCreatingObject()).lookup(event);
/*  584: 820 */               return true;
/*  585:     */             }
/*  586:     */           }
/*  587:     */         }
/*  588:     */         else
/*  589:     */         {
/*  590: 828 */           multiBean.setValue(prefix + "OFFSET", "");
/*  591: 829 */           multiBean.setValue(prefix + "MEASURE", "");
/*  592: 830 */           multiBean.setValue(prefix + "ASSETFEATUREID", "");
/*  593:     */         }
/*  594: 833 */         return true;
/*  595:     */       }
/*  596: 840 */       multiBean.setValue(prefix + "ASSETFEATUREID", "");
/*  597: 841 */       multiBean.setValue(prefix + "OFFSET", "");
/*  598:     */       
/*  599: 843 */       MobileMboDataBean assetBean = DataBeanCache.getDataBean("ASSET", "ASSET");
/*  600:     */       
/*  601: 845 */       MobileMboQBE qbe = assetBean.getQBE();
/*  602: 846 */       qbe.saveState();
/*  603:     */       
/*  604: 848 */       qbe.setQBE("ASSETNUM", multiBean.getValue("ASSETNUM"));
/*  605: 849 */       qbe.setQBE("SITEID", multiBean.getValue("SITEID"));
/*  606: 850 */       assetBean.reset();
/*  607:     */       
/*  608: 852 */       MobileMbo assetMbo = assetBean.getMobileMbo(0);
/*  609: 853 */       if (assetMbo != null) {
/*  610: 855 */         multiBean.setValue(prefix + "MEASURE", assetMbo.getValue(prefix + "MEASURE"));
/*  611:     */       }
/*  612: 858 */       qbe.restoreState();
/*  613: 859 */       assetBean.reset();
/*  614:     */     }
/*  615: 863 */     return true;
/*  616:     */   }
/*  617:     */   
/*  618:     */   protected boolean calculateMeasure(UIEvent event, String prefix)
/*  619:     */     throws MobileApplicationException
/*  620:     */   {
/*  621: 878 */     MobileMboDataBean multiBean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*  622: 879 */     if (multiBean != null)
/*  623:     */     {
/*  624: 881 */       String offset = (String)event.getValue();
/*  625:     */       
/*  626: 883 */       multiBean.setValue(prefix + "OFFSET", offset, false);
/*  627: 884 */       if ((offset != null) && (offset.length() > 0))
/*  628:     */       {
/*  629: 888 */         MobileMboDataBean assetBean = new MobileMboDataBeanManager("ASSET").getDataBean();
/*  630: 889 */         MobileMboQBE qbe = assetBean.getQBE();
/*  631: 890 */         qbe.setQbeExactMatch(true);
/*  632: 891 */         qbe.setQBE("ASSETNUM", multiBean.getValue("ASSETNUM"));
/*  633: 892 */         qbe.setQBE("SITEID", multiBean.getValue("SITEID"));
/*  634: 893 */         assetBean.reset();
/*  635:     */         
/*  636: 895 */         MobileMbo assetMbo = assetBean.getMobileMbo(0);
/*  637:     */         
/*  638: 897 */         MobileMboDataBean assetFeatureBean = new MobileMboDataBeanManager("ASSETFEATURE").getDataBean();
/*  639: 898 */         qbe = assetFeatureBean.getQBE();
/*  640: 899 */         qbe.setQbeExactMatch(true);
/*  641: 900 */         qbe.setQBE("ASSETFEATUREID", multiBean.getValue(prefix + "ASSETFEATUREID"));
/*  642: 901 */         assetFeatureBean.reset();
/*  643:     */         
/*  644: 903 */         MobileMbo assetFeatureMbo = assetFeatureBean.getMobileMbo(0);
/*  645: 904 */         if ((assetMbo != null) && (assetFeatureMbo != null))
/*  646:     */         {
/*  647: 906 */           String measureStr = assetFeatureMbo.getValue(prefix + "MEASURE");
/*  648: 907 */           double measure = (measureStr != null) && (measureStr.length() > 0) ? DefaultMobileMboDataFormatter.stringToDouble(measureStr) : -1.0D;
/*  649: 908 */           if ((measureStr != null) && (measureStr.length() > 0))
/*  650:     */           {
/*  651: 912 */             String meaUnit = assetFeatureMbo.getValue(prefix + "MEASUREUNITID");
/*  652: 913 */             String offUnit = assetFeatureMbo.getValue(prefix + "OFFSETUNITID");
/*  653: 914 */             double conversion = getConversionFactor(offUnit, meaUnit);
/*  654:     */             
/*  655: 916 */             measure += DefaultMobileMboDataFormatter.stringToDouble(offset) * conversion;
/*  656: 917 */             if (verifyMeasureBoundaries(assetMbo.getValue("STARTMEASURE"), assetMbo.getValue("ENDMEASURE"), String.valueOf(measure)))
/*  657:     */             {
/*  658: 919 */               multiBean.getMobileMbo().setDoubleValue(prefix + "MEASURE", measure, false);
/*  659:     */             }
/*  660:     */             else
/*  661:     */             {
/*  662: 923 */               event.setEventErrored();
/*  663: 924 */               throw new MobileApplicationException("invalidoffset", new Object[] { formatPrefix(prefix), assetMbo.getValue("STARTMEASURE"), assetMbo.getValue("ENDMEASURE") });
/*  664:     */             }
/*  665:     */           }
/*  666:     */         }
/*  667:     */       }
/*  668:     */       else
/*  669:     */       {
/*  670: 933 */         MobileMboDataBean assetFeatureBean = DataBeanCache.getDataBean("ASSETFEATURE", "ASSETFEATURE");
/*  671: 934 */         int currentPos = assetFeatureBean.getCurrentPosition();
/*  672: 935 */         MobileMboQBE qbe = assetFeatureBean.getQBE();
/*  673: 936 */         qbe.saveState();
/*  674:     */         
/*  675: 938 */         qbe.setQBE("ASSETFEATUREID", multiBean.getValue(prefix + "ASSETFEATUREID"));
/*  676: 939 */         assetFeatureBean.reset();
/*  677:     */         
/*  678: 941 */         MobileMbo assetFeatureMbo = assetFeatureBean.getMobileMbo(0);
/*  679: 942 */         multiBean.getMobileMbo().setDoubleValue(prefix + "MEASURE", assetFeatureMbo.getDoubleValue(prefix + "MEASURE"), false);
/*  680:     */         
/*  681: 944 */         qbe.restoreState();
/*  682: 945 */         assetFeatureBean.reset();
/*  683: 946 */         assetFeatureBean.setCurrentPosition(currentPos);
/*  684:     */       }
/*  685:     */     }
/*  686: 949 */     return true;
/*  687:     */   }
/*  688:     */   
/*  689:     */   protected boolean validateMeasure(UIEvent event, String prefix)
/*  690:     */     throws MobileApplicationException
/*  691:     */   {
/*  692: 963 */     MobileMboDataBean assetBean = DataBeanCache.getDataBean("ASSET", "ASSET");
/*  693:     */     
/*  694: 965 */     MobileMboDataBean multiBean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*  695: 966 */     if ((assetBean != null) && (multiBean != null))
/*  696:     */     {
/*  697: 969 */       int currentPos = assetBean.getCurrentPosition();
/*  698: 970 */       assetBean.getQBE().saveState();
/*  699: 971 */       assetBean.getQBE().setQBE("SITEID", multiBean.getValue("SITEID"));
/*  700: 972 */       assetBean.getQBE().setQBE("ASSETNUM", multiBean.getValue("ASSETNUM"));
/*  701: 973 */       assetBean.reset();
/*  702: 974 */       MobileMbo assetMbo = assetBean.getMobileMbo();
/*  703: 975 */       if (assetMbo != null)
/*  704:     */       {
/*  705: 977 */         String measure = (String)event.getValue();
/*  706: 978 */         boolean valid = verifyMeasureBoundaries(assetMbo.getValue("STARTMEASURE"), assetMbo.getValue("ENDMEASURE"), measure);
/*  707: 979 */         if (!valid)
/*  708:     */         {
/*  709: 981 */           event.setEventErrored();
/*  710: 982 */           assetBean.getQBE().restoreState();
/*  711: 983 */           assetBean.reset();
/*  712: 984 */           assetBean.setCurrentPosition(currentPos);
/*  713: 985 */           throw new MobileApplicationException("invalidmeasure", new Object[] { formatPrefix(prefix), assetMbo.getValue("STARTMEASURE"), assetMbo.getValue("ENDMEASURE") });
/*  714:     */         }
/*  715:     */       }
/*  716: 988 */       assetBean.getQBE().restoreState();
/*  717: 989 */       assetBean.reset();
/*  718: 990 */       assetBean.setCurrentPosition(currentPos);
/*  719:     */     }
/*  720: 993 */     return true;
/*  721:     */   }
/*  722:     */   
/*  723:     */   protected boolean isLinearAsset(UIEvent event)
/*  724:     */     throws MobileApplicationException
/*  725:     */   {
/*  726:1006 */     MobileMboDataBean assetBean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*  727:1007 */     if (assetBean != null) {
/*  728:1009 */       ((AbstractMobileControl)event.getCreatingObject()).setVisibility("1".equals(assetBean.getValue("ISLINEAR")));
/*  729:     */     }
/*  730:1012 */     return true;
/*  731:     */   }
/*  732:     */   
/*  733:     */   protected boolean setProgressTab(UIEvent event)
/*  734:     */     throws MobileApplicationException
/*  735:     */   {
/*  736:1026 */     MobileMboDataBean prBean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*  737:1027 */     if ((prBean != null) && (prBean.getParentBean() != null))
/*  738:     */     {
/*  739:1029 */       MobileMboDataBean multiBean = prBean.getParentBean().getDataBean("WOMULTIASSETLOCCI");
/*  740:1030 */       if (multiBean != null)
/*  741:     */       {
/*  742:1033 */         prBean.getQBE().reset();
/*  743:1034 */         prBean.getQBE().setQBE("MULTIID", String.valueOf(DefaultMobileMboDataFormatter.stringToLong(multiBean.getValue("MULTIID"), Locale.getDefault())));
/*  744:1035 */         prBean.reset();
/*  745:     */       }
/*  746:     */     }
/*  747:1039 */     return true;
/*  748:     */   }
/*  749:     */   
/*  750:     */   protected boolean insertProgress(UIEvent event)
/*  751:     */     throws MobileApplicationException
/*  752:     */   {
/*  753:1053 */     MobileMboDataBean prBean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*  754:1055 */     if ((prBean != null) && (prBean.getParentBean() != null))
/*  755:     */     {
/*  756:1057 */       MobileMboDataBean multiBean = prBean.getParentBean().getDataBean("WOMULTIASSETLOCCI");
/*  757:1058 */       if (multiBean != null)
/*  758:     */       {
/*  759:1062 */         prBean.insert();
/*  760:1063 */         prBean.getMobileMbo().setLongValue("MULTIID", multiBean.getMobileMbo().getLongValue("MULTIID"));
/*  761:1064 */         prBean.getMobileMbo().setLongValue("STARTASSETFEATUREID", multiBean.getMobileMbo().getLongValue("STARTASSETFEATUREID"));
/*  762:1065 */         prBean.getMobileMbo().setLongValue("ENDASSETFEATUREID", multiBean.getMobileMbo().getLongValue("ENDASSETFEATUREID"));
/*  763:1066 */         prBean.setValue("ASSETNUM", multiBean.getValue("ASSETNUM"));
/*  764:1067 */         prBean.setValue("FEATURE", multiBean.getValue("FEATURE"));
/*  765:1068 */         prBean.setValue("FEATURELABEL", multiBean.getValue("FEATURELABEL"));
/*  766:1069 */         prBean.setValue("STARTFEATURELABEL", multiBean.getValue("STARTFEATURELABEL"));
/*  767:1070 */         prBean.getMobileMbo().setDoubleValue("STARTOFFSET", multiBean.getMobileMbo().getDoubleValue("STARTOFFSET"));
/*  768:1071 */         prBean.getMobileMbo().setDoubleValue("STARTMEASURE", multiBean.getMobileMbo().getDoubleValue("STARTMEASURE"));
/*  769:1072 */         prBean.setValue("ENDFEATURELABEL", multiBean.getValue("ENDFEATURELABEL"));
/*  770:1073 */         prBean.getMobileMbo().setDoubleValue("ENDOFFSET", multiBean.getMobileMbo().getDoubleValue("ENDOFFSET"));
/*  771:1074 */         prBean.getMobileMbo().setDoubleValue("ENDMEASURE", multiBean.getMobileMbo().getDoubleValue("ENDMEASURE"));
/*  772:1075 */         prBean.setValue("CHANGEBY", WOApp.getUsersPersonId());
/*  773:1076 */         prBean.getMobileMbo().setDateValue("CHANGEDATE", multiBean.getCurrentTime());
/*  774:     */         
/*  775:1078 */         UIUtil.refreshCurrentScreen();
/*  776:     */       }
/*  777:     */     }
/*  778:1081 */     return true;
/*  779:     */   }
/*  780:     */   
/*  781:     */   public static void setMultiLinearFields(MobileMboDataBean multiDataBean, MobileMbo assetMbo)
/*  782:     */     throws MobileApplicationException
/*  783:     */   {
/*  784:1095 */     if ((multiDataBean != null) && (assetMbo != null)) {
/*  785:1098 */       if (("1".equals(assetMbo.getValue("ISLINEAR"))) && (isWorkOrderOrSR(multiDataBean)))
/*  786:     */       {
/*  787:1100 */         multiDataBean.setValue("FEATURE", "");
/*  788:1101 */         multiDataBean.setValue("FEATURELABEL", "");
/*  789:1102 */         multiDataBean.setValue("ASSETFEATUREID", "");
/*  790:     */         
/*  791:1104 */         multiDataBean.setValue("ASSETLRM", assetMbo.getValue("LRM"), false);
/*  792:1105 */         multiDataBean.setValue("STARTFEATURELABEL", "");
/*  793:1106 */         multiDataBean.setValue("STARTOFFSET", "");
/*  794:1107 */         multiDataBean.setValue("STARTMEASURE", assetMbo.getValue("STARTMEASURE"));
/*  795:1108 */         multiDataBean.setValue("STARTYOFFSET", "");
/*  796:1109 */         multiDataBean.setValue("ENDFEATURELABEL", "");
/*  797:1110 */         multiDataBean.setValue("ENDOFFSET", "");
/*  798:1111 */         multiDataBean.setValue("ENDMEASURE", assetMbo.getValue("ENDMEASURE"));
/*  799:1112 */         multiDataBean.setValue("ENDYOFFSET", "");
/*  800:     */         
/*  801:1114 */         multiDataBean.setValue("STARTZOFFSET", "");
/*  802:1115 */         multiDataBean.setValue("ENDZOFFSET", "");
/*  803:     */         
/*  804:     */ 
/*  805:1118 */         MobileMboDataBean linrefbean = DataBeanCache.getDataBean("LINEARREFMETHOD", "LINEARREFMETHOD");
/*  806:1119 */         if (linrefbean != null)
/*  807:     */         {
/*  808:1122 */           int currentPos = linrefbean.getCurrentPosition();
/*  809:1123 */           linrefbean.getQBE().saveState();
/*  810:1124 */           linrefbean.getQBE().setQBE("LRM", assetMbo.getValue("LRM"));
/*  811:1125 */           linrefbean.reset();
/*  812:1126 */           MobileMbo linrefmbo = linrefbean.getMobileMbo();
/*  813:1127 */           if (linrefmbo != null)
/*  814:     */           {
/*  815:1129 */             multiDataBean.setValue("STARTYOFFSETREF", linrefmbo.getValue("YOFFSETREF"));
/*  816:1130 */             multiDataBean.setValue("STARTZOFFSETREF", linrefmbo.getValue("ZOFFSETREF"));
/*  817:1131 */             multiDataBean.setValue("ENDYOFFSETREF", linrefmbo.getValue("YOFFSETREF"));
/*  818:1132 */             multiDataBean.setValue("ENDZOFFSETREF", linrefmbo.getValue("ZOFFSETREF"));
/*  819:1133 */             multiDataBean.setValue("YOFFSETMEASUREUNITID", linrefmbo.getValue("YOFFSETMEASUREUNITID"));
/*  820:1134 */             multiDataBean.setValue("ZOFFSETMEASUREUNITID", linrefmbo.getValue("ZOFFSETMEASUREUNITID"));
/*  821:1135 */             multiDataBean.setValue("STARTMEASUREUNITID", linrefmbo.getValue("MEASUREUNITID"));
/*  822:1136 */             multiDataBean.setValue("ENDMEASUREUNITID", linrefmbo.getValue("MEASUREUNITID"));
/*  823:1137 */             multiDataBean.setValue("STARTOFFSETUNITID", linrefmbo.getValue("OFFSETMEASUREUNITID"));
/*  824:1138 */             multiDataBean.setValue("ENDOFFSETUNITID", linrefmbo.getValue("OFFSETMEASUREUNITID"));
/*  825:     */           }
/*  826:1141 */           linrefbean.getQBE().restoreState();
/*  827:1142 */           linrefbean.reset();
/*  828:1143 */           linrefbean.setCurrentPosition(currentPos);
/*  829:     */         }
/*  830:     */       }
/*  831:     */       else
/*  832:     */       {
/*  833:1150 */         clearLinearFields(multiDataBean);
/*  834:     */       }
/*  835:     */     }
/*  836:     */   }
/*  837:     */   
/*  838:     */   private static void clearLinearFields(MobileMboDataBean multiDataBean)
/*  839:     */     throws MobileApplicationException
/*  840:     */   {
/*  841:1164 */     multiDataBean.setValue("FEATURE", "");
/*  842:1165 */     multiDataBean.setValue("FEATURELABEL", "");
/*  843:1166 */     multiDataBean.setValue("ASSETFEATUREID", "");
/*  844:1167 */     multiDataBean.setValue("ASSETLRM", "", false);
/*  845:1168 */     multiDataBean.setValue("STARTFEATURELABEL", "");
/*  846:1169 */     multiDataBean.setValue("STARTOFFSET", "");
/*  847:1170 */     multiDataBean.setValue("STARTMEASURE", "");
/*  848:1171 */     multiDataBean.setValue("STARTYOFFSET", "");
/*  849:1172 */     multiDataBean.setValue("ENDFEATURELABEL", "");
/*  850:1173 */     multiDataBean.setValue("ENDOFFSET", "");
/*  851:1174 */     multiDataBean.setValue("ENDMEASURE", "");
/*  852:1175 */     multiDataBean.setValue("ENDYOFFSET", "");
/*  853:1176 */     multiDataBean.setValue("STARTZOFFSET", "");
/*  854:1177 */     multiDataBean.setValue("ENDZOFFSET", "");
/*  855:1178 */     multiDataBean.setValue("STARTYOFFSETREF", "");
/*  856:1179 */     multiDataBean.setValue("STARTZOFFSETREF", "");
/*  857:1180 */     multiDataBean.setValue("ENDYOFFSETREF", "");
/*  858:1181 */     multiDataBean.setValue("ENDZOFFSETREF", "");
/*  859:1182 */     multiDataBean.setValue("YOFFSETMEASUREUNITID", "");
/*  860:1183 */     multiDataBean.setValue("ZOFFSETMEASUREUNITID", "");
/*  861:1184 */     multiDataBean.setValue("STARTMEASUREUNITID", "");
/*  862:1185 */     multiDataBean.setValue("ENDMEASUREUNITID", "");
/*  863:1186 */     multiDataBean.setValue("STARTOFFSETUNITID", "");
/*  864:1187 */     multiDataBean.setValue("ENDOFFSETUNITID", "");
/*  865:     */   }
/*  866:     */   
/*  867:     */   private boolean verifyMeasureBoundaries(String startMeasure, String endMeasure, String measure)
/*  868:     */     throws MobileApplicationException
/*  869:     */   {
/*  870:1201 */     double sM = 0.0D;
/*  871:1202 */     double eM = 0.0D;
/*  872:1203 */     double me = 0.0D;
/*  873:1204 */     if ((startMeasure != null) && (startMeasure.length() > 0)) {
/*  874:1206 */       sM = DefaultMobileMboDataFormatter.stringToDouble(startMeasure);
/*  875:     */     }
/*  876:1208 */     if ((endMeasure != null) && (endMeasure.length() > 0)) {
/*  877:1210 */       eM = DefaultMobileMboDataFormatter.stringToDouble(endMeasure);
/*  878:     */     }
/*  879:1212 */     if ((measure != null) && (measure.length() > 0)) {
/*  880:1214 */       me = DefaultMobileMboDataFormatter.stringToDouble(measure);
/*  881:     */     }
/*  882:1216 */     if ((me >= sM) && (me <= eM)) {
/*  883:1218 */       return true;
/*  884:     */     }
/*  885:1221 */     return false;
/*  886:     */   }
/*  887:     */   
/*  888:     */   private String formatPrefix(String prefix)
/*  889:     */   {
/*  890:1232 */     if (prefix != null) {
/*  891:1234 */       return prefix.substring(0, 1).toUpperCase() + prefix.substring(1, prefix.length()).toLowerCase();
/*  892:     */     }
/*  893:1236 */     return null;
/*  894:     */   }
/*  895:     */   
/*  896:     */   private static boolean isWorkOrderOrSR(MobileMboDataBean dataBean)
/*  897:     */     throws MobileApplicationException
/*  898:     */   {
/*  899:1249 */     if (dataBean != null)
/*  900:     */     {
/*  901:1251 */       String name = dataBean.getName();
/*  902:1252 */       if ("WORKORDER".equalsIgnoreCase(name)) {
/*  903:1254 */         return ((WOApp)UIUtil.getApplication()).getInternalValue(dataBean, "WOCLASS", dataBean.getValue("WOCLASS")).equalsIgnoreCase("WORKORDER");
/*  904:     */       }
/*  905:1256 */       if ("TICKET".equalsIgnoreCase(name)) {
/*  906:1258 */         return ((WOApp)UIUtil.getApplication()).getInternalValue(dataBean, "TKCLASS", dataBean.getValue("CLASS")).equalsIgnoreCase("SR");
/*  907:     */       }
/*  908:1260 */       if ("WOMULTIASSETLOCCI".equalsIgnoreCase(name)) {
/*  909:1262 */         return ((WOApp)UIUtil.getApplication()).getInternalValue(dataBean, "WOCLASS", dataBean.getValue("RECORDCLASS")).equalsIgnoreCase("WORKORDER");
/*  910:     */       }
/*  911:1264 */       if ("TKMULTIASSETLOCCI".equalsIgnoreCase(name)) {
/*  912:1266 */         return ((WOApp)UIUtil.getApplication()).getInternalValue(dataBean, "TKCLASS", dataBean.getValue("RECORDCLASS")).equalsIgnoreCase("SR");
/*  913:     */       }
/*  914:     */     }
/*  915:1269 */     return false;
/*  916:     */   }
/*  917:     */   
/*  918:     */   private double getConversionFactor(String fromUOM, String toUOM)
/*  919:     */     throws MobileApplicationException
/*  920:     */   {
/*  921:1276 */     if ((fromUOM.equals("")) || (toUOM.equals(""))) {
/*  922:1278 */       throw new MobileApplicationException("parametesAreRequired");
/*  923:     */     }
/*  924:1282 */     if (fromUOM.equals(toUOM)) {
/*  925:1284 */       return 1.0D;
/*  926:     */     }
/*  927:1287 */     MobileMboDataBeanManager dbm = new MobileMboDataBeanManager("CONVERSION");
/*  928:1288 */     MobileMboDataBean conversion = dbm.getDataBean();
/*  929:1289 */     conversion.reset();
/*  930:1290 */     conversion.getQBE().setQBE("FROMMEASUREUNIT", fromUOM);
/*  931:1291 */     conversion.getQBE().setQBE("TOMEASUREUNIT", toUOM);
/*  932:1292 */     conversion.reset();
/*  933:1295 */     if (conversion.count() >= 1)
/*  934:     */     {
/*  935:1297 */       String conversionStr = conversion.getValue("CONVERSION");
/*  936:1298 */       return DefaultMobileMboDataFormatter.stringToDouble(conversionStr);
/*  937:     */     }
/*  938:1303 */     conversion.getQBE().setQBE("FROMMEASUREUNIT", toUOM);
/*  939:1304 */     conversion.getQBE().setQBE("TOMEASUREUNIT", fromUOM);
/*  940:1305 */     conversion.reset();
/*  941:1308 */     if (conversion.count() >= 1)
/*  942:     */     {
/*  943:1310 */       String conversionStr = conversion.getValue("CONVERSION");
/*  944:1311 */       return 1.0D / DefaultMobileMboDataFormatter.stringToDouble(conversionStr);
/*  945:     */     }
/*  946:1315 */     Object[] err = { fromUOM, toUOM };
/*  947:1316 */     throw new MobileApplicationException("conversionDoesNotExist", err);
/*  948:     */   }
/*  949:     */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.mobilewo.LinearAssetEventHandler
 * JD-Core Version:    0.7.0.1
 */