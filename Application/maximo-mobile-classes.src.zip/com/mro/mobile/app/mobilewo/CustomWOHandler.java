/*   1:    */ package com.mro.mobile.app.mobilewo;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.app.AbstractMobileDeviceApplication;
/*   5:    */ import com.mro.mobile.app.AppEventHandler;
/*   6:    */ import com.mro.mobile.app.DefaultEventHandler;
/*   7:    */ import com.mro.mobile.mbo.MobileMbo;
/*   8:    */ import com.mro.mobile.ui.MobileMboDataBean;
/*   9:    */ import com.mro.mobile.ui.MobileMboDataBeanManager;
/*  10:    */ import com.mro.mobile.ui.UIHandlerManager;
/*  11:    */ import com.mro.mobile.ui.event.UIEvent;
/*  12:    */ import com.mro.mobile.ui.event.UIEventHandler;
/*  13:    */ import com.mro.mobile.ui.res.UIUtil;
/*  14:    */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*  15:    */ import com.mro.mobileapp.WOApp;
/*  16:    */ import java.io.PrintStream;
/*  17:    */ 
/*  18:    */ public class CustomWOHandler
/*  19:    */   extends DefaultEventHandler
/*  20:    */ {
/*  21:    */   private static final String mobileStatusList = "DISPATCH,TRAVEL,ONSITE,RETURN,START,ONHOLD,WOCOMP,COMP";
/*  22:    */   private static final String dispatchList = "TRAVEL";
/*  23:    */   private static final String travelList = "ONSITE,RETURN";
/*  24:    */   private static final String onsiteList = "START,RETURN";
/*  25:    */   private static final String startList = "ONHOLD,RETURN,WOCOMP";
/*  26:    */   private static final String onholdList = "START";
/*  27:    */   private static final String wocompList = "COMP";
/*  28:    */   
/*  29:    */   public boolean performEvent(UIEvent event)
/*  30:    */     throws MobileApplicationException
/*  31:    */   {
/*  32: 28 */     if (event != null)
/*  33:    */     {
/*  34: 29 */       String eventId = event.getEventName();
/*  35: 30 */       if (eventId.equalsIgnoreCase("filterstatusvalues")) {
/*  36: 31 */         return filterstatusvalues(event);
/*  37:    */       }
/*  38: 33 */       if (eventId.equalsIgnoreCase("filterreturncodevalues")) {
/*  39: 34 */         return filterreturncodevalues(event);
/*  40:    */       }
/*  41: 36 */       if (eventId.equalsIgnoreCase("capturesignature")) {
/*  42: 37 */         return interceptCaptureSignature(event);
/*  43:    */       }
/*  44: 39 */       if (eventId.equalsIgnoreCase("validateStatusChange")) {
/*  45: 40 */         return interceptValidateChangeStatus(event);
/*  46:    */       }
/*  47: 42 */       if (eventId.equals("validatepage")) {
/*  48: 43 */         return interceptValidateChangeStatusPage(event);
/*  49:    */       }
/*  50: 45 */       if (eventId.equals("mitigationcodechanged")) {
/*  51: 46 */         return interceptMitigationCodeChanged(event);
/*  52:    */       }
/*  53: 48 */       if (eventId.equals("hideIfNotRETURN")) {
/*  54: 49 */         return hideIfNotRETURN(event);
/*  55:    */       }
/*  56: 51 */       if (eventId.equals("hideIfNotCOMP")) {
/*  57: 52 */         return hideIfNotCOMP(event);
/*  58:    */       }
/*  59: 54 */       if (eventId.equals("readOnlyIfNotNew")) {
/*  60: 55 */         return readOnlyIfNotNew(event);
/*  61:    */       }
/*  62: 57 */       if (eventId.equalsIgnoreCase("createPrimaryMultiEntry")) {
/*  63: 58 */         return interceptCreatePrimaryMultiEntry(event);
/*  64:    */       }
/*  65:    */     }
/*  66: 62 */     return UIUtil.getAppEventHandler().performEvent(event);
/*  67:    */   }
/*  68:    */   
/*  69:    */   public boolean interceptValidateChangeStatusPage(UIEvent event)
/*  70:    */     throws MobileApplicationException
/*  71:    */   {
/*  72: 76 */     UIHandlerManager hMan = UIHandlerManager.getInstance();
/*  73: 77 */     UIEventHandler wochangestatushandler = hMan.getUIHandler("wochangestatushandler");
/*  74: 78 */     if (wochangestatushandler != null)
/*  75:    */     {
/*  76: 79 */       wochangestatushandler.performEvent(event);
/*  77: 80 */       MobileMboDataBean wodatabean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*  78: 81 */       String status = wodatabean.getValue("STATUS") == null ? "" : wodatabean.getValue("STATUS");
/*  79: 82 */       if (status != null)
/*  80:    */       {
/*  81: 84 */         if ((status.equalsIgnoreCase("START")) && (wodatabean.getValue("IRVOLDSTATUS").equals("ONSITE")))
/*  82:    */         {
/*  83: 85 */           wodatabean.getMobileMbo().setDateValue("ACTSTART", wodatabean.getCurrentTime());
/*  84:    */         }
/*  85: 88 */         else if (status.equalsIgnoreCase("WOCOMP"))
/*  86:    */         {
/*  87: 89 */           wodatabean.getMobileMbo().setDateValue("ACTFINISH", wodatabean.getCurrentTime());
/*  88:    */         }
/*  89: 91 */         else if (status.equalsIgnoreCase("RETURN"))
/*  90:    */         {
/*  91: 93 */           if (wodatabean.getValue("IRV_RETURNSTATUSCODE").length() == 0) {
/*  92: 94 */             throw new MobileApplicationException("irvReturnStatusCode");
/*  93:    */           }
/*  94: 97 */           MobileMboDataBean worklogBean = wodatabean.getDataBean("WORKLOG");
/*  95: 98 */           worklogBean.insert();
/*  96: 99 */           worklogBean.setValue("SITEID", wodatabean.getValue("SITEID"));
/*  97:100 */           worklogBean.setValue("RECORDKEY", wodatabean.getValue("WONUM"));
/*  98:101 */           worklogBean.setValue("CLASS", "WORKORDER");
/*  99:102 */           worklogBean.setValue("CREATEBY", UIUtil.getApplication().getCurrentUser().toUpperCase());
/* 100:103 */           worklogBean.getMobileMbo().setDateValue("CREATEDATE", wodatabean.getCurrentTime());
/* 101:104 */           worklogBean.setValue("LOGTYPE", "WORK");
/* 102:105 */           worklogBean.setValue("CLIENTVIEWABLE", "1");
/* 103:106 */           worklogBean.setValue("DESCRIPTION", "The work order was returned.");
/* 104:107 */           worklogBean.setValue("DESCRIPTION_LONGDESCRIPTION", "The work order was returned with the reason: " + wodatabean.getValue("IRV_RETURNSTATUSCODE"));
/* 105:    */           
/* 106:109 */           worklogBean.getDataBeanManager().save();
/* 107:    */         }
/* 108:111 */         else if (status.equalsIgnoreCase("COMP"))
/* 109:    */         {
/* 110:112 */           MobileMboDataBean attachments = wodatabean.getDataBean("WOATTACHMENTS");
/* 111:113 */           int attachmentCount = attachments.count();
/* 112:114 */           if (attachmentCount > 0)
/* 113:    */           {
/* 114:115 */             boolean signatureFound = false;
/* 115:116 */             for (int i = 0; i < attachmentCount; i++) {
/* 116:117 */               if (attachments.getMobileMbo(i).getBooleanValue("IRVISSIGNATURE"))
/* 117:    */               {
/* 118:118 */                 signatureFound = true;
/* 119:119 */                 break;
/* 120:    */               }
/* 121:    */             }
/* 122:122 */             if ((!signatureFound) && 
/* 123:123 */               (wodatabean.getValue("IRV_NOSIGNATURECODE").length() == 0)) {
/* 124:124 */               throw new MobileApplicationException("irvNoSignature");
/* 125:    */             }
/* 126:    */           }
/* 127:128 */           else if (wodatabean.getValue("IRV_NOSIGNATURECODE").length() == 0)
/* 128:    */           {
/* 129:129 */             throw new MobileApplicationException("irvNoSignature");
/* 130:    */           }
/* 131:    */         }
/* 132:150 */         else if (status.equalsIgnoreCase("START"))
/* 133:    */         {
/* 134:152 */           String riskAssessmentFlag = wodatabean.getValue("IRVRISKASSESSMENT");
/* 135:154 */           if ((riskAssessmentFlag == null) || (riskAssessmentFlag.trim().length() <= 0) || (riskAssessmentFlag.trim().equalsIgnoreCase("NO"))) {
/* 136:155 */             throw new MobileApplicationException("irvRAFReqd");
/* 137:    */           }
/* 138:    */         }
/* 139:159 */         wodatabean.getMobileMbo().setDateValue("NEWSTATUSASOFDATE", wodatabean.getCurrentTime());
/* 140:    */       }
/* 141:    */     }
/* 142:162 */     return true;
/* 143:    */   }
/* 144:    */   
/* 145:    */   public boolean interceptValidateChangeStatus(UIEvent event)
/* 146:    */     throws MobileApplicationException
/* 147:    */   {
/* 148:173 */     String status = (String)event.getValue();
/* 149:174 */     MobileMboDataBean wodatabean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/* 150:175 */     wodatabean.setValue("IRVOLDSTATUS", wodatabean.getValue("STATUS"));
/* 151:177 */     if ((status != null) && (status.equalsIgnoreCase("START")))
/* 152:    */     {
/* 153:179 */       String riskAssessmentFlag = wodatabean.getValue("IRVRISKASSESSMENT");
/* 154:181 */       if ((riskAssessmentFlag == null) || (riskAssessmentFlag.trim().length() <= 0) || (riskAssessmentFlag.trim().equalsIgnoreCase("NO"))) {
/* 155:182 */         throw new MobileApplicationException("irvRAFReqd");
/* 156:    */       }
/* 157:    */     }
/* 158:186 */     wodatabean.getMobileMbo().setDateValue("NEWSTATUSASOFDATE", wodatabean.getCurrentTime());
/* 159:    */     
/* 160:188 */     return true;
/* 161:    */   }
/* 162:    */   
/* 163:    */   public boolean interceptCaptureSignature(UIEvent event)
/* 164:    */     throws MobileApplicationException
/* 165:    */   {
/* 166:199 */     if (UIUtil.getAppEventHandler().performEvent(event))
/* 167:    */     {
/* 168:200 */       MobileMboDataBean databean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/* 169:201 */       if (databean != null)
/* 170:    */       {
/* 171:203 */         databean.getMobileMbo().setDateValue("CHANGEDATE", databean.getCurrentTime());
/* 172:204 */         databean.getMobileMbo().setBooleanValue("ISSIGNATURE", true);
/* 173:205 */         databean.getMobileMbo().setBooleanValue("IRVISSIGNATURE", true);
/* 174:    */       }
/* 175:    */     }
/* 176:208 */     return true;
/* 177:    */   }
/* 178:    */   
/* 179:    */   public boolean filterstatusvalues(UIEvent event)
/* 180:    */     throws MobileApplicationException
/* 181:    */   {
/* 182:220 */     MobileMboDataBean wodatabean = UIUtil.getCurrentScreen().getDataBean();
/* 183:221 */     String status = wodatabean.getValue("STATUS") == null ? "" : wodatabean.getValue("STATUS");
/* 184:223 */     if (wodatabean != null)
/* 185:    */     {
/* 186:224 */       MobileMboDataBean dropdownbean = (MobileMboDataBean)event.getValue();
/* 187:225 */       for (int i = dropdownbean.count() - 1; i >= 0; i--)
/* 188:    */       {
/* 189:226 */         System.out.println(dropdownbean.getValue(i, "VALUE"));
/* 190:    */         
/* 191:228 */         String ddValue = dropdownbean.getValue(i, "VALUE");
/* 192:229 */         if ((status.equals("DISPATCH")) && ("TRAVEL".indexOf(ddValue) == -1)) {
/* 193:230 */           dropdownbean.remove(i);
/* 194:231 */         } else if ((status.equals("TRAVEL")) && ("ONSITE,RETURN".indexOf(ddValue) == -1)) {
/* 195:232 */           dropdownbean.remove(i);
/* 196:233 */         } else if ((status.equals("ONSITE")) && ("START,RETURN".indexOf(ddValue) == -1)) {
/* 197:234 */           dropdownbean.remove(i);
/* 198:235 */         } else if ((status.equals("START")) && (("ONHOLD,RETURN,WOCOMP".indexOf(ddValue) == -1) || (ddValue.equals("COMP")))) {
/* 199:236 */           dropdownbean.remove(i);
/* 200:237 */         } else if ((status.equals("ONHOLD")) && ("START".indexOf(ddValue) == -1)) {
/* 201:238 */           dropdownbean.remove(i);
/* 202:239 */         } else if ((status.equals("WOCOMP")) && ("COMP".indexOf(ddValue) == -1)) {
/* 203:240 */           dropdownbean.remove(i);
/* 204:241 */         } else if ("DISPATCH,TRAVEL,ONSITE,RETURN,START,ONHOLD,WOCOMP,COMP".indexOf(ddValue) == -1) {
/* 205:242 */           dropdownbean.remove(i);
/* 206:    */         }
/* 207:    */       }
/* 208:    */     }
/* 209:247 */     return true;
/* 210:    */   }
/* 211:    */   
/* 212:    */   public boolean filterreturncodevalues(UIEvent event)
/* 213:    */     throws MobileApplicationException
/* 214:    */   {
/* 215:258 */     MobileMboDataBean wodatabean = UIUtil.getCurrentScreen().getDataBean();
/* 216:259 */     String status = wodatabean.getValue("STATUS") == null ? "" : wodatabean.getValue("STATUS");
/* 217:262 */     if (wodatabean != null)
/* 218:    */     {
/* 219:263 */       MobileMboDataBean dropdownbean = (MobileMboDataBean)event.getValue();
/* 220:264 */       for (int i = dropdownbean.count() - 1; i >= 0; i--)
/* 221:    */       {
/* 222:265 */         System.out.println(dropdownbean.getValue(i, "VALUE"));
/* 223:266 */         String ddValue = dropdownbean.getValue(i, "VALUE");
/* 224:267 */         if ((!status.equals("TRAVEL")) && (ddValue.equalsIgnoreCase("Abandon"))) {
/* 225:268 */           dropdownbean.remove(i);
/* 226:    */         }
/* 227:    */       }
/* 228:    */     }
/* 229:273 */     return true;
/* 230:    */   }
/* 231:    */   
/* 232:    */   public boolean hideIfNotRETURN(UIEvent event)
/* 233:    */     throws MobileApplicationException
/* 234:    */   {
/* 235:285 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/* 236:286 */     String status = databean.getValue("NEWSTATUSDISPLAY");
/* 237:288 */     if (status.equals("RETURN")) {
/* 238:289 */       ((AbstractMobileControl)event.getCreatingObject()).setVisibility(true);
/* 239:    */     } else {
/* 240:291 */       ((AbstractMobileControl)event.getCreatingObject()).setVisibility(false);
/* 241:    */     }
/* 242:293 */     return true;
/* 243:    */   }
/* 244:    */   
/* 245:    */   public boolean readOnlyIfNotNew(UIEvent event)
/* 246:    */     throws MobileApplicationException
/* 247:    */   {
/* 248:297 */     MobileMboDataBean wodatabean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/* 249:298 */     if (wodatabean != null)
/* 250:    */     {
/* 251:300 */       WOApp app = (WOApp)UIUtil.getApplication();
/* 252:301 */       String status = app.getInternalValue(wodatabean, "WOSTATUS", wodatabean.getValue("STATUS"));
/* 253:303 */       if (status.equals("WAPPR")) {
/* 254:304 */         ((AbstractMobileControl)event.getCreatingObject()).setReadonly(false);
/* 255:    */       } else {
/* 256:306 */         ((AbstractMobileControl)event.getCreatingObject()).setReadonly(true);
/* 257:    */       }
/* 258:    */     }
/* 259:309 */     return true;
/* 260:    */   }
/* 261:    */   
/* 262:    */   public boolean hideIfNotCOMP(UIEvent event)
/* 263:    */     throws MobileApplicationException
/* 264:    */   {
/* 265:320 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/* 266:321 */     String status = databean.getValue("NEWSTATUSDISPLAY");
/* 267:323 */     if (status.equals("COMP")) {
/* 268:324 */       ((AbstractMobileControl)event.getCreatingObject()).setVisibility(true);
/* 269:    */     } else {
/* 270:326 */       ((AbstractMobileControl)event.getCreatingObject()).setVisibility(false);
/* 271:    */     }
/* 272:328 */     return true;
/* 273:    */   }
/* 274:    */   
/* 275:    */   public boolean interceptMitigationCodeChanged(UIEvent event)
/* 276:    */     throws MobileApplicationException
/* 277:    */   {
/* 278:339 */     String mitigationCode = (String)event.getValue();
/* 279:340 */     MobileMboDataBean wodatabean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/* 280:    */     
/* 281:342 */     String excusingStatus = wodatabean.getValue("IRV_EXCSTATUS") == null ? "" : wodatabean.getValue("IRV_EXCSTATUS");
/* 282:344 */     if ((mitigationCode.trim().length() > 0) && 
/* 283:345 */       (excusingStatus.trim().length() <= 0)) {
/* 284:346 */       wodatabean.setValue("IRV_EXCSTATUS", "REQUESTED");
/* 285:    */     }
/* 286:350 */     return true;
/* 287:    */   }
/* 288:    */   
/* 289:    */   public boolean interceptCreatePrimaryMultiEntry(UIEvent event)
/* 290:    */     throws MobileApplicationException
/* 291:    */   {
/* 292:362 */     MobileMboDataBean wodatabean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/* 293:364 */     if (wodatabean.getValue("ASSETSITEID") == "")
/* 294:    */     {
/* 295:365 */       wodatabean.setValue("ASSETSITEID", wodatabean.getValue("SITEID"));
/* 296:366 */       wodatabean.setValue("ASSETORGID", wodatabean.getValue("ORGID"));
/* 297:    */     }
/* 298:370 */     if ((wodatabean.getValue("OWNERGROUP") == "") && (wodatabean.getValue("OWNER") == ""))
/* 299:    */     {
/* 300:371 */       wodatabean.setValue("NEWOWNERGROUP", "NSCSD");
/* 301:372 */       wodatabean.setValue("OWNERGROUP", "NSCSD");
/* 302:    */     }
/* 303:375 */     return true;
/* 304:    */   }
/* 305:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.mobilewo.CustomWOHandler
 * JD-Core Version:    0.7.0.1
 */