/*   1:    */ package com.mro.mobile.app.mobilewo;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.mbo.MobileMbo;
/*   5:    */ import com.mro.mobile.mbo.MobileMboOrder;
/*   6:    */ import com.mro.mobile.ui.DataBeanCache;
/*   7:    */ import com.mro.mobile.ui.MobileMboDataBean;
/*   8:    */ import com.mro.mobile.ui.MobileMboDataBeanManager;
/*   9:    */ import com.mro.mobile.ui.event.UIEvent;
/*  10:    */ import com.mro.mobile.ui.res.UIUtil;
/*  11:    */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*  12:    */ import com.mro.mobile.ui.res.controls.PageControl;
/*  13:    */ import com.mro.mobileapp.WOApp;
/*  14:    */ 
/*  15:    */ public class LockOutTagOutEventHandler
/*  16:    */   extends MobileWOCommonEventHandler
/*  17:    */ {
/*  18:    */   public boolean performEvent(UIEvent event)
/*  19:    */     throws MobileApplicationException
/*  20:    */   {
/*  21: 32 */     if (event == null) {
/*  22: 32 */       return false;
/*  23:    */     }
/*  24: 34 */     String eventId = event.getEventName();
/*  25: 36 */     if (eventId.equalsIgnoreCase("initPrecautionsTable")) {
/*  26: 38 */       return initPrecautionsTable(event);
/*  27:    */     }
/*  28: 40 */     if (eventId.equalsIgnoreCase("initTagOutTable")) {
/*  29: 42 */       return initTagOutTable(event);
/*  30:    */     }
/*  31: 44 */     if (eventId.equalsIgnoreCase("initLockOutTable")) {
/*  32: 46 */       return initLockOutTable(event);
/*  33:    */     }
/*  34: 48 */     if (eventId.equalsIgnoreCase("ORDERTAGSBYREMOVE")) {
/*  35: 50 */       return ORDERTAGSBYREMOVE(event);
/*  36:    */     }
/*  37: 52 */     if (eventId.equalsIgnoreCase("ORDERTASKSBYREMOVE")) {
/*  38: 54 */       return ORDERTASKSBYREMOVE(event);
/*  39:    */     }
/*  40: 56 */     if (eventId.equalsIgnoreCase("showprecautionslink")) {
/*  41: 58 */       return showprecautionslink(event);
/*  42:    */     }
/*  43: 60 */     if (eventId.equalsIgnoreCase("showtagoutlink")) {
/*  44: 62 */       return showtagoutlink(event);
/*  45:    */     }
/*  46: 64 */     if (eventId.equalsIgnoreCase("showlockoutlink")) {
/*  47: 66 */       return showlockoutlink(event);
/*  48:    */     }
/*  49: 68 */     if (eventId.equalsIgnoreCase("sort")) {
/*  50: 70 */       return sort(event);
/*  51:    */     }
/*  52: 73 */     if (eventId.equalsIgnoreCase("hideifnull")) {
/*  53: 75 */       return processPopUpMenuDisplay(event, true);
/*  54:    */     }
/*  55: 78 */     if (eventId.equalsIgnoreCase("hideifnotnull")) {
/*  56: 80 */       return processPopUpMenuDisplay(event, false);
/*  57:    */     }
/*  58: 83 */     super.performEvent(event);
/*  59:    */     
/*  60: 85 */     return false;
/*  61:    */   }
/*  62:    */   
/*  63:    */   private boolean processPopUpMenuDisplay(UIEvent event, boolean hideIfNull)
/*  64:    */     throws MobileApplicationException
/*  65:    */   {
/*  66: 93 */     MobileMboDataBean dataBean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*  67: 94 */     String currentFieldName = ((AbstractMobileControl)event.getCreatingObject()).getValue("dataattribute");
/*  68: 95 */     String currentValue = dataBean.getValue(currentFieldName);
/*  69: 96 */     boolean isNull = false;
/*  70: 98 */     if ((currentValue == null) || (currentValue.length() == 0)) {
/*  71:100 */       isNull = true;
/*  72:    */     }
/*  73:103 */     if (isNull) {
/*  74:105 */       ((AbstractMobileControl)event.getCreatingObject()).setVisibility(!hideIfNull);
/*  75:    */     } else {
/*  76:109 */       ((AbstractMobileControl)event.getCreatingObject()).setVisibility(hideIfNull);
/*  77:    */     }
/*  78:113 */     return true;
/*  79:    */   }
/*  80:    */   
/*  81:    */   public boolean initPrecautionsTable(UIEvent event)
/*  82:    */     throws MobileApplicationException
/*  83:    */   {
/*  84:119 */     MobileMboDataBean databean = ((PageControl)event.getCreatingObject()).getDataBean();
/*  85:    */     
/*  86:121 */     int count = databean.count();
/*  87:122 */     for (int i = 0; i < count; i++)
/*  88:    */     {
/*  89:125 */       MobileMboDataBean todatabean = databean.getDataBean(i, "WOPRECAUTIONS");
/*  90:126 */       if ((todatabean != null) && (todatabean.getMobileMbo(0) != null)) {
/*  91:128 */         databean.setValue(i, "DESCRIPTION", todatabean.getMobileMbo(0).getValue("DESCRIPTION"), false);
/*  92:    */       }
/*  93:    */     }
/*  94:132 */     databean.getDataBeanManager().save();
/*  95:    */     
/*  96:134 */     DataBeanCache.rebuild();
/*  97:    */     
/*  98:136 */     return true;
/*  99:    */   }
/* 100:    */   
/* 101:    */   public boolean initTagOutTable(UIEvent event)
/* 102:    */     throws MobileApplicationException
/* 103:    */   {
/* 104:142 */     MobileMboDataBean databean = ((PageControl)event.getCreatingObject()).getDataBean();
/* 105:143 */     int count = databean.count();
/* 106:144 */     for (int i = 0; i < count; i++)
/* 107:    */     {
/* 108:146 */       MobileMboDataBean todatabean = databean.getDataBean(i, "WOTAGOUT");
/* 109:147 */       if ((todatabean != null) && (todatabean.getMobileMbo(0) != null))
/* 110:    */       {
/* 111:149 */         databean.setValue(i, "LOCATION", todatabean.getMobileMbo(0).getValue("LOCATION"), false);
/* 112:150 */         databean.setValue(i, "ASSETNUM", todatabean.getMobileMbo(0).getValue("ASSETNUM"), false);
/* 113:151 */         databean.setValue(i, "REQUIREDSTATE", todatabean.getMobileMbo(0).getValue("REQUIREDSTATE"), false);
/* 114:152 */         databean.setValue(i, "DESCRIPTION", todatabean.getMobileMbo(0).getValue("DESCRIPTION"), false);
/* 115:    */       }
/* 116:    */     }
/* 117:155 */     databean.getDataBeanManager().save();
/* 118:    */     
/* 119:157 */     DataBeanCache.rebuild();
/* 120:    */     
/* 121:159 */     return initTable(event, "ORDERTAGSBYREMOVE");
/* 122:    */   }
/* 123:    */   
/* 124:    */   public boolean initLockOutTable(UIEvent event)
/* 125:    */     throws MobileApplicationException
/* 126:    */   {
/* 127:165 */     MobileMboDataBean databean = ((PageControl)event.getCreatingObject()).getDataBean();
/* 128:    */     
/* 129:167 */     int count = databean.count();
/* 130:168 */     for (int i = 0; i < count; i++)
/* 131:    */     {
/* 132:170 */       MobileMboDataBean todatabean = databean.getDataBean(i, "WOLOCKOUT");
/* 133:171 */       if ((todatabean != null) && (todatabean.getMobileMbo(0) != null))
/* 134:    */       {
/* 135:173 */         databean.setValue(i, "LOCATION", todatabean.getMobileMbo(0).getValue("LOCATION"), false);
/* 136:174 */         databean.setValue(i, "ASSETNUM", todatabean.getMobileMbo(0).getValue("ASSETNUM"), false);
/* 137:175 */         databean.setValue(i, "REQUIREDSTATE", todatabean.getMobileMbo(0).getValue("REQUIREDSTATE"), false);
/* 138:176 */         databean.setValue(i, "DEVICEDESCRIPTION", todatabean.getMobileMbo(0).getValue("DEVICEDESCRIPTION"), false);
/* 139:    */       }
/* 140:    */     }
/* 141:180 */     databean.getDataBeanManager().save();
/* 142:    */     
/* 143:182 */     DataBeanCache.rebuild();
/* 144:    */     
/* 145:184 */     return initTable(event, "ORDERTASKSBYREMOVE");
/* 146:    */   }
/* 147:    */   
/* 148:    */   public boolean initTable(UIEvent event, String woField)
/* 149:    */     throws MobileApplicationException
/* 150:    */   {
/* 151:189 */     MobileMboDataBean allflagsBean = WOApp.getWpAllFlags();
/* 152:    */     
/* 153:191 */     String showInRemoveOrder = "0";
/* 154:192 */     if (allflagsBean != null) {
/* 155:193 */       showInRemoveOrder = allflagsBean.getValue(woField);
/* 156:    */     }
/* 157:196 */     MobileMboDataBean databean = ((PageControl)event.getCreatingObject()).getDataBean();
/* 158:197 */     orderData(showInRemoveOrder, databean, woField);
/* 159:    */     
/* 160:199 */     return true;
/* 161:    */   }
/* 162:    */   
/* 163:    */   public boolean ORDERTAGSBYREMOVE(UIEvent event)
/* 164:    */     throws MobileApplicationException
/* 165:    */   {
/* 166:204 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/* 167:205 */     orderData((String)event.getValue(), databean, "ORDERTAGSBYREMOVE");
/* 168:    */     
/* 169:207 */     return true;
/* 170:    */   }
/* 171:    */   
/* 172:    */   public boolean ORDERTASKSBYREMOVE(UIEvent event)
/* 173:    */     throws MobileApplicationException
/* 174:    */   {
/* 175:212 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/* 176:213 */     orderData((String)event.getValue(), databean, "ORDERTASKSBYREMOVE");
/* 177:    */     
/* 178:215 */     return true;
/* 179:    */   }
/* 180:    */   
/* 181:    */   public boolean orderData(String checkValue, MobileMboDataBean databean, String woField)
/* 182:    */     throws MobileApplicationException
/* 183:    */   {
/* 184:220 */     MobileMboOrder mboOrder = new MobileMboOrder();
/* 185:222 */     if ((checkValue.equalsIgnoreCase("true")) || (checkValue.equals("1"))) {
/* 186:223 */       mboOrder.setOrder("REMOVESEQ", true);
/* 187:    */     } else {
/* 188:225 */       mboOrder.setOrder("APPLYSEQ", true);
/* 189:    */     }
/* 190:227 */     databean.reset();
/* 191:228 */     databean.setOrder(mboOrder);
/* 192:    */     
/* 193:230 */     MobileMboDataBean allflagsBean = WOApp.getWpAllFlags();
/* 194:231 */     if (allflagsBean != null)
/* 195:    */     {
/* 196:233 */       if ((checkValue.equals("true")) || (checkValue.equals("1"))) {
/* 197:234 */         allflagsBean.setValue(woField, "1");
/* 198:    */       } else {
/* 199:236 */         allflagsBean.setValue(woField, "0");
/* 200:    */       }
/* 201:237 */       allflagsBean.getDataBeanManager().save();
/* 202:    */     }
/* 203:240 */     UIUtil.refreshCurrentScreen();
/* 204:    */     
/* 205:242 */     return true;
/* 206:    */   }
/* 207:    */   
/* 208:    */   public boolean showprecautionslink(UIEvent event)
/* 209:    */     throws MobileApplicationException
/* 210:    */   {
/* 211:247 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/* 212:248 */     int count = databean.getDataBean("WOPRECAUTIONS").count();
/* 213:249 */     boolean bShow = false;
/* 214:251 */     if (count > 0) {
/* 215:252 */       bShow = true;
/* 216:    */     }
/* 217:254 */     ((AbstractMobileControl)event.getCreatingObject()).setVisibility(bShow);
/* 218:    */     
/* 219:256 */     return true;
/* 220:    */   }
/* 221:    */   
/* 222:    */   public boolean showtagoutlink(UIEvent event)
/* 223:    */     throws MobileApplicationException
/* 224:    */   {
/* 225:261 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/* 226:262 */     int count = databean.getDataBean("WOTAGOUTS").count();
/* 227:263 */     boolean bShow = false;
/* 228:265 */     if (count > 0) {
/* 229:266 */       bShow = true;
/* 230:    */     }
/* 231:268 */     ((AbstractMobileControl)event.getCreatingObject()).setVisibility(bShow);
/* 232:    */     
/* 233:270 */     return true;
/* 234:    */   }
/* 235:    */   
/* 236:    */   public boolean showlockoutlink(UIEvent event)
/* 237:    */     throws MobileApplicationException
/* 238:    */   {
/* 239:275 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/* 240:276 */     int count = databean.getDataBean("WOLOCKOUTTASKS").count();
/* 241:277 */     boolean bShow = false;
/* 242:279 */     if (count > 0) {
/* 243:280 */       bShow = true;
/* 244:    */     }
/* 245:282 */     ((AbstractMobileControl)event.getCreatingObject()).setVisibility(bShow);
/* 246:    */     
/* 247:284 */     return true;
/* 248:    */   }
/* 249:    */   
/* 250:    */   public boolean sort(UIEvent event)
/* 251:    */     throws MobileApplicationException
/* 252:    */   {
/* 253:289 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/* 254:    */     
/* 255:291 */     MobileMboDataBean allflagsBean = WOApp.getWpAllFlags();
/* 256:292 */     if (allflagsBean != null)
/* 257:    */     {
/* 258:294 */       String woField = "";
/* 259:295 */       if (databean.getName().equalsIgnoreCase("WOTAGOUTS")) {
/* 260:296 */         woField = "ORDERTAGSBYREMOVE";
/* 261:297 */       } else if (databean.getName().equalsIgnoreCase("WOLOCKOUTTASKS")) {
/* 262:298 */         woField = "ORDERTASKSBYREMOVE";
/* 263:    */       }
/* 264:300 */       if (!allflagsBean.getValue(woField).equalsIgnoreCase("0"))
/* 265:    */       {
/* 266:302 */         allflagsBean.setValue(woField, "0");
/* 267:303 */         allflagsBean.getDataBeanManager().save();
/* 268:304 */         UIUtil.refreshCurrentScreen();
/* 269:    */       }
/* 270:    */     }
/* 271:308 */     return false;
/* 272:    */   }
/* 273:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.mobilewo.LockOutTagOutEventHandler
 * JD-Core Version:    0.7.0.1
 */