/*   1:    */ package com.mro.mobile.app.mobilewo;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.ui.MobileMboDataBean;
/*   5:    */ import com.mro.mobile.ui.res.UIUtil;
/*   6:    */ import com.mro.mobileapp.WOApp;
/*   7:    */ 
/*   8:    */ public class TKStatusHandler
/*   9:    */ {
/*  10: 30 */   WOApp woapp = null;
/*  11: 33 */   MobileMboDataBean tkdatabean = null;
/*  12: 34 */   String statuslistname = null;
/*  13:    */   private static final String newList = "";
/*  14:    */   private static final String queuedList = "NEW,QUEUED,INPROG,PENDING,RESOLVED,CLOSED";
/*  15:    */   private static final String inprogList = "NEW,QUEUED,INPROG,PENDING,RESOLVED,CLOSED";
/*  16:    */   private static final String pendingList = "NEW,QUEUED,INPROG,PENDING,RESOLVED,CLOSED";
/*  17:    */   private static final String resolvedList = "NEW,QUEUED,INPROG,PENDING,RESOLVED,CLOSED";
/*  18:    */   private static final String closeList = "NEW,QUEUED,INPROG,PENDING,RESOLVED,CLOSED";
/*  19:    */   
/*  20:    */   public TKStatusHandler(WOApp app, MobileMboDataBean tkmdb, String statusListName)
/*  21:    */   {
/*  22: 39 */     this.woapp = app;
/*  23: 40 */     this.tkdatabean = tkmdb;
/*  24: 41 */     this.statuslistname = statusListName;
/*  25:    */   }
/*  26:    */   
/*  27:    */   private boolean possibleStatusChange(String currentMaxStatus, String desiredMaxStatus)
/*  28:    */     throws MobileApplicationException
/*  29:    */   {
/*  30: 58 */     if ((desiredMaxStatus.equals("NEW")) && ("".indexOf(currentMaxStatus) == -1)) {
/*  31: 60 */       return false;
/*  32:    */     }
/*  33: 62 */     if ((desiredMaxStatus.equals("QUEUED")) && ("NEW,QUEUED,INPROG,PENDING,RESOLVED,CLOSED".indexOf(currentMaxStatus) == -1)) {
/*  34: 64 */       return false;
/*  35:    */     }
/*  36: 66 */     if ((desiredMaxStatus.equals("INPROG")) && ("NEW,QUEUED,INPROG,PENDING,RESOLVED,CLOSED".indexOf(currentMaxStatus) == -1)) {
/*  37: 68 */       return false;
/*  38:    */     }
/*  39: 70 */     if ((desiredMaxStatus.equals("PENDING")) && ("NEW,QUEUED,INPROG,PENDING,RESOLVED,CLOSED".indexOf(currentMaxStatus) == -1)) {
/*  40: 72 */       return false;
/*  41:    */     }
/*  42: 74 */     if ((desiredMaxStatus.equals("RESOLVED")) && ("NEW,QUEUED,INPROG,PENDING,RESOLVED,CLOSED".indexOf(currentMaxStatus) == -1)) {
/*  43: 76 */       return false;
/*  44:    */     }
/*  45: 78 */     if ((desiredMaxStatus.equals("CLOSED")) && ("NEW,QUEUED,INPROG,PENDING,RESOLVED,CLOSED".indexOf(currentMaxStatus) == -1)) {
/*  46: 80 */       return false;
/*  47:    */     }
/*  48: 82 */     return true;
/*  49:    */   }
/*  50:    */   
/*  51:    */   public boolean canChangeStatus(String currentStatus, String desiredStatus)
/*  52:    */     throws MobileApplicationException
/*  53:    */   {
/*  54: 92 */     String currentMaxStatus = this.woapp.getInternalValue(this.tkdatabean, this.statuslistname, currentStatus);
/*  55: 93 */     String desiredMaxStatus = this.woapp.getInternalValue(this.tkdatabean, this.statuslistname, desiredStatus);
/*  56: 96 */     if ((desiredMaxStatus.equals("HISTEDIT")) || (desiredStatus.equals("HISTEDIT"))) {
/*  57: 98 */       return false;
/*  58:    */     }
/*  59:101 */     if (!possibleStatusChange(currentMaxStatus, desiredMaxStatus)) {
/*  60:102 */       return false;
/*  61:    */     }
/*  62:105 */     if (desiredMaxStatus.equals("PENDING"))
/*  63:    */     {
/*  64:106 */       if (!canPending(currentMaxStatus)) {
/*  65:106 */         return false;
/*  66:    */       }
/*  67:    */     }
/*  68:107 */     else if (desiredMaxStatus.equals("QUEUED"))
/*  69:    */     {
/*  70:108 */       if (!canQueue(currentMaxStatus)) {
/*  71:108 */         return false;
/*  72:    */       }
/*  73:    */     }
/*  74:109 */     else if (desiredMaxStatus.equals("RESOLVED"))
/*  75:    */     {
/*  76:110 */       if (!canResolve(currentMaxStatus)) {
/*  77:110 */         return false;
/*  78:    */       }
/*  79:    */     }
/*  80:111 */     else if (desiredMaxStatus.equals("INPROG"))
/*  81:    */     {
/*  82:112 */       if (!canInitiate(currentMaxStatus)) {
/*  83:112 */         return false;
/*  84:    */       }
/*  85:    */     }
/*  86:    */     else
/*  87:    */     {
/*  88:113 */       if (desiredMaxStatus.equals("CLOSED")) {
/*  89:114 */         return false;
/*  90:    */       }
/*  91:118 */       return false;
/*  92:    */     }
/*  93:122 */     String optionName = getOptionName(desiredMaxStatus);
/*  94:123 */     return checkUserSecurity(optionName);
/*  95:    */   }
/*  96:    */   
/*  97:    */   public boolean checkUserSecurity(String optionName)
/*  98:    */     throws MobileApplicationException
/*  99:    */   {
/* 100:132 */     if ((optionName == null) || (optionName.equals(""))) {
/* 101:132 */       return false;
/* 102:    */     }
/* 103:134 */     if (this.tkdatabean != null) {
/* 104:135 */       return this.tkdatabean.isOptionAuthorized(optionName);
/* 105:    */     }
/* 106:137 */     return this.woapp.isOptionAuthorized(optionName);
/* 107:    */   }
/* 108:    */   
/* 109:    */   public boolean isChangeOK(String currentStatus, String desiredStatus)
/* 110:    */     throws MobileApplicationException
/* 111:    */   {
/* 112:143 */     String desiredOptionName = getOptionName(desiredStatus);
/* 113:144 */     if (desiredOptionName == null) {
/* 114:145 */       return false;
/* 115:    */     }
/* 116:147 */     if (!checkUserSecurity(desiredOptionName)) {
/* 117:148 */       return false;
/* 118:    */     }
/* 119:150 */     return true;
/* 120:    */   }
/* 121:    */   
/* 122:    */   String getOptionName(String status)
/* 123:    */     throws MobileApplicationException
/* 124:    */   {
/* 125:164 */     String tkclass = ((WOApp)UIUtil.getApplication()).getInternalValue(this.tkdatabean, "TKCLASS", this.tkdatabean.getValue("CLASS"));
/* 126:167 */     if (tkclass.equalsIgnoreCase("SR"))
/* 127:    */     {
/* 128:169 */       if (status.equalsIgnoreCase("CLOSED")) {
/* 129:169 */         return "SRCLOSED";
/* 130:    */       }
/* 131:170 */       if (status.equalsIgnoreCase("INPROG")) {
/* 132:170 */         return "SRINPROG";
/* 133:    */       }
/* 134:171 */       if (status.equalsIgnoreCase("NEW")) {
/* 135:171 */         return "SRNEW";
/* 136:    */       }
/* 137:172 */       if (status.equalsIgnoreCase("PENDING")) {
/* 138:172 */         return "SRPENDING";
/* 139:    */       }
/* 140:173 */       if (status.equalsIgnoreCase("QUEUED")) {
/* 141:173 */         return "SRQUEUED";
/* 142:    */       }
/* 143:174 */       if (status.equalsIgnoreCase("RESOLVED")) {
/* 144:174 */         return "SRRESOLVED";
/* 145:    */       }
/* 146:    */     }
/* 147:177 */     else if (tkclass.equalsIgnoreCase("INCIDENT"))
/* 148:    */     {
/* 149:179 */       if (status.equalsIgnoreCase("CLOSED")) {
/* 150:179 */         return "INCLOSED";
/* 151:    */       }
/* 152:180 */       if (status.equalsIgnoreCase("INPROG")) {
/* 153:180 */         return "ININPROG";
/* 154:    */       }
/* 155:181 */       if (status.equalsIgnoreCase("NEW")) {
/* 156:181 */         return "INNEW";
/* 157:    */       }
/* 158:182 */       if (status.equalsIgnoreCase("PENDING")) {
/* 159:182 */         return "INPENDING";
/* 160:    */       }
/* 161:183 */       if (status.equalsIgnoreCase("QUEUED")) {
/* 162:183 */         return "INQUEUED";
/* 163:    */       }
/* 164:184 */       if (status.equalsIgnoreCase("RESOLVED")) {
/* 165:184 */         return "INRESOLVED";
/* 166:    */       }
/* 167:    */     }
/* 168:187 */     else if (tkclass.equalsIgnoreCase("PROBLEM"))
/* 169:    */     {
/* 170:189 */       if (status.equalsIgnoreCase("CLOSED")) {
/* 171:189 */         return "PRCLOSED";
/* 172:    */       }
/* 173:190 */       if (status.equalsIgnoreCase("INPROG")) {
/* 174:190 */         return "PRINPROG";
/* 175:    */       }
/* 176:191 */       if (status.equalsIgnoreCase("NEW")) {
/* 177:191 */         return "PRNEW";
/* 178:    */       }
/* 179:192 */       if (status.equalsIgnoreCase("PENDING")) {
/* 180:192 */         return "PRPENDING";
/* 181:    */       }
/* 182:193 */       if (status.equalsIgnoreCase("QUEUED")) {
/* 183:193 */         return "PRQUEUED";
/* 184:    */       }
/* 185:194 */       if (status.equalsIgnoreCase("RESOLVED")) {
/* 186:194 */         return "PRRESOLVED";
/* 187:    */       }
/* 188:    */     }
/* 189:197 */     return null;
/* 190:    */   }
/* 191:    */   
/* 192:    */   boolean canClose(String currentStatus)
/* 193:    */     throws MobileApplicationException
/* 194:    */   {
/* 195:206 */     if (!isChangeOK(currentStatus, "CLOSED")) {
/* 196:208 */       return false;
/* 197:    */     }
/* 198:210 */     return true;
/* 199:    */   }
/* 200:    */   
/* 201:    */   boolean canPending(String currentStatus)
/* 202:    */     throws MobileApplicationException
/* 203:    */   {
/* 204:220 */     if (!isChangeOK(currentStatus, "PENDING")) {
/* 205:222 */       return false;
/* 206:    */     }
/* 207:224 */     return true;
/* 208:    */   }
/* 209:    */   
/* 210:    */   boolean canQueue(String currentStatus)
/* 211:    */     throws MobileApplicationException
/* 212:    */   {
/* 213:229 */     if (!isChangeOK(currentStatus, "QUEUED")) {
/* 214:231 */       return false;
/* 215:    */     }
/* 216:233 */     return true;
/* 217:    */   }
/* 218:    */   
/* 219:    */   boolean canResolve(String currentStatus)
/* 220:    */     throws MobileApplicationException
/* 221:    */   {
/* 222:238 */     if (!isChangeOK(currentStatus, "RESOLVED")) {
/* 223:240 */       return false;
/* 224:    */     }
/* 225:242 */     return true;
/* 226:    */   }
/* 227:    */   
/* 228:    */   boolean canInitiate(String currentStatus)
/* 229:    */     throws MobileApplicationException
/* 230:    */   {
/* 231:247 */     if (!isChangeOK(currentStatus, "INPROG")) {
/* 232:249 */       return false;
/* 233:    */     }
/* 234:251 */     return true;
/* 235:    */   }
/* 236:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.mobilewo.TKStatusHandler
 * JD-Core Version:    0.7.0.1
 */