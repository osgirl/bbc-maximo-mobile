/*   1:    */ package com.mro.mobile.app.mobilewo;
/*   2:    */ 
/*   3:    */ import com.ibm.tivoli.maximo.util.mboadapter.mobile.MobileMboAdapter;
/*   4:    */ import com.mro.mobile.MobileApplicationException;
/*   5:    */ import com.mro.mobile.MobileMessageGenerator;
/*   6:    */ import com.mro.mobile.app.DefaultMobileMboDataFormatter;
/*   7:    */ import com.mro.mobile.app.pluscmobwo.PlusCMobileWOToolTransDelegate;
/*   8:    */ import com.mro.mobile.mbo.MobileMbo;
/*   9:    */ import com.mro.mobile.mbo.MobileMboQBE;
/*  10:    */ import com.mro.mobile.persist.RDOException;
/*  11:    */ import com.mro.mobile.ui.DataBeanCache;
/*  12:    */ import com.mro.mobile.ui.MobileMboDataBean;
/*  13:    */ import com.mro.mobile.ui.MobileMboDataBeanManager;
/*  14:    */ import com.mro.mobile.ui.event.UIEvent;
/*  15:    */ import com.mro.mobile.ui.res.UIUtil;
/*  16:    */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*  17:    */ import com.mro.mobile.ui.res.controls.PageControl;
/*  18:    */ import com.mro.mobile.ui.res.controls.TextboxControl;
/*  19:    */ import com.mro.mobileapp.WOApp;
/*  20:    */ import java.util.Date;
/*  21:    */ import java.util.List;
/*  22:    */ 
/*  23:    */ public class WOToolTransEventHandler
/*  24:    */   extends MobileWOCommonEventHandler
/*  25:    */ {
/*  26:    */   public boolean performEvent(UIEvent event)
/*  27:    */     throws MobileApplicationException
/*  28:    */   {
/*  29: 41 */     if (event == null) {
/*  30: 41 */       return false;
/*  31:    */     }
/*  32: 43 */     String eventId = event.getEventName();
/*  33: 45 */     if (eventId.equalsIgnoreCase("validatepage")) {
/*  34: 47 */       return validatepage(event);
/*  35:    */     }
/*  36: 49 */     if (eventId.equalsIgnoreCase("inserttoolactual")) {
/*  37: 51 */       return inserttoolactual(event);
/*  38:    */     }
/*  39: 53 */     if (eventId.equalsIgnoreCase("validatetask")) {
/*  40: 54 */       return validateTask(event);
/*  41:    */     }
/*  42: 60 */     if (eventId.equalsIgnoreCase("lookup")) {
/*  43: 62 */       return lookup(event);
/*  44:    */     }
/*  45: 64 */     if (eventId.equalsIgnoreCase("setRequiredIfRotating")) {
/*  46: 67 */       return setRequiredIfRotating(event);
/*  47:    */     }
/*  48: 69 */     if (eventId.equalsIgnoreCase("initpagerotatingassetlookup")) {
/*  49: 72 */       return initPageRotatingAssetLookup(event);
/*  50:    */     }
/*  51: 74 */     if (eventId.equalsIgnoreCase("setItemNum")) {
/*  52: 77 */       return setItemNum(event);
/*  53:    */     }
/*  54: 80 */     if (eventId.equalsIgnoreCase("pluscfillduedate")) {
/*  55: 82 */       return pluscfillduedate(event);
/*  56:    */     }
/*  57: 86 */     super.performEvent(event);
/*  58:    */     
/*  59: 88 */     return false;
/*  60:    */   }
/*  61:    */   
/*  62:    */   protected boolean setItemNum(UIEvent event)
/*  63:    */     throws MobileApplicationException
/*  64:    */   {
/*  65:100 */     MobileMboDataBean toolDataBean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*  66:102 */     if ((!UIUtil.isNull((String)event.getValue())) && (UIUtil.isNull(toolDataBean.getValue("ITEMNUM"))))
/*  67:    */     {
/*  68:103 */       MobileMboDataBeanManager assetDBMgr = new MobileMboDataBeanManager("ASSET");
/*  69:104 */       MobileMboDataBean assetDataBean = assetDBMgr.getDataBean();
/*  70:105 */       assetDataBean.getQBE().setQBE("ASSETNUM", (String)event.getValue());
/*  71:106 */       assetDataBean.getQBE().setQbeExactMatch(true);
/*  72:107 */       assetDataBean.reset();
/*  73:108 */       MobileMbo assetMbo = assetDataBean.getMobileMbo(0);
/*  74:109 */       if (assetMbo != null) {
/*  75:110 */         toolDataBean.setValue("ITEMNUM", assetMbo.getValue("ITEMNUM"));
/*  76:    */       }
/*  77:    */     }
/*  78:114 */     return pluscfillduedate(event);
/*  79:    */   }
/*  80:    */   
/*  81:    */   protected boolean initPageRotatingAssetLookup(UIEvent event)
/*  82:    */     throws MobileApplicationException
/*  83:    */   {
/*  84:128 */     MobileMboDataBean assetDataBean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*  85:129 */     MobileMbo toolMbo = UIUtil.getCurrentScreen().getDataBean().getMobileMbo();
/*  86:131 */     if (UIUtil.isNull(toolMbo.getValue("ITEMNUM")))
/*  87:    */     {
/*  88:132 */       assetDataBean.getQBE().setQBE("ITEMNUM", "!=~NULL~");
/*  89:133 */       String itemType = ((WOApp)UIUtil.getApplication()).getInternalValue(assetDataBean, "ITEMTYPE", "TOOL");
/*  90:134 */       assetDataBean.getQBE().setQBE("ITEMTYPE", itemType);
/*  91:    */     }
/*  92:    */     else
/*  93:    */     {
/*  94:137 */       assetDataBean.getQBE().setQBE("ITEMNUM", toolMbo.getValue("ITEMNUM"));
/*  95:138 */       assetDataBean.getQBE().setQBE("ITEMSETID", toolMbo.getValue("ITEMSETID"));
/*  96:    */     }
/*  97:140 */     assetDataBean.getQBE().setQbeExactMatch(true);
/*  98:141 */     assetDataBean.reset();
/*  99:    */     
/* 100:143 */     return true;
/* 101:    */   }
/* 102:    */   
/* 103:    */   protected boolean setRequiredIfRotating(UIEvent event)
/* 104:    */     throws MobileApplicationException
/* 105:    */   {
/* 106:156 */     MobileMbo mbo = ((AbstractMobileControl)event.getCreatingObject()).getDataBean().getMobileMbo();
/* 107:158 */     if (mbo != null) {
/* 108:159 */       if (UIUtil.isNull(mbo.getValue("ITEMNUM")))
/* 109:    */       {
/* 110:161 */         mbo.setRequired("ROTASSETNUM", false);
/* 111:    */       }
/* 112:    */       else
/* 113:    */       {
/* 114:167 */         MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager("TOOL");
/* 115:168 */         MobileMboDataBean itemBean = mgrDBMgr.getDataBean();
/* 116:169 */         itemBean.getQBE().setQBE("ITEMNUM", mbo.getValue("ITEMNUM"));
/* 117:170 */         itemBean.getQBE().setQBE("ITEMSETID", mbo.getValue("ITEMSETID"));
/* 118:171 */         itemBean.getQBE().setQbeExactMatch(true);
/* 119:172 */         itemBean.reset();
/* 120:173 */         if (itemBean.getMobileMbo(0) == null) {
/* 121:175 */           mbo.setRequired("ROTASSETNUM", false);
/* 122:177 */         } else if (itemBean.getMobileMbo(0).getBooleanValue("ROTATING")) {
/* 123:179 */           mbo.setRequired("ROTASSETNUM", true);
/* 124:    */         } else {
/* 125:183 */           mbo.setRequired("ROTASSETNUM", false);
/* 126:    */         }
/* 127:    */       }
/* 128:    */     }
/* 129:187 */     return true;
/* 130:    */   }
/* 131:    */   
/* 132:    */   private boolean validateTask(UIEvent event)
/* 133:    */     throws MobileApplicationException
/* 134:    */   {
/* 135:192 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/* 136:193 */     MobileMboDataBeanManager wotasks = new MobileMboDataBeanManager("WOTASKS");
/* 137:194 */     MobileMboDataBean wotasksDataBean = wotasks.getDataBean();
/* 138:195 */     wotasksDataBean.getQBE().setQBE("TASKID", (String)event.getValue());
/* 139:196 */     wotasksDataBean.reset();
/* 140:197 */     MobileMbo wotasksMbo = wotasksDataBean.getMobileMbo();
/* 141:198 */     if (wotasksMbo != null)
/* 142:    */     {
/* 143:199 */       databean.setValue("TOOLHRS", wotasksMbo.getValue("ESTDUR"));
/* 144:200 */       return true;
/* 145:    */     }
/* 146:202 */     return false;
/* 147:    */   }
/* 148:    */   
/* 149:    */   public boolean validatepage(UIEvent event)
/* 150:    */     throws MobileApplicationException
/* 151:    */   {
/* 152:210 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/* 153:213 */     if (databean.isMobileMboReadOnly()) {
/* 154:215 */       return true;
/* 155:    */     }
/* 156:218 */     MobileMbo woToolTransMbo = databean.getMobileMbo();
/* 157:    */     
/* 158:    */ 
/* 159:    */ 
/* 160:    */ 
/* 161:    */ 
/* 162:    */ 
/* 163:    */ 
/* 164:    */ 
/* 165:    */ 
/* 166:    */ 
/* 167:    */ 
/* 168:    */ 
/* 169:    */ 
/* 170:232 */     MobileMboDataBeanManager mgrItemDataBean = new MobileMboDataBeanManager("PLUSCITEM");
/* 171:    */     
/* 172:234 */     MobileMboDataBean itemDataBean = mgrItemDataBean.getDataBean();
/* 173:    */     
/* 174:236 */     itemDataBean.getQBE().setQbeExactMatch(true);
/* 175:237 */     itemDataBean.getQBE().setQBE("ITEMNUM", woToolTransMbo.getValue("ITEMNUM"));
/* 176:238 */     itemDataBean.getQBE().setQBE("ITEMSETID", woToolTransMbo.getValue("ITEMSETID"));
/* 177:    */     
/* 178:240 */     MobileMbo itemMbo = itemDataBean.getMobileMbo(0);
/* 179:242 */     if ((woToolTransMbo.isNull("ROTASSETNUM")) || (woToolTransMbo.getValue("ROTASSETNUM").equalsIgnoreCase(""))) {
/* 180:244 */       if ((itemMbo != null) && (itemMbo.getBooleanValue("ROTATING")))
/* 181:    */       {
/* 182:246 */         woToolTransMbo.setRequired("ROTASSETNUM", true);
/* 183:247 */         UIUtil.refreshCurrentScreen();
/* 184:248 */         return false;
/* 185:    */       }
/* 186:    */     }
/* 187:254 */     MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager("ASSET");
/* 188:255 */     MobileMboDataBean assetBean = mgrDBMgr.getDataBean();
/* 189:256 */     assetBean.getQBE().setQBE("ASSETNUM", (String)event.getValue());
/* 190:257 */     assetBean.getQBE().setQBE("SITEID", woToolTransMbo.getValue("SITEID"));
/* 191:258 */     MobileMbo assetMbo = assetBean.getMobileMbo(0);
/* 192:260 */     if (assetMbo != null) {
/* 193:261 */       woToolTransMbo.setValue("ROTASSETSITE", assetMbo.getValue("SITEID"), false);
/* 194:    */     }
/* 195:264 */     String workTypeCal = null;
/* 196:    */     
/* 197:266 */     String itemNum = ((TextboxControl)UIUtil.findControl("wotooltrans_details_itemnum")).getControlValue();
/* 198:267 */     String plusctechnician = ((TextboxControl)UIUtil.findControl("wotooltrans_details_plusctechnician")).getControlValue();
/* 199:    */     
/* 200:269 */     String pluscduedate = ((TextboxControl)UIUtil.findControl("wotooltrans_details_pluscduedate")).getControlValue();
/* 201:270 */     String plusctoolusedate = ((TextboxControl)UIUtil.findControl("wotooltrans_details_plusctoolusedate")).getControlValue();
/* 202:271 */     Date duedate = pluscduedate.equalsIgnoreCase("") ? null : DefaultMobileMboDataFormatter.stringToDateTime(pluscduedate);
/* 203:    */     
/* 204:273 */     Date toolusedate = plusctoolusedate.equalsIgnoreCase("") ? null : DefaultMobileMboDataFormatter.stringToDateTime(plusctoolusedate);
/* 205:    */     
/* 206:    */ 
/* 207:    */ 
/* 208:277 */     String pluscqualtech = ((WOApp)UIUtil.getApplication()).getMaxVar(databean, "PLUSCQUALTECH");
/* 209:    */     
/* 210:    */ 
/* 211:280 */     String pluscpastdueval = ((WOApp)UIUtil.getApplication()).getMaxVar(databean, "PLUSCPASTDUEVAL");
/* 212:    */     
/* 213:282 */     MobileMboDataBean woDataBean = databean.getParentBean();
/* 214:284 */     if (pluscpastdueval.equals("1")) {
/* 215:287 */       if (woDataBean != null)
/* 216:    */       {
/* 217:289 */         if (woDataBean.getName().equals("WORKORDER")) {
/* 218:291 */           workTypeCal = ((WOApp)UIUtil.getApplication()).getMaxVar(databean, "PLUSCWORKTYPECAL");
/* 219:    */         }
/* 220:293 */         if (woDataBean.getMobileMbo().getValue("WORKTYPE").equals(workTypeCal)) {
/* 221:296 */           if (duedate != null)
/* 222:    */           {
/* 223:299 */             if (toolusedate == null) {
/* 224:303 */               toolusedate = databean.getCurrentTime();
/* 225:    */             }
/* 226:305 */             if (duedate.before(toolusedate)) {
/* 227:307 */               throw new MobileApplicationException("plusctoolpastduecal");
/* 228:    */             }
/* 229:    */           }
/* 230:    */         }
/* 231:    */       }
/* 232:    */     }
/* 233:314 */     if (!pluscqualtech.equals("0")) {
/* 234:317 */       if ((!itemNum.equals("")) && (!plusctechnician.equals("")))
/* 235:    */       {
/* 236:320 */         MobileMboDataBeanManager mgrToolQualDataBean = new MobileMboDataBeanManager("TOOLQUAL");
/* 237:321 */         MobileMboDataBean toolQualDataBean = mgrToolQualDataBean.getDataBean();
/* 238:322 */         toolQualDataBean.reset();
/* 239:323 */         toolQualDataBean.getQBE().setQbeExactMatch(true);
/* 240:324 */         toolQualDataBean.getQBE().setQBE("ITEMNUM", itemNum);
/* 241:325 */         toolQualDataBean.getQBE().setQBE("ITEMSETID", woToolTransMbo.getValue("ITEMSETID"));
/* 242:326 */         toolQualDataBean.reset();
/* 243:    */         
/* 244:328 */         MobileMbo toolQualMbo = null;
/* 245:329 */         int dloop = 0;
/* 246:330 */         boolean tecQualified = true;
/* 247:332 */         while ((toolQualMbo = toolQualDataBean.getMobileMbo(dloop)) != null)
/* 248:    */         {
/* 249:335 */           MobileMboDataBeanManager mgrLaborQualDataBean = new MobileMboDataBeanManager("LABORQUAL");
/* 250:336 */           MobileMboDataBean laborQualDataBean = mgrLaborQualDataBean.getDataBean();
/* 251:    */           
/* 252:338 */           laborQualDataBean.reset();
/* 253:339 */           laborQualDataBean.getQBE().setQbeExactMatch(true);
/* 254:340 */           laborQualDataBean.getQBE().setQBE("QUALIFICATIONID", toolQualMbo.getValue("QUALIFICATIONID"));
/* 255:341 */           laborQualDataBean.getQBE().setQBE("LABORCODE", plusctechnician);
/* 256:342 */           laborQualDataBean.reset();
/* 257:344 */           if (laborQualDataBean.count() == 0) {
/* 258:346 */             tecQualified = false;
/* 259:    */           }
/* 260:348 */           dloop++;
/* 261:    */         }
/* 262:351 */         if (!tecQualified) {
/* 263:353 */           if (pluscqualtech.equals("1"))
/* 264:    */           {
/* 265:355 */             String msg = MobileMessageGenerator.generate("pluscdescbox_Tech", null);
/* 266:    */             
/* 267:357 */             UIUtil.showMessageBoxControl("pluscdescbox", msg, event);
/* 268:    */           }
/* 269:359 */           else if (pluscqualtech.equals("2"))
/* 270:    */           {
/* 271:361 */             throw new MobileApplicationException("pluscqualtechwarn");
/* 272:    */           }
/* 273:    */         }
/* 274:    */       }
/* 275:    */     }
/* 276:370 */     if (!validateRotating(databean)) {
/* 277:371 */       throw new MobileApplicationException("requiredblank", new String[] { "Rotating Asset" });
/* 278:    */     }
/* 279:377 */     PlusCMobileWOToolTransDelegate toolTrans = new PlusCMobileWOToolTransDelegate(new MobileMboAdapter(woToolTransMbo, databean));
/* 280:    */     try
/* 281:    */     {
/* 282:380 */       toolTrans.validateBufferSolution();
/* 283:    */       
/* 284:382 */       toolTrans.validateDates();
/* 285:    */     }
/* 286:    */     catch (MobileApplicationException me)
/* 287:    */     {
/* 288:385 */       throw me;
/* 289:    */     }
/* 290:    */     catch (RuntimeException rte)
/* 291:    */     {
/* 292:386 */       throw rte;
/* 293:    */     }
/* 294:    */     catch (Exception e)
/* 295:    */     {
/* 296:388 */       e.printStackTrace();
/* 297:389 */       throw new MobileApplicationException("internalerror", e);
/* 298:    */     }
/* 299:397 */     MobileMboDataBean wodatabean = databean.getParentBean();
/* 300:400 */     if (databean.getValue("ACTUALSTASKID").equals(""))
/* 301:    */     {
/* 302:402 */       if (wodatabean.getValue("WOACCEPTSCHARGES").equals("0")) {
/* 303:403 */         throw new MobileApplicationException("WOAcceptsChargesNo");
/* 304:    */       }
/* 305:    */     }
/* 306:    */     else
/* 307:    */     {
/* 308:407 */       MobileMboDataBean wotasks = wodatabean.getDataBean("WOTASKS");
/* 309:408 */       int count = wotasks.count();
/* 310:409 */       for (int i = 0; i < count; i++) {
/* 311:411 */         if (wotasks.getMobileMbo(i).getValue("TASKID").equals(databean.getValue("ACTUALSTASKID")))
/* 312:    */         {
/* 313:413 */           if (!wotasks.getMobileMbo(i).getValue("WOACCEPTSCHARGES").equals("0")) {
/* 314:    */             break;
/* 315:    */           }
/* 316:414 */           throw new MobileApplicationException("TaskAcceptsChargesNo");
/* 317:    */         }
/* 318:    */       }
/* 319:    */     }
/* 320:421 */     return true;
/* 321:    */   }
/* 322:    */   
/* 323:    */   public boolean inserttoolactual(UIEvent event)
/* 324:    */     throws MobileApplicationException
/* 325:    */   {
/* 326:426 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/* 327:427 */     if (databean != null) {
/* 328:429 */       if (databean.getName().equals("WOTOOLTRANS"))
/* 329:    */       {
/* 330:431 */         databean.insert();
/* 331:432 */         databean.setValue("TOOLQTY", "1");
/* 332:    */         
/* 333:434 */         databean.setValue("TOOLHRS", "1");
/* 334:    */       }
/* 335:    */     }
/* 336:437 */     UIUtil.refreshCurrentScreen();
/* 337:438 */     return true;
/* 338:    */   }
/* 339:    */   
/* 340:    */   public boolean lookup(UIEvent event)
/* 341:    */     throws MobileApplicationException
/* 342:    */   {
/* 343:448 */     String fieldName = ((AbstractMobileControl)event.getCreatingObject()).getValue("dataattribute");
/* 344:452 */     if ((fieldName != null) && (!fieldName.equals(""))) {
/* 345:454 */       if (fieldName.equalsIgnoreCase("itemnum"))
/* 346:    */       {
/* 347:456 */         MobileMboDataBean databean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/* 348:457 */         MobileMbo mbo = databean.getMobileMbo();
/* 349:    */         
/* 350:459 */         MobileMboDataBean toolbean = DataBeanCache.findDataBean("TOOL");
/* 351:460 */         if (toolbean == null)
/* 352:    */         {
/* 353:462 */           MobileMboDataBeanManager mgrbean = new MobileMboDataBeanManager("TOOL");
/* 354:463 */           toolbean = mgrbean.getDataBean();
/* 355:464 */           DataBeanCache.cacheDataBean("TOOL", toolbean);
/* 356:    */         }
/* 357:467 */         ItemFilter filter = new ItemFilter(toolbean);
/* 358:468 */         List statusesInv = ItemFilter.translateItemStatusName(databean, new String[] { "ACTIVE", "PENDOBS" });
/* 359:469 */         List statusItemOrg = ItemFilter.translateItemStatusName(databean, new String[] { "ACTIVE" });
/* 360:    */         
/* 361:471 */         String woorgid = mbo.getValue("ORGID");
/* 362:    */         
/* 363:473 */         filter.applyItemOrgInfoFilter("TOOLITEMORGINFO", statusItemOrg, false, woorgid, "TOOLINVENTORY", statusesInv);
/* 364:    */         
/* 365:475 */         MobileMboQBE qbe = toolbean.getQBE();
/* 366:476 */         qbe.reset();
/* 367:477 */         qbe.setQbeExactMatch(true);
/* 368:478 */         qbe.setLookupParameter("WORKORDER", "ORGID", woorgid);
/* 369:479 */         qbe.setQBE("DISPLAY_IN_LOOKUP", "1");
/* 370:480 */         toolbean.reset();
/* 371:    */       }
/* 372:    */     }
/* 373:484 */     return false;
/* 374:    */   }
/* 375:    */   
/* 376:    */   public boolean pluscfillduedate(UIEvent event)
/* 377:    */     throws MobileApplicationException
/* 378:    */   {
/* 379:501 */     String thisControlValue = (String)event.getValue();
/* 380:503 */     if ((thisControlValue == null) || (thisControlValue.equalsIgnoreCase(""))) {
/* 381:505 */       return true;
/* 382:    */     }
/* 383:509 */     MobileMboDataBean woToolDataBean = UIUtil.getCurrentScreen().getDataBean();
/* 384:510 */     MobileMboDataBean woToolTransDataBean = ((PageControl)UIUtil.getCurrentScreen()).getLaunchingControl().getDataBean();
/* 385:    */     
/* 386:    */ 
/* 387:    */ 
/* 388:    */ 
/* 389:    */ 
/* 390:    */ 
/* 391:    */ 
/* 392:    */ 
/* 393:    */ 
/* 394:    */ 
/* 395:    */ 
/* 396:    */ 
/* 397:    */ 
/* 398:    */ 
/* 399:    */ 
/* 400:    */ 
/* 401:    */ 
/* 402:528 */     MobileMboDataBeanManager mgrPM = new MobileMboDataBeanManager("PM");
/* 403:529 */     MobileMboDataBean pmDataBean = mgrPM.getDataBean();
/* 404:    */     
/* 405:531 */     String workTypeCal = ((WOApp)UIUtil.getApplication()).getMaxVar(woToolTransDataBean, "PLUSCWORKTYPECAL");
/* 406:    */     
/* 407:533 */     pmDataBean.reset();
/* 408:534 */     pmDataBean.getQBE().setQbeExactMatch(true);
/* 409:535 */     pmDataBean.getQBE().setQBE("ASSETNUM", thisControlValue);
/* 410:536 */     pmDataBean.getQBE().setQBE("SITEID", woToolDataBean.getValue("SITEID"));
/* 411:537 */     pmDataBean.getQBE().setQBE("WORKTYPE", workTypeCal);
/* 412:538 */     pmDataBean.reset();
/* 413:540 */     if (pmDataBean.count() != 0)
/* 414:    */     {
/* 415:542 */       MobileMbo pmMbo = pmDataBean.getMobileMbo(0);
/* 416:543 */       if (pmMbo != null)
/* 417:    */       {
/* 418:545 */         Date nextCalDueDate = pmMbo.getDateValue("NEXTDATE");
/* 419:546 */         if (nextCalDueDate != null) {
/* 420:548 */           woToolTransDataBean.getMobileMbo(0).setDateValue("PLUSCDUEDATE", nextCalDueDate, false);
/* 421:    */         }
/* 422:    */       }
/* 423:    */     }
/* 424:555 */     return false;
/* 425:    */   }
/* 426:    */   
/* 427:    */   protected boolean validateRotating(MobileMboDataBean woToolTransDataBean)
/* 428:    */     throws MobileApplicationException, RDOException
/* 429:    */   {
/* 430:571 */     boolean retval = true;
/* 431:    */     
/* 432:573 */     String itemNum = woToolTransDataBean.getValue("ITEMNUM");
/* 433:574 */     if (itemNum != null)
/* 434:    */     {
/* 435:576 */       String itemSetId = woToolTransDataBean.getValue("ITEMSETID");
/* 436:    */       
/* 437:578 */       MobileMbo tool = getTool(itemNum, itemSetId);
/* 438:579 */       if ((tool != null) && (tool.getBooleanValue("ROTATING")))
/* 439:    */       {
/* 440:580 */         String rotAsset = woToolTransDataBean.getValue("ROTASSETNUM");
/* 441:581 */         if ((rotAsset == null) || (rotAsset.equals(""))) {
/* 442:582 */           retval = false;
/* 443:    */         }
/* 444:    */       }
/* 445:    */     }
/* 446:587 */     return retval;
/* 447:    */   }
/* 448:    */   
/* 449:    */   protected MobileMbo getTool(String itemNum, String itemSetId)
/* 450:    */     throws MobileApplicationException, RDOException
/* 451:    */   {
/* 452:604 */     MobileMboDataBeanManager toolsDataBeanMgr = new MobileMboDataBeanManager("TOOL");
/* 453:605 */     MobileMboDataBean tools = toolsDataBeanMgr.getDataBean();
/* 454:    */     
/* 455:607 */     tools.reset();
/* 456:608 */     tools.getQBE().setQbeExactMatch(true);
/* 457:609 */     tools.getQBE().setQBE("ITEMSETID", itemSetId);
/* 458:610 */     tools.getQBE().setQBE("ITEMNUM", itemNum);
/* 459:611 */     tools.reset();
/* 460:    */     
/* 461:613 */     MobileMbo tool = tools.getMobileMbo();
/* 462:    */     
/* 463:615 */     return tool;
/* 464:    */   }
/* 465:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.mobilewo.WOToolTransEventHandler
 * JD-Core Version:    0.7.0.1
 */