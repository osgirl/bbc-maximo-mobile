/*   1:    */ package com.mro.mobile.app.mobilewo;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.MobileMessageGenerator;
/*   5:    */ import com.mro.mobile.app.BasicMobileDeviceUIApplication;
/*   6:    */ import com.mro.mobile.mbo.MobileMbo;
/*   7:    */ import com.mro.mobile.mbo.MobileMboQBE;
/*   8:    */ import com.mro.mobile.ui.DataBeanCache;
/*   9:    */ import com.mro.mobile.ui.MobileMboDataBean;
/*  10:    */ import com.mro.mobile.ui.MobileMboDataBeanManager;
/*  11:    */ import com.mro.mobile.ui.event.UIEvent;
/*  12:    */ import com.mro.mobile.ui.res.UIUtil;
/*  13:    */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*  14:    */ import java.util.Enumeration;
/*  15:    */ 
/*  16:    */ public class MultiAssetLocCIUGenericHandler
/*  17:    */ {
/*  18: 33 */   private String masterDataBean = null;
/*  19: 34 */   private String multiBean = null;
/*  20: 35 */   private String cachedMultiBean = null;
/*  21: 36 */   private String recordKeySourceField = null;
/*  22: 37 */   private String recordClassSourceField = null;
/*  23: 38 */   private String detailsPage = null;
/*  24: 40 */   private boolean refreshTable = false;
/*  25: 41 */   private boolean valueChanged = false;
/*  26: 42 */   private String previousAssetNum = null;
/*  27: 43 */   private String previousLocation = null;
/*  28: 45 */   private String currentAssetLocation = null;
/*  29:    */   
/*  30:    */   public void setMasterDataBean(String masterDataBean)
/*  31:    */   {
/*  32: 49 */     this.masterDataBean = masterDataBean;
/*  33:    */   }
/*  34:    */   
/*  35:    */   public void setMultiBean(String multiBean)
/*  36:    */   {
/*  37: 53 */     this.multiBean = multiBean;
/*  38:    */   }
/*  39:    */   
/*  40:    */   public void setCachedMultiBean(String cachedMultiBean)
/*  41:    */   {
/*  42: 57 */     this.cachedMultiBean = cachedMultiBean;
/*  43:    */   }
/*  44:    */   
/*  45:    */   public void setRecordKeySourceField(String recordKeySourceField)
/*  46:    */   {
/*  47: 61 */     this.recordKeySourceField = recordKeySourceField;
/*  48:    */   }
/*  49:    */   
/*  50:    */   public void setRecordClassSourceField(String recordClassSourceField)
/*  51:    */   {
/*  52: 65 */     this.recordClassSourceField = recordClassSourceField;
/*  53:    */   }
/*  54:    */   
/*  55:    */   public void setDetailsPage(String detailsPage)
/*  56:    */   {
/*  57: 69 */     this.detailsPage = detailsPage;
/*  58:    */   }
/*  59:    */   
/*  60:    */   public boolean insertmulti(UIEvent event)
/*  61:    */     throws MobileApplicationException
/*  62:    */   {
/*  63: 74 */     MobileMboDataBean databean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*  64: 75 */     if (databean != null)
/*  65:    */     {
/*  66: 77 */       if (!databean.isOptionAuthorized("ADDMULTI")) {
/*  67: 79 */         throw new MobileApplicationException("notauthorizedinsertmulti");
/*  68:    */       }
/*  69: 82 */       MobileMboDataBean multidatabean = DataBeanCache.findDataBean(this.cachedMultiBean);
/*  70: 84 */       if (UIUtil.checkESignature(event, multidatabean))
/*  71:    */       {
/*  72: 86 */         MobileMboDataBean maindatabean = DataBeanCache.findDataBean(this.masterDataBean);
/*  73: 87 */         multidatabean.insert();
/*  74:    */         
/*  75: 89 */         long uid = UIUtil.getApplication().getUniqueNumber(multidatabean.getName(), "_" + multidatabean.getName());
/*  76: 90 */         multidatabean.setValue("MULTIID", String.valueOf(uid));
/*  77:    */         
/*  78: 92 */         multidatabean.setValue("RECORDKEY", maindatabean.getValue(this.recordKeySourceField));
/*  79: 93 */         multidatabean.setValue("RECORDCLASS", maindatabean.getValue(this.recordClassSourceField));
/*  80: 94 */         multidatabean.setValue("WORKSITEID", maindatabean.getValue("SITEID"));
/*  81: 95 */         multidatabean.setValue("WORKORGID", maindatabean.getValue("ORGID"));
/*  82: 96 */         multidatabean.setValue("ISPRIMARY", "0");
/*  83:    */         
/*  84: 98 */         multidatabean.setValue("COPIED", "0");
/*  85:    */         
/*  86:    */ 
/*  87:    */ 
/*  88:    */ 
/*  89:    */ 
/*  90:    */ 
/*  91:    */ 
/*  92:    */ 
/*  93:    */ 
/*  94:    */ 
/*  95:109 */         UIUtil.gotoPageNoSave(this.detailsPage, UIUtil.getCurrentScreen());
/*  96:    */       }
/*  97:    */       else
/*  98:    */       {
/*  99:113 */         event.setEventErrored();
/* 100:114 */         return true;
/* 101:    */       }
/* 102:    */     }
/* 103:118 */     return true;
/* 104:    */   }
/* 105:    */   
/* 106:    */   public boolean refreshmultitable(UIEvent event)
/* 107:    */     throws MobileApplicationException
/* 108:    */   {
/* 109:123 */     MobileMboDataBean currentdatabean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/* 110:125 */     if (!this.refreshTable) {
/* 111:127 */       if ((currentdatabean != null) && (currentdatabean.getName().equalsIgnoreCase(this.multiBean)))
/* 112:    */       {
/* 113:129 */         MobileMboDataBean databean = DataBeanCache.findDataBean(this.cachedMultiBean);
/* 114:    */         
/* 115:    */ 
/* 116:132 */         databean.setValue("PROGRESS", currentdatabean.getValue("PROGRESS"));
/* 117:133 */         databean.getDataBeanManager().save();
/* 118:    */         
/* 119:135 */         MobileMboQBE qbe = databean.getQBE();
/* 120:    */         
/* 121:137 */         boolean isFiltered = databean.isFiltered();
/* 122:    */         
/* 123:139 */         qbe.setQbeExactMatch(true);
/* 124:140 */         if (isFiltered)
/* 125:    */         {
/* 126:142 */           MobileMboQBE qbeFilter = databean.getQBE();
/* 127:143 */           Enumeration qbeAttributes = qbeFilter.getQBEAttributes();
/* 128:144 */           while (qbeAttributes.hasMoreElements())
/* 129:    */           {
/* 130:146 */             String attrName = (String)qbeAttributes.nextElement();
/* 131:147 */             qbe.setQBE(attrName, qbeFilter.getQBE(attrName));
/* 132:    */           }
/* 133:    */         }
/* 134:151 */         qbe.setQBE("ISPRIMARY", "0");
/* 135:152 */         qbe.setQBE("_DELETED", "0");
/* 136:    */         
/* 137:154 */         databean.reset();
/* 138:    */         
/* 139:    */ 
/* 140:    */ 
/* 141:    */ 
/* 142:    */ 
/* 143:    */ 
/* 144:    */ 
/* 145:    */ 
/* 146:    */ 
/* 147:    */ 
/* 148:165 */         this.refreshTable = true;
/* 149:166 */         ((AbstractMobileControl)event.getCreatingObject()).refresh(event);
/* 150:167 */         this.refreshTable = false;
/* 151:    */       }
/* 152:    */     }
/* 153:170 */     return true;
/* 154:    */   }
/* 155:    */   
/* 156:    */   public boolean assetchanged(UIEvent event)
/* 157:    */     throws MobileApplicationException
/* 158:    */   {
/* 159:175 */     MobileMboDataBean databean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/* 160:176 */     if ((databean != null) && (event.getValue() != null) && (!event.getValue().equals("")))
/* 161:    */     {
/* 162:181 */       String currentLocation = databean.getValue("LOCATION");
/* 163:182 */       String assetLocation = databean.getValue("ASSETLOCATION");
/* 164:    */       
/* 165:184 */       MobileMboDataBeanManager mgr = new MobileMboDataBeanManager("ASSET");
/* 166:185 */       MobileMboDataBean assetbean = mgr.getDataBean();
/* 167:186 */       MobileMboQBE qbe = assetbean.getQBE();
/* 168:187 */       qbe.setQbeExactMatch(true);
/* 169:188 */       qbe.reset();
/* 170:189 */       qbe.setQBE("ASSETNUM", (String)event.getValue());
/* 171:190 */       qbe.setQBE("SITEID", databean.getValue("SITEID"));
/* 172:191 */       assetbean.reset();
/* 173:192 */       MobileMbo assetmbo = assetbean.getMobileMbo(0);
/* 174:    */       
/* 175:    */ 
/* 176:195 */       LinearAssetEventHandler.setMultiLinearFields(databean, assetmbo);
/* 177:200 */       if ((assetLocation == null) || (assetLocation.equals(""))) {
/* 178:203 */         if (assetmbo != null)
/* 179:    */         {
/* 180:205 */           assetLocation = assetmbo.getValue("LOCATION");
/* 181:    */         }
/* 182:    */         else
/* 183:    */         {
/* 184:212 */           this.previousAssetNum = ((String)event.getValue());
/* 185:    */           
/* 186:214 */           return true;
/* 187:    */         }
/* 188:    */       }
/* 189:217 */       if ((currentLocation == null) || (currentLocation.trim().equals("")))
/* 190:    */       {
/* 191:221 */         this.previousAssetNum = ((String)event.getValue());
/* 192:222 */         databean.setValue("LOCATION", assetLocation);
/* 193:223 */         this.previousLocation = assetLocation;
/* 194:    */       }
/* 195:    */       else
/* 196:    */       {
/* 197:225 */         if (!assetLocation.equalsIgnoreCase(currentLocation))
/* 198:    */         {
/* 199:228 */           if (event.getMsgResponse().equals("-1"))
/* 200:    */           {
/* 201:233 */             String newAssetLocation = event.getValue() + "|" + currentLocation;
/* 202:234 */             if ((this.currentAssetLocation != null) && (this.currentAssetLocation.equalsIgnoreCase(newAssetLocation))) {
/* 203:236 */               return true;
/* 204:    */             }
/* 205:240 */             this.currentAssetLocation = (event.getValue() + "|" + currentLocation);
/* 206:241 */             Object[] param = { assetLocation };
/* 207:242 */             UIUtil.showYESNOCANCELMessageBox(event, MobileMessageGenerator.generate("differentassetlocation", param));
/* 208:248 */             if (event.getInitialEvent() != null)
/* 209:    */             {
/* 210:250 */               UIEvent parentEvent = event.getInitialEvent();
/* 211:251 */               event.setInitialEvent(null);
/* 212:252 */               parentEvent.setInitialEvent(event);
/* 213:253 */               event = parentEvent;
/* 214:    */             }
/* 215:256 */             event.setEventErrored();
/* 216:257 */             return true;
/* 217:    */           }
/* 218:259 */           if (event.getMsgResponse().equals("1"))
/* 219:    */           {
/* 220:262 */             this.previousAssetNum = ((String)event.getValue());
/* 221:263 */             databean.setValue("LOCATION", assetLocation);
/* 222:264 */             this.previousLocation = assetLocation;
/* 223:    */             
/* 224:    */ 
/* 225:    */ 
/* 226:268 */             UIUtil.refreshCurrentScreen();
/* 227:    */           }
/* 228:270 */           else if (event.getMsgResponse().equals("0"))
/* 229:    */           {
/* 230:273 */             this.previousAssetNum = ((String)event.getValue());
/* 231:    */           }
/* 232:    */           else
/* 233:    */           {
/* 234:278 */             this.valueChanged = true;
/* 235:    */             
/* 236:    */ 
/* 237:    */ 
/* 238:282 */             UIUtil.refreshCurrentScreen();
/* 239:283 */             this.currentAssetLocation = null;
/* 240:    */           }
/* 241:285 */           databean.setValue("ASSETLOCATION", "");
/* 242:286 */           return true;
/* 243:    */         }
/* 244:290 */         this.currentAssetLocation = null;
/* 245:291 */         this.previousAssetNum = ((String)event.getValue());
/* 246:    */       }
/* 247:    */     }
/* 248:294 */     else if ("".equals(event.getValue()))
/* 249:    */     {
/* 250:296 */       this.currentAssetLocation = null;
/* 251:297 */       this.previousAssetNum = "";
/* 252:    */     }
/* 253:300 */     return true;
/* 254:    */   }
/* 255:    */   
/* 256:    */   public boolean checkchangedvalues(UIEvent event)
/* 257:    */     throws MobileApplicationException
/* 258:    */   {
/* 259:324 */     if (this.valueChanged)
/* 260:    */     {
/* 261:326 */       MobileMboDataBean databean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/* 262:327 */       if (databean != null)
/* 263:    */       {
/* 264:329 */         String currentAsset = this.previousAssetNum;
/* 265:330 */         String newAsset = databean.getValue("ASSETNUM");
/* 266:331 */         if ((currentAsset != null) && (!currentAsset.equals(newAsset))) {
/* 267:334 */           databean.setValue("ASSETNUM", currentAsset);
/* 268:    */         }
/* 269:337 */         String currentLocation = this.previousLocation;
/* 270:338 */         String newLocation = databean.getValue("LOCATION");
/* 271:339 */         if ((currentLocation != null) && (!currentLocation.equals(newLocation))) {
/* 272:342 */           databean.setValue("LOCATION", currentLocation);
/* 273:    */         }
/* 274:    */       }
/* 275:    */     }
/* 276:346 */     this.valueChanged = false;
/* 277:347 */     return true;
/* 278:    */   }
/* 279:    */   
/* 280:    */   public boolean validateMulti(UIEvent event)
/* 281:    */     throws MobileApplicationException
/* 282:    */   {
/* 283:352 */     MobileMboDataBean databean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/* 284:    */     
/* 285:354 */     String isPrimary = databean.getValue("ISPRIMARY");
/* 286:355 */     String assetNum = databean.getValue("ASSETNUM");
/* 287:356 */     String location = databean.getValue("LOCATION");
/* 288:357 */     String ciNum = databean.getValue("CINUM");
/* 289:358 */     String targetDesc = databean.getValue("TARGETDESC");
/* 290:360 */     if ((!isPrimary.equals("1")) && (UIUtil.isNull(assetNum)) && (UIUtil.isNull(location)) && (UIUtil.isNull(ciNum)) && (UIUtil.isNull(targetDesc))) {
/* 291:366 */       throw new MobileApplicationException("oneoffieldsrequired");
/* 292:    */     }
/* 293:368 */     if ((!UIUtil.isNull(assetNum)) || (!UIUtil.isNull(location))) {
/* 294:370 */       if (UIUtil.isNull(databean.getValue("SITEID"))) {
/* 295:372 */         throw new MobileApplicationException("multiassetsite");
/* 296:    */       }
/* 297:    */     }
/* 298:375 */     return true;
/* 299:    */   }
/* 300:    */   
/* 301:    */   public boolean deletemulti(UIEvent event)
/* 302:    */     throws MobileApplicationException
/* 303:    */   {
/* 304:380 */     MobileMboDataBean databean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/* 305:381 */     if ((databean != null) && (databean.getName().equalsIgnoreCase(this.multiBean)))
/* 306:    */     {
/* 307:383 */       if (event.getMsgResponse().equals("-1"))
/* 308:    */       {
/* 309:385 */         Object[] param = new Object[0];
/* 310:386 */         UIUtil.showOKCANCELMessageBox(event, MobileMessageGenerator.generate("confirmdelete", param));
/* 311:387 */         event.setEventErrored();
/* 312:388 */         return true;
/* 313:    */       }
/* 314:390 */       if (event.getMsgResponse().equals("1"))
/* 315:    */       {
/* 316:392 */         databean.delete();
/* 317:393 */         databean.getDataBeanManager().save();
/* 318:394 */         databean.reset();
/* 319:395 */         UIUtil.closePage();
/* 320:    */       }
/* 321:    */     }
/* 322:398 */     return true;
/* 323:    */   }
/* 324:    */   
/* 325:    */   public boolean candeletemulti(UIEvent event)
/* 326:    */     throws MobileApplicationException
/* 327:    */   {
/* 328:403 */     MobileMboDataBean databean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/* 329:404 */     MobileMbo mobileMbo = databean.getMobileMbo();
/* 330:405 */     if ((databean.getName().equalsIgnoreCase(this.multiBean)) && (mobileMbo != null))
/* 331:    */     {
/* 332:407 */       boolean candelete = (mobileMbo.isNew()) && (!mobileMbo.getBooleanValue("COPIED"));
/* 333:    */       
/* 334:    */ 
/* 335:410 */       ((AbstractMobileControl)event.getCreatingObject()).setVisibility(candelete);
/* 336:    */     }
/* 337:412 */     return true;
/* 338:    */   }
/* 339:    */   
/* 340:    */   public boolean locationchanged(UIEvent event)
/* 341:    */     throws MobileApplicationException
/* 342:    */   {
/* 343:417 */     MobileMboDataBean databean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/* 344:418 */     if ((databean != null) && (event.getValue() != null) && (!event.getValue().equals("")))
/* 345:    */     {
/* 346:422 */       String currentAsset = databean.getValue("ASSETNUM");
/* 347:423 */       String newLocation = (String)event.getValue();
/* 348:424 */       if ((currentAsset == null) || (currentAsset.trim().equals("")))
/* 349:    */       {
/* 350:426 */         this.previousLocation = newLocation;
/* 351:    */       }
/* 352:    */       else
/* 353:    */       {
/* 354:430 */         MobileMboDataBeanManager mgr = new MobileMboDataBeanManager("ASSET");
/* 355:431 */         MobileMboDataBean assetbean = mgr.getDataBean();
/* 356:432 */         MobileMboQBE qbe = assetbean.getQBE();
/* 357:433 */         qbe.setQbeExactMatch(true);
/* 358:434 */         qbe.reset();
/* 359:435 */         qbe.setQBE("LOCATION", newLocation);
/* 360:436 */         qbe.setQBE("ASSETNUM", currentAsset);
/* 361:437 */         assetbean.reset();
/* 362:438 */         if (assetbean.count() == 0)
/* 363:    */         {
/* 364:442 */           qbe.reset();
/* 365:443 */           qbe.setQBE("LOCATION", newLocation);
/* 366:444 */           assetbean.reset();
/* 367:446 */           if (assetbean.count() == 0)
/* 368:    */           {
/* 369:451 */             this.previousLocation = newLocation;
/* 370:452 */             return true;
/* 371:    */           }
/* 372:454 */           if (assetbean.count() == 1)
/* 373:    */           {
/* 374:458 */             String newAsset = assetbean.getValue("ASSETNUM");
/* 375:459 */             if (event.getMsgResponse().equals("-1"))
/* 376:    */             {
/* 377:463 */               String newAssetLocation = currentAsset + "|" + event.getValue();
/* 378:464 */               if ((this.currentAssetLocation != null) && (this.currentAssetLocation.equalsIgnoreCase(newAssetLocation))) {
/* 379:466 */                 return true;
/* 380:    */               }
/* 381:470 */               this.currentAssetLocation = (currentAsset + "|" + event.getValue());
/* 382:471 */               Object[] param = { newLocation };
/* 383:472 */               UIUtil.showYESNOCANCELMessageBox(event, MobileMessageGenerator.generate("locnotcontainassetone", param));
/* 384:478 */               if (event.getInitialEvent() != null)
/* 385:    */               {
/* 386:480 */                 UIEvent parentEvent = event.getInitialEvent();
/* 387:481 */                 event.setInitialEvent(null);
/* 388:482 */                 parentEvent.setInitialEvent(event);
/* 389:483 */                 event = parentEvent;
/* 390:    */               }
/* 391:486 */               event.setEventErrored();
/* 392:487 */               return true;
/* 393:    */             }
/* 394:489 */             if (event.getMsgResponse().equals("1"))
/* 395:    */             {
/* 396:492 */               this.previousLocation = newLocation;
/* 397:493 */               databean.setValue("ASSETNUM", newAsset);
/* 398:494 */               this.previousAssetNum = newAsset;
/* 399:    */               
/* 400:    */ 
/* 401:    */ 
/* 402:498 */               UIUtil.refreshCurrentScreen();
/* 403:    */             }
/* 404:500 */             else if (event.getMsgResponse().equals("0"))
/* 405:    */             {
/* 406:503 */               this.previousLocation = newLocation;
/* 407:    */             }
/* 408:    */             else
/* 409:    */             {
/* 410:508 */               this.valueChanged = true;
/* 411:    */               
/* 412:    */ 
/* 413:    */ 
/* 414:512 */               UIUtil.refreshCurrentScreen();
/* 415:513 */               this.currentAssetLocation = null;
/* 416:    */             }
/* 417:    */           }
/* 418:    */           else
/* 419:    */           {
/* 420:520 */             if (event.getMsgResponse().equals("-1"))
/* 421:    */             {
/* 422:524 */               String newAssetLocation = currentAsset + "|" + event.getValue();
/* 423:525 */               if ((this.currentAssetLocation != null) && (this.currentAssetLocation.equalsIgnoreCase(newAssetLocation))) {
/* 424:527 */                 return true;
/* 425:    */               }
/* 426:531 */               this.currentAssetLocation = (currentAsset + "|" + event.getValue());
/* 427:532 */               Object[] param = new Object[0];
/* 428:533 */               UIUtil.showYESNOCANCELMessageBox(event, MobileMessageGenerator.generate("locnotcontainassetmorethenone", param));
/* 429:539 */               if (event.getInitialEvent() != null)
/* 430:    */               {
/* 431:541 */                 UIEvent parentEvent = event.getInitialEvent();
/* 432:542 */                 event.setInitialEvent(null);
/* 433:543 */                 parentEvent.setInitialEvent(event);
/* 434:544 */                 event = parentEvent;
/* 435:    */               }
/* 436:547 */               event.setEventErrored();
/* 437:548 */               return true;
/* 438:    */             }
/* 439:550 */             if (event.getMsgResponse().equals("1"))
/* 440:    */             {
/* 441:553 */               this.previousLocation = newLocation;
/* 442:    */               
/* 443:555 */               databean.setValue("ASSETNUM", null);
/* 444:556 */               this.previousAssetNum = "";
/* 445:    */               
/* 446:    */ 
/* 447:    */ 
/* 448:560 */               UIUtil.refreshCurrentScreen();
/* 449:    */             }
/* 450:562 */             else if (event.getMsgResponse().equals("0"))
/* 451:    */             {
/* 452:565 */               this.previousLocation = newLocation;
/* 453:    */             }
/* 454:    */             else
/* 455:    */             {
/* 456:570 */               this.valueChanged = true;
/* 457:    */               
/* 458:    */ 
/* 459:    */ 
/* 460:574 */               UIUtil.refreshCurrentScreen();
/* 461:575 */               this.currentAssetLocation = null;
/* 462:    */             }
/* 463:    */           }
/* 464:    */         }
/* 465:    */         else
/* 466:    */         {
/* 467:583 */           this.currentAssetLocation = null;
/* 468:584 */           this.previousLocation = newLocation;
/* 469:    */         }
/* 470:586 */         return true;
/* 471:    */       }
/* 472:    */     }
/* 473:589 */     else if ("".equals(event.getValue()))
/* 474:    */     {
/* 475:591 */       this.currentAssetLocation = null;
/* 476:592 */       this.previousLocation = "";
/* 477:    */     }
/* 478:594 */     return true;
/* 479:    */   }
/* 480:    */   
/* 481:    */   public boolean cichanged(UIEvent event)
/* 482:    */     throws MobileApplicationException
/* 483:    */   {
/* 484:599 */     if ((event.getValue() != null) && (!event.getValue().equals("")))
/* 485:    */     {
/* 486:601 */       MobileMboDataBean databean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/* 487:602 */       if ((databean.getMobileMbo().isNull("ASSETNUM")) && (databean.getMobileMbo().isNull("LOCATION"))) {
/* 488:605 */         if (!databean.getMobileMbo().isNull("CIASSETNUM")) {
/* 489:607 */           databean.setValue("ASSETNUM", databean.getValue("CIASSETNUM"));
/* 490:609 */         } else if (!databean.getMobileMbo().isNull("CILOCATION")) {
/* 491:611 */           databean.setValue("LOCATION", databean.getValue("CILOCATION"));
/* 492:    */         }
/* 493:    */       }
/* 494:    */     }
/* 495:616 */     return true;
/* 496:    */   }
/* 497:    */   
/* 498:    */   public boolean setActualProgressField(UIEvent event)
/* 499:    */     throws MobileApplicationException
/* 500:    */   {
/* 501:621 */     MobileMboDataBean databean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/* 502:622 */     if (databean.getName().equalsIgnoreCase(this.multiBean))
/* 503:    */     {
/* 504:624 */       String value = "true".equals(event.getValue()) ? "1" : "0";
/* 505:625 */       databean.setValue("PROGRESS", value);
/* 506:626 */       databean.getDataBeanManager().save();
/* 507:    */     }
/* 508:628 */     return false;
/* 509:    */   }
/* 510:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.mobilewo.MultiAssetLocCIUGenericHandler
 * JD-Core Version:    0.7.0.1
 */