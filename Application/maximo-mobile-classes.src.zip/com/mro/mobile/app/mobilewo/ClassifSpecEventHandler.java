/*   1:    */ package com.mro.mobile.app.mobilewo;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.MobileMessageGenerator;
/*   5:    */ import com.mro.mobile.app.BasicMobileDeviceUIApplication;
/*   6:    */ import com.mro.mobile.mbo.MobileMboQBE;
/*   7:    */ import com.mro.mobile.ui.LookupManager;
/*   8:    */ import com.mro.mobile.ui.MobileMboDataBean;
/*   9:    */ import com.mro.mobile.ui.event.UIEvent;
/*  10:    */ import com.mro.mobile.ui.res.UIUtil;
/*  11:    */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*  12:    */ import com.mro.mobile.ui.res.controls.LookupControl;
/*  13:    */ import com.mro.mobile.ui.res.controls.PageControl;
/*  14:    */ import com.mro.mobile.ui.res.controls.TextboxControl;
/*  15:    */ import com.mro.mobileapp.WOApp;
/*  16:    */ 
/*  17:    */ public class ClassifSpecEventHandler
/*  18:    */   extends MobileWOCommonEventHandler
/*  19:    */ {
/*  20:    */   public boolean performEvent(UIEvent event)
/*  21:    */     throws MobileApplicationException
/*  22:    */   {
/*  23: 39 */     if (event == null) {
/*  24: 41 */       return super.performEvent(event);
/*  25:    */     }
/*  26: 44 */     String eventId = event.getEventName();
/*  27: 45 */     if (eventId.equalsIgnoreCase("initvalues")) {
/*  28: 47 */       return initvalues(event);
/*  29:    */     }
/*  30: 49 */     if (eventId.equalsIgnoreCase("displayalnvalue")) {
/*  31: 51 */       return displayalnvalue(event);
/*  32:    */     }
/*  33: 53 */     if (eventId.equalsIgnoreCase("displaynumvalue")) {
/*  34: 55 */       return displaynumvalue(event);
/*  35:    */     }
/*  36: 57 */     if (eventId.equalsIgnoreCase("displaytablevalue")) {
/*  37: 59 */       return displaytablevalue(event);
/*  38:    */     }
/*  39: 61 */     if (eventId.equalsIgnoreCase("initspeclookup")) {
/*  40: 63 */       return initspeclookup(event);
/*  41:    */     }
/*  42: 65 */     if (eventId.equalsIgnoreCase("tablevaluevalidate"))
/*  43:    */     {
/*  44: 67 */       UIUtil.showInfoMessageBox(MobileMessageGenerator.generate("cannotvalidatetabledomain", null));
/*  45:    */       
/*  46: 69 */       return true;
/*  47:    */     }
/*  48: 71 */     if (eventId.equalsIgnoreCase("validateNumValue")) {
/*  49: 73 */       return validateNumValue(event);
/*  50:    */     }
/*  51: 77 */     return super.performEvent(event);
/*  52:    */   }
/*  53:    */   
/*  54:    */   public boolean initvalues(UIEvent event)
/*  55:    */     throws MobileApplicationException
/*  56:    */   {
/*  57: 89 */     MobileMboDataBean aux = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*  58:    */     
/*  59: 91 */     MobileMboDataBean dataBean = null;
/*  60: 92 */     if (aux != null)
/*  61:    */     {
/*  62: 95 */       if ("WORKORDER".equals(aux.getName())) {
/*  63: 97 */         dataBean = aux.getDataBean("WORKORDERSPEC");
/*  64: 99 */       } else if ("TICKET".equals(aux.getName())) {
/*  65:101 */         dataBean = aux.getDataBean("TICKETSPEC");
/*  66:104 */       } else if (("WORKORDERSPEC".equals(aux.getName())) || ("TICKETSPEC".equals(aux.getName()))) {
/*  67:107 */         dataBean = aux;
/*  68:    */       }
/*  69:109 */       fillNonPersistentValues(dataBean);
/*  70:    */     }
/*  71:112 */     return true;
/*  72:    */   }
/*  73:    */   
/*  74:    */   public boolean displayalnvalue(UIEvent event)
/*  75:    */     throws MobileApplicationException
/*  76:    */   {
/*  77:124 */     ((AbstractMobileControl)event.getCreatingObject()).setVisibility(compareDataType(event, "ALN"));
/*  78:126 */     if (((AbstractMobileControl)event.getCreatingObject()).isVisible()) {
/*  79:128 */       setValueFieldRequirement(event);
/*  80:    */     }
/*  81:130 */     return true;
/*  82:    */   }
/*  83:    */   
/*  84:    */   public boolean displaynumvalue(UIEvent event)
/*  85:    */     throws MobileApplicationException
/*  86:    */   {
/*  87:143 */     ((AbstractMobileControl)event.getCreatingObject()).setVisibility(compareDataType(event, "NUMERIC"));
/*  88:145 */     if (((AbstractMobileControl)event.getCreatingObject()).isVisible()) {
/*  89:147 */       setValueFieldRequirement(event);
/*  90:    */     }
/*  91:149 */     return true;
/*  92:    */   }
/*  93:    */   
/*  94:    */   public boolean displaytablevalue(UIEvent event)
/*  95:    */     throws MobileApplicationException
/*  96:    */   {
/*  97:162 */     ((AbstractMobileControl)event.getCreatingObject()).setVisibility(compareDataType(event, "MAXTABLE"));
/*  98:164 */     if (((AbstractMobileControl)event.getCreatingObject()).isVisible()) {
/*  99:166 */       setValueFieldRequirement(event);
/* 100:    */     }
/* 101:168 */     return true;
/* 102:    */   }
/* 103:    */   
/* 104:    */   public boolean initspeclookup(UIEvent event)
/* 105:    */     throws MobileApplicationException
/* 106:    */   {
/* 107:183 */     MobileMboDataBean dataBean = ((PageControl)event.getCreatingObject()).getLaunchingControl().getPage().getDataBean();
/* 108:    */     
/* 109:    */ 
/* 110:186 */     MobileMboDataBean lookupDataBean = ((LookupControl)event.getCreatingObject()).getDataBean();
/* 111:    */     
/* 112:    */ 
/* 113:    */ 
/* 114:190 */     lookupDataBean.getQBE().reset();
/* 115:191 */     lookupDataBean.getQBE().setQbeExactMatch(true);
/* 116:192 */     String value = null;
/* 117:193 */     if (dataBean.getName().equals("WORKORDERSPEC")) {
/* 118:195 */       value = dataBean.getValue("WOCLASSSPEC.DOMAINID");
/* 119:197 */     } else if (dataBean.getName().equals("TICKETSPEC")) {
/* 120:199 */       value = dataBean.getValue("TKCLASSSPEC.DOMAINID");
/* 121:    */     }
/* 122:201 */     if ((value != null) && (value.length() > 0)) {
/* 123:203 */       lookupDataBean.getQBE().setQBE("DOMAINID", value);
/* 124:    */     } else {
/* 125:207 */       lookupDataBean.getQBE().setQBE("DOMAINID", "NODOMAIN");
/* 126:    */     }
/* 127:209 */     lookupDataBean.reset();
/* 128:    */     
/* 129:211 */     return true;
/* 130:    */   }
/* 131:    */   
/* 132:    */   private void setValueFieldRequirement(UIEvent event)
/* 133:    */     throws MobileApplicationException
/* 134:    */   {
/* 135:218 */     MobileMboDataBean dataBean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/* 136:219 */     if (dataBean != null)
/* 137:    */     {
/* 138:221 */       String mandatory = dataBean.getValue("MANDATORY");
/* 139:222 */       if ("1".equalsIgnoreCase(mandatory)) {
/* 140:224 */         ((AbstractMobileControl)event.getCreatingObject()).setRequired(true);
/* 141:    */       } else {
/* 142:228 */         ((AbstractMobileControl)event.getCreatingObject()).setRequired(false);
/* 143:    */       }
/* 144:    */     }
/* 145:    */   }
/* 146:    */   
/* 147:    */   private boolean validateNumValue(UIEvent event)
/* 148:    */     throws MobileApplicationException
/* 149:    */   {
/* 150:239 */     MobileMboDataBean databean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/* 151:    */     
/* 152:    */ 
/* 153:242 */     UIEvent userevent = UIUtil.getApplication().getUserEvent();
/* 154:243 */     if ((userevent != null) && (userevent.getEventName().equalsIgnoreCase("acceptvalue"))) {
/* 155:244 */       return true;
/* 156:    */     }
/* 157:247 */     String value = (String)event.getValue();
/* 158:249 */     if (value != null) {
/* 159:    */       try
/* 160:    */       {
/* 161:254 */         double numValue = Double.parseDouble(value);
/* 162:    */         
/* 163:    */ 
/* 164:257 */         LookupManager luMan = UIUtil.getLookupManager();
/* 165:258 */         MobileMboDataBean domainBean = luMan.createLookupDomainBean("CLASSIFSPECNUMERIC");
/* 166:259 */         luMan.applyMultisiteFilter(domainBean, databean);
/* 167:260 */         domainBean.getQBE().setQbeExactMatch(true);
/* 168:261 */         domainBean.getQBE().setQBE("VALUE", value);
/* 169:262 */         domainBean.reset();
/* 170:264 */         if (domainBean.getMobileMbo(0) == null)
/* 171:    */         {
/* 172:267 */           UIUtil.popupPage("invalidvalue", event);
/* 173:268 */           ((TextboxControl)event.getCreatingObject()).setTextWidgetInvalid(event.errorOccured());
/* 174:269 */           event.setEventErrored();
/* 175:    */         }
/* 176:    */       }
/* 177:    */       catch (Exception e) {}
/* 178:    */     }
/* 179:278 */     return true;
/* 180:    */   }
/* 181:    */   
/* 182:    */   private boolean compareDataType(UIEvent event, String value)
/* 183:    */     throws MobileApplicationException
/* 184:    */   {
/* 185:293 */     MobileMboDataBean dataBean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/* 186:    */     
/* 187:295 */     return compareDataType(dataBean, value);
/* 188:    */   }
/* 189:    */   
/* 190:    */   private boolean compareDataType(MobileMboDataBean dataBean, String value)
/* 191:    */     throws MobileApplicationException
/* 192:    */   {
/* 193:309 */     if (dataBean != null)
/* 194:    */     {
/* 195:311 */       String datatype = null;
/* 196:    */       
/* 197:    */ 
/* 198:314 */       datatype = ((WOApp)UIUtil.getApplication()).getInternalValue(dataBean, "DATATYPE", dataBean.getValue("DATATYPE"));
/* 199:315 */       if ((datatype != null) && (datatype.equalsIgnoreCase(value))) {
/* 200:317 */         return true;
/* 201:    */       }
/* 202:    */     }
/* 203:320 */     return false;
/* 204:    */   }
/* 205:    */   
/* 206:    */   private void fillNonPersistentValues(MobileMboDataBean dataBean)
/* 207:    */     throws MobileApplicationException
/* 208:    */   {
/* 209:332 */     if (dataBean != null)
/* 210:    */     {
/* 211:334 */       for (int i = 0; i < dataBean.count(); i++)
/* 212:    */       {
/* 213:337 */         if (compareDataType(dataBean, "ALN")) {
/* 214:339 */           dataBean.setValue("DISPLAY_VALUE", dataBean.getValue("ALNVALUE"));
/* 215:342 */         } else if (compareDataType(dataBean, "NUMERIC")) {
/* 216:344 */           dataBean.setValue("DISPLAY_VALUE", dataBean.getValue("NUMVALUE"));
/* 217:347 */         } else if (compareDataType(dataBean, "MAXTABLE")) {
/* 218:349 */           dataBean.setValue("DISPLAY_VALUE", dataBean.getValue("TABLEVALUE"));
/* 219:    */         }
/* 220:364 */         dataBean.setCurrentPosition(i + 1);
/* 221:    */       }
/* 222:366 */       dataBean.setCurrentPosition(0);
/* 223:    */     }
/* 224:    */   }
/* 225:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.mobilewo.ClassifSpecEventHandler
 * JD-Core Version:    0.7.0.1
 */