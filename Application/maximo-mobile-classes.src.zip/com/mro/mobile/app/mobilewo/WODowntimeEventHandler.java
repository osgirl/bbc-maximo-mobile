/*   1:    */ package com.mro.mobile.app.mobilewo;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.app.BasicMobileDeviceUIApplication;
/*   5:    */ import com.mro.mobile.app.DefaultMobileMboDataFormatter;
/*   6:    */ import com.mro.mobile.mbo.MobileMbo;
/*   7:    */ import com.mro.mobile.mbo.MobileMboOrder;
/*   8:    */ import com.mro.mobile.mbo.MobileMboQBE;
/*   9:    */ import com.mro.mobile.ui.DataBeanCache;
/*  10:    */ import com.mro.mobile.ui.MobileMboDataBean;
/*  11:    */ import com.mro.mobile.ui.MobileMboDataBeanManager;
/*  12:    */ import com.mro.mobile.ui.event.UIEvent;
/*  13:    */ import com.mro.mobile.ui.res.UIUtil;
/*  14:    */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*  15:    */ import com.mro.mobile.ui.res.controls.PageControl;
/*  16:    */ import com.mro.mobileapp.WOApp;
/*  17:    */ import java.util.Date;
/*  18:    */ 
/*  19:    */ public class WODowntimeEventHandler
/*  20:    */   extends MobileWOCommonEventHandler
/*  21:    */ {
/*  22:    */   public boolean performEvent(UIEvent event)
/*  23:    */     throws MobileApplicationException
/*  24:    */   {
/*  25: 32 */     if (event == null) {
/*  26: 32 */       return false;
/*  27:    */     }
/*  28: 34 */     String eventId = event.getEventName();
/*  29: 36 */     if (eventId.equalsIgnoreCase("initpagedowntime")) {
/*  30: 38 */       return initpagedowntime(event);
/*  31:    */     }
/*  32: 40 */     if (eventId.equalsIgnoreCase("validate_startdate")) {
/*  33: 42 */       return validate_startdate(event);
/*  34:    */     }
/*  35: 44 */     if (eventId.equalsIgnoreCase("validate_enddate")) {
/*  36: 46 */       return validate_enddate(event);
/*  37:    */     }
/*  38: 48 */     if (eventId.equalsIgnoreCase("validatepagedowntime")) {
/*  39: 50 */       return validatepagedowntime(event);
/*  40:    */     }
/*  41: 52 */     if (eventId.equalsIgnoreCase("initpagestatus")) {
/*  42: 54 */       return initpagestatus(event);
/*  43:    */     }
/*  44: 56 */     if (eventId.equalsIgnoreCase("validate_statuschangedate")) {
/*  45: 58 */       return validate_statuschangedate(event);
/*  46:    */     }
/*  47: 60 */     if (eventId.equalsIgnoreCase("validatepagestatus")) {
/*  48: 62 */       return validatepagestatus(event);
/*  49:    */     }
/*  50: 65 */     super.performEvent(event);
/*  51:    */     
/*  52: 67 */     return false;
/*  53:    */   }
/*  54:    */   
/*  55:    */   public boolean initpagedowntime(UIEvent event)
/*  56:    */     throws MobileApplicationException
/*  57:    */   {
/*  58: 73 */     MobileMboDataBean databean = ((PageControl)event.getCreatingObject()).getDataBean();
/*  59: 74 */     MobileMboDataBean wodatabean = databean.getParentBean();
/*  60:    */     
/*  61: 76 */     String assetNum = null;
/*  62: 77 */     String siteId = null;
/*  63:    */     
/*  64:    */ 
/*  65: 80 */     MobileMboDataBean womulti = DataBeanCache.findDataBean("WOMULTI");
/*  66: 81 */     if ((womulti != null) && (womulti.getMobileMbo() != null))
/*  67:    */     {
/*  68: 82 */       assetNum = womulti.getValue("ASSETNUM");
/*  69: 83 */       siteId = womulti.getValue("SITEID");
/*  70:    */     }
/*  71:    */     else
/*  72:    */     {
/*  73: 85 */       if (wodatabean.getValue("ASSETNUM").equals("")) {
/*  74: 87 */         throw new MobileApplicationException("noassetdefined");
/*  75:    */       }
/*  76: 90 */       assetNum = wodatabean.getValue("ASSETNUM");
/*  77: 91 */       siteId = wodatabean.getValue("SITEID");
/*  78:    */     }
/*  79: 93 */     String isrunning = getAssetIsRunning(wodatabean);
/*  80:    */     
/*  81: 95 */     databean.insert();
/*  82: 96 */     databean.setValue("ASSETNUM", assetNum);
/*  83: 97 */     databean.setValue("SITEID", siteId);
/*  84: 98 */     databean.setValue("ISRUNNING", isrunning);
/*  85: 99 */     databean.setValue("ISDOWNTIMEREPORT", "1");
/*  86:100 */     databean.setValue("CURRENTSTATUS", getCurrentAssetStatus(wodatabean, isrunning));
/*  87:101 */     databean.setValue("STARTDATESOURCE", getMaxVarDOWNTIMEDFLTS(wodatabean));
/*  88:    */     
/*  89:103 */     setDownTimeRptValues(wodatabean, databean);
/*  90:    */     
/*  91:105 */     UIUtil.refreshCurrentScreen();
/*  92:106 */     return true;
/*  93:    */   }
/*  94:    */   
/*  95:    */   private String getCurrentAssetStatus(MobileMboDataBean wodatabean, String isrunning)
/*  96:    */     throws MobileApplicationException
/*  97:    */   {
/*  98:111 */     String status = "DOWN";
/*  99:113 */     if (isrunning.equals("1")) {
/* 100:115 */       status = "UP";
/* 101:    */     }
/* 102:118 */     return ((WOApp)UIUtil.getApplication()).getDefaultValue(wodatabean, "ASSETSTATUS", status);
/* 103:    */   }
/* 104:    */   
/* 105:    */   private String getMaxVarDOWNTIMEDFLTS(MobileMboDataBean wodatabean)
/* 106:    */     throws MobileApplicationException
/* 107:    */   {
/* 108:123 */     String dateDefault = ((WOApp)UIUtil.getApplication()).getMaxVar(wodatabean, "DOWNTIMEDFLTS");
/* 109:127 */     if (dateDefault.equalsIgnoreCase("START")) {
/* 110:129 */       return "ACTSTART";
/* 111:    */     }
/* 112:131 */     if (dateDefault.equalsIgnoreCase("REPORTED")) {
/* 113:133 */       return "REPORTDATE";
/* 114:    */     }
/* 115:137 */     return "NONE";
/* 116:    */   }
/* 117:    */   
/* 118:    */   protected void setDownTimeRptValues(MobileMboDataBean wodatabean, MobileMboDataBean databean)
/* 119:    */     throws MobileApplicationException
/* 120:    */   {
/* 121:143 */     Date startdate = null;
/* 122:144 */     Date enddate = null;
/* 123:157 */     if (!wodatabean.getValue("REPORTDATE").equals("")) {
/* 124:158 */       startdate = wodatabean.getMobileMbo().getDateValue("REPORTDATE");
/* 125:159 */     } else if (!wodatabean.getValue("ACTSTART").equals("")) {
/* 126:160 */       startdate = wodatabean.getMobileMbo().getDateValue("ACTSTART");
/* 127:    */     }
/* 128:162 */     databean.getMobileMbo().setDateValue("STARTDATE", startdate);
/* 129:164 */     if (!wodatabean.getValue("ACTFINISH").equals("")) {
/* 130:165 */       enddate = wodatabean.getMobileMbo().getDateValue("ACTFINISH");
/* 131:    */     } else {
/* 132:167 */       enddate = ((WOApp)UIUtil.getApplication()).getCurrentTime();
/* 133:    */     }
/* 134:170 */     if ((enddate != null) && ((startdate == null) || (!enddate.before(startdate)))) {
/* 135:172 */       databean.getMobileMbo().setDateValue("ENDDATE", enddate);
/* 136:    */     }
/* 137:175 */     if ((startdate != null) && (enddate != null)) {
/* 138:176 */       databean.setValue("DOWNTIME", "" + WOApp.calculateHours(startdate, enddate));
/* 139:    */     }
/* 140:    */   }
/* 141:    */   
/* 142:    */   public boolean validate_startdate(UIEvent event)
/* 143:    */     throws MobileApplicationException
/* 144:    */   {
/* 145:182 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/* 146:183 */     if (event.getValue() == null)
/* 147:    */     {
/* 148:185 */       databean.setValue("DOWNTIME", "");
/* 149:    */     }
/* 150:189 */     else if (!databean.getValue("ENDDATE").equals(""))
/* 151:    */     {
/* 152:192 */       if (databean.getMobileMbo().getDateValue("ENDDATE").before((Date)event.getValue())) {
/* 153:193 */         throw new MobileApplicationException("startafterend");
/* 154:    */       }
/* 155:195 */       databean.setValue("DOWNTIME", "" + WOApp.calculateHours((Date)event.getValue(), databean.getMobileMbo().getDateValue("ENDDATE")));
/* 156:    */     }
/* 157:201 */     UIUtil.refreshCurrentScreen();
/* 158:202 */     return true;
/* 159:    */   }
/* 160:    */   
/* 161:    */   public boolean validate_enddate(UIEvent event)
/* 162:    */     throws MobileApplicationException
/* 163:    */   {
/* 164:207 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/* 165:208 */     if (event.getValue() == null)
/* 166:    */     {
/* 167:210 */       databean.setValue("DOWNTIME", "");
/* 168:    */     }
/* 169:214 */     else if (!databean.getValue("STARTDATE").equals(""))
/* 170:    */     {
/* 171:216 */       if (databean.getMobileMbo().getDateValue("STARTDATE").after((Date)event.getValue())) {
/* 172:217 */         throw new MobileApplicationException("endbeforestart");
/* 173:    */       }
/* 174:219 */       databean.getMobileMbo().setValue("DOWNTIME", "" + WOApp.calculateHours(databean.getMobileMbo().getDateValue("STARTDATE"), (Date)event.getValue()));
/* 175:    */     }
/* 176:225 */     UIUtil.refreshCurrentScreen();
/* 177:226 */     return true;
/* 178:    */   }
/* 179:    */   
/* 180:    */   public boolean validatepagedowntime(UIEvent event)
/* 181:    */     throws MobileApplicationException
/* 182:    */   {
/* 183:231 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/* 184:232 */     MobileMboDataBean wodatabean = databean.getParentBean();
/* 185:234 */     if (!event.hasPassedESig())
/* 186:    */     {
/* 187:236 */       checkDates(databean, wodatabean);
/* 188:    */       
/* 189:    */ 
/* 190:239 */       double calcdowntime = WOApp.calculateHours(databean.getMobileMbo().getDateValue("STARTDATE"), databean.getMobileMbo().getDateValue("ENDDATE"));
/* 191:240 */       double downtime = DefaultMobileMboDataFormatter.durationToDouble(databean.getValue("DOWNTIME"));
/* 192:241 */       if (downtime > calcdowntime) {
/* 193:242 */         throw new MobileApplicationException("DurationToBig");
/* 194:    */       }
/* 195:    */     }
/* 196:245 */     if (UIUtil.checkESignature(event, wodatabean, "REPDOWN"))
/* 197:    */     {
/* 198:247 */       databean.getMobileMbo().setDateValue("ASSETSTATUSDATE", databean.getMobileMbo().getDateValue("STARTDATE"));
/* 199:    */       
/* 200:249 */       String assetnum = wodatabean.getValue("ASSETNUM");
/* 201:250 */       String siteid = wodatabean.getValue("SITEID");
/* 202:251 */       wodatabean.getDataBeanManager().save();
/* 203:    */       
/* 204:    */ 
/* 205:254 */       setAssetStatus(wodatabean);
/* 206:255 */       UIUtil.getApplication().removeCurrentScreen(false);
/* 207:    */     }
/* 208:    */     else
/* 209:    */     {
/* 210:259 */       event.setEventErrored();
/* 211:    */     }
/* 212:262 */     return true;
/* 213:    */   }
/* 214:    */   
/* 215:    */   public void checkDates(MobileMboDataBean databean, MobileMboDataBean wodatabean)
/* 216:    */     throws MobileApplicationException
/* 217:    */   {
/* 218:272 */     boolean isrunning = databean.getMobileMbo().getBooleanValue("ISRUNNING");
/* 219:273 */     Date start = databean.getMobileMbo().getDateValue("STARTDATE");
/* 220:274 */     Date end = databean.getMobileMbo().getDateValue("ENDDATE");
/* 221:    */     
/* 222:    */ 
/* 223:277 */     MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager("DOWNTIMEREPORT");
/* 224:278 */     MobileMboDataBean dtrBean = mgrDBMgr.getDataBean();
/* 225:279 */     dtrBean.getQBE().reset();
/* 226:280 */     dtrBean.getQBE().setQbeExactMatch(true);
/* 227:    */     
/* 228:282 */     dtrBean.getQBE().setQBE("ASSETNUM", wodatabean.getValue("ASSETNUM"));
/* 229:283 */     dtrBean.getQBE().setQBE("SITEID", wodatabean.getValue("SITEID"));
/* 230:284 */     dtrBean.reset();
/* 231:285 */     int dtrcount = dtrBean.count();
/* 232:289 */     if (dtrcount == 0) {
/* 233:290 */       return;
/* 234:    */     }
/* 235:292 */     for (int i = 0; i < dtrcount; i++) {
/* 236:294 */       if (dtrBean.getMobileMbo(i).getValue("ISDOWNTIMEREPORT").equals("1"))
/* 237:    */       {
/* 238:297 */         if (((start.after(dtrBean.getMobileMbo(i).getDateValue("STARTDATE"))) && (start.before(dtrBean.getMobileMbo(i).getDateValue("ENDDATE")))) || ((end.after(dtrBean.getMobileMbo(i).getDateValue("STARTDATE"))) && (end.before(dtrBean.getMobileMbo(i).getDateValue("ENDDATE"))))) {
/* 239:303 */           throw new MobileApplicationException("splitcompdtreport");
/* 240:    */         }
/* 241:    */       }
/* 242:309 */       else if ((dtrBean.getMobileMbo(i).getDateValue("STATUSCHANGEDATE").after(start)) && (dtrBean.getMobileMbo(i).getDateValue("STATUSCHANGEDATE").before(end)))
/* 243:    */       {
/* 244:312 */         Object[] param = { DefaultMobileMboDataFormatter.dateTimeToString(dtrBean.getMobileMbo(i).getDateValue("STATUSCHANGEDATE")) };
/* 245:313 */         throw new MobileApplicationException("splitstatusreport", param);
/* 246:    */       }
/* 247:    */     }
/* 248:    */   }
/* 249:    */   
/* 250:    */   public boolean initpagestatus(UIEvent event)
/* 251:    */     throws MobileApplicationException
/* 252:    */   {
/* 253:322 */     MobileMboDataBean databean = ((PageControl)event.getCreatingObject()).getDataBean();
/* 254:323 */     MobileMboDataBean wodatabean = databean.getParentBean();
/* 255:    */     
/* 256:325 */     String assetNum = null;
/* 257:326 */     String siteId = null;
/* 258:    */     
/* 259:    */ 
/* 260:329 */     MobileMboDataBean womulti = DataBeanCache.findDataBean("WOMULTI");
/* 261:330 */     if ((womulti != null) && (womulti.getMobileMbo() != null))
/* 262:    */     {
/* 263:331 */       assetNum = womulti.getValue("ASSETNUM");
/* 264:332 */       siteId = womulti.getValue("SITEID");
/* 265:    */     }
/* 266:    */     else
/* 267:    */     {
/* 268:334 */       if (wodatabean.getValue("ASSETNUM").equals("")) {
/* 269:336 */         throw new MobileApplicationException("noassetdefined");
/* 270:    */       }
/* 271:339 */       assetNum = wodatabean.getValue("ASSETNUM");
/* 272:340 */       siteId = wodatabean.getValue("SITEID");
/* 273:    */     }
/* 274:342 */     String isrunning = getAssetIsRunning(wodatabean);
/* 275:    */     
/* 276:344 */     databean.insert();
/* 277:345 */     databean.setValue("ASSETNUM", assetNum);
/* 278:346 */     databean.setValue("SITEID", siteId);
/* 279:347 */     databean.setValue("ISRUNNING", isrunning);
/* 280:348 */     databean.setValue("ISDOWNTIMEREPORT", "0");
/* 281:349 */     databean.setValue("CURRENTSTATUS", getCurrentAssetStatus(wodatabean, isrunning));
/* 282:350 */     databean.setValue("STARTDATESOURCE", getMaxVarDOWNTIMEDFLTS(wodatabean));
/* 283:351 */     if (!wodatabean.getValue("REPORTDATE").equals("")) {
/* 284:352 */       databean.getMobileMbo().setDateValue("STATUSCHANGEDATE", wodatabean.getMobileMbo().getDateValue("REPORTDATE"));
/* 285:353 */     } else if (!wodatabean.getValue("ACTSTART").equals("")) {
/* 286:354 */       databean.getMobileMbo().setDateValue("STATUSCHANGEDATE", wodatabean.getMobileMbo().getDateValue("ACTSTART"));
/* 287:    */     }
/* 288:356 */     return true;
/* 289:    */   }
/* 290:    */   
/* 291:    */   public boolean validate_statuschangedate(UIEvent event)
/* 292:    */     throws MobileApplicationException
/* 293:    */   {
/* 294:361 */     return true;
/* 295:    */   }
/* 296:    */   
/* 297:    */   public boolean validatepagestatus(UIEvent event)
/* 298:    */     throws MobileApplicationException
/* 299:    */   {
/* 300:366 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/* 301:367 */     MobileMboDataBean wodatabean = databean.getParentBean();
/* 302:    */     
/* 303:    */ 
/* 304:    */ 
/* 305:371 */     MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager("DOWNTIMEREPORT");
/* 306:372 */     MobileMboDataBean dtrBean = mgrDBMgr.getDataBean();
/* 307:373 */     dtrBean.getQBE().reset();
/* 308:374 */     dtrBean.getQBE().setQbeExactMatch(true);
/* 309:    */     
/* 310:376 */     dtrBean.getQBE().setQBE("ASSETNUM", wodatabean.getValue("ASSETNUM"));
/* 311:377 */     dtrBean.getQBE().setQBE("SITEID", wodatabean.getValue("SITEID"));
/* 312:378 */     dtrBean.reset();
/* 313:379 */     int dtrcount = dtrBean.count();
/* 314:381 */     if (dtrcount > 0)
/* 315:    */     {
/* 316:383 */       Date lastdate = null;
/* 317:384 */       for (int i = 0; i < dtrcount; i++) {
/* 318:386 */         if (dtrBean.getMobileMbo(i).getValue("ISDOWNTIMEREPORT").equals("1"))
/* 319:    */         {
/* 320:388 */           if (lastdate == null) {
/* 321:390 */             lastdate = dtrBean.getMobileMbo(i).getDateValue("ENDDATE");
/* 322:393 */           } else if (dtrBean.getMobileMbo(i).getDateValue("ENDDATE").after(lastdate)) {
/* 323:395 */             lastdate = dtrBean.getMobileMbo(i).getDateValue("ENDDATE");
/* 324:    */           }
/* 325:    */         }
/* 326:401 */         else if (lastdate == null) {
/* 327:403 */           lastdate = dtrBean.getMobileMbo(i).getDateValue("STATUSCHANGEDATE");
/* 328:406 */         } else if (dtrBean.getMobileMbo(i).getDateValue("STATUSCHANGEDATE").after(lastdate)) {
/* 329:408 */           lastdate = dtrBean.getMobileMbo(i).getDateValue("STATUSCHANGEDATE");
/* 330:    */         }
/* 331:    */       }
/* 332:413 */       if (lastdate != null) {
/* 333:415 */         if (databean.getMobileMbo().getDateValue("STATUSCHANGEDATE").before(lastdate))
/* 334:    */         {
/* 335:417 */           Object[] param = { DefaultMobileMboDataFormatter.dateTimeToString(lastdate) };
/* 336:418 */           throw new MobileApplicationException("assetstatusdateinvalid", param);
/* 337:    */         }
/* 338:    */       }
/* 339:    */     }
/* 340:423 */     databean.getMobileMbo().setDateValue("ASSETSTATUSDATE", databean.getMobileMbo().getDateValue("STATUSCHANGEDATE"));
/* 341:424 */     wodatabean.getDataBeanManager().save();
/* 342:    */     
/* 343:    */ 
/* 344:427 */     setAssetStatus(wodatabean);
/* 345:    */     
/* 346:429 */     return true;
/* 347:    */   }
/* 348:    */   
/* 349:    */   public String getAssetIsRunning(MobileMboDataBean wodatabean)
/* 350:    */     throws MobileApplicationException
/* 351:    */   {
/* 352:434 */     String isrunning = "0";
/* 353:    */     
/* 354:    */ 
/* 355:437 */     MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager("ASSET");
/* 356:438 */     MobileMboDataBean assetBean = mgrDBMgr.getDataBean();
/* 357:439 */     assetBean.getQBE().reset();
/* 358:440 */     assetBean.getQBE().setQbeExactMatch(true);
/* 359:441 */     assetBean.getQBE().setQBE("ASSETNUM", wodatabean.getValue("ASSETNUM"));
/* 360:442 */     assetBean.getQBE().setQBE("SITEID", wodatabean.getValue("SITEID"));
/* 361:443 */     assetBean.reset();
/* 362:444 */     if (assetBean.getMobileMbo(0) != null) {
/* 363:446 */       return assetBean.getMobileMbo(0).getValue("ISRUNNING");
/* 364:    */     }
/* 365:449 */     return isrunning;
/* 366:    */   }
/* 367:    */   
/* 368:    */   public void setAssetStatus(MobileMboDataBean wodatabean)
/* 369:    */     throws MobileApplicationException
/* 370:    */   {
/* 371:460 */     MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager("DOWNTIMEREPORT");
/* 372:461 */     MobileMboDataBean dtrBean = mgrDBMgr.getDataBean();
/* 373:462 */     dtrBean.getQBE().reset();
/* 374:463 */     dtrBean.getQBE().setQbeExactMatch(true);
/* 375:    */     
/* 376:465 */     dtrBean.getQBE().setQBE("ASSETNUM", wodatabean.getValue("ASSETNUM"));
/* 377:466 */     dtrBean.getQBE().setQBE("SITEID", wodatabean.getValue("SITEID"));
/* 378:467 */     dtrBean.getOrder().setOrder("ASSETSTATUSDATE", false);
/* 379:468 */     dtrBean.reset();
/* 380:470 */     if (dtrBean.getMobileMbo(0) == null) {
/* 381:471 */       return;
/* 382:    */     }
/* 383:475 */     mgrDBMgr = new MobileMboDataBeanManager("ASSET");
/* 384:476 */     MobileMboDataBean assetBean = mgrDBMgr.getDataBean();
/* 385:477 */     assetBean.getQBE().reset();
/* 386:478 */     assetBean.getQBE().setQbeExactMatch(true);
/* 387:479 */     assetBean.getQBE().setQBE("ASSETNUM", wodatabean.getValue("ASSETNUM"));
/* 388:480 */     assetBean.getQBE().setQBE("SITEID", wodatabean.getValue("SITEID"));
/* 389:481 */     assetBean.reset();
/* 390:482 */     if (assetBean.getMobileMbo(0) == null) {
/* 391:483 */       return;
/* 392:    */     }
/* 393:485 */     if (dtrBean.getValue("ISDOWNTIMEREPORT").equals("1")) {
/* 394:486 */       assetBean.getMobileMbo(0).setBooleanValue("ISRUNNING", true, false);
/* 395:    */     } else {
/* 396:488 */       assetBean.getMobileMbo(0).setBooleanValue("ISRUNNING", !dtrBean.getMobileMbo(0).getBooleanValue("ISRUNNING"), false);
/* 397:    */     }
/* 398:    */   }
/* 399:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.mobilewo.WODowntimeEventHandler
 * JD-Core Version:    0.7.0.1
 */