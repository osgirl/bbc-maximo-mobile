/*   1:    */ package com.mro.mobile.app.mobilewo;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.mbo.MobileMbo;
/*   5:    */ import com.mro.mobile.mbo.MobileMboQBE;
/*   6:    */ import com.mro.mobile.persist.QBE;
/*   7:    */ import com.mro.mobile.ui.DataBeanCache;
/*   8:    */ import com.mro.mobile.ui.MobileMboDataBean;
/*   9:    */ import com.mro.mobile.ui.MobileMboDataBeanManager;
/*  10:    */ import com.mro.mobile.ui.event.UIEvent;
/*  11:    */ import com.mro.mobile.ui.res.ControlData;
/*  12:    */ import com.mro.mobile.ui.res.UIUtil;
/*  13:    */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*  14:    */ import com.mro.mobile.ui.res.controls.PageControl;
/*  15:    */ import com.mro.mobile.ui.res.controls.TextboxControl;
/*  16:    */ import com.mro.mobileapp.WOApp;
/*  17:    */ import java.util.Date;
/*  18:    */ 
/*  19:    */ public class TKEventHandler
/*  20:    */   extends MobileWOCommonEventHandler
/*  21:    */ {
/*  22:    */   public boolean performEvent(UIEvent event)
/*  23:    */     throws MobileApplicationException
/*  24:    */   {
/*  25: 37 */     if (event == null) {
/*  26: 37 */       return false;
/*  27:    */     }
/*  28: 39 */     String eventId = event.getEventName();
/*  29: 41 */     if (eventId.equalsIgnoreCase("initactivitydetails")) {
/*  30: 43 */       return initactivitydetails(event);
/*  31:    */     }
/*  32: 45 */     if (eventId.equalsIgnoreCase("initfailurereport")) {
/*  33: 47 */       return initfailurereport(event);
/*  34:    */     }
/*  35: 49 */     if (eventId.equalsIgnoreCase("initTKDetails")) {
/*  36: 51 */       return initTKDetails(event);
/*  37:    */     }
/*  38: 53 */     if (eventId.equalsIgnoreCase("refreshTKDetails")) {
/*  39: 55 */       return refreshTKDetails(event);
/*  40:    */     }
/*  41: 57 */     if (eventId.equalsIgnoreCase("validatesolution")) {
/*  42: 59 */       return validatesolution(event);
/*  43:    */     }
/*  44: 61 */     if (eventId.equalsIgnoreCase("validatecreatesolution")) {
/*  45: 63 */       return validatecreatesolution(event);
/*  46:    */     }
/*  47: 65 */     if (eventId.equalsIgnoreCase("caneditactivity")) {
/*  48: 67 */       return caneditactivity(event);
/*  49:    */     }
/*  50: 69 */     if (eventId.equalsIgnoreCase("validatesiteid")) {
/*  51: 71 */       return validatesiteid(event);
/*  52:    */     }
/*  53: 73 */     if (eventId.equalsIgnoreCase("assetchanged")) {
/*  54: 75 */       return assetchanged(event);
/*  55:    */     }
/*  56: 77 */     if (eventId.equalsIgnoreCase("locationchanged")) {
/*  57: 79 */       return locationchanged(event);
/*  58:    */     }
/*  59: 81 */     if (eventId.equalsIgnoreCase("cichanged")) {
/*  60: 83 */       return cichanged(event);
/*  61:    */     }
/*  62: 85 */     if (eventId.equalsIgnoreCase("clrfailrepfield")) {
/*  63: 87 */       return clrfailrepfield(event);
/*  64:    */     }
/*  65: 89 */     if (eventId.equalsIgnoreCase("reportedbychanged")) {
/*  66: 91 */       return reportedbychanged(event);
/*  67:    */     }
/*  68: 93 */     if (eventId.equalsIgnoreCase("affectedpersonchanged")) {
/*  69: 95 */       return affectedpersonchanged(event);
/*  70:    */     }
/*  71: 97 */     if (eventId.equalsIgnoreCase("canshowsolutionview")) {
/*  72: 99 */       return canshowsolutionview(event);
/*  73:    */     }
/*  74:101 */     if (eventId.equalsIgnoreCase("save")) {
/*  75:103 */       return save(event);
/*  76:    */     }
/*  77:105 */     if (eventId.equalsIgnoreCase("validateactstart")) {
/*  78:107 */       return validateactstart(event);
/*  79:    */     }
/*  80:109 */     if (eventId.equalsIgnoreCase("validateactfinish")) {
/*  81:111 */       return validateactfinish(event);
/*  82:    */     }
/*  83:113 */     if (eventId.equalsIgnoreCase("validatetargstart")) {
/*  84:115 */       return validatetargstart(event);
/*  85:    */     }
/*  86:117 */     if (eventId.equalsIgnoreCase("validatetargend")) {
/*  87:119 */       return validatetargend(event);
/*  88:    */     }
/*  89:122 */     if (eventId.equalsIgnoreCase("defaultfailurereportremdate")) {
/*  90:124 */       return defaultfailurereportremdate(event);
/*  91:    */     }
/*  92:127 */     super.performEvent(event);
/*  93:    */     
/*  94:129 */     return false;
/*  95:    */   }
/*  96:    */   
/*  97:    */   public boolean initTKDetails(UIEvent event)
/*  98:    */     throws MobileApplicationException
/*  99:    */   {
/* 100:134 */     MobileMboDataBean databean = ((PageControl)event.getCreatingObject()).getDataBean();
/* 101:135 */     if ((databean != null) && (databean.getName().equals("TICKET")))
/* 102:    */     {
/* 103:137 */       if (databean.getValue("TICKETID").equals("")) {
/* 104:138 */         return true;
/* 105:    */       }
/* 106:140 */       MobileMboDataBean attachments = databean.getDataBean("TKATTACHMENTS");
/* 107:    */       
/* 108:    */ 
/* 109:143 */       attachments.getQBE().reset();
/* 110:144 */       attachments.reset();
/* 111:145 */       databean.setValue("ATTACHCOUNT", "" + attachments.count());
/* 112:    */       
/* 113:147 */       attachments.getQBE().reset();
/* 114:148 */       attachments.reset();
/* 115:    */     }
/* 116:151 */     return true;
/* 117:    */   }
/* 118:    */   
/* 119:    */   public boolean refreshTKDetails(UIEvent event)
/* 120:    */     throws MobileApplicationException
/* 121:    */   {
/* 122:156 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/* 123:157 */     if ((databean != null) && (databean.getName().equals("TICKET")))
/* 124:    */     {
/* 125:159 */       if (databean.getValue("WONUM").equals("")) {
/* 126:160 */         return true;
/* 127:    */       }
/* 128:162 */       MobileMboDataBean attachments = databean.getDataBean("TKATTACHMENTS");
/* 129:    */       
/* 130:    */ 
/* 131:165 */       attachments.getQBE().reset();
/* 132:166 */       attachments.reset();
/* 133:167 */       databean.setValue("ATTACHCOUNT", "" + attachments.count());
/* 134:    */       
/* 135:169 */       attachments.getQBE().reset();
/* 136:170 */       attachments.reset();
/* 137:    */     }
/* 138:173 */     return true;
/* 139:    */   }
/* 140:    */   
/* 141:    */   public boolean assetchanged(UIEvent event)
/* 142:    */     throws MobileApplicationException
/* 143:    */   {
/* 144:179 */     MobileMboDataBean databean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/* 145:180 */     if (databean != null) {
/* 146:182 */       if (event.getValue() != null)
/* 147:    */       {
/* 148:187 */         MobileMboDataBean assetBean = DataBeanCache.getDataBean("ASSET", "ASSET");
/* 149:    */         
/* 150:189 */         String newAsset = (String)event.getValue();
/* 151:190 */         MobileMboQBE qbe = assetBean.getQBE();
/* 152:    */         
/* 153:    */ 
/* 154:193 */         int currentPos = assetBean.getCurrentPosition();
/* 155:194 */         qbe.saveState();
/* 156:    */         
/* 157:196 */         qbe.setQBE("ASSETNUM", newAsset);
/* 158:    */         
/* 159:198 */         assetBean.reset();
/* 160:    */         
/* 161:200 */         MobileMbo assetmbo = assetBean.getMobileMbo(0);
/* 162:201 */         qbe.restoreState();
/* 163:202 */         assetBean.reset();
/* 164:203 */         assetBean.setCurrentPosition(currentPos);
/* 165:204 */         if (assetmbo != null)
/* 166:    */         {
/* 167:206 */           if (!databean.getName().equalsIgnoreCase("WOACTIVITY"))
/* 168:    */           {
/* 169:208 */             databean.setValue("ASSETORGID", assetmbo.getValue("ORGID"));
/* 170:209 */             databean.setValue("ASSETSITEID", assetmbo.getValue("SITEID"));
/* 171:    */           }
/* 172:211 */           databean.setValue("LOCATION", assetmbo.getValue("LOCATION"));
/* 173:    */           
/* 174:    */ 
/* 175:214 */           WOFailCodeEventHandler failcodehandler = new WOFailCodeEventHandler();
/* 176:215 */           failcodehandler.saveOriginalValues(databean);
/* 177:219 */           if (!assetmbo.getValue("FAILURECODE").equals(""))
/* 178:    */           {
/* 179:220 */             databean.setValue("FAILUREREPORTCHANGED", "1");
/* 180:221 */             databean.setValue("FAILURECODE", assetmbo.getValue("FAILURECODE"));
/* 181:    */           }
/* 182:226 */           MobileMboDataBean tkmultibean = databean.getDataBean("TKMULTIASSETLOCCI");
/* 183:227 */           if (tkmultibean != null)
/* 184:    */           {
/* 185:229 */             tkmultibean.getQBE().reset();
/* 186:230 */             tkmultibean.getQBE().setQbeExactMatch(true);
/* 187:231 */             tkmultibean.getQBE().setQBE("ISPRIMARY", "1");
/* 188:232 */             tkmultibean.reset();
/* 189:234 */             if (tkmultibean.count() == 1)
/* 190:    */             {
/* 191:236 */               tkmultibean.setValue("ASSETNUM", newAsset);
/* 192:    */               
/* 193:238 */               LinearAssetEventHandler.setMultiLinearFields(tkmultibean, assetmbo);
/* 194:239 */               tkmultibean.getDataBeanManager().save();
/* 195:    */             }
/* 196:    */           }
/* 197:    */         }
/* 198:    */       }
/* 199:    */     }
/* 200:245 */     return true;
/* 201:    */   }
/* 202:    */   
/* 203:    */   public boolean reportedbychanged(UIEvent event)
/* 204:    */     throws MobileApplicationException
/* 205:    */   {
/* 206:251 */     MobileMboDataBean databean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/* 207:252 */     if (databean != null) {
/* 208:256 */       if ((event.getValue() == null) || (((String)event.getValue()).length() == 0))
/* 209:    */       {
/* 210:258 */         databean.setValue("REPORTEDBYNAME", "");
/* 211:259 */         databean.setValue("REPORTEDBY", "");
/* 212:    */       }
/* 213:    */       else
/* 214:    */       {
/* 215:263 */         MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager("PERSONS");
/* 216:264 */         MobileMboDataBean personBean = mgrDBMgr.getDataBean();
/* 217:265 */         personBean.getQBE().reset();
/* 218:266 */         personBean.getQBE().setQbeExactMatch(true);
/* 219:    */         
/* 220:268 */         String personid = (String)event.getValue();
/* 221:269 */         personid = personid.toUpperCase();
/* 222:270 */         personBean.getQBE().setQBE("PERSONID", personid);
/* 223:    */         
/* 224:    */ 
/* 225:273 */         String reportedBy = ((String)event.getValue()).toUpperCase();
/* 226:274 */         databean.setValue("REPORTEDBY", reportedBy);
/* 227:277 */         if (personBean.getMobileMbo(0) == null)
/* 228:    */         {
/* 229:279 */           databean.setValue("REPORTEDBYNAME", "");
/* 230:    */         }
/* 231:    */         else
/* 232:    */         {
/* 233:283 */           databean.setValue("REPORTEDBYNAME", personBean.getValue(0, "DISPLAYNAME"));
/* 234:284 */           if (databean.getValue("AFFECTEDPERSONID").equals(""))
/* 235:    */           {
/* 236:287 */             databean.setValue("AFFECTEDPERSON", reportedBy);
/* 237:288 */             databean.setValue("AFFECTEDUSERNAME", personBean.getValue(0, "DISPLAYNAME"));
/* 238:    */           }
/* 239:    */         }
/* 240:    */       }
/* 241:    */     }
/* 242:295 */     return true;
/* 243:    */   }
/* 244:    */   
/* 245:    */   public boolean affectedpersonchanged(UIEvent event)
/* 246:    */     throws MobileApplicationException
/* 247:    */   {
/* 248:301 */     MobileMboDataBean databean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/* 249:302 */     if (databean != null) {
/* 250:306 */       if ((event.getValue() == null) || (((String)event.getValue()).length() == 0))
/* 251:    */       {
/* 252:308 */         databean.setValue("AFFECTEDUSERNAME", "");
/* 253:309 */         databean.setValue("AFFECTEDPERSON", "");
/* 254:    */       }
/* 255:    */       else
/* 256:    */       {
/* 257:313 */         MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager("PERSONS");
/* 258:314 */         MobileMboDataBean personBean = mgrDBMgr.getDataBean();
/* 259:315 */         personBean.getQBE().reset();
/* 260:316 */         personBean.getQBE().setQbeExactMatch(true);
/* 261:    */         
/* 262:318 */         String personid = (String)event.getValue();
/* 263:319 */         personid = personid.toUpperCase();
/* 264:320 */         personBean.getQBE().setQBE("PERSONID", personid);
/* 265:    */         
/* 266:322 */         databean.setValue("AFFECTEDPERSON", personid);
/* 267:325 */         if (personBean.getMobileMbo(0) == null) {
/* 268:327 */           databean.setValue("AFFECTEDUSERNAME", "");
/* 269:    */         } else {
/* 270:331 */           databean.setValue("AFFECTEDUSERNAME", personBean.getValue(0, "DISPLAYNAME"));
/* 271:    */         }
/* 272:    */       }
/* 273:    */     }
/* 274:338 */     return true;
/* 275:    */   }
/* 276:    */   
/* 277:    */   public boolean save(UIEvent event)
/* 278:    */     throws MobileApplicationException
/* 279:    */   {
/* 280:343 */     if (((PageControl)event.getCreatingObject()).getId().equalsIgnoreCase("ticketmain"))
/* 281:    */     {
/* 282:345 */       MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/* 283:346 */       if (databean != null)
/* 284:    */       {
/* 285:348 */         if ((databean.getMobileMbo() != null) && (databean.getMobileMbo().isToBeInserted()))
/* 286:    */         {
/* 287:351 */           String insertsigoption = "NEWPROB,CREATEPB";
/* 288:352 */           String tkclass = ((WOApp)UIUtil.getApplication()).getInternalValue(databean, "TKCLASS", databean.getValue("CLASS"));
/* 289:353 */           if (tkclass.equals("INCIDENT")) {
/* 290:354 */             insertsigoption = "NEWINC,CREATEIN";
/* 291:    */           }
/* 292:355 */           if (tkclass.equals("SR")) {
/* 293:356 */             insertsigoption = "NEWSR,CREATESR";
/* 294:    */           }
/* 295:364 */           ((PageControl)UIUtil.getCurrentScreen()).getControlData().putValue("insertesigoption", insertsigoption);
/* 296:    */         }
/* 297:370 */         MobileMboDataBean multiBean = databean.getDataBean("TKMULTIASSETLOCCI");
/* 298:371 */         if ((multiBean != null) && (multiBean.isMobileMboModified())) {
/* 299:373 */           multiBean.getDataBeanManager().save();
/* 300:    */         }
/* 301:    */       }
/* 302:    */     }
/* 303:378 */     return false;
/* 304:    */   }
/* 305:    */   
/* 306:    */   public boolean initactivitydetails(UIEvent event)
/* 307:    */     throws MobileApplicationException
/* 308:    */   {
/* 309:383 */     MobileMboDataBean databean = ((PageControl)event.getCreatingObject()).getDataBean();
/* 310:384 */     if ((databean.getMobileMbo() != null) && (databean.getValue("POINTNUM").equals("")))
/* 311:    */     {
/* 312:386 */       databean.getMobileMbo().setReadOnly("MEASUREMENTVALUE", true);
/* 313:387 */       databean.getMobileMbo().setReadOnly("MEASUREDATE", true);
/* 314:    */     }
/* 315:390 */     if ((databean.getMobileMbo() != null) && (databean.getMobileMbo().getLongValue("_ID") > 0L))
/* 316:    */     {
/* 317:394 */       MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager("WORKORDER");
/* 318:395 */       MobileMboDataBean woBean = mgrDBMgr.getDataBean();
/* 319:396 */       woBean.getQBE().setQbeExactMatch(true);
/* 320:397 */       woBean.getQBE().setQBE("_ID", "" + databean.getMobileMbo().getLongValue("_ID"));
/* 321:398 */       if (woBean.getMobileMbo(0) != null) {
/* 322:400 */         databean.getMobileMbo().setReadOnly(true);
/* 323:    */       }
/* 324:    */     }
/* 325:404 */     return true;
/* 326:    */   }
/* 327:    */   
/* 328:    */   public boolean initfailurereport(UIEvent event)
/* 329:    */     throws MobileApplicationException
/* 330:    */   {
/* 331:410 */     return true;
/* 332:    */   }
/* 333:    */   
/* 334:    */   public boolean validatecreatesolution(UIEvent event)
/* 335:    */     throws MobileApplicationException
/* 336:    */   {
/* 337:415 */     MobileMboDataBean databean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/* 338:416 */     if ((event.getValue() != null) && (((String)event.getValue()).equals("true")))
/* 339:    */     {
/* 340:418 */       if (UIUtil.checkESignature(event, databean, "CREATSOL"))
/* 341:    */       {
/* 342:420 */         databean.setValue("CREATESOLUTION", "1");
/* 343:421 */         UIUtil.refreshCurrentScreen();
/* 344:422 */         return false;
/* 345:    */       }
/* 346:426 */       event.setEventErrored();
/* 347:427 */       return true;
/* 348:    */     }
/* 349:431 */     return false;
/* 350:    */   }
/* 351:    */   
/* 352:    */   public boolean validatesolution(UIEvent event)
/* 353:    */     throws MobileApplicationException
/* 354:    */   {
/* 355:436 */     if ((event.getValue() == null) || (event.getValue().equals(""))) {
/* 356:437 */       return true;
/* 357:    */     }
/* 358:440 */     MobileMboDataBean databean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/* 359:    */     
/* 360:    */ 
/* 361:443 */     MobileMboDataBean solBean = UIUtil.getCurrentScreen().getDataBean();
/* 362:444 */     if ((solBean != null) && (solBean.getName().equalsIgnoreCase("SOLUTION")))
/* 363:    */     {
/* 364:446 */       if (!solBean.getValue("PROBLEMCODE_LONGDESCRIPTION").equals("")) {
/* 365:447 */         databean.setValue("PROBLEMCODE_LONGDESCRIPTION", solBean.getValue("PROBLEMCODE_LONGDESCRIPTION"));
/* 366:    */       }
/* 367:448 */       if (!solBean.getValue("FR1CODE_LONGDESCRIPTION").equals("")) {
/* 368:449 */         databean.setValue("FR1CODE_LONGDESCRIPTION", solBean.getValue("FR1CODE_LONGDESCRIPTION"));
/* 369:    */       }
/* 370:450 */       if (!solBean.getValue("FR2CODE_LONGDESCRIPTION").equals("")) {
/* 371:451 */         databean.setValue("FR2CODE_LONGDESCRIPTION", solBean.getValue("FR2CODE_LONGDESCRIPTION"));
/* 372:    */       }
/* 373:453 */       return true;
/* 374:    */     }
/* 375:456 */     MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager("SOLUTION");
/* 376:457 */     solBean = mgrDBMgr.getDataBean();
/* 377:458 */     solBean.getQBE().setQbeExactMatch(true);
/* 378:459 */     solBean.getQBE().setQBE("SOLUTION", (String)event.getValue());
/* 379:460 */     if (solBean.getMobileMbo(0) == null) {
/* 380:462 */       throw new MobileApplicationException("invalidSolution");
/* 381:    */     }
/* 382:466 */     if (!solBean.getMobileMbo(0).getValue("PROBLEMCODE_LONGDESCRIPTION").equals("")) {
/* 383:467 */       databean.setValue("PROBLEMCODE_LONGDESCRIPTION", solBean.getMobileMbo(0).getValue("PROBLEMCODE_LONGDESCRIPTION"));
/* 384:    */     }
/* 385:468 */     if (!solBean.getMobileMbo(0).getValue("FR1CODE_LONGDESCRIPTION").equals("")) {
/* 386:469 */       databean.setValue("FR1CODE_LONGDESCRIPTION", solBean.getMobileMbo(0).getValue("FR1CODE_LONGDESCRIPTION"));
/* 387:    */     }
/* 388:470 */     if (!solBean.getMobileMbo(0).getValue("FR2CODE_LONGDESCRIPTION").equals("")) {
/* 389:471 */       databean.setValue("FR2CODE_LONGDESCRIPTION", solBean.getMobileMbo(0).getValue("FR2CODE_LONGDESCRIPTION"));
/* 390:    */     }
/* 391:474 */     return true;
/* 392:    */   }
/* 393:    */   
/* 394:    */   public boolean caneditactivity(UIEvent event)
/* 395:    */     throws MobileApplicationException
/* 396:    */   {
/* 397:479 */     ((AbstractMobileControl)event.getCreatingObject()).setVisibility(!WOApp.isActivityAlsoWO());
/* 398:    */     
/* 399:481 */     return true;
/* 400:    */   }
/* 401:    */   
/* 402:    */   public boolean validatesiteid(UIEvent event)
/* 403:    */     throws MobileApplicationException
/* 404:    */   {
/* 405:487 */     MobileMboDataBean databean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/* 406:488 */     String siteid = (String)event.getValue();
/* 407:489 */     if ((siteid == null) || (siteid.equalsIgnoreCase("")))
/* 408:    */     {
/* 409:490 */       databean.setValue("ORGID", "");
/* 410:    */     }
/* 411:    */     else
/* 412:    */     {
/* 413:493 */       MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager("SITE");
/* 414:494 */       MobileMboDataBean siteBean = mgrDBMgr.getDataBean();
/* 415:495 */       siteBean.getQBE().reset();
/* 416:496 */       siteBean.getQBE().setQbeExactMatch(true);
/* 417:497 */       siteBean.getQBE().setQBE("SITEID", (String)event.getValue());
/* 418:498 */       siteBean.reset();
/* 419:499 */       if (siteBean.getMobileMbo(0) != null) {
/* 420:501 */         databean.setValue("BINNUM", "");
/* 421:    */       }
/* 422:    */     }
/* 423:505 */     return true;
/* 424:    */   }
/* 425:    */   
/* 426:    */   public boolean clrfailrepfield(UIEvent event)
/* 427:    */     throws MobileApplicationException
/* 428:    */   {
/* 429:511 */     MobileMboDataBean tkdatabean = UIUtil.getCurrentScreen().getDataBean();
/* 430:512 */     String launchingfield = ((TextboxControl)((PageControl)UIUtil.getCurrentScreen()).getCurrentInput()).getStringValue("dataattribute");
/* 431:    */     
/* 432:    */ 
/* 433:515 */     WOFailCodeEventHandler failcodehandler = new WOFailCodeEventHandler();
/* 434:516 */     failcodehandler.saveOriginalValues(tkdatabean);
/* 435:    */     
/* 436:518 */     int ifieldoffset = 0;
/* 437:519 */     if (!launchingfield.equals("FAILURECODE")) {
/* 438:522 */       ifieldoffset = launchingfield.charAt(launchingfield.length() - 1) - '0';
/* 439:    */     }
/* 440:525 */     if (ifieldoffset == 0)
/* 441:    */     {
/* 442:528 */       tkdatabean.setValue("FAILURECODE", "");
/* 443:    */       
/* 444:530 */       ifieldoffset = 1;
/* 445:    */     }
/* 446:534 */     tkdatabean.setValue("FAILUREREPORTCHANGED", "1");
/* 447:537 */     for (int i = ifieldoffset; i <= failcodehandler.getFailRepLevels(tkdatabean); i++)
/* 448:    */     {
/* 449:539 */       tkdatabean.setValue("FAILURECODE" + i, "");
/* 450:540 */       tkdatabean.setValue("FAILURECODE" + i + "_FAILURELIST", "");
/* 451:541 */       tkdatabean.setValue("FAILURECODE" + i + "_DISPLAY", "");
/* 452:    */     }
/* 453:544 */     tkdatabean.getDataBeanManager().save();
/* 454:545 */     UIUtil.refreshCurrentScreen();
/* 455:    */     
/* 456:547 */     return true;
/* 457:    */   }
/* 458:    */   
/* 459:    */   public boolean canshowsolutionview(UIEvent event)
/* 460:    */     throws MobileApplicationException
/* 461:    */   {
/* 462:552 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/* 463:553 */     boolean bShow = true;
/* 464:557 */     if ((UIUtil.getCurrentScreen().getId().equals("tktime")) && (databean.getName().equals("TKLABTRANS"))) {
/* 465:558 */       databean = databean.getParentBean();
/* 466:    */     }
/* 467:561 */     String tkclass = ((WOApp)UIUtil.getApplication()).getInternalValue(databean, "TKCLASS", databean.getValue("CLASS"));
/* 468:562 */     if (tkclass.equalsIgnoreCase("SR")) {
/* 469:563 */       bShow = false;
/* 470:    */     }
/* 471:566 */     ((AbstractMobileControl)event.getCreatingObject()).setVisibility(bShow);
/* 472:    */     
/* 473:568 */     return true;
/* 474:    */   }
/* 475:    */   
/* 476:    */   public boolean locationchanged(UIEvent event)
/* 477:    */     throws MobileApplicationException
/* 478:    */   {
/* 479:574 */     MobileMboDataBean databean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/* 480:575 */     if ((event.getValue() != null) && (!event.getValue().equals("")) && (databean.getMobileMbo().isNull("ASSETNUM")))
/* 481:    */     {
/* 482:579 */       MobileMboDataBeanManager mgr = new MobileMboDataBeanManager("ASSET");
/* 483:580 */       MobileMboDataBean assetdatabean = mgr.getDataBean();
/* 484:581 */       QBE qbe = assetdatabean.getQBE();
/* 485:582 */       qbe.reset();
/* 486:583 */       qbe.setQbeExactMatch(true);
/* 487:584 */       qbe.setQBE("LOCATION", (String)event.getValue());
/* 488:585 */       qbe.setQBE("SITEID", databean.getValue("SITEID"));
/* 489:586 */       assetdatabean.reset();
/* 490:587 */       if (assetdatabean.count() == 1) {
/* 491:589 */         databean.getMobileMbo().setValue("ASSETNUM", assetdatabean.getValue("ASSETNUM"));
/* 492:    */       }
/* 493:    */     }
/* 494:592 */     return true;
/* 495:    */   }
/* 496:    */   
/* 497:    */   public boolean cichanged(UIEvent event)
/* 498:    */     throws MobileApplicationException
/* 499:    */   {
/* 500:597 */     if ((event.getValue() != null) && (!event.getValue().equals("")))
/* 501:    */     {
/* 502:599 */       MobileMboDataBean databean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/* 503:600 */       if ((databean.getMobileMbo().isNull("ASSETNUM")) && (databean.getMobileMbo().isNull("LOCATION"))) {
/* 504:603 */         if (!databean.getMobileMbo().isNull("CIASSETNUM")) {
/* 505:605 */           databean.setValue("ASSETNUM", databean.getValue("CIASSETNUM"));
/* 506:607 */         } else if (!databean.getMobileMbo().isNull("CILOCATION")) {
/* 507:609 */           databean.setValue("LOCATION", databean.getValue("CILOCATION"));
/* 508:    */         }
/* 509:    */       }
/* 510:    */     }
/* 511:614 */     return true;
/* 512:    */   }
/* 513:    */   
/* 514:    */   public boolean defaultfailurereportremdate(UIEvent event)
/* 515:    */     throws MobileApplicationException
/* 516:    */   {
/* 517:621 */     MobileMboDataBean tkdatabean = UIUtil.getCurrentScreen().getDataBean();
/* 518:    */     
/* 519:    */ 
/* 520:624 */     WOFailCodeEventHandler failcodehandler = new WOFailCodeEventHandler();
/* 521:625 */     failcodehandler.saveOriginalValues(tkdatabean);
/* 522:    */     
/* 523:627 */     tkdatabean.setValue("FAILUREREPORTCHANGED", "1");
/* 524:629 */     if (tkdatabean.getValue("REMARKENTERDATE").equals("")) {
/* 525:630 */       tkdatabean.getMobileMbo().setDateValue("REMARKENTERDATE", tkdatabean.getCurrentTime());
/* 526:    */     }
/* 527:632 */     return true;
/* 528:    */   }
/* 529:    */   
/* 530:    */   public boolean validateactstart(UIEvent event)
/* 531:    */     throws MobileApplicationException
/* 532:    */   {
/* 533:637 */     if ((event.getValue() == null) || (event.getValue().equals(""))) {
/* 534:638 */       return true;
/* 535:    */     }
/* 536:640 */     MobileMboDataBean databean = ((TextboxControl)event.getCreatingObject()).getDataBean();
/* 537:641 */     if (databean.getValue("ACTUALFINISH").equals("")) {
/* 538:642 */       return true;
/* 539:    */     }
/* 540:644 */     if (((Date)event.getValue()).after(databean.getMobileMbo().getDateValue("ACTUALFINISH"))) {
/* 541:645 */       throw new MobileApplicationException("invalidactstart");
/* 542:    */     }
/* 543:647 */     return true;
/* 544:    */   }
/* 545:    */   
/* 546:    */   public boolean validateactfinish(UIEvent event)
/* 547:    */     throws MobileApplicationException
/* 548:    */   {
/* 549:652 */     if ((event.getValue() == null) || (event.getValue().equals(""))) {
/* 550:653 */       return true;
/* 551:    */     }
/* 552:655 */     MobileMboDataBean databean = ((TextboxControl)event.getCreatingObject()).getDataBean();
/* 553:656 */     if (databean.getValue("ACTUALSTART").equals("")) {
/* 554:657 */       return true;
/* 555:    */     }
/* 556:659 */     if (((Date)event.getValue()).before(databean.getMobileMbo().getDateValue("ACTUALSTART"))) {
/* 557:660 */       throw new MobileApplicationException("invalidactfin");
/* 558:    */     }
/* 559:662 */     return true;
/* 560:    */   }
/* 561:    */   
/* 562:    */   public boolean validatetargstart(UIEvent event)
/* 563:    */     throws MobileApplicationException
/* 564:    */   {
/* 565:667 */     if ((event.getValue() == null) || (event.getValue().equals(""))) {
/* 566:668 */       return true;
/* 567:    */     }
/* 568:670 */     MobileMboDataBean databean = ((TextboxControl)event.getCreatingObject()).getDataBean();
/* 569:671 */     if (databean.getValue("TARGETFINISH").equals("")) {
/* 570:672 */       return true;
/* 571:    */     }
/* 572:674 */     if (((Date)event.getValue()).after(databean.getMobileMbo().getDateValue("TARGETFINISH"))) {
/* 573:675 */       throw new MobileApplicationException("invalidtargstart");
/* 574:    */     }
/* 575:677 */     return true;
/* 576:    */   }
/* 577:    */   
/* 578:    */   public boolean validatetargend(UIEvent event)
/* 579:    */     throws MobileApplicationException
/* 580:    */   {
/* 581:682 */     if ((event.getValue() == null) || (event.getValue().equals(""))) {
/* 582:683 */       return true;
/* 583:    */     }
/* 584:685 */     MobileMboDataBean databean = ((TextboxControl)event.getCreatingObject()).getDataBean();
/* 585:686 */     if (databean.getValue("TARGETSTART").equals("")) {
/* 586:687 */       return true;
/* 587:    */     }
/* 588:689 */     if (((Date)event.getValue()).before(databean.getMobileMbo().getDateValue("TARGETSTART"))) {
/* 589:690 */       throw new MobileApplicationException("invalidtargcomp");
/* 590:    */     }
/* 591:692 */     return true;
/* 592:    */   }
/* 593:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.mobilewo.TKEventHandler
 * JD-Core Version:    0.7.0.1
 */