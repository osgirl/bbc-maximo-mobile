/*   1:    */ package com.mro.mobile.app.mobilewo;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.app.BasicMobileDeviceUIApplication;
/*   5:    */ import com.mro.mobile.mbo.MobileMbo;
/*   6:    */ import com.mro.mobile.mbo.MobileMboInfo;
/*   7:    */ import com.mro.mobile.mbo.MobileMboQBE;
/*   8:    */ import com.mro.mobile.ui.DataBeanCache;
/*   9:    */ import com.mro.mobile.ui.MobileMboDataBean;
/*  10:    */ import com.mro.mobile.ui.MobileMboDataBeanManager;
/*  11:    */ import com.mro.mobile.ui.event.UIEvent;
/*  12:    */ import com.mro.mobile.ui.res.ControlData;
/*  13:    */ import com.mro.mobile.ui.res.UIUtil;
/*  14:    */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*  15:    */ import com.mro.mobile.ui.res.controls.PageControl;
/*  16:    */ import com.mro.mobileapp.WOApp;
/*  17:    */ import java.util.Date;
/*  18:    */ import java.util.Vector;
/*  19:    */ 
/*  20:    */ public class WOFailCodeEventHandler
/*  21:    */   extends MobileWOCommonEventHandler
/*  22:    */ {
/*  23: 35 */   public int failrepLevels = -1;
/*  24:    */   
/*  25:    */   public boolean performEvent(UIEvent event)
/*  26:    */     throws MobileApplicationException
/*  27:    */   {
/*  28: 39 */     if (event == null) {
/*  29: 39 */       return false;
/*  30:    */     }
/*  31: 41 */     String eventId = event.getEventName();
/*  32: 43 */     if (eventId.equalsIgnoreCase("initpage")) {
/*  33: 45 */       return initpage(event);
/*  34:    */     }
/*  35: 47 */     if (eventId.equalsIgnoreCase("select")) {
/*  36: 49 */       return select(event);
/*  37:    */     }
/*  38: 51 */     if (eventId.equalsIgnoreCase("saveclose")) {
/*  39: 53 */       return saveclose(event);
/*  40:    */     }
/*  41: 56 */     if (eventId.equalsIgnoreCase("filter")) {
/*  42: 58 */       return filter(event);
/*  43:    */     }
/*  44: 61 */     if (eventId.equalsIgnoreCase("cancelpage")) {
/*  45: 63 */       return cancelPage(event);
/*  46:    */     }
/*  47: 66 */     super.performEvent(event);
/*  48:    */     
/*  49: 68 */     return false;
/*  50:    */   }
/*  51:    */   
/*  52:    */   private boolean cancelPage(UIEvent event)
/*  53:    */     throws MobileApplicationException
/*  54:    */   {
/*  55: 74 */     MobileMboDataBean woTkDatabean = ((PageControl)UIUtil.getCurrentScreen()).getLaunchingControl().getDataBean();
/*  56: 75 */     if (woTkDatabean != null) {
/*  57: 77 */       woTkDatabean.getDataBeanManager().cancel();
/*  58:    */     }
/*  59: 80 */     return false;
/*  60:    */   }
/*  61:    */   
/*  62:    */   protected boolean filter(UIEvent event)
/*  63:    */     throws MobileApplicationException
/*  64:    */   {
/*  65: 86 */     AbstractMobileControl curPage = UIUtil.getCurrentScreen();
/*  66: 87 */     if (curPage.getId().equalsIgnoreCase("failurecodefilter"))
/*  67:    */     {
/*  68: 89 */       MobileMboDataBean databean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*  69:    */       
/*  70: 91 */       databean.getQBE().setQbeExactMatch(false);
/*  71:    */     }
/*  72: 94 */     return false;
/*  73:    */   }
/*  74:    */   
/*  75:    */   public boolean initpage(UIEvent event)
/*  76:    */     throws MobileApplicationException
/*  77:    */   {
/*  78: 99 */     MobileMboDataBean wodatabean = ((PageControl)event.getCreatingObject()).getLaunchingControl().getDataBean();
/*  79:100 */     wodatabean.setValue("FAILUREREPORTPENDING", "0");
/*  80:    */     
/*  81:    */ 
/*  82:103 */     saveOriginalValues(wodatabean);
/*  83:104 */     String failurecode = wodatabean.getValue("FAILURECODE");
/*  84:106 */     if (failurecode.equals(""))
/*  85:    */     {
/*  86:107 */       restoreOriginalDataBean();
/*  87:    */     }
/*  88:    */     else
/*  89:    */     {
/*  90:109 */       MobileMboDataBean databean = getAndUpdateRightDataBean(failurecode, false);
/*  91:    */       
/*  92:    */ 
/*  93:112 */       databean.getQBE().setQbeExactMatch(true);
/*  94:115 */       if (wodatabean.getValue("FAILURECODE1").equals(""))
/*  95:    */       {
/*  96:117 */         MobileMbo failMbo = getFailureList(failurecode, null);
/*  97:118 */         if (failMbo != null)
/*  98:    */         {
/*  99:119 */           String failurelist = failMbo.getValue("FAILURELIST");
/* 100:120 */           databean.getQBE().setQBE("PARENT", failurelist);
/* 101:    */         }
/* 102:    */         else
/* 103:    */         {
/* 104:127 */           String failureList = wodatabean.getMobileMbo().getValue("FAILURELIST");
/* 105:128 */           if ((failureList != null) && (!failureList.equalsIgnoreCase(""))) {
/* 106:129 */             databean.getQBE().setQBE("PARENT", failureList);
/* 107:    */           }
/* 108:    */         }
/* 109:    */       }
/* 110:    */       else
/* 111:    */       {
/* 112:135 */         int levels = getFailRepLevels(wodatabean);
/* 113:136 */         for (int i = levels; i > 0; i--) {
/* 114:137 */           if (!wodatabean.getValue("FAILURECODE" + i).equals(""))
/* 115:    */           {
/* 116:138 */             databean.getQBE().setQBE("PARENT", wodatabean.getValue("FAILURECODE" + i + "_FAILURELIST"));
/* 117:    */             
/* 118:    */ 
/* 119:141 */             break;
/* 120:    */           }
/* 121:    */         }
/* 122:    */       }
/* 123:145 */       databean.reset();
/* 124:    */     }
/* 125:149 */     return true;
/* 126:    */   }
/* 127:    */   
/* 128:    */   protected void restoreOriginalDataBean()
/* 129:    */     throws MobileApplicationException
/* 130:    */   {
/* 131:153 */     PageControl thisPage = (PageControl)UIUtil.getApplication().getScreen("failurecodelookup");
/* 132:154 */     thisPage.getControlData().putValue("mobilembo", "FAILURELOOKUP");
/* 133:155 */     thisPage.getControlData().putValue("datasrcname", "FAILURELOOKUP");
/* 134:156 */     DataBeanCache.removeDataBean("FAILURECLASSHIER");
/* 135:157 */     DataBeanCache.removeDataBean("FAILURELIST");
/* 136:158 */     PageControl filterPage = (PageControl)UIUtil.getApplication().getScreen("failurecodefilter");
/* 137:159 */     filterPage.getControlData().putValue("datasrcname", "FAILURELOOKUP");
/* 138:    */   }
/* 139:    */   
/* 140:    */   protected MobileMboDataBean getAndUpdateRightDataBean(MobileMbo current, boolean online)
/* 141:    */     throws MobileApplicationException
/* 142:    */   {
/* 143:164 */     ensureExistsInFailureLookupTable(current);
/* 144:165 */     return getAndUpdateRightDataBean(current.getValue("FAILURECODE"), online);
/* 145:    */   }
/* 146:    */   
/* 147:    */   private void ensureExistsInFailureLookupTable(MobileMbo current)
/* 148:    */     throws MobileApplicationException
/* 149:    */   {
/* 150:169 */     ((WOApp)UIUtil.getApplication()).ensureExistsInFailureLookupTable(current);
/* 151:    */   }
/* 152:    */   
/* 153:    */   protected MobileMboDataBean getAndUpdateRightDataBean(String failureCode, boolean online)
/* 154:    */     throws MobileApplicationException
/* 155:    */   {
/* 156:174 */     MobileMboDataBean currentBean = DataBeanCache.findDataBean("FAILURELOOKUP");
/* 157:175 */     if (currentBean == null)
/* 158:    */     {
/* 159:176 */       currentBean = new MobileMboDataBeanManager("FAILURELOOKUP").getDataBean();
/* 160:177 */       currentBean.getQBE().setQbeExactMatch(true);
/* 161:178 */       currentBean.getQBE().setQBE("FAILURECODE", failureCode);
/* 162:179 */       currentBean.reset();
/* 163:    */     }
/* 164:181 */     MobileMbo selected = currentBean.getMobileMbo();
/* 165:182 */     String fromObject = null;
/* 166:184 */     if (selected != null) {
/* 167:185 */       fromObject = selected.getValue("LOOKUPFROMOBJECT");
/* 168:    */     }
/* 169:189 */     if ((fromObject == null) || (fromObject.equalsIgnoreCase(""))) {
/* 170:190 */       fromObject = "FAILURECLASSHIER";
/* 171:    */     }
/* 172:192 */     PageControl thisPage = (PageControl)UIUtil.getApplication().getScreen("failurecodelookup");
/* 173:193 */     thisPage.getControlData().putValue("mobilembo", fromObject);
/* 174:194 */     thisPage.getControlData().putValue("datasrcname", fromObject);
/* 175:195 */     PageControl filterPage = (PageControl)UIUtil.getApplication().getScreen("failurecodefilter");
/* 176:196 */     filterPage.getControlData().putValue("datasrcname", fromObject);
/* 177:197 */     DataBeanCache.removeDataBean("FAILURELOOKUP");
/* 178:198 */     MobileMboDataBean result = thisPage.getDataBean();
/* 179:    */     
/* 180:200 */     result.setOnline(online);
/* 181:201 */     return result;
/* 182:    */   }
/* 183:    */   
/* 184:    */   public void saveOriginalValues(MobileMboDataBean wodatabean)
/* 185:    */     throws MobileApplicationException
/* 186:    */   {
/* 187:206 */     if (!wodatabean.getMobileMbo().getBooleanValue("FAILUREREPORTCHANGED"))
/* 188:    */     {
/* 189:208 */       wodatabean.setValue("ORIG_FAILURECODE", "DUMMY");
/* 190:209 */       wodatabean.setValue("ORIG_FAILURECODE", wodatabean.getValue("FAILURECODE"));
/* 191:210 */       for (int i = 1; i < getFailRepLevels(wodatabean) + 1; i++)
/* 192:    */       {
/* 193:212 */         wodatabean.setValue("ORIG_FAILURECODE" + i, "DUMMY");
/* 194:213 */         wodatabean.setValue("ORIG_FAILURECODE" + i + "_LIST", "DUMMY");
/* 195:214 */         wodatabean.setValue("ORIG_FAILURECODE" + i, wodatabean.getValue("FAILURECODE" + i));
/* 196:215 */         wodatabean.setValue("ORIG_FAILURECODE" + i + "_LIST", wodatabean.getValue("FAILURECODE" + i + "_FAILURELIST"));
/* 197:    */       }
/* 198:217 */       wodatabean.setValue("ORIG_REMARKDESC", "DUMMY");
/* 199:218 */       wodatabean.setValue("ORIG_REMARKDESC", wodatabean.getValue("REMARKDESC"));
/* 200:219 */       wodatabean.getMobileMbo().setDateValue("ORIG_REMARKENTERDATE", new Date());
/* 201:220 */       wodatabean.getMobileMbo().setDateValue("ORIG_REMARKENTERDATE", wodatabean.getMobileMbo().getDateValue("REMARKENTERDATE"));
/* 202:    */     }
/* 203:    */   }
/* 204:    */   
/* 205:    */   public boolean select(UIEvent event)
/* 206:    */     throws MobileApplicationException
/* 207:    */   {
/* 208:227 */     MobileMboDataBean wodatabean = ((PageControl)UIUtil.getCurrentScreen()).getLaunchingControl().getDataBean();
/* 209:228 */     wodatabean.setValue("FAILUREREPORTPENDING", "1");
/* 210:    */     
/* 211:230 */     String failurelist = null;
/* 212:    */     
/* 213:232 */     MobileMboDataBean databean = null;
/* 214:233 */     if (needToChangeDataBean())
/* 215:    */     {
/* 216:234 */       MobileMboDataBean bean = DataBeanCache.findDataBean("FAILURELOOKUP");
/* 217:235 */       failurelist = bean.getMobileMbo().getValue("FAILURELIST");
/* 218:236 */       databean = getAndUpdateRightDataBean(bean.getMobileMbo(), bean.isOnline());
/* 219:    */     }
/* 220:    */     else
/* 221:    */     {
/* 222:238 */       databean = UIUtil.getCurrentScreen().getDataBean();
/* 223:239 */       failurelist = databean.getMobileMbo().getValue("FAILURELIST");
/* 224:    */     }
/* 225:243 */     MobileMboDataBean copyBean = new MobileMboDataBeanManager(databean.getName()).getDataBean();
/* 226:    */     
/* 227:    */ 
/* 228:246 */     copyBean.getQBE().setQBE("PARENT", failurelist);
/* 229:247 */     copyBean.getQBE().setQbeExactMatch(true);
/* 230:248 */     copyBean.reset();
/* 231:251 */     if (copyBean.count() == 0)
/* 232:    */     {
/* 233:254 */       wodatabean.setValue("FAILUREREPORTCHANGED", "1");
/* 234:    */       
/* 235:    */ 
/* 236:257 */       databean.getQBE().reset();
/* 237:258 */       databean.getQBE().setQBE("FAILURELIST", failurelist);
/* 238:259 */       databean.getQBE().setQbeExactMatch(true);
/* 239:260 */       databean.reset();
/* 240:262 */       if (validateandsavepage(event)) {
/* 241:263 */         UIUtil.getApplication().removeCurrentScreen(false);
/* 242:    */       }
/* 243:266 */       return true;
/* 244:    */     }
/* 245:269 */     databean.getQBE().reset();
/* 246:270 */     databean.getQBE().setQBE("PARENT", failurelist);
/* 247:271 */     databean.getQBE().setQbeExactMatch(true);
/* 248:272 */     databean.reset();
/* 249:    */     
/* 250:274 */     UIUtil.refreshCurrentScreen();
/* 251:275 */     return true;
/* 252:    */   }
/* 253:    */   
/* 254:    */   private boolean needToChangeDataBean()
/* 255:    */   {
/* 256:279 */     return "FAILURELOOKUP".equals(UIUtil.getCurrentScreen().getControlData().getValue("mobilembo"));
/* 257:    */   }
/* 258:    */   
/* 259:    */   public boolean saveclose(UIEvent event)
/* 260:    */     throws MobileApplicationException
/* 261:    */   {
/* 262:284 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/* 263:290 */     if (databean.getMobileMbo() != null)
/* 264:    */     {
/* 265:292 */       String parent = databean.getMobileMbo().getValue("PARENT");
/* 266:    */       
/* 267:    */ 
/* 268:295 */       databean.getQBE().reset();
/* 269:296 */       databean.getQBE().setQBE("FAILURELIST", parent);
/* 270:297 */       databean.getQBE().setQbeExactMatch(true);
/* 271:298 */       databean.reset();
/* 272:299 */       databean.setCurrentPosition(0);
/* 273:    */     }
/* 274:304 */     MobileMboDataBean wodatabean = ((PageControl)UIUtil.getCurrentScreen()).getLaunchingControl().getDataBean();
/* 275:305 */     if (wodatabean.getValue("FAILUREREPORTPENDING").equals("1")) {
/* 276:306 */       wodatabean.setValue("FAILUREREPORTCHANGED", "1");
/* 277:    */     }
/* 278:308 */     if (validateandsavepage(event)) {
/* 279:309 */       UIUtil.getApplication().removeCurrentScreen(false);
/* 280:    */     }
/* 281:311 */     return true;
/* 282:    */   }
/* 283:    */   
/* 284:    */   public boolean validateandsavepage(UIEvent event)
/* 285:    */     throws MobileApplicationException
/* 286:    */   {
/* 287:316 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/* 288:317 */     MobileMboDataBean wodatabean = ((PageControl)UIUtil.getCurrentScreen()).getLaunchingControl().getDataBean();
/* 289:320 */     if (wodatabean.getValue("FAILUREREPORTCHANGED").equals("0")) {
/* 290:321 */       return true;
/* 291:    */     }
/* 292:324 */     if (databean.getMobileMbo() == null) {
/* 293:325 */       return true;
/* 294:    */     }
/* 295:330 */     String curParent = databean.getMobileMbo().getValue("PARENT");
/* 296:331 */     String curFailurecode = databean.getMobileMbo().getValue("FAILURECODE");
/* 297:334 */     for (int i = 1; i < getFailRepLevels(wodatabean) + 1; i++)
/* 298:    */     {
/* 299:336 */       wodatabean.setValue("FAILURECODE" + i, "");
/* 300:337 */       wodatabean.setValue("FAILURECODE" + i + "_FAILURELIST", "");
/* 301:338 */       wodatabean.setValue("FAILURECODE" + i + "_DISPLAY", "");
/* 302:    */     }
/* 303:341 */     if (curParent.equals(""))
/* 304:    */     {
/* 305:345 */       wodatabean.setValue("FAILURECODE", curFailurecode);
/* 306:    */       
/* 307:    */ 
/* 308:348 */       wodatabean.setValue("FAILURELIST", databean.getMobileMbo().getValue("FAILURELIST"));
/* 309:    */       
/* 310:350 */       wodatabean.getDataBeanManager().save();
/* 311:351 */       return true;
/* 312:    */     }
/* 313:355 */     Vector vChoices = new Vector();
/* 314:356 */     vChoices.add(databean.getMobileMbo());
/* 315:    */     
/* 316:358 */     String topFailurecode = curFailurecode;
/* 317:359 */     MobileMbo failMbo = getFailureList(curParent, databean.isOnline());
/* 318:360 */     while (failMbo != null)
/* 319:    */     {
/* 320:362 */       vChoices.add(failMbo);
/* 321:363 */       topFailurecode = failMbo.getValue("FAILURECODE");
/* 322:364 */       String myParent = failMbo.getValue("PARENT");
/* 323:366 */       if (myParent.equals("")) {
/* 324:    */         break;
/* 325:    */       }
/* 326:368 */       failMbo = getFailureList(myParent, databean.isOnline());
/* 327:    */     }
/* 328:372 */     int listcount = vChoices.size();
/* 329:373 */     int fritem = listcount - 1;
/* 330:374 */     for (int i = 0; i < listcount; i++)
/* 331:    */     {
/* 332:377 */       MobileMbo savedFailMbo = (MobileMbo)vChoices.get(fritem);
/* 333:379 */       if (i == 0)
/* 334:    */       {
/* 335:381 */         wodatabean.setValue("FAILURECODE", savedFailMbo.getValue("FAILURECODE"));
/* 336:    */       }
/* 337:    */       else
/* 338:    */       {
/* 339:385 */         wodatabean.setValue("FAILURECODE" + i, savedFailMbo.getValue("FAILURECODE"));
/* 340:386 */         wodatabean.setValue("FAILURECODE" + i + "_FAILURELIST", savedFailMbo.getValue("FAILURELIST"));
/* 341:    */         
/* 342:388 */         wodatabean.setValue("FAILURECODE" + i + "_DISPLAY", savedFailMbo.getValue("DESCRIPTION"));
/* 343:    */       }
/* 344:391 */       fritem--;
/* 345:    */     }
/* 346:395 */     wodatabean.setValue("FAILURECODE", topFailurecode);
/* 347:    */     
/* 348:397 */     wodatabean.getDataBeanManager().save();
/* 349:    */     
/* 350:399 */     return true;
/* 351:    */   }
/* 352:    */   
/* 353:    */   public MobileMbo getFailureList(String failurelist, boolean online)
/* 354:    */     throws MobileApplicationException
/* 355:    */   {
/* 356:406 */     String databeanName = UIUtil.getCurrentScreen().getControlData().getValue("mobilembo");
/* 357:407 */     MobileMboDataBeanManager flBeanMgr = new MobileMboDataBeanManager(databeanName);
/* 358:408 */     MobileMboDataBean flBean = flBeanMgr.getDataBean();
/* 359:409 */     flBean.setOnline(online);
/* 360:    */     
/* 361:    */ 
/* 362:412 */     flBean.getQBE().reset();
/* 363:    */     
/* 364:414 */     flBean.getQBE().setQBE("FAILURELIST", failurelist);
/* 365:415 */     flBean.getQBE().setQbeExactMatch(true);
/* 366:416 */     flBean.reset();
/* 367:418 */     if (flBean.getMobileMbo(0) != null) {
/* 368:419 */       return flBean.getMobileMbo(0);
/* 369:    */     }
/* 370:421 */     return null;
/* 371:    */   }
/* 372:    */   
/* 373:    */   public MobileMbo getFailureList(String failurecode, String parent)
/* 374:    */     throws MobileApplicationException
/* 375:    */   {
/* 376:427 */     String databeanName = UIUtil.getApplication().getScreen("failurecodelookup").getControlData().getValue("mobilembo");
/* 377:428 */     MobileMboDataBeanManager flBeanMgr = new MobileMboDataBeanManager(databeanName);
/* 378:    */     
/* 379:430 */     MobileMboDataBean flBean = flBeanMgr.getDataBean();
/* 380:    */     
/* 381:    */ 
/* 382:433 */     flBean.getQBE().reset();
/* 383:    */     
/* 384:435 */     flBean.getQBE().setQBE("FAILURECODE", failurecode);
/* 385:436 */     if ((parent == null) || (parent.equals(""))) {
/* 386:437 */       flBean.getQBE().setQBE("PARENT", "~NULL~");
/* 387:    */     } else {
/* 388:439 */       flBean.getQBE().setQBE("PARENT", parent);
/* 389:    */     }
/* 390:440 */     flBean.getQBE().setQbeExactMatch(true);
/* 391:441 */     flBean.reset();
/* 392:443 */     if (flBean.getMobileMbo(0) != null) {
/* 393:444 */       return flBean.getMobileMbo(0);
/* 394:    */     }
/* 395:446 */     return null;
/* 396:    */   }
/* 397:    */   
/* 398:    */   public void setFailRepLevels(MobileMboDataBean wodatabean)
/* 399:    */   {
/* 400:453 */     MobileMboInfo woinfo = wodatabean.getMobileMboInfo();
/* 401:    */     
/* 402:455 */     int levels = 0;
/* 403:456 */     for (int i = 1; i < 26; i++)
/* 404:    */     {
/* 405:458 */       if (woinfo.getAttributeInfo("FAILURECODE" + i) == null) {
/* 406:    */         break;
/* 407:    */       }
/* 408:460 */       levels++;
/* 409:    */     }
/* 410:462 */     this.failrepLevels = levels;
/* 411:    */   }
/* 412:    */   
/* 413:    */   public int getFailRepLevels(MobileMboDataBean wodatabean)
/* 414:    */   {
/* 415:468 */     if (this.failrepLevels == -1) {
/* 416:470 */       setFailRepLevels(wodatabean);
/* 417:    */     }
/* 418:473 */     return this.failrepLevels;
/* 419:    */   }
/* 420:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.mobilewo.WOFailCodeEventHandler
 * JD-Core Version:    0.7.0.1
 */