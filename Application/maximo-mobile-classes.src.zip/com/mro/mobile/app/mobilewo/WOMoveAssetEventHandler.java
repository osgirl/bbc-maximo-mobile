/*   1:    */ package com.mro.mobile.app.mobilewo;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.MobileMessageGenerator;
/*   5:    */ import com.mro.mobile.app.BasicMobileDeviceUIApplication;
/*   6:    */ import com.mro.mobile.mbo.MobileMbo;
/*   7:    */ import com.mro.mobile.mbo.MobileMboAttributeInfo;
/*   8:    */ import com.mro.mobile.mbo.MobileMboInfo;
/*   9:    */ import com.mro.mobile.mbo.MobileMboQBE;
/*  10:    */ import com.mro.mobile.ui.DataBeanCache;
/*  11:    */ import com.mro.mobile.ui.MobileMboDataBean;
/*  12:    */ import com.mro.mobile.ui.MobileMboDataBeanManager;
/*  13:    */ import com.mro.mobile.ui.event.UIEvent;
/*  14:    */ import com.mro.mobile.ui.res.UIUtil;
/*  15:    */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*  16:    */ import com.mro.mobile.ui.res.controls.PageControl;
/*  17:    */ import com.mro.mobile.ui.res.controls.TextboxControl;
/*  18:    */ import com.mro.mobileapp.WOApp;
/*  19:    */ 
/*  20:    */ public class WOMoveAssetEventHandler
/*  21:    */   extends MobileWOCommonEventHandler
/*  22:    */ {
/*  23:    */   public boolean performEvent(UIEvent event)
/*  24:    */     throws MobileApplicationException
/*  25:    */   {
/*  26: 34 */     if (event == null) {
/*  27: 34 */       return false;
/*  28:    */     }
/*  29: 36 */     String eventId = event.getEventName();
/*  30: 38 */     if (eventId.equalsIgnoreCase("initScreen")) {
/*  31: 40 */       return initScreen(event);
/*  32:    */     }
/*  33: 42 */     if (eventId.equalsIgnoreCase("validateField")) {
/*  34: 44 */       return validateField(event);
/*  35:    */     }
/*  36: 46 */     if (eventId.equalsIgnoreCase("validateParentField")) {
/*  37: 48 */       return validateParentField(event);
/*  38:    */     }
/*  39: 50 */     if (eventId.equalsIgnoreCase("validateLocField")) {
/*  40: 52 */       return validateLocField(event);
/*  41:    */     }
/*  42: 54 */     if (eventId.equalsIgnoreCase("validateBinField")) {
/*  43: 56 */       return validateBinField(event);
/*  44:    */     }
/*  45: 58 */     if (eventId.equalsIgnoreCase("validateReplaceAssetNum")) {
/*  46: 60 */       return validateReplaceAssetNum(event);
/*  47:    */     }
/*  48: 62 */     if (eventId.equalsIgnoreCase("validateReplacementSite")) {
/*  49: 64 */       return validateReplacementSite(event);
/*  50:    */     }
/*  51: 66 */     if (eventId.equalsIgnoreCase("validateMoveToSite")) {
/*  52: 68 */       return validateMoveToSite(event);
/*  53:    */     }
/*  54: 71 */     if (eventId.equalsIgnoreCase("validateMoveSwap")) {
/*  55: 73 */       return validateMoveSwap(event);
/*  56:    */     }
/*  57: 76 */     if (eventId.equalsIgnoreCase("setReplaceAssetLookup")) {
/*  58: 78 */       return setReplaceAssetLookup(event);
/*  59:    */     }
/*  60: 81 */     if (eventId.equalsIgnoreCase("initmovetoloclookup")) {
/*  61: 83 */       return initmovetoloclookup(event);
/*  62:    */     }
/*  63: 86 */     if (eventId.equalsIgnoreCase("initassetlookupparent")) {
/*  64: 88 */       return initAssetLookupParent(event);
/*  65:    */     }
/*  66: 91 */     if (eventId.equalsIgnoreCase("initreplacementtab")) {
/*  67: 93 */       return initReplacementTab(event);
/*  68:    */     }
/*  69: 96 */     if (eventId.equalsIgnoreCase("validateNewAsset")) {
/*  70: 98 */       return validateNewAsset(event);
/*  71:    */     }
/*  72:100 */     super.performEvent(event);
/*  73:    */     
/*  74:102 */     return false;
/*  75:    */   }
/*  76:    */   
/*  77:    */   protected boolean initAssetLookupParent(UIEvent event)
/*  78:    */     throws MobileApplicationException
/*  79:    */   {
/*  80:114 */     filterLookupBean(event, "MOVETOSITE", "SITEID");
/*  81:115 */     filterLookupBean(event, "MOVETOLOCATION", "LOCATION");
/*  82:    */     
/*  83:117 */     return true;
/*  84:    */   }
/*  85:    */   
/*  86:    */   private void filterLookupBean(UIEvent event, String databeanAttribute, String lookupBeanAttribute)
/*  87:    */     throws MobileApplicationException
/*  88:    */   {
/*  89:132 */     MobileMboDataBean dataBean = ((PageControl)event.getCreatingObject()).getLaunchingControl().getPage().getDataBean();
/*  90:    */     
/*  91:134 */     MobileMboDataBean lookupDataBean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*  92:136 */     if ((dataBean != null) && (lookupDataBean != null))
/*  93:    */     {
/*  94:138 */       String attribute = dataBean.getValue(databeanAttribute);
/*  95:139 */       if ((attribute != null) && (attribute.length() > 0))
/*  96:    */       {
/*  97:141 */         lookupDataBean.setInternalQBE(lookupBeanAttribute, attribute);
/*  98:    */       }
/*  99:    */       else
/* 100:    */       {
/* 101:145 */         String defaultAttribute = null;
/* 102:146 */         if (lookupBeanAttribute.equalsIgnoreCase("SITEID")) {
/* 103:148 */           defaultAttribute = UIUtil.getApplication().getDefaultInsertSite();
/* 104:    */         }
/* 105:150 */         lookupDataBean.setInternalQBE(lookupBeanAttribute, defaultAttribute);
/* 106:    */       }
/* 107:152 */       lookupDataBean.reset();
/* 108:    */     }
/* 109:    */   }
/* 110:    */   
/* 111:    */   private boolean validateNewAsset(UIEvent event)
/* 112:    */     throws MobileApplicationException
/* 113:    */   {
/* 114:167 */     AbstractMobileControl control = (AbstractMobileControl)event.getCreatingObject();
/* 115:168 */     MobileMboDataBean dataBean = control.getDataBean();
/* 116:    */     
/* 117:170 */     String currentAssetNum = dataBean.getValue("ASSETNUM");
/* 118:171 */     String newAssetNum = (String)event.getValue();
/* 119:173 */     if (!currentAssetNum.equalsIgnoreCase(newAssetNum)) {
/* 120:175 */       dataBean.setValue("NEWASSETNUM", newAssetNum, false);
/* 121:    */     } else {
/* 122:179 */       dataBean.setValue("NEWASSETNUM", "", false);
/* 123:    */     }
/* 124:182 */     return true;
/* 125:    */   }
/* 126:    */   
/* 127:    */   public boolean initReplacementTab(UIEvent event)
/* 128:    */     throws MobileApplicationException
/* 129:    */   {
/* 130:189 */     MobileMboDataBean dataBean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/* 131:192 */     if ((dataBean.getValue("REPLACEMENTSITE") != null) && (dataBean.getValue("REPLACEMENTSITE").length() > 0)) {
/* 132:194 */       return true;
/* 133:    */     }
/* 134:198 */     String assetNum = dataBean.getValue("ASSETNUM");
/* 135:199 */     if (assetNum.length() > 0)
/* 136:    */     {
/* 137:201 */       String assetSite = "";
/* 138:202 */       MobileMboDataBean assetBean = DataBeanCache.getDataBean("ASSET", "ASSET");
/* 139:203 */       int count = assetBean.count();
/* 140:205 */       for (int i = 0; i < count; i++) {
/* 141:207 */         if (assetNum.equals(assetBean.getValue(i, "ASSETNUM")))
/* 142:    */         {
/* 143:209 */           assetSite = assetBean.getValue(i, "SITEID");
/* 144:210 */           break;
/* 145:    */         }
/* 146:    */       }
/* 147:213 */       if (assetSite.length() > 0) {
/* 148:215 */         dataBean.setValue("REPLACEMENTSITE", assetSite);
/* 149:    */       }
/* 150:    */     }
/* 151:220 */     return true;
/* 152:    */   }
/* 153:    */   
/* 154:    */   public boolean initmovetoloclookup(UIEvent event)
/* 155:    */     throws MobileApplicationException
/* 156:    */   {
/* 157:227 */     filterLookupBean(event, "MOVETOSITE", "SITEID");
/* 158:228 */     return true;
/* 159:    */   }
/* 160:    */   
/* 161:    */   public boolean setReplaceAssetLookup(UIEvent event)
/* 162:    */     throws MobileApplicationException
/* 163:    */   {
/* 164:235 */     MobileMboDataBean dataBean = ((PageControl)event.getCreatingObject()).getLaunchingControl().getPage().getDataBean();
/* 165:    */     
/* 166:237 */     MobileMboDataBean lookupDataBean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/* 167:239 */     if ((dataBean != null) && (lookupDataBean != null))
/* 168:    */     {
/* 169:243 */       String decommissionedStatus = ((WOApp)UIUtil.getApplication()).getDefaultValue(dataBean, "LOC_ASSETSTATUS", "DECOMMISSIONED");
/* 170:244 */       lookupDataBean.getQBE().setQBE("STATUS", "!=" + decommissionedStatus);
/* 171:    */       
/* 172:246 */       String replaceSite = dataBean.getValue("REPLACEMENTSITE");
/* 173:247 */       if ((replaceSite != null) && (replaceSite.length() > 0))
/* 174:    */       {
/* 175:249 */         lookupDataBean.setInternalQBE("SITEID", replaceSite);
/* 176:250 */         lookupDataBean.reset();
/* 177:    */       }
/* 178:    */       else
/* 179:    */       {
/* 180:254 */         String defaultSite = UIUtil.getApplication().getDefaultInsertSite();
/* 181:255 */         lookupDataBean.setInternalQBE("SITEID", defaultSite);
/* 182:256 */         lookupDataBean.reset();
/* 183:    */       }
/* 184:    */     }
/* 185:259 */     return true;
/* 186:    */   }
/* 187:    */   
/* 188:    */   private boolean validateMoveSwap(UIEvent event)
/* 189:    */     throws MobileApplicationException
/* 190:    */   {
/* 191:265 */     String msgResponse = event.getMsgResponse();
/* 192:266 */     if (msgResponse.equals("-1"))
/* 193:    */     {
/* 194:268 */       MobileMboDataBean databean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/* 195:269 */       if (databean.getValue("MOVETOLOCATION").trim().equals(""))
/* 196:    */       {
/* 197:271 */         UIUtil.showOKCANCELMessageBox(event, MobileMessageGenerator.generate("tolocationnotset", null));
/* 198:272 */         event.setEventErrored();
/* 199:    */       }
/* 200:    */     }
/* 201:275 */     else if (msgResponse.equals("2"))
/* 202:    */     {
/* 203:278 */       event.setEventErrored();
/* 204:    */     }
/* 205:281 */     return true;
/* 206:    */   }
/* 207:    */   
/* 208:    */   public boolean initScreen(UIEvent event)
/* 209:    */     throws MobileApplicationException
/* 210:    */   {
/* 211:288 */     MobileMboDataBean databean = ((PageControl)event.getCreatingObject()).getDataBean();
/* 212:289 */     MobileMboDataBean assetdatabean = databean.getDataBean("MULTIASSET");
/* 213:    */     
/* 214:291 */     PageControl page = (PageControl)event.getCreatingObject();
/* 215:292 */     String pageID = page.getId();
/* 216:294 */     if ((assetdatabean == null) || (assetdatabean.getMobileMbo(0) == null)) {
/* 217:295 */       return true;
/* 218:    */     }
/* 219:299 */     if (isInventoryLocation(assetdatabean))
/* 220:    */     {
/* 221:301 */       databean.getMobileMboInfo().getAttributeInfo("MOVETOLOCATION").setReadOnly(true);
/* 222:302 */       databean.getMobileMboInfo().getAttributeInfo("MOVETOPARENT").setReadOnly(true);
/* 223:303 */       databean.getMobileMboInfo().getAttributeInfo("MOVETOBIN").setReadOnly(false);
/* 224:    */     }
/* 225:    */     else
/* 226:    */     {
/* 227:307 */       databean.getMobileMboInfo().getAttributeInfo("MOVETOLOCATION").setReadOnly(false);
/* 228:308 */       databean.getMobileMboInfo().getAttributeInfo("MOVETOPARENT").setReadOnly(false);
/* 229:309 */       databean.getMobileMboInfo().getAttributeInfo("MOVETOBIN").setReadOnly(true);
/* 230:    */     }
/* 231:312 */     databean.getMobileMboInfo().getAttributeInfo("DISPLAY_NEWASSETNUM").setReadOnly(true);
/* 232:313 */     databean.getMobileMboInfo().getAttributeInfo("NEWREPLACEASSETNUM").setReadOnly(true);
/* 233:318 */     if (databean.getValue("PERFORMMOVETO").equals("1"))
/* 234:    */     {
/* 235:320 */       if (!databean.getValue("SITEID").equals(databean.getValue("MOVETOSITE"))) {
/* 236:322 */         databean.getMobileMboInfo().getAttributeInfo("DISPLAY_NEWASSETNUM").setReadOnly(false);
/* 237:    */       }
/* 238:325 */       if (!databean.getValue("SITEID").equals(databean.getValue("REPLACEMENTSITE"))) {
/* 239:327 */         databean.getMobileMboInfo().getAttributeInfo("NEWREPLACEASSETNUM").setReadOnly(false);
/* 240:    */       }
/* 241:331 */       databean.setValue("DISPLAY_NEWASSETNUM", databean.getValue("NEWASSETNUM"), false);
/* 242:332 */       return true;
/* 243:    */     }
/* 244:335 */     databean.setValue("PERFORMMOVETO", "0");
/* 245:    */     
/* 246:    */ 
/* 247:338 */     databean.setValue("MOVETOLOCATION", "");
/* 248:339 */     databean.setValue("MOVETOPARENT", assetdatabean.getValue("PARENT"));
/* 249:340 */     databean.setValue("MOVETOBIN", assetdatabean.getValue("BINNUM"));
/* 250:341 */     databean.setValue("DISPLAY_NEWASSETNUM", assetdatabean.getValue("ASSETNUM"), false);
/* 251:342 */     databean.setValue("MOVETOSITE", assetdatabean.getValue("SITEID"));
/* 252:    */     
/* 253:344 */     return true;
/* 254:    */   }
/* 255:    */   
/* 256:    */   public boolean validateParentField(UIEvent event)
/* 257:    */     throws MobileApplicationException
/* 258:    */   {
/* 259:350 */     AbstractMobileControl control = (AbstractMobileControl)event.getCreatingObject();
/* 260:351 */     MobileMboDataBean multiBean = control.getDataBean();
/* 261:352 */     MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager("ASSET");
/* 262:353 */     MobileMboDataBean assetBean = mgrDBMgr.getDataBean();
/* 263:    */     
/* 264:355 */     assetBean.getQBE().setQBE("ASSETNUM", multiBean.getValue("ASSETNUM"));
/* 265:356 */     assetBean.getQBE().setQBE("SITEID", multiBean.getValue("SITEID"));
/* 266:357 */     assetBean.reset();
/* 267:359 */     if (!assetBean.getValue("PARENT").equalsIgnoreCase((String)event.getValue())) {
/* 268:361 */       multiBean.setValue("PERFORMMOVETO", "1", false);
/* 269:    */     }
/* 270:364 */     return validateField(event);
/* 271:    */   }
/* 272:    */   
/* 273:    */   public boolean validateLocField(UIEvent event)
/* 274:    */     throws MobileApplicationException
/* 275:    */   {
/* 276:370 */     AbstractMobileControl control = (AbstractMobileControl)event.getCreatingObject();
/* 277:371 */     MobileMboDataBean multiBean = control.getDataBean();
/* 278:372 */     MobileMboDataBeanManager mobileMboDBMgr = new MobileMboDataBeanManager("ASSET");
/* 279:373 */     MobileMboDataBean assetBean = mobileMboDBMgr.getDataBean();
/* 280:    */     
/* 281:375 */     assetBean.getQBE().setQBE("ASSETNUM", multiBean.getValue("ASSETNUM"));
/* 282:376 */     assetBean.getQBE().setQBE("SITEID", multiBean.getValue("SITEID"));
/* 283:377 */     assetBean.reset();
/* 284:379 */     if (!assetBean.getValue("LOCATION").equalsIgnoreCase((String)event.getValue())) {
/* 285:381 */       multiBean.setValue("PERFORMMOVETO", "1", false);
/* 286:    */     }
/* 287:384 */     if ((event.getValue() == null) || (event.getValue().equals(""))) {
/* 288:385 */       return true;
/* 289:    */     }
/* 290:386 */     MobileMboDataBean wodatabean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/* 291:    */     
/* 292:    */ 
/* 293:389 */     MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager("LOCATIONS");
/* 294:390 */     MobileMboDataBean locBean = mgrDBMgr.getDataBean();
/* 295:391 */     locBean.getQBE().setQBE("LOCATION", (String)event.getValue());
/* 296:392 */     locBean.getQBE().setQBE("SITEID", wodatabean.getValue("SITEID"));
/* 297:393 */     if (locBean.getMobileMbo(0) == null) {
/* 298:394 */       return true;
/* 299:    */     }
/* 300:396 */     if (isInvalidLoc(locBean)) {
/* 301:398 */       throw new MobileApplicationException("invalidMoveToLoc");
/* 302:    */     }
/* 303:401 */     return validateField(event);
/* 304:    */   }
/* 305:    */   
/* 306:    */   public boolean validateReplaceAssetNum(UIEvent event)
/* 307:    */     throws MobileApplicationException
/* 308:    */   {
/* 309:406 */     MobileMboDataBean multiBean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/* 310:407 */     MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager("ASSET");
/* 311:408 */     MobileMboDataBean assetBean = mgrDBMgr.getDataBean();
/* 312:    */     
/* 313:410 */     assetBean.getQBE().setQBE("ASSETNUM", (String)event.getValue());
/* 314:411 */     assetBean.getQBE().setQBE("SITEID", multiBean.getValue("REPLACEMENTSITE"));
/* 315:412 */     assetBean.reset();
/* 316:421 */     if ((event.getValue() != null) && (((String)event.getValue()).trim() != "") && (!multiBean.getValue("ASSETNUM").equalsIgnoreCase((String)event.getValue()))) {
/* 317:425 */       multiBean.setValue("PERFORMMOVETO", "1", false);
/* 318:    */     }
/* 319:428 */     if (!"".equalsIgnoreCase(((String)event.getValue()).trim())) {
/* 320:430 */       multiBean.setValue("NEWREPLACEASSETNUM", (String)event.getValue(), false);
/* 321:    */     }
/* 322:433 */     if (assetBean.count() == 1)
/* 323:    */     {
/* 324:435 */       multiBean.setValue("FROMPARENT", assetBean.getValue("PARENT"));
/* 325:436 */       multiBean.setValue("FROMLOCATION", assetBean.getValue("LOCATION"));
/* 326:437 */       multiBean.setValue("FROMBIN", assetBean.getValue("BINNUM"));
/* 327:438 */       multiBean.setValue("REPLACEMENTSITE", assetBean.getValue("SITEID"));
/* 328:    */     }
/* 329:    */     else
/* 330:    */     {
/* 331:442 */       multiBean.setValue("FROMPARENT", "");
/* 332:443 */       multiBean.setValue("FROMLOCATION", "");
/* 333:444 */       multiBean.setValue("FROMBIN", "");
/* 334:    */     }
/* 335:447 */     boolean replaceAssetReadOnly = multiBean.getValue("REPLACEMENTSITE").equals(multiBean.getValue("SITEID"));
/* 336:    */     
/* 337:449 */     multiBean.getMobileMboInfo().getAttributeInfo("NEWREPLACEASSETNUM").setReadOnly(replaceAssetReadOnly);
/* 338:    */     
/* 339:451 */     UIUtil.refreshCurrentScreen();
/* 340:    */     
/* 341:453 */     return true;
/* 342:    */   }
/* 343:    */   
/* 344:    */   public boolean validateReplacementSite(UIEvent event)
/* 345:    */     throws MobileApplicationException
/* 346:    */   {
/* 347:458 */     MobileMboDataBean multiBean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/* 348:    */     
/* 349:    */ 
/* 350:461 */     boolean replaceAssetReadOnly = multiBean.getValue("SITEID").equalsIgnoreCase((String)event.getValue());
/* 351:468 */     if ((event.getValue() != null) && (((String)event.getValue()).trim().length() > 0) && (!multiBean.getValue("SITEID").equalsIgnoreCase((String)event.getValue()))) {
/* 352:472 */       multiBean.setValue("PERFORMMOVETO", "1", false);
/* 353:    */     }
/* 354:475 */     if (!multiBean.getValue("REPLACEMENTSITE").equalsIgnoreCase((String)event.getValue()))
/* 355:    */     {
/* 356:477 */       multiBean.setValue("REPLACEASSETNUM", "", false);
/* 357:478 */       multiBean.setValue("FROMPARENT", "", false);
/* 358:479 */       multiBean.setValue("FROMLOCATION", "", false);
/* 359:480 */       multiBean.setValue("FROMBIN", "", false);
/* 360:481 */       multiBean.setValue("NEWREPLACEASSETNUM", "", false);
/* 361:    */     }
/* 362:484 */     multiBean.getMobileMboInfo().getAttributeInfo("NEWREPLACEASSETNUM").setReadOnly(replaceAssetReadOnly);
/* 363:    */     
/* 364:486 */     return true;
/* 365:    */   }
/* 366:    */   
/* 367:    */   public boolean validateMoveToSite(UIEvent event)
/* 368:    */     throws MobileApplicationException
/* 369:    */   {
/* 370:495 */     MobileMboDataBean multiBean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/* 371:497 */     if ((event.getValue() != null) && (((String)event.getValue()).trim().length() > 0) && (!multiBean.getValue("SITEID").equalsIgnoreCase((String)event.getValue()))) {
/* 372:501 */       multiBean.setValue("PERFORMMOVETO", "1", false);
/* 373:    */     }
/* 374:505 */     boolean replaceAssetReadOnly = multiBean.getValue("SITEID").equalsIgnoreCase((String)event.getValue());
/* 375:    */     
/* 376:507 */     multiBean.getMobileMboInfo().getAttributeInfo("DISPLAY_NEWASSETNUM").setReadOnly(replaceAssetReadOnly);
/* 377:    */     
/* 378:509 */     return true;
/* 379:    */   }
/* 380:    */   
/* 381:    */   public boolean validateBinField(UIEvent event)
/* 382:    */     throws MobileApplicationException
/* 383:    */   {
/* 384:515 */     AbstractMobileControl control = (AbstractMobileControl)event.getCreatingObject();
/* 385:516 */     MobileMboDataBean multiBean = control.getDataBean();
/* 386:517 */     MobileMboDataBeanManager mobileMboDBMgr = new MobileMboDataBeanManager("ASSET");
/* 387:518 */     MobileMboDataBean assetBean = mobileMboDBMgr.getDataBean();
/* 388:    */     
/* 389:520 */     assetBean.getQBE().setQBE("ASSETNUM", multiBean.getValue("ASSETNUM"));
/* 390:521 */     assetBean.getQBE().setQBE("SITEID", multiBean.getValue("SITEID"));
/* 391:522 */     assetBean.reset();
/* 392:524 */     if (!assetBean.getValue("BINNUM").equalsIgnoreCase((String)event.getValue())) {
/* 393:526 */       multiBean.setValue("PERFORMMOVETO", "1", false);
/* 394:    */     }
/* 395:529 */     return validateField(event);
/* 396:    */   }
/* 397:    */   
/* 398:    */   public boolean validateField(UIEvent event)
/* 399:    */     throws MobileApplicationException
/* 400:    */   {
/* 401:536 */     MobileMboDataBean databean = ((TextboxControl)event.getCreatingObject()).getDataBean().getParentBean();
/* 402:537 */     databean.setValue("EXECUTEATTRMOVECHANGES", "1");
/* 403:    */     
/* 404:539 */     return true;
/* 405:    */   }
/* 406:    */   
/* 407:    */   private boolean isInventoryLocation(MobileMboDataBean assetdatabean)
/* 408:    */     throws MobileApplicationException
/* 409:    */   {
/* 410:544 */     if (assetdatabean.getMobileMbo(0) == null) {
/* 411:545 */       return false;
/* 412:    */     }
/* 413:548 */     if (assetdatabean.getMobileMbo(0).getValue("LOCATION").equals("")) {
/* 414:549 */       return false;
/* 415:    */     }
/* 416:553 */     MobileMboDataBean locdatabean = assetdatabean.getDataBean(0, "ASSETLOC");
/* 417:554 */     if (locdatabean.getMobileMbo(0) == null) {
/* 418:555 */       return false;
/* 419:    */     }
/* 420:557 */     return locdatabean.getMobileMbo(0).getBooleanValue("ISINVENTORYLOCATION");
/* 421:    */   }
/* 422:    */   
/* 423:    */   private boolean isInvalidLoc(MobileMboDataBean locdatabean)
/* 424:    */     throws MobileApplicationException
/* 425:    */   {
/* 426:587 */     if (locdatabean.getMobileMbo(0) == null) {
/* 427:588 */       return false;
/* 428:    */     }
/* 429:590 */     String internalLocType = ((WOApp)UIUtil.getApplication()).getInternalValue(locdatabean, "LOCTYPE", locdatabean.getMobileMbo(0).getValue("TYPE"));
/* 430:594 */     if ((internalLocType.equals("STOREROOM")) || (internalLocType.equals("COURIER")) || (internalLocType.equals("LABOR"))) {
/* 431:595 */       return true;
/* 432:    */     }
/* 433:597 */     return false;
/* 434:    */   }
/* 435:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.mobilewo.WOMoveAssetEventHandler
 * JD-Core Version:    0.7.0.1
 */