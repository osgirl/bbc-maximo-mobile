/*  1:   */ package com.mro.mobile.app.mobilewo;
/*  2:   */ 
/*  3:   */ import com.mro.mobile.MobileApplicationException;
/*  4:   */ import com.mro.mobile.ui.event.UIEvent;
/*  5:   */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*  6:   */ import com.mro.mobileapp.WOApp;
/*  7:   */ 
/*  8:   */ public class TKMenuBarEventHandler
/*  9:   */   extends MobileWOCommonEventHandler
/* 10:   */ {
/* 11:   */   public boolean performEvent(UIEvent event)
/* 12:   */     throws MobileApplicationException
/* 13:   */   {
/* 14:26 */     if (event == null) {
/* 15:26 */       return false;
/* 16:   */     }
/* 17:28 */     String eventId = event.getEventName();
/* 18:30 */     if (eventId.equalsIgnoreCase("done"))
/* 19:   */     {
/* 20:33 */       saveLinearDetails();
/* 21:34 */       return super.done(event);
/* 22:   */     }
/* 23:36 */     if (eventId.equalsIgnoreCase("prevrec")) {
/* 24:38 */       return super.prevrec(event);
/* 25:   */     }
/* 26:40 */     if (eventId.equalsIgnoreCase("nextrec")) {
/* 27:42 */       return super.nextrec(event);
/* 28:   */     }
/* 29:44 */     if (eventId.equalsIgnoreCase("caneditactivity")) {
/* 30:46 */       return caneditactivity(event);
/* 31:   */     }
/* 32:49 */     super.performEvent(event);
/* 33:   */     
/* 34:51 */     return false;
/* 35:   */   }
/* 36:   */   
/* 37:   */   public boolean caneditactivity(UIEvent event)
/* 38:   */     throws MobileApplicationException
/* 39:   */   {
/* 40:56 */     ((AbstractMobileControl)event.getCreatingObject()).setVisibility(!WOApp.isActivityAlsoWO());
/* 41:   */     
/* 42:58 */     return true;
/* 43:   */   }
/* 44:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.mobilewo.TKMenuBarEventHandler
 * JD-Core Version:    0.7.0.1
 */