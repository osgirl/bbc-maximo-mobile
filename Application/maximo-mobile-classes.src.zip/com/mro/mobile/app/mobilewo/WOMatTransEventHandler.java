/*    1:     */ package com.mro.mobile.app.mobilewo;
/*    2:     */ 
/*    3:     */ import com.mro.mobile.MobileApplicationException;
/*    4:     */ import com.mro.mobile.MobileMessageGenerator;
/*    5:     */ import com.mro.mobile.app.BasicMobileDeviceUIApplication;
/*    6:     */ import com.mro.mobile.app.DefaultMobileMboDataFormatter;
/*    7:     */ import com.mro.mobile.mbo.MobileMbo;
/*    8:     */ import com.mro.mobile.mbo.MobileMboQBE;
/*    9:     */ import com.mro.mobile.ui.DataBeanCache;
/*   10:     */ import com.mro.mobile.ui.MobileMboDataBean;
/*   11:     */ import com.mro.mobile.ui.MobileMboDataBeanManager;
/*   12:     */ import com.mro.mobile.ui.event.UIEvent;
/*   13:     */ import com.mro.mobile.ui.res.UIUtil;
/*   14:     */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*   15:     */ import com.mro.mobile.ui.res.controls.PageControl;
/*   16:     */ import com.mro.mobile.ui.res.controls.TableControl;
/*   17:     */ import com.mro.mobileapp.WOApp;
/*   18:     */ import java.util.List;
/*   19:     */ 
/*   20:     */ public class WOMatTransEventHandler
/*   21:     */   extends MobileWOCommonEventHandler
/*   22:     */ {
/*   23:     */   public boolean performEvent(UIEvent event)
/*   24:     */     throws MobileApplicationException
/*   25:     */   {
/*   26:  40 */     if (event == null) {
/*   27:  40 */       return false;
/*   28:     */     }
/*   29:  42 */     String eventId = event.getEventName();
/*   30:  45 */     if (eventId.equalsIgnoreCase("refreshStoreroom")) {
/*   31:  47 */       return refreshStoreRoom(event);
/*   32:     */     }
/*   33:  53 */     if (eventId.equalsIgnoreCase("multiselect")) {
/*   34:  54 */       return selectStoreRomm(event);
/*   35:     */     }
/*   36:  57 */     if (eventId.equalsIgnoreCase("validatepage")) {
/*   37:  59 */       return validatepage(event);
/*   38:     */     }
/*   39:  61 */     if (eventId.equalsIgnoreCase("insertmatactual")) {
/*   40:  63 */       return insertmatactual(event);
/*   41:     */     }
/*   42:  65 */     if (eventId.equalsIgnoreCase("setlinetype")) {
/*   43:  67 */       return setlinetype(event);
/*   44:     */     }
/*   45:  69 */     if (eventId.equalsIgnoreCase("validateitemnum")) {
/*   46:  71 */       return validateitemnum(event);
/*   47:     */     }
/*   48:  73 */     if (eventId.equalsIgnoreCase("initwomattrans")) {
/*   49:  75 */       return initwomattrans(event);
/*   50:     */     }
/*   51:  77 */     if (eventId.equalsIgnoreCase("validatestoreloc")) {
/*   52:  79 */       return validatestoreloc(event);
/*   53:     */     }
/*   54:  81 */     if (eventId.equalsIgnoreCase("validatesiteid")) {
/*   55:  83 */       return validatesiteid(event);
/*   56:     */     }
/*   57:  85 */     if (eventId.equalsIgnoreCase("validatebinnum")) {
/*   58:  87 */       return validatebinnum(event);
/*   59:     */     }
/*   60:  89 */     if (eventId.equalsIgnoreCase("validaterotassetnum")) {
/*   61:  91 */       return validaterotassetnum(event);
/*   62:     */     }
/*   63:  93 */     if (eventId.equalsIgnoreCase("validatequantity")) {
/*   64:  95 */       return validatequantity(event);
/*   65:     */     }
/*   66:  97 */     if (eventId.equalsIgnoreCase("validatelotnum")) {
/*   67:  99 */       return validatelotnum(event);
/*   68:     */     }
/*   69: 101 */     if (eventId.equalsIgnoreCase("validateconcode")) {
/*   70: 103 */       return validateconcode(event);
/*   71:     */     }
/*   72: 105 */     if (eventId.equalsIgnoreCase("initpageSTOREROOM")) {
/*   73: 107 */       return initpageSTOREROOM(event);
/*   74:     */     }
/*   75: 109 */     if (eventId.equalsIgnoreCase("initpageBINNUM")) {
/*   76: 111 */       return initpageBINNUM(event);
/*   77:     */     }
/*   78: 113 */     if (eventId.equalsIgnoreCase("initpageLOTNUM")) {
/*   79: 115 */       return initpageLOTNUM(event);
/*   80:     */     }
/*   81: 117 */     if (eventId.equalsIgnoreCase("initpageCONCODE")) {
/*   82: 119 */       return initpageCONCODE(event);
/*   83:     */     }
/*   84: 121 */     if (eventId.equalsIgnoreCase("initpagerotatingassetlookup")) {
/*   85: 123 */       return initpagerotatingassetlookup(event);
/*   86:     */     }
/*   87: 129 */     if (eventId.equalsIgnoreCase("lookup")) {
/*   88: 131 */       return lookup(event);
/*   89:     */     }
/*   90: 134 */     super.performEvent(event);
/*   91:     */     
/*   92: 136 */     return false;
/*   93:     */   }
/*   94:     */   
/*   95:     */   private boolean isItemAvailableinStoreroom(String siteid, String item, String storeroom, boolean isOnline)
/*   96:     */     throws MobileApplicationException
/*   97:     */   {
/*   98: 147 */     MobileMboDataBeanManager inventoryMgr = new MobileMboDataBeanManager("INVENTORY");
/*   99: 148 */     MobileMboDataBean inventoryDataBean = inventoryMgr.getDataBean();
/*  100: 150 */     if (inventoryDataBean != null) {
/*  101: 151 */       inventoryDataBean.setOnline(isOnline);
/*  102:     */     }
/*  103: 154 */     inventoryDataBean.getQBE().setQbeExactMatch(true);
/*  104: 155 */     if (!"".equals(item)) {
/*  105: 156 */       inventoryDataBean.getQBE().setQBE("ITEMNUM", "=" + item);
/*  106:     */     }
/*  107: 158 */     if (siteid != null) {
/*  108: 159 */       inventoryDataBean.getQBE().setQBE("SITEID", "=" + siteid);
/*  109:     */     }
/*  110: 161 */     inventoryDataBean.getQBE().setQBE("LOCATION", "=" + storeroom);
/*  111: 162 */     inventoryDataBean.reset();
/*  112: 163 */     if (inventoryDataBean.count() == 1) {
/*  113: 164 */       return true;
/*  114:     */     }
/*  115: 166 */     return false;
/*  116:     */   }
/*  117:     */   
/*  118:     */   private boolean selectStoreRomm(UIEvent event)
/*  119:     */     throws MobileApplicationException
/*  120:     */   {
/*  121: 177 */     MobileMboDataBean databean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*  122: 178 */     if ("STOREROOMS".equalsIgnoreCase(databean.getName()))
/*  123:     */     {
/*  124: 179 */       MobileMboDataBean parentBean = databean.getParentBean();
/*  125: 180 */       String itemName = "";
/*  126: 181 */       if ("MRLINE".equals(parentBean.getName())) {
/*  127: 182 */         itemName = "ITEM";
/*  128:     */       } else {
/*  129: 184 */         itemName = "ITEMNUM";
/*  130:     */       }
/*  131: 186 */       String item = parentBean.getValue(itemName);
/*  132: 187 */       if ((item != null) && (!"".equals(item)))
/*  133:     */       {
/*  134: 188 */         String siteid = databean.getValue("SITEID");
/*  135: 189 */         String storeroom = databean.getValue("LOCATION");
/*  136:     */         
/*  137:     */ 
/*  138:     */ 
/*  139:     */ 
/*  140:     */ 
/*  141: 195 */         MobileMboDataBean itemBean = new MobileMboDataBeanManager("ITEM").getDataBean();
/*  142: 196 */         String itemsetid = parentBean.getValue("ITEMSETID");
/*  143: 197 */         itemBean.setAdditionalWhere("itemnum = ? and itemsetid = ?", new String[] { item, itemsetid });
/*  144: 198 */         itemBean.reset();
/*  145: 201 */         if ((itemBean.count() > 0) || (databean.isOnline())) {
/*  146: 203 */           if (!isItemAvailableinStoreroom(siteid, item, storeroom, databean.isOnline()))
/*  147:     */           {
/*  148: 204 */             Object[] params = new Object[2];
/*  149: 205 */             params[0] = item;
/*  150: 206 */             params[1] = storeroom;
/*  151: 207 */             throw new MobileApplicationException("itemdoesntexistinstoreroom", params);
/*  152:     */           }
/*  153:     */         }
/*  154:     */       }
/*  155:     */     }
/*  156: 212 */     return false;
/*  157:     */   }
/*  158:     */   
/*  159:     */   private boolean refreshStoreRoom(UIEvent event)
/*  160:     */     throws MobileApplicationException
/*  161:     */   {
/*  162: 219 */     MobileMboDataBean databean = ((TableControl)event.getCreatingObject()).getDataBean();
/*  163: 220 */     MobileMboDataBean screenDatabean = databean.getParentBean();
/*  164: 221 */     if (screenDatabean.getName().equals("MRLINE")) {
/*  165: 223 */       databean.getQBE().setQBE("TYPE", "=STOREROOM");
/*  166:     */     }
/*  167: 225 */     databean.reset();
/*  168: 226 */     return true;
/*  169:     */   }
/*  170:     */   
/*  171:     */   public boolean initwomattrans(UIEvent event)
/*  172:     */     throws MobileApplicationException
/*  173:     */   {
/*  174: 233 */     MobileMboDataBean databean = ((PageControl)event.getCreatingObject()).getDataBean();
/*  175: 235 */     if (databean.getMobileMbo() == null) {
/*  176: 236 */       return true;
/*  177:     */     }
/*  178: 242 */     if ((!databean.getValue("ITEMNUM").equals("")) || (!databean.getValue("DESCRIPTION").equals("")))
/*  179:     */     {
/*  180: 244 */       String linetype = ((WOApp)UIUtil.getApplication()).getInternalValue(databean, "LINETYPE", databean.getValue("LINETYPE"));
/*  181: 246 */       if (linetype != null) {
/*  182: 248 */         if (linetype.equals("ITEM"))
/*  183:     */         {
/*  184: 250 */           databean.getMobileMbo().setReadOnly("ITEMNUM", false);
/*  185: 251 */           databean.getMobileMbo().setReadOnly("DESCRIPTION", true);
/*  186: 252 */           databean.getMobileMbo().setReadOnly("STORELOC", false);
/*  187: 253 */           databean.getMobileMbo().setRequired("ITEMNUM", true);
/*  188: 254 */           databean.getMobileMbo().setRequired("DESCRIPTION", false);
/*  189:     */           
/*  190: 256 */           MobileMboDataBean itemBean = getDataBean("ITEM");
/*  191: 257 */           itemBean.getQBE().setQBE("ITEMNUM", databean.getValue("ITEMNUM"));
/*  192: 258 */           itemBean.getQBE().setQBE("ITEMSETID", databean.getValue("ITEMSETID"));
/*  193: 259 */           if (itemBean.getMobileMbo(0) != null) {
/*  194: 261 */             if (itemBean.getMobileMbo(0).getBooleanValue("ROTATING"))
/*  195:     */             {
/*  196: 263 */               databean.getMobileMbo().setReadOnly("ROTASSETNUM", false);
/*  197: 264 */               databean.getMobileMbo().setRequired("ROTASSETNUM", true);
/*  198:     */             }
/*  199:     */           }
/*  200:     */         }
/*  201: 268 */         else if (linetype.equals("MATERIAL"))
/*  202:     */         {
/*  203: 270 */           databean.getMobileMbo().setReadOnly("DESCRIPTION", false);
/*  204: 271 */           databean.getMobileMbo().setReadOnly("ITEMNUM", true);
/*  205: 272 */           databean.getMobileMbo().setReadOnly("STORELOC", true);
/*  206: 273 */           databean.getMobileMbo().setRequired("ITEMNUM", false);
/*  207: 274 */           databean.getMobileMbo().setRequired("DESCRIPTION", true);
/*  208:     */         }
/*  209:     */       }
/*  210:     */     }
/*  211: 281 */     MobileMbo mobileMbo = databean.getMobileMbo();
/*  212: 282 */     String itemnum = mobileMbo.getValue("ITEMNUM");
/*  213: 283 */     String siteid = mobileMbo.getValue("SITEID");
/*  214: 284 */     String storeroom = mobileMbo.getValue("STORELOC");
/*  215: 286 */     if ((storeroom != null) && (storeroom.length() > 0) && (!existStocked(itemnum, siteid, storeroom)))
/*  216:     */     {
/*  217: 288 */       databean.setValue("STORELOC", "");
/*  218: 289 */       databean.getMobileMbo().setReadOnly("STORELOC", true);
/*  219:     */     }
/*  220: 292 */     return true;
/*  221:     */   }
/*  222:     */   
/*  223:     */   public boolean insertmatactual(UIEvent event)
/*  224:     */     throws MobileApplicationException
/*  225:     */   {
/*  226: 297 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/*  227: 298 */     if (databean != null)
/*  228:     */     {
/*  229: 300 */       MobileMboDataBean parentBean = databean.getParentBean();
/*  230: 301 */       String orgid = null;
/*  231: 302 */       String siteid = null;
/*  232: 303 */       if (parentBean != null)
/*  233:     */       {
/*  234: 305 */         orgid = parentBean.getValue("ORGID");
/*  235: 306 */         siteid = parentBean.getValue("SITEID");
/*  236:     */       }
/*  237:     */       else
/*  238:     */       {
/*  239: 310 */         orgid = ((WOApp)UIUtil.getApplication()).getDefaultInsertOrg();
/*  240: 311 */         siteid = ((WOApp)UIUtil.getApplication()).getDefaultInsertSite();
/*  241:     */       }
/*  242: 314 */       if (databean.getName().equals("WOMATTRANS"))
/*  243:     */       {
/*  244: 316 */         databean.insert();
/*  245: 317 */         databean.setValue("POSITIVEQUANTITY", "1");
/*  246: 318 */         databean.setValue("ORGID", orgid);
/*  247: 319 */         databean.setValue("SITEID", siteid);
/*  248:     */         
/*  249:     */ 
/*  250: 322 */         databean.setValue("LINETYPE", ((WOApp)UIUtil.getApplication()).getDefaultValue(databean, "LINETYPE", "ITEM"));
/*  251:     */         
/*  252:     */ 
/*  253: 325 */         databean.getMobileMbo().setReadOnly("ITEMNUM", false);
/*  254: 326 */         databean.getMobileMbo().setReadOnly("DESCRIPTION", false);
/*  255: 327 */         databean.getMobileMbo().setReadOnly("STORELOC", false);
/*  256: 328 */         databean.getMobileMbo().setRequired("ITEMNUM", true);
/*  257: 329 */         databean.getMobileMbo().setRequired("DESCRIPTION", false);
/*  258:     */       }
/*  259:     */     }
/*  260: 332 */     UIUtil.refreshCurrentScreen();
/*  261: 333 */     return true;
/*  262:     */   }
/*  263:     */   
/*  264:     */   public boolean validateitemnum(UIEvent event)
/*  265:     */     throws MobileApplicationException
/*  266:     */   {
/*  267: 339 */     UIEvent userevent = UIUtil.getApplication().getUserEvent();
/*  268: 340 */     if ((userevent != null) && (userevent.getEventName().equalsIgnoreCase("acceptvalue"))) {
/*  269: 341 */       return true;
/*  270:     */     }
/*  271: 344 */     MobileMboDataBean databean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*  272:     */     
/*  273: 346 */     databean.getMobileMbo().setReadOnly("STORELOC", false);
/*  274: 348 */     if ((event.getValue() == null) || (event.getValue().equals("")))
/*  275:     */     {
/*  276: 351 */       databean.getMobileMbo().setReadOnly("DESCRIPTION", false);
/*  277: 352 */       databean.setValue("DESCRIPTION", "");
/*  278:     */       
/*  279: 354 */       databean.getMobileMbo().setReadOnly("ROTASSETNUM", true);
/*  280: 355 */       databean.getMobileMbo().setRequired("ROTASSETNUM", false);
/*  281:     */     }
/*  282:     */     else
/*  283:     */     {
/*  284: 361 */       MobileMboDataBean itemBean = getDataBean("ITEM");
/*  285: 362 */       String itemnum = (String)event.getValue();
/*  286: 363 */       itemBean.getQBE().setQBE("ITEMNUM", itemnum);
/*  287: 364 */       itemBean.getQBE().setQBE("ITEMSETID", databean.getValue("ITEMSETID"));
/*  288: 365 */       if (itemBean.getMobileMbo(0) != null)
/*  289:     */       {
/*  290: 367 */         String storeroom = databean.getValue("STORELOC");
/*  291:     */         
/*  292:     */ 
/*  293: 370 */         String siteid = databean.getValue("SITEID");
/*  294: 371 */         if (!existStocked(itemnum, siteid, storeroom))
/*  295:     */         {
/*  296: 375 */           databean.setValue("STORELOC", "");
/*  297: 376 */           databean.getMobileMbo().setReadOnly("STORELOC", true);
/*  298:     */         }
/*  299: 379 */         databean.setValue("ITEMNUM", itemnum);
/*  300: 380 */         databean.getMobileMbo().setReadOnly("DESCRIPTION", false);
/*  301: 381 */         databean.setValue("DESCRIPTION", itemBean.getMobileMbo(0).getValue("DESCRIPTION"));
/*  302: 382 */         databean.getMobileMbo().setReadOnly("DESCRIPTION", true);
/*  303:     */       }
/*  304: 386 */       if (itemBean.getMobileMbo(0) == null)
/*  305:     */       {
/*  306: 390 */         MobileMboDataBean item = UIUtil.getCurrentScreen().getDataBean();
/*  307: 391 */         if ((item != null) && (item.getName().equalsIgnoreCase("ITEM")))
/*  308:     */         {
/*  309: 393 */           if (!item.getValue("DESCRIPTION").equals(""))
/*  310:     */           {
/*  311: 395 */             databean.getMobileMbo().setReadOnly("DESCRIPTION", false);
/*  312: 396 */             databean.setValue("DESCRIPTION", item.getValue("DESCRIPTION"));
/*  313: 397 */             databean.getMobileMbo().setReadOnly("DESCRIPTION", true);
/*  314:     */           }
/*  315: 400 */           databean.getMobileMbo().setRequired("ROTASSETNUM", false);
/*  316: 401 */           databean.getMobileMbo().setReadOnly("ROTASSETNUM", false);
/*  317: 402 */           return true;
/*  318:     */         }
/*  319: 407 */         databean.getMobileMbo().setRequired("ROTASSETNUM", false);
/*  320: 408 */         databean.getMobileMbo().setReadOnly("ROTASSETNUM", false);
/*  321:     */       }
/*  322: 410 */       else if (itemBean.getMobileMbo(0).getBooleanValue("ROTATING"))
/*  323:     */       {
/*  324: 413 */         databean.getMobileMbo().setReadOnly("ROTASSETNUM", false);
/*  325: 414 */         databean.getMobileMbo().setRequired("ROTASSETNUM", true);
/*  326:     */       }
/*  327:     */       else
/*  328:     */       {
/*  329: 418 */         databean.getMobileMbo().setRequired("ROTASSETNUM", false);
/*  330: 419 */         databean.getMobileMbo().setReadOnly("ROTASSETNUM", true);
/*  331: 420 */         databean.getMobileMbo().setValue("ROTASSETNUM", "");
/*  332:     */       }
/*  333:     */     }
/*  334: 424 */     return false;
/*  335:     */   }
/*  336:     */   
/*  337:     */   protected MobileMboDataBean getDataBean(String databeanName)
/*  338:     */     throws MobileApplicationException
/*  339:     */   {
/*  340: 430 */     MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager(databeanName);
/*  341: 431 */     MobileMboDataBean databean = mgrDBMgr.getDataBean();
/*  342: 432 */     return databean;
/*  343:     */   }
/*  344:     */   
/*  345:     */   protected boolean existStocked(String itemnum, String siteId, String storeroom)
/*  346:     */     throws MobileApplicationException
/*  347:     */   {
/*  348: 440 */     MobileMboDataBean invBean = getDataBean("INVENTORY");
/*  349:     */     
/*  350: 442 */     invBean.getQBE().reset();
/*  351: 443 */     invBean.getQBE().setQbeExactMatch(true);
/*  352: 444 */     invBean.getQBE().setQBE("ITEMNUM", itemnum);
/*  353: 445 */     invBean.getQBE().setQBE("SITEID", siteId);
/*  354: 446 */     invBean.reset();
/*  355: 447 */     if (invBean.getMobileMbo(0) == null) {
/*  356: 448 */       return false;
/*  357:     */     }
/*  358: 450 */     checkIfRequiresHardReserv(invBean, storeroom);
/*  359:     */     
/*  360: 452 */     return true;
/*  361:     */   }
/*  362:     */   
/*  363:     */   protected void checkIfRequiresHardReserv(MobileMboDataBean invBean, String storeroom)
/*  364:     */     throws MobileApplicationException
/*  365:     */   {
/*  366: 458 */     if ((storeroom == null) || (storeroom.length() == 0)) {
/*  367: 459 */       return;
/*  368:     */     }
/*  369: 461 */     int index = 0;
/*  370: 462 */     MobileMbo mbo = invBean.getMobileMbo(index);
/*  371: 463 */     while (mbo != null)
/*  372:     */     {
/*  373: 465 */       if ((mbo.getValue("LOCATION").equalsIgnoreCase(storeroom)) && (mbo.getBooleanValue("HARDRESISSUE") == true)) {
/*  374: 468 */         throw new MobileApplicationException("requireshardresev");
/*  375:     */       }
/*  376: 470 */       mbo = invBean.getMobileMbo(++index);
/*  377:     */     }
/*  378:     */   }
/*  379:     */   
/*  380:     */   public boolean setlinetype(UIEvent event)
/*  381:     */     throws MobileApplicationException
/*  382:     */   {
/*  383: 477 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/*  384: 478 */     if ((event.getValue() == null) || (event.getValue().equals(""))) {
/*  385: 480 */       return true;
/*  386:     */     }
/*  387: 484 */     String linetype = ((WOApp)UIUtil.getApplication()).getInternalValue(databean, "LINETYPE", (String)event.getValue());
/*  388:     */     
/*  389: 486 */     seteditablilty(databean, linetype);
/*  390:     */     
/*  391:     */ 
/*  392: 489 */     UIUtil.refreshCurrentScreen();
/*  393: 490 */     return true;
/*  394:     */   }
/*  395:     */   
/*  396:     */   public boolean seteditablilty(MobileMboDataBean databean, String linetype)
/*  397:     */     throws MobileApplicationException
/*  398:     */   {
/*  399: 499 */     if (linetype.equals("ITEM"))
/*  400:     */     {
/*  401: 501 */       databean.setValue("DESCRIPTION", "");
/*  402: 502 */       databean.getMobileMbo().setReadOnly("ITEMNUM", false);
/*  403: 503 */       databean.getMobileMbo().setReadOnly("DESCRIPTION", true);
/*  404: 504 */       databean.getMobileMbo().setReadOnly("STORELOC", false);
/*  405: 505 */       databean.getMobileMbo().setRequired("ITEMNUM", true);
/*  406: 506 */       databean.getMobileMbo().setRequired("DESCRIPTION", false);
/*  407:     */     }
/*  408: 508 */     else if (linetype.equals("MATERIAL"))
/*  409:     */     {
/*  410: 510 */       databean.getMobileMbo().setReadOnly("DESCRIPTION", false);
/*  411: 512 */       if ((!databean.getValue("ITEMNUM").equals("")) && (!databean.getValue("DESCRIPTION").equals(""))) {
/*  412: 513 */         databean.setValue("DESCRIPTION", "");
/*  413:     */       }
/*  414: 514 */       databean.setValue("ITEMNUM", "");
/*  415: 515 */       databean.setValue("STORELOC", "");
/*  416: 516 */       databean.getMobileMbo().setReadOnly("ITEMNUM", true);
/*  417: 517 */       databean.getMobileMbo().setReadOnly("STORELOC", true);
/*  418: 518 */       databean.getMobileMbo().setRequired("ITEMNUM", false);
/*  419: 519 */       databean.getMobileMbo().setRequired("DESCRIPTION", true);
/*  420:     */     }
/*  421: 522 */     return true;
/*  422:     */   }
/*  423:     */   
/*  424:     */   public boolean validatepage(UIEvent event)
/*  425:     */     throws MobileApplicationException
/*  426:     */   {
/*  427: 527 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/*  428: 528 */     if (databean.isMobileMboReadOnly()) {
/*  429: 530 */       return true;
/*  430:     */     }
/*  431: 533 */     MobileMboDataBean wodatabean = databean.getParentBean();
/*  432: 536 */     if (databean.getValue("ACTUALSTASKID").equals(""))
/*  433:     */     {
/*  434: 538 */       if (wodatabean.getValue("WOACCEPTSCHARGES").equals("0")) {
/*  435: 539 */         throw new MobileApplicationException("WOAcceptsChargesNo");
/*  436:     */       }
/*  437:     */     }
/*  438:     */     else
/*  439:     */     {
/*  440: 543 */       MobileMboDataBean wotasks = wodatabean.getDataBean("WOTASKS");
/*  441: 544 */       int count = wotasks.count();
/*  442: 545 */       for (int i = 0; i < count; i++) {
/*  443: 547 */         if (wotasks.getMobileMbo(i).getValue("TASKID").equals(databean.getValue("ACTUALSTASKID")))
/*  444:     */         {
/*  445: 549 */           if (!wotasks.getMobileMbo(i).getValue("WOACCEPTSCHARGES").equals("0")) {
/*  446:     */             break;
/*  447:     */           }
/*  448: 550 */           throw new MobileApplicationException("TaskAcceptsChargesNo");
/*  449:     */         }
/*  450:     */       }
/*  451:     */     }
/*  452: 557 */     String linetype = ((WOApp)UIUtil.getApplication()).getInternalValue(databean, "LINETYPE", databean.getValue("LINETYPE"));
/*  453: 559 */     if (linetype.equals("MATERIAL")) {
/*  454: 560 */       databean.setValue("ITEMNUMDISPLAY", databean.getValue("DESCRIPTION"));
/*  455:     */     }
/*  456: 563 */     if (linetype.equals("ITEM"))
/*  457:     */     {
/*  458: 565 */       databean.setValue("ITEMNUMDISPLAY", databean.getValue("ITEMNUM"));
/*  459:     */       
/*  460:     */ 
/*  461:     */ 
/*  462:     */ 
/*  463: 570 */       MobileMbo matUseTransMbo = databean.getMobileMbo();
/*  464: 571 */       if ((matUseTransMbo.isNull("STORELOC")) && (matUseTransMbo.isReadOnly("STORELOC"))) {
/*  465: 573 */         return true;
/*  466:     */       }
/*  467: 576 */       if (!isValidSiteStoreBin(databean))
/*  468:     */       {
/*  469: 578 */         if (event.getMsgResponse().equals("-1"))
/*  470:     */         {
/*  471: 580 */           Object[] param = new Object[0];
/*  472: 581 */           UIUtil.showYESNOCANCELMessageBox(event, MobileMessageGenerator.generate("invalidstoreroom", param));
/*  473: 582 */           event.setEventErrored();
/*  474: 583 */           return true;
/*  475:     */         }
/*  476: 585 */         if (!event.getMsgResponse().equals("1")) {
/*  477: 589 */           if ((event.getMsgResponse().equals("0")) || (event.getMsgResponse().equals("2")))
/*  478:     */           {
/*  479: 592 */             event.setEventErrored();
/*  480: 593 */             return true;
/*  481:     */           }
/*  482:     */         }
/*  483:     */       }
/*  484:     */     }
/*  485: 599 */     if (!databean.isComplete()) {
/*  486: 600 */       databean.markComplete();
/*  487:     */     }
/*  488: 602 */     return false;
/*  489:     */   }
/*  490:     */   
/*  491:     */   public boolean validatequantity(UIEvent event)
/*  492:     */     throws MobileApplicationException
/*  493:     */   {
/*  494: 608 */     if ((event.getValue() == null) || (event.getValue().equals(""))) {
/*  495: 610 */       return true;
/*  496:     */     }
/*  497: 613 */     String strqty = (String)event.getValue();
/*  498: 614 */     double qty = DefaultMobileMboDataFormatter.stringToDouble(strqty);
/*  499: 615 */     if (qty < 0.0D) {
/*  500: 617 */       throw new MobileApplicationException("NoNegQuantities");
/*  501:     */     }
/*  502: 620 */     return true;
/*  503:     */   }
/*  504:     */   
/*  505:     */   public boolean validatestoreloc(UIEvent event)
/*  506:     */     throws MobileApplicationException
/*  507:     */   {
/*  508: 626 */     MobileMboDataBean databean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*  509: 627 */     databean.setValue("BINNUM", "");
/*  510: 629 */     if ((event.getValue() == null) || (event.getValue().equals(""))) {
/*  511: 630 */       return true;
/*  512:     */     }
/*  513: 632 */     if (!databean.getValue("ITEMNUM").equals(""))
/*  514:     */     {
/*  515: 633 */       if (!"-1".equalsIgnoreCase(event.getMsgResponse()))
/*  516:     */       {
/*  517: 638 */         if ("0".equalsIgnoreCase(event.getMsgResponse())) {
/*  518: 640 */           event.setEventErrored();
/*  519:     */         }
/*  520: 642 */         return true;
/*  521:     */       }
/*  522: 644 */       MobileMboDataBeanManager inventoryDBMgr = new MobileMboDataBeanManager("INVENTORY");
/*  523: 645 */       MobileMboDataBean inventoryDataBean = inventoryDBMgr.getDataBean();
/*  524: 646 */       inventoryDataBean.getQBE().reset();
/*  525:     */       
/*  526: 648 */       inventoryDataBean.getQBE().setQbeExactMatch(true);
/*  527: 649 */       inventoryDataBean.getQBE().setQBE("SITEID", "~NULL~");
/*  528: 650 */       inventoryDataBean.getQBE().setQBE("ITEMNUM", databean.getValue("ITEMNUM"));
/*  529:     */       
/*  530: 652 */       String typedStoreroom = (String)event.getValue();
/*  531: 653 */       inventoryDataBean.getQBE().setQBE("LOCATION", typedStoreroom);
/*  532: 655 */       if (!databean.getValue("SITEID").equals("")) {
/*  533: 656 */         inventoryDataBean.getQBE().setQBE("SITEID", databean.getValue("SITEID"));
/*  534:     */       }
/*  535: 658 */       inventoryDataBean.reset();
/*  536: 659 */       UIEvent userevent = UIUtil.getApplication().getUserEvent();
/*  537: 660 */       int count = inventoryDataBean.count();
/*  538: 661 */       if ((count == 0) && (!"acceptvalue".equalsIgnoreCase(userevent.getEventName())))
/*  539:     */       {
/*  540: 663 */         MobileMboDataBean lookupBean = ((AbstractMobileControl)userevent.getCreatingObject()).getDataBean();
/*  541: 667 */         if ((lookupBean != null) && (!lookupBean.isOnline()))
/*  542:     */         {
/*  543: 671 */           String[] params = { databean.getValue("ITEMNUM"), typedStoreroom };
/*  544: 672 */           UIUtil.showMessageBox("nolocalinvinfoavailable", params, "warning", 12, event);
/*  545: 673 */           event.setEventErrored();
/*  546: 674 */           return true;
/*  547:     */         }
/*  548: 677 */         return true;
/*  549:     */       }
/*  550: 680 */       if (count != 0)
/*  551:     */       {
/*  552: 682 */         boolean requiresHardReservatio = inventoryDataBean.getMobileMbo().getBooleanValue("HARDRESISSUE");
/*  553: 683 */         if (requiresHardReservatio == true) {
/*  554: 685 */           throw new MobileApplicationException("requireshardresev");
/*  555:     */         }
/*  556:     */       }
/*  557:     */     }
/*  558: 689 */     MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager("INVBALANCES");
/*  559: 690 */     MobileMboDataBean balBean = mgrDBMgr.getDataBean();
/*  560:     */     
/*  561: 692 */     balBean.getQBE().reset();
/*  562: 693 */     balBean.getQBE().setQbeExactMatch(true);
/*  563: 694 */     balBean.getQBE().setQBE("SITEID", "~NULL~");
/*  564: 695 */     balBean.getQBE().setQBE("LOCATION", "~NULL~");
/*  565:     */     
/*  566: 697 */     balBean.getQBE().setQBE("ITEMNUM", databean.getValue("ITEMNUM"));
/*  567: 698 */     balBean.getQBE().setQBE("ITEMSETID", databean.getValue("ITEMSETID"));
/*  568: 699 */     balBean.getQBE().setQBE("LOCATION", (String)event.getValue());
/*  569: 701 */     if (!databean.getValue("SITEID").equals("")) {
/*  570: 702 */       balBean.getQBE().setQBE("SITEID", databean.getValue("SITEID"));
/*  571:     */     }
/*  572: 704 */     if ((balBean.getMobileMbo(0) != null) && (balBean.getMobileMbo(1) == null)) {
/*  573: 705 */       databean.setValue("BINNUM", balBean.getMobileMbo(0).getValue("BINNUM"));
/*  574:     */     }
/*  575: 707 */     return true;
/*  576:     */   }
/*  577:     */   
/*  578:     */   public boolean validatesiteid(UIEvent event)
/*  579:     */     throws MobileApplicationException
/*  580:     */   {
/*  581: 713 */     MobileMboDataBean databean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*  582: 714 */     databean.setValue("STORELOC", "");
/*  583: 715 */     databean.setValue("BINNUM", "");
/*  584:     */     
/*  585: 717 */     return true;
/*  586:     */   }
/*  587:     */   
/*  588:     */   public boolean validatebinnum(UIEvent event)
/*  589:     */     throws MobileApplicationException
/*  590:     */   {
/*  591: 722 */     return true;
/*  592:     */   }
/*  593:     */   
/*  594:     */   public boolean validaterotassetnum(UIEvent event)
/*  595:     */     throws MobileApplicationException
/*  596:     */   {
/*  597: 728 */     UIEvent userevent = UIUtil.getApplication().getUserEvent();
/*  598: 729 */     MobileMboDataBean databean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*  599: 730 */     if ((userevent != null) && (userevent.getEventName().equalsIgnoreCase("acceptvalue")))
/*  600:     */     {
/*  601: 733 */       databean.setValue("POSITIVEQUANTITY", "1");
/*  602: 734 */       databean.getMobileMbo().setReadOnly("POSITIVEQUANTITY", true);
/*  603: 735 */       return true;
/*  604:     */     }
/*  605: 739 */     if ((event.getValue() == null) || (event.getValue().equals("")))
/*  606:     */     {
/*  607: 742 */       databean.getMobileMbo().setReadOnly("POSITIVEQUANTITY", false);
/*  608: 743 */       return true;
/*  609:     */     }
/*  610: 748 */     if ((userevent != null) && (userevent.getEventName().equalsIgnoreCase("select")) && (!databean.getValue("STORELOC").equals("")))
/*  611:     */     {
/*  612: 752 */       databean.setValue("POSITIVEQUANTITY", "1");
/*  613: 753 */       databean.getMobileMbo().setReadOnly("POSITIVEQUANTITY", true);
/*  614: 754 */       return true;
/*  615:     */     }
/*  616: 759 */     MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager("ASSET");
/*  617: 760 */     MobileMboDataBean assetBean = mgrDBMgr.getDataBean();
/*  618: 761 */     assetBean.getQBE().setQBE("ASSETNUM", (String)event.getValue());
/*  619: 762 */     assetBean.getQBE().setQBE("SITEID", databean.getValue("SITEID"));
/*  620: 763 */     MobileMbo assetMbo = assetBean.getMobileMbo(0);
/*  621: 765 */     if (assetMbo == null) {
/*  622: 767 */       if ((userevent != null) && (userevent.getEventName().equalsIgnoreCase("select")))
/*  623:     */       {
/*  624: 769 */         if (userevent.getMsgResponse().equals("-1"))
/*  625:     */         {
/*  626: 771 */           Object[] param = new Object[0];
/*  627: 772 */           UIUtil.showYESNOCANCELMessageBox(userevent, MobileMessageGenerator.generate("cannotbevalidated", param));
/*  628: 773 */           event.setEventErrored();
/*  629: 774 */           return true;
/*  630:     */         }
/*  631: 776 */         if (userevent.getMsgResponse().equals("1"))
/*  632:     */         {
/*  633: 779 */           databean.setValue("POSITIVEQUANTITY", "1");
/*  634: 780 */           databean.getMobileMbo().setReadOnly("POSITIVEQUANTITY", true);
/*  635: 781 */           return true;
/*  636:     */         }
/*  637: 783 */         if (userevent.getMsgResponse().equals("0"))
/*  638:     */         {
/*  639: 786 */           databean.getMobileMbo().setReadOnly("POSITIVEQUANTITY", false);
/*  640: 787 */           event.setEventErrored();
/*  641: 788 */           return true;
/*  642:     */         }
/*  643: 790 */         if (userevent.getMsgResponse().equals("2"))
/*  644:     */         {
/*  645: 792 */           event.setEventErrored();
/*  646: 793 */           UIUtil.getApplication().removeCurrentScreen();
/*  647: 794 */           return true;
/*  648:     */         }
/*  649:     */       }
/*  650:     */       else
/*  651:     */       {
/*  652: 800 */         UIUtil.popupPage("invalidvalue", event);
/*  653: 801 */         event.setEventErrored();
/*  654: 802 */         return true;
/*  655:     */       }
/*  656:     */     }
/*  657: 806 */     if ((assetMbo.getValue("ITEMNUM").equals("")) || (!assetMbo.getValue("ITEMNUM").equals(databean.getValue("ITEMNUM")))) {
/*  658: 808 */       throw new MobileApplicationException("invalidRotAssetItem");
/*  659:     */     }
/*  660: 810 */     String moveFromLoc = databean.getValue("STORELOC");
/*  661: 811 */     String assetLoc = assetMbo.getValue("LOCATION");
/*  662: 813 */     if ((assetLoc != null) && (!assetLoc.equals("")) && (!assetLoc.equalsIgnoreCase(moveFromLoc))) {
/*  663: 815 */       throw new MobileApplicationException("invalidRotAssetLocation");
/*  664:     */     }
/*  665: 818 */     return true;
/*  666:     */   }
/*  667:     */   
/*  668:     */   public boolean validatelotnum(UIEvent event)
/*  669:     */     throws MobileApplicationException
/*  670:     */   {
/*  671: 823 */     return true;
/*  672:     */   }
/*  673:     */   
/*  674:     */   public boolean validateconcode(UIEvent event)
/*  675:     */     throws MobileApplicationException
/*  676:     */   {
/*  677: 828 */     return true;
/*  678:     */   }
/*  679:     */   
/*  680:     */   public boolean isValidSiteStoreBin(MobileMboDataBean databean)
/*  681:     */     throws MobileApplicationException
/*  682:     */   {
/*  683: 834 */     MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager("INVBALANCES");
/*  684: 835 */     MobileMboDataBean balBean = mgrDBMgr.getDataBean();
/*  685:     */     
/*  686: 837 */     balBean.getQBE().reset();
/*  687: 838 */     balBean.getQBE().setQbeExactMatch(true);
/*  688: 839 */     balBean.getQBE().setQBE("SITEID", "~NULL~");
/*  689: 840 */     balBean.getQBE().setQBE("LOCATION", "~NULL~");
/*  690: 841 */     balBean.getQBE().setQBE("BINNUM", "~NULL~");
/*  691: 842 */     balBean.getQBE().setQBE("LOTNUM", "~NULL~");
/*  692: 843 */     balBean.getQBE().setQBE("CONDITIONCODE", "~NULL~");
/*  693:     */     
/*  694: 845 */     balBean.getQBE().setQBE("ITEMNUM", databean.getValue("ITEMNUM"));
/*  695: 846 */     balBean.getQBE().setQBE("ITEMSETID", databean.getValue("ITEMSETID"));
/*  696: 848 */     if (!databean.getValue("SITEID").equals("")) {
/*  697: 849 */       balBean.getQBE().setQBE("SITEID", databean.getValue("SITEID"));
/*  698:     */     }
/*  699: 851 */     if (!databean.getValue("STORELOC").equals("")) {
/*  700: 852 */       balBean.getQBE().setQBE("LOCATION", databean.getValue("STORELOC"));
/*  701:     */     }
/*  702: 854 */     if (!databean.getValue("BINNUM").equals("")) {
/*  703: 855 */       balBean.getQBE().setQBE("BINNUM", databean.getValue("BINNUM"));
/*  704:     */     }
/*  705: 857 */     if (!databean.getValue("LOTNUM").equals("")) {
/*  706: 858 */       balBean.getQBE().setQBE("LOTNUM", databean.getValue("LOTNUM"));
/*  707:     */     }
/*  708: 860 */     if (!databean.getValue("CONDITIONCODE").equals("")) {
/*  709: 861 */       balBean.getQBE().setQBE("CONDITIONCODE", databean.getValue("CONDITIONCODE"));
/*  710:     */     }
/*  711: 863 */     MobileMbo balMbo = balBean.getMobileMbo(0);
/*  712: 864 */     if (balMbo == null) {
/*  713: 864 */       return false;
/*  714:     */     }
/*  715: 866 */     return true;
/*  716:     */   }
/*  717:     */   
/*  718:     */   public boolean initpageSTOREROOM(UIEvent event)
/*  719:     */     throws MobileApplicationException
/*  720:     */   {
/*  721: 873 */     MobileMboDataBean databean = ((PageControl)event.getCreatingObject()).getDataBean();
/*  722: 874 */     String siteid = null;
/*  723:     */     
/*  724: 876 */     MobileMboDataBean mtdatabean = UIUtil.getCurrentScreen().getDataBean();
/*  725: 877 */     if (mtdatabean.getName().equals("MR"))
/*  726:     */     {
/*  727: 880 */       mtdatabean = mtdatabean.getDataBean("MRLINE");
/*  728: 881 */       if (!mtdatabean.getValue("STORELOCSITE").equals(""))
/*  729:     */       {
/*  730: 883 */         siteid = mtdatabean.getValue("STORELOCSITE");
/*  731:     */         
/*  732: 885 */         databean.getQBE().setQBE("SITEID", siteid);
/*  733:     */       }
/*  734: 890 */       databean.getQBE().setQBE("TYPE", ((WOApp)UIUtil.getApplication()).getExternalValue(databean, "LOCTYPE", "STOREROOM"));
/*  735:     */     }
/*  736: 894 */     else if (!mtdatabean.getValue("SITEID").equals(""))
/*  737:     */     {
/*  738: 896 */       siteid = mtdatabean.getValue("SITEID");
/*  739: 897 */       databean.getQBE().setQbeExactMatch(true);
/*  740: 898 */       databean.getQBE().setQBE("SITEID", siteid);
/*  741: 901 */       if (!mtdatabean.getValue("ITEMNUM").equals(""))
/*  742:     */       {
/*  743: 903 */         String locations = getInventoryLocationsForItem(mtdatabean.getValue("ITEMNUM"), siteid);
/*  744: 904 */         if (locations != null) {
/*  745: 906 */           databean.getQBE().setQBE("LOCATION", locations);
/*  746:     */         }
/*  747:     */       }
/*  748:     */     }
/*  749: 912 */     databean.getQBE().setQBE("DISABLED", "0");
/*  750: 913 */     databean.getQBE().setQBE("STATUS", "!=" + ((WOApp)UIUtil.getApplication()).getExternalValue(databean, "LOC_ASSETSTATUS", "DECOMMISSIONED"));
/*  751:     */     
/*  752: 915 */     databean.reset();
/*  753: 916 */     return false;
/*  754:     */   }
/*  755:     */   
/*  756:     */   private String getInventoryLocationsForItem(String itemNum, String siteId)
/*  757:     */     throws MobileApplicationException
/*  758:     */   {
/*  759: 923 */     MobileMboDataBeanManager dbm = new MobileMboDataBeanManager("INVENTORY");
/*  760: 924 */     MobileMboDataBean invBean = dbm.getDataBean();
/*  761:     */     
/*  762: 926 */     invBean.getQBE().setQBE("ITEMNUM", itemNum);
/*  763: 927 */     invBean.getQBE().setQBE("SITEID", siteId);
/*  764: 928 */     invBean.getQBE().setQbeExactMatch(true);
/*  765: 929 */     invBean.reset();
/*  766: 930 */     int count = invBean.count();
/*  767: 931 */     if (count > 0)
/*  768:     */     {
/*  769: 933 */       StringBuffer locs = new StringBuffer();
/*  770: 935 */       for (int i = 0; i < count; i++) {
/*  771: 937 */         if (i == count - 1) {
/*  772: 939 */           locs.append(invBean.getValue(i, "LOCATION"));
/*  773:     */         } else {
/*  774: 943 */           locs.append(invBean.getValue(i, "LOCATION") + ",");
/*  775:     */         }
/*  776:     */       }
/*  777: 946 */       return locs.toString();
/*  778:     */     }
/*  779: 949 */     return null;
/*  780:     */   }
/*  781:     */   
/*  782:     */   public boolean initpageBINNUM(UIEvent event)
/*  783:     */     throws MobileApplicationException
/*  784:     */   {
/*  785: 956 */     MobileMboDataBean databean = ((PageControl)event.getCreatingObject()).getDataBean();
/*  786:     */     
/*  787:     */ 
/*  788: 959 */     MobileMboDataBean mtdatabean = UIUtil.getCurrentScreen().getDataBean();
/*  789:     */     
/*  790: 961 */     databean.getQBE().setQBE("BINNUM", "!=~NULL~");
/*  791: 963 */     if (!mtdatabean.getValue("ITEMNUM").equals(""))
/*  792:     */     {
/*  793: 965 */       databean.getQBE().setQBE("ITEMNUM", mtdatabean.getValue("ITEMNUM"));
/*  794: 966 */       databean.getQBE().setQBE("ITEMSETID", mtdatabean.getValue("ITEMSETID"));
/*  795:     */     }
/*  796: 969 */     if (!mtdatabean.getValue("SITEID").equals("")) {
/*  797: 970 */       databean.getQBE().setQBE("SITEID", mtdatabean.getValue("SITEID"));
/*  798:     */     }
/*  799: 971 */     if (!mtdatabean.getValue("STORELOC").equals("")) {
/*  800: 972 */       databean.getQBE().setQBE("LOCATION", mtdatabean.getValue("STORELOC"));
/*  801:     */     }
/*  802: 974 */     databean.reset();
/*  803:     */     
/*  804: 976 */     return false;
/*  805:     */   }
/*  806:     */   
/*  807:     */   public boolean initpageLOTNUM(UIEvent event)
/*  808:     */     throws MobileApplicationException
/*  809:     */   {
/*  810: 982 */     MobileMboDataBean databean = ((PageControl)event.getCreatingObject()).getDataBean();
/*  811:     */     
/*  812:     */ 
/*  813: 985 */     MobileMboDataBean mtdatabean = UIUtil.getCurrentScreen().getDataBean();
/*  814:     */     
/*  815: 987 */     databean.getQBE().setQBE("LOTNUM", "!=~NULL~");
/*  816: 989 */     if (!mtdatabean.getValue("ITEMNUM").equals(""))
/*  817:     */     {
/*  818: 991 */       databean.getQBE().setQBE("ITEMNUM", mtdatabean.getValue("ITEMNUM"));
/*  819: 992 */       databean.getQBE().setQBE("ITEMSETID", mtdatabean.getValue("ITEMSETID"));
/*  820:     */     }
/*  821: 995 */     if (!mtdatabean.getValue("SITEID").equals("")) {
/*  822: 996 */       databean.getQBE().setQBE("SITEID", mtdatabean.getValue("SITEID"));
/*  823:     */     }
/*  824: 997 */     if (!mtdatabean.getValue("STORELOC").equals("")) {
/*  825: 998 */       databean.getQBE().setQBE("LOCATION", mtdatabean.getValue("STORELOC"));
/*  826:     */     }
/*  827: 999 */     if (!mtdatabean.getValue("BINNUM").equals("")) {
/*  828:1000 */       databean.getQBE().setQBE("BINNUM", mtdatabean.getValue("BINNUM"));
/*  829:     */     }
/*  830:1002 */     databean.reset();
/*  831:     */     
/*  832:1004 */     return false;
/*  833:     */   }
/*  834:     */   
/*  835:     */   public boolean initpageCONCODE(UIEvent event)
/*  836:     */     throws MobileApplicationException
/*  837:     */   {
/*  838:1010 */     MobileMboDataBean databean = ((PageControl)event.getCreatingObject()).getDataBean();
/*  839:     */     
/*  840:     */ 
/*  841:1013 */     MobileMboDataBean mtdatabean = UIUtil.getCurrentScreen().getDataBean();
/*  842:     */     
/*  843:1015 */     databean.getQBE().setQBE("CONDITIONCODE", "!=~NULL~");
/*  844:1017 */     if (!mtdatabean.getValue("ITEMNUM").equals(""))
/*  845:     */     {
/*  846:1019 */       databean.getQBE().setQBE("ITEMNUM", mtdatabean.getValue("ITEMNUM"));
/*  847:1020 */       databean.getQBE().setQBE("ITEMSETID", mtdatabean.getValue("ITEMSETID"));
/*  848:     */     }
/*  849:1023 */     if (!mtdatabean.getValue("SITEID").equals("")) {
/*  850:1024 */       databean.getQBE().setQBE("SITEID", mtdatabean.getValue("SITEID"));
/*  851:     */     }
/*  852:1025 */     if (!mtdatabean.getValue("STORELOC").equals("")) {
/*  853:1026 */       databean.getQBE().setQBE("LOCATION", mtdatabean.getValue("STORELOC"));
/*  854:     */     }
/*  855:1027 */     if (!mtdatabean.getValue("BINNUM").equals("")) {
/*  856:1028 */       databean.getQBE().setQBE("BINNUM", mtdatabean.getValue("BINNUM"));
/*  857:     */     }
/*  858:1030 */     databean.reset();
/*  859:     */     
/*  860:1032 */     return false;
/*  861:     */   }
/*  862:     */   
/*  863:     */   public boolean initpagerotatingassetlookup(UIEvent event)
/*  864:     */     throws MobileApplicationException
/*  865:     */   {
/*  866:1038 */     MobileMboDataBean databean = ((PageControl)event.getCreatingObject()).getDataBean();
/*  867:     */     
/*  868:1040 */     MobileMboDataBean mtdatabean = UIUtil.getCurrentScreen().getDataBean();
/*  869:     */     
/*  870:1042 */     databean.getQBE().setQBE("ITEMNUM", mtdatabean.getValue("ITEMNUM"));
/*  871:1043 */     if (!mtdatabean.getValue("STORELOC").equals("")) {
/*  872:1044 */       databean.getQBE().setQBE("LOCATION", mtdatabean.getValue("STORELOC"));
/*  873:     */     }
/*  874:1047 */     if (!mtdatabean.getValue("SITEID").equals("")) {
/*  875:1048 */       databean.getQBE().setQBE("SITEID", mtdatabean.getValue("SITEID"));
/*  876:     */     }
/*  877:1050 */     databean.reset();
/*  878:     */     
/*  879:1052 */     return false;
/*  880:     */   }
/*  881:     */   
/*  882:     */   public boolean lookup(UIEvent event)
/*  883:     */     throws MobileApplicationException
/*  884:     */   {
/*  885:1061 */     String fieldName = ((AbstractMobileControl)event.getCreatingObject()).getValue("dataattribute");
/*  886:1063 */     if ((fieldName != null) && (fieldName.equalsIgnoreCase("itemnum")))
/*  887:     */     {
/*  888:1065 */       MobileMboDataBean databean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*  889:1066 */       MobileMbo mbo = databean.getMobileMbo();
/*  890:     */       
/*  891:1068 */       MobileMboDataBean itembean = DataBeanCache.findDataBean("ITEM");
/*  892:1069 */       if (itembean == null)
/*  893:     */       {
/*  894:1071 */         MobileMboDataBeanManager mgrbean = new MobileMboDataBeanManager("ITEM");
/*  895:1072 */         itembean = mgrbean.getDataBean();
/*  896:1073 */         DataBeanCache.cacheDataBean("ITEM", itembean);
/*  897:     */       }
/*  898:1076 */       ItemFilter filter = new ItemFilter(itembean);
/*  899:     */       
/*  900:1078 */       String wostoreloc = mbo.getValue("STORELOC") != null ? mbo.getValue("STORELOC") : "";
/*  901:1079 */       String wobinnum = mbo.getValue("BINNUM") != null ? mbo.getValue("BINNUM") : "";
/*  902:1080 */       String wolotnum = mbo.getValue("LOTNUM") != null ? mbo.getValue("LOTNUM") : "";
/*  903:     */       
/*  904:1082 */       String itemType = null;
/*  905:1083 */       if (!mbo.isNull("ISSUETYPE")) {
/*  906:1085 */         itemType = ((WOApp)UIUtil.getApplication()).getInternalValue(databean, "ISSUETYP", databean.getValue("ISSUETYPE"));
/*  907:     */       }
/*  908:1090 */       if ((!"return".equalsIgnoreCase(itemType)) && ((!"".equals(wostoreloc)) || (!"".equals(wobinnum)) || (!"".equals(wolotnum)))) {
/*  909:1092 */         filter.applyInvbalancesFilter("ITEMBAL", wostoreloc, wobinnum, wolotnum);
/*  910:     */       }
/*  911:1095 */       List statuses = ItemFilter.translateItemStatusName(databean, new String[] { "ACTIVE", "PENDOBS" });
/*  912:     */       
/*  913:1097 */       String woorgid = mbo.getValue("ORGID");
/*  914:1098 */       String wositeid = mbo.getValue("SITEID");
/*  915:1100 */       if ((wostoreloc != null) && (wostoreloc.length() > 0)) {
/*  916:1101 */         filter.applyInventoryFilter("ITEMINVENTORY", statuses, wostoreloc, wositeid);
/*  917:     */       }
/*  918:1103 */       MobileMboQBE qbe = itembean.getQBE();
/*  919:1104 */       qbe.reset();
/*  920:     */       
/*  921:     */ 
/*  922:     */ 
/*  923:     */ 
/*  924:     */ 
/*  925:     */ 
/*  926:1111 */       qbe.setLookupParameter("WORKORDER", "ORGID", woorgid);
/*  927:1112 */       qbe.setLookupParameter("MATUSETRANS", "SITEID", wositeid);
/*  928:1113 */       qbe.setLookupParameter("MATUSETRANS", "STORELOC", wostoreloc);
/*  929:1114 */       qbe.setLookupParameter("MATUSETRANS", "BINNUM", wobinnum);
/*  930:1115 */       qbe.setLookupParameter("MATUSETRANS", "LOTNUM", wolotnum);
/*  931:1116 */       qbe.setQBE("DISPLAY_IN_LOOKUP", "1");
/*  932:     */       
/*  933:1118 */       itembean.reset();
/*  934:1119 */       itembean.getMobileMbo();
/*  935:     */     }
/*  936:1121 */     return false;
/*  937:     */   }
/*  938:     */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.mobilewo.WOMatTransEventHandler
 * JD-Core Version:    0.7.0.1
 */