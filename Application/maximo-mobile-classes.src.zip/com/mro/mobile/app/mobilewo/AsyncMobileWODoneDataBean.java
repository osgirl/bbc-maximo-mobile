/*  1:   */ package com.mro.mobile.app.mobilewo;
/*  2:   */ 
/*  3:   */ import com.mro.mobile.MobileApplicationException;
/*  4:   */ import com.mro.mobile.app.async.AsyncEventHandlerSupport;
/*  5:   */ import com.mro.mobile.ui.MobileMboDataBean;
/*  6:   */ import com.mro.mobile.ui.event.UIEvent;
/*  7:   */ import com.mro.mobile.ui.res.UIUtil;
/*  8:   */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*  9:   */ 
/* 10:   */ public class AsyncMobileWODoneDataBean
/* 11:   */   extends AsyncEventHandlerSupport
/* 12:   */ {
/* 13:25 */   private MobileMboDataBean databean = null;
/* 14:   */   
/* 15:   */   public AsyncMobileWODoneDataBean(MobileMboDataBean databean)
/* 16:   */   {
/* 17:28 */     this.databean = databean;
/* 18:   */   }
/* 19:   */   
/* 20:   */   public boolean doRealWok(UIEvent event)
/* 21:   */     throws MobileApplicationException
/* 22:   */   {
/* 23:32 */     super.updateProgressBar("submitdata", null, event);
/* 24:33 */     this.databean.done();
/* 25:34 */     return true;
/* 26:   */   }
/* 27:   */   
/* 28:   */   public void postRealWork(UIEvent event)
/* 29:   */     throws MobileApplicationException
/* 30:   */   {
/* 31:38 */     String listpage = UIUtil.getCurrentScreen().getParentControl().getStringValue("listpage");
/* 32:39 */     if (listpage != null) {
/* 33:40 */       UIUtil.showPage(listpage);
/* 34:   */     }
/* 35:   */   }
/* 36:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.mobilewo.AsyncMobileWODoneDataBean
 * JD-Core Version:    0.7.0.1
 */