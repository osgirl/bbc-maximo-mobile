/*   1:    */ package com.mro.mobile.app.mobilewo;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.app.BasicMobileDeviceUIApplication;
/*   5:    */ import com.mro.mobile.app.DefaultMobileMboDataFormatter;
/*   6:    */ import com.mro.mobile.mbo.MobileMbo;
/*   7:    */ import com.mro.mobile.mbo.MobileMboQBE;
/*   8:    */ import com.mro.mobile.ui.DataBeanCache;
/*   9:    */ import com.mro.mobile.ui.MobileMboDataBean;
/*  10:    */ import com.mro.mobile.ui.MobileMboDataBeanManager;
/*  11:    */ import com.mro.mobile.ui.event.UIEvent;
/*  12:    */ import com.mro.mobile.ui.res.UIUtil;
/*  13:    */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*  14:    */ import com.mro.mobile.ui.res.controls.PageControl;
/*  15:    */ import java.util.List;
/*  16:    */ 
/*  17:    */ public class SelectPlannedToolEventHandler
/*  18:    */   extends MobileWOCommonEventHandler
/*  19:    */ {
/*  20:    */   public boolean performEvent(UIEvent event)
/*  21:    */     throws MobileApplicationException
/*  22:    */   {
/*  23: 34 */     if (event == null) {
/*  24: 34 */       return false;
/*  25:    */     }
/*  26: 36 */     String eventId = event.getEventName();
/*  27: 38 */     if (eventId.equalsIgnoreCase("selectvalues")) {
/*  28: 40 */       return selectvalues(event);
/*  29:    */     }
/*  30: 42 */     if (eventId.equalsIgnoreCase("initpage")) {
/*  31: 44 */       return initpage(event);
/*  32:    */     }
/*  33: 46 */     if (eventId.equalsIgnoreCase("luconnect")) {
/*  34: 47 */       applyQBE(event);
/*  35:    */     }
/*  36: 50 */     super.performEvent(event);
/*  37:    */     
/*  38: 52 */     return false;
/*  39:    */   }
/*  40:    */   
/*  41:    */   public void applyQBE(UIEvent event)
/*  42:    */     throws MobileApplicationException
/*  43:    */   {
/*  44: 58 */     MobileMboDataBean toolbean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*  45: 59 */     MobileMboDataBean workorderBean = DataBeanCache.findDataBean("WORKORDER");
/*  46: 60 */     MobileMboQBE qbe = toolbean.getQBE();
/*  47: 61 */     qbe.reset();
/*  48: 62 */     qbe.setQbeExactMatch(true);
/*  49: 64 */     if (workorderBean != null)
/*  50:    */     {
/*  51: 65 */       ItemFilter filter = new ItemFilter(toolbean);
/*  52: 66 */       List statusesInv = ItemFilter.translateItemStatusName(workorderBean, new String[] { "ACTIVE", "PENDOBS" });
/*  53: 67 */       List statusItemOrg = ItemFilter.translateItemStatusName(workorderBean, new String[] { "ACTIVE" });
/*  54:    */       
/*  55: 69 */       String woorgid = workorderBean.getMobileMbo().getValue("ORGID");
/*  56:    */       
/*  57: 71 */       filter.applyItemOrgInfoFilter("TOOLITEMORGINFO", statusItemOrg, false, woorgid, "TOOLINVENTORY", statusesInv);
/*  58:    */       
/*  59: 73 */       qbe.setLookupParameter("WORKORDER", "ORGID", woorgid);
/*  60: 74 */       qbe.setQBE("DISPLAY_IN_LOOKUP", "1");
/*  61: 75 */       toolbean.reset();
/*  62:    */     }
/*  63:    */     else
/*  64:    */     {
/*  65: 77 */       qbe.setLookupParameter("WORKORDER", "ORGID", "!=~NULL~");
/*  66: 78 */       qbe.setQBE("DISPLAY_IN_LOOKUP", "1");
/*  67:    */     }
/*  68:    */   }
/*  69:    */   
/*  70:    */   private boolean initpage(UIEvent event)
/*  71:    */     throws MobileApplicationException
/*  72:    */   {
/*  73: 84 */     MobileMboDataBean databean = ((PageControl)event.getCreatingObject()).getDataBean();
/*  74: 88 */     for (int i = 0; i < databean.count(); i++) {
/*  75: 89 */       databean.setValue(i, "ENTEREDHOURS", databean.getValue(i, "HOURS"));
/*  76:    */     }
/*  77: 92 */     return true;
/*  78:    */   }
/*  79:    */   
/*  80:    */   public boolean selectvalues(UIEvent event)
/*  81:    */     throws MobileApplicationException
/*  82:    */   {
/*  83: 99 */     String pageid = UIUtil.getCurrentScreen().getPage().getId();
/*  84:101 */     if (pageid.equalsIgnoreCase("toolslookup")) {
/*  85:102 */       return selecttoolvalues(event);
/*  86:    */     }
/*  87:104 */     if (pageid.equalsIgnoreCase("plannedtoollookup")) {
/*  88:105 */       return selectplannedtools(event);
/*  89:    */     }
/*  90:107 */     return true;
/*  91:    */   }
/*  92:    */   
/*  93:    */   public boolean selecttoolvalues(UIEvent event)
/*  94:    */     throws MobileApplicationException
/*  95:    */   {
/*  96:112 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/*  97:113 */     MobileMboDataBean ttdatabean = ((PageControl)UIUtil.getCurrentScreen()).getLaunchingControl().getDataBean();
/*  98:114 */     boolean atleastonerowcopied = false;
/*  99:    */     
/* 100:116 */     int count = databean.count();
/* 101:117 */     for (int i = 0; i < count; i++) {
/* 102:119 */       if (databean.getMobileMbo(i).isSelected())
/* 103:    */       {
/* 104:122 */         atleastonerowcopied = true;
/* 105:123 */         ttdatabean.insert();
/* 106:    */         
/* 107:125 */         ttdatabean.setValue("ITEMSETID", databean.getMobileMbo(i).getValue("ITEMSETID"));
/* 108:126 */         ttdatabean.setValue("ITEMNUM", databean.getMobileMbo(i).getValue("ITEMNUM"));
/* 109:127 */         ttdatabean.setValue("TOOLQTY", "1");
/* 110:128 */         ttdatabean.setValue("TOOLHRS", "1");
/* 111:    */       }
/* 112:    */     }
/* 113:132 */     if (!atleastonerowcopied)
/* 114:    */     {
/* 115:134 */       ttdatabean.getDataBeanManager().cancel();
/* 116:135 */       UIUtil.getApplication().removeCurrentScreen(true);
/* 117:136 */       return true;
/* 118:    */     }
/* 119:139 */     if (!UIUtil.checkESignature(event, ttdatabean, "TOOLACTUAL"))
/* 120:    */     {
/* 121:141 */       ttdatabean.getDataBeanManager().cancel();
/* 122:    */     }
/* 123:    */     else
/* 124:    */     {
/* 125:145 */       ttdatabean.getDataBeanManager().save();
/* 126:146 */       ttdatabean.reset();
/* 127:147 */       UIUtil.getApplication().removeCurrentScreen(true);
/* 128:    */     }
/* 129:149 */     return true;
/* 130:    */   }
/* 131:    */   
/* 132:    */   public boolean selectplannedtools(UIEvent event)
/* 133:    */     throws MobileApplicationException
/* 134:    */   {
/* 135:154 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/* 136:155 */     MobileMboDataBean wodatabean = databean.getParentBean();
/* 137:156 */     MobileMboDataBean ttdatabean = wodatabean.getDataBean("WOTOOLTRANS");
/* 138:157 */     boolean atleastonerowcopied = false;
/* 139:    */     
/* 140:159 */     int count = databean.count();
/* 141:160 */     for (int i = 0; i < count; i++) {
/* 142:162 */       if (databean.getMobileMbo(i).isSelected())
/* 143:    */       {
/* 144:167 */         atleastonerowcopied = true;
/* 145:168 */         ttdatabean.insert();
/* 146:169 */         ttdatabean.setValue("ACTUALSTASKID", databean.getMobileMbo(i).getValue("TASKID"));
/* 147:170 */         ttdatabean.setValue("ITEMSETID", databean.getMobileMbo(i).getValue("ITEMSETID"));
/* 148:171 */         ttdatabean.setValue("ITEMNUM", databean.getMobileMbo(i).getValue("ITEMNUM"));
/* 149:172 */         if (databean.getMobileMbo(i).getValue("ITEMNUM").equals("1"))
/* 150:    */         {
/* 151:174 */           ttdatabean.setValue("TOOLQTY", "1");
/* 152:    */         }
/* 153:    */         else
/* 154:    */         {
/* 155:178 */           Double d = new Double(DefaultMobileMboDataFormatter.stringToDouble(databean.getMobileMbo(i).getValue("ITEMQTY")));
/* 156:179 */           ttdatabean.setValue("TOOLQTY", "" + d.intValue());
/* 157:    */         }
/* 158:183 */         ttdatabean.setValue("TOOLHRS", databean.getMobileMbo(i).getValue("ENTEREDHOURS"));
/* 159:184 */         ttdatabean.setValue("TOOLRATE", databean.getMobileMbo(i).getValue("RATE"));
/* 160:    */       }
/* 161:    */     }
/* 162:188 */     if (!atleastonerowcopied)
/* 163:    */     {
/* 164:190 */       ttdatabean.getDataBeanManager().cancel();
/* 165:191 */       UIUtil.getApplication().removeCurrentScreen(true);
/* 166:192 */       return true;
/* 167:    */     }
/* 168:195 */     if (!UIUtil.checkESignature(event, ttdatabean, "TOOLACTUAL"))
/* 169:    */     {
/* 170:197 */       ttdatabean.getDataBeanManager().cancel();
/* 171:    */     }
/* 172:    */     else
/* 173:    */     {
/* 174:201 */       ttdatabean.getDataBeanManager().save();
/* 175:202 */       ttdatabean.reset();
/* 176:203 */       UIUtil.getApplication().removeCurrentScreen(true);
/* 177:    */     }
/* 178:205 */     return true;
/* 179:    */   }
/* 180:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.mobilewo.SelectPlannedToolEventHandler
 * JD-Core Version:    0.7.0.1
 */