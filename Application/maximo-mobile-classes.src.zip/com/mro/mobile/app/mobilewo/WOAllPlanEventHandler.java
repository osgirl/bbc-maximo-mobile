/*   1:    */ package com.mro.mobile.app.mobilewo;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.app.AbstractMobileDeviceApplication;
/*   5:    */ import com.mro.mobile.app.DefaultMobileMboDataFormatter;
/*   6:    */ import com.mro.mobile.app.MobileDeviceAppSession;
/*   7:    */ import com.mro.mobile.app.async.AsyncEventHandlerSupport;
/*   8:    */ import com.mro.mobile.mbo.MobileMbo;
/*   9:    */ import com.mro.mobile.mbo.MobileMboInfo;
/*  10:    */ import com.mro.mobile.mbo.MobileMboOrder;
/*  11:    */ import com.mro.mobile.mbo.MobileMboQBE;
/*  12:    */ import com.mro.mobile.ui.DataBeanCache;
/*  13:    */ import com.mro.mobile.ui.MobileMboDataBean;
/*  14:    */ import com.mro.mobile.ui.MobileMboDataBeanManager;
/*  15:    */ import com.mro.mobile.ui.MobileMboDataFormatter;
/*  16:    */ import com.mro.mobile.ui.event.UIEvent;
/*  17:    */ import com.mro.mobile.ui.res.UIUtil;
/*  18:    */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*  19:    */ import com.mro.mobileapp.WOApp;
/*  20:    */ 
/*  21:    */ public class WOAllPlanEventHandler
/*  22:    */   extends MobileWOCommonEventHandler
/*  23:    */ {
/*  24:    */   public boolean performEvent(UIEvent event)
/*  25:    */     throws MobileApplicationException
/*  26:    */   {
/*  27: 36 */     if (event == null) {
/*  28: 36 */       return false;
/*  29:    */     }
/*  30: 38 */     String eventId = event.getEventName();
/*  31: 40 */     if (eventId.equalsIgnoreCase("initallmaterials")) {
/*  32: 42 */       return initAllMaterials(event);
/*  33:    */     }
/*  34: 44 */     if (eventId.equalsIgnoreCase("refreshallmaterials")) {
/*  35: 46 */       return refreshAllMaterials(event);
/*  36:    */     }
/*  37: 48 */     if (eventId.equalsIgnoreCase("initalltools")) {
/*  38: 50 */       return initAllTools(event);
/*  39:    */     }
/*  40: 52 */     if (eventId.equalsIgnoreCase("refreshalltools")) {
/*  41: 54 */       return refreshAllTools(event);
/*  42:    */     }
/*  43: 56 */     if (eventId.equalsIgnoreCase("toggleMatSummarize")) {
/*  44: 58 */       return toggleMatSummarize(event);
/*  45:    */     }
/*  46: 60 */     if (eventId.equalsIgnoreCase("toggleToolSummarize")) {
/*  47: 62 */       return toggleToolSummarize(event);
/*  48:    */     }
/*  49: 64 */     if (eventId.equalsIgnoreCase("matOkValueChanged")) {
/*  50: 66 */       return matOkValueChanged(event);
/*  51:    */     }
/*  52: 68 */     if (eventId.equalsIgnoreCase("toolOkValueChanged")) {
/*  53: 70 */       return toolOkValueChanged(event);
/*  54:    */     }
/*  55: 72 */     if (eventId.equalsIgnoreCase("matShowAll")) {
/*  56: 74 */       return matShowAll(event);
/*  57:    */     }
/*  58: 76 */     if (eventId.equalsIgnoreCase("matShowSummary")) {
/*  59: 78 */       return matShowSummary(event);
/*  60:    */     }
/*  61: 80 */     if (eventId.equalsIgnoreCase("toolShowAll")) {
/*  62: 82 */       return toolShowAll(event);
/*  63:    */     }
/*  64: 84 */     if (eventId.equalsIgnoreCase("toolShowSummary")) {
/*  65: 86 */       return toolShowSummary(event);
/*  66:    */     }
/*  67: 88 */     if (eventId.equalsIgnoreCase("setvalue")) {
/*  68: 90 */       return setvalue(event);
/*  69:    */     }
/*  70: 93 */     super.performEvent(event);
/*  71:    */     
/*  72: 95 */     return false;
/*  73:    */   }
/*  74:    */   
/*  75:    */   public boolean initAllMaterials(UIEvent event)
/*  76:    */     throws MobileApplicationException
/*  77:    */   {
/*  78:100 */     final MobileMboDataBean tabledatabean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*  79:101 */     final MobileMboDataBean wodatabean = DataBeanCache.findDataBean("WPALLMATSWOS");
/*  80:    */     
/*  81:103 */     new AsyncEventHandlerSupport()
/*  82:    */     {
/*  83:    */       public boolean doRealWok(UIEvent event)
/*  84:    */         throws MobileApplicationException
/*  85:    */       {
/*  86:105 */         super.updateProgressBar("processdatainprogress", null, event);
/*  87:106 */         return WOAllPlanEventHandler.this.initTable(event, "WPMATERIAL", tabledatabean, wodatabean);
/*  88:    */       }
/*  89:    */       
/*  90:    */       public void postRealWork(UIEvent event)
/*  91:    */         throws MobileApplicationException
/*  92:    */       {}
/*  93:106 */     }.handleInBackground(event);
/*  94:    */     
/*  95:    */ 
/*  96:    */ 
/*  97:    */ 
/*  98:    */ 
/*  99:    */ 
/* 100:113 */     return true;
/* 101:    */   }
/* 102:    */   
/* 103:    */   public boolean refreshAllMaterials(UIEvent event)
/* 104:    */     throws MobileApplicationException
/* 105:    */   {
/* 106:120 */     MobileMboDataBean currentdatabean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/* 107:121 */     if (currentdatabean != null)
/* 108:    */     {
/* 109:122 */       MobileMboDataBean databean = DataBeanCache.findDataBean("WPALLMATERIALS");
/* 110:123 */       databean.setValue("OK", currentdatabean.getValue("OK"));
/* 111:124 */       databean.getDataBeanManager().save();
/* 112:125 */       databean.reset();
/* 113:    */     }
/* 114:127 */     return true;
/* 115:    */   }
/* 116:    */   
/* 117:    */   public boolean initAllTools(UIEvent event)
/* 118:    */     throws MobileApplicationException
/* 119:    */   {
/* 120:134 */     final MobileMboDataBean tabledatabean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/* 121:135 */     final MobileMboDataBean wodatabean = DataBeanCache.findDataBean("WPALLTOOLSWOS");
/* 122:    */     
/* 123:137 */     new AsyncEventHandlerSupport()
/* 124:    */     {
/* 125:    */       public boolean doRealWok(UIEvent event)
/* 126:    */         throws MobileApplicationException
/* 127:    */       {
/* 128:139 */         super.updateProgressBar("processdatainprogress", null, event);
/* 129:140 */         return WOAllPlanEventHandler.this.initTable(event, "WPTOOL", tabledatabean, wodatabean);
/* 130:    */       }
/* 131:    */       
/* 132:    */       public void postRealWork(UIEvent event)
/* 133:    */         throws MobileApplicationException
/* 134:    */       {}
/* 135:140 */     }.handleInBackground(event);
/* 136:    */     
/* 137:    */ 
/* 138:    */ 
/* 139:    */ 
/* 140:    */ 
/* 141:    */ 
/* 142:147 */     return true;
/* 143:    */   }
/* 144:    */   
/* 145:    */   public boolean refreshAllTools(UIEvent event)
/* 146:    */     throws MobileApplicationException
/* 147:    */   {
/* 148:153 */     MobileMboDataBean currentdatabean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/* 149:154 */     if (currentdatabean != null)
/* 150:    */     {
/* 151:155 */       MobileMboDataBean databean = DataBeanCache.findDataBean("WPALLTOOLS");
/* 152:156 */       databean.setValue("OK", currentdatabean.getValue("OK"));
/* 153:157 */       databean.getDataBeanManager().save();
/* 154:158 */       databean.reset();
/* 155:    */     }
/* 156:160 */     return true;
/* 157:    */   }
/* 158:    */   
/* 159:    */   public boolean initTable(UIEvent event, String page, MobileMboDataBean tabledatabean, MobileMboDataBean wodatabean)
/* 160:    */     throws MobileApplicationException
/* 161:    */   {
/* 162:167 */     MobileMboDataBean allflagsBean = WOApp.getWpAllFlags();
/* 163:    */     
/* 164:    */ 
/* 165:    */ 
/* 166:171 */     int delcount = tabledatabean.count();
/* 167:172 */     for (int i = 0; i < delcount; i++) {
/* 168:174 */       tabledatabean.deleteLocal(i);
/* 169:    */     }
/* 170:176 */     tabledatabean.getDataBeanManager().save();
/* 171:177 */     tabledatabean.reset();
/* 172:    */     
/* 173:    */ 
/* 174:180 */     int count = wodatabean.count();
/* 175:181 */     for (int i = 0; i < count; i++)
/* 176:    */     {
/* 177:183 */       MobileMboDataBean plans = wodatabean.getDataBean(i, page);
/* 178:184 */       int plancount = plans.count();
/* 179:185 */       for (int b = 0; b < plancount; b++) {
/* 180:187 */         if (page.equalsIgnoreCase("WPMATERIAL"))
/* 181:    */         {
/* 182:189 */           tabledatabean.insert();
/* 183:    */           
/* 184:    */ 
/* 185:192 */           tabledatabean.setValue("_ID", "" + plans.getMobileMbo(b).getLongValue("_ID"));
/* 186:193 */           tabledatabean.setValue("ORGID", plans.getValue(b, "ORGID"));
/* 187:194 */           tabledatabean.setValue("SITEID", plans.getValue(b, "SITEID"));
/* 188:195 */           tabledatabean.setValue("TASKID", plans.getValue(b, "TASKID"));
/* 189:196 */           tabledatabean.setValue("ITEMNUM", plans.getValue(b, "ITEMNUM"));
/* 190:197 */           tabledatabean.setValue("ITEMSETID", plans.getValue(b, "ITEMSETID"));
/* 191:198 */           tabledatabean.setValue("DESCRIPTION", plans.getValue(b, "DESCRIPTION"));
/* 192:199 */           tabledatabean.setValue("LOCATION_DESCRIPTION", plans.getValue(b, "LOCATION_DESCRIPTION"));
/* 193:200 */           tabledatabean.setValue("ITEMQTY", plans.getValue(b, "ITEMQTY"));
/* 194:201 */           tabledatabean.setValue("LOCATION", plans.getValue(b, "LOCATION"));
/* 195:202 */           tabledatabean.setValue("VENDOR", plans.getValue(b, "VENDOR"));
/* 196:203 */           tabledatabean.setValue("WONUM", plans.getValue(b, "WONUM"));
/* 197:204 */           tabledatabean.setValue("DISPLAYWONUM", plans.getValue(b, "DISPLAYWONUM"));
/* 198:205 */           tabledatabean.setValue("MANUFACTURER", plans.getValue(b, "MANUFACTURER"));
/* 199:206 */           tabledatabean.setValue("DIRECTREQ", plans.getValue(b, "DIRECTREQ"));
/* 200:207 */           tabledatabean.setValue("OK", plans.getValue(b, "OK"));
/* 201:208 */           tabledatabean.setValue("ORDERUNIT", plans.getValue(b, "ORDERUNIT"));
/* 202:209 */           tabledatabean.setValue("UNITCOST", plans.getValue(b, "UNITCOST"));
/* 203:210 */           tabledatabean.setValue("LINECOST", plans.getValue(b, "LINECOST"));
/* 204:211 */           tabledatabean.setValue("MODELNUM", plans.getValue(b, "MODELNUM"));
/* 205:212 */           tabledatabean.setValue("STORELOCSITE", plans.getValue(b, "STORELOCSITE"));
/* 206:213 */           tabledatabean.setValue("PR", plans.getValue(b, "PR"));
/* 207:214 */           tabledatabean.setValue("PRLINENUM", plans.getValue(b, "PRLINENUM"));
/* 208:215 */           tabledatabean.setValue("SUMMARYROW", "0");
/* 209:    */         }
/* 210:217 */         else if (page.equalsIgnoreCase("WPTOOL"))
/* 211:    */         {
/* 212:219 */           tabledatabean.insert();
/* 213:220 */           tabledatabean.setValue("_ID", plans.getValue(b, "_ID"));
/* 214:221 */           tabledatabean.setValue("ORGID", plans.getValue(b, "ORGID"));
/* 215:222 */           tabledatabean.setValue("SITEID", plans.getValue(b, "SITEID"));
/* 216:223 */           tabledatabean.setValue("TASKID", plans.getValue(b, "TASKID"));
/* 217:224 */           tabledatabean.setValue("ITEMNUM", plans.getValue(b, "ITEMNUM"));
/* 218:225 */           tabledatabean.setValue("ITEMSETID", plans.getValue(b, "ITEMSETID"));
/* 219:226 */           tabledatabean.setValue("DESCRIPTION", plans.getValue(b, "DESCRIPTION"));
/* 220:227 */           tabledatabean.setValue("ITEMQTY", plans.getValue(b, "ITEMQTY"));
/* 221:228 */           tabledatabean.setValue("LOCATION", plans.getValue(b, "LOCATION"));
/* 222:229 */           tabledatabean.setValue("WONUM", plans.getValue(b, "WONUM"));
/* 223:230 */           tabledatabean.setValue("DISPLAYWONUM", plans.getValue(b, "DISPLAYWONUM"));
/* 224:231 */           tabledatabean.setValue("OK", plans.getValue(b, "OK"));
/* 225:232 */           tabledatabean.setValue("HOURS", plans.getValue(b, "HOURS"));
/* 226:233 */           tabledatabean.setValue("STORELOCSITE", plans.getValue(b, "STORELOCSITE"));
/* 227:234 */           tabledatabean.setValue("SUMMARYROW", "0");
/* 228:    */         }
/* 229:    */       }
/* 230:    */     }
/* 231:239 */     tabledatabean.getDataBeanManager().save();
/* 232:240 */     MobileMboOrder mboOrder = new MobileMboOrder();
/* 233:241 */     mboOrder.setOrder("ITEMNUM", true);
/* 234:242 */     mboOrder.setOrder("ITEMSETID", true);
/* 235:243 */     mboOrder.setOrder("DESCRIPTION", true);
/* 236:244 */     tabledatabean.setOrder(mboOrder);
/* 237:245 */     tabledatabean.reset();
/* 238:    */     
/* 239:    */ 
/* 240:    */ 
/* 241:    */ 
/* 242:250 */     String databeanName = "";
/* 243:251 */     if (page.equalsIgnoreCase("WPMATERIAL")) {
/* 244:252 */       databeanName = "WPALLMATERIALS";
/* 245:253 */     } else if (page.equalsIgnoreCase("WPTOOL")) {
/* 246:254 */       databeanName = "WPALLTOOLS";
/* 247:    */     }
/* 248:256 */     MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager(databeanName);
/* 249:257 */     MobileMboDataBean newBean = mgrDBMgr.getDataBean();
/* 250:    */     
/* 251:259 */     String lastItemnum = "";
/* 252:260 */     String lastItemsetid = "";
/* 253:261 */     String lastDesc = "";
/* 254:262 */     int iSummaryRow = 0;
/* 255:263 */     int iSummaryRowId = 0;
/* 256:264 */     int tblcount = tabledatabean.count();
/* 257:265 */     for (int b = 0; b < tblcount; b++)
/* 258:    */     {
/* 259:267 */       MobileMbo mbo = tabledatabean.getMobileMbo(b);
/* 260:268 */       if ((!lastItemnum.equals(mbo.getValue("ITEMNUM"))) || (!lastItemsetid.equals(mbo.getValue("ITEMSETID"))) || (!lastDesc.equals(mbo.getValue("DESCRIPTION"))))
/* 261:    */       {
/* 262:272 */         newBean.insert();
/* 263:273 */         iSummaryRow = newBean.getCurrentPosition();
/* 264:274 */         iSummaryRowId++;
/* 265:275 */         if (page.equalsIgnoreCase("WPMATERIAL"))
/* 266:    */         {
/* 267:277 */           newBean.setValue("SUMMARYROWID", "" + iSummaryRowId);
/* 268:278 */           newBean.setValue("ORGID", mbo.getValue("ORGID"));
/* 269:279 */           newBean.setValue("SITEID", mbo.getValue("SITEID"));
/* 270:280 */           newBean.setValue("TASKID", mbo.getValue("TASKID"));
/* 271:281 */           newBean.setValue("ITEMNUM", mbo.getValue("ITEMNUM"));
/* 272:282 */           newBean.setValue("ITEMSETID", mbo.getValue("ITEMSETID"));
/* 273:283 */           newBean.setValue("DESCRIPTION", mbo.getValue("DESCRIPTION"));
/* 274:284 */           newBean.setValue("ITEMQTY", mbo.getValue("ITEMQTY"));
/* 275:285 */           newBean.setValue("LOCATION", mbo.getValue("LOCATION"));
/* 276:286 */           newBean.setValue("WONUM", mbo.getValue("WONUM"));
/* 277:287 */           newBean.setValue("DISPLAYWONUM", mbo.getValue("DISPLAYWONUM"));
/* 278:288 */           newBean.setValue("MANUFACTURER", mbo.getValue("MANUFACTURER"));
/* 279:289 */           newBean.setValue("DIRECTREQ", mbo.getValue("DIRECTREQ"));
/* 280:290 */           newBean.setValue("OK", mbo.getValue("OK"));
/* 281:291 */           newBean.setValue("ORDERUNIT", mbo.getValue("ORDERUNIT"));
/* 282:292 */           newBean.setValue("UNITCOST", mbo.getValue("UNITCOST"));
/* 283:293 */           newBean.setValue("LINECOST", mbo.getValue("LINECOST"));
/* 284:294 */           newBean.setValue("MODELNUM", mbo.getValue("MODELNUM"));
/* 285:295 */           newBean.setValue("STORELOCSITE", mbo.getValue("STORELOCSITE"));
/* 286:296 */           newBean.setValue("PR", mbo.getValue("PR"));
/* 287:297 */           newBean.setValue("PRLINENUM", mbo.getValue("PRLINENUM"));
/* 288:    */         }
/* 289:299 */         else if (page.equalsIgnoreCase("WPTOOL"))
/* 290:    */         {
/* 291:301 */           newBean.setValue("SUMMARYROWID", "" + iSummaryRowId);
/* 292:302 */           newBean.setValue("ORGID", mbo.getValue("ORGID"));
/* 293:303 */           newBean.setValue("SITEID", mbo.getValue("SITEID"));
/* 294:304 */           newBean.setValue("TASKID", mbo.getValue("TASKID"));
/* 295:305 */           newBean.setValue("ITEMNUM", mbo.getValue("ITEMNUM"));
/* 296:306 */           newBean.setValue("ITEMSETID", mbo.getValue("ITEMSETID"));
/* 297:307 */           newBean.setValue("DESCRIPTION", mbo.getValue("DESCRIPTION"));
/* 298:308 */           newBean.setValue("ITEMQTY", mbo.getValue("ITEMQTY"));
/* 299:309 */           newBean.setValue("LOCATION", mbo.getValue("LOCATION"));
/* 300:310 */           newBean.setValue("WONUM", mbo.getValue("WONUM"));
/* 301:311 */           newBean.setValue("DISPLAYWONUM", mbo.getValue("DISPLAYWONUM"));
/* 302:312 */           newBean.setValue("OK", mbo.getValue("OK"));
/* 303:313 */           newBean.setValue("HOURS", mbo.getValue("HOURS"));
/* 304:314 */           newBean.setValue("STORELOCSITE", mbo.getValue("STORELOCSITE"));
/* 305:    */         }
/* 306:316 */         newBean.setValue("SUMMARYROW", "1");
/* 307:    */       }
/* 308:    */       else
/* 309:    */       {
/* 310:321 */         double qty = DefaultMobileMboDataFormatter.stringToDouble(newBean.getMobileMbo(iSummaryRow).getValue("ITEMQTY"));
/* 311:322 */         double qty2 = DefaultMobileMboDataFormatter.stringToDouble(mbo.getValue("ITEMQTY"));
/* 312:323 */         newBean.setValue(iSummaryRow, "ITEMQTY", "" + (qty + qty2));
/* 313:324 */         if (page.equalsIgnoreCase("WPMATERIAL"))
/* 314:    */         {
/* 315:326 */           double totalLineCost = DefaultMobileMboDataFormatter.stringToDouble(newBean.getMobileMbo(iSummaryRow).getValue("LINECOST"));
/* 316:327 */           double currentLineCost = DefaultMobileMboDataFormatter.stringToDouble(mbo.getValue("LINECOST"));
/* 317:328 */           newBean.setValue(iSummaryRow, "LINECOST", "" + (totalLineCost + currentLineCost));
/* 318:    */         }
/* 319:330 */         if (page.equalsIgnoreCase("WPTOOL"))
/* 320:    */         {
/* 321:332 */           double hours = DefaultMobileMboDataFormatter.durationToDouble(newBean.getMobileMbo(iSummaryRow).getValue("HOURS"));
/* 322:333 */           double hours2 = DefaultMobileMboDataFormatter.durationToDouble(mbo.getValue("HOURS"));
/* 323:334 */           newBean.setValue(iSummaryRow, "HOURS", "" + (hours + hours2));
/* 324:    */         }
/* 325:337 */         if (!mbo.getBooleanValue("OK")) {
/* 326:338 */           newBean.setValue(iSummaryRow, "OK", "0");
/* 327:    */         }
/* 328:    */       }
/* 329:340 */       mbo.setValue("SUMMARYROWID", "" + iSummaryRowId);
/* 330:    */       
/* 331:342 */       lastItemnum = mbo.getValue("ITEMNUM");
/* 332:343 */       lastItemsetid = mbo.getValue("ITEMSETID");
/* 333:344 */       lastDesc = mbo.getValue("DESCRIPTION");
/* 334:    */     }
/* 335:346 */     newBean.getDataBeanManager().save();
/* 336:347 */     tabledatabean.getDataBeanManager().save();
/* 337:    */     
/* 338:349 */     boolean showsummarized = false;
/* 339:350 */     if (allflagsBean != null) {
/* 340:352 */       if (page.equalsIgnoreCase("WPMATERIAL"))
/* 341:    */       {
/* 342:354 */         if (allflagsBean.getMobileMbo(0).getBooleanValue("SHOWMATSUMMARIZE")) {
/* 343:355 */           showsummarized = true;
/* 344:    */         }
/* 345:    */       }
/* 346:357 */       else if (page.equalsIgnoreCase("WPTOOL")) {
/* 347:359 */         if (allflagsBean.getMobileMbo(0).getBooleanValue("SHOWTOOLSUMMARIZE")) {
/* 348:360 */           showsummarized = false;
/* 349:    */         }
/* 350:    */       }
/* 351:    */     }
/* 352:364 */     tabledatabean.setOrder(mboOrder);
/* 353:366 */     if (showsummarized) {
/* 354:367 */       tabledatabean.getQBE().setQBE("SUMMARYROW", "1");
/* 355:    */     } else {
/* 356:369 */       tabledatabean.getQBE().setQBE("SUMMARYROW", "0");
/* 357:    */     }
/* 358:371 */     tabledatabean.reset();
/* 359:    */     
/* 360:373 */     return true;
/* 361:    */   }
/* 362:    */   
/* 363:    */   public boolean refreshTable(UIEvent event, String page)
/* 364:    */     throws MobileApplicationException
/* 365:    */   {
/* 366:378 */     return true;
/* 367:    */   }
/* 368:    */   
/* 369:    */   public boolean toggleMatSummarize(UIEvent event)
/* 370:    */     throws MobileApplicationException
/* 371:    */   {
/* 372:383 */     MobileMboDataBean tableBean = DataBeanCache.findDataBean("WPALLMATERIALS");
/* 373:384 */     return toggleSummarize(event, "WPMATERIAL", tableBean);
/* 374:    */   }
/* 375:    */   
/* 376:    */   public boolean toggleToolSummarize(UIEvent event)
/* 377:    */     throws MobileApplicationException
/* 378:    */   {
/* 379:389 */     MobileMboDataBean tableBean = DataBeanCache.findDataBean("WPALLTOOLS");
/* 380:390 */     return toggleSummarize(event, "WPTOOL", tableBean);
/* 381:    */   }
/* 382:    */   
/* 383:    */   public boolean toggleSummarize(UIEvent event, String page, MobileMboDataBean tableBean)
/* 384:    */     throws MobileApplicationException
/* 385:    */   {
/* 386:395 */     tableBean.getDataBeanManager().save();
/* 387:    */     
/* 388:397 */     MobileMboDataBean allflagsBean = WOApp.getWpAllFlags();
/* 389:398 */     if (allflagsBean == null) {
/* 390:398 */       return true;
/* 391:    */     }
/* 392:400 */     String sValue = (String)event.getValue();
/* 393:401 */     boolean showsummarized = false;
/* 394:402 */     if ((sValue != null) && (sValue.equalsIgnoreCase("true"))) {
/* 395:403 */       showsummarized = true;
/* 396:    */     }
/* 397:405 */     MobileMboOrder mboOrder = new MobileMboOrder();
/* 398:406 */     mboOrder.setOrder("ITEMNUM", true);
/* 399:407 */     mboOrder.setOrder("ITEMSETID", true);
/* 400:408 */     mboOrder.setOrder("DESCRIPTION", true);
/* 401:409 */     tableBean.setOrder(mboOrder);
/* 402:411 */     if (showsummarized)
/* 403:    */     {
/* 404:413 */       tableBean.getQBE().setQBE("SUMMARYROW", "1");
/* 405:414 */       if (page.equals("WPMATERIAL")) {
/* 406:415 */         allflagsBean.setValue("SHOWMATSUMMARIZE", "1");
/* 407:    */       } else {
/* 408:417 */         allflagsBean.setValue("SHOWTOOLSUMMARIZE", "1");
/* 409:    */       }
/* 410:    */     }
/* 411:    */     else
/* 412:    */     {
/* 413:421 */       tableBean.getQBE().setQBE("SUMMARYROW", "0");
/* 414:422 */       if (page.equals("WPMATERIAL")) {
/* 415:423 */         allflagsBean.setValue("SHOWMATSUMMARIZE", "0");
/* 416:    */       } else {
/* 417:425 */         allflagsBean.setValue("SHOWTOOLSUMMARIZE", "0");
/* 418:    */       }
/* 419:    */     }
/* 420:427 */     allflagsBean.getDataBeanManager().save();
/* 421:428 */     tableBean.reset();
/* 422:    */     
/* 423:430 */     return true;
/* 424:    */   }
/* 425:    */   
/* 426:    */   public boolean setvalue(UIEvent event)
/* 427:    */     throws MobileApplicationException
/* 428:    */   {
/* 429:435 */     MobileMboDataBean tabledatabean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/* 430:436 */     if (tabledatabean.getName().equalsIgnoreCase("WPALLMATERIALS")) {
/* 431:438 */       matOkValueChanged(event);
/* 432:440 */     } else if (tabledatabean.getName().equalsIgnoreCase("WPALLTOOLS")) {
/* 433:442 */       toolOkValueChanged(event);
/* 434:    */     }
/* 435:445 */     return false;
/* 436:    */   }
/* 437:    */   
/* 438:    */   public boolean matOkValueChanged(UIEvent event)
/* 439:    */     throws MobileApplicationException
/* 440:    */   {
/* 441:450 */     MobileMboDataBean tableBean = DataBeanCache.findDataBean("WPALLMATERIALS");
/* 442:451 */     return okValueChanged(event, "WPMATERIAL", tableBean);
/* 443:    */   }
/* 444:    */   
/* 445:    */   public boolean toolOkValueChanged(UIEvent event)
/* 446:    */     throws MobileApplicationException
/* 447:    */   {
/* 448:456 */     MobileMboDataBean tableBean = DataBeanCache.findDataBean("WPALLTOOLS");
/* 449:457 */     return okValueChanged(event, "WPTOOL", tableBean);
/* 450:    */   }
/* 451:    */   
/* 452:    */   public boolean okValueChanged(UIEvent event, String page, MobileMboDataBean tableBean)
/* 453:    */     throws MobileApplicationException
/* 454:    */   {
/* 455:462 */     MobileMboDataBean allflagsBean = WOApp.getWpAllFlags();
/* 456:463 */     if (allflagsBean == null) {
/* 457:463 */       return true;
/* 458:    */     }
/* 459:465 */     String databeanName = "";
/* 460:466 */     String planIds = "";
/* 461:467 */     boolean showsummarized = false;
/* 462:468 */     boolean ok = false;
/* 463:    */     
/* 464:470 */     String sOK = (String)event.getValue();
/* 465:471 */     if ((sOK != null) && (sOK.equalsIgnoreCase("true"))) {
/* 466:472 */       ok = true;
/* 467:    */     }
/* 468:474 */     if (page.equalsIgnoreCase("WPMATERIAL"))
/* 469:    */     {
/* 470:476 */       databeanName = "WPALLMATERIALS";
/* 471:477 */       showsummarized = allflagsBean.getMobileMbo(0).getBooleanValue("SHOWMATSUMMARIZE");
/* 472:    */     }
/* 473:479 */     else if (page.equalsIgnoreCase("WPTOOL"))
/* 474:    */     {
/* 475:481 */       databeanName = "WPALLTOOLS";
/* 476:482 */       showsummarized = allflagsBean.getMobileMbo(0).getBooleanValue("SHOWTOOLSUMMARIZE");
/* 477:    */     }
/* 478:484 */     MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager(databeanName);
/* 479:485 */     MobileMboDataBean allPlansBean = mgrDBMgr.getDataBean();
/* 480:    */     
/* 481:    */ 
/* 482:488 */     MobileDeviceAppSession deviceAppSession = MobileDeviceAppSession.getSession();
/* 483:489 */     AbstractMobileDeviceApplication app = deviceAppSession.getApplication();
/* 484:490 */     MobileMboDataFormatter formatter = app.getMobileMboDataFormatter();
/* 485:492 */     if (showsummarized)
/* 486:    */     {
/* 487:495 */       allPlansBean.getQBE().setQbeExactMatch(true);
/* 488:496 */       allPlansBean.getQBE().setQBE("SUMMARYROW", "0");
/* 489:497 */       allPlansBean.getQBE().setQBE("SUMMARYROWID", tableBean.getValue("SUMMARYROWID"));
/* 490:498 */       int count = allPlansBean.count();
/* 491:499 */       StringBuffer sbPlanIds = new StringBuffer();
/* 492:500 */       for (int b = 0; b < count; b++)
/* 493:    */       {
/* 494:502 */         allPlansBean.getMobileMbo(b).setBooleanValue("OK", ok);
/* 495:    */         
/* 496:    */ 
/* 497:505 */         String unformattedId = formatter.formatDisplayToInternal(allPlansBean.getMobileMbo(b).getValue("_ID"), allPlansBean.getMobileMboInfo().getAttributeInfo("_ID"));
/* 498:509 */         if (sbPlanIds.length() > 0) {
/* 499:510 */           sbPlanIds.append(",");
/* 500:    */         }
/* 501:511 */         sbPlanIds.append(unformattedId);
/* 502:    */       }
/* 503:513 */       planIds = sbPlanIds.toString();
/* 504:514 */       allPlansBean.getDataBeanManager().save();
/* 505:    */     }
/* 506:    */     else
/* 507:    */     {
/* 508:519 */       planIds = tableBean.getValue("_ID");
/* 509:    */       
/* 510:    */ 
/* 511:522 */       String summarizedRowId = tableBean.getValue("SUMMARYROWID");
/* 512:523 */       allPlansBean.getQBE().setQbeExactMatch(true);
/* 513:524 */       allPlansBean.getQBE().setQBE("SUMMARYROW", "1");
/* 514:525 */       allPlansBean.getQBE().setQBE("SUMMARYROWID", summarizedRowId);
/* 515:526 */       if (allPlansBean.getMobileMbo(0) != null) {
/* 516:528 */         if (!ok)
/* 517:    */         {
/* 518:531 */           allPlansBean.getMobileMbo(0).setBooleanValue("OK", false);
/* 519:    */         }
/* 520:    */         else
/* 521:    */         {
/* 522:537 */           boolean allrowschecked = true;
/* 523:538 */           int count = tableBean.count();
/* 524:539 */           for (int b = 0; b < count; b++) {
/* 525:542 */             if (tableBean.getMobileMbo(b).getValue("SUMMARYROWID").equals(summarizedRowId)) {
/* 526:546 */               if (!tableBean.getMobileMbo(b).getValue("_ID").equals(tableBean.getValue("_ID"))) {
/* 527:549 */                 if (!tableBean.getMobileMbo(b).getBooleanValue("OK"))
/* 528:    */                 {
/* 529:551 */                   allrowschecked = false;
/* 530:552 */                   break;
/* 531:    */                 }
/* 532:    */               }
/* 533:    */             }
/* 534:    */           }
/* 535:555 */           allPlansBean.getMobileMbo(0).setBooleanValue("OK", allrowschecked);
/* 536:    */           
/* 537:    */ 
/* 538:558 */           String unformattedId = formatter.formatDisplayToInternal(allPlansBean.getMobileMbo(0).getValue("_ID"), allPlansBean.getMobileMboInfo().getAttributeInfo("_ID"));
/* 539:562 */           if (!planIds.equals("")) {
/* 540:563 */             planIds = planIds + ";";
/* 541:    */           }
/* 542:564 */           planIds = planIds + unformattedId;
/* 543:    */         }
/* 544:    */       }
/* 545:    */     }
/* 546:568 */     allPlansBean.getDataBeanManager().save();
/* 547:    */     
/* 548:    */ 
/* 549:571 */     mgrDBMgr = new MobileMboDataBeanManager(page);
/* 550:572 */     MobileMboDataBean planBean = mgrDBMgr.getDataBean();
/* 551:573 */     planBean.getQBE().setQBE("_ID", planIds);
/* 552:574 */     int count = planBean.count();
/* 553:575 */     for (int i = 0; i < count; i++) {
/* 554:579 */       planBean.getMobileMbo(i).setBooleanValue("OK", ok, false);
/* 555:    */     }
/* 556:581 */     planBean.getDataBeanManager().save();
/* 557:    */     
/* 558:583 */     return true;
/* 559:    */   }
/* 560:    */   
/* 561:    */   public boolean matShowAll(UIEvent event)
/* 562:    */     throws MobileApplicationException
/* 563:    */   {
/* 564:588 */     return showLink(event, "WPMATERIAL", true);
/* 565:    */   }
/* 566:    */   
/* 567:    */   public boolean toolShowAll(UIEvent event)
/* 568:    */     throws MobileApplicationException
/* 569:    */   {
/* 570:593 */     return showLink(event, "WPTOOL", true);
/* 571:    */   }
/* 572:    */   
/* 573:    */   public boolean matShowSummary(UIEvent event)
/* 574:    */     throws MobileApplicationException
/* 575:    */   {
/* 576:598 */     return showLink(event, "WPMATERIAL", false);
/* 577:    */   }
/* 578:    */   
/* 579:    */   public boolean toolShowSummary(UIEvent event)
/* 580:    */     throws MobileApplicationException
/* 581:    */   {
/* 582:603 */     return showLink(event, "WPTOOL", false);
/* 583:    */   }
/* 584:    */   
/* 585:    */   public boolean showLink(UIEvent event, String page, boolean bFromShowAll)
/* 586:    */     throws MobileApplicationException
/* 587:    */   {
/* 588:608 */     MobileMboDataBean allflagsBean = WOApp.getWpAllFlags();
/* 589:609 */     if (allflagsBean == null) {
/* 590:609 */       return true;
/* 591:    */     }
/* 592:611 */     boolean showsummarized = true;
/* 593:612 */     if (page.equalsIgnoreCase("WPMATERIAL")) {
/* 594:614 */       showsummarized = allflagsBean.getMobileMbo(0).getBooleanValue("SHOWMATSUMMARIZE");
/* 595:616 */     } else if (page.equalsIgnoreCase("WPTOOL")) {
/* 596:618 */       showsummarized = allflagsBean.getMobileMbo(0).getBooleanValue("SHOWTOOLSUMMARIZE");
/* 597:    */     }
/* 598:621 */     if (bFromShowAll) {
/* 599:622 */       ((AbstractMobileControl)event.getCreatingObject()).setVisibility(!showsummarized);
/* 600:    */     } else {
/* 601:624 */       ((AbstractMobileControl)event.getCreatingObject()).setVisibility(showsummarized);
/* 602:    */     }
/* 603:626 */     return true;
/* 604:    */   }
/* 605:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.mobilewo.WOAllPlanEventHandler
 * JD-Core Version:    0.7.0.1
 */