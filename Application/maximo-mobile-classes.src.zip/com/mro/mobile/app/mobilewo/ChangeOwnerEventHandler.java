/*   1:    */ package com.mro.mobile.app.mobilewo;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.mbo.MobileMbo;
/*   5:    */ import com.mro.mobile.mbo.MobileMboQBE;
/*   6:    */ import com.mro.mobile.ui.DataBeanCache;
/*   7:    */ import com.mro.mobile.ui.DataBeanCacheItem;
/*   8:    */ import com.mro.mobile.ui.MobileMboDataBean;
/*   9:    */ import com.mro.mobile.ui.MobileMboDataBeanManager;
/*  10:    */ import com.mro.mobile.ui.event.UIEvent;
/*  11:    */ import com.mro.mobile.ui.res.UIUtil;
/*  12:    */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*  13:    */ import com.mro.mobile.ui.res.controls.PageControl;
/*  14:    */ import com.mro.mobile.ui.res.controls.TabControl;
/*  15:    */ import com.mro.mobile.ui.res.controls.TabGroupControl;
/*  16:    */ import com.mro.mobileapp.WOApp;
/*  17:    */ import java.util.Calendar;
/*  18:    */ import java.util.Date;
/*  19:    */ 
/*  20:    */ public class ChangeOwnerEventHandler
/*  21:    */   extends MobileWOCommonEventHandler
/*  22:    */ {
/*  23:    */   public boolean performEvent(UIEvent event)
/*  24:    */     throws MobileApplicationException
/*  25:    */   {
/*  26: 37 */     if (event == null) {
/*  27: 37 */       return false;
/*  28:    */     }
/*  29: 39 */     String eventId = event.getEventName();
/*  30: 41 */     if (eventId.equalsIgnoreCase("select")) {
/*  31: 43 */       return select(event);
/*  32:    */     }
/*  33: 45 */     if (eventId.equalsIgnoreCase("canitakeownership")) {
/*  34: 47 */       return canitakeownership(event);
/*  35:    */     }
/*  36: 49 */     if (eventId.equalsIgnoreCase("takeownership")) {
/*  37: 51 */       return takeownership(event);
/*  38:    */     }
/*  39: 54 */     super.performEvent(event);
/*  40:    */     
/*  41: 56 */     return false;
/*  42:    */   }
/*  43:    */   
/*  44:    */   public boolean select(UIEvent event)
/*  45:    */     throws MobileApplicationException
/*  46:    */   {
/*  47: 61 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/*  48: 62 */     MobileMboDataBean wodatabean = ((PageControl)UIUtil.getCurrentScreen()).getLaunchingControl().getDataBean();
/*  49: 64 */     if ((wodatabean != null) && (wodatabean.getName().equals("WORKLIST"))) {
/*  50: 67 */       wodatabean = ((MobileWOAppEventHandler)UIUtil.getAppEventHandler()).setWorklistRecordBean(event, wodatabean);
/*  51:    */     }
/*  52: 70 */     if (UIUtil.checkESignature(event, wodatabean, "OWNASSIGN"))
/*  53:    */     {
/*  54: 72 */       TabGroupControl tgc = UIUtil.getTabGroup(UIUtil.getCurrentScreen());
/*  55: 73 */       if (tgc != null)
/*  56:    */       {
/*  57: 75 */         String sCurrentTab = tgc.getCurrentTab().getId();
/*  58: 76 */         databean = tgc.getCurrentTab().getDataBean();
/*  59: 78 */         if (databean.getName().equalsIgnoreCase("PERSONS"))
/*  60:    */         {
/*  61: 80 */           wodatabean.setValue("OWNER", databean.getValue("PERSONID"));
/*  62: 81 */           wodatabean.setValue("NEWOWNER", databean.getValue("PERSONID"));
/*  63: 82 */           wodatabean.setValue("OWNERGROUP", "");
/*  64: 83 */           wodatabean.setValue("NEWOWNERGROUP", "");
/*  65:    */         }
/*  66:    */         else
/*  67:    */         {
/*  68: 87 */           wodatabean.setValue("OWNER", "");
/*  69: 88 */           wodatabean.setValue("NEWOWNER", "");
/*  70: 89 */           wodatabean.setValue("OWNERGROUP", databean.getValue("PERSONGROUP"));
/*  71: 90 */           wodatabean.setValue("NEWOWNERGROUP", databean.getValue("PERSONGROUP"));
/*  72:    */         }
/*  73: 93 */         wodatabean.getDataBeanManager().save();
/*  74: 96 */         if (wodatabean.getName().equals("WORKORDER")) {
/*  75: 98 */           insertWoOwnerHistory(databean, wodatabean);
/*  76:100 */         } else if (wodatabean.getName().equals("TICKET")) {
/*  77:102 */           insertTkOwnerHistory(databean, wodatabean);
/*  78:    */         }
/*  79:    */       }
/*  80:107 */       UIUtil.cancelPage();
/*  81:    */     }
/*  82:    */     else
/*  83:    */     {
/*  84:111 */       event.setEventErrored();
/*  85:    */     }
/*  86:114 */     return true;
/*  87:    */   }
/*  88:    */   
/*  89:    */   private void insertTkOwnerHistory(MobileMboDataBean databean, MobileMboDataBean tkdatabean)
/*  90:    */     throws MobileApplicationException
/*  91:    */   {
/*  92:123 */     MobileMboDataBean histbean = tkdatabean.getDataBean("TKOWNERHISTORY");
/*  93:124 */     String mobileMboName = "TKOWNERHISTORY";
/*  94:125 */     String dataSrc = "TKOWNERHISTORY";
/*  95:126 */     if (histbean != null)
/*  96:    */     {
/*  97:128 */       DataBeanCacheItem item = new DataBeanCacheItem(dataSrc, tkdatabean.getName(), mobileMboName, histbean);
/*  98:129 */       DataBeanCache.cacheDataBean(dataSrc, item);
/*  99:    */     }
/* 100:132 */     if (histbean != null)
/* 101:    */     {
/* 102:137 */       Date ownDate = databean.getCurrentTime();
/* 103:138 */       processSameMinuteEntry(histbean, ownDate);
/* 104:    */       
/* 105:140 */       histbean.insert();
/* 106:141 */       if (databean.getName().equalsIgnoreCase("PERSONS"))
/* 107:    */       {
/* 108:143 */         histbean.setValue("OWNER", databean.getValue("PERSONID"));
/* 109:    */         
/* 110:    */ 
/* 111:    */ 
/* 112:147 */         histbean.setValue("OWNERGROUP", "DUMMY");
/* 113:148 */         histbean.setValue("OWNERGROUP", "");
/* 114:    */       }
/* 115:    */       else
/* 116:    */       {
/* 117:152 */         histbean.setValue("OWNERGROUP", databean.getValue("PERSONGROUP"));
/* 118:    */         
/* 119:154 */         histbean.setValue("OWNER", "DUMMY");
/* 120:155 */         histbean.setValue("OWNER", "");
/* 121:    */       }
/* 122:159 */       histbean.getMobileMbo().setDateValue("OWNDATE", ownDate);
/* 123:160 */       histbean.setValue("CLASS", tkdatabean.getMobileMbo().getValue("CLASS"));
/* 124:161 */       histbean.setValue("ORGID", tkdatabean.getMobileMbo().getValue("ORGID"));
/* 125:162 */       histbean.setValue("SITEID", tkdatabean.getMobileMbo().getValue("SITEID"));
/* 126:163 */       histbean.setValue("OWNERCHANGEBY", WOApp.getUsersPersonId());
/* 127:164 */       histbean.setValue("_PARENTID", tkdatabean.getMobileMbo().getValue("_ID"));
/* 128:165 */       histbean.setValue("TICKETID", tkdatabean.getMobileMbo().getValue("TICKETID"));
/* 129:166 */       histbean.getDataBeanManager().save();
/* 130:    */     }
/* 131:    */   }
/* 132:    */   
/* 133:    */   private void insertWoOwnerHistory(MobileMboDataBean databean, MobileMboDataBean wodatabean)
/* 134:    */     throws MobileApplicationException
/* 135:    */   {
/* 136:178 */     MobileMboDataBean histbean = wodatabean.getDataBean("WOOWNERHISTORY");
/* 137:179 */     String mobileMboName = "WOOWNERHISTORY";
/* 138:180 */     String dataSrc = "WOOWNERHISTORY";
/* 139:181 */     if (histbean != null)
/* 140:    */     {
/* 141:183 */       DataBeanCacheItem item = new DataBeanCacheItem(dataSrc, wodatabean.getName(), mobileMboName, histbean);
/* 142:184 */       DataBeanCache.cacheDataBean(dataSrc, item);
/* 143:    */     }
/* 144:186 */     if (histbean != null)
/* 145:    */     {
/* 146:189 */       Date ownDate = databean.getCurrentTime();
/* 147:190 */       processSameMinuteEntry(histbean, ownDate);
/* 148:    */       
/* 149:192 */       histbean.insert();
/* 150:193 */       if (databean.getName().equalsIgnoreCase("PERSONS"))
/* 151:    */       {
/* 152:195 */         histbean.setValue("OWNER", databean.getValue("PERSONID"));
/* 153:    */         
/* 154:    */ 
/* 155:    */ 
/* 156:199 */         histbean.setValue("OWNERGROUP", "DUMMY");
/* 157:200 */         histbean.setValue("OWNERGROUP", "");
/* 158:    */       }
/* 159:    */       else
/* 160:    */       {
/* 161:204 */         histbean.setValue("OWNERGROUP", databean.getValue("PERSONGROUP"));
/* 162:    */         
/* 163:206 */         histbean.setValue("OWNER", "DUMMY");
/* 164:207 */         histbean.setValue("OWNER", "");
/* 165:    */       }
/* 166:211 */       histbean.getMobileMbo().setDateValue("OWNDATE", ownDate);
/* 167:212 */       histbean.setValue("WOCLASS", wodatabean.getMobileMbo().getValue("WOCLASS"));
/* 168:213 */       histbean.setValue("ORGID", wodatabean.getMobileMbo().getValue("ORGID"));
/* 169:214 */       histbean.setValue("SITEID", wodatabean.getMobileMbo().getValue("SITEID"));
/* 170:215 */       histbean.setValue("OWNERCHANGEBY", WOApp.getUsersPersonId());
/* 171:216 */       histbean.setValue("_PARENTID", wodatabean.getMobileMbo().getValue("_ID"));
/* 172:217 */       histbean.getDataBeanManager().save();
/* 173:    */     }
/* 174:    */   }
/* 175:    */   
/* 176:    */   private void insertTkOwnerHistoryTakeOwnership(MobileMboDataBean personBean, MobileMboDataBean tkdatabean)
/* 177:    */     throws MobileApplicationException
/* 178:    */   {
/* 179:230 */     MobileMboDataBean histbean = tkdatabean.getDataBean("TKOWNERHISTORY");
/* 180:231 */     String mobileMboName = "TKOWNERHISTORY";
/* 181:232 */     String dataSrc = "TKOWNERHISTORY";
/* 182:233 */     if (histbean != null)
/* 183:    */     {
/* 184:235 */       DataBeanCacheItem item = new DataBeanCacheItem(dataSrc, tkdatabean.getName(), mobileMboName, histbean);
/* 185:236 */       DataBeanCache.cacheDataBean(dataSrc, item);
/* 186:    */     }
/* 187:239 */     if (histbean != null)
/* 188:    */     {
/* 189:242 */       Date ownDate = personBean.getCurrentTime();
/* 190:243 */       processSameMinuteEntry(histbean, ownDate);
/* 191:244 */       histbean.insert();
/* 192:245 */       if (personBean.getMobileMbo(0).getName().equalsIgnoreCase("PERSON"))
/* 193:    */       {
/* 194:247 */         histbean.setValue("OWNER", personBean.getMobileMbo(0).getValue("PERSONID"));
/* 195:    */         
/* 196:    */ 
/* 197:    */ 
/* 198:251 */         histbean.setValue("OWNERGROUP", "DUMMY");
/* 199:252 */         histbean.setValue("OWNERGROUP", "");
/* 200:    */       }
/* 201:255 */       histbean.getMobileMbo().setDateValue("OWNDATE", ownDate);
/* 202:256 */       histbean.setValue("CLASS", tkdatabean.getMobileMbo().getValue("CLASS"));
/* 203:257 */       histbean.setValue("ORGID", tkdatabean.getMobileMbo().getValue("ORGID"));
/* 204:258 */       histbean.setValue("SITEID", tkdatabean.getMobileMbo().getValue("SITEID"));
/* 205:259 */       histbean.setValue("OWNERCHANGEBY", WOApp.getUsersPersonId());
/* 206:260 */       histbean.setValue("_PARENTID", tkdatabean.getMobileMbo().getValue("_ID"));
/* 207:261 */       histbean.setValue("TICKETID", tkdatabean.getMobileMbo().getValue("TICKETID"));
/* 208:262 */       histbean.getDataBeanManager().save();
/* 209:    */     }
/* 210:    */   }
/* 211:    */   
/* 212:    */   private void insertWoOwnerHistoryTakeOwnership(MobileMboDataBean personBean, MobileMboDataBean wodatabean)
/* 213:    */     throws MobileApplicationException
/* 214:    */   {
/* 215:271 */     MobileMboDataBean histbean = DataBeanCache.getDataBean("WOOWNERHISTORY", "WOOWNERHISTORY");
/* 216:272 */     if (histbean != null)
/* 217:    */     {
/* 218:275 */       Date ownDate = personBean.getCurrentTime();
/* 219:276 */       processSameMinuteEntry(histbean, ownDate);
/* 220:    */       
/* 221:278 */       histbean.insert();
/* 222:279 */       if (personBean.getMobileMbo(0).getName().equalsIgnoreCase("PERSON"))
/* 223:    */       {
/* 224:281 */         histbean.setValue("OWNER", personBean.getMobileMbo(0).getValue("PERSONID"));
/* 225:    */         
/* 226:    */ 
/* 227:    */ 
/* 228:285 */         histbean.setValue("OWNERGROUP", "DUMMY");
/* 229:286 */         histbean.setValue("OWNERGROUP", "");
/* 230:    */       }
/* 231:290 */       histbean.getMobileMbo().setDateValue("OWNDATE", ownDate);
/* 232:291 */       histbean.setValue("WOCLASS", wodatabean.getMobileMbo().getValue("WOCLASS"));
/* 233:292 */       histbean.setValue("ORGID", wodatabean.getMobileMbo().getValue("ORGID"));
/* 234:293 */       histbean.setValue("SITEID", wodatabean.getMobileMbo().getValue("SITEID"));
/* 235:294 */       histbean.setValue("OWNERCHANGEBY", WOApp.getUsersPersonId());
/* 236:295 */       histbean.setValue("_PARENTID", wodatabean.getMobileMbo().getValue("_ID"));
/* 237:296 */       histbean.getDataBeanManager().save();
/* 238:    */     }
/* 239:    */   }
/* 240:    */   
/* 241:    */   private void processSameMinuteEntry(MobileMboDataBean histbean, Date ownDate)
/* 242:    */     throws MobileApplicationException
/* 243:    */   {
/* 244:310 */     int i = 0;
/* 245:312 */     if (histbean.isFiltered())
/* 246:    */     {
/* 247:314 */       histbean.getQBE().reset();
/* 248:315 */       histbean.reset();
/* 249:    */     }
/* 250:318 */     MobileMbo mobileMbo = histbean.getMobileMbo(i);
/* 251:319 */     boolean needToContinue = false;
/* 252:320 */     while (mobileMbo != null)
/* 253:    */     {
/* 254:322 */       needToContinue = false;
/* 255:324 */       if (mobileMbo.isNew())
/* 256:    */       {
/* 257:326 */         Date existingDate = mobileMbo.getDateValue("OWNDATE");
/* 258:327 */         long timeDiff = existingDate.getTime() - ownDate.getTime();
/* 259:329 */         if (timeDiff <= 60000L)
/* 260:    */         {
/* 261:332 */           Calendar exCal = Calendar.getInstance();
/* 262:333 */           exCal.setTime(existingDate);
/* 263:    */           
/* 264:335 */           Calendar curCal = Calendar.getInstance();
/* 265:336 */           curCal.setTime(ownDate);
/* 266:338 */           if (exCal.get(12) == curCal.get(12))
/* 267:    */           {
/* 268:340 */             needToContinue = true;
/* 269:341 */             existingDate.setTime(existingDate.getTime() - 60000L);
/* 270:342 */             mobileMbo.setDateValue("OWNDATE", existingDate, false);
/* 271:    */             
/* 272:344 */             ownDate = existingDate;
/* 273:    */           }
/* 274:    */         }
/* 275:    */       }
/* 276:350 */       if (!needToContinue) {
/* 277:352 */         return;
/* 278:    */       }
/* 279:354 */       mobileMbo = histbean.getMobileMbo(++i);
/* 280:    */     }
/* 281:    */   }
/* 282:    */   
/* 283:    */   public boolean canitakeownership(UIEvent event)
/* 284:    */     throws MobileApplicationException
/* 285:    */   {
/* 286:360 */     MobileMboDataBean wodatabean = ((PageControl)UIUtil.getCurrentScreen()).getLaunchingControl().getDataBean();
/* 287:362 */     if ((wodatabean != null) && (wodatabean.getName().equals("WORKLIST"))) {
/* 288:365 */       wodatabean = ((MobileWOAppEventHandler)UIUtil.getAppEventHandler()).setWorklistRecordBean(event, wodatabean);
/* 289:    */     }
/* 290:368 */     boolean bShow = true;
/* 291:370 */     if (!wodatabean.getValue("OWNER").equals(""))
/* 292:    */     {
/* 293:373 */       MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager("PERSON");
/* 294:374 */       MobileMboDataBean personBean = mgrDBMgr.getDataBean();
/* 295:375 */       personBean.getQBE().reset();
/* 296:376 */       if (wodatabean.getValue("OWNER").equalsIgnoreCase(personBean.getMobileMbo(0).getValue("PERSONID"))) {
/* 297:377 */         bShow = false;
/* 298:    */       }
/* 299:    */     }
/* 300:379 */     ((AbstractMobileControl)event.getCreatingObject()).setVisibility(bShow);
/* 301:380 */     return true;
/* 302:    */   }
/* 303:    */   
/* 304:    */   public boolean takeownership(UIEvent event)
/* 305:    */     throws MobileApplicationException
/* 306:    */   {
/* 307:385 */     MobileMboDataBean wodatabean = ((PageControl)UIUtil.getCurrentScreen()).getLaunchingControl().getDataBean();
/* 308:387 */     if (UIUtil.checkESignature(event, wodatabean, "OWNASSIGN"))
/* 309:    */     {
/* 310:389 */       if ((wodatabean != null) && (wodatabean.getName().equals("WORKLIST"))) {
/* 311:392 */         wodatabean = ((MobileWOAppEventHandler)UIUtil.getAppEventHandler()).setWorklistRecordBean(event, wodatabean);
/* 312:    */       }
/* 313:396 */       MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager("PERSON");
/* 314:397 */       MobileMboDataBean personBean = mgrDBMgr.getDataBean();
/* 315:398 */       personBean.getQBE().reset();
/* 316:    */       
/* 317:    */ 
/* 318:401 */       wodatabean.setValue("OWNERGROUP", "");
/* 319:402 */       wodatabean.setValue("NEWOWNERGROUP", "");
/* 320:    */       
/* 321:    */ 
/* 322:405 */       wodatabean.setValue("OWNER", personBean.getMobileMbo(0).getValue("PERSONID"));
/* 323:406 */       wodatabean.setValue("NEWOWNER", personBean.getMobileMbo(0).getValue("PERSONID"));
/* 324:407 */       wodatabean.getDataBeanManager().save();
/* 325:410 */       if (wodatabean.getName().equals("WORKORDER")) {
/* 326:412 */         insertWoOwnerHistoryTakeOwnership(personBean, wodatabean);
/* 327:414 */       } else if (wodatabean.getName().equals("TICKET")) {
/* 328:416 */         insertTkOwnerHistoryTakeOwnership(personBean, wodatabean);
/* 329:    */       }
/* 330:420 */       UIUtil.cancelPage();
/* 331:    */     }
/* 332:    */     else
/* 333:    */     {
/* 334:424 */       event.setEventErrored();
/* 335:    */     }
/* 336:427 */     return true;
/* 337:    */   }
/* 338:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.mobilewo.ChangeOwnerEventHandler
 * JD-Core Version:    0.7.0.1
 */