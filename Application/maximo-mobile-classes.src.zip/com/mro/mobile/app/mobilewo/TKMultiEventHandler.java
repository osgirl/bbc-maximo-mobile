/*   1:    */ package com.mro.mobile.app.mobilewo;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.ui.event.UIEvent;
/*   5:    */ 
/*   6:    */ public class TKMultiEventHandler
/*   7:    */   extends MobileWOCommonEventHandler
/*   8:    */ {
/*   9: 38 */   private MultiAssetLocCIUGenericHandler multiHandler = null;
/*  10:    */   
/*  11:    */   public TKMultiEventHandler()
/*  12:    */   {
/*  13: 42 */     this.multiHandler = new MultiAssetLocCIUGenericHandler();
/*  14: 43 */     this.multiHandler.setMasterDataBean("TICKET");
/*  15: 44 */     this.multiHandler.setMultiBean("TKMULTIASSETLOCCI");
/*  16: 45 */     this.multiHandler.setCachedMultiBean("TKMULTI");
/*  17: 46 */     this.multiHandler.setRecordKeySourceField("TICKETID");
/*  18: 47 */     this.multiHandler.setRecordClassSourceField("CLASS");
/*  19: 48 */     this.multiHandler.setDetailsPage("tkmulti_details");
/*  20:    */   }
/*  21:    */   
/*  22:    */   public boolean performEvent(UIEvent event)
/*  23:    */     throws MobileApplicationException
/*  24:    */   {
/*  25: 53 */     if (event == null) {
/*  26: 53 */       return false;
/*  27:    */     }
/*  28: 55 */     String eventId = event.getEventName();
/*  29: 57 */     if (eventId.equalsIgnoreCase("insertmulti")) {
/*  30: 59 */       return this.multiHandler.insertmulti(event);
/*  31:    */     }
/*  32: 61 */     if (eventId.equalsIgnoreCase("refreshmultitable")) {
/*  33: 63 */       return this.multiHandler.refreshmultitable(event);
/*  34:    */     }
/*  35: 65 */     if (eventId.equalsIgnoreCase("assetchanged")) {
/*  36: 67 */       return this.multiHandler.assetchanged(event);
/*  37:    */     }
/*  38: 76 */     if (eventId.equalsIgnoreCase("checkchangedvalues")) {
/*  39: 78 */       return this.multiHandler.checkchangedvalues(event);
/*  40:    */     }
/*  41: 80 */     if (eventId.equalsIgnoreCase("validateMulti")) {
/*  42: 82 */       return this.multiHandler.validateMulti(event);
/*  43:    */     }
/*  44: 84 */     if (eventId.equalsIgnoreCase("deletemulti")) {
/*  45: 86 */       return this.multiHandler.deletemulti(event);
/*  46:    */     }
/*  47: 88 */     if (eventId.equalsIgnoreCase("candeletemulti")) {
/*  48: 90 */       return this.multiHandler.candeletemulti(event);
/*  49:    */     }
/*  50: 92 */     if (eventId.equalsIgnoreCase("locationchanged")) {
/*  51: 94 */       return this.multiHandler.locationchanged(event);
/*  52:    */     }
/*  53: 96 */     if (eventId.equalsIgnoreCase("cichanged")) {
/*  54: 98 */       return this.multiHandler.cichanged(event);
/*  55:    */     }
/*  56:100 */     if (eventId.equalsIgnoreCase("setActualProgressField")) {
/*  57:102 */       return this.multiHandler.setActualProgressField(event);
/*  58:    */     }
/*  59:110 */     return false;
/*  60:    */   }
/*  61:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.mobilewo.TKMultiEventHandler
 * JD-Core Version:    0.7.0.1
 */