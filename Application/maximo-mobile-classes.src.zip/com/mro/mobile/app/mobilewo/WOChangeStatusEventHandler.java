/*   1:    */ package com.mro.mobile.app.mobilewo;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.MobileMessageGenerator;
/*   5:    */ import com.mro.mobile.ProgressObserver;
/*   6:    */ import com.mro.mobile.app.BasicMobileDeviceUIApplication;
/*   7:    */ import com.mro.mobile.app.CurrentTimeProvider;
/*   8:    */ import com.mro.mobile.app.async.AsyncEventHandlerSupport;
/*   9:    */ import com.mro.mobile.app.pluscmobwo.PlusCMobUtil;
/*  10:    */ import com.mro.mobile.mbo.MobileMbo;
/*  11:    */ import com.mro.mobile.mbo.MobileMboInfo;
/*  12:    */ import com.mro.mobile.mbo.MobileMboQBE;
/*  13:    */ import com.mro.mobile.persist.RDO;
/*  14:    */ import com.mro.mobile.ui.DataBeanCache;
/*  15:    */ import com.mro.mobile.ui.MobileMboDataBean;
/*  16:    */ import com.mro.mobile.ui.MobileMboDataBeanManager;
/*  17:    */ import com.mro.mobile.ui.MobileUIControlData;
/*  18:    */ import com.mro.mobile.ui.event.UIEvent;
/*  19:    */ import com.mro.mobile.ui.res.UIUtil;
/*  20:    */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*  21:    */ import com.mro.mobile.ui.res.controls.PageControl;
/*  22:    */ import com.mro.mobileapp.WOApp;
/*  23:    */ import java.net.ConnectException;
/*  24:    */ import java.util.Date;
/*  25:    */ 
/*  26:    */ public class WOChangeStatusEventHandler
/*  27:    */   extends MobileWOCommonEventHandler
/*  28:    */ {
/*  29: 40 */   private boolean mobileMboModified = false;
/*  30:    */   
/*  31:    */   public boolean performEvent(UIEvent event)
/*  32:    */     throws MobileApplicationException
/*  33:    */   {
/*  34: 44 */     if (event == null) {
/*  35: 44 */       return false;
/*  36:    */     }
/*  37: 46 */     String eventId = event.getEventName();
/*  38: 48 */     if (eventId.equalsIgnoreCase("initpage")) {
/*  39: 50 */       return initpage(event);
/*  40:    */     }
/*  41: 52 */     if (eventId.equalsIgnoreCase("validatepage")) {
/*  42: 54 */       return validatepage(event, UIUtil.getCurrentScreen().getDataBean());
/*  43:    */     }
/*  44: 56 */     if (eventId.equalsIgnoreCase("saveclose")) {
/*  45: 58 */       return saveclose((PageControl)UIUtil.getCurrentScreen(), event, UIUtil.getCurrentScreen().getDataBean(), true, false, null);
/*  46:    */     }
/*  47: 60 */     if (eventId.equalsIgnoreCase("cancelpage"))
/*  48:    */     {
/*  49: 62 */       this.mobileMboModified = false;
/*  50:    */     }
/*  51:    */     else
/*  52:    */     {
/*  53: 64 */       if (eventId.equalsIgnoreCase("candisplaywonum")) {
/*  54: 65 */         return candisplaywonum(event);
/*  55:    */       }
/*  56: 68 */       if (eventId.equalsIgnoreCase("cancelwotaskpage")) {
/*  57: 70 */         return cancelwotaskpage(event);
/*  58:    */       }
/*  59:    */     }
/*  60: 72 */     super.performEvent(event);
/*  61:    */     
/*  62: 74 */     return false;
/*  63:    */   }
/*  64:    */   
/*  65:    */   private boolean cancelwotaskpage(UIEvent event)
/*  66:    */     throws MobileApplicationException
/*  67:    */   {
/*  68: 80 */     MobileMboDataBean taskDataBean = ((PageControl)UIUtil.getCurrentScreen()).getLaunchingControl().getDataBean();
/*  69: 81 */     MobileMboDataBean taskStatusHistDataBean = DataBeanCache.getDataBean("WOTASKSTATUSHIST", "WOTASKSTATUSHIST");
/*  70: 83 */     if (taskStatusHistDataBean.getModifiedCount() == 0) {
/*  71: 84 */       taskDataBean.getMobileMbo().restoreOriginal();
/*  72: 86 */     } else if (taskDataBean != null) {
/*  73: 87 */       taskDataBean.getDataBeanManager().cancel();
/*  74:    */     }
/*  75: 91 */     UIUtil.closePage();
/*  76: 92 */     return true;
/*  77:    */   }
/*  78:    */   
/*  79:    */   private boolean saveclose(PageControl page, UIEvent event, final MobileMboDataBean databean, final boolean closePage, final boolean startNewTimer, final UIEvent refEvent)
/*  80:    */     throws MobileApplicationException
/*  81:    */   {
/*  82: 98 */     if ((page != null) && 
/*  83: 99 */       (!page.checkRequiredFields()))
/*  84:    */     {
/*  85:100 */       event.setEventErrored();
/*  86:101 */       return true;
/*  87:    */     }
/*  88:105 */     if (!checkEsig(databean, event))
/*  89:    */     {
/*  90:107 */       event.setEventErrored();
/*  91:108 */       return true;
/*  92:    */     }
/*  93:111 */     if (isRealTimeStatusChange(databean, databean.getCurrentPosition()))
/*  94:    */     {
/*  95:112 */       new AsyncEventHandlerSupport()
/*  96:    */       {
/*  97:    */         public boolean doRealWok(UIEvent event)
/*  98:    */           throws MobileApplicationException
/*  99:    */         {
/* 100:114 */           event.getProgressObserver().setWorkProgressMessage(MobileMessageGenerator.generate("sendingstatus", null));
/* 101:115 */           event.getProgressObserver().updateWorkProgress();
/* 102:116 */           WOChangeStatusEventHandler.this.doRealTimeStatusChange(databean, databean.getCurrentPosition(), event);
/* 103:117 */           return true;
/* 104:    */         }
/* 105:    */         
/* 106:    */         public void postRealWork(UIEvent event)
/* 107:    */           throws MobileApplicationException
/* 108:    */         {
/* 109:121 */           if (event.getException() != null) {
/* 110:122 */             UIUtil.showExceptionMessage(event.getException(), null, 0);
/* 111:    */           }
/* 112:125 */           databean.getDataBeanManager().save();
/* 113:126 */           if (closePage) {
/* 114:128 */             UIUtil.closePage();
/* 115:    */           } else {
/* 116:130 */             UIUtil.refreshCurrentScreen();
/* 117:    */           }
/* 118:132 */           if (startNewTimer) {
/* 119:133 */             ((MobileWOAppEventHandler)UIUtil.getAppEventHandler()).starttimer(refEvent);
/* 120:    */           }
/* 121:    */         }
/* 122:    */         
/* 123:    */         protected void realWorkFailed(UIEvent event)
/* 124:    */           throws MobileApplicationException
/* 125:    */         {
/* 126:138 */           UIUtil.showExceptionMessage(event.getException(), null, 0);
/* 127:139 */           databean.getDataBeanManager().save();
/* 128:140 */           if (closePage) {
/* 129:142 */             UIUtil.closePage();
/* 130:    */           } else {
/* 131:144 */             UIUtil.refreshCurrentScreen();
/* 132:    */           }
/* 133:146 */           if (startNewTimer) {
/* 134:147 */             ((MobileWOAppEventHandler)UIUtil.getAppEventHandler()).starttimer(refEvent);
/* 135:    */           }
/* 136:    */         }
/* 137:147 */       }.handleInBackground(event);
/* 138:    */     }
/* 139:    */     else
/* 140:    */     {
/* 141:152 */       validatepage(event, databean);
/* 142:153 */       databean.getDataBeanManager().save();
/* 143:154 */       if (closePage) {
/* 144:156 */         UIUtil.closePage();
/* 145:    */       } else {
/* 146:158 */         UIUtil.refreshCurrentScreen();
/* 147:    */       }
/* 148:160 */       if (startNewTimer)
/* 149:    */       {
/* 150:161 */         ((MobileWOAppEventHandler)UIUtil.getAppEventHandler()).starttimer(refEvent);
/* 151:162 */         if (!event.hasPassedESig()) {
/* 152:163 */           UIUtil.getApplication().removeCurrentScreen(false);
/* 153:    */         }
/* 154:    */       }
/* 155:    */     }
/* 156:167 */     return true;
/* 157:    */   }
/* 158:    */   
/* 159:    */   public boolean initpage(UIEvent event)
/* 160:    */     throws MobileApplicationException
/* 161:    */   {
/* 162:172 */     MobileMboDataBean databean = ((PageControl)event.getCreatingObject()).getDataBean();
/* 163:173 */     this.mobileMboModified = databean.isMobileMboModified();
/* 164:    */     
/* 165:175 */     databean.getMobileMbo().setValue("NEWSTATUSDISPLAY", "");
/* 166:176 */     databean.getMobileMbo().setValue("NEWSTATUSMEMO", "");
/* 167:177 */     databean.getMobileMbo().setDateValue("NEWSTATUSASOFDATE", databean.getCurrentTime());
/* 168:    */     
/* 169:179 */     return true;
/* 170:    */   }
/* 171:    */   
/* 172:    */   public boolean candisplaywonum(UIEvent event)
/* 173:    */     throws MobileApplicationException
/* 174:    */   {
/* 175:184 */     MobileMboDataBean woTaskBean = UIUtil.getCurrentScreen().getDataBean();
/* 176:    */     
/* 177:    */ 
/* 178:187 */     MobileMboDataBean woBean = woTaskBean.getParentBean();
/* 179:189 */     if (woBean != null) {
/* 180:190 */       ((AbstractMobileControl)event.getCreatingObject()).setVisibility(!woBean.getMobileMbo().isNew());
/* 181:    */     }
/* 182:192 */     return true;
/* 183:    */   }
/* 184:    */   
/* 185:    */   public boolean validatepage(UIEvent event, MobileMboDataBean refDataBean)
/* 186:    */     throws MobileApplicationException
/* 187:    */   {
/* 188:197 */     return validatepage(event, true, refDataBean);
/* 189:    */   }
/* 190:    */   
/* 191:    */   protected void doRealTimeStatusChange(MobileMboDataBean databean, int pos, UIEvent event)
/* 192:    */     throws MobileApplicationException
/* 193:    */   {
/* 194:202 */     BasicMobileDeviceUIApplication app = UIUtil.getApplication();
/* 195:203 */     MobileWOWebServiceProxy service = (MobileWOWebServiceProxy)app.getDefaultMobileWebServiceProxy();
/* 196:204 */     MobileMbo mobileMbo = databean.getMobileMbo(pos);
/* 197:205 */     event.getProgressObserver().updateWorkProgress();
/* 198:    */     
/* 199:    */ 
/* 200:208 */     event.getProgressObserver().setWorkProgressMessage(MobileMessageGenerator.generate("connectingserver", null));
/* 201:    */     try
/* 202:    */     {
/* 203:210 */       service.changeWOStatus(mobileMbo.getValue("WONUM"), mobileMbo.getValue("SITEID"), mobileMbo.getValue("STATUS"), mobileMbo.getValue("NEWSTATUSDISPLAY"), mobileMbo.getDateValue("NEWSTATUSASOFDATE"), mobileMbo.getValue("NEWSTATUSMEMO"));
/* 204:    */       
/* 205:    */ 
/* 206:    */ 
/* 207:    */ 
/* 208:    */ 
/* 209:    */ 
/* 210:217 */       validatepage(event, false, databean);
/* 211:218 */       event.getProgressObserver().updateWorkProgress();
/* 212:    */       
/* 213:220 */       event.getProgressObserver().setWorkProgressMessage(MobileMessageGenerator.generate("sendstatuscompl", null));
/* 214:221 */       event.setThreadStatus(2);
/* 215:    */       
/* 216:223 */       cleanupLocalStatusChangeValues(mobileMbo);
/* 217:    */       
/* 218:    */ 
/* 219:226 */       cleanupLocalStatusChangeValuesForDepedendent(databean.getDataBean("WOCHILDREN"));
/* 220:229 */       if (!this.mobileMboModified) {
/* 221:230 */         mobileMbo.getRDO().setBooleanValue("_MODIFIED", false);
/* 222:    */       }
/* 223:232 */       event.setThreadStatus(2);
/* 224:    */     }
/* 225:    */     catch (MobileApplicationException e)
/* 226:    */     {
/* 227:234 */       if (isConnectException(e))
/* 228:    */       {
/* 229:235 */         queuePendingStatusChange(mobileMbo);
/* 230:    */         
/* 231:237 */         validatepage(event, true, databean);
/* 232:    */       }
/* 233:240 */       else if (!this.mobileMboModified)
/* 234:    */       {
/* 235:241 */         mobileMbo.getRDO().setBooleanValue("_MODIFIED", false);
/* 236:    */       }
/* 237:244 */       generateErrorMessage(event, e);
/* 238:    */     }
/* 239:    */   }
/* 240:    */   
/* 241:    */   private void cleanupLocalStatusChangeValuesForDepedendent(MobileMboDataBean dataBean)
/* 242:    */     throws MobileApplicationException
/* 243:    */   {
/* 244:251 */     if (dataBean != null) {
/* 245:252 */       for (int i = 0; i < dataBean.count(); i++) {
/* 246:253 */         cleanupLocalStatusChangeValues(dataBean.getMobileMbo(i));
/* 247:    */       }
/* 248:    */     }
/* 249:    */   }
/* 250:    */   
/* 251:    */   private void cleanupLocalStatusChangeValues(MobileMbo mobileMbo)
/* 252:    */     throws MobileApplicationException
/* 253:    */   {
/* 254:261 */     mobileMbo.changeOriginalValue("STATUS", mobileMbo.getValue("NEWSTATUSDISPLAY"));
/* 255:262 */     mobileMbo.changeOriginalDateValue("STATUSDATE", mobileMbo.getDateValue("NEWSTATUSASOFDATE"));
/* 256:263 */     mobileMbo.setValue("NEWSTATUS", "");
/* 257:    */   }
/* 258:    */   
/* 259:    */   private boolean isConnectException(MobileApplicationException e)
/* 260:    */   {
/* 261:269 */     return e.getNestedException() instanceof ConnectException;
/* 262:    */   }
/* 263:    */   
/* 264:    */   private void generateErrorMessage(UIEvent event, MobileApplicationException e)
/* 265:    */   {
/* 266:275 */     StringBuffer buf = new StringBuffer(MobileMessageGenerator.generate("errorsendingstatus", null));
/* 267:276 */     buf.append(":\n");
/* 268:277 */     buf.append(e.getCompleteMessage());
/* 269:278 */     MobileApplicationException exception = new MobileApplicationException(buf.toString(), e);
/* 270:279 */     event.setException(exception);
/* 271:    */   }
/* 272:    */   
/* 273:    */   private void queuePendingStatusChange(MobileMbo mobileMbo)
/* 274:    */     throws MobileApplicationException
/* 275:    */   {
/* 276:285 */     MobileMboDataBeanManager mngr = new MobileMboDataBeanManager("PENDINGCHGSTATUS");
/* 277:286 */     MobileMboDataBean pendingQueue = mngr.getDataBean();
/* 278:287 */     pendingQueue.insert();
/* 279:288 */     pendingQueue.setValue("WONUM", mobileMbo.getValue("WONUM"));
/* 280:289 */     pendingQueue.setValue("SITEID", mobileMbo.getValue("SITEID"));
/* 281:290 */     pendingQueue.setValue("CURRENTSTATUS", mobileMbo.getValue("STATUS"));
/* 282:291 */     pendingQueue.setValue("NEWSTATUS", mobileMbo.getValue("NEWSTATUSDISPLAY"));
/* 283:292 */     pendingQueue.getMobileMbo().setDateValue("STATUSDATE", mobileMbo.getDateValue("NEWSTATUSASOFDATE"));
/* 284:293 */     pendingQueue.setValue("MEMO", mobileMbo.getValue("NEWSTATUSMEMO"));
/* 285:294 */     pendingQueue.setValue("MOBMBONAME", mobileMbo.getValue("WOCLASS"));
/* 286:295 */     mngr.save();
/* 287:    */   }
/* 288:    */   
/* 289:    */   private boolean validatepage(UIEvent event, boolean generateHistory, MobileMboDataBean databean)
/* 290:    */     throws MobileApplicationException
/* 291:    */   {
/* 292:301 */     String statusBeanName = "WOSTATUSHIST";
/* 293:302 */     if (databean.getName().equalsIgnoreCase("WOTASKS")) {
/* 294:304 */       statusBeanName = "WOTASKSTATUSHIST";
/* 295:307 */     } else if (databean.getName().equalsIgnoreCase("WOACTIVITY")) {
/* 296:309 */       statusBeanName = "WOACTSTATUSHIST";
/* 297:    */     }
/* 298:312 */     if (!databean.getValue("NEWSTATUSDISPLAY").equals(""))
/* 299:    */     {
/* 300:314 */       databean.setValue("STATUS", databean.getValue("NEWSTATUSDISPLAY"), false);
/* 301:315 */       databean.setValue("NEWSTATUS", databean.getValue("NEWSTATUSDISPLAY"));
/* 302:316 */       MobileMbo wo = databean.getMobileMbo();
/* 303:318 */       if (isInprogStatus(databean)) {
/* 304:320 */         if ((wo.getMobileMboInfo().getAttributeInfo("ACTSTART") != null) && (wo.isNull("ACTSTART"))) {
/* 305:321 */           wo.setDateValue("ACTSTART", wo.getDateValue("NEWSTATUSASOFDATE"));
/* 306:    */         }
/* 307:    */       }
/* 308:326 */       if (isInprogStatus(databean)) {
/* 309:328 */         if ((wo.getMobileMboInfo().getAttributeInfo("ACTSTART") != null) && (wo.isNull("ACTSTART"))) {
/* 310:329 */           wo.setDateValue("ACTSTART", wo.getDateValue("NEWSTATUSASOFDATE"));
/* 311:    */         }
/* 312:    */       }
/* 313:334 */       if (isCompleteStatus(databean))
/* 314:    */       {
/* 315:337 */         Date[] labTransDates = getWOLabTransDates(databean.getDataBean("WOLABTRANS"));
/* 316:338 */         Date start = labTransDates[0];
/* 317:339 */         Date finish = labTransDates[1];
/* 318:340 */         if ((start != null) && (wo.getMobileMboInfo().getAttributeInfo("ACTSTART") != null))
/* 319:    */         {
/* 320:342 */           Date currentStart = wo.getDateValue("ACTSTART");
/* 321:343 */           if ((currentStart == null) || (currentStart.after(start))) {
/* 322:345 */             wo.setDateValue("ACTSTART", start);
/* 323:    */           }
/* 324:    */         }
/* 325:348 */         if (wo.getMobileMboInfo().getAttributeInfo("ACTFINISH") != null) {
/* 326:350 */           if (finish == null) {
/* 327:352 */             wo.setDateValue("ACTFINISH", wo.getDateValue("NEWSTATUSASOFDATE"));
/* 328:    */           } else {
/* 329:357 */             wo.setDateValue("ACTFINISH", finish);
/* 330:    */           }
/* 331:    */         }
/* 332:    */       }
/* 333:362 */       if (generateHistory)
/* 334:    */       {
/* 335:364 */         MobileMboDataBean histbean = databean.getDataBean(statusBeanName);
/* 336:365 */         if (histbean != null)
/* 337:    */         {
/* 338:367 */           histbean.insert();
/* 339:    */           
/* 340:369 */           histbean.setValue("CHANGEBY", WOApp.getUserId());
/* 341:370 */           histbean.getMobileMbo().setDateValue("CHANGEDATE", wo.getDateValue("NEWSTATUSASOFDATE"));
/* 342:371 */           histbean.setValue("ORGID", databean.getValue("ORGID"));
/* 343:372 */           histbean.setValue("SITEID", databean.getValue("SITEID"));
/* 344:373 */           histbean.setValue("STATUS", databean.getValue("NEWSTATUSDISPLAY"));
/* 345:374 */           histbean.setValue("MEMO", databean.getValue("NEWSTATUSMEMO"));
/* 346:    */         }
/* 347:    */       }
/* 348:378 */       if (statusBeanName.equals("WOSTATUSHIST"))
/* 349:    */       {
/* 350:381 */         MobileMboDataBean taskdatabean = databean.getDataBean("WOTASKS");
/* 351:382 */         int count = taskdatabean.count();
/* 352:383 */         for (int i = 0; i < count; i++) {
/* 353:385 */           if (taskdatabean.getValue(i, "PARENTCHGSSTATUS").equalsIgnoreCase("1"))
/* 354:    */           {
/* 355:387 */             String maxStatus = ((WOApp)UIUtil.getApplication()).getInternalValue(taskdatabean, "WOSTATUS", taskdatabean.getValue(i, "STATUS"));
/* 356:392 */             if ((!maxStatus.equals("COMP")) && (!maxStatus.equals("CLOSE")) && (!maxStatus.equals("CAN")) && (!maxStatus.equalsIgnoreCase(databean.getValue("NEWSTATUSDISPLAY")))) {
/* 357:399 */               if ((!maxStatus.equals("INPRG")) || (!((WOApp)UIUtil.getApplication()).getInternalValue(databean, "WOSTATUS", databean.getValue("NEWSTATUSDISPLAY")).equals("APPR")))
/* 358:    */               {
/* 359:404 */                 taskdatabean.setValue(i, "STATUS", databean.getValue("NEWSTATUSDISPLAY"), false);
/* 360:405 */                 taskdatabean.setValue(i, "NEWSTATUS", databean.getValue("NEWSTATUSDISPLAY"));
/* 361:    */                 
/* 362:    */ 
/* 363:    */ 
/* 364:409 */                 taskdatabean.getMobileMbo(i).setDateValue("NEWSTATUSASOFDATE", databean.getMobileMbo().getDateValue("NEWSTATUSASOFDATE"));
/* 365:412 */                 if (generateHistory)
/* 366:    */                 {
/* 367:416 */                   MobileMboDataBean histtaskbean = taskdatabean.getDataBean(i, "WOTASKSTATUSHIST");
/* 368:417 */                   if (histtaskbean != null)
/* 369:    */                   {
/* 370:419 */                     histtaskbean.insert();
/* 371:420 */                     histtaskbean.setValue("CHANGEBY", WOApp.getUsersPersonId());
/* 372:421 */                     histtaskbean.getMobileMbo().setDateValue("CHANGEDATE", taskdatabean.getMobileMbo().getDateValue("NEWSTATUSASOFDATE"));
/* 373:422 */                     histtaskbean.setValue("ORGID", taskdatabean.getValue("ORGID"));
/* 374:423 */                     histtaskbean.setValue("SITEID", taskdatabean.getValue("SITEID"));
/* 375:424 */                     histtaskbean.setValue("STATUS", databean.getValue("NEWSTATUSDISPLAY"));
/* 376:425 */                     histtaskbean.setValue("MEMO", databean.getValue("NEWSTATUSMEMO"));
/* 377:    */                   }
/* 378:    */                 }
/* 379:    */               }
/* 380:    */             }
/* 381:    */           }
/* 382:    */         }
/* 383:    */       }
/* 384:    */     }
/* 385:435 */     String intStatus = ((WOApp)UIUtil.getApplication()).getInternalValue(databean, "WOSTATUS", databean.getValue("NEWSTATUSDISPLAY"));
/* 386:438 */     if (("WORKORDER".equalsIgnoreCase(databean.getName())) && ("APPR".equals(intStatus)))
/* 387:    */     {
/* 388:439 */       MobileMboDataBeanManager mgr = new MobileMboDataBeanManager("PLUSCWODSPOINT");
/* 389:440 */       MobileMboDataBean calPointDataBean = mgr.getDataBean();
/* 390:    */       
/* 391:442 */       calPointDataBean.getQBE().setQBE("ORGID", databean.getValue("ORGID"));
/* 392:443 */       calPointDataBean.getQBE().setQBE("SITEID", databean.getValue("SITEID"));
/* 393:444 */       calPointDataBean.getQBE().setQBE("WONUM", databean.getValue("WONUM"));
/* 394:    */       
/* 395:446 */       calPointDataBean.reset();
/* 396:    */       
/* 397:448 */       String[] namesToRemoveReadOnly = { "ASFOUNDINPUT", "ASLEFTINPUT", "ASFOUNDOUTPUT", "ASLEFTOUTPUT", "ASFOUNDSETPOINT", "ASLEFTSETPOINT", "SETPOINTACTION", "SETPOINTVALUE" };
/* 398:    */       
/* 399:    */ 
/* 400:    */ 
/* 401:    */ 
/* 402:    */ 
/* 403:    */ 
/* 404:    */ 
/* 405:    */ 
/* 406:    */ 
/* 407:458 */       int count = calPointDataBean.count();
/* 408:459 */       for (int i = 0; i < count; i++) {
/* 409:460 */         PlusCMobUtil.setMobileMboAttrInfoFieldsReadOnly(calPointDataBean.getMobileMbo(i), namesToRemoveReadOnly, false, false);
/* 410:    */       }
/* 411:    */     }
/* 412:464 */     return false;
/* 413:    */   }
/* 414:    */   
/* 415:    */   protected static boolean isInprogStatus(MobileMboDataBean databean)
/* 416:    */     throws MobileApplicationException
/* 417:    */   {
/* 418:469 */     String maxStatus = ((WOApp)UIUtil.getApplication()).getInternalValue(databean, "WOSTATUS", databean.getValue("STATUS"));
/* 419:470 */     return "INPRG".equals(maxStatus);
/* 420:    */   }
/* 421:    */   
/* 422:    */   protected static boolean isCompleteStatus(MobileMboDataBean databean)
/* 423:    */     throws MobileApplicationException
/* 424:    */   {
/* 425:476 */     String maxStatus = ((WOApp)UIUtil.getApplication()).getInternalValue(databean, "WOSTATUS", databean.getValue("STATUS"));
/* 426:477 */     return "COMP".equals(maxStatus);
/* 427:    */   }
/* 428:    */   
/* 429:    */   protected static boolean isApprStatus(MobileMboDataBean databean)
/* 430:    */     throws MobileApplicationException
/* 431:    */   {
/* 432:481 */     String maxStatus = ((WOApp)UIUtil.getApplication()).getInternalValue(databean, "WOSTATUS", databean.getValue("STATUS"));
/* 433:482 */     return "APPR".equals(maxStatus);
/* 434:    */   }
/* 435:    */   
/* 436:    */   private Date[] getWOLabTransDates(MobileMboDataBean woLabTrans)
/* 437:    */     throws MobileApplicationException
/* 438:    */   {
/* 439:487 */     Date earliest = null;
/* 440:488 */     Date latest = null;
/* 441:489 */     if (woLabTrans != null)
/* 442:    */     {
/* 443:491 */       int count = woLabTrans.count();
/* 444:492 */       if (count > 0)
/* 445:    */       {
/* 446:494 */         woLabTrans.getMobileMbo(count);
/* 447:495 */         for (int i = 0; i < count; i++)
/* 448:    */         {
/* 449:497 */           woLabTrans.setCurrentPosition(i);
/* 450:    */           
/* 451:499 */           woLabTrans.setValue("STARTDATETIME", woLabTrans.getValue("STARTDATE") + " " + woLabTrans.getValue("STARTTIME"));
/* 452:500 */           Date startDate = woLabTrans.getMobileMbo(i).getDateValue("STARTDATETIME");
/* 453:501 */           if ((earliest == null) || (startDate.before(earliest))) {
/* 454:502 */             earliest = startDate;
/* 455:    */           }
/* 456:505 */           woLabTrans.setValue("FINISHDATETIME", woLabTrans.getValue("FINISHDATE") + " " + woLabTrans.getValue("FINISHTIME"));
/* 457:506 */           Date finishDate = woLabTrans.getMobileMbo(i).getDateValue("FINISHDATETIME");
/* 458:507 */           if ((latest == null) || (finishDate.after(latest))) {
/* 459:508 */             latest = finishDate;
/* 460:    */           }
/* 461:    */         }
/* 462:    */       }
/* 463:    */     }
/* 464:513 */     return new Date[] { earliest, latest };
/* 465:    */   }
/* 466:    */   
/* 467:    */   protected boolean isRealTimeStatusChange(MobileMboDataBean databean, int pos)
/* 468:    */     throws MobileApplicationException
/* 469:    */   {
/* 470:518 */     MobileMbo currentMbo = databean.getMobileMbo(pos);
/* 471:521 */     if ((currentMbo.isNew()) || ((!currentMbo.getName().equals("WORKORDER")) && (!currentMbo.getName().equals("WOACTIVITY")))) {
/* 472:522 */       return false;
/* 473:    */     }
/* 474:525 */     MobileMboDataBean userConfig = DataBeanCache.getDataBean("MOBREALSTATUSCFG", "MOBREALSTATUSCFG");
/* 475:    */     
/* 476:527 */     int count = userConfig.count();
/* 477:528 */     userConfig.dataExists(count);
/* 478:529 */     userConfig.close();
/* 479:    */     
/* 480:    */ 
/* 481:532 */     userConfig.indexMobileMboDataBean("MOBREALSTATUSCFG", new String[] { "DOMAINID", "VALUE", "CLASS" }, false);
/* 482:533 */     String internalClass = ((WOApp)UIUtil.getApplication()).getInternalValue(databean, "WOCLASS", currentMbo.getValue("WOCLASS"));
/* 483:534 */     String displayStatus = currentMbo.getValue("NEWSTATUSDISPLAY");
/* 484:    */     
/* 485:536 */     return userConfig.getIndexedMobileMbo("MOBREALSTATUSCFG", new String[] { "WOSTATUS", displayStatus, internalClass }) != null;
/* 486:    */   }
/* 487:    */   
/* 488:    */   private boolean checkEsig(MobileMboDataBean databean, UIEvent event)
/* 489:    */     throws MobileApplicationException
/* 490:    */   {
/* 491:553 */     WOStatusHandler woHandler = new WOStatusHandler((WOApp)UIUtil.getApplication(), databean);
/* 492:554 */     String newStatus = ((WOApp)UIUtil.getApplication()).getInternalValue(databean, "WOSTATUS", databean.getValue("NEWSTATUSDISPLAY"));
/* 493:555 */     String optionName = woHandler.getOptionName(newStatus);
/* 494:    */     
/* 495:557 */     return (event.hasPassedESig()) || (UIUtil.checkESignature(event, databean, optionName));
/* 496:    */   }
/* 497:    */   
/* 498:    */   protected void startWorkOrder(final MobileMboDataBean refDataBean, MobileMbo record, UIEvent refEvent)
/* 499:    */     throws MobileApplicationException
/* 500:    */   {
/* 501:562 */     this.mobileMboModified = true;
/* 502:    */     
/* 503:564 */     String externalInprog = ((WOApp)UIUtil.getApplication()).getExternalValue(refDataBean, "WOSTATUS", "INPRG");
/* 504:565 */     if (canChangeWorkOrderStatus(refDataBean, record.getValue("STATUS"), externalInprog))
/* 505:    */     {
/* 506:566 */       record.setDateValue("NEWSTATUSASOFDATE", CurrentTimeProvider.getInstance().getCurrentTime());
/* 507:567 */       record.setValue("NEWSTATUSDISPLAY", externalInprog);
/* 508:568 */       record.setValue("MEMO", "");
/* 509:569 */       PageControl fakePage = new PageControl()
/* 510:    */       {
/* 511:    */         protected boolean performEvent(UIEvent event)
/* 512:    */           throws MobileApplicationException
/* 513:    */         {
/* 514:571 */           WOChangeStatusEventHandler.this.mobileMboModified = true;
/* 515:572 */           if ((event != null) && (event.getEventName().equalsIgnoreCase("saveclose"))) {
/* 516:573 */             return WOChangeStatusEventHandler.this.saveclose(null, event, refDataBean, false, false, null);
/* 517:    */           }
/* 518:575 */           return false;
/* 519:    */         }
/* 520:577 */       };
/* 521:578 */       MobileUIControlData fakeData = new MobileUIControlData();
/* 522:579 */       fakeData.putValue("sigoption", "STATUS");
/* 523:580 */       fakeData.putValue("esigdatasrc", "$$_TEMP_ESIG_DS");
/* 524:581 */       DataBeanCache.cacheDataBean("$$_TEMP_ESIG_DS", refDataBean);
/* 525:582 */       fakePage.setControlData(fakeData);
/* 526:583 */       UIEvent event = new UIEvent(fakePage, "saveclose", null, "");
/* 527:    */       
/* 528:585 */       event.setPassedESig(refEvent.hasPassedESig());
/* 529:586 */       saveclose(null, event, refDataBean, false, false, null);
/* 530:    */     }
/* 531:    */   }
/* 532:    */   
/* 533:    */   protected void completeWorkOrder(final MobileMboDataBean refDataBean, MobileMbo record, final boolean closeESigPage, final boolean startNewTimer, final UIEvent refEvent)
/* 534:    */     throws MobileApplicationException
/* 535:    */   {
/* 536:592 */     this.mobileMboModified = true;
/* 537:    */     
/* 538:594 */     String externalComp = ((WOApp)UIUtil.getApplication()).getExternalValue(refDataBean, "WOSTATUS", "COMP");
/* 539:595 */     if (canChangeWorkOrderStatus(refDataBean, record.getValue("STATUS"), externalComp))
/* 540:    */     {
/* 541:596 */       record.setDateValue("NEWSTATUSASOFDATE", CurrentTimeProvider.getInstance().getCurrentTime());
/* 542:597 */       record.setValue("NEWSTATUSDISPLAY", externalComp);
/* 543:598 */       record.setValue("MEMO", "");
/* 544:599 */       PageControl fakePage = new PageControl()
/* 545:    */       {
/* 546:    */         protected boolean performEvent(UIEvent event)
/* 547:    */           throws MobileApplicationException
/* 548:    */         {
/* 549:601 */           WOChangeStatusEventHandler.this.mobileMboModified = true;
/* 550:602 */           if ((event != null) && (event.getEventName().equalsIgnoreCase("saveclose"))) {
/* 551:603 */             return WOChangeStatusEventHandler.this.saveclose(null, event, refDataBean, closeESigPage, startNewTimer, refEvent);
/* 552:    */           }
/* 553:605 */           return false;
/* 554:    */         }
/* 555:607 */       };
/* 556:608 */       MobileUIControlData fakeData = new MobileUIControlData();
/* 557:609 */       fakeData.putValue("sigoption", "STATUS");
/* 558:610 */       fakeData.putValue("esigdatasrc", "$$_TEMP_ESIG_DS");
/* 559:611 */       DataBeanCache.cacheDataBean("$$_TEMP_ESIG_DS", refDataBean);
/* 560:612 */       fakePage.setControlData(fakeData);
/* 561:613 */       UIEvent event = new UIEvent(fakePage, "saveclose", null, "");
/* 562:    */       
/* 563:615 */       event.setPassedESig(refEvent.hasPassedESig());
/* 564:616 */       saveclose(null, event, refDataBean, closeESigPage, startNewTimer, refEvent);
/* 565:617 */       refEvent.setEventErrored(event.errorOccured());
/* 566:    */     }
/* 567:    */   }
/* 568:    */   
/* 569:    */   private boolean canChangeWorkOrderStatus(MobileMboDataBean refDataBean, String currentExternalStatus, String desiredExternalStatus)
/* 570:    */     throws MobileApplicationException
/* 571:    */   {
/* 572:623 */     WOStatusHandler wostatushandler = new WOStatusHandler((WOApp)UIUtil.getApplication(), refDataBean);
/* 573:624 */     return wostatushandler.canChangeStatus(currentExternalStatus, desiredExternalStatus);
/* 574:    */   }
/* 575:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.mobilewo.WOChangeStatusEventHandler
 * JD-Core Version:    0.7.0.1
 */