package com.mro.mobile.app.mobilewo;

import com.mro.mobile.DefaultMobileWebService;
import com.mro.mobile.MobileApplicationException;
import com.mro.mobile.mbo.MobileMbo;
import com.mro.mobile.mbo.MobileMboChange;
import java.util.Date;

public abstract interface MobileWOWebService
  extends DefaultMobileWebService
{
  public abstract void performAction(String paramString, Long paramLong, MobileMbo paramMobileMbo)
    throws MobileApplicationException;
  
  public abstract void requestWork(MobileMbo paramMobileMbo)
    throws MobileApplicationException;
  
  public abstract void applyChanges(MobileMboChange paramMobileMboChange)
    throws MobileApplicationException;
  
  public abstract void createServiceRequest(MobileMboChange paramMobileMboChange)
    throws MobileApplicationException;
  
  public abstract void changeWOStatus(String paramString1, String paramString2, String paramString3, String paramString4, Date paramDate, String paramString5)
    throws MobileApplicationException;
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.mobilewo.MobileWOWebService
 * JD-Core Version:    0.7.0.1
 */