/*    1:     */ package com.mro.mobile.app.mobilewo;
/*    2:     */ 
/*    3:     */ import com.mro.mobile.MobileApplicationException;
/*    4:     */ import com.mro.mobile.MobileMessageGenerator;
/*    5:     */ import com.mro.mobile.app.BasicMobileDeviceUIApplication;
/*    6:     */ import com.mro.mobile.app.DefaultMobileMboDataFormatter;
/*    7:     */ import com.mro.mobile.mbo.MobileMbo;
/*    8:     */ import com.mro.mobile.mbo.MobileMboAttributeInfo;
/*    9:     */ import com.mro.mobile.mbo.MobileMboInfo;
/*   10:     */ import com.mro.mobile.mbo.MobileMboQBE;
/*   11:     */ import com.mro.mobile.persist.QBE;
/*   12:     */ import com.mro.mobile.ui.DataBeanCache;
/*   13:     */ import com.mro.mobile.ui.MobileMboDataBean;
/*   14:     */ import com.mro.mobile.ui.MobileMboDataBeanManager;
/*   15:     */ import com.mro.mobile.ui.event.UIEvent;
/*   16:     */ import com.mro.mobile.ui.res.ControlData;
/*   17:     */ import com.mro.mobile.ui.res.UIUtil;
/*   18:     */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*   19:     */ import com.mro.mobile.ui.res.controls.ButtonControl;
/*   20:     */ import com.mro.mobile.ui.res.controls.PageControl;
/*   21:     */ import com.mro.mobile.ui.res.controls.TableControl;
/*   22:     */ import com.mro.mobile.ui.res.controls.TextboxControl;
/*   23:     */ import com.mro.mobileapp.WOApp;
/*   24:     */ import java.util.Date;
/*   25:     */ 
/*   26:     */ public class WOEventHandler
/*   27:     */   extends MobileWOCommonEventHandler
/*   28:     */ {
/*   29:     */   public boolean performEvent(UIEvent event)
/*   30:     */     throws MobileApplicationException
/*   31:     */   {
/*   32:  42 */     if (event == null) {
/*   33:  42 */       return false;
/*   34:     */     }
/*   35:  44 */     String eventId = event.getEventName();
/*   36:  46 */     if (eventId.equalsIgnoreCase("initfailurereport")) {
/*   37:  48 */       return initfailurereport(event);
/*   38:     */     }
/*   39:  50 */     if (eventId.equalsIgnoreCase("defaultfailurereportremdate")) {
/*   40:  52 */       return defaultfailurereportremdate(event);
/*   41:     */     }
/*   42:  54 */     if (eventId.equalsIgnoreCase("clrfailrepfield")) {
/*   43:  56 */       return clrfailrepfield(event);
/*   44:     */     }
/*   45:  58 */     if (eventId.equalsIgnoreCase("failurecodechanged")) {
/*   46:  60 */       return failurecodechanged(event);
/*   47:     */     }
/*   48:  62 */     if (eventId.equalsIgnoreCase("initWODetails")) {
/*   49:  64 */       return initWODetails(event);
/*   50:     */     }
/*   51:  66 */     if (eventId.equalsIgnoreCase("refreshWODetails")) {
/*   52:  68 */       return refreshWODetails(event);
/*   53:     */     }
/*   54:  70 */     if (eventId.equalsIgnoreCase("assetchanged")) {
/*   55:  72 */       return assetchanged(event);
/*   56:     */     }
/*   57:  74 */     if (eventId.equalsIgnoreCase("locationchanged")) {
/*   58:  76 */       return locationchanged(event);
/*   59:     */     }
/*   60:  78 */     if (eventId.equalsIgnoreCase("cichanged")) {
/*   61:  80 */       return cichanged(event);
/*   62:     */     }
/*   63:  82 */     if (eventId.equalsIgnoreCase("inittaskdetails")) {
/*   64:  84 */       return inittaskdetails(event);
/*   65:     */     }
/*   66:  86 */     if (eventId.equalsIgnoreCase("validatemeasurepoint")) {
/*   67:  88 */       return validatemeasurepoint(event);
/*   68:     */     }
/*   69:  90 */     if (eventId.equalsIgnoreCase("validatemeasurement")) {
/*   70:  92 */       return validatemeasurement(event);
/*   71:     */     }
/*   72:  94 */     if (eventId.equalsIgnoreCase("save")) {
/*   73:  96 */       return save(event);
/*   74:     */     }
/*   75:  98 */     if (eventId.equalsIgnoreCase("validatetargstart")) {
/*   76: 100 */       return validatetargstart(event);
/*   77:     */     }
/*   78: 102 */     if (eventId.equalsIgnoreCase("validatetargend")) {
/*   79: 104 */       return validatetargend(event);
/*   80:     */     }
/*   81: 106 */     if (eventId.equalsIgnoreCase("validateschedstart")) {
/*   82: 108 */       return validateschedstart(event);
/*   83:     */     }
/*   84: 110 */     if (eventId.equalsIgnoreCase("validateschedend")) {
/*   85: 112 */       return validateschedend(event);
/*   86:     */     }
/*   87: 114 */     if (eventId.equalsIgnoreCase("validateactstart")) {
/*   88: 116 */       return validateactstart(event);
/*   89:     */     }
/*   90: 118 */     if (eventId.equalsIgnoreCase("validateactend")) {
/*   91: 120 */       return validateactend(event);
/*   92:     */     }
/*   93: 122 */     if (eventId.equalsIgnoreCase("initwocommlog")) {
/*   94: 124 */       return initwocommlog(event);
/*   95:     */     }
/*   96: 126 */     if (eventId.equalsIgnoreCase("initenterwoobservation")) {
/*   97: 128 */       return initenterwoobservation(event);
/*   98:     */     }
/*   99: 130 */     if (eventId.equalsIgnoreCase("filterworktype")) {
/*  100: 132 */       return filterworktype(event);
/*  101:     */     }
/*  102: 134 */     if (eventId.equalsIgnoreCase("canedittask")) {
/*  103: 136 */       return canedittask(event);
/*  104:     */     }
/*  105: 138 */     if (eventId.equalsIgnoreCase("validatewopriority")) {
/*  106: 140 */       return validatewopriority(event);
/*  107:     */     }
/*  108: 143 */     if (eventId.equalsIgnoreCase("showCIField")) {
/*  109: 145 */       return showCIField(event);
/*  110:     */     }
/*  111: 147 */     if (eventId.equalsIgnoreCase("showTargetDescField")) {
/*  112: 149 */       return showTargetDescField(event);
/*  113:     */     }
/*  114: 151 */     if (eventId.equalsIgnoreCase("displayMultiAsset")) {
/*  115: 153 */       return displayMultiAsset(event);
/*  116:     */     }
/*  117: 155 */     if (eventId.equalsIgnoreCase("toggleSwap")) {
/*  118: 157 */       return toggleSwap(event);
/*  119:     */     }
/*  120: 160 */     if (eventId.equalsIgnoreCase("validatescheddate")) {
/*  121: 162 */       return validatescheddate(event);
/*  122:     */     }
/*  123: 165 */     if (eventId.equalsIgnoreCase("validatetargetdate")) {
/*  124: 167 */       return validatetargetdate(event);
/*  125:     */     }
/*  126: 170 */     if (eventId.equalsIgnoreCase("isAssetReadOnlyBasedOnStatus")) {
/*  127: 172 */       return isReadOnlyBasedOnStatus(event, "EDITASSET");
/*  128:     */     }
/*  129: 175 */     if (eventId.equalsIgnoreCase("isLocReadOnlyBasedOnStatus")) {
/*  130: 177 */       return isReadOnlyBasedOnStatus(event, "EDITLOC");
/*  131:     */     }
/*  132: 180 */     if (eventId.equalsIgnoreCase("processChangeTaskStatus")) {
/*  133: 182 */       return processChangeTaskStatus(event);
/*  134:     */     }
/*  135: 185 */     if (eventId.equalsIgnoreCase("onLaborAssignmentChanged")) {
/*  136: 186 */       return onLaborAssignmentChanged(event);
/*  137:     */     }
/*  138: 189 */     super.performEvent(event);
/*  139:     */     
/*  140: 191 */     return false;
/*  141:     */   }
/*  142:     */   
/*  143:     */   protected boolean processChangeTaskStatus(UIEvent event)
/*  144:     */     throws MobileApplicationException
/*  145:     */   {
/*  146: 198 */     MobileMboDataBean taskDataBean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*  147: 199 */     if (taskDataBean.isToBeSaved())
/*  148:     */     {
/*  149: 201 */       UIUtil.showInfoMessageBox(MobileMessageGenerator.generate("UnsavedNoUsage", null));
/*  150: 202 */       return true;
/*  151:     */     }
/*  152: 205 */     UIUtil.gotoPage(event.getValue().toString(), (AbstractMobileControl)event.getCreatingObject());
/*  153: 206 */     return true;
/*  154:     */   }
/*  155:     */   
/*  156:     */   private boolean isReadOnlyBasedOnStatus(UIEvent event, String field)
/*  157:     */     throws MobileApplicationException
/*  158:     */   {
/*  159: 212 */     MobileMboDataBean wodatabean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*  160: 213 */     if (wodatabean != null)
/*  161:     */     {
/*  162: 215 */       WOApp app = (WOApp)UIUtil.getApplication();
/*  163: 216 */       String status = app.getInternalValue(wodatabean, "WOSTATUS", wodatabean.getValue("STATUS"));
/*  164: 217 */       String orgid = app.getDefaultInsertOrg();
/*  165: 218 */       MobileMboDataBean wpeditSettings = new MobileMboDataBeanManager("WPEDITSETTING").getDataBean();
/*  166: 219 */       wpeditSettings.getQBE().setQbeExactMatch(true);
/*  167: 220 */       wpeditSettings.getQBE().setQBE("STATUS", status);
/*  168: 221 */       wpeditSettings.getQBE().setQBE("ORGID", orgid);
/*  169: 222 */       wpeditSettings.reset();
/*  170: 223 */       MobileMbo conf = wpeditSettings.getMobileMbo();
/*  171: 224 */       if ((conf != null) && (!conf.getBooleanValue(field))) {
/*  172: 226 */         ((AbstractMobileControl)event.getCreatingObject()).setReadonly(true);
/*  173:     */       } else {
/*  174: 230 */         ((AbstractMobileControl)event.getCreatingObject()).setReadonly(false);
/*  175:     */       }
/*  176:     */     }
/*  177: 233 */     return true;
/*  178:     */   }
/*  179:     */   
/*  180:     */   private boolean validatescheddate(UIEvent event)
/*  181:     */     throws MobileApplicationException
/*  182:     */   {
/*  183: 241 */     MobileMboDataBean databean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*  184: 242 */     if (databean != null)
/*  185:     */     {
/*  186: 244 */       MobileMbo mbo = databean.getMobileMbo();
/*  187: 245 */       if (mbo != null)
/*  188:     */       {
/*  189: 247 */         Date schedStart = null;
/*  190: 248 */         Date schedFinish = null;
/*  191: 249 */         String datefield = ((AbstractMobileControl)event.getCreatingObject()).getValue("dataattribute");
/*  192: 250 */         if ("SCHEDSTART".equalsIgnoreCase(datefield))
/*  193:     */         {
/*  194: 252 */           schedStart = (Date)event.getValue();
/*  195: 253 */           schedFinish = mbo.getDateValue("SCHEDFINISH");
/*  196:     */         }
/*  197: 255 */         else if ("SCHEDFINISH".equalsIgnoreCase(datefield))
/*  198:     */         {
/*  199: 257 */           schedStart = mbo.getDateValue("SCHEDSTART");
/*  200: 258 */           schedFinish = (Date)event.getValue();
/*  201:     */         }
/*  202: 261 */         if ((schedStart == null) || (schedFinish == null)) {
/*  203: 263 */           return true;
/*  204:     */         }
/*  205: 267 */         if (schedStart.after(schedFinish))
/*  206:     */         {
/*  207: 269 */           event.setEventErrored();
/*  208: 270 */           databean.setValue(datefield.toUpperCase(), "");
/*  209: 271 */           UIUtil.showFailureMessageBox(MobileMessageGenerator.generate("startafterend", null));
/*  210: 272 */           UIUtil.refreshCurrentScreen();
/*  211: 273 */           return true;
/*  212:     */         }
/*  213:     */       }
/*  214:     */     }
/*  215: 277 */     return true;
/*  216:     */   }
/*  217:     */   
/*  218:     */   private boolean validatetargetdate(UIEvent event)
/*  219:     */     throws MobileApplicationException
/*  220:     */   {
/*  221: 285 */     MobileMboDataBean databean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*  222: 286 */     if (databean != null)
/*  223:     */     {
/*  224: 288 */       MobileMbo mbo = databean.getMobileMbo();
/*  225: 289 */       if (mbo != null)
/*  226:     */       {
/*  227: 291 */         Date schedStart = null;
/*  228: 292 */         Date schedFinish = null;
/*  229:     */         
/*  230: 294 */         String datefield = ((AbstractMobileControl)event.getCreatingObject()).getValue("dataattribute");
/*  231: 295 */         if ("TARGSTARTDATE".equalsIgnoreCase(datefield))
/*  232:     */         {
/*  233: 297 */           schedStart = (Date)event.getValue();
/*  234: 298 */           schedFinish = mbo.getDateValue("TARGCOMPDATE");
/*  235:     */         }
/*  236: 300 */         else if ("TARGCOMPDATE".equalsIgnoreCase(datefield))
/*  237:     */         {
/*  238: 302 */           schedStart = mbo.getDateValue("TARGSTARTDATE");
/*  239: 303 */           schedFinish = (Date)event.getValue();
/*  240:     */         }
/*  241: 306 */         if ((schedStart == null) || (schedFinish == null)) {
/*  242: 308 */           return true;
/*  243:     */         }
/*  244: 312 */         if (schedStart.after(schedFinish))
/*  245:     */         {
/*  246: 314 */           event.setEventErrored();
/*  247: 315 */           databean.setValue(datefield.toUpperCase(), "");
/*  248: 316 */           UIUtil.showFailureMessageBox(MobileMessageGenerator.generate("startafterend", null));
/*  249: 317 */           UIUtil.refreshCurrentScreen();
/*  250: 318 */           return true;
/*  251:     */         }
/*  252:     */       }
/*  253:     */     }
/*  254: 322 */     return true;
/*  255:     */   }
/*  256:     */   
/*  257:     */   public boolean initfailurereport(UIEvent event)
/*  258:     */     throws MobileApplicationException
/*  259:     */   {
/*  260: 328 */     return true;
/*  261:     */   }
/*  262:     */   
/*  263:     */   public boolean defaultfailurereportremdate(UIEvent event)
/*  264:     */     throws MobileApplicationException
/*  265:     */   {
/*  266: 334 */     MobileMboDataBean wodatabean = UIUtil.getCurrentScreen().getDataBean();
/*  267:     */     
/*  268:     */ 
/*  269: 337 */     WOFailCodeEventHandler failcodehandler = new WOFailCodeEventHandler();
/*  270: 338 */     failcodehandler.saveOriginalValues(wodatabean);
/*  271:     */     
/*  272: 340 */     wodatabean.setValue("FAILUREREPORTCHANGED", "1");
/*  273: 342 */     if (wodatabean.getValue("REMARKENTERDATE").equals("")) {
/*  274: 343 */       wodatabean.getMobileMbo().setDateValue("REMARKENTERDATE", wodatabean.getCurrentTime());
/*  275:     */     }
/*  276: 345 */     return true;
/*  277:     */   }
/*  278:     */   
/*  279:     */   public boolean failurecodechanged(UIEvent event)
/*  280:     */     throws MobileApplicationException
/*  281:     */   {
/*  282: 351 */     MobileMboDataBean wodatabean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*  283: 352 */     WOFailCodeEventHandler failcodehandler = new WOFailCodeEventHandler();
/*  284: 353 */     int ifieldoffset = 1;
/*  285:     */     
/*  286:     */ 
/*  287: 356 */     failcodehandler.saveOriginalValues(wodatabean);
/*  288:     */     
/*  289:     */ 
/*  290: 359 */     wodatabean.setValue("FAILUREREPORTCHANGED", "1");
/*  291: 362 */     for (int i = ifieldoffset; i <= failcodehandler.getFailRepLevels(wodatabean); i++)
/*  292:     */     {
/*  293: 364 */       wodatabean.setValue("FAILURECODE" + i, "");
/*  294: 365 */       wodatabean.setValue("FAILURECODE" + i + "_FAILURELIST", "");
/*  295: 366 */       wodatabean.setValue("FAILURECODE" + i + "_DISPLAY", "");
/*  296:     */     }
/*  297: 369 */     return true;
/*  298:     */   }
/*  299:     */   
/*  300:     */   public boolean clrfailrepfield(UIEvent event)
/*  301:     */     throws MobileApplicationException
/*  302:     */   {
/*  303: 376 */     MobileMboDataBean wodatabean = UIUtil.getCurrentScreen().getDataBean();
/*  304: 377 */     String launchingfield = ((TextboxControl)((PageControl)UIUtil.getCurrentScreen()).getCurrentInput()).getStringValue("dataattribute");
/*  305:     */     
/*  306:     */ 
/*  307: 380 */     WOFailCodeEventHandler failcodehandler = new WOFailCodeEventHandler();
/*  308:     */     
/*  309:     */ 
/*  310: 383 */     failcodehandler.saveOriginalValues(wodatabean);
/*  311:     */     
/*  312: 385 */     int ifieldoffset = 0;
/*  313: 386 */     if (!launchingfield.equals("FAILURECODE")) {
/*  314: 389 */       ifieldoffset = launchingfield.charAt(launchingfield.length() - 1) - '0';
/*  315:     */     }
/*  316: 392 */     if (ifieldoffset == 0)
/*  317:     */     {
/*  318: 395 */       wodatabean.setValue("FAILURECODE", "");
/*  319:     */       
/*  320: 397 */       ifieldoffset = 1;
/*  321:     */     }
/*  322: 401 */     wodatabean.setValue("FAILUREREPORTCHANGED", "1");
/*  323: 403 */     for (int i = ifieldoffset; i <= failcodehandler.getFailRepLevels(wodatabean); i++)
/*  324:     */     {
/*  325: 405 */       wodatabean.setValue("FAILURECODE" + i, "");
/*  326: 406 */       wodatabean.setValue("FAILURECODE" + i + "_FAILURELIST", "");
/*  327: 407 */       wodatabean.setValue("FAILURECODE" + i + "_DISPLAY", "");
/*  328:     */     }
/*  329: 410 */     wodatabean.getDataBeanManager().save();
/*  330: 411 */     UIUtil.refreshCurrentScreen();
/*  331:     */     
/*  332: 413 */     return true;
/*  333:     */   }
/*  334:     */   
/*  335:     */   public boolean initWODetails(UIEvent event)
/*  336:     */     throws MobileApplicationException
/*  337:     */   {
/*  338: 418 */     MobileMboDataBean wodatabean = ((PageControl)event.getCreatingObject()).getDataBean();
/*  339: 419 */     if ((wodatabean != null) && (wodatabean.getName().equals("WORKORDER")))
/*  340:     */     {
/*  341: 422 */       if (wodatabean.getValue("WONUM").equals("")) {
/*  342: 423 */         return true;
/*  343:     */       }
/*  344: 425 */       MobileMboDataBean attachments = wodatabean.getDataBean("WOATTACHMENTS");
/*  345:     */       
/*  346: 427 */       attachments.getQBE().reset();
/*  347: 428 */       attachments.reset();
/*  348: 429 */       wodatabean.setValue("ATTACHCOUNT", "" + attachments.count());
/*  349: 430 */       attachments.reset();
/*  350:     */     }
/*  351: 433 */     return true;
/*  352:     */   }
/*  353:     */   
/*  354:     */   public boolean showCIField(UIEvent event)
/*  355:     */     throws MobileApplicationException
/*  356:     */   {
/*  357: 438 */     MobileMboDataBean wodatabean = UIUtil.getCurrentScreen().getDataBean();
/*  358: 439 */     if ((wodatabean != null) && (wodatabean.getName().equals("WORKORDER")))
/*  359:     */     {
/*  360: 441 */       AbstractMobileControl ciField = (AbstractMobileControl)event.getCreatingObject();
/*  361:     */       
/*  362:     */ 
/*  363: 444 */       String clazz = ((WOApp)UIUtil.getApplication()).getInternalValue(wodatabean, "WOCLASS", wodatabean.getValue("WOCLASS"));
/*  364: 446 */       if ((clazz != null) && (clazz.equalsIgnoreCase("WORKORDER"))) {
/*  365: 447 */         ciField.setVisibility(false);
/*  366:     */       }
/*  367: 449 */       if (wodatabean.getMobileMboInfo().getAttributeInfo("ASSETNUM").isReadOnly() == true) {
/*  368: 451 */         ciField.setReadonly(true);
/*  369:     */       }
/*  370:     */     }
/*  371: 454 */     return true;
/*  372:     */   }
/*  373:     */   
/*  374:     */   public boolean showTargetDescField(UIEvent event)
/*  375:     */     throws MobileApplicationException
/*  376:     */   {
/*  377: 459 */     MobileMboDataBean wodatabean = UIUtil.getCurrentScreen().getDataBean();
/*  378: 460 */     if ((wodatabean != null) && (wodatabean.getName().equals("WORKORDER")))
/*  379:     */     {
/*  380: 462 */       AbstractMobileControl targetDescField = (AbstractMobileControl)event.getCreatingObject();
/*  381:     */       
/*  382:     */ 
/*  383: 465 */       String clazz = ((WOApp)UIUtil.getApplication()).getInternalValue(wodatabean, "WOCLASS", wodatabean.getValue("WOCLASS"));
/*  384: 466 */       if ((clazz != null) && (clazz.equalsIgnoreCase("WORKORDER"))) {
/*  385: 468 */         targetDescField.setVisibility(false);
/*  386:     */       }
/*  387: 471 */       String currentMaxStatus = ((WOApp)UIUtil.getApplication()).getInternalValue(wodatabean, "WOSTATUS", wodatabean.getValue("STATUS"));
/*  388: 473 */       if (currentMaxStatus.equalsIgnoreCase("CLOSE")) {
/*  389: 475 */         targetDescField.setReadonly(true);
/*  390:     */       }
/*  391:     */     }
/*  392: 478 */     return true;
/*  393:     */   }
/*  394:     */   
/*  395:     */   public boolean refreshWODetails(UIEvent event)
/*  396:     */     throws MobileApplicationException
/*  397:     */   {
/*  398: 483 */     MobileMboDataBean wodatabean = UIUtil.getCurrentScreen().getDataBean();
/*  399: 484 */     if ((wodatabean != null) && (wodatabean.getName().equals("WORKORDER")))
/*  400:     */     {
/*  401: 487 */       if (wodatabean.getValue("WONUM").equals("")) {
/*  402: 488 */         return true;
/*  403:     */       }
/*  404: 490 */       MobileMboDataBean attachments = wodatabean.getDataBean("WOATTACHMENTS");
/*  405:     */       
/*  406:     */ 
/*  407: 493 */       attachments.getQBE().reset();
/*  408: 494 */       attachments.reset();
/*  409: 495 */       wodatabean.setValue("ATTACHCOUNT", "" + attachments.count());
/*  410: 496 */       attachments.reset();
/*  411:     */     }
/*  412: 499 */     return true;
/*  413:     */   }
/*  414:     */   
/*  415:     */   public boolean assetchanged(UIEvent event)
/*  416:     */     throws MobileApplicationException
/*  417:     */   {
/*  418: 506 */     MobileMboDataBean databean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*  419: 510 */     if (databean != null) {
/*  420: 513 */       if ((event.getValue() != null) && (event.getValue().toString().length() > 0))
/*  421:     */       {
/*  422: 516 */         MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager("ASSET");
/*  423: 517 */         MobileMboDataBean assetBean = mgrDBMgr.getDataBean();
/*  424:     */         
/*  425: 519 */         assetBean.getQBE().setQbeExactMatch(true);
/*  426:     */         
/*  427: 521 */         assetBean.getQBE().setQBE("SITEID", databean.getValue("SITEID"));
/*  428: 522 */         assetBean.getQBE().setQBE("ASSETNUM", (String)event.getValue());
/*  429: 523 */         assetBean.reset();
/*  430: 524 */         int count = assetBean.count();
/*  431: 525 */         if (count == 1)
/*  432:     */         {
/*  433: 526 */           databean.setValue("PLUSCPHYLOC", assetBean.getMobileMbo(0).getValue("PLUSCPHYLOC"));
/*  434: 527 */           databean.setValue("PLUSCPHYLOC_LONGDESCRIPTION", assetBean.getMobileMbo(0).getValue("PLUSCPHYLOC_LONGDESCRIPTION"));
/*  435:     */         }
/*  436: 533 */         String newAsset = (String)event.getValue();
/*  437: 534 */         MobileMbo assetmbo = assetBean.getMobileMbo();
/*  438: 536 */         if (assetmbo != null)
/*  439:     */         {
/*  440: 538 */           databean.setValue("LOCATION", assetmbo.getValue("LOCATION"));
/*  441:     */           
/*  442:     */ 
/*  443: 541 */           WOFailCodeEventHandler failcodehandler = new WOFailCodeEventHandler();
/*  444: 542 */           failcodehandler.saveOriginalValues(databean);
/*  445: 546 */           if (!assetmbo.getValue("FAILURECODE").equals(""))
/*  446:     */           {
/*  447: 548 */             databean.setValue("FAILUREREPORTCHANGED", "1");
/*  448: 549 */             databean.setValue("FAILURECODE", assetmbo.getValue("FAILURECODE"));
/*  449:     */             
/*  450: 551 */             databean.setValue("FAILURELIST", assetmbo.getValue("FAILURELIST"));
/*  451:     */           }
/*  452: 558 */           databean.setValue("WARRANTYEXIST", assetmbo.getValue("WARRANTYEXISTS"), false);
/*  453: 559 */           if (assetmbo.getValue("WARRANTYEXISTS") == "1") {
/*  454: 561 */             UIUtil.showInfoMessageBox(MobileMessageGenerator.generate("assetunderwarranty", new Object[] { assetmbo.getValue("ASSETNUM") }));
/*  455:     */           } else {
/*  456: 565 */             databean.setValue("WARRANTYEXIST", "0", false);
/*  457:     */           }
/*  458: 569 */           MobileMboDataBean womultibean = databean.getDataBean("WOMULTIASSETLOCCI");
/*  459: 570 */           if (womultibean != null)
/*  460:     */           {
/*  461: 572 */             womultibean.getQBE().reset();
/*  462: 573 */             womultibean.getQBE().setQbeExactMatch(true);
/*  463: 574 */             womultibean.getQBE().setQBE("ISPRIMARY", "1");
/*  464: 575 */             womultibean.reset();
/*  465: 577 */             if (womultibean.count() == 1)
/*  466:     */             {
/*  467: 579 */               womultibean.setValue("ASSETNUM", newAsset);
/*  468:     */               
/*  469: 581 */               LinearAssetEventHandler.setMultiLinearFields(womultibean, assetmbo);
/*  470: 582 */               womultibean.getDataBeanManager().save();
/*  471:     */             }
/*  472:     */           }
/*  473:     */         }
/*  474:     */       }
/*  475:     */     }
/*  476: 588 */     return true;
/*  477:     */   }
/*  478:     */   
/*  479:     */   public boolean save(UIEvent event)
/*  480:     */     throws MobileApplicationException
/*  481:     */   {
/*  482: 594 */     String pageId = ((PageControl)event.getCreatingObject()).getId();
/*  483: 595 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/*  484: 596 */     if (pageId.equalsIgnoreCase("womain")) {
/*  485: 598 */       if (databean != null)
/*  486:     */       {
/*  487: 600 */         if ((databean.getMobileMbo() != null) && (databean.getMobileMbo().isToBeInserted()))
/*  488:     */         {
/*  489: 603 */           String insertsigoption = "INSERT,CREATEWO";
/*  490: 604 */           String woclass = ((WOApp)UIUtil.getApplication()).getInternalValue(databean, "WOCLASS", databean.getValue("WOCLASS"));
/*  491: 605 */           if (woclass.equals("CHANGE")) {
/*  492: 606 */             insertsigoption = "NEWCHNG,CREATECH";
/*  493:     */           }
/*  494: 607 */           if (woclass.equals("RELEASE")) {
/*  495: 608 */             insertsigoption = "NEWREL,CREATERE";
/*  496:     */           }
/*  497: 616 */           ((PageControl)UIUtil.getCurrentScreen()).getControlData().putValue("insertesigoption", insertsigoption);
/*  498:     */         }
/*  499: 621 */         MobileMboDataBean multiBean = databean.getDataBean("WOMULTIASSETLOCCI");
/*  500: 622 */         if ((multiBean != null) && (multiBean.isMobileMboModified())) {
/*  501: 624 */           multiBean.getDataBeanManager().save();
/*  502:     */         }
/*  503:     */       }
/*  504:     */     }
/*  505: 629 */     return false;
/*  506:     */   }
/*  507:     */   
/*  508:     */   public boolean inittaskdetails(UIEvent event)
/*  509:     */     throws MobileApplicationException
/*  510:     */   {
/*  511: 634 */     MobileMboDataBean databean = ((PageControl)event.getCreatingObject()).getDataBean();
/*  512: 635 */     if ((databean.getMobileMbo() != null) && (databean.getValue("POINTNUM").equals("")))
/*  513:     */     {
/*  514: 637 */       databean.getMobileMbo().setReadOnly("MEASUREMENTVALUE", true);
/*  515: 638 */       databean.getMobileMbo().setReadOnly("MEASUREDATE", true);
/*  516:     */     }
/*  517: 641 */     if ((databean.getMobileMbo() != null) && (databean.getMobileMbo().getLongValue("_ID") > 0L))
/*  518:     */     {
/*  519: 645 */       MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager("WORKORDER");
/*  520: 646 */       MobileMboDataBean woBean = mgrDBMgr.getDataBean();
/*  521: 647 */       woBean.getQBE().setQbeExactMatch(true);
/*  522: 648 */       woBean.getQBE().setQBE("_ID", "" + databean.getMobileMbo().getLongValue("_ID"));
/*  523: 649 */       if (woBean.getMobileMbo(0) != null) {
/*  524: 651 */         databean.getMobileMbo().setReadOnly(true);
/*  525:     */       }
/*  526:     */     }
/*  527: 655 */     return false;
/*  528:     */   }
/*  529:     */   
/*  530:     */   public boolean validatemeasurepoint(UIEvent event)
/*  531:     */     throws MobileApplicationException
/*  532:     */   {
/*  533: 660 */     MobileMboDataBean databean = ((TextboxControl)event.getCreatingObject()).getDataBean();
/*  534: 662 */     if ((event.getValue() == null) || (event.getValue().equals("")))
/*  535:     */     {
/*  536: 664 */       databean.setValue("MEASUREMENTVALUE", "");
/*  537: 665 */       databean.setValue("MEASUREDATE", "");
/*  538: 666 */       databean.getMobileMbo().setReadOnly("MEASUREMENTVALUE", true);
/*  539: 667 */       databean.getMobileMbo().setReadOnly("MEASUREDATE", true);
/*  540:     */     }
/*  541:     */     else
/*  542:     */     {
/*  543: 671 */       databean.getMobileMbo().setReadOnly("MEASUREMENTVALUE", false);
/*  544: 672 */       databean.getMobileMbo().setReadOnly("MEASUREDATE", false);
/*  545:     */     }
/*  546: 675 */     return false;
/*  547:     */   }
/*  548:     */   
/*  549:     */   public boolean validatemeasurement(UIEvent event)
/*  550:     */     throws MobileApplicationException
/*  551:     */   {
/*  552: 680 */     MobileMboDataBean databean = ((TextboxControl)event.getCreatingObject()).getDataBean();
/*  553: 682 */     if ((event.getValue() == null) || (event.getValue().equals(""))) {
/*  554: 684 */       databean.setValue("MEASUREDATE", "");
/*  555:     */     } else {
/*  556: 688 */       databean.getMobileMbo().setDateValue("MEASUREDATE", databean.getCurrentTime());
/*  557:     */     }
/*  558: 691 */     return false;
/*  559:     */   }
/*  560:     */   
/*  561:     */   public boolean validatetargstart(UIEvent event)
/*  562:     */     throws MobileApplicationException
/*  563:     */   {
/*  564: 696 */     if ((event.getValue() == null) || (event.getValue().equals(""))) {
/*  565: 697 */       return true;
/*  566:     */     }
/*  567: 699 */     MobileMboDataBean databean = ((TextboxControl)event.getCreatingObject()).getDataBean();
/*  568: 700 */     if (databean.getValue("TARGCOMPDATE").equals("")) {
/*  569: 701 */       return true;
/*  570:     */     }
/*  571: 703 */     if (((Date)event.getValue()).after(databean.getMobileMbo().getDateValue("TARGCOMPDATE"))) {
/*  572: 704 */       throw new MobileApplicationException("invalidtargstart");
/*  573:     */     }
/*  574: 706 */     return true;
/*  575:     */   }
/*  576:     */   
/*  577:     */   public boolean validatetargend(UIEvent event)
/*  578:     */     throws MobileApplicationException
/*  579:     */   {
/*  580: 711 */     if ((event.getValue() == null) || (event.getValue().equals(""))) {
/*  581: 712 */       return true;
/*  582:     */     }
/*  583: 714 */     MobileMboDataBean databean = ((TextboxControl)event.getCreatingObject()).getDataBean();
/*  584: 715 */     if (databean.getValue("TARGSTARTDATE").equals("")) {
/*  585: 716 */       return true;
/*  586:     */     }
/*  587: 718 */     if (((Date)event.getValue()).before(databean.getMobileMbo().getDateValue("TARGSTARTDATE"))) {
/*  588: 719 */       throw new MobileApplicationException("invalidtargcomp");
/*  589:     */     }
/*  590: 721 */     return true;
/*  591:     */   }
/*  592:     */   
/*  593:     */   public boolean validateschedstart(UIEvent event)
/*  594:     */     throws MobileApplicationException
/*  595:     */   {
/*  596: 726 */     if ((event.getValue() == null) || (event.getValue().equals(""))) {
/*  597: 727 */       return true;
/*  598:     */     }
/*  599: 729 */     MobileMboDataBean databean = ((TextboxControl)event.getCreatingObject()).getDataBean();
/*  600: 730 */     if (databean.getValue("SCHEDFINISH").equals("")) {
/*  601: 731 */       return true;
/*  602:     */     }
/*  603: 733 */     if (((Date)event.getValue()).after(databean.getMobileMbo().getDateValue("SCHEDFINISH"))) {
/*  604: 734 */       throw new MobileApplicationException("invalidschedstart");
/*  605:     */     }
/*  606: 736 */     return true;
/*  607:     */   }
/*  608:     */   
/*  609:     */   public boolean validateschedend(UIEvent event)
/*  610:     */     throws MobileApplicationException
/*  611:     */   {
/*  612: 741 */     if ((event.getValue() == null) || (event.getValue().equals(""))) {
/*  613: 742 */       return true;
/*  614:     */     }
/*  615: 744 */     MobileMboDataBean databean = ((TextboxControl)event.getCreatingObject()).getDataBean();
/*  616: 745 */     if (databean.getValue("SCHEDSTART").equals("")) {
/*  617: 746 */       return true;
/*  618:     */     }
/*  619: 748 */     if (((Date)event.getValue()).before(databean.getMobileMbo().getDateValue("SCHEDSTART"))) {
/*  620: 749 */       throw new MobileApplicationException("invalidschedfin");
/*  621:     */     }
/*  622: 751 */     return true;
/*  623:     */   }
/*  624:     */   
/*  625:     */   public boolean validateactstart(UIEvent event)
/*  626:     */     throws MobileApplicationException
/*  627:     */   {
/*  628: 756 */     if ((event.getValue() == null) || (event.getValue().equals(""))) {
/*  629: 757 */       return true;
/*  630:     */     }
/*  631: 759 */     MobileMboDataBean databean = ((TextboxControl)event.getCreatingObject()).getDataBean();
/*  632: 760 */     if (databean.getValue("ACTFINISH").equals("")) {
/*  633: 761 */       return true;
/*  634:     */     }
/*  635: 763 */     if (((Date)event.getValue()).after(databean.getMobileMbo().getDateValue("ACTFINISH"))) {
/*  636: 764 */       throw new MobileApplicationException("invalidactstart");
/*  637:     */     }
/*  638: 766 */     return true;
/*  639:     */   }
/*  640:     */   
/*  641:     */   public boolean validateactend(UIEvent event)
/*  642:     */     throws MobileApplicationException
/*  643:     */   {
/*  644: 771 */     if ((event.getValue() == null) || (event.getValue().equals(""))) {
/*  645: 772 */       return true;
/*  646:     */     }
/*  647: 774 */     MobileMboDataBean databean = ((TextboxControl)event.getCreatingObject()).getDataBean();
/*  648: 775 */     if (databean.getValue("ACTSTART").equals("")) {
/*  649: 776 */       return true;
/*  650:     */     }
/*  651: 778 */     if (((Date)event.getValue()).before(databean.getMobileMbo().getDateValue("ACTSTART"))) {
/*  652: 779 */       throw new MobileApplicationException("invalidactfin");
/*  653:     */     }
/*  654: 781 */     return true;
/*  655:     */   }
/*  656:     */   
/*  657:     */   public boolean initwocommlog(UIEvent event)
/*  658:     */     throws MobileApplicationException
/*  659:     */   {
/*  660: 786 */     MobileMboDataBean databean = ((TableControl)event.getCreatingObject()).getDataBean();
/*  661: 787 */     if (databean != null)
/*  662:     */     {
/*  663: 789 */       databean.getQBE().reset();
/*  664: 790 */       databean.getQBE().setQBE("_ERR", "0");
/*  665: 791 */       databean.getQBE().setQBE("PENDING", "~NULL~");
/*  666: 792 */       databean.reset();
/*  667:     */     }
/*  668: 794 */     return true;
/*  669:     */   }
/*  670:     */   
/*  671:     */   public boolean initenterwoobservation(UIEvent event)
/*  672:     */     throws MobileApplicationException
/*  673:     */   {
/*  674: 799 */     MobileMboDataBean wodatabean = ((PageControl)event.getCreatingObject()).getDataBean();
/*  675: 800 */     if ((wodatabean != null) && ((wodatabean.getName().equals("WORKORDER")) || (wodatabean.getName().equals("WOCHILDREN")))) {
/*  676: 803 */       if (wodatabean.getValue("INSPECTOR").equals(""))
/*  677:     */       {
/*  678: 806 */         MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager("PERSON");
/*  679: 807 */         MobileMboDataBean personBean = mgrDBMgr.getDataBean();
/*  680: 808 */         personBean.getQBE().reset();
/*  681: 809 */         if (personBean.getMobileMbo(0) != null) {
/*  682: 810 */           wodatabean.setValue("INSPECTOR", personBean.getMobileMbo(0).getValue("PERSONID"));
/*  683:     */         }
/*  684:     */       }
/*  685:     */     }
/*  686: 813 */     return true;
/*  687:     */   }
/*  688:     */   
/*  689:     */   public boolean filterworktype(UIEvent event)
/*  690:     */     throws MobileApplicationException
/*  691:     */   {
/*  692: 818 */     MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/*  693: 819 */     if (databean != null)
/*  694:     */     {
/*  695: 821 */       MobileMboDataBean dropdownbean = (MobileMboDataBean)event.getValue();
/*  696: 822 */       if (dropdownbean != null)
/*  697:     */       {
/*  698: 824 */         String woclass = ((WOApp)UIUtil.getApplication()).getInternalValue(databean, "WOCLASS", databean.getValue("WOCLASS"));
/*  699: 825 */         if (woclass.equalsIgnoreCase("ACTIVITY")) {
/*  700: 827 */           woclass = "WORKORDER";
/*  701:     */         }
/*  702: 829 */         dropdownbean.getQBE().setQbeExactMatch(true);
/*  703:     */         
/*  704:     */ 
/*  705: 832 */         dropdownbean.getQBE().setQBE("WOCLASS", ((WOApp)UIUtil.getApplication()).getExternalValue(databean, "WOCLASS", woclass));
/*  706:     */       }
/*  707:     */     }
/*  708: 835 */     return false;
/*  709:     */   }
/*  710:     */   
/*  711:     */   public boolean canedittask(UIEvent event)
/*  712:     */     throws MobileApplicationException
/*  713:     */   {
/*  714: 841 */     boolean canedit = !WOApp.isTaskAlsoWO();
/*  715: 850 */     if ((canedit) && ((event.getCreatingObject() instanceof ButtonControl)))
/*  716:     */     {
/*  717: 852 */       MobileWOAppEventHandler wostatushandler = (MobileWOAppEventHandler)UIUtil.getAppEventHandler();
/*  718: 853 */       wostatushandler.canchangetaskstatus(event);
/*  719:     */     }
/*  720:     */     else
/*  721:     */     {
/*  722: 855 */       ((AbstractMobileControl)event.getCreatingObject()).setVisibility(canedit);
/*  723:     */     }
/*  724: 857 */     return true;
/*  725:     */   }
/*  726:     */   
/*  727:     */   public boolean validatewopriority(UIEvent event)
/*  728:     */     throws MobileApplicationException
/*  729:     */   {
/*  730: 862 */     if ((event.getValue() == null) || (((String)event.getValue()).equals(""))) {
/*  731: 863 */       return false;
/*  732:     */     }
/*  733: 865 */     int ivalue = DefaultMobileMboDataFormatter.stringToInt((String)event.getValue());
/*  734: 866 */     if ((ivalue < 0) || (ivalue > 999))
/*  735:     */     {
/*  736: 868 */       Object[] param = { (String)event.getValue() };
/*  737: 869 */       UIUtil.showMessageBox(MobileMessageGenerator.generate("WOPriorityNotValid", param));
/*  738: 870 */       event.setEventErrored();
/*  739: 871 */       return true;
/*  740:     */     }
/*  741: 874 */     return false;
/*  742:     */   }
/*  743:     */   
/*  744:     */   public boolean displayMultiAsset(UIEvent event)
/*  745:     */     throws MobileApplicationException
/*  746:     */   {
/*  747: 879 */     MobileMboDataBean databean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*  748: 880 */     return true;
/*  749:     */   }
/*  750:     */   
/*  751:     */   public boolean toggleSwap(UIEvent event)
/*  752:     */     throws MobileApplicationException
/*  753:     */   {
/*  754: 885 */     if ((event.getValue() == null) || (((String)event.getValue()).equals(""))) {
/*  755: 886 */       return false;
/*  756:     */     }
/*  757: 888 */     String sValue = (String)event.getValue();
/*  758:     */     
/*  759: 890 */     boolean isSwap = false;
/*  760: 892 */     if ((sValue != null) && (sValue.equalsIgnoreCase("true"))) {
/*  761: 893 */       isSwap = true;
/*  762:     */     }
/*  763: 895 */     MobileMboDataBean wodatabean = UIUtil.getCurrentScreen().getDataBean();
/*  764: 896 */     if ((wodatabean != null) && (wodatabean.getName().equals("WORKORDER"))) {
/*  765: 898 */       if (wodatabean.getValue("WONUM").equals("")) {
/*  766: 899 */         return true;
/*  767:     */       }
/*  768:     */     }
/*  769: 902 */     String response = UIUtil.getApplication().getUserEvent().getMsgResponse();
/*  770: 905 */     if (response.equals("2"))
/*  771:     */     {
/*  772: 907 */       event.setEventErrored();
/*  773: 908 */       return true;
/*  774:     */     }
/*  775: 911 */     String msgId = isSwap ? "moveToSwap" : "swapToMove";
/*  776: 913 */     if (response.equals("-1"))
/*  777:     */     {
/*  778: 915 */       event.setEventErrored();
/*  779: 916 */       String msg = MobileMessageGenerator.generate(msgId, new Object[0]);
/*  780:     */       
/*  781: 918 */       UIUtil.showMessageBox(msg, "question", 3, UIUtil.getApplication().getUserEvent());
/*  782: 919 */       return true;
/*  783:     */     }
/*  784: 922 */     if (isSwap)
/*  785:     */     {
/*  786: 924 */       MobileMboDataBean attrBean = wodatabean.getDataBean("ASSAUTOATTRUPDATE");
/*  787: 925 */       for (int i = 0; i < attrBean.count(); i++) {
/*  788: 926 */         attrBean.delete(i);
/*  789:     */       }
/*  790: 928 */       attrBean.getDataBeanManager().save();
/*  791: 929 */       attrBean.reset();
/*  792:     */     }
/*  793:     */     else
/*  794:     */     {
/*  795: 932 */       MobileMboDataBean multiBean = wodatabean.getDataBean("WOMULTIASSETLOCCI");
/*  796: 933 */       for (int i = 0; i < multiBean.count(); i++)
/*  797:     */       {
/*  798: 934 */         MobileMbo mmbo = multiBean.getMobileMbo(i);
/*  799:     */         
/*  800: 936 */         mmbo.setReadOnly("NEWREPLACEASSETNUM", false);
/*  801:     */         
/*  802: 938 */         mmbo.setValue("REPLACEASSETNUM", null);
/*  803: 939 */         mmbo.setValue("REPLACEMENTSITE", null);
/*  804: 941 */         if (!mmbo.isNull("NEWREPLACEASSETNUM")) {
/*  805: 942 */           mmbo.setValue("NEWREPLACEASSETNUM", null, false);
/*  806:     */         }
/*  807:     */       }
/*  808: 944 */       multiBean.getDataBeanManager().save();
/*  809: 945 */       multiBean.reset();
/*  810:     */     }
/*  811: 948 */     return false;
/*  812:     */   }
/*  813:     */   
/*  814:     */   public boolean locationchanged(UIEvent event)
/*  815:     */     throws MobileApplicationException
/*  816:     */   {
/*  817: 953 */     MobileMboDataBean databean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*  818: 957 */     if (databean != null) {
/*  819: 959 */       if ((event.getValue() != null) && (!event.getValue().equals("")))
/*  820:     */       {
/*  821: 961 */         MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager("LOCATIONS");
/*  822: 962 */         MobileMboDataBean assetBean = mgrDBMgr.getDataBean();
/*  823:     */         
/*  824: 964 */         assetBean.getQBE().setQbeExactMatch(true);
/*  825:     */         
/*  826: 966 */         assetBean.getQBE().setQBE("SITEID", databean.getValue("SITEID"));
/*  827: 967 */         assetBean.getQBE().setQBE("LOCATION", (String)event.getValue());
/*  828: 968 */         assetBean.reset();
/*  829: 969 */         int count = assetBean.count();
/*  830: 970 */         if (count == 1) {
/*  831: 971 */           databean.setValue("PLUSCLOOP", assetBean.getMobileMbo(0).getValue("PLUSCLOOP"));
/*  832:     */         }
/*  833:     */       }
/*  834:     */       else
/*  835:     */       {
/*  836: 974 */         databean.setValue("PLUSCLOOP", "0");
/*  837:     */       }
/*  838:     */     }
/*  839: 982 */     if ((event.getValue() != null) && (!event.getValue().equals("")))
/*  840:     */     {
/*  841: 986 */       if (databean.getMobileMbo().isNull("ASSETNUM"))
/*  842:     */       {
/*  843: 988 */         MobileMboDataBeanManager mgr = new MobileMboDataBeanManager("ASSET");
/*  844: 989 */         MobileMboDataBean assetdatabean = mgr.getDataBean();
/*  845: 990 */         QBE qbe = assetdatabean.getQBE();
/*  846: 991 */         qbe.reset();
/*  847: 992 */         qbe.setQbeExactMatch(true);
/*  848: 993 */         qbe.setQBE("LOCATION", (String)event.getValue());
/*  849: 994 */         qbe.setQBE("SITEID", databean.getValue("SITEID"));
/*  850: 995 */         assetdatabean.reset();
/*  851: 996 */         if (assetdatabean.count() == 1) {
/*  852: 998 */           databean.getMobileMbo().setValue("ASSETNUM", assetdatabean.getValue("ASSETNUM"));
/*  853:     */         }
/*  854:     */       }
/*  855:1003 */       MobileMboDataBean womultibean = databean.getDataBean("WOMULTIASSETLOCCI");
/*  856:1004 */       if (womultibean != null)
/*  857:     */       {
/*  858:1006 */         womultibean.getQBE().reset();
/*  859:1007 */         womultibean.getQBE().setQbeExactMatch(true);
/*  860:1008 */         womultibean.getQBE().setQBE("ISPRIMARY", "1");
/*  861:1009 */         womultibean.reset();
/*  862:     */         
/*  863:1011 */         String newLocation = (String)event.getValue();
/*  864:1013 */         if (womultibean.count() == 1)
/*  865:     */         {
/*  866:1015 */           womultibean.setValue("LOCATION", newLocation);
/*  867:1016 */           womultibean.getDataBeanManager().save();
/*  868:     */         }
/*  869:     */       }
/*  870:     */     }
/*  871:1023 */     return true;
/*  872:     */   }
/*  873:     */   
/*  874:     */   public boolean cichanged(UIEvent event)
/*  875:     */     throws MobileApplicationException
/*  876:     */   {
/*  877:1028 */     if ((event.getValue() != null) && (!event.getValue().equals("")))
/*  878:     */     {
/*  879:1030 */       MobileMboDataBean databean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/*  880:1031 */       if ((databean.getMobileMbo().isNull("ASSETNUM")) && (databean.getMobileMbo().isNull("LOCATION"))) {
/*  881:1034 */         if (!databean.getMobileMbo().isNull("CIASSETNUM")) {
/*  882:1036 */           databean.setValue("ASSETNUM", databean.getValue("CIASSETNUM"));
/*  883:1038 */         } else if (!databean.getMobileMbo().isNull("CILOCATION")) {
/*  884:1040 */           databean.setValue("LOCATION", databean.getValue("CILOCATION"));
/*  885:     */         }
/*  886:     */       }
/*  887:     */     }
/*  888:1045 */     return true;
/*  889:     */   }
/*  890:     */   
/*  891:     */   protected boolean onLaborAssignmentChanged(UIEvent event)
/*  892:     */     throws MobileApplicationException
/*  893:     */   {
/*  894:1050 */     MobileMboDataBean assignmentBean = DataBeanCache.findDataBean("WOPLANNEDLABOR");
/*  895:1051 */     MobileMbo assignment = assignmentBean.getMobileMbo();
/*  896:1052 */     String selectedValue = event.getValue() != null ? event.getValue().toString() : null;
/*  897:1053 */     if ((selectedValue == null) || (selectedValue.length() <= 0))
/*  898:     */     {
/*  899:1054 */       String status = ((WOApp)UIUtil.getApplication()).getExternalValue(assignmentBean, "WOASSIGNSTATUS", "WAITASGN");
/*  900:1055 */       assignment.setValue("STATUS", status, false);
/*  901:1056 */       assignment.setValue("CONTRACTNUM", "", false);
/*  902:1057 */       assignment.setValue("VENDOR", "", false);
/*  903:     */     }
/*  904:     */     else
/*  905:     */     {
/*  906:1059 */       String status = ((WOApp)UIUtil.getApplication()).getExternalValue(assignmentBean, "WOASSIGNSTATUS", "ASSIGNED");
/*  907:1060 */       assignment.setValue("STATUS", status, false);
/*  908:1061 */       MobileMboDataBean craft = new MobileMboDataBeanManager("LABORCRAFTRATE").getDataBean();
/*  909:1062 */       craft.getQBE().setQbeExactMatch(true);
/*  910:1063 */       craft.getQBE().setQBE("ORGID", assignment.getValue("ORGID"));
/*  911:1064 */       craft.getQBE().setQBE("LABORCODE", selectedValue);
/*  912:1065 */       craft.reset();
/*  913:1066 */       MobileMbo selectedLabor = craft.getMobileMbo(0);
/*  914:1067 */       if (selectedLabor != null)
/*  915:     */       {
/*  916:1068 */         assignment.setValue("CRAFT", selectedLabor.getValue("CRAFT"), false);
/*  917:1069 */         assignment.setValue("SKILLLEVEL", selectedLabor.getValue("SKILLLEVEL"), false);
/*  918:1070 */         assignment.setValue("CONTRACTNUM", selectedLabor.getValue("CONTRACTNUM"), false);
/*  919:1071 */         assignment.setValue("VENDOR", selectedLabor.getValue("VENDOR"), false);
/*  920:     */       }
/*  921:     */       else
/*  922:     */       {
/*  923:1075 */         assignment.setValue("CRAFT", "", false);
/*  924:1076 */         assignment.setValue("SKILLLEVEL", "", false);
/*  925:1077 */         assignment.setValue("CONTRACTNUM", "", false);
/*  926:1078 */         assignment.setValue("VENDOR", "", false);
/*  927:     */       }
/*  928:     */     }
/*  929:1082 */     return true;
/*  930:     */   }
/*  931:     */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.mobilewo.WOEventHandler
 * JD-Core Version:    0.7.0.1
 */