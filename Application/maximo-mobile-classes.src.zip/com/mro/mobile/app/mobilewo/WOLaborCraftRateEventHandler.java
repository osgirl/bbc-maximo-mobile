/*   1:    */ package com.mro.mobile.app.mobilewo;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.MobileMessageGenerator;
/*   5:    */ import com.mro.mobile.mbo.MobileMbo;
/*   6:    */ import com.mro.mobile.mbo.MobileMboQBE;
/*   7:    */ import com.mro.mobile.ui.DataBeanCache;
/*   8:    */ import com.mro.mobile.ui.MobileMboDataBean;
/*   9:    */ import com.mro.mobile.ui.MobileMboDataBeanManager;
/*  10:    */ import com.mro.mobile.ui.event.UIEvent;
/*  11:    */ import com.mro.mobile.ui.res.UIUtil;
/*  12:    */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*  13:    */ import com.mro.mobile.ui.res.controls.PageControl;
/*  14:    */ import java.util.HashSet;
/*  15:    */ import java.util.Hashtable;
/*  16:    */ import java.util.Set;
/*  17:    */ 
/*  18:    */ public class WOLaborCraftRateEventHandler
/*  19:    */   extends MobileWOCommonEventHandler
/*  20:    */ {
/*  21:    */   public boolean performEvent(UIEvent event)
/*  22:    */     throws MobileApplicationException
/*  23:    */   {
/*  24: 36 */     if (event == null) {
/*  25: 36 */       return false;
/*  26:    */     }
/*  27: 38 */     String eventId = event.getEventName();
/*  28: 40 */     if (eventId.equalsIgnoreCase("initpageLABOR")) {
/*  29: 42 */       return initpageLABOR(event);
/*  30:    */     }
/*  31: 44 */     if (eventId.equalsIgnoreCase("refreshpageLABOR")) {
/*  32: 46 */       return refreshpageLABOR(event);
/*  33:    */     }
/*  34: 48 */     if (eventId.equalsIgnoreCase("initpageCRAFT")) {
/*  35: 50 */       return initpageCRAFT(event);
/*  36:    */     }
/*  37: 52 */     if (eventId.equalsIgnoreCase("refreshpageCRAFT")) {
/*  38: 54 */       return refreshpageCRAFT(event);
/*  39:    */     }
/*  40: 56 */     if (eventId.equalsIgnoreCase("initpageSKILL")) {
/*  41: 58 */       return initpageSKILL(event);
/*  42:    */     }
/*  43: 60 */     if (eventId.equalsIgnoreCase("refreshpageSKILL")) {
/*  44: 62 */       return refreshpageSKILL(event);
/*  45:    */     }
/*  46: 64 */     if (eventId.equalsIgnoreCase("initpageCONTRACT")) {
/*  47: 66 */       return initpageCONTRACT(event);
/*  48:    */     }
/*  49: 68 */     if (eventId.equalsIgnoreCase("refreshpageCONTRACT")) {
/*  50: 70 */       return refreshpageCONTRACT(event);
/*  51:    */     }
/*  52: 72 */     if (eventId.equalsIgnoreCase("initpageVENDOR")) {
/*  53: 74 */       return initpageVENDOR(event);
/*  54:    */     }
/*  55: 76 */     if (eventId.equalsIgnoreCase("refreshpageVENDOR")) {
/*  56: 78 */       return refreshpageVENDOR(event);
/*  57:    */     }
/*  58: 80 */     if (eventId.equalsIgnoreCase("select")) {
/*  59: 82 */       return select(event);
/*  60:    */     }
/*  61: 83 */     if (eventId.equalsIgnoreCase("barcoderead")) {
/*  62: 84 */       return laborCrewScan(event);
/*  63:    */     }
/*  64: 85 */     if (eventId.equalsIgnoreCase("displayMobileCrew")) {
/*  65: 86 */       return displayMobileCrew(event);
/*  66:    */     }
/*  67: 87 */     if (eventId.equalsIgnoreCase("selectCrew")) {
/*  68: 88 */       return selectCrew(event);
/*  69:    */     }
/*  70: 92 */     super.performEvent(event);
/*  71:    */     
/*  72: 94 */     return false;
/*  73:    */   }
/*  74:    */   
/*  75:    */   public boolean laborCrewScan(UIEvent event)
/*  76:    */     throws MobileApplicationException
/*  77:    */   {
/*  78: 99 */     String scannedValue = (String)event.getValue();
/*  79:100 */     String field = getPrimaryScanField();
/*  80:101 */     MobileMboDataBean laborCraftRateBean = getLaborCraftBean(field, scannedValue);
/*  81:102 */     int count = laborCraftRateBean.count();
/*  82:103 */     if (count == 1) {
/*  83:104 */       createCrewMembers(laborCraftRateBean, event, true);
/*  84:105 */     } else if (count > 1) {
/*  85:106 */       UIUtil.showMessageBox(MobileMessageGenerator.generate("morethanonevaluescanned", null));
/*  86:    */     } else {
/*  87:108 */       UIUtil.showMessageBox(MobileMessageGenerator.generate("notfoundvaluescanned", null));
/*  88:    */     }
/*  89:110 */     return true;
/*  90:    */   }
/*  91:    */   
/*  92:    */   private String getPrimaryScanField()
/*  93:    */     throws MobileApplicationException
/*  94:    */   {
/*  95:115 */     MobileMboDataBeanManager manager = new MobileMboDataBeanManager("TABCOLSEL");
/*  96:116 */     MobileMboDataBean bean = manager.getDataBean();
/*  97:117 */     bean.getQBE().setQBE("CTRLID", "currentcrewpagetbl");
/*  98:118 */     bean.getQBE().setQBE("PRIMARYSCAN", "1");
/*  99:119 */     bean.reset();
/* 100:120 */     String field = bean.getValue("COLUMNNAME");
/* 101:121 */     return (field != null) && (field.equals("")) ? "LABORCODE" : field;
/* 102:    */   }
/* 103:    */   
/* 104:    */   private boolean isNewLaborPartOfCrew(Set existing, MobileMbo mobileMbo)
/* 105:    */     throws MobileApplicationException
/* 106:    */   {
/* 107:126 */     return existing.contains(buildKey(mobileMbo));
/* 108:    */   }
/* 109:    */   
/* 110:    */   private String buildKey(MobileMbo mobileMbo)
/* 111:    */     throws MobileApplicationException
/* 112:    */   {
/* 113:131 */     return mobileMbo.getValue("ORGID") + "|" + mobileMbo.getValue("LABORCODE");
/* 114:    */   }
/* 115:    */   
/* 116:    */   private MobileMboDataBean getLaborCraftBean(String field, String value)
/* 117:    */     throws MobileApplicationException
/* 118:    */   {
/* 119:136 */     MobileMboDataBeanManager manager = new MobileMboDataBeanManager("LABORCRAFTRATE");
/* 120:137 */     MobileMboDataBean bean = manager.getDataBean();
/* 121:138 */     bean.getQBE().setQbeExactMatch(true);
/* 122:139 */     bean.getQBE().setQBE(field, value);
/* 123:140 */     bean.reset();
/* 124:141 */     return bean;
/* 125:    */   }
/* 126:    */   
/* 127:    */   protected boolean selectCrew(UIEvent event)
/* 128:    */     throws MobileApplicationException
/* 129:    */   {
/* 130:146 */     if (existsCurrentCrew())
/* 131:    */     {
/* 132:147 */       if (event.getMsgResponse().equals("-1"))
/* 133:    */       {
/* 134:148 */         UIUtil.showOKCANCELMessageBox(event, MobileMessageGenerator.generate("currentcrewexists", new Object[0]));
/* 135:149 */         return true;
/* 136:    */       }
/* 137:150 */       if (event.getMsgResponse().equals("1")) {
/* 138:151 */         redefineCrew(event);
/* 139:152 */       } else if (event.getMsgResponse().equals("2")) {
/* 140:153 */         UIUtil.closePage();
/* 141:    */       }
/* 142:    */     }
/* 143:    */     else
/* 144:    */     {
/* 145:156 */       redefineCrew(event);
/* 146:    */     }
/* 147:158 */     UIUtil.refreshCurrentScreen();
/* 148:159 */     return true;
/* 149:    */   }
/* 150:    */   
/* 151:    */   private void redefineCrew(UIEvent event)
/* 152:    */     throws MobileApplicationException
/* 153:    */   {
/* 154:164 */     MobileMboDataBean currentCrew = DataBeanCache.getDataBean("CURRENTCREW", "CURRENTCREW");
/* 155:165 */     clearCurrentCrew(currentCrew);
/* 156:166 */     MobileMboDataBean mobileCrew = UIUtil.getCurrentScreen().getDataBean();
/* 157:167 */     MobileMboDataBean mobileCrewLabors = mobileCrew.getDataBean("CREWLABOR");
/* 158:168 */     createCrewMembers(mobileCrewLabors, event, false);
/* 159:    */   }
/* 160:    */   
/* 161:    */   private void createCrewMembers(MobileMboDataBean mobileCrewLabors, UIEvent event, boolean showDetails)
/* 162:    */     throws MobileApplicationException
/* 163:    */   {
/* 164:173 */     MobileMboDataBean currentCrew = DataBeanCache.getDataBean("CURRENTCREW", "CURRENTCREW");
/* 165:174 */     Set existingMembers = createCrewLaborCache(currentCrew);
/* 166:    */     
/* 167:    */ 
/* 168:    */ 
/* 169:    */ 
/* 170:179 */     String[] attributes = { "ORGID", "LABORCODE", "CRAFT", "SKILLLEVEL", "CONTRACTNUM", "VENDOR", "LABOR_DISPLAYNAME", "CRAFT_DESCRIPTION", "SKILLLEVEL_DESCRIPTION" };
/* 171:    */     
/* 172:    */ 
/* 173:    */ 
/* 174:    */ 
/* 175:    */ 
/* 176:    */ 
/* 177:    */ 
/* 178:    */ 
/* 179:188 */     int count = mobileCrewLabors.count();
/* 180:189 */     for (int i = 0; i < count; i++)
/* 181:    */     {
/* 182:190 */       MobileMbo mobileMbo = mobileCrewLabors.getMobileMbo(i);
/* 183:191 */       if (!isNewLaborPartOfCrew(existingMembers, mobileMbo))
/* 184:    */       {
/* 185:192 */         currentCrew.insert();
/* 186:193 */         for (int j = 0; j < attributes.length; j++) {
/* 187:194 */           currentCrew.getMobileMbo().setValue(attributes[j], mobileMbo.getValue(attributes[j]));
/* 188:    */         }
/* 189:196 */         existingMembers.add(buildKey(mobileMbo));
/* 190:    */       }
/* 191:    */     }
/* 192:199 */     currentCrew.getDataBeanManager().save();
/* 193:200 */     currentCrew.reset();
/* 194:201 */     if (showDetails)
/* 195:    */     {
/* 196:203 */       positionateBean(currentCrew, mobileCrewLabors.getMobileMbo(0));
/* 197:204 */       UIUtil.gotoPage("currentcrew_details", (AbstractMobileControl)event.getCreatingObject());
/* 198:    */     }
/* 199:    */     else
/* 200:    */     {
/* 201:207 */       UIUtil.closePage();
/* 202:208 */       UIUtil.gotoPage("currentcrewpage", (AbstractMobileControl)event.getCreatingObject());
/* 203:209 */       UIUtil.refreshCurrentScreen();
/* 204:    */     }
/* 205:    */   }
/* 206:    */   
/* 207:    */   private void positionateBean(MobileMboDataBean currentCrew, MobileMbo mobileMbo)
/* 208:    */     throws MobileApplicationException
/* 209:    */   {
/* 210:215 */     int position = 0;
/* 211:216 */     if (mobileMbo != null)
/* 212:    */     {
/* 213:217 */       String laborCode = mobileMbo.getValue("LABORCODE");
/* 214:218 */       String orgId = mobileMbo.getValue("ORGID");
/* 215:219 */       int count = currentCrew.count();
/* 216:220 */       for (int i = 0; i < count; i++)
/* 217:    */       {
/* 218:221 */         MobileMbo current = currentCrew.getMobileMbo(i);
/* 219:222 */         if ((current.getValue("LABORCODE").equals(laborCode)) && (current.getValue("ORGID").equals(orgId)))
/* 220:    */         {
/* 221:224 */           position = i;
/* 222:225 */           break;
/* 223:    */         }
/* 224:    */       }
/* 225:    */     }
/* 226:229 */     currentCrew.setCurrentPosition(position);
/* 227:    */   }
/* 228:    */   
/* 229:    */   private Set createCrewLaborCache(MobileMboDataBean currentCrew)
/* 230:    */     throws MobileApplicationException
/* 231:    */   {
/* 232:234 */     HashSet set = new HashSet();
/* 233:235 */     for (int i = 0; i < currentCrew.count(); i++)
/* 234:    */     {
/* 235:236 */       MobileMbo mbo = currentCrew.getMobileMbo(i);
/* 236:237 */       set.add(buildKey(mbo));
/* 237:    */     }
/* 238:239 */     return set;
/* 239:    */   }
/* 240:    */   
/* 241:    */   private void clearCurrentCrew(MobileMboDataBean currentCrew)
/* 242:    */     throws MobileApplicationException
/* 243:    */   {
/* 244:244 */     for (int i = 0; i < currentCrew.count(); i++) {
/* 245:245 */       currentCrew.deleteLocal(i);
/* 246:    */     }
/* 247:247 */     currentCrew.getDataBeanManager().save();
/* 248:248 */     currentCrew.reset();
/* 249:    */   }
/* 250:    */   
/* 251:    */   private boolean existsCurrentCrew()
/* 252:    */     throws MobileApplicationException
/* 253:    */   {
/* 254:253 */     MobileMboDataBean currentCrewBean = DataBeanCache.getDataBean("CURRENTCREW", "CURRENTCREW");
/* 255:254 */     return currentCrewBean.count() > 0;
/* 256:    */   }
/* 257:    */   
/* 258:    */   protected boolean displayMobileCrew(UIEvent event)
/* 259:    */     throws MobileApplicationException
/* 260:    */   {
/* 261:259 */     MobileMboDataBean mobileCrew = DataBeanCache.getDataBean("MOBILECREW", "MOBILECREW");
/* 262:260 */     int count = 0;
/* 263:261 */     if (mobileCrew != null) {
/* 264:262 */       count = mobileCrew.count();
/* 265:    */     }
/* 266:264 */     ((AbstractMobileControl)event.getCreatingObject()).setVisibility(count > 0);
/* 267:265 */     return true;
/* 268:    */   }
/* 269:    */   
/* 270:    */   public boolean initpageLABOR(UIEvent event)
/* 271:    */     throws MobileApplicationException
/* 272:    */   {
/* 273:271 */     return initpage(event, "LABORCODE", "I");
/* 274:    */   }
/* 275:    */   
/* 276:    */   public boolean refreshpageLABOR(UIEvent event)
/* 277:    */     throws MobileApplicationException
/* 278:    */   {
/* 279:275 */     return initpage(event, "LABORCODE", "R");
/* 280:    */   }
/* 281:    */   
/* 282:    */   public boolean initpageCRAFT(UIEvent event)
/* 283:    */     throws MobileApplicationException
/* 284:    */   {
/* 285:280 */     return initpage(event, "CRAFT", "I");
/* 286:    */   }
/* 287:    */   
/* 288:    */   public boolean refreshpageCRAFT(UIEvent event)
/* 289:    */     throws MobileApplicationException
/* 290:    */   {
/* 291:284 */     return initpage(event, "CRAFT", "R");
/* 292:    */   }
/* 293:    */   
/* 294:    */   public boolean initpageSKILL(UIEvent event)
/* 295:    */     throws MobileApplicationException
/* 296:    */   {
/* 297:289 */     return initpage(event, "SKILLLEVEL", "I");
/* 298:    */   }
/* 299:    */   
/* 300:    */   public boolean refreshpageSKILL(UIEvent event)
/* 301:    */     throws MobileApplicationException
/* 302:    */   {
/* 303:293 */     return initpage(event, "SKILLLEVEL", "R");
/* 304:    */   }
/* 305:    */   
/* 306:    */   public boolean initpageCONTRACT(UIEvent event)
/* 307:    */     throws MobileApplicationException
/* 308:    */   {
/* 309:298 */     return initpage(event, "CONTRACTNUM", "I");
/* 310:    */   }
/* 311:    */   
/* 312:    */   public boolean refreshpageCONTRACT(UIEvent event)
/* 313:    */     throws MobileApplicationException
/* 314:    */   {
/* 315:302 */     return initpage(event, "CONTRACTNUM", "R");
/* 316:    */   }
/* 317:    */   
/* 318:    */   public boolean initpageVENDOR(UIEvent event)
/* 319:    */     throws MobileApplicationException
/* 320:    */   {
/* 321:307 */     return initpage(event, "VENDOR", "I");
/* 322:    */   }
/* 323:    */   
/* 324:    */   public boolean refreshpageVENDOR(UIEvent event)
/* 325:    */     throws MobileApplicationException
/* 326:    */   {
/* 327:311 */     return initpage(event, "VENDOR", "R");
/* 328:    */   }
/* 329:    */   
/* 330:    */   public boolean initpage(UIEvent event, String field, String eventtype)
/* 331:    */     throws MobileApplicationException
/* 332:    */   {
/* 333:316 */     MobileMboDataBean lcrBean = null;
/* 334:317 */     MobileMboDataBean databean = null;
/* 335:319 */     if (eventtype.equalsIgnoreCase("I"))
/* 336:    */     {
/* 337:322 */       lcrBean = ((PageControl)event.getCreatingObject()).getDataBean();
/* 338:323 */       databean = ((PageControl)event.getCreatingObject()).getLaunchingControl().getDataBean();
/* 339:    */     }
/* 340:325 */     else if (eventtype.equalsIgnoreCase("R"))
/* 341:    */     {
/* 342:328 */       lcrBean = UIUtil.getCurrentScreen().getDataBean();
/* 343:329 */       databean = ((PageControl)UIUtil.getCurrentScreen()).getLaunchingControl().getDataBean();
/* 344:    */     }
/* 345:    */     else
/* 346:    */     {
/* 347:333 */       return true;
/* 348:    */     }
/* 349:336 */     if (!eventtype.equalsIgnoreCase("R"))
/* 350:    */     {
/* 351:338 */       lcrBean.getQBE().reset();
/* 352:340 */       if ((!field.equals("LABORCODE")) && (!databean.getValue("LABORCODE").equals(""))) {
/* 353:341 */         lcrBean.getQBE().setQBE("LABORCODE", databean.getValue("LABORCODE"));
/* 354:    */       }
/* 355:343 */       if ((!field.equals("LABORCODE")) && (!field.equals("CRAFT")) && (!databean.getValue("CRAFT").equals(""))) {
/* 356:344 */         lcrBean.getQBE().setQBE("CRAFT", databean.getValue("CRAFT"));
/* 357:    */       }
/* 358:346 */       if ((!field.equals("LABORCODE")) && (!field.equals("SKILLLEVEL")) && (!databean.getValue("SKILLLEVEL").equals(""))) {
/* 359:347 */         lcrBean.getQBE().setQBE("SKILLLEVEL", databean.getValue("SKILLLEVEL"));
/* 360:    */       }
/* 361:349 */       if ((!field.equals("LABORCODE")) && (!field.equals("VENDOR")) && (!databean.getValue("VENDOR").equals(""))) {
/* 362:350 */         lcrBean.getQBE().setQBE("VENDOR", databean.getValue("VENDOR"));
/* 363:    */       }
/* 364:352 */       if ((!field.equals("LABORCODE")) && (!field.equals("CONTRACTNUM")) && (!databean.getValue("CONTRACTNUM").equals(""))) {
/* 365:353 */         lcrBean.getQBE().setQBE("CONTRACTNUM", databean.getValue("CONTRACTNUM"));
/* 366:    */       }
/* 367:355 */       lcrBean.reset();
/* 368:    */     }
/* 369:359 */     Hashtable ht = new Hashtable();
/* 370:    */     
/* 371:361 */     int count = lcrBean.count();
/* 372:362 */     for (int i = count - 1; i >= 0; i--) {
/* 373:364 */       if ((field.equals("CRAFT")) || (field.equals("SKILLLEVEL")))
/* 374:    */       {
/* 375:367 */         if ((lcrBean.getMobileMbo(i).getValue("CRAFT").equals("")) && (lcrBean.getMobileMbo(i).getValue("SKILLLEVEL").equals("")))
/* 376:    */         {
/* 377:369 */           lcrBean.remove(i);
/* 378:    */         }
/* 379:    */         else
/* 380:    */         {
/* 381:372 */           String key = lcrBean.getMobileMbo(i).getValue("CRAFT") + "^" + lcrBean.getMobileMbo(i).getValue("SKILLLEVEL");
/* 382:373 */           if (ht.containsKey(key)) {
/* 383:374 */             lcrBean.remove(i);
/* 384:    */           } else {
/* 385:376 */             ht.put(key, key);
/* 386:    */           }
/* 387:    */         }
/* 388:    */       }
/* 389:380 */       else if (lcrBean.getMobileMbo(i).getValue(field).equals("")) {
/* 390:382 */         lcrBean.remove(i);
/* 391:385 */       } else if (ht.containsKey(lcrBean.getMobileMbo(i).getValue(field))) {
/* 392:386 */         lcrBean.remove(i);
/* 393:    */       } else {
/* 394:388 */         ht.put(lcrBean.getMobileMbo(i).getValue(field), lcrBean.getMobileMbo(i).getValue(field));
/* 395:    */       }
/* 396:    */     }
/* 397:393 */     lcrBean.close();
/* 398:394 */     return true;
/* 399:    */   }
/* 400:    */   
/* 401:    */   public boolean select(UIEvent event)
/* 402:    */     throws MobileApplicationException
/* 403:    */   {
/* 404:399 */     String screenId = ((PageControl)UIUtil.getCurrentScreen()).getId();
/* 405:400 */     if ((screenId.equals("lcrlookup_cr")) || (screenId.equals("lcrlookup_sl")))
/* 406:    */     {
/* 407:402 */       MobileMboDataBean databean = UIUtil.getCurrentScreen().getDataBean();
/* 408:403 */       MobileMboDataBean wolabtransdatabean = ((PageControl)UIUtil.getCurrentScreen()).getLaunchingControl().getDataBean();
/* 409:    */       
/* 410:405 */       wolabtransdatabean.setValue("CRAFT", databean.getValue("CRAFT"));
/* 411:406 */       wolabtransdatabean.setValue("SKILLLEVEL", databean.getValue("SKILLLEVEL"));
/* 412:    */     }
/* 413:409 */     return false;
/* 414:    */   }
/* 415:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.mobilewo.WOLaborCraftRateEventHandler
 * JD-Core Version:    0.7.0.1
 */