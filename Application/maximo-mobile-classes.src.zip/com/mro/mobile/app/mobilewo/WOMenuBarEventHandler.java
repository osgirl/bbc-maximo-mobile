/*   1:    */ package com.mro.mobile.app.mobilewo;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.ui.DataBeanCache;
/*   5:    */ import com.mro.mobile.ui.MobileMboDataBean;
/*   6:    */ import com.mro.mobile.ui.event.UIEvent;
/*   7:    */ import com.mro.mobile.ui.res.UIUtil;
/*   8:    */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*   9:    */ import com.mro.mobile.ui.res.controls.StateControl;
/*  10:    */ import com.mro.mobileapp.WOApp;
/*  11:    */ 
/*  12:    */ public class WOMenuBarEventHandler
/*  13:    */   extends MobileWOCommonEventHandler
/*  14:    */ {
/*  15:    */   public boolean performEvent(UIEvent event)
/*  16:    */     throws MobileApplicationException
/*  17:    */   {
/*  18: 32 */     if (event == null) {
/*  19: 32 */       return false;
/*  20:    */     }
/*  21: 34 */     String eventId = event.getEventName();
/*  22: 36 */     if (eventId.equalsIgnoreCase("done"))
/*  23:    */     {
/*  24: 39 */       saveLinearDetails();
/*  25:    */       
/*  26:    */ 
/*  27: 42 */       return done(event);
/*  28:    */     }
/*  29: 45 */     if (eventId.equalsIgnoreCase("prevrec")) {
/*  30: 47 */       return super.prevrec(event);
/*  31:    */     }
/*  32: 49 */     if (eventId.equalsIgnoreCase("nextrec")) {
/*  33: 51 */       return super.nextrec(event);
/*  34:    */     }
/*  35: 53 */     if (eventId.equalsIgnoreCase("canedittask")) {
/*  36: 55 */       return canedittask(event);
/*  37:    */     }
/*  38: 57 */     if (eventId.equalsIgnoreCase("togglenextrec")) {
/*  39: 59 */       return togglenextrec(event);
/*  40:    */     }
/*  41: 61 */     super.performEvent(event);
/*  42:    */     
/*  43: 63 */     return false;
/*  44:    */   }
/*  45:    */   
/*  46:    */   public boolean togglenextrec(UIEvent event)
/*  47:    */     throws MobileApplicationException
/*  48:    */   {
/*  49: 71 */     MobileMboDataBean dataBean = null;
/*  50: 72 */     AbstractMobileControl control = (AbstractMobileControl)event.getCreatingObject();
/*  51: 73 */     String dataSrc = control.getValue("datasrcname");
/*  52: 74 */     if (dataSrc != null) {
/*  53: 76 */       dataBean = DataBeanCache.findDataBean(dataSrc);
/*  54:    */     }
/*  55: 78 */     StateControl state = (StateControl)event.getCreatingObject();
/*  56: 79 */     if (dataBean != null)
/*  57:    */     {
/*  58: 81 */       if (dataBean.getMobileMbo(dataBean.getCurrentPosition() + 1) == null) {
/*  59: 82 */         state.setStateViaState("off");
/*  60:    */       } else {
/*  61: 85 */         state.setStateViaState("on");
/*  62:    */       }
/*  63:    */     }
/*  64:    */     else {
/*  65: 89 */       state.setStateViaState("off");
/*  66:    */     }
/*  67: 91 */     return true;
/*  68:    */   }
/*  69:    */   
/*  70:    */   public boolean canedittask(UIEvent event)
/*  71:    */     throws MobileApplicationException
/*  72:    */   {
/*  73: 96 */     ((AbstractMobileControl)event.getCreatingObject()).setVisibility(!WOApp.isTaskAlsoWO());
/*  74:    */     
/*  75: 98 */     return true;
/*  76:    */   }
/*  77:    */   
/*  78:    */   public boolean done(UIEvent event)
/*  79:    */     throws MobileApplicationException
/*  80:    */   {
/*  81:105 */     if (UIUtil.getCurrentScreen().getId().equals("pluscdsresults")) {
/*  82:106 */       UIUtil.gotoPage("womain", (AbstractMobileControl)event.getCreatingObject());
/*  83:    */     }
/*  84:109 */     MobileWOAppEventHandler wodsEvntHndr = (MobileWOAppEventHandler)UIUtil.getAppEventHandler();
/*  85:    */     
/*  86:111 */     MobileMboDataBean woDataBean = UIUtil.getCurrentScreen().getDataBean();
/*  87:    */     
/*  88:113 */     wodsEvntHndr.calcWoDsStatusBeforeSendSrv(event, woDataBean.getMobileMbo());
/*  89:    */     
/*  90:115 */     return super.done(event);
/*  91:    */   }
/*  92:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.mobilewo.WOMenuBarEventHandler
 * JD-Core Version:    0.7.0.1
 */