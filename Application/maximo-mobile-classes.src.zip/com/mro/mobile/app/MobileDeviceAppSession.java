/*   1:    */ package com.mro.mobile.app;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileMetaData;
/*   4:    */ import com.mro.mobile.ui.event.UIEventHandler;
/*   5:    */ import java.util.HashMap;
/*   6:    */ 
/*   7:    */ public class MobileDeviceAppSession
/*   8:    */ {
/*   9:    */   private static MobileDeviceAppSession session;
/*  10:    */   private HashMap sessionData;
/*  11:    */   private AbstractMobileDeviceApplication application;
/*  12:    */   private UIEventHandler eventHandler;
/*  13:    */   private MobileMetaData metadata;
/*  14:    */   private String appName;
/*  15:    */   
/*  16:    */   private MobileDeviceAppSession()
/*  17:    */   {
/*  18: 35 */     this.sessionData = new HashMap();
/*  19:    */   }
/*  20:    */   
/*  21: 44 */   private static ThreadLocal backgroundThreadIndicator = new ThreadLocal();
/*  22:    */   
/*  23:    */   public static MobileDeviceAppSession getSession()
/*  24:    */   {
/*  25: 47 */     if (session == null) {
/*  26: 48 */       session = new MobileDeviceAppSession();
/*  27:    */     }
/*  28: 50 */     return session;
/*  29:    */   }
/*  30:    */   
/*  31:    */   public void setAttribute(String name, Object value)
/*  32:    */   {
/*  33: 54 */     this.sessionData.put(name, value);
/*  34:    */   }
/*  35:    */   
/*  36:    */   public Object getAttribute(String name)
/*  37:    */   {
/*  38: 58 */     return this.sessionData.get(name);
/*  39:    */   }
/*  40:    */   
/*  41:    */   public void removeAttribute(String name)
/*  42:    */   {
/*  43: 62 */     this.sessionData.remove(name);
/*  44:    */   }
/*  45:    */   
/*  46:    */   public BasicMobileDeviceUIApplication getApplicationAsUIApplication()
/*  47:    */   {
/*  48: 66 */     return (BasicMobileDeviceUIApplication)this.application;
/*  49:    */   }
/*  50:    */   
/*  51:    */   public AbstractMobileDeviceApplication getApplication()
/*  52:    */   {
/*  53: 70 */     return this.application;
/*  54:    */   }
/*  55:    */   
/*  56:    */   public void setApplication(AbstractMobileDeviceApplication application)
/*  57:    */   {
/*  58: 74 */     this.application = application;
/*  59:    */   }
/*  60:    */   
/*  61:    */   public UIEventHandler getUIEventHandler()
/*  62:    */   {
/*  63: 78 */     return this.eventHandler;
/*  64:    */   }
/*  65:    */   
/*  66:    */   public AppEventHandler getUIEventHandlerAsAppEventHandler()
/*  67:    */   {
/*  68: 82 */     return (AppEventHandler)this.eventHandler;
/*  69:    */   }
/*  70:    */   
/*  71:    */   public void setUIEventHandler(UIEventHandler eventHandler)
/*  72:    */   {
/*  73: 86 */     this.eventHandler = eventHandler;
/*  74:    */   }
/*  75:    */   
/*  76:    */   public MobileMetaData getMobileMetadata()
/*  77:    */   {
/*  78: 90 */     return this.metadata;
/*  79:    */   }
/*  80:    */   
/*  81:    */   public void setMobileMetadata(MobileMetaData metadata)
/*  82:    */   {
/*  83: 94 */     this.metadata = metadata;
/*  84:    */   }
/*  85:    */   
/*  86:    */   public String getAppName()
/*  87:    */   {
/*  88: 98 */     return this.appName;
/*  89:    */   }
/*  90:    */   
/*  91:    */   public void setAppName(String appName)
/*  92:    */   {
/*  93:102 */     this.appName = appName;
/*  94:    */   }
/*  95:    */   
/*  96:    */   public void release()
/*  97:    */   {
/*  98:106 */     if (this.metadata != null) {
/*  99:107 */       this.metadata = null;
/* 100:    */     }
/* 101:109 */     if (this.sessionData != null)
/* 102:    */     {
/* 103:110 */       this.sessionData.clear();
/* 104:111 */       this.sessionData = null;
/* 105:    */     }
/* 106:113 */     if (this.application != null) {
/* 107:114 */       this.application = null;
/* 108:    */     }
/* 109:116 */     if (this.eventHandler != null) {
/* 110:117 */       this.eventHandler = null;
/* 111:    */     }
/* 112:119 */     session = null;
/* 113:    */   }
/* 114:    */   
/* 115:    */   public void setBackgroudThread(boolean b)
/* 116:    */   {
/* 117:129 */     backgroundThreadIndicator.set(Boolean.valueOf(b));
/* 118:    */   }
/* 119:    */   
/* 120:    */   public boolean isBackgroudThread()
/* 121:    */   {
/* 122:133 */     Object b = backgroundThreadIndicator.get();
/* 123:134 */     if ((b != null) && ((b instanceof Boolean)) && (((Boolean)b).booleanValue() == true)) {
/* 124:135 */       return true;
/* 125:    */     }
/* 126:137 */     return false;
/* 127:    */   }
/* 128:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.MobileDeviceAppSession
 * JD-Core Version:    0.7.0.1
 */