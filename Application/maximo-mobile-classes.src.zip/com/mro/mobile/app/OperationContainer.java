/*  1:   */ package com.mro.mobile.app;
/*  2:   */ 
/*  3:   */ public class OperationContainer
/*  4:   */ {
/*  5:23 */   private String operationName = null;
/*  6:24 */   private String MobileMboDataBeanName = null;
/*  7:25 */   private OperationHandler handler = null;
/*  8:   */   
/*  9:   */   public OperationContainer(String operationName, String mobileMboDataBeanName, OperationHandler handler)
/* 10:   */   {
/* 11:33 */     this.operationName = operationName;
/* 12:34 */     this.MobileMboDataBeanName = mobileMboDataBeanName;
/* 13:35 */     this.handler = handler;
/* 14:   */   }
/* 15:   */   
/* 16:   */   public OperationContainer(String operationName, OperationHandler handler)
/* 17:   */   {
/* 18:45 */     this.operationName = operationName;
/* 19:46 */     this.MobileMboDataBeanName = null;
/* 20:47 */     this.handler = handler;
/* 21:   */   }
/* 22:   */   
/* 23:   */   public OperationHandler getHandler()
/* 24:   */   {
/* 25:53 */     return this.handler;
/* 26:   */   }
/* 27:   */   
/* 28:   */   public void setHandler(OperationHandler handler)
/* 29:   */   {
/* 30:59 */     this.handler = handler;
/* 31:   */   }
/* 32:   */   
/* 33:   */   public String getMobileMboDataBeanName()
/* 34:   */   {
/* 35:65 */     return this.MobileMboDataBeanName;
/* 36:   */   }
/* 37:   */   
/* 38:   */   public void setMobileMboDataBeanName(String mobileMboDataBeanName)
/* 39:   */   {
/* 40:71 */     this.MobileMboDataBeanName = mobileMboDataBeanName;
/* 41:   */   }
/* 42:   */   
/* 43:   */   public String getOperationName()
/* 44:   */   {
/* 45:77 */     return this.operationName;
/* 46:   */   }
/* 47:   */   
/* 48:   */   public void setOperationName(String operationName)
/* 49:   */   {
/* 50:83 */     this.operationName = operationName;
/* 51:   */   }
/* 52:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.OperationContainer
 * JD-Core Version:    0.7.0.1
 */