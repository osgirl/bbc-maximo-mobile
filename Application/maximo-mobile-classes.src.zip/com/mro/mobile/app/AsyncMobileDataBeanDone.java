/*  1:   */ package com.mro.mobile.app;
/*  2:   */ 
/*  3:   */ import com.mro.mobile.MobileApplicationException;
/*  4:   */ import com.mro.mobile.app.async.AsyncEventHandlerSupport;
/*  5:   */ import com.mro.mobile.ui.MobileMboDataBean;
/*  6:   */ import com.mro.mobile.ui.event.UIEvent;
/*  7:   */ import com.mro.mobile.ui.res.UIUtil;
/*  8:   */ 
/*  9:   */ public class AsyncMobileDataBeanDone
/* 10:   */   extends AsyncEventHandlerSupport
/* 11:   */ {
/* 12:   */   public boolean doRealWok(UIEvent event)
/* 13:   */     throws MobileApplicationException
/* 14:   */   {
/* 15:25 */     super.updateProgressBar("submitdata", null, event);
/* 16:26 */     if (getDataBeanOf(event) != null) {
/* 17:27 */       getDataBeanOf(event).done();
/* 18:   */     }
/* 19:29 */     return true;
/* 20:   */   }
/* 21:   */   
/* 22:   */   public void postRealWork(UIEvent event)
/* 23:   */     throws MobileApplicationException
/* 24:   */   {}
/* 25:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.AsyncMobileDataBeanDone
 * JD-Core Version:    0.7.0.1
 */