/*    1:     */ package com.mro.mobile.app;
/*    2:     */ 
/*    3:     */ import com.mro.mobile.MobileApplicationException;
/*    4:     */ import com.mro.mobile.mbo.MobileMboAttributeInfo;
/*    5:     */ import com.mro.mobile.ui.MobileMboDataFormatter;
/*    6:     */ import java.text.DateFormat;
/*    7:     */ import java.text.DateFormatSymbols;
/*    8:     */ import java.text.DecimalFormatSymbols;
/*    9:     */ import java.text.NumberFormat;
/*   10:     */ import java.text.ParseException;
/*   11:     */ import java.text.ParsePosition;
/*   12:     */ import java.text.SimpleDateFormat;
/*   13:     */ import java.util.Calendar;
/*   14:     */ import java.util.Date;
/*   15:     */ import java.util.Locale;
/*   16:     */ import java.util.StringTokenizer;
/*   17:     */ import java.util.TimeZone;
/*   18:     */ 
/*   19:     */ public class DefaultMobileMboDataFormatter
/*   20:     */   extends MobileMboDataFormatter
/*   21:     */ {
/*   22:     */   public static final int UNLIMITEDPLACES = 8;
/*   23:     */   public static final double MINSPERHOUR = 60.0D;
/*   24:     */   public static final String TIMESEP = ":";
/*   25:     */   public static final String DATESEP = "/";
/*   26:     */   public static final char YEARCHAR = 'y';
/*   27:     */   public static final char MONTHCHAR = 'M';
/*   28:     */   public static final char DAYCHAR = 'd';
/*   29:     */   public static final char AMCHAR = 'a';
/*   30:     */   public static final char MINCHAR = 'm';
/*   31:     */   public static final char HOUR24CHAR = 'H';
/*   32:     */   public static final char HOUR12CHAR = 'h';
/*   33:     */   public static final char SECONDCHAR = 's';
/*   34:     */   public static final String SEPERATORS = " /-.:";
/*   35:     */   
/*   36:     */   public String formatInternalToDispaly(String value, MobileMboAttributeInfo attrInfo)
/*   37:     */     throws MobileApplicationException
/*   38:     */   {
/*   39:  56 */     if (value == null) {
/*   40:  57 */       return "";
/*   41:     */     }
/*   42:  59 */     if (value.trim().length() == 0) {
/*   43:  61 */       return "";
/*   44:     */     }
/*   45:  64 */     int dataType = attrInfo.getDataType();
/*   46:  65 */     Locale l = Locale.getDefault();
/*   47:  66 */     TimeZone tz = TimeZone.getDefault();
/*   48:     */     
/*   49:  68 */     String formattedValue = value;
/*   50:  70 */     switch (dataType)
/*   51:     */     {
/*   52:     */     case 1: 
/*   53:     */     case 2: 
/*   54:     */     case 3: 
/*   55:     */       break;
/*   56:     */     case 4: 
/*   57:  80 */       long longValue = convertInternalStringToLong(value);
/*   58:  81 */       formattedValue = longToString(longValue, l);
/*   59:  82 */       break;
/*   60:     */     case 5: 
/*   61:  87 */       long longValue = convertInternalStringToLong(value);
/*   62:  88 */       formattedValue = longToString(longValue, l);
/*   63:  89 */       break;
/*   64:     */     case 6: 
/*   65:     */     case 7: 
/*   66:  95 */       double doubleValue = convertInternalStringToDouble(value);
/*   67:  96 */       formattedValue = doubleToString(doubleValue, attrInfo.getScale(), l);
/*   68:  98 */       if (formattedValue.length() > attrInfo.getLength()) {
/*   69:  99 */         throw new MobileApplicationException("formattedmaximumlength");
/*   70:     */       }
/*   71:     */       break;
/*   72:     */     case 13: 
/*   73: 106 */       double doubleValue = convertInternalStringToDouble(value);
/*   74: 107 */       formattedValue = doubleToDuration(doubleValue, l);
/*   75: 108 */       break;
/*   76:     */     case 8: 
/*   77: 113 */       boolean booleanValue = convertInternalStringToBoolean(value);
/*   78: 114 */       if (booleanValue) {
/*   79: 116 */         formattedValue = "1";
/*   80:     */       } else {
/*   81: 120 */         formattedValue = "0";
/*   82:     */       }
/*   83: 122 */       break;
/*   84:     */     case 9: 
/*   85: 127 */       long longValue = convertInternalStringToLong(value);
/*   86: 128 */       formattedValue = dateToString(new Date(longValue), l, tz);
/*   87: 129 */       break;
/*   88:     */     case 11: 
/*   89: 134 */       long longValue = convertInternalStringToLong(value);
/*   90: 135 */       formattedValue = dateTimeToString(new Date(longValue), l, tz);
/*   91: 136 */       break;
/*   92:     */     case 10: 
/*   93: 141 */       long longValue = convertInternalStringToLong(value);
/*   94: 142 */       formattedValue = timeToString(new Date(longValue), l, tz);
/*   95: 143 */       break;
/*   96:     */     case 12: 
/*   97: 148 */       throw new MobileApplicationException("notsupported");
/*   98:     */     }
/*   99: 155 */     return formattedValue;
/*  100:     */   }
/*  101:     */   
/*  102:     */   public String formatDisplayToInternal(String value, MobileMboAttributeInfo attrInfo)
/*  103:     */     throws MobileApplicationException
/*  104:     */   {
/*  105: 162 */     return formatDisplayToInternal(value, attrInfo, true);
/*  106:     */   }
/*  107:     */   
/*  108:     */   public String formatDisplayToInternal(String value, MobileMboAttributeInfo attrInfo, boolean validateLength)
/*  109:     */     throws MobileApplicationException
/*  110:     */   {
/*  111: 169 */     if (value == null) {
/*  112: 170 */       return "";
/*  113:     */     }
/*  114: 172 */     if (value.trim().length() == 0) {
/*  115: 174 */       return "";
/*  116:     */     }
/*  117: 177 */     int dataType = attrInfo.getDataType();
/*  118: 178 */     Locale l = Locale.getDefault();
/*  119: 179 */     TimeZone tz = TimeZone.getDefault();
/*  120:     */     
/*  121: 181 */     String internalValue = value;
/*  122: 183 */     switch (dataType)
/*  123:     */     {
/*  124:     */     case 1: 
/*  125: 188 */       if ((validateLength) && (value.length() > attrInfo.getLength())) {
/*  126: 190 */         throw new MobileApplicationException("maximumlength");
/*  127:     */       }
/*  128:     */       break;
/*  129:     */     case 2: 
/*  130: 198 */       if ((validateLength) && (value.length() > attrInfo.getLength())) {
/*  131: 200 */         throw new MobileApplicationException("maximumlength");
/*  132:     */       }
/*  133: 202 */       internalValue = value.toUpperCase();
/*  134: 203 */       break;
/*  135:     */     case 3: 
/*  136: 208 */       if ((validateLength) && (value.length() > attrInfo.getLength())) {
/*  137: 210 */         throw new MobileApplicationException("maximumlength");
/*  138:     */       }
/*  139: 212 */       internalValue = value.toLowerCase();
/*  140: 213 */       break;
/*  141:     */     case 4: 
/*  142: 218 */       if (value.indexOf(',') != -1)
/*  143:     */       {
/*  144: 220 */         StringBuffer buffer = new StringBuffer();
/*  145: 221 */         StringTokenizer st = new StringTokenizer(value, ",");
/*  146: 222 */         while (st.hasMoreTokens())
/*  147:     */         {
/*  148: 224 */           String token = st.nextToken();
/*  149: 225 */           buffer.append(Long.toString(stringToLong(token, l)));
/*  150:     */         }
/*  151: 228 */         internalValue = buffer.toString();
/*  152:     */       }
/*  153:     */       else
/*  154:     */       {
/*  155: 233 */         internalValue = Long.toString(stringToLong(value, l));
/*  156:     */       }
/*  157: 236 */       break;
/*  158:     */     case 5: 
/*  159: 240 */       if (value.indexOf(',') != -1)
/*  160:     */       {
/*  161: 242 */         StringBuffer buffer = new StringBuffer();
/*  162: 243 */         StringTokenizer st = new StringTokenizer(value, ",");
/*  163: 244 */         while (st.hasMoreTokens())
/*  164:     */         {
/*  165: 246 */           String token = st.nextToken();
/*  166: 247 */           buffer.append(Long.toString(stringToLong(token, l)));
/*  167:     */         }
/*  168: 250 */         internalValue = buffer.toString();
/*  169:     */       }
/*  170:     */       else
/*  171:     */       {
/*  172: 255 */         internalValue = Long.toString(stringToLong(value, l));
/*  173:     */       }
/*  174: 258 */       break;
/*  175:     */     case 6: 
/*  176:     */     case 7: 
/*  177: 264 */       internalValue = Double.toString(stringToDouble(value, l));
/*  178: 265 */       break;
/*  179:     */     case 13: 
/*  180: 270 */       internalValue = "" + durationToDouble(value, l);
/*  181: 271 */       break;
/*  182:     */     case 8: 
/*  183: 275 */       boolean booleanValue = convertDisplayStringToBoolean(value);
/*  184: 277 */       if (booleanValue) {
/*  185: 279 */         internalValue = "1";
/*  186:     */       } else {
/*  187: 283 */         internalValue = "0";
/*  188:     */       }
/*  189: 285 */       break;
/*  190:     */     case 9: 
/*  191: 290 */       internalValue = Long.toString(stringToDate(value, l, tz).getTime());
/*  192: 291 */       break;
/*  193:     */     case 11: 
/*  194: 296 */       internalValue = Long.toString(stringToDateTime(value, l, tz).getTime());
/*  195: 297 */       break;
/*  196:     */     case 10: 
/*  197: 302 */       internalValue = Long.toString(stringToTime(value, l, tz).getTime());
/*  198: 303 */       break;
/*  199:     */     case 12: 
/*  200: 308 */       throw new MobileApplicationException("notsupported");
/*  201:     */     }
/*  202: 314 */     return internalValue;
/*  203:     */   }
/*  204:     */   
/*  205:     */   public Date convertStringToDate(String value)
/*  206:     */     throws MobileApplicationException
/*  207:     */   {
/*  208: 319 */     return stringToDate(value, Locale.getDefault(), TimeZone.getDefault());
/*  209:     */   }
/*  210:     */   
/*  211:     */   public Date convertStringToDateTime(String value)
/*  212:     */     throws MobileApplicationException
/*  213:     */   {
/*  214: 324 */     return stringToDateTime(value, Locale.getDefault(), TimeZone.getDefault());
/*  215:     */   }
/*  216:     */   
/*  217:     */   public Date convertStringToTime(String value)
/*  218:     */     throws MobileApplicationException
/*  219:     */   {
/*  220: 329 */     return stringToTime(value, Locale.getDefault(), TimeZone.getDefault());
/*  221:     */   }
/*  222:     */   
/*  223:     */   protected long convertInternalStringToLong(String value)
/*  224:     */     throws MobileApplicationException
/*  225:     */   {
/*  226:     */     try
/*  227:     */     {
/*  228: 337 */       return Long.parseLong(value);
/*  229:     */     }
/*  230:     */     catch (NumberFormatException e)
/*  231:     */     {
/*  232: 342 */       throw new MobileApplicationException("invalidnumber");
/*  233:     */     }
/*  234:     */   }
/*  235:     */   
/*  236:     */   protected double convertInternalStringToDouble(String value)
/*  237:     */     throws MobileApplicationException
/*  238:     */   {
/*  239:     */     try
/*  240:     */     {
/*  241: 350 */       return Double.parseDouble(value);
/*  242:     */     }
/*  243:     */     catch (NumberFormatException e)
/*  244:     */     {
/*  245: 355 */       throw new MobileApplicationException("invalidnumber");
/*  246:     */     }
/*  247:     */   }
/*  248:     */   
/*  249:     */   protected boolean convertInternalStringToBoolean(String value)
/*  250:     */     throws MobileApplicationException
/*  251:     */   {
/*  252: 361 */     if (value.equals("1")) {
/*  253: 363 */       return true;
/*  254:     */     }
/*  255: 366 */     return false;
/*  256:     */   }
/*  257:     */   
/*  258:     */   protected boolean convertDisplayStringToBoolean(String value)
/*  259:     */     throws MobileApplicationException
/*  260:     */   {
/*  261:     */     try
/*  262:     */     {
/*  263: 373 */       int boolValue = Integer.parseInt(value);
/*  264: 374 */       if (boolValue == 1) {
/*  265: 376 */         return true;
/*  266:     */       }
/*  267: 380 */       return false;
/*  268:     */     }
/*  269:     */     catch (NumberFormatException e)
/*  270:     */     {
/*  271: 385 */       throw new MobileApplicationException("invalidboolean");
/*  272:     */     }
/*  273:     */   }
/*  274:     */   
/*  275:     */   public static int stringToInt(String s)
/*  276:     */     throws MobileApplicationException
/*  277:     */   {
/*  278: 391 */     return stringToInt(s, Locale.getDefault());
/*  279:     */   }
/*  280:     */   
/*  281:     */   public static int stringToInt(String s, Locale l)
/*  282:     */     throws MobileApplicationException
/*  283:     */   {
/*  284: 400 */     if (s == null) {
/*  285: 401 */       throw new MobileApplicationException("invalidnumber");
/*  286:     */     }
/*  287: 403 */     Number num = null;
/*  288:     */     try
/*  289:     */     {
/*  290: 407 */       if (isZero(s, l)) {
/*  291: 408 */         return 0;
/*  292:     */       }
/*  293: 410 */       NumberFormat fmt = NumberFormat.getInstance(l);
/*  294: 411 */       fmt.setParseIntegerOnly(true);
/*  295:     */       
/*  296: 413 */       ParsePosition parsePosition = new ParsePosition(0);
/*  297: 414 */       num = fmt.parse(s, parsePosition);
/*  298: 416 */       if (parsePosition.getIndex() != s.length()) {
/*  299: 418 */         throw new ParseException("parseerror", 0);
/*  300:     */       }
/*  301: 421 */       return num.intValue();
/*  302:     */     }
/*  303:     */     catch (Exception e)
/*  304:     */     {
/*  305: 425 */       throw new MobileApplicationException("invalidnumber");
/*  306:     */     }
/*  307:     */   }
/*  308:     */   
/*  309:     */   public static String longToString(long longValue, Locale l)
/*  310:     */     throws MobileApplicationException
/*  311:     */   {
/*  312:     */     try
/*  313:     */     {
/*  314: 434 */       NumberFormat fmt = NumberFormat.getInstance(l);
/*  315: 435 */       return fmt.format(longValue);
/*  316:     */     }
/*  317:     */     catch (Exception ex)
/*  318:     */     {
/*  319: 439 */       throw new MobileApplicationException("invalidnumber");
/*  320:     */     }
/*  321:     */   }
/*  322:     */   
/*  323:     */   public static long stringToLong(String s, Locale l)
/*  324:     */     throws MobileApplicationException
/*  325:     */   {
/*  326: 449 */     if (s == null) {
/*  327: 450 */       throw new MobileApplicationException("invalidnumber");
/*  328:     */     }
/*  329: 453 */     if (isZero(s, l)) {
/*  330: 454 */       return 0L;
/*  331:     */     }
/*  332: 456 */     Number num = null;
/*  333:     */     try
/*  334:     */     {
/*  335: 459 */       NumberFormat fmt = NumberFormat.getInstance(l);
/*  336: 460 */       fmt.setParseIntegerOnly(true);
/*  337:     */       
/*  338: 462 */       ParsePosition parsePosition = new ParsePosition(0);
/*  339: 463 */       num = fmt.parse(s, parsePosition);
/*  340: 465 */       if (parsePosition.getIndex() != s.length()) {
/*  341: 467 */         throw new ParseException("parseerror", 0);
/*  342:     */       }
/*  343: 470 */       return num.longValue();
/*  344:     */     }
/*  345:     */     catch (Exception e)
/*  346:     */     {
/*  347: 474 */       throw new MobileApplicationException("invalidnumber");
/*  348:     */     }
/*  349:     */   }
/*  350:     */   
/*  351:     */   public static String doubleToString(double d, int places, Locale l)
/*  352:     */     throws MobileApplicationException
/*  353:     */   {
/*  354:     */     try
/*  355:     */     {
/*  356: 487 */       NumberFormat fmt = NumberFormat.getInstance(l);
/*  357: 488 */       fmt.setMaximumFractionDigits(places);
/*  358: 489 */       if (places != 8) {
/*  359: 491 */         fmt.setMinimumFractionDigits(places);
/*  360:     */       }
/*  361: 493 */       return fmt.format(d);
/*  362:     */     }
/*  363:     */     catch (Exception e)
/*  364:     */     {
/*  365: 497 */       throw new MobileApplicationException("invalidnumber");
/*  366:     */     }
/*  367:     */   }
/*  368:     */   
/*  369:     */   public static String doubleToInternalString(double d, int places, Locale l)
/*  370:     */     throws MobileApplicationException
/*  371:     */   {
/*  372:     */     try
/*  373:     */     {
/*  374: 512 */       NumberFormat fmt = NumberFormat.getInstance(l);
/*  375: 513 */       fmt.setGroupingUsed(false);
/*  376: 514 */       fmt.setMaximumFractionDigits(places);
/*  377: 515 */       if (places != 8) {
/*  378: 517 */         fmt.setMinimumFractionDigits(places);
/*  379:     */       }
/*  380: 519 */       return fmt.format(d);
/*  381:     */     }
/*  382:     */     catch (Exception e)
/*  383:     */     {
/*  384: 523 */       throw new MobileApplicationException("invalidnumber");
/*  385:     */     }
/*  386:     */   }
/*  387:     */   
/*  388:     */   public static double stringToDouble(String s)
/*  389:     */     throws MobileApplicationException
/*  390:     */   {
/*  391: 529 */     return stringToDouble(s, Locale.getDefault());
/*  392:     */   }
/*  393:     */   
/*  394:     */   public static double stringToDouble(String s, Locale l)
/*  395:     */     throws MobileApplicationException
/*  396:     */   {
/*  397: 538 */     if (s == null) {
/*  398: 539 */       throw new MobileApplicationException("invalidnumber");
/*  399:     */     }
/*  400: 542 */     if (isZero(s, l)) {
/*  401: 543 */       return 0.0D;
/*  402:     */     }
/*  403:     */     try
/*  404:     */     {
/*  405: 551 */       return NumberFormat.getInstance(l).parse(s).doubleValue();
/*  406:     */     }
/*  407:     */     catch (Exception e)
/*  408:     */     {
/*  409:     */       try
/*  410:     */       {
/*  411: 560 */         NumberFormat fmt = NumberFormat.getInstance(l);
/*  412: 561 */         Number num = null;
/*  413:     */         
/*  414:     */ 
/*  415: 564 */         ParsePosition parsePosition = new ParsePosition(0);
/*  416: 565 */         num = fmt.parse(s, parsePosition);
/*  417: 567 */         if (parsePosition.getIndex() != s.length())
/*  418:     */         {
/*  419: 571 */           fmt = NumberFormat.getInstance(Locale.US);
/*  420: 572 */           parsePosition = new ParsePosition(0);
/*  421: 573 */           num = fmt.parse(s, parsePosition);
/*  422: 574 */           if (parsePosition.getIndex() != s.length()) {
/*  423: 576 */             throw new ParseException("parseerror", 0);
/*  424:     */           }
/*  425:     */         }
/*  426: 586 */         validateConversion(doubleToString(num.doubleValue(), 4, l), num.longValue());
/*  427:     */         
/*  428: 588 */         return num.doubleValue();
/*  429:     */       }
/*  430:     */       catch (ParseException e)
/*  431:     */       {
/*  432: 593 */         throw new MobileApplicationException("invalidnumber");
/*  433:     */       }
/*  434:     */     }
/*  435:     */   }
/*  436:     */   
/*  437:     */   private static void validateConversion(String s, long integerPart)
/*  438:     */     throws MobileApplicationException
/*  439:     */   {
/*  440: 605 */     for (int i = s.length() - 1; i >= 0; i--)
/*  441:     */     {
/*  442: 606 */       char c = s.charAt(i);
/*  443: 607 */       if ((c < '0') || (c > '9'))
/*  444:     */       {
/*  445: 608 */         String number = s.substring(0, i);
/*  446: 609 */         char[] clean = new char[number.length()];
/*  447: 610 */         int k = 0;
/*  448: 611 */         for (int j = 0; j < clean.length; j++)
/*  449:     */         {
/*  450: 612 */           char aux = number.charAt(j);
/*  451: 613 */           if (((aux >= '0') && (aux <= '9')) || (aux == '-')) {
/*  452: 614 */             clean[(k++)] = aux;
/*  453:     */           }
/*  454:     */         }
/*  455: 617 */         number = new String(clean, 0, k);
/*  456: 618 */         long value = Long.parseLong(number);
/*  457: 619 */         if (integerPart == value) {
/*  458:     */           break;
/*  459:     */         }
/*  460: 620 */         throw new MobileApplicationException("invalidnumber");
/*  461:     */       }
/*  462:     */     }
/*  463:     */   }
/*  464:     */   
/*  465:     */   public static double durationToDouble(String s)
/*  466:     */     throws MobileApplicationException
/*  467:     */   {
/*  468: 637 */     return durationToDouble(s, Locale.getDefault());
/*  469:     */   }
/*  470:     */   
/*  471:     */   public static double durationToDouble(String s, Locale l)
/*  472:     */     throws MobileApplicationException
/*  473:     */   {
/*  474: 646 */     int hours = 0;
/*  475: 647 */     int mins = 0;
/*  476: 648 */     boolean minus = false;
/*  477:     */     
/*  478: 650 */     char DECIMALSEP = new DecimalFormatSymbols(l).getDecimalSeparator();
/*  479:     */     try
/*  480:     */     {
/*  481: 656 */       if (s.indexOf(":") == -1) {
/*  482: 657 */         return stringToDouble(s, l);
/*  483:     */       }
/*  484:     */     }
/*  485:     */     catch (Exception ex)
/*  486:     */     {
/*  487: 661 */       throw new MobileApplicationException("invalidduration");
/*  488:     */     }
/*  489: 665 */     if (s.indexOf(DECIMALSEP) != -1) {
/*  490: 666 */       throw new MobileApplicationException("invalidduration");
/*  491:     */     }
/*  492: 669 */     if (s.startsWith("-"))
/*  493:     */     {
/*  494: 671 */       s = s.substring(1);
/*  495: 672 */       minus = true;
/*  496:     */     }
/*  497: 675 */     StringTokenizer st = new StringTokenizer(s, ":");
/*  498: 676 */     if (st.hasMoreTokens())
/*  499:     */     {
/*  500: 678 */       hours = stringToInt(st.nextToken(), l);
/*  501: 679 */       if (st.hasMoreTokens())
/*  502:     */       {
/*  503: 680 */         mins = stringToInt(st.nextToken(), l);
/*  504:     */       }
/*  505: 681 */       else if (s.startsWith(":"))
/*  506:     */       {
/*  507: 683 */         mins = hours;
/*  508: 684 */         hours = 0;
/*  509:     */       }
/*  510:     */     }
/*  511: 688 */     double dl = 0.0D;
/*  512: 689 */     if (minus)
/*  513:     */     {
/*  514: 691 */       double tmpDl = hours + mins / 60.0D;
/*  515: 692 */       String tmpStr = "-" + new Double(tmpDl).toString();
/*  516: 693 */       dl = new Double(tmpStr).doubleValue();
/*  517:     */     }
/*  518:     */     else
/*  519:     */     {
/*  520: 697 */       dl = hours + mins / 60.0D;
/*  521:     */     }
/*  522: 699 */     return dl;
/*  523:     */   }
/*  524:     */   
/*  525:     */   public static String doubleToDuration(double d)
/*  526:     */   {
/*  527: 708 */     return doubleToDuration(d, Locale.getDefault());
/*  528:     */   }
/*  529:     */   
/*  530:     */   public static String doubleToDuration(double d, Locale l)
/*  531:     */   {
/*  532: 716 */     boolean minus = false;
/*  533: 719 */     if (d < 0.0D)
/*  534:     */     {
/*  535: 721 */       d = Math.abs(d);
/*  536: 722 */       minus = true;
/*  537:     */     }
/*  538: 725 */     int hours = (int)d;
/*  539:     */     
/*  540: 727 */     int mins = (int)Math.round((d - hours) * 60.0D);
/*  541: 728 */     String retStr = null;
/*  542: 729 */     if (mins < 10) {
/*  543: 730 */       retStr = hours + ":" + "0" + mins;
/*  544:     */     } else {
/*  545: 732 */       retStr = hours + ":" + mins;
/*  546:     */     }
/*  547: 734 */     if (minus) {
/*  548: 735 */       retStr = "-" + retStr;
/*  549:     */     }
/*  550: 737 */     return retStr;
/*  551:     */   }
/*  552:     */   
/*  553:     */   public static String dateToStringFull(Date d)
/*  554:     */     throws MobileApplicationException
/*  555:     */   {
/*  556: 745 */     return dateToString(d, Locale.getDefault(), TimeZone.getDefault(), 0);
/*  557:     */   }
/*  558:     */   
/*  559:     */   public static String dateToString(Date d)
/*  560:     */     throws MobileApplicationException
/*  561:     */   {
/*  562: 750 */     return dateToString(d, Locale.getDefault(), TimeZone.getDefault());
/*  563:     */   }
/*  564:     */   
/*  565:     */   public static String dateToString(Date d, Locale l, TimeZone tz)
/*  566:     */     throws MobileApplicationException
/*  567:     */   {
/*  568: 755 */     return dateToString(d, l, tz, 3);
/*  569:     */   }
/*  570:     */   
/*  571:     */   private static String dateToString(Date d, Locale l, TimeZone tz, int dateFormatStylePattern)
/*  572:     */     throws MobileApplicationException
/*  573:     */   {
/*  574:     */     try
/*  575:     */     {
/*  576: 762 */       Calendar c = Calendar.getInstance(tz, l);
/*  577: 763 */       c.setLenient(false);
/*  578: 764 */       c.setTime(d);
/*  579: 765 */       String dateFormat = null;
/*  580: 766 */       dateFormat = ((SimpleDateFormat)DateFormat.getDateInstance(dateFormatStylePattern, l)).toPattern();
/*  581:     */       
/*  582: 768 */       SimpleDateFormat df = new SimpleDateFormat(dateFormat, l);
/*  583:     */       
/*  584: 770 */       df.setTimeZone(tz);
/*  585:     */       
/*  586: 772 */       return df.format(c.getTime());
/*  587:     */     }
/*  588:     */     catch (Exception e)
/*  589:     */     {
/*  590: 776 */       throw buildInvalidDateException();
/*  591:     */     }
/*  592:     */   }
/*  593:     */   
/*  594:     */   public static Date stringToDate(String s)
/*  595:     */     throws MobileApplicationException
/*  596:     */   {
/*  597: 782 */     return stringToDate(s, Locale.getDefault(), TimeZone.getDefault());
/*  598:     */   }
/*  599:     */   
/*  600:     */   public static Date stringToDate(String s, Locale l, TimeZone tz)
/*  601:     */     throws MobileApplicationException
/*  602:     */   {
/*  603: 788 */     if (s == null) {
/*  604: 789 */       throw buildInvalidDateException();
/*  605:     */     }
/*  606:     */     try
/*  607:     */     {
/*  608: 793 */       String dateFormat = null;
/*  609: 794 */       dateFormat = ((SimpleDateFormat)DateFormat.getDateInstance(3, l)).toPattern();
/*  610: 795 */       SimpleDateFormat df = new SimpleDateFormat(dateFormat, l);
/*  611:     */       
/*  612: 797 */       int[] value = parseDateTime(s, l, df.toPattern());
/*  613:     */       
/*  614: 799 */       Calendar c = Calendar.getInstance(tz, l);
/*  615: 800 */       c.setLenient(false);
/*  616:     */       
/*  617: 802 */       c.set(value[2], value[1] - 1, value[0], 1, 0, 0);
/*  618: 803 */       c.set(14, 0);
/*  619: 804 */       return c.getTime();
/*  620:     */     }
/*  621:     */     catch (Exception e)
/*  622:     */     {
/*  623: 808 */       throw buildInvalidDateException();
/*  624:     */     }
/*  625:     */   }
/*  626:     */   
/*  627:     */   public static String dateTimeToString(Date d)
/*  628:     */     throws MobileApplicationException
/*  629:     */   {
/*  630: 814 */     return dateTimeToString(d, Locale.getDefault(), TimeZone.getDefault());
/*  631:     */   }
/*  632:     */   
/*  633:     */   public static String dateTimeToString(Date d, Locale l, TimeZone tz)
/*  634:     */     throws MobileApplicationException
/*  635:     */   {
/*  636:     */     try
/*  637:     */     {
/*  638: 821 */       String timeFormat = null;
/*  639: 822 */       String dateFormat = null;
/*  640:     */       
/*  641: 824 */       dateFormat = ((SimpleDateFormat)DateFormat.getDateInstance(3, l)).toPattern();
/*  642: 825 */       timeFormat = ((SimpleDateFormat)DateFormat.getTimeInstance(3, l)).toPattern();
/*  643:     */       
/*  644: 827 */       SimpleDateFormat df = new SimpleDateFormat(dateFormat + " " + timeFormat, l);
/*  645:     */       
/*  646: 829 */       df.setTimeZone(tz);
/*  647: 830 */       return df.format(d);
/*  648:     */     }
/*  649:     */     catch (Exception e)
/*  650:     */     {
/*  651: 834 */       throw buildInvalidDateTimeException();
/*  652:     */     }
/*  653:     */   }
/*  654:     */   
/*  655:     */   public static Date stringToDateTime(String s)
/*  656:     */     throws MobileApplicationException
/*  657:     */   {
/*  658: 840 */     return stringToDateTime(s, Locale.getDefault(), TimeZone.getDefault());
/*  659:     */   }
/*  660:     */   
/*  661:     */   public static Date stringToDateTime(String s, Locale l, TimeZone tz)
/*  662:     */     throws MobileApplicationException
/*  663:     */   {
/*  664:     */     try
/*  665:     */     {
/*  666: 847 */       String timeFormat = null;
/*  667: 848 */       String dateFormat = null;
/*  668: 849 */       dateFormat = ((SimpleDateFormat)DateFormat.getDateInstance(3, l)).toPattern();
/*  669: 850 */       timeFormat = ((SimpleDateFormat)DateFormat.getTimeInstance(2, l)).toPattern();
/*  670: 851 */       SimpleDateFormat df = new SimpleDateFormat(dateFormat + " " + timeFormat, l);
/*  671:     */       
/*  672:     */ 
/*  673: 854 */       int[] value = parseDateTime(s, l, df.toPattern());
/*  674:     */       
/*  675: 856 */       Calendar c = Calendar.getInstance(l);
/*  676: 857 */       c.setTimeZone(tz);
/*  677: 858 */       c.setLenient(false);
/*  678: 859 */       c.set(5, value[0]);
/*  679: 860 */       c.set(2, value[1] - 1);
/*  680: 861 */       c.set(1, value[2]);
/*  681: 862 */       c.set(11, value[3]);
/*  682: 863 */       c.set(12, value[4]);
/*  683: 864 */       c.set(13, 0);
/*  684:     */       
/*  685: 866 */       c.set(14, 0);
/*  686:     */       
/*  687: 868 */       return c.getTime();
/*  688:     */     }
/*  689:     */     catch (Exception e)
/*  690:     */     {
/*  691: 872 */       throw buildInvalidDateTimeException();
/*  692:     */     }
/*  693:     */   }
/*  694:     */   
/*  695:     */   public static String timeToString(Date d, Locale l, TimeZone tz)
/*  696:     */     throws MobileApplicationException
/*  697:     */   {
/*  698:     */     try
/*  699:     */     {
/*  700: 880 */       String timeFormat = null;
/*  701: 881 */       timeFormat = ((SimpleDateFormat)DateFormat.getTimeInstance(3, l)).toPattern();
/*  702: 882 */       SimpleDateFormat df = new SimpleDateFormat(timeFormat, l);
/*  703:     */       
/*  704: 884 */       df.setTimeZone(tz);
/*  705: 885 */       return df.format(d);
/*  706:     */     }
/*  707:     */     catch (Exception e)
/*  708:     */     {
/*  709: 889 */       throw buildInvalidTimeException();
/*  710:     */     }
/*  711:     */   }
/*  712:     */   
/*  713:     */   private static MobileApplicationException buildInvalidTimeException()
/*  714:     */   {
/*  715:     */     try
/*  716:     */     {
/*  717: 897 */       String exampleTime = timeToString(new Date(), Locale.getDefault(), TimeZone.getDefault());
/*  718: 898 */       return new MobileApplicationException("invalidtimeparam", new Object[] { exampleTime });
/*  719:     */     }
/*  720:     */     catch (Exception ex) {}
/*  721: 905 */     return new MobileApplicationException("invalidtime");
/*  722:     */   }
/*  723:     */   
/*  724:     */   private static MobileApplicationException buildInvalidDateException()
/*  725:     */   {
/*  726:     */     try
/*  727:     */     {
/*  728: 912 */       String exampleDate = dateToString(new Date(), Locale.getDefault(), TimeZone.getDefault());
/*  729: 913 */       return new MobileApplicationException("invaliddateparam", new Object[] { exampleDate });
/*  730:     */     }
/*  731:     */     catch (Exception ex) {}
/*  732: 920 */     return new MobileApplicationException("invaliddate");
/*  733:     */   }
/*  734:     */   
/*  735:     */   private static MobileApplicationException buildInvalidDateTimeException()
/*  736:     */   {
/*  737:     */     try
/*  738:     */     {
/*  739: 927 */       String exampleDateTime = dateTimeToString(new Date(), Locale.getDefault(), TimeZone.getDefault());
/*  740: 928 */       return new MobileApplicationException("invaliddatetimeparam", new Object[] { exampleDateTime });
/*  741:     */     }
/*  742:     */     catch (Exception ex) {}
/*  743: 935 */     return new MobileApplicationException("invaliddatetime");
/*  744:     */   }
/*  745:     */   
/*  746:     */   public static Date stringToTime(String s)
/*  747:     */     throws MobileApplicationException
/*  748:     */   {
/*  749: 940 */     return stringToTime(s, Locale.getDefault(), TimeZone.getDefault());
/*  750:     */   }
/*  751:     */   
/*  752:     */   public static Date stringToTime(String s, Locale l, TimeZone tz)
/*  753:     */     throws MobileApplicationException
/*  754:     */   {
/*  755: 945 */     boolean isError = false;
/*  756:     */     
/*  757: 947 */     DecimalFormatSymbols symb = new DecimalFormatSymbols(l);
/*  758: 948 */     Character minusSign = new Character(symb.getMinusSign());
/*  759: 950 */     if (minusSign != null) {
/*  760: 952 */       if (s.startsWith(minusSign.toString()))
/*  761:     */       {
/*  762: 954 */         isError = true;
/*  763: 955 */         throw buildInvalidTimeException();
/*  764:     */       }
/*  765:     */     }
/*  766:     */     try
/*  767:     */     {
/*  768: 961 */       String timeFormat = null;
/*  769: 962 */       timeFormat = ((SimpleDateFormat)DateFormat.getTimeInstance(2, l)).toPattern();
/*  770:     */       
/*  771: 964 */       SimpleDateFormat df = new SimpleDateFormat(timeFormat, l);
/*  772:     */       
/*  773: 966 */       int[] value = parseDateTime(s, l, df.toPattern());
/*  774: 970 */       if (value[3] > 24) {
/*  775: 971 */         isError = true;
/*  776:     */       }
/*  777: 973 */       Calendar c = Calendar.getInstance(l);
/*  778: 974 */       c.setTimeZone(tz);
/*  779:     */       
/*  780: 976 */       c.setLenient(false);
/*  781: 977 */       c.set(5, 1);
/*  782: 978 */       c.set(2, 0);
/*  783: 979 */       c.set(1, 1970);
/*  784: 980 */       c.set(11, value[3]);
/*  785: 981 */       c.set(12, value[4]);
/*  786: 982 */       c.set(13, 0);
/*  787:     */       
/*  788: 984 */       c.set(14, 0);
/*  789:     */       
/*  790: 986 */       return c.getTime();
/*  791:     */     }
/*  792:     */     catch (Exception e)
/*  793:     */     {
/*  794: 990 */       throw buildInvalidTimeException();
/*  795:     */     }
/*  796:     */   }
/*  797:     */   
/*  798:     */   private static int[] parseDateTime(String s, Locale l, String pattern)
/*  799:     */     throws MobileApplicationException
/*  800:     */   {
/*  801:1014 */     boolean yearentered = false;
/*  802:1015 */     boolean ampmValidate = false;
/*  803:     */     
/*  804:1017 */     int[] value = { 0, 0, 0, 0, 0, 0 };
/*  805:1018 */     int tokencount = 0;
/*  806:     */     
/*  807:     */ 
/*  808:     */ 
/*  809:1022 */     String ampm = null;
/*  810:     */     
/*  811:1024 */     DateFormatSymbols df = new DateFormatSymbols(l);
/*  812:1025 */     String[] pm = df.getAmPmStrings();
/*  813:1027 */     for (int i = 0; i < pm.length; i++) {
/*  814:1030 */       if ((s.indexOf(pm[i].toUpperCase()) > -1) || (s.indexOf(pm[i].toLowerCase()) > -1)) {
/*  815:1031 */         ampm = pm[i];
/*  816:     */       }
/*  817:     */     }
/*  818:1034 */     StringBuffer tmpStr = new StringBuffer(s);
/*  819:1035 */     if (ampm != null)
/*  820:     */     {
/*  821:1037 */       int index = s.indexOf(ampm);
/*  822:1038 */       if ((index > -1) && (tmpStr.charAt(index + 1) != ' ') && (index + ampm.length() < s.length())) {
/*  823:1040 */         tmpStr.insert(index + ampm.length(), ' ');
/*  824:     */       }
/*  825:     */     }
/*  826:1043 */     StringTokenizer st = new StringTokenizer(tmpStr.toString(), " /-.:");
/*  827:1046 */     while (st.hasMoreTokens())
/*  828:     */     {
/*  829:1048 */       String token = st.nextToken();
/*  830:     */       try
/*  831:     */       {
/*  832:1051 */         int pos = tokenToPosition(tokencount, pattern);
/*  833:1052 */         value[pos] = stringToInt(token, l);
/*  834:1054 */         if (pos == 2) {
/*  835:1055 */           yearentered = true;
/*  836:     */         }
/*  837:     */       }
/*  838:     */       catch (MobileApplicationException e)
/*  839:     */       {
/*  840:     */         int am;
/*  841:1060 */         if ((am = stringToAmPm(token, l)) != -1)
/*  842:     */         {
/*  843:1062 */           ampmValidate = true;
/*  844:1064 */           if ((value[3] > 0) && (value[3] <= 12))
/*  845:     */           {
/*  846:1068 */             if (value[3] == 12) {
/*  847:1069 */               value[3] -= 12;
/*  848:     */             }
/*  849:1070 */             value[3] += am * 12;
/*  850:     */           }
/*  851:     */           else
/*  852:     */           {
/*  853:1074 */             throw buildInvalidDateException();
/*  854:     */           }
/*  855:     */         }
/*  856:     */         else
/*  857:     */         {
/*  858:     */           int m;
/*  859:1079 */           if ((m = stringToMonth(token, l)) != -1)
/*  860:     */           {
/*  861:1081 */             if (value[1] != 0) {
/*  862:1082 */               value[0] = value[1];
/*  863:     */             }
/*  864:1083 */             value[1] = m;
/*  865:     */           }
/*  866:     */           else
/*  867:     */           {
/*  868:1086 */             throw buildInvalidDateException();
/*  869:     */           }
/*  870:     */         }
/*  871:     */       }
/*  872:1088 */       tokencount++;
/*  873:     */     }
/*  874:1092 */     if ((ampm != null) && (!ampmValidate)) {
/*  875:1093 */       throw buildInvalidDateException();
/*  876:     */     }
/*  877:1097 */     Calendar c = Calendar.getInstance(l);
/*  878:1098 */     c.setTime(new Date());
/*  879:1102 */     if ((value[1] != 0) && (value[0] == 0) && (value[2] == 0))
/*  880:     */     {
/*  881:1104 */       value[0] = value[1];
/*  882:1105 */       value[1] = 0;
/*  883:     */     }
/*  884:1107 */     else if ((value[2] != 0) && (value[0] == 0) && (value[1] == 0))
/*  885:     */     {
/*  886:1109 */       value[0] = value[2];
/*  887:1110 */       value[2] = 0;
/*  888:1111 */       yearentered = false;
/*  889:     */     }
/*  890:1114 */     if (value[1] == 0) {
/*  891:1115 */       value[1] = (c.get(2) + 1);
/*  892:     */     }
/*  893:1117 */     if (!yearentered)
/*  894:     */     {
/*  895:1118 */       value[2] = c.get(1);
/*  896:     */     }
/*  897:1119 */     else if (value[2] < 100)
/*  898:     */     {
/*  899:1123 */       int currYear = c.get(1) % 100;
/*  900:1124 */       int currCentury = c.get(1) / 100 * 100;
/*  901:1126 */       if ((currYear >= 0) && (currYear <= 49) && (value[2] >= 0) && (value[2] <= 49)) {
/*  902:1128 */         value[2] += currCentury;
/*  903:1129 */       } else if ((currYear >= 50) && (currYear <= 99) && (value[2] >= 0) && (value[2] <= 49)) {
/*  904:1131 */         value[2] += currCentury + 100;
/*  905:1132 */       } else if ((currYear >= 0) && (currYear <= 49) && (value[2] >= 50) && (value[2] <= 99)) {
/*  906:1134 */         value[2] += currCentury - 100;
/*  907:1135 */       } else if ((currYear >= 50) && (currYear <= 99) && (value[2] >= 50) && (value[2] <= 99)) {
/*  908:1137 */         value[2] += currCentury;
/*  909:     */       }
/*  910:     */     }
/*  911:1139 */     else if ((value[2] > 9999) || (value[2] <= 999))
/*  912:     */     {
/*  913:1140 */       throw buildInvalidDateException();
/*  914:     */     }
/*  915:1142 */     return value;
/*  916:     */   }
/*  917:     */   
/*  918:     */   private static int stringToAmPm(String s, Locale l)
/*  919:     */   {
/*  920:1151 */     DateFormatSymbols df = new DateFormatSymbols(l);
/*  921:     */     
/*  922:1153 */     s = s.toUpperCase();
/*  923:1154 */     String[] pm = df.getAmPmStrings();
/*  924:1156 */     for (int i = 0; i < pm.length; i++) {
/*  925:1157 */       if (s.equals(pm[i].toUpperCase())) {
/*  926:1158 */         return i;
/*  927:     */       }
/*  928:     */     }
/*  929:1160 */     return -1;
/*  930:     */   }
/*  931:     */   
/*  932:     */   private static int stringToMonth(String s, Locale l)
/*  933:     */   {
/*  934:1168 */     DateFormatSymbols df = new DateFormatSymbols(l);
/*  935:     */     
/*  936:1170 */     s = s.toUpperCase();
/*  937:1171 */     String[] shortmnths = df.getShortMonths();
/*  938:1172 */     for (int i = 0; i < shortmnths.length; i++) {
/*  939:1173 */       if (s.equals(shortmnths[i].toUpperCase())) {
/*  940:1174 */         return i + 1;
/*  941:     */       }
/*  942:     */     }
/*  943:1176 */     String[] mnths = df.getMonths();
/*  944:1177 */     for (int i = 0; i < mnths.length; i++) {
/*  945:1178 */       if (s.equals(mnths[i].toUpperCase())) {
/*  946:1179 */         return i + 1;
/*  947:     */       }
/*  948:     */     }
/*  949:1181 */     return -1;
/*  950:     */   }
/*  951:     */   
/*  952:     */   private static int tokenToPosition(int tokennum, String pattern)
/*  953:     */   {
/*  954:1192 */     StringTokenizer st = new StringTokenizer(pattern, " /-.:");
/*  955:1193 */     int i = 0;
/*  956:1195 */     while (st.hasMoreTokens())
/*  957:     */     {
/*  958:1197 */       String s = st.nextToken();
/*  959:1198 */       if ((s.indexOf('d') != -1) && (i == tokennum)) {
/*  960:1199 */         return 0;
/*  961:     */       }
/*  962:1200 */       if ((s.indexOf('M') != -1) && (i == tokennum)) {
/*  963:1201 */         return 1;
/*  964:     */       }
/*  965:1202 */       if ((s.indexOf('y') != -1) && (i == tokennum)) {
/*  966:1203 */         return 2;
/*  967:     */       }
/*  968:1204 */       if ((s.indexOf('H') != -1) && (i == tokennum)) {
/*  969:1205 */         return 3;
/*  970:     */       }
/*  971:1206 */       if ((s.indexOf('h') != -1) && (i == tokennum)) {
/*  972:1207 */         return 3;
/*  973:     */       }
/*  974:1208 */       if ((s.indexOf('m') != -1) && (i == tokennum)) {
/*  975:1209 */         return 4;
/*  976:     */       }
/*  977:1210 */       if ((s.indexOf('s') != -1) && (i == tokennum)) {
/*  978:1211 */         return 5;
/*  979:     */       }
/*  980:1212 */       i++;
/*  981:     */     }
/*  982:1215 */     return -1;
/*  983:     */   }
/*  984:     */   
/*  985:     */   private static boolean isZero(String s, Locale l)
/*  986:     */   {
/*  987:1225 */     DecimalFormatSymbols symb = new DecimalFormatSymbols(l);
/*  988:1227 */     for (int i = 0; i < s.length(); i++) {
/*  989:1229 */       if ((s.charAt(i) != symb.getDecimalSeparator()) && (s.charAt(i) != symb.getGroupingSeparator()) && (s.charAt(i) != '0') && (s.charAt(i) != symb.getMinusSign())) {
/*  990:1233 */         return false;
/*  991:     */       }
/*  992:     */     }
/*  993:1236 */     return true;
/*  994:     */   }
/*  995:     */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.DefaultMobileMboDataFormatter
 * JD-Core Version:    0.7.0.1
 */