/*   1:    */ package com.mro.mobile.app;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.ProgressObserver;
/*   5:    */ import com.mro.mobile.comm.ConnectionTimeoutConfigurator;
/*   6:    */ import com.mro.mobile.mbo.MobileMbo;
/*   7:    */ import com.mro.mobile.persist.RDORuntime;
/*   8:    */ import com.mro.mobile.sensor.barcode.MobileBarcodeEvent;
/*   9:    */ import com.mro.mobile.sensor.barcode.MobileBarcodeReadListener;
/*  10:    */ import com.mro.mobile.sensor.barcode.MobileBarcodeReader;
/*  11:    */ import com.mro.mobile.sensor.barcode.MobileBarcodeReaderHelper;
/*  12:    */ import com.mro.mobile.sensor.barcode.MobileBarcodeReaderSupport;
/*  13:    */ import com.mro.mobile.sensor.barcode.MobileBarcodeReaderWrapper;
/*  14:    */ import com.mro.mobile.sensor.rfid.MobileRFIDEvent;
/*  15:    */ import com.mro.mobile.sensor.rfid.MobileRFIDReadListener;
/*  16:    */ import com.mro.mobile.sensor.rfid.MobileRFIDReaderHelper;
/*  17:    */ import com.mro.mobile.sensor.rfid.MobileRFIDReaderSupport;
/*  18:    */ import com.mro.mobile.sensor.rfid.MobileRFIDReaderWrapper;
/*  19:    */ import com.mro.mobile.ui.event.UIEvent;
/*  20:    */ import com.mro.mobile.ui.res.MobileUIManager;
/*  21:    */ import com.mro.mobile.ui.res.MobileUIResources;
/*  22:    */ import com.mro.mobile.ui.res.MobileUIResourcesType;
/*  23:    */ import com.mro.mobile.ui.res.UIUtil;
/*  24:    */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*  25:    */ import com.mro.mobile.ui.res.controls.InputControl;
/*  26:    */ import com.mro.mobile.ui.res.controls.PageControl;
/*  27:    */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  28:    */ import java.io.FileInputStream;
/*  29:    */ import java.io.FileNotFoundException;
/*  30:    */ import java.io.IOException;
/*  31:    */ import java.io.InputStream;
/*  32:    */ import java.io.InputStreamReader;
/*  33:    */ import java.io.UnsupportedEncodingException;
/*  34:    */ import java.net.HttpURLConnection;
/*  35:    */ import java.util.Enumeration;
/*  36:    */ import java.util.Hashtable;
/*  37:    */ 
/*  38:    */ public abstract class BasicMobileDeviceUIApplication
/*  39:    */   extends BasicMobileDeviceApplication
/*  40:    */   implements MobileBarcodeReadListener, MobileRFIDReadListener, MobileBarcodeReaderSupport, MobileRFIDReaderSupport
/*  41:    */ {
/*  42: 54 */   private SystemInterface systemInterface = null;
/*  43:    */   private MobileUIManager uiManager;
/*  44:    */   private MobileBarcodeReaderHelper barcodeReaderHelper;
/*  45:    */   private MobileRFIDReaderHelper rfidReaderHelper;
/*  46:    */   private ConnectionTimeoutConfigurator connectionTimeoutConfigurator;
/*  47:    */   public static final String propertieslocation = "/properties/";
/*  48:    */   
/*  49:    */   public BasicMobileDeviceUIApplication(MobileUIManager uiManager)
/*  50:    */   {
/*  51: 68 */     this.uiManager = uiManager;
/*  52:    */     
/*  53:    */ 
/*  54: 71 */     this.barcodeReaderHelper = new MobileBarcodeReaderHelper();
/*  55:    */     
/*  56:    */ 
/*  57: 74 */     this.rfidReaderHelper = new MobileRFIDReaderHelper();
/*  58:    */   }
/*  59:    */   
/*  60:    */   protected void ensureAllDepenciesAreSetBeforeBoot()
/*  61:    */   {
/*  62: 78 */     super.ensureAllDepenciesAreSetBeforeBoot();
/*  63: 79 */     if (this.uiManager == null) {
/*  64: 80 */       throw new IllegalStateException("MobileUIManager is not set.");
/*  65:    */     }
/*  66:    */   }
/*  67:    */   
/*  68:    */   public void init()
/*  69:    */     throws MobileApplicationException
/*  70:    */   {
/*  71: 85 */     this.uiManager.init();
/*  72:    */   }
/*  73:    */   
/*  74:    */   public void start()
/*  75:    */     throws MobileApplicationException
/*  76:    */   {
/*  77: 89 */     init();
/*  78: 90 */     this.uiManager.setFrameSize();
/*  79:    */     
/*  80:    */ 
/*  81:    */ 
/*  82: 94 */     markSplashScreenLockDone();
/*  83:    */   }
/*  84:    */   
/*  85:    */   public void postStart()
/*  86:    */     throws MobileApplicationException
/*  87:    */   {
/*  88: 98 */     activateBarCodeReader(this);
/*  89: 99 */     activateRFIDReader(this);
/*  90:100 */     showLoginScreen();
/*  91:101 */     this.uiManager.setVisible(true);
/*  92:    */   }
/*  93:    */   
/*  94:    */   public void appBoot()
/*  95:    */     throws MobileApplicationException
/*  96:    */   {
/*  97:105 */     super.appBoot();
/*  98:106 */     this.barcodeReaderHelper.initialize();
/*  99:107 */     this.rfidReaderHelper.initialize();
/* 100:    */   }
/* 101:    */   
/* 102:    */   protected void showLoginScreen()
/* 103:    */     throws MobileApplicationException
/* 104:    */   {
/* 105:111 */     this.uiManager.showLoginScreen();
/* 106:    */   }
/* 107:    */   
/* 108:    */   public MobileUIManager getMobileUIManager()
/* 109:    */   {
/* 110:115 */     return this.uiManager;
/* 111:    */   }
/* 112:    */   
/* 113:    */   public Hashtable loadUISettings(String fileType)
/* 114:    */   {
/* 115:120 */     String currentResourceFolder = MobileUIResources.getInstance().getCurrentResourceFolder();
/* 116:    */     
/* 117:122 */     Hashtable uiProps = loadPropertyFile(currentResourceFolder + "/properties/" + "ui." + fileType);
/* 118:123 */     Hashtable appProps = loadPropertyFile(currentResourceFolder + "/properties/" + getAppName() + "." + fileType);
/* 119:124 */     if (appProps == null) {
/* 120:125 */       return uiProps;
/* 121:    */     }
/* 122:126 */     if (uiProps == null) {
/* 123:127 */       return appProps;
/* 124:    */     }
/* 125:129 */     uiProps.putAll(appProps);
/* 126:130 */     return uiProps;
/* 127:    */   }
/* 128:    */   
/* 129:    */   public Hashtable loadPropertyFile(String file)
/* 130:    */   {
/* 131:134 */     return loadPropertyFile(file, null);
/* 132:    */   }
/* 133:    */   
/* 134:    */   public Hashtable loadPropertyFile(String file, String charset)
/* 135:    */   {
/* 136:138 */     InputStream is = null;
/* 137:    */     
/* 138:140 */     is = getClass().getResourceAsStream(file);
/* 139:141 */     InputStreamReader reader = null;
/* 140:142 */     if (is == null) {
/* 141:    */       try
/* 142:    */       {
/* 143:145 */         is = new FileInputStream(file);
/* 144:    */       }
/* 145:    */       catch (FileNotFoundException e)
/* 146:    */       {
/* 147:147 */         return null;
/* 148:    */       }
/* 149:    */     }
/* 150:    */     try
/* 151:    */     {
/* 152:152 */       if (charset != null) {
/* 153:153 */         reader = new InputStreamReader(is, charset);
/* 154:    */       }
/* 155:    */     }
/* 156:    */     catch (UnsupportedEncodingException e1) {}finally
/* 157:    */     {
/* 158:157 */       if (reader == null) {
/* 159:158 */         reader = new InputStreamReader(is);
/* 160:    */       }
/* 161:    */     }
/* 162:    */     try
/* 163:    */     {
/* 164:163 */       Hashtable properties = new Hashtable();
/* 165:164 */       char[] charBuf = new char[1024];
/* 166:165 */       StringBuffer lineBuf = new StringBuffer();
/* 167:    */       int charsRead;
/* 168:    */       for (;;)
/* 169:    */       {
/* 170:168 */         charsRead = reader.read(charBuf, 0, charBuf.length);
/* 171:169 */         if (charsRead == -1)
/* 172:    */         {
/* 173:175 */           lineBuf = getPropertyKeyValue(properties, lineBuf);
/* 174:176 */           break;
/* 175:    */         }
/* 176:180 */         for (int i = 0; i < charsRead; i++) {
/* 177:181 */           if ((charBuf[i] == '\n') || (charBuf[i] == '\r')) {
/* 178:182 */             lineBuf = getPropertyKeyValue(properties, lineBuf);
/* 179:    */           } else {
/* 180:184 */             lineBuf.append(charBuf[i]);
/* 181:    */           }
/* 182:    */         }
/* 183:    */       }
/* 184:188 */       return properties;
/* 185:    */     }
/* 186:    */     catch (IOException e) {}finally
/* 187:    */     {
/* 188:    */       try
/* 189:    */       {
/* 190:195 */         reader.close();
/* 191:    */       }
/* 192:    */       catch (IOException e) {}
/* 193:    */     }
/* 194:199 */     return null;
/* 195:    */   }
/* 196:    */   
/* 197:    */   private StringBuffer getPropertyKeyValue(Hashtable properties, StringBuffer lineBuf)
/* 198:    */   {
/* 199:212 */     String line = lineBuf.toString();
/* 200:213 */     lineBuf = new StringBuffer();
/* 201:    */     
/* 202:215 */     line = line.trim();
/* 203:216 */     if ((line.length() > 0) && (!line.startsWith("//")))
/* 204:    */     {
/* 205:217 */       int index = line.indexOf('=');
/* 206:218 */       if (index > 0)
/* 207:    */       {
/* 208:219 */         String propertyName = line.substring(0, index);
/* 209:220 */         String propertyValue = line.substring(index + 1);
/* 210:221 */         properties.put(propertyName, propertyValue);
/* 211:    */       }
/* 212:    */     }
/* 213:224 */     return lineBuf;
/* 214:    */   }
/* 215:    */   
/* 216:    */   public void barcodeReadError(MobileBarcodeEvent barcodeReadEvent)
/* 217:    */   {
/* 218:235 */     if (this.uiManager.allowEvents())
/* 219:    */     {
/* 220:236 */       Exception e = barcodeReadEvent.getError();
/* 221:237 */       if (e != null) {
/* 222:238 */         UIUtil.showFailureMessageBox(e.getMessage());
/* 223:    */       }
/* 224:    */     }
/* 225:    */   }
/* 226:    */   
/* 227:    */   public void barcodeReadSuccess(MobileBarcodeEvent barcodeReadEvent)
/* 228:    */   {
/* 229:251 */     if (this.uiManager.allowEvents())
/* 230:    */     {
/* 231:252 */       AbstractMobileControl page = getCurrentScreen();
/* 232:253 */       page.handleEvent("barcoderead", null, barcodeReadEvent.getData());
/* 233:    */     }
/* 234:    */   }
/* 235:    */   
/* 236:    */   public AbstractMobileControl getCurrentScreen()
/* 237:    */   {
/* 238:258 */     return this.uiManager.getCurrentScreen();
/* 239:    */   }
/* 240:    */   
/* 241:    */   public void RFIDReadSuccess(MobileRFIDEvent rfidReadEvent)
/* 242:    */   {
/* 243:262 */     UIComponent focusOwner = this.uiManager.getFocusOwner();
/* 244:263 */     if (focusOwner != null)
/* 245:    */     {
/* 246:264 */       AbstractMobileControl tCtrl = focusOwner.getController();
/* 247:267 */       if ((tCtrl != null) && (tCtrl.rfidEnabled()) && ((tCtrl instanceof InputControl)) && 
/* 248:268 */         (tCtrl.handleEvent("rfidread", null, rfidReadEvent.getData()))) {
/* 249:269 */         return;
/* 250:    */       }
/* 251:    */     }
/* 252:273 */     AbstractMobileControl page = getCurrentScreen();
/* 253:274 */     if ((page != null) && (page.rfidEnabled())) {
/* 254:275 */       page.handleEvent("rfidread", null, rfidReadEvent.getListData());
/* 255:    */     }
/* 256:    */   }
/* 257:    */   
/* 258:    */   public void RFIDReadFailure(MobileRFIDEvent rfidReadEvent)
/* 259:    */   {
/* 260:280 */     Exception e = rfidReadEvent.getError();
/* 261:281 */     if (e != null) {
/* 262:282 */       UIUtil.showFailureMessageBox(e.getMessage());
/* 263:    */     }
/* 264:    */   }
/* 265:    */   
/* 266:    */   private boolean loadFontImageSize()
/* 267:    */     throws MobileApplicationException
/* 268:    */   {
/* 269:288 */     String fontSize = getSystemSetting("_FONTIMAGESIZE");
/* 270:289 */     if ((fontSize != null) && (!"".equals(fontSize))) {
/* 271:290 */       if (fontSize.equals(MobileUIResourcesType.SMALL.toString())) {
/* 272:291 */         MobileUIResources.setMode(MobileUIResourcesType.SMALL);
/* 273:292 */       } else if (fontSize.equals(MobileUIResourcesType.LARGE.toString())) {
/* 274:293 */         MobileUIResources.setMode(MobileUIResourcesType.LARGE);
/* 275:    */       }
/* 276:    */     }
/* 277:297 */     return true;
/* 278:    */   }
/* 279:    */   
/* 280:    */   public void boot()
/* 281:    */     throws MobileApplicationException
/* 282:    */   {
/* 283:301 */     super.boot();
/* 284:    */     
/* 285:303 */     loadFontImageSize();
/* 286:304 */     enableLoggers();
/* 287:    */   }
/* 288:    */   
/* 289:    */   public void setFontImageSizeResource(String value)
/* 290:    */     throws MobileApplicationException
/* 291:    */   {
/* 292:309 */     RDORuntime systemRDORuntime = RDORuntime.getSystemInstance();
/* 293:    */     
/* 294:311 */     RDORuntime tempRuntime = createRDORuntime("MOBILESYS", "MOBILESYS", null);
/* 295:312 */     systemRDORuntime.registerRDOInfoManager(tempRuntime.getRDOInfoManager());
/* 296:313 */     systemRDORuntime.registerRDOManager(tempRuntime.getRDOManager());
/* 297:314 */     systemRDORuntime.registerRDOTransactionManager(tempRuntime.getRDOTransactionManager());
/* 298:    */     
/* 299:316 */     setSetting("_FONTIMAGESIZE", value, systemRDORuntime);
/* 300:317 */     setSystemSetting("_FONTIMAGESIZE", value);
/* 301:    */   }
/* 302:    */   
/* 303:    */   public void setupDefaultPreferences(MobileMbo preferencesMbo)
/* 304:    */     throws MobileApplicationException
/* 305:    */   {
/* 306:321 */     super.setupDefaultPreferences(preferencesMbo);
/* 307:    */     
/* 308:323 */     preferencesMbo.setValue("MOBFONTIMAGESIZE", MobileUIResources.getMode().toString());
/* 309:324 */     preferencesMbo.setValue("MOBFONTIMAGESIZE_OLD", MobileUIResources.getMode().toString());
/* 310:    */   }
/* 311:    */   
/* 312:    */   public String getStartupScreenId()
/* 313:    */   {
/* 314:328 */     return this.uiManager.getStartupScreenId();
/* 315:    */   }
/* 316:    */   
/* 317:    */   public void removeCurrentScreen(boolean autoSave)
/* 318:    */     throws MobileApplicationException
/* 319:    */   {
/* 320:332 */     this.uiManager.removeCurrentScreen(autoSave);
/* 321:    */   }
/* 322:    */   
/* 323:    */   public AbstractMobileControl getScreen(String screenId)
/* 324:    */     throws MobileApplicationException
/* 325:    */   {
/* 326:336 */     return this.uiManager.getScreen(screenId);
/* 327:    */   }
/* 328:    */   
/* 329:    */   public UIEvent getUserEvent()
/* 330:    */   {
/* 331:340 */     return this.uiManager.getUserEvent();
/* 332:    */   }
/* 333:    */   
/* 334:    */   public void clearPageStack()
/* 335:    */   {
/* 336:344 */     this.uiManager.clearPageStack();
/* 337:    */   }
/* 338:    */   
/* 339:    */   public UIComponent showScreen(AbstractMobileControl screen, AbstractMobileControl launchingControl, boolean stackPage, boolean savePage)
/* 340:    */     throws MobileApplicationException
/* 341:    */   {
/* 342:349 */     return this.uiManager.showScreen(screen, launchingControl, stackPage, savePage);
/* 343:    */   }
/* 344:    */   
/* 345:    */   public UIComponent showScreen(String screenName)
/* 346:    */     throws MobileApplicationException
/* 347:    */   {
/* 348:353 */     return this.uiManager.showScreen(screenName);
/* 349:    */   }
/* 350:    */   
/* 351:    */   public UIComponent showScreen(String startupScreenId, AbstractMobileControl currentScreen, boolean stackPage, boolean savePage)
/* 352:    */     throws MobileApplicationException
/* 353:    */   {
/* 354:358 */     return this.uiManager.showScreen(startupScreenId, currentScreen, stackPage, savePage);
/* 355:    */   }
/* 356:    */   
/* 357:    */   public Enumeration getActiveScreens()
/* 358:    */   {
/* 359:362 */     return this.uiManager.getActiveScreens();
/* 360:    */   }
/* 361:    */   
/* 362:    */   public int getActiveScreensCount()
/* 363:    */   {
/* 364:366 */     return this.uiManager.getActiveScreensCount();
/* 365:    */   }
/* 366:    */   
/* 367:    */   public void removeCurrentScreen()
/* 368:    */     throws MobileApplicationException
/* 369:    */   {
/* 370:370 */     this.uiManager.removeCurrentScreen();
/* 371:    */   }
/* 372:    */   
/* 373:    */   public boolean sendEventToScreen(String targetId, UIEvent event)
/* 374:    */     throws MobileApplicationException
/* 375:    */   {
/* 376:374 */     return this.uiManager.sendEventToScreen(targetId, event);
/* 377:    */   }
/* 378:    */   
/* 379:    */   public void setStopEvents(boolean stop)
/* 380:    */   {
/* 381:378 */     this.uiManager.setStopEvents(stop);
/* 382:    */   }
/* 383:    */   
/* 384:    */   public UIComponent showScreen(String pageId, AbstractMobileControl launchingControl, boolean stackPage)
/* 385:    */     throws MobileApplicationException
/* 386:    */   {
/* 387:382 */     return this.uiManager.showScreen(pageId, launchingControl, stackPage);
/* 388:    */   }
/* 389:    */   
/* 390:    */   public void setUserEvent(UIEvent event)
/* 391:    */   {
/* 392:386 */     this.uiManager.setUserEvent(event);
/* 393:    */   }
/* 394:    */   
/* 395:    */   public void removeLoginScreen()
/* 396:    */     throws MobileApplicationException
/* 397:    */   {
/* 398:390 */     this.uiManager.removeLoginScreen();
/* 399:    */   }
/* 400:    */   
/* 401:    */   public void removeUserEvent(UIEvent event)
/* 402:    */   {
/* 403:394 */     this.uiManager.removeUserEvent(event);
/* 404:    */   }
/* 405:    */   
/* 406:    */   public void showWait()
/* 407:    */   {
/* 408:398 */     this.uiManager.showWait();
/* 409:    */   }
/* 410:    */   
/* 411:    */   public void setTitle(String title)
/* 412:    */   {
/* 413:402 */     this.uiManager.setTitle(title);
/* 414:    */   }
/* 415:    */   
/* 416:    */   public ProgressObserver showProgressScreen(AbstractMobileControl creatingObject, UIEvent event)
/* 417:    */     throws MobileApplicationException
/* 418:    */   {
/* 419:406 */     return this.uiManager.showProgressScreen(creatingObject, event);
/* 420:    */   }
/* 421:    */   
/* 422:    */   public void releaseApplication()
/* 423:    */   {
/* 424:410 */     super.releaseApplication();
/* 425:411 */     releaseBarcodeReader();
/* 426:412 */     releaseRFIDReader();
/* 427:413 */     releaseUIManager();
/* 428:    */   }
/* 429:    */   
/* 430:    */   protected void releaseUIManager()
/* 431:    */   {
/* 432:417 */     this.uiManager.release();
/* 433:    */   }
/* 434:    */   
/* 435:    */   public boolean isBarcodeEnabled()
/* 436:    */   {
/* 437:421 */     return this.barcodeReaderHelper.isBarcodeEnabled();
/* 438:    */   }
/* 439:    */   
/* 440:    */   public boolean isBarcodeReaderBasedOnIntents()
/* 441:    */   {
/* 442:425 */     return (this.barcodeReaderHelper.isBarcodeEnabled()) && (this.barcodeReaderHelper.getBarcodeReaderSupport().getBarcodeReader().isIntentBased());
/* 443:    */   }
/* 444:    */   
/* 445:    */   public MobileBarcodeReaderWrapper getBarcodeReaderSupport()
/* 446:    */   {
/* 447:429 */     return this.barcodeReaderHelper.getBarcodeReaderSupport();
/* 448:    */   }
/* 449:    */   
/* 450:    */   public void releaseBarcodeReader()
/* 451:    */   {
/* 452:433 */     this.barcodeReaderHelper.releaseBarcodeReader();
/* 453:    */   }
/* 454:    */   
/* 455:    */   public void activateBarCodeReader(MobileBarcodeReadListener listener)
/* 456:    */   {
/* 457:437 */     this.barcodeReaderHelper.activateBarCodeReader(listener);
/* 458:    */   }
/* 459:    */   
/* 460:    */   public void removeBarCodeListener(MobileBarcodeReadListener listener)
/* 461:    */   {
/* 462:441 */     this.barcodeReaderHelper.removeBarCodeListener(listener);
/* 463:    */   }
/* 464:    */   
/* 465:    */   public void deactivateBarCodeReader(MobileBarcodeReadListener listener)
/* 466:    */   {
/* 467:445 */     this.barcodeReaderHelper.deactivateBarCodeReader(listener);
/* 468:    */   }
/* 469:    */   
/* 470:    */   public void plugBarcodeReaderSupport(MobileBarcodeReaderWrapper barcodeReaderSupport)
/* 471:    */   {
/* 472:449 */     if (!this.barcodeReaderHelper.isBarcodeEnabled()) {
/* 473:450 */       this.barcodeReaderHelper = new MobileBarcodeReaderHelper(barcodeReaderSupport);
/* 474:    */     }
/* 475:    */   }
/* 476:    */   
/* 477:    */   public boolean isRFIDEnabled()
/* 478:    */   {
/* 479:455 */     return this.rfidReaderHelper.isRFIDEnabled();
/* 480:    */   }
/* 481:    */   
/* 482:    */   public MobileRFIDReaderWrapper getRFIDReaderSupport()
/* 483:    */   {
/* 484:459 */     return this.rfidReaderHelper.getRFIDReaderSupport();
/* 485:    */   }
/* 486:    */   
/* 487:    */   public void releaseRFIDReader()
/* 488:    */   {
/* 489:463 */     this.rfidReaderHelper.releaseRFIDReader();
/* 490:    */   }
/* 491:    */   
/* 492:    */   public void plugRFIDReaderSupport(MobileRFIDReaderWrapper rfidReaderSupport)
/* 493:    */   {
/* 494:467 */     if (!this.rfidReaderHelper.isRFIDEnabled()) {
/* 495:468 */       this.rfidReaderHelper = new MobileRFIDReaderHelper(rfidReaderSupport);
/* 496:    */     }
/* 497:    */   }
/* 498:    */   
/* 499:    */   public void activateRFIDReader(MobileRFIDReadListener listener)
/* 500:    */   {
/* 501:473 */     this.rfidReaderHelper.activateRFIDReader(listener);
/* 502:    */   }
/* 503:    */   
/* 504:    */   public void removeRFIDListener(MobileRFIDReadListener listener)
/* 505:    */   {
/* 506:477 */     this.rfidReaderHelper.removeRFIDListener(listener);
/* 507:    */   }
/* 508:    */   
/* 509:    */   public void deactivateRFIDReader(MobileRFIDReadListener listener)
/* 510:    */   {
/* 511:481 */     this.rfidReaderHelper.deactivateRFIDReader(listener);
/* 512:    */   }
/* 513:    */   
/* 514:    */   public void enableMenu(boolean enable)
/* 515:    */   {
/* 516:485 */     this.uiManager.enableMenu(enable);
/* 517:    */   }
/* 518:    */   
/* 519:    */   public void removeMenuBar()
/* 520:    */   {
/* 521:489 */     this.uiManager.removeMenuBar();
/* 522:    */   }
/* 523:    */   
/* 524:    */   public int getWindowWidth()
/* 525:    */   {
/* 526:493 */     return this.uiManager.getWindowWidth();
/* 527:    */   }
/* 528:    */   
/* 529:    */   public int getWindowHeight()
/* 530:    */   {
/* 531:497 */     return this.uiManager.getWindowHeight();
/* 532:    */   }
/* 533:    */   
/* 534:    */   public Object getNativeWindowFrame()
/* 535:    */   {
/* 536:510 */     return this.uiManager.getNativeWindowFrame();
/* 537:    */   }
/* 538:    */   
/* 539:    */   public void popupPage(String pageName, UIEvent event)
/* 540:    */     throws MobileApplicationException
/* 541:    */   {
/* 542:514 */     this.uiManager.popupPage(pageName, event);
/* 543:    */   }
/* 544:    */   
/* 545:    */   public boolean isValidThreadToRefresh(Thread candidate)
/* 546:    */   {
/* 547:518 */     return this.uiManager.isValidThreadToRefresh(candidate);
/* 548:    */   }
/* 549:    */   
/* 550:    */   public boolean pageAcceptsBackButtonInPopUp(String pageName)
/* 551:    */   {
/* 552:522 */     return false;
/* 553:    */   }
/* 554:    */   
/* 555:    */   public int getWindowMaxSizeForTable()
/* 556:    */   {
/* 557:526 */     return this.uiManager.getWindowMaxSizeForTable();
/* 558:    */   }
/* 559:    */   
/* 560:    */   public void refreshScreen(AbstractMobileControl screen, UIEvent event, boolean addPageGroupMenubar)
/* 561:    */     throws MobileApplicationException
/* 562:    */   {
/* 563:530 */     this.uiManager.refreshScreen(screen, event, addPageGroupMenubar);
/* 564:    */   }
/* 565:    */   
/* 566:    */   public void pageFocus(PageControl page)
/* 567:    */   {
/* 568:534 */     this.uiManager.setPageFocus(page);
/* 569:    */   }
/* 570:    */   
/* 571:    */   public void pluginConnectionTimeoutConfigurator(ConnectionTimeoutConfigurator configurator)
/* 572:    */   {
/* 573:538 */     this.connectionTimeoutConfigurator = configurator;
/* 574:    */   }
/* 575:    */   
/* 576:    */   public void setupConnectionTimeoutSetttings(HttpURLConnection connection)
/* 577:    */   {
/* 578:542 */     if (this.connectionTimeoutConfigurator != null) {
/* 579:543 */       this.connectionTimeoutConfigurator.setupConnectionTimeoutSetttings(connection);
/* 580:    */     }
/* 581:    */   }
/* 582:    */   
/* 583:    */   public void launchBarcodeReaderIntentForResult()
/* 584:    */   {
/* 585:548 */     if (isBarcodeReaderBasedOnIntents()) {
/* 586:549 */       getBarcodeReaderSupport().getBarcodeReader().launchIntent();
/* 587:    */     }
/* 588:    */   }
/* 589:    */   
/* 590:    */   public SystemInterface getSystemInterface()
/* 591:    */   {
/* 592:555 */     return this.systemInterface;
/* 593:    */   }
/* 594:    */   
/* 595:    */   public void setSystemInterface(SystemInterface systemInterface)
/* 596:    */   {
/* 597:559 */     this.systemInterface = systemInterface;
/* 598:    */   }
/* 599:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.BasicMobileDeviceUIApplication
 * JD-Core Version:    0.7.0.1
 */