package com.mro.mobile.app;

import com.mro.mobile.MobileApplicationException;
import com.mro.mobile.ui.MobileMboDataBean;

public abstract interface OperationHandler
{
  public static final String OPERATION_DONE = "done";
  public static final String OPERATION_UNDO = "undo";
  public static final String OPERATION_SAVE = "save";
  
  public abstract void handleOperation(String paramString, MobileMboDataBean paramMobileMboDataBean, int paramInt)
    throws MobileApplicationException;
  
  public abstract boolean beforeOperation(String paramString, MobileMboDataBean paramMobileMboDataBean, int paramInt)
    throws MobileApplicationException;
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.OperationHandler
 * JD-Core Version:    0.7.0.1
 */