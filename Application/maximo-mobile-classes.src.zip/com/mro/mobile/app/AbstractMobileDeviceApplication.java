/*    1:     */ package com.mro.mobile.app;
/*    2:     */ 
/*    3:     */ import com.mro.mobile.DefaultMobileDeviceMessageGenerator;
/*    4:     */ import com.mro.mobile.MobileApplicationException;
/*    5:     */ import com.mro.mobile.MobileDeviceApplicationContextProvider;
/*    6:     */ import com.mro.mobile.MobileInitialContext;
/*    7:     */ import com.mro.mobile.MobileMessageGenerator;
/*    8:     */ import com.mro.mobile.MobileMetaData;
/*    9:     */ import com.mro.mobile.ProgressObserver;
/*   10:     */ import com.mro.mobile.app.async.AsynchronousExecutor;
/*   11:     */ import com.mro.mobile.app.async.AutoRefreshWorkLauncher;
/*   12:     */ import com.mro.mobile.app.userlocation.UserLocationProvider;
/*   13:     */ import com.mro.mobile.comm.RequestPacket;
/*   14:     */ import com.mro.mobile.comm.ResponsePacket;
/*   15:     */ import com.mro.mobile.mbo.MobileMbo;
/*   16:     */ import com.mro.mobile.mbo.MobileMboAttributeInfo;
/*   17:     */ import com.mro.mobile.mbo.MobileMboChange;
/*   18:     */ import com.mro.mobile.mbo.MobileMboData;
/*   19:     */ import com.mro.mobile.mbo.MobileMboInfo;
/*   20:     */ import com.mro.mobile.mbo.MobileMboOrder;
/*   21:     */ import com.mro.mobile.mbo.MobileMboQBE;
/*   22:     */ import com.mro.mobile.mbo.MobileMboRuntime;
/*   23:     */ import com.mro.mobile.mbo.MobileMboUtil;
/*   24:     */ import com.mro.mobile.persist.DefaultQBE;
/*   25:     */ import com.mro.mobile.persist.DefaultRDO;
/*   26:     */ import com.mro.mobile.persist.DefaultRDOAttributeInfo;
/*   27:     */ import com.mro.mobile.persist.DefaultRDOInfo;
/*   28:     */ import com.mro.mobile.persist.Order;
/*   29:     */ import com.mro.mobile.persist.QBE;
/*   30:     */ import com.mro.mobile.persist.RDO;
/*   31:     */ import com.mro.mobile.persist.RDOEnumeration;
/*   32:     */ import com.mro.mobile.persist.RDOException;
/*   33:     */ import com.mro.mobile.persist.RDOInfo;
/*   34:     */ import com.mro.mobile.persist.RDOInfoManager;
/*   35:     */ import com.mro.mobile.persist.RDOManager;
/*   36:     */ import com.mro.mobile.persist.RDORuntime;
/*   37:     */ import com.mro.mobile.persist.RDORuntimeFactory;
/*   38:     */ import com.mro.mobile.persist.RDOTransactionManager;
/*   39:     */ import com.mro.mobile.persist.sql.MobileWhereClause;
/*   40:     */ import com.mro.mobile.ui.DataBeanCache;
/*   41:     */ import com.mro.mobile.ui.MobileMboDataBean;
/*   42:     */ import com.mro.mobile.ui.MobileMboDataBeanManager;
/*   43:     */ import com.mro.mobile.ui.MobileMboDataFormatter;
/*   44:     */ import com.mro.mobile.ui.MobileMboEnumeration;
/*   45:     */ import com.mro.mobile.ui.MobileUIControlData;
/*   46:     */ import com.mro.mobile.ui.MobileUIControlInfo;
/*   47:     */ import com.mro.mobile.ui.event.UIEventHandler;
/*   48:     */ import com.mro.mobile.userlocation.UserLocationDataInfo;
/*   49:     */ import com.mro.mobile.util.Base64;
/*   50:     */ import com.mro.mobile.util.MobileLogger;
/*   51:     */ import com.mro.mobile.util.MobileLoggerFactory;
/*   52:     */ import java.io.DataInputStream;
/*   53:     */ import java.io.File;
/*   54:     */ import java.io.FileWriter;
/*   55:     */ import java.io.IOException;
/*   56:     */ import java.io.InputStream;
/*   57:     */ import java.io.InputStreamReader;
/*   58:     */ import java.net.HttpURLConnection;
/*   59:     */ import java.util.ArrayList;
/*   60:     */ import java.util.Date;
/*   61:     */ import java.util.Enumeration;
/*   62:     */ import java.util.Hashtable;
/*   63:     */ import java.util.List;
/*   64:     */ import java.util.StringTokenizer;
/*   65:     */ import java.util.Vector;
/*   66:     */ 
/*   67:     */ public abstract class AbstractMobileDeviceApplication
/*   68:     */ {
/*   69:     */   public static final String MAXOBJECT = "MAXOBJECT";
/*   70:     */   public static final String MAXSYSSETTINGS = "MAXSYSSETTING";
/*   71:     */   public static final String REGISTEREDUSER = "REGISTEREDUSER";
/*   72:     */   public static final String METADATAOBTAINED = "METADATAOBTAINED";
/*   73:     */   public static final char AND_SEPARATOR = ',';
/*   74:     */   public static final char OR_SEPARATOR = ';';
/*   75:  99 */   private DefaultMobileWebServiceProxy mobileWebServiceProxy = null;
/*   76: 101 */   private Hashtable systemSettings = new Hashtable();
/*   77: 102 */   private Hashtable appSettings = new Hashtable();
/*   78: 103 */   private Hashtable properties = new Hashtable();
/*   79: 104 */   private Hashtable systemProperties = new Hashtable();
/*   80:     */   private UserLocationProvider locationProvider;
/*   81: 108 */   private String metaDataVersion = null;
/*   82: 109 */   private String version = null;
/*   83: 110 */   private String appName = null;
/*   84: 111 */   private String appDescription = null;
/*   85: 112 */   private String mobileDeviceId = null;
/*   86: 114 */   private String currentUser = null;
/*   87: 115 */   private String currentUserPassword = null;
/*   88: 116 */   private RDORuntime rdoRuntime = null;
/*   89: 118 */   private boolean appOptionsAuthRefreshNeeded = false;
/*   90: 119 */   private boolean initialized = false;
/*   91: 120 */   private boolean passwordExpired = false;
/*   92: 121 */   private boolean passwordExpireNotification = false;
/*   93: 125 */   private boolean adHocErrorMgmtEnabled = true;
/*   94: 129 */   private Hashtable operationHandlers = new Hashtable();
/*   95: 133 */   private Hashtable beanOperationHandlers = new Hashtable();
/*   96: 136 */   private Hashtable systemLevelAuthorizations = new Hashtable();
/*   97: 140 */   private Hashtable siteLevelAuthorizations = new Hashtable();
/*   98: 144 */   private Hashtable orgLevelAuthorizations = new Hashtable();
/*   99: 148 */   private int totalDownloadCount = 0;
/*  100: 150 */   private int refreshNumberOfRecords = -1;
/*  101:     */   private RDORuntimeFactory rdoRuntimeFactory;
/*  102:     */   private AsynchronousExecutor executor;
/*  103: 156 */   private AutoRefreshWorkLauncher autoRefreshWorker = null;
/*  104:     */   private boolean automationMode;
/*  105:     */   
/*  106:     */   static
/*  107:     */   {
/*  108: 162 */     MobileMessageGenerator.setMessageGenerator(new DefaultMobileDeviceMessageGenerator());
/*  109:     */     
/*  110:     */ 
/*  111: 165 */     MobileLoggerFactory.registerLogger("maximo.mobile.serialization", new MobileLogger("maximo.mobile.serialization"));
/*  112: 166 */     MobileLoggerFactory.registerLogger("maximo.mobile.persistence", new MobileLogger("maximo.mobile.persistence"));
/*  113: 167 */     MobileLoggerFactory.registerLogger("maximo.mobile.communication", new MobileLogger("maximo.mobile.communication"));
/*  114: 168 */     MobileLoggerFactory.registerLogger("maximo.mobile.sensor", new MobileLogger("maximo.mobile.sensor"));
/*  115: 169 */     MobileLoggerFactory.registerLogger("maximo.mobile.snapshot", new MobileLogger("maximo.mobile.snapshot"));
/*  116: 170 */     MobileLoggerFactory.registerLogger("maximo.mobile.servicecall", new MobileLogger("maximo.mobile.servicecall"));
/*  117:     */   }
/*  118:     */   
/*  119:     */   public AbstractMobileDeviceApplication()
/*  120:     */   {
/*  121: 175 */     loadApplicationProperties("/mobile.properties");
/*  122:     */     
/*  123:     */ 
/*  124:     */ 
/*  125: 179 */     loadApplicationProperties("/mobileversion.properties");
/*  126:     */   }
/*  127:     */   
/*  128:     */   protected MobileLogger getDefaultLogger()
/*  129:     */   {
/*  130: 183 */     return MobileLoggerFactory.getDefaultLogger();
/*  131:     */   }
/*  132:     */   
/*  133:     */   public void setSystemProperty(String name, String value)
/*  134:     */   {
/*  135: 187 */     this.systemProperties.put(name, value);
/*  136:     */   }
/*  137:     */   
/*  138:     */   public String getSystemProperty(String name)
/*  139:     */   {
/*  140: 191 */     return (String)this.systemProperties.get(name);
/*  141:     */   }
/*  142:     */   
/*  143:     */   public void setRDORuntimeFactory(RDORuntimeFactory rdoRuntimeFactory)
/*  144:     */   {
/*  145: 195 */     this.rdoRuntimeFactory = rdoRuntimeFactory;
/*  146:     */   }
/*  147:     */   
/*  148:     */   public RDORuntimeFactory getRDORuntimeFactory()
/*  149:     */   {
/*  150: 199 */     return this.rdoRuntimeFactory;
/*  151:     */   }
/*  152:     */   
/*  153:     */   public void setAsynchronousExecutor(AsynchronousExecutor executor)
/*  154:     */   {
/*  155: 203 */     this.executor = executor;
/*  156:     */   }
/*  157:     */   
/*  158:     */   public AsynchronousExecutor getAsynchronousExecutor()
/*  159:     */   {
/*  160: 207 */     return this.executor;
/*  161:     */   }
/*  162:     */   
/*  163:     */   public void boot()
/*  164:     */     throws MobileApplicationException
/*  165:     */   {
/*  166: 213 */     initSystemProperties();
/*  167:     */     
/*  168: 215 */     ensureAllDepenciesAreSetBeforeBoot();
/*  169:     */     
/*  170: 217 */     enableLoggers();
/*  171:     */     
/*  172:     */ 
/*  173: 220 */     setAppName("MOBILESYS");
/*  174:     */     
/*  175:     */ 
/*  176: 223 */     appBoot();
/*  177:     */     
/*  178:     */ 
/*  179: 226 */     MobileDeviceApplicationContextProvider provider = new MobileDeviceApplicationContextProvider(getAppName());
/*  180: 227 */     MobileInitialContext.setMobileContextProvider(provider);
/*  181:     */     
/*  182:     */ 
/*  183:     */ 
/*  184: 231 */     initSystemPersistenceRuntime();
/*  185:     */     
/*  186:     */ 
/*  187: 234 */     MobileMetaData metaData = loadMetaDataFromFile();
/*  188:     */     
/*  189:     */ 
/*  190:     */ 
/*  191:     */ 
/*  192: 239 */     setAppName(metaData.getAppName());
/*  193:     */     
/*  194:     */ 
/*  195:     */ 
/*  196:     */ 
/*  197: 244 */     String lcaseAppName = metaData.getAppName().toLowerCase();
/*  198: 245 */     loadApplicationProperties("/" + lcaseAppName + ".properties");
/*  199:     */     
/*  200: 247 */     setAppDescription(metaData.getAppDescription());
/*  201: 248 */     setMetaDataVersion(metaData.getVersion());
/*  202:     */     
/*  203:     */ 
/*  204: 251 */     autoCleanDatabaseOnMetaDataChange(metaData);
/*  205:     */     
/*  206:     */ 
/*  207: 254 */     MobileDeviceApplicationContextProvider provider1 = new MobileDeviceApplicationContextProvider(metaData.getAppName());
/*  208: 255 */     MobileInitialContext.setMobileContextProvider(provider1);
/*  209:     */     
/*  210:     */ 
/*  211: 258 */     MobileDeviceAppSession deviceAppSession = MobileDeviceAppSession.getSession();
/*  212: 259 */     deviceAppSession.setAppName(this.appName);
/*  213: 260 */     deviceAppSession.setApplication(this);
/*  214: 261 */     deviceAppSession.setUIEventHandler(createEventHandler());
/*  215: 262 */     deviceAppSession.setMobileMetadata(metaData);
/*  216:     */     
/*  217: 264 */     determineAdHocErrorManagement();
/*  218: 265 */     determineAutomationMode();
/*  219:     */   }
/*  220:     */   
/*  221:     */   protected void ensureAllDepenciesAreSetBeforeBoot()
/*  222:     */   {
/*  223: 278 */     if (this.rdoRuntimeFactory == null) {
/*  224: 279 */       throw new IllegalStateException("RDORuntimeFactory is not set.");
/*  225:     */     }
/*  226: 281 */     if (this.executor == null) {
/*  227: 282 */       throw new IllegalStateException("AsynchronousExecutor is not set.");
/*  228:     */     }
/*  229:     */   }
/*  230:     */   
/*  231:     */   protected void autoCleanDatabaseOnMetaDataChange(MobileMetaData metaData)
/*  232:     */     throws MobileApplicationException
/*  233:     */   {
/*  234: 287 */     boolean autoCleanDatabase = true;
/*  235: 288 */     String autoCleanProperty = getProperty("maximo.db.autoclean");
/*  236: 289 */     if ((autoCleanProperty != null) && (!autoCleanProperty.equals("true"))) {
/*  237: 290 */       autoCleanDatabase = false;
/*  238:     */     }
/*  239: 293 */     if (!autoCleanDatabase) {
/*  240: 294 */       return;
/*  241:     */     }
/*  242: 299 */     String metadataTimeStamp = getSystemSetting("METADATATIMESTAMP");
/*  243: 300 */     if (metadataTimeStamp != null)
/*  244:     */     {
/*  245: 301 */       String latestMetaDataTimeStamp = metaData.getTimestamp() + "";
/*  246: 302 */       if (!latestMetaDataTimeStamp.equals(metadataTimeStamp))
/*  247:     */       {
/*  248: 303 */         resetApplication();
/*  249:     */         
/*  250: 305 */         setSystemSetting("METADATATIMESTAMP", latestMetaDataTimeStamp);
/*  251:     */       }
/*  252:     */     }
/*  253:     */     else
/*  254:     */     {
/*  255: 308 */       String latestMetaDataTimeStamp = metaData.getTimestamp() + "";
/*  256: 309 */       setSystemSetting("METADATATIMESTAMP", latestMetaDataTimeStamp);
/*  257:     */     }
/*  258:     */   }
/*  259:     */   
/*  260:     */   public void enableLoggers()
/*  261:     */   {
/*  262: 314 */     String debug = getProperty("maximo.mobile.debug");
/*  263: 315 */     if ((debug != null) && (debug.equals("true")))
/*  264:     */     {
/*  265: 316 */       String debugPersistence = getProperty("maximo.mobile.debug.persistence");
/*  266: 317 */       if (debugPersistence != null) {
/*  267: 318 */         MobileLoggerFactory.getLogger("maximo.mobile.persistence").setVerbosity(debugPersistence);
/*  268:     */       }
/*  269: 321 */       String debugSerialization = getProperty("maximo.mobile.debug.serialization");
/*  270: 322 */       if (debugSerialization != null) {
/*  271: 323 */         MobileLoggerFactory.getLogger("maximo.mobile.serialization").setVerbosity(debugSerialization);
/*  272:     */       }
/*  273: 326 */       String debugCommunication = getProperty("maximo.mobile.debug.communication");
/*  274: 327 */       if (debugCommunication != null) {
/*  275: 328 */         MobileLoggerFactory.getLogger("maximo.mobile.communication").setVerbosity(debugCommunication);
/*  276:     */       }
/*  277: 331 */       String debugSensor = getProperty("maximo.mobile.debug.sensor");
/*  278: 332 */       if (debugCommunication != null) {
/*  279: 333 */         MobileLoggerFactory.getLogger("maximo.mobile.sensor").setVerbosity(debugSensor);
/*  280:     */       }
/*  281: 335 */       String debugSnapshot = getProperty("maximo.mobile.debug.snapshot");
/*  282: 336 */       if (debugSnapshot != null) {
/*  283: 337 */         MobileLoggerFactory.getLogger("maximo.mobile.snapshot").setVerbosity(debugSnapshot);
/*  284:     */       }
/*  285: 340 */       String debugServiceCall = getProperty("maximo.mobile.debug.servicecall");
/*  286: 341 */       if (debugServiceCall != null) {
/*  287: 342 */         MobileLoggerFactory.getLogger("maximo.mobile.servicecall").setVerbosity(debugServiceCall);
/*  288:     */       }
/*  289:     */     }
/*  290:     */   }
/*  291:     */   
/*  292:     */   public void loadApplicationProperties(String fileName)
/*  293:     */   {
/*  294: 348 */     loadApplicationProperties(fileName, this.properties);
/*  295:     */   }
/*  296:     */   
/*  297:     */   public void loadApplicationProperties(String fileName, Hashtable map)
/*  298:     */   {
/*  299: 352 */     InputStream is = null;
/*  300:     */     
/*  301: 354 */     is = getClass().getResourceAsStream(fileName);
/*  302: 356 */     if (is == null) {
/*  303: 357 */       return;
/*  304:     */     }
/*  305: 359 */     InputStreamReader reader = new InputStreamReader(is);
/*  306:     */     try
/*  307:     */     {
/*  308: 362 */       char[] charBuf = new char[1024];
/*  309: 363 */       StringBuffer lineBuf = new StringBuffer();
/*  310: 364 */       String line = null;
/*  311:     */       for (;;)
/*  312:     */       {
/*  313: 367 */         int charsRead = reader.read(charBuf, 0, charBuf.length);
/*  314: 368 */         if (charsRead == -1)
/*  315:     */         {
/*  316: 370 */           if (lineBuf.length() <= 0) {
/*  317:     */             break;
/*  318:     */           }
/*  319: 371 */           line = lineBuf.toString();
/*  320: 372 */           line = line.trim();
/*  321: 373 */           if ((line.length() <= 0) || (line.startsWith("//"))) {
/*  322:     */             break;
/*  323:     */           }
/*  324: 374 */           processProperty(line, map); break;
/*  325:     */         }
/*  326: 381 */         for (int i = 0; i < charsRead; i++) {
/*  327: 382 */           if ((charBuf[i] == '\n') || (charBuf[i] == '\r'))
/*  328:     */           {
/*  329: 383 */             line = lineBuf.toString();
/*  330: 384 */             lineBuf = new StringBuffer();
/*  331:     */             
/*  332: 386 */             line = line.trim();
/*  333: 387 */             if ((line.length() > 0) && (!line.startsWith("//"))) {
/*  334: 388 */               processProperty(line, map);
/*  335:     */             }
/*  336:     */           }
/*  337:     */           else
/*  338:     */           {
/*  339: 391 */             lineBuf.append(charBuf[i]);
/*  340:     */           }
/*  341:     */         }
/*  342:     */       }
/*  343:     */     }
/*  344:     */     catch (IOException e) {}
/*  345:     */   }
/*  346:     */   
/*  347:     */   protected void processProperty(String propertyLine, Hashtable map)
/*  348:     */   {
/*  349: 401 */     int index = propertyLine.indexOf('=');
/*  350: 402 */     if (index > 0)
/*  351:     */     {
/*  352: 403 */       String propertyName = propertyLine.substring(0, index);
/*  353: 404 */       String propertyValue = propertyLine.substring(index + 1);
/*  354:     */       
/*  355: 406 */       propertyValue = propertyValue.trim();
/*  356: 407 */       if (propertyValue.length() > 0) {
/*  357: 408 */         map.put(propertyName, propertyValue);
/*  358:     */       }
/*  359:     */     }
/*  360:     */   }
/*  361:     */   
/*  362:     */   public String getProperty(String propertyName)
/*  363:     */   {
/*  364: 418 */     return (String)this.properties.get(propertyName);
/*  365:     */   }
/*  366:     */   
/*  367:     */   public String getPackageLanguage()
/*  368:     */   {
/*  369: 423 */     return (String)this.properties.get("maximo.mobile.packagelanguage");
/*  370:     */   }
/*  371:     */   
/*  372:     */   public void setProperty(String propertyName, String propValue)
/*  373:     */   {
/*  374: 427 */     this.properties.put(propertyName, propValue);
/*  375:     */   }
/*  376:     */   
/*  377:     */   public void initializeAppAccess(String userName, String password)
/*  378:     */     throws MobileApplicationException
/*  379:     */   {
/*  380: 431 */     initializeAppAccess(userName, password, null);
/*  381:     */   }
/*  382:     */   
/*  383:     */   public void initializeAppAccess(String userName, String password, ProgressObserver observer)
/*  384:     */     throws MobileApplicationException
/*  385:     */   {
/*  386: 435 */     initializeAppAccess(userName, password, false, observer);
/*  387:     */   }
/*  388:     */   
/*  389:     */   public void initializeAppAccess(String userName, String password, boolean verifyWithServer, ProgressObserver observer)
/*  390:     */     throws MobileApplicationException
/*  391:     */   {
/*  392: 439 */     initializeAppAccess(userName, password, verifyWithServer, observer, false);
/*  393:     */   }
/*  394:     */   
/*  395:     */   public void initializeAppAccess(String userName, String password, boolean verifyWithServer, ProgressObserver observer, boolean pwdchanged)
/*  396:     */     throws MobileApplicationException
/*  397:     */   {
/*  398: 448 */     boolean registerWithServer = false;
/*  399: 450 */     if (observer != null)
/*  400:     */     {
/*  401: 451 */       String msg = MobileMessageGenerator.generate("verifyuser", new Object[] { userName });
/*  402: 452 */       observer.setWorkProgressMessage(msg);
/*  403:     */     }
/*  404: 455 */     if (!isUserRegistered(userName))
/*  405:     */     {
/*  406: 456 */       registerWithServer(userName, password, password, observer);
/*  407: 457 */       registerWithServer = true;
/*  408:     */     }
/*  409: 459 */     else if (verifyWithServer)
/*  410:     */     {
/*  411: 460 */       registerWithServer(userName, password, password);
/*  412:     */     }
/*  413:     */     else
/*  414:     */     {
/*  415: 463 */       login(userName, password, observer);
/*  416:     */     }
/*  417: 467 */     if (observer != null)
/*  418:     */     {
/*  419: 468 */       String msg = MobileMessageGenerator.generate("initapp", new Object[0]);
/*  420: 469 */       observer.setWorkProgressMessage(msg);
/*  421:     */     }
/*  422: 472 */     initApplicationFromMetaData(MobileDeviceAppSession.getSession().getMobileMetadata());
/*  423: 473 */     this.currentUser = userName;
/*  424: 474 */     this.currentUserPassword = password;
/*  425:     */     
/*  426: 476 */     initializeApplication();
/*  427:     */     
/*  428:     */ 
/*  429:     */ 
/*  430:     */ 
/*  431:     */ 
/*  432:     */ 
/*  433:     */ 
/*  434:     */ 
/*  435: 485 */     refreshSystemData(observer);
/*  436: 487 */     if (verifyWithServer) {
/*  437: 488 */       refreshAppOptionsAuth(observer);
/*  438:     */     }
/*  439: 491 */     if ((verifyWithServer) || (registerWithServer))
/*  440:     */     {
/*  441: 492 */       checkPasswordExpirationWithServer();
/*  442: 493 */       if (isPasswordExpired()) {
/*  443: 494 */         setPasswordExpired();
/*  444:     */       }
/*  445:     */     }
/*  446:     */     else
/*  447:     */     {
/*  448: 497 */       checkPasswordExpiration();
/*  449:     */     }
/*  450: 500 */     if (isPasswordExpired())
/*  451:     */     {
/*  452: 501 */       setSystemSetting("OPTIONAUTHREFRESH", "true");
/*  453: 502 */       setSystemSetting("SYSDATAREFRESH", "true");
/*  454:     */       
/*  455: 504 */       throw new MobileApplicationException("passwordexpired");
/*  456:     */     }
/*  457: 507 */     if ((verifyWithServer) || (registerWithServer))
/*  458:     */     {
/*  459: 508 */       setAppSetting("_ACCESS", "true");
/*  460:     */     }
/*  461:     */     else
/*  462:     */     {
/*  463: 510 */       String access = getAppSetting("_ACCESS");
/*  464: 511 */       if ((access != null) && 
/*  465: 512 */         (access.equals("false"))) {
/*  466: 513 */         throw new MobileApplicationException("noappauth");
/*  467:     */       }
/*  468:     */     }
/*  469: 520 */     MobileMboDataBeanManager mgrAppAuth = new MobileMboDataBeanManager("_APPOPTIONAUTH");
/*  470: 521 */     MobileMboDataBean authBean = mgrAppAuth.getDataBean();
/*  471: 522 */     authBean.getQBE().reset();
/*  472: 523 */     authBean.reset();
/*  473: 524 */     for (int i = 0; i < authBean.count(); i++)
/*  474:     */     {
/*  475: 525 */       MobileMbo authMbo = authBean.getMobileMbo(i);
/*  476: 526 */       if (!authMbo.isNull("SITEID")) {
/*  477: 527 */         this.siteLevelAuthorizations.put(authBean.getValue(i, "OPTIONNAME"), authBean.getValue(i, "SITEID"));
/*  478:     */       }
/*  479: 529 */       if ((authMbo.isNull("SITEID")) && (!authMbo.isNull("ORGID"))) {
/*  480: 530 */         this.orgLevelAuthorizations.put(authBean.getValue(i, "OPTIONNAME"), authBean.getValue(i, "ORGID"));
/*  481:     */       }
/*  482: 532 */       if ((authMbo.isNull("SITEID")) && (authMbo.isNull("ORGID"))) {
/*  483: 533 */         this.systemLevelAuthorizations.put(authBean.getValue(i, "OPTIONNAME"), authBean.getValue(i, "OPTIONNAME"));
/*  484:     */       }
/*  485:     */     }
/*  486: 537 */     this.initialized = true;
/*  487:     */     
/*  488: 539 */     initPreferences();
/*  489:     */     
/*  490: 541 */     initAbout();
/*  491:     */     
/*  492: 543 */     initAutoRefreshBackgroundService();
/*  493: 546 */     if (!isOptionAuthorized(getAppName())) {
/*  494: 547 */       throw new MobileApplicationException("noappauth");
/*  495:     */     }
/*  496: 550 */     if (!pwdchanged)
/*  497:     */     {
/*  498: 552 */       checkPasswordExpirationDuration();
/*  499: 553 */       if (isPasswordExpireNotification())
/*  500:     */       {
/*  501: 554 */         Object[] params = { "" + getNumDaysToExpire() };
/*  502: 555 */         throw new MobileApplicationException("passworddurationnotify", params);
/*  503:     */       }
/*  504:     */     }
/*  505:     */   }
/*  506:     */   
/*  507:     */   protected void initAutoRefreshBackgroundService()
/*  508:     */     throws MobileApplicationException
/*  509:     */   {
/*  510: 561 */     boolean autoRefreshEnabled = isAutoRefreshEnabled();
/*  511: 562 */     int autoRefreshInterval = getAutoRefreshInterval();
/*  512: 563 */     this.autoRefreshWorker = new AutoRefreshWorkLauncher(this.executor);
/*  513: 564 */     this.autoRefreshWorker.init(autoRefreshEnabled, autoRefreshInterval);
/*  514: 565 */     this.executor.start(this.autoRefreshWorker);
/*  515:     */   }
/*  516:     */   
/*  517:     */   public int getAutoUpdateInterval()
/*  518:     */   {
/*  519: 569 */     String checkInterval = getProperty("MOBILECDC.UPDATECHECKINTERVAL");
/*  520: 570 */     if ((checkInterval != null) && (!"".equals(checkInterval))) {
/*  521: 571 */       return Integer.parseInt(checkInterval);
/*  522:     */     }
/*  523: 573 */     return 0;
/*  524:     */   }
/*  525:     */   
/*  526:     */   public String getAlreadyUsedByUser(String userName)
/*  527:     */     throws MobileApplicationException
/*  528:     */   {
/*  529: 585 */     Vector registeredUsers = getAllRegisteredUsers();
/*  530: 586 */     int regUserSize = registeredUsers.size();
/*  531: 587 */     for (int i = 0; i < regUserSize; i++)
/*  532:     */     {
/*  533: 588 */       String regUserName = (String)registeredUsers.get(i);
/*  534: 589 */       if (!regUserName.equalsIgnoreCase(userName)) {
/*  535: 590 */         return regUserName;
/*  536:     */       }
/*  537:     */     }
/*  538: 594 */     return null;
/*  539:     */   }
/*  540:     */   
/*  541:     */   public boolean isSnapshotEnabled()
/*  542:     */   {
/*  543: 604 */     return false;
/*  544:     */   }
/*  545:     */   
/*  546:     */   protected void unregisterAppRuntime()
/*  547:     */   {
/*  548: 630 */     RDORuntime.unregisterInstance(getAppName());
/*  549: 631 */     this.rdoRuntime = null;
/*  550:     */   }
/*  551:     */   
/*  552:     */   public void checkPasswordExpirationWithServer()
/*  553:     */     throws MobileApplicationException
/*  554:     */   {
/*  555: 635 */     this.passwordExpired = this.mobileWebServiceProxy.isPasswordExpired();
/*  556:     */   }
/*  557:     */   
/*  558: 638 */   private long numDays = 0L;
/*  559:     */   
/*  560:     */   public long getNumDaysToExpire()
/*  561:     */   {
/*  562: 641 */     return this.numDays;
/*  563:     */   }
/*  564:     */   
/*  565:     */   public void checkPasswordExpirationDuration()
/*  566:     */     throws MobileApplicationException
/*  567:     */   {
/*  568: 645 */     this.passwordExpireNotification = false;
/*  569: 646 */     this.numDays = 0L;
/*  570: 647 */     MobileMboDataBeanManager dataBeanManager = new MobileMboDataBeanManager("USER");
/*  571: 648 */     MobileMboDataBean userDataBean = dataBeanManager.getDataBean();
/*  572: 649 */     userDataBean.reset();
/*  573: 650 */     dataBeanManager = new MobileMboDataBeanManager("PREFERENCES");
/*  574: 651 */     MobileMboDataBean preferenceDataBean = dataBeanManager.getDataBean();
/*  575: 652 */     preferenceDataBean.reset();
/*  576: 653 */     MobileMbo userMbo = userDataBean.getMobileMbo(0);
/*  577: 654 */     MobileMbo prefMbo = preferenceDataBean.getMobileMbo(0);
/*  578: 655 */     if ((userMbo == null) || (prefMbo == null)) {
/*  579: 656 */       return;
/*  580:     */     }
/*  581: 658 */     if (!userMbo.isNull("PWEXPIRATION"))
/*  582:     */     {
/*  583: 659 */       Date pwExpiration = userMbo.getDateValue("PWEXPIRATION");
/*  584:     */       
/*  585: 661 */       long pwExpTime = pwExpiration.getTime();
/*  586:     */       
/*  587: 663 */       long curTime = CurrentTimeProvider.getInstance().getCurrentTime().getTime();
/*  588: 664 */       this.numDays = ((pwExpTime - curTime) / 86400000L);
/*  589:     */       
/*  590: 666 */       long pwdurationDays = prefMbo.getLongValue("PWDURATION");
/*  591: 667 */       if (this.numDays <= pwdurationDays) {
/*  592: 668 */         this.passwordExpireNotification = true;
/*  593:     */       }
/*  594:     */     }
/*  595:     */   }
/*  596:     */   
/*  597:     */   public void checkPasswordExpiration()
/*  598:     */     throws MobileApplicationException
/*  599:     */   {
/*  600: 674 */     this.passwordExpired = false;
/*  601:     */     
/*  602: 676 */     MobileMboDataBeanManager dataBeanManager = new MobileMboDataBeanManager("USER");
/*  603: 677 */     MobileMboDataBean userDataBean = dataBeanManager.getDataBean();
/*  604: 678 */     userDataBean.reset();
/*  605:     */     
/*  606: 680 */     MobileMbo userMbo = userDataBean.getMobileMbo(0);
/*  607: 681 */     if (userMbo == null) {
/*  608: 682 */       return;
/*  609:     */     }
/*  610: 686 */     if (!isServerAuthentication()) {
/*  611: 687 */       if (userMbo.getBooleanValue("FORCEEXPIRATION"))
/*  612:     */       {
/*  613: 688 */         this.passwordExpired = true;
/*  614:     */       }
/*  615: 689 */       else if (!userMbo.isNull("PWEXPIRATION"))
/*  616:     */       {
/*  617: 690 */         Date pwExpiration = userMbo.getDateValue("PWEXPIRATION");
/*  618:     */         
/*  619: 692 */         long pwExpTime = pwExpiration.getTime();
/*  620: 693 */         long curTime = System.currentTimeMillis();
/*  621: 695 */         if (curTime > pwExpTime) {
/*  622: 696 */           this.passwordExpired = true;
/*  623:     */         }
/*  624:     */       }
/*  625:     */     }
/*  626:     */   }
/*  627:     */   
/*  628:     */   public boolean isPasswordExpired()
/*  629:     */     throws MobileApplicationException
/*  630:     */   {
/*  631: 703 */     return this.passwordExpired;
/*  632:     */   }
/*  633:     */   
/*  634:     */   public void changeExpiredPassword(String newPassword)
/*  635:     */     throws MobileApplicationException
/*  636:     */   {
/*  637: 707 */     changeExpiredPassword(newPassword, null);
/*  638:     */   }
/*  639:     */   
/*  640:     */   public void changeExpiredPassword(String newPassword, ProgressObserver observer)
/*  641:     */     throws MobileApplicationException
/*  642:     */   {
/*  643: 711 */     if (observer != null)
/*  644:     */     {
/*  645: 712 */       String msg = MobileMessageGenerator.generate("changingpassword", new Object[0]);
/*  646: 713 */       observer.setWorkProgressMessage(msg);
/*  647: 714 */       if (observer.isWorkStopped()) {
/*  648: 715 */         return;
/*  649:     */       }
/*  650:     */     }
/*  651: 719 */     this.mobileWebServiceProxy.changeExpiredPassword(this.currentUserPassword, newPassword);
/*  652: 720 */     refreshMobileMbos("USER");
/*  653:     */     
/*  654: 722 */     registerUser(getCurrentUser(), newPassword, newPassword);
/*  655:     */     
/*  656:     */ 
/*  657: 725 */     RDORuntime.unregisterInstance(getAppName());
/*  658: 726 */     this.rdoRuntime = null;
/*  659:     */     
/*  660:     */ 
/*  661:     */ 
/*  662: 730 */     initSystemPersistenceRuntime();
/*  663:     */     
/*  664: 732 */     initializeAppAccess(getCurrentUser(), newPassword, false, null, true);
/*  665:     */   }
/*  666:     */   
/*  667:     */   public void changePassword(String newPassword)
/*  668:     */     throws MobileApplicationException
/*  669:     */   {
/*  670: 736 */     changePassword(newPassword, null);
/*  671:     */   }
/*  672:     */   
/*  673:     */   public void changePassword(String newPassword, ProgressObserver observer)
/*  674:     */     throws MobileApplicationException
/*  675:     */   {
/*  676: 740 */     if (observer != null)
/*  677:     */     {
/*  678: 741 */       String msg = MobileMessageGenerator.generate("changingpassword", new Object[0]);
/*  679: 742 */       observer.setWorkProgressMessage(msg);
/*  680: 743 */       if (observer.isWorkStopped()) {
/*  681: 744 */         return;
/*  682:     */       }
/*  683:     */     }
/*  684: 748 */     this.mobileWebServiceProxy.changePassword(this.currentUserPassword, newPassword);
/*  685: 749 */     refreshMobileMbos("USER");
/*  686:     */     
/*  687: 751 */     registerUser(getCurrentUser(), newPassword, newPassword);
/*  688:     */     
/*  689:     */ 
/*  690: 754 */     RDORuntime.unregisterInstance(getAppName());
/*  691: 755 */     this.rdoRuntime = null;
/*  692:     */     
/*  693:     */ 
/*  694:     */ 
/*  695: 759 */     initSystemPersistenceRuntime();
/*  696:     */     
/*  697: 761 */     initializeAppAccess(getCurrentUser(), newPassword, false, null, true);
/*  698:     */   }
/*  699:     */   
/*  700:     */   public boolean isCurrentPasswordMatched(String password)
/*  701:     */   {
/*  702: 765 */     if (this.currentUserPassword.equals(password)) {
/*  703: 766 */       return true;
/*  704:     */     }
/*  705: 769 */     return false;
/*  706:     */   }
/*  707:     */   
/*  708:     */   public boolean isAllDataRefreshedOnce()
/*  709:     */   {
/*  710: 773 */     boolean refreshedOnce = getBooleanSystemSetting("REFRESHALLDONEONCE");
/*  711: 774 */     return refreshedOnce;
/*  712:     */   }
/*  713:     */   
/*  714:     */   public void refreshSystemData()
/*  715:     */     throws MobileApplicationException
/*  716:     */   {
/*  717: 778 */     refreshSystemData(null);
/*  718:     */   }
/*  719:     */   
/*  720:     */   public void refreshSystemData(ProgressObserver observer)
/*  721:     */     throws MobileApplicationException
/*  722:     */   {
/*  723: 782 */     boolean optionAuthRefreshedOnce = getBooleanSystemSetting("OPTIONAUTHREFRESH");
/*  724: 784 */     if (!optionAuthRefreshedOnce)
/*  725:     */     {
/*  726: 785 */       if (observer != null)
/*  727:     */       {
/*  728: 786 */         String msg = MobileMessageGenerator.generate("initappauth", new Object[0]);
/*  729: 787 */         observer.setWorkProgressMessage(msg);
/*  730: 788 */         if (observer.isWorkStopped()) {
/*  731: 789 */           return;
/*  732:     */         }
/*  733:     */       }
/*  734: 792 */       refreshAppOptionsAuth(observer);
/*  735: 793 */       setSystemSetting("OPTIONAUTHREFRESH", "true");
/*  736: 794 */       determineTimeAdjustment(observer);
/*  737:     */     }
/*  738:     */     else
/*  739:     */     {
/*  740: 797 */       setAppOptionsAuthRefreshNeeded(true);
/*  741:     */     }
/*  742: 800 */     boolean systemDataRefreshedOnce = getBooleanSystemSetting("SYSDATAREFRESH");
/*  743: 801 */     if (!systemDataRefreshedOnce)
/*  744:     */     {
/*  745: 802 */       if (observer != null)
/*  746:     */       {
/*  747: 803 */         String msg = MobileMessageGenerator.generate("initsystemdata", new Object[0]);
/*  748: 804 */         observer.setWorkProgressMessage(msg);
/*  749: 805 */         if (observer.isWorkStopped()) {
/*  750: 806 */           return;
/*  751:     */         }
/*  752:     */       }
/*  753: 810 */       String[] sysMobileMboNames = getSystemRefreshOrder();
/*  754: 811 */       for (int i = 0; i < sysMobileMboNames.length; i++) {
/*  755: 812 */         refreshMobileMbos(sysMobileMboNames[i], observer);
/*  756:     */       }
/*  757: 815 */       setSystemSetting("SYSDATAREFRESH", "true");
/*  758:     */     }
/*  759:     */   }
/*  760:     */   
/*  761:     */   public void releaseApplication()
/*  762:     */   {
/*  763: 824 */     MobileDeviceAppSession.getSession().release();
/*  764: 825 */     releaseUserLocationProvider();
/*  765:     */   }
/*  766:     */   
/*  767:     */   protected void releaseUserLocationProvider()
/*  768:     */   {
/*  769: 829 */     if (this.locationProvider != null) {
/*  770: 830 */       this.locationProvider.shutdown();
/*  771:     */     }
/*  772:     */   }
/*  773:     */   
/*  774:     */   public boolean isInitialized()
/*  775:     */   {
/*  776: 835 */     return this.initialized;
/*  777:     */   }
/*  778:     */   
/*  779:     */   public String getAppName()
/*  780:     */   {
/*  781: 839 */     return this.appName;
/*  782:     */   }
/*  783:     */   
/*  784:     */   void setAppName(String appName)
/*  785:     */   {
/*  786: 843 */     this.appName = appName;
/*  787:     */   }
/*  788:     */   
/*  789:     */   public String getAppDescription()
/*  790:     */   {
/*  791: 847 */     return this.appDescription;
/*  792:     */   }
/*  793:     */   
/*  794:     */   void setAppDescription(String description)
/*  795:     */   {
/*  796: 851 */     this.appDescription = description;
/*  797:     */   }
/*  798:     */   
/*  799:     */   public String getCurrentUser()
/*  800:     */   {
/*  801: 855 */     return this.currentUser;
/*  802:     */   }
/*  803:     */   
/*  804:     */   public String getVersion()
/*  805:     */   {
/*  806: 859 */     return this.version;
/*  807:     */   }
/*  808:     */   
/*  809:     */   public String getMetaDataVersion()
/*  810:     */   {
/*  811: 863 */     return this.metaDataVersion;
/*  812:     */   }
/*  813:     */   
/*  814:     */   void setMetaDataVersion(String newVersion)
/*  815:     */   {
/*  816: 867 */     this.metaDataVersion = newVersion;
/*  817:     */   }
/*  818:     */   
/*  819:     */   public String getCurrentUserEmail()
/*  820:     */   {
/*  821: 871 */     String eMailAddress = "";
/*  822:     */     try
/*  823:     */     {
/*  824: 874 */       MobileMboDataBeanManager dataBeanManager = new MobileMboDataBeanManager("USEREMAIL");
/*  825: 875 */       MobileMboDataBean userDataBean = dataBeanManager.getDataBean();
/*  826: 876 */       userDataBean.reset();
/*  827:     */       
/*  828: 878 */       MobileMbo userMbo = userDataBean.getMobileMbo(0);
/*  829: 879 */       if (userMbo == null) {
/*  830: 880 */         return eMailAddress;
/*  831:     */       }
/*  832: 883 */       eMailAddress = userMbo.getValue("EMAILADDRESS");
/*  833:     */     }
/*  834:     */     catch (Exception ex) {}
/*  835: 888 */     return eMailAddress;
/*  836:     */   }
/*  837:     */   
/*  838:     */   protected void setDefaultMobileWebServiceProxy(DefaultMobileWebServiceProxy mobileWebService)
/*  839:     */   {
/*  840: 892 */     this.mobileWebServiceProxy = mobileWebService;
/*  841:     */   }
/*  842:     */   
/*  843:     */   public DefaultMobileWebServiceProxy getDefaultMobileWebServiceProxy()
/*  844:     */   {
/*  845: 896 */     return this.mobileWebServiceProxy;
/*  846:     */   }
/*  847:     */   
/*  848:     */   public int countRecordsModified()
/*  849:     */     throws MobileApplicationException
/*  850:     */   {
/*  851: 920 */     String[] records = recordsToWatchModifications();
/*  852: 921 */     int count = 0;
/*  853: 922 */     if (records != null) {
/*  854: 923 */       for (int i = 0; i < records.length; i++)
/*  855:     */       {
/*  856: 924 */         MobileMboDataBean databean = DataBeanCache.findDataBean(records[i]);
/*  857: 925 */         if (databean == null)
/*  858:     */         {
/*  859: 926 */           MobileMboDataBeanManager mgr = new MobileMboDataBeanManager(records[i]);
/*  860: 927 */           databean = mgr.getDataBean();
/*  861:     */         }
/*  862: 929 */         count += databean.getModifiedCount();
/*  863:     */       }
/*  864:     */     }
/*  865: 932 */     return count;
/*  866:     */   }
/*  867:     */   
/*  868:     */   public boolean doneAllRecordsModified()
/*  869:     */     throws MobileApplicationException
/*  870:     */   {
/*  871: 936 */     String[] records = recordsToWatchModifications();
/*  872: 937 */     if (records != null) {
/*  873: 938 */       for (int i = 0; i < records.length; i++)
/*  874:     */       {
/*  875: 939 */         MobileMboDataBean databean = DataBeanCache.findDataBean(records[i]);
/*  876: 940 */         if (databean == null)
/*  877:     */         {
/*  878: 941 */           MobileMboDataBeanManager mgr = new MobileMboDataBeanManager(records[i]);
/*  879: 942 */           databean = mgr.getDataBean();
/*  880:     */         }
/*  881: 944 */         int count = databean.getModifiedCount();
/*  882: 945 */         if (count > 0) {
/*  883: 946 */           databean.doneAll();
/*  884:     */         }
/*  885:     */       }
/*  886:     */     }
/*  887: 951 */     return true;
/*  888:     */   }
/*  889:     */   
/*  890:     */   public MobileMboDataFormatter getMobileMboDataFormatter()
/*  891:     */   {
/*  892: 955 */     return new DefaultMobileMboDataFormatter();
/*  893:     */   }
/*  894:     */   
/*  895:     */   public void login(String userName, String userPIN, ProgressObserver observer)
/*  896:     */     throws MobileApplicationException
/*  897:     */   {
/*  898: 960 */     resetSystemPersistenceRuntime();
/*  899:     */     
/*  900: 962 */     initializeAppUserRuntime(userName, observer);
/*  901:     */     
/*  902: 964 */     DefaultMobileWebServiceProxy proxy = createMobileWebServiceProxy();
/*  903: 965 */     setDefaultMobileWebServiceProxy(proxy);
/*  904: 967 */     if (proxy == null) {
/*  905: 968 */       throw new MobileApplicationException("noproxy");
/*  906:     */     }
/*  907: 971 */     verifyUserLocal(userName, userPIN);
/*  908:     */     
/*  909:     */ 
/*  910: 974 */     proxy.setProperty("maximo.mobile.hostname", getProperty("maximo.mobile.hostname"));
/*  911: 975 */     proxy.setProperty("maximo.mobile.port", getProperty("maximo.mobile.port"));
/*  912: 976 */     proxy.setProperty("maximo.mobile.ssl", getProperty("maximo.mobile.ssl"));
/*  913: 977 */     proxy.setProperty("maximo.mobile.contextname", getProperty("maximo.mobile.contextname"));
/*  914:     */     
/*  915: 979 */     proxy.setProperty("APPNAME", this.appName);
/*  916: 980 */     proxy.setProperty("USERNAME", userName);
/*  917: 981 */     proxy.setProperty("PASSWORD", getPassword(userName));
/*  918: 982 */     if (this.metaDataVersion != null) {
/*  919: 983 */       proxy.setProperty("VERSION", this.metaDataVersion);
/*  920:     */     }
/*  921: 985 */     proxy.setProperty("MOBILEID", getMobileDeviceId());
/*  922:     */     
/*  923: 987 */     setAppOptionsAuthRefreshNeeded(true);
/*  924:     */   }
/*  925:     */   
/*  926:     */   protected RDORuntime createRDORuntime(String appName, String userName)
/*  927:     */     throws MobileApplicationException
/*  928:     */   {
/*  929: 992 */     return createRDORuntime(appName, userName, null);
/*  930:     */   }
/*  931:     */   
/*  932:     */   protected RDORuntime createRDORuntime(String appName, String userName, ProgressObserver observer)
/*  933:     */     throws MobileApplicationException
/*  934:     */   {
/*  935: 996 */     return getRDORuntimeFactory().createRDORuntime(appName, userName, observer);
/*  936:     */   }
/*  937:     */   
/*  938:     */   public RDORuntime getRDORuntime()
/*  939:     */   {
/*  940:1000 */     return this.rdoRuntime;
/*  941:     */   }
/*  942:     */   
/*  943:     */   public void initializeAppUserRuntime(String userName, ProgressObserver observer)
/*  944:     */     throws MobileApplicationException
/*  945:     */   {
/*  946:1005 */     if (this.rdoRuntime == null)
/*  947:     */     {
/*  948:1009 */       this.rdoRuntime = createRDORuntime(this.appName, userName, observer);
/*  949:1010 */       RDORuntime.registerInstance(this.appName, this.rdoRuntime);
/*  950:     */     }
/*  951:1013 */     this.rdoRuntime.getRDOTransactionManager().begin();
/*  952:     */     
/*  953:     */ 
/*  954:1016 */     MobileMboInfo.initSerializer();
/*  955:1017 */     MobileMbo.initSerializer();
/*  956:1018 */     RequestPacket.initSerializer();
/*  957:1019 */     ResponsePacket.initSerializer();
/*  958:1020 */     MobileMetaData.initSerializer();
/*  959:1021 */     MobileMboData.initSerializer();
/*  960:1022 */     MobileMboQBE.initSerializer();
/*  961:1023 */     MobileMboOrder.initSerializer();
/*  962:1024 */     MobileUIControlInfo.initSerializer();
/*  963:1025 */     MobileUIControlData.initSerializer();
/*  964:1026 */     MobileMboChange.initSerializer();
/*  965:1027 */     MobileWhereClause.initSerializer();
/*  966:     */     
/*  967:     */ 
/*  968:1030 */     RDOInfoManager dbInfoManager = this.rdoRuntime.getRDOInfoManager();
/*  969:     */     
/*  970:1032 */     RDOInfo reqPacketInfo = RequestPacket.getRequestPacketInfo();
/*  971:1033 */     dbInfoManager.registerInfo(reqPacketInfo.getName(), reqPacketInfo);
/*  972:     */     
/*  973:1035 */     RDOInfo respPacketInfo = ResponsePacket.getResponsePacketInfo();
/*  974:1036 */     dbInfoManager.registerInfo(respPacketInfo.getName(), respPacketInfo);
/*  975:     */     
/*  976:1038 */     RDOInfo mobileMboInfo = MobileMboInfo.getMobileMboInfo();
/*  977:1039 */     dbInfoManager.registerInfo(mobileMboInfo.getName(), mobileMboInfo);
/*  978:     */     
/*  979:1041 */     RDOInfo uiControlInfo = MobileUIControlInfo.getUIComponentInfo();
/*  980:1042 */     dbInfoManager.registerInfo("UICOMPONENT", uiControlInfo);
/*  981:     */     
/*  982:     */ 
/*  983:1045 */     MobileMboRuntime mobileMboRuntime = MobileMboRuntime.getNewInstance();
/*  984:1046 */     MobileMboRuntime.registerInstance(this.appName, mobileMboRuntime);
/*  985:     */     
/*  986:1048 */     loadSettings();
/*  987:     */     
/*  988:     */ 
/*  989:1051 */     setupMobileDeviceId();
/*  990:     */     
/*  991:1053 */     String lastTxnId = getSystemSetting("LASTTXNID");
/*  992:1054 */     if (lastTxnId == null)
/*  993:     */     {
/*  994:1055 */       lastTxnId = System.currentTimeMillis() + "";
/*  995:1056 */       setSystemSetting("LASTTXNID", lastTxnId);
/*  996:     */     }
/*  997:1059 */     this.rdoRuntime.getRDOTransactionManager().commit();
/*  998:     */   }
/*  999:     */   
/* 1000:     */   public void release(String userName)
/* 1001:     */     throws MobileApplicationException
/* 1002:     */   {
/* 1003:1063 */     RDORuntime appRuntime = RDORuntime.getInstance(this.appName);
/* 1004:     */     
/* 1005:     */ 
/* 1006:1066 */     appRuntime.getRDOInfoManager().release();
/* 1007:1067 */     appRuntime.getRDOManager().release();
/* 1008:     */   }
/* 1009:     */   
/* 1010:     */   public String getMobileDeviceId()
/* 1011:     */   {
/* 1012:1071 */     if (this.mobileDeviceId == null) {
/* 1013:1072 */       this.mobileDeviceId = (System.currentTimeMillis() + "");
/* 1014:     */     }
/* 1015:1075 */     return this.mobileDeviceId;
/* 1016:     */   }
/* 1017:     */   
/* 1018:     */   public void setupMobileDeviceId()
/* 1019:     */     throws MobileApplicationException
/* 1020:     */   {
/* 1021:1079 */     String mDeviceId = getMobileDeviceId();
/* 1022:     */     
/* 1023:     */ 
/* 1024:     */ 
/* 1025:1083 */     String mId = getSystemSetting("MOBILEID");
/* 1026:1084 */     if (mId == null) {
/* 1027:1085 */       setSystemSetting("MOBILEID", mDeviceId);
/* 1028:     */     } else {
/* 1029:1087 */       this.mobileDeviceId = mId;
/* 1030:     */     }
/* 1031:1090 */     if (getDefaultMobileWebServiceProxy() != null) {
/* 1032:1091 */       getDefaultMobileWebServiceProxy().setProperty("MOBILEID", getMobileDeviceId());
/* 1033:     */     }
/* 1034:     */   }
/* 1035:     */   
/* 1036:     */   public synchronized long getNextTransactionId()
/* 1037:     */     throws MobileApplicationException
/* 1038:     */   {
/* 1039:1096 */     String lastTxnId = getSystemSetting("LASTTXNID");
/* 1040:1097 */     if (lastTxnId == null) {
/* 1041:1098 */       return 0L;
/* 1042:     */     }
/* 1043:1101 */     long txnId = Long.parseLong(lastTxnId);
/* 1044:     */     
/* 1045:1103 */     txnId += 1L;
/* 1046:     */     
/* 1047:1105 */     setSystemSetting("LASTTXNID", txnId + "");
/* 1048:     */     
/* 1049:1107 */     return txnId;
/* 1050:     */   }
/* 1051:     */   
/* 1052:     */   public synchronized void updateLastCommunicationTime()
/* 1053:     */     throws MobileApplicationException
/* 1054:     */   {
/* 1055:1111 */     long time = System.currentTimeMillis();
/* 1056:     */     
/* 1057:1113 */     setSystemSetting("LASTCOMMTIME", time + "");
/* 1058:     */   }
/* 1059:     */   
/* 1060:     */   public Date getLastCommunicationTime()
/* 1061:     */     throws MobileApplicationException
/* 1062:     */   {
/* 1063:1117 */     String lastCommTime = getSystemSetting("LASTCOMMTIME");
/* 1064:1119 */     if (lastCommTime == null) {
/* 1065:1120 */       return null;
/* 1066:     */     }
/* 1067:1123 */     long time = Long.parseLong(lastCommTime);
/* 1068:1124 */     return new Date(time);
/* 1069:     */   }
/* 1070:     */   
/* 1071:     */   public void sendQueuedMessages()
/* 1072:     */     throws MobileApplicationException
/* 1073:     */   {
/* 1074:1129 */     this.mobileWebServiceProxy.getService().processPendingRequests();
/* 1075:     */   }
/* 1076:     */   
/* 1077:     */   public void setBatchAsyncMode(boolean enable)
/* 1078:     */   {
/* 1079:1133 */     this.mobileWebServiceProxy.getService().setBatchAsyncMode(enable);
/* 1080:     */   }
/* 1081:     */   
/* 1082:     */   public int getQueuedMessageCount()
/* 1083:     */     throws MobileApplicationException
/* 1084:     */   {
/* 1085:1137 */     RDORuntime rdoRuntime = RDORuntime.getInstance(this.appName);
/* 1086:1138 */     RDOManager rdoManager = rdoRuntime.getRDOManager();
/* 1087:     */     
/* 1088:1140 */     return rdoManager.size("REQUEST");
/* 1089:     */   }
/* 1090:     */   
/* 1091:     */   public int getCount(String name)
/* 1092:     */     throws MobileApplicationException
/* 1093:     */   {
/* 1094:1144 */     RDORuntime rdoRuntime = RDORuntime.getInstance(this.appName);
/* 1095:1145 */     RDOManager rdoManager = rdoRuntime.getRDOManager();
/* 1096:     */     
/* 1097:1147 */     return rdoManager.size(name);
/* 1098:     */   }
/* 1099:     */   
/* 1100:     */   public int getCount(String name, QBE filter)
/* 1101:     */     throws MobileApplicationException
/* 1102:     */   {
/* 1103:1151 */     RDORuntime rdoRuntime = RDORuntime.getInstance(this.appName);
/* 1104:1152 */     RDOManager rdoManager = rdoRuntime.getRDOManager();
/* 1105:     */     
/* 1106:1154 */     return rdoManager.size(name, filter);
/* 1107:     */   }
/* 1108:     */   
/* 1109:     */   public int getMobileMboModifiedCount(String name)
/* 1110:     */     throws MobileApplicationException
/* 1111:     */   {
/* 1112:1158 */     MobileMboDataBeanManager dataBeanManager = new MobileMboDataBeanManager(name);
/* 1113:1159 */     MobileMboDataBean dataBean = dataBeanManager.getDataBean();
/* 1114:1160 */     dataBean.getQBE().setQBE("_MODIFIED", "true");
/* 1115:1161 */     dataBean.getQBE().setQBE("_DONE", "0");
/* 1116:1162 */     dataBean.reset();
/* 1117:     */     
/* 1118:1164 */     return dataBean.count();
/* 1119:     */   }
/* 1120:     */   
/* 1121:     */   public int getMobileMboErrorCount(String name)
/* 1122:     */     throws MobileApplicationException
/* 1123:     */   {
/* 1124:1168 */     MobileMboDataBeanManager dataBeanManager = new MobileMboDataBeanManager(name);
/* 1125:1169 */     MobileMboDataBean dataBean = dataBeanManager.getDataBean();
/* 1126:1170 */     dataBean.getQBE().setQBE("_ERR", "true");
/* 1127:1171 */     dataBean.getQBE().setQBE("_DONE", "0");
/* 1128:1172 */     dataBean.reset();
/* 1129:     */     
/* 1130:1174 */     return dataBean.count();
/* 1131:     */   }
/* 1132:     */   
/* 1133:     */   public int getMobileMboCount(String name)
/* 1134:     */     throws MobileApplicationException
/* 1135:     */   {
/* 1136:1178 */     RDORuntime rdoRuntime = RDORuntime.getInstance(this.appName);
/* 1137:1179 */     RDOManager rdoManager = rdoRuntime.getRDOManager();
/* 1138:     */     
/* 1139:1181 */     return rdoManager.size(name);
/* 1140:     */   }
/* 1141:     */   
/* 1142:     */   public int getMobileMboCount(String name, QBE filter)
/* 1143:     */     throws MobileApplicationException
/* 1144:     */   {
/* 1145:1185 */     RDORuntime rdoRuntime = RDORuntime.getInstance(this.appName);
/* 1146:1186 */     RDOManager rdoManager = rdoRuntime.getRDOManager();
/* 1147:     */     
/* 1148:1188 */     return rdoManager.size(name, filter);
/* 1149:     */   }
/* 1150:     */   
/* 1151:     */   public int getMobileMboCount(String name, QBE filter, MobileWhereClause whereClause)
/* 1152:     */     throws MobileApplicationException
/* 1153:     */   {
/* 1154:1192 */     RDORuntime rdoRuntime = RDORuntime.getInstance(this.appName);
/* 1155:1193 */     RDOManager rdoManager = rdoRuntime.getRDOManager();
/* 1156:     */     
/* 1157:1195 */     return rdoManager.size(name, filter, whereClause);
/* 1158:     */   }
/* 1159:     */   
/* 1160:     */   public int getMobileMboCountRemote(String name)
/* 1161:     */     throws MobileApplicationException
/* 1162:     */   {
/* 1163:1199 */     int count = this.mobileWebServiceProxy.getMobileMboCount(name);
/* 1164:1200 */     return count;
/* 1165:     */   }
/* 1166:     */   
/* 1167:     */   public int getMobileMboCountRemote(String name, MobileMboQBE filter)
/* 1168:     */     throws MobileApplicationException
/* 1169:     */   {
/* 1170:1204 */     int count = this.mobileWebServiceProxy.getMobileMboCount(name, filter);
/* 1171:1205 */     return count;
/* 1172:     */   }
/* 1173:     */   
/* 1174:     */   public int getMobileMboCountRemote(String name, MobileMboQBE filter, MobileWhereClause whereClause)
/* 1175:     */     throws MobileApplicationException
/* 1176:     */   {
/* 1177:1209 */     int count = this.mobileWebServiceProxy.getMobileMboCount(name, filter, whereClause);
/* 1178:1210 */     return count;
/* 1179:     */   }
/* 1180:     */   
/* 1181:     */   public void initSystemPersistenceRuntime()
/* 1182:     */     throws MobileApplicationException
/* 1183:     */   {
/* 1184:1216 */     RDORuntime systemRDORuntime = RDORuntime.getSystemInstance();
/* 1185:1217 */     RDORuntime tempRuntime = createRDORuntime("MOBILESYS", "MOBILESYS");
/* 1186:     */     
/* 1187:1219 */     systemRDORuntime.registerRDOInfoManager(tempRuntime.getRDOInfoManager());
/* 1188:1220 */     systemRDORuntime.registerRDOManager(tempRuntime.getRDOManager());
/* 1189:1221 */     systemRDORuntime.registerRDOTransactionManager(tempRuntime.getRDOTransactionManager());
/* 1190:     */     
/* 1191:1223 */     systemRDORuntime.getRDOTransactionManager().begin();
/* 1192:     */     
/* 1193:     */ 
/* 1194:1226 */     RequestPacket.initSerializer();
/* 1195:1227 */     ResponsePacket.initSerializer();
/* 1196:     */     
/* 1197:     */ 
/* 1198:1230 */     RDOInfoManager dbInfoManager = systemRDORuntime.getRDOInfoManager();
/* 1199:     */     
/* 1200:1232 */     RDOInfo reqPacketInfo = RequestPacket.getRequestPacketInfo();
/* 1201:1233 */     dbInfoManager.registerInfo(reqPacketInfo.getName(), reqPacketInfo);
/* 1202:     */     
/* 1203:1235 */     RDOInfo respPacketInfo = ResponsePacket.getResponsePacketInfo();
/* 1204:1236 */     dbInfoManager.registerInfo(respPacketInfo.getName(), respPacketInfo);
/* 1205:     */     
/* 1206:1238 */     RDOInfo mobileMboInfo = MobileMboInfo.getMobileMboInfo();
/* 1207:1239 */     dbInfoManager.registerInfo(mobileMboInfo.getName(), mobileMboInfo);
/* 1208:     */     
/* 1209:1241 */     RDOInfo uiControlInfo = MobileUIControlInfo.getUIComponentInfo();
/* 1210:1242 */     dbInfoManager.registerInfo("UICOMPONENT", uiControlInfo);
/* 1211:     */     
/* 1212:1244 */     this.rdoRuntime = systemRDORuntime;
/* 1213:     */     
/* 1214:1246 */     this.rdoRuntime.getRDOTransactionManager().commit();
/* 1215:     */     
/* 1216:1248 */     loadSettings();
/* 1217:     */   }
/* 1218:     */   
/* 1219:     */   public void resetSystemPersistenceRuntime()
/* 1220:     */   {
/* 1221:     */     
/* 1222:1253 */     if (this.rdoRuntime != null) {
/* 1223:     */       try
/* 1224:     */       {
/* 1225:1255 */         this.rdoRuntime.getRDOInfoManager().release();
/* 1226:1256 */         this.rdoRuntime.getRDOManager().release();
/* 1227:     */       }
/* 1228:     */       catch (RDOException e)
/* 1229:     */       {
/* 1230:1258 */         getDefaultLogger().warn("Failed to reset system persistence runtime", e);
/* 1231:     */       }
/* 1232:     */     }
/* 1233:1261 */     this.rdoRuntime = null;
/* 1234:     */   }
/* 1235:     */   
/* 1236:     */   public void registerWithServer(String userName, String password, String userPIN)
/* 1237:     */     throws MobileApplicationException
/* 1238:     */   {
/* 1239:1265 */     registerWithServer(userName, password, userPIN, null);
/* 1240:     */   }
/* 1241:     */   
/* 1242:     */   public void registerWithServer(String userName, String password, String userPIN, ProgressObserver observer)
/* 1243:     */     throws MobileApplicationException
/* 1244:     */   {
/* 1245:1269 */     DefaultMobileWebServiceProxy proxy = createMobileWebServiceProxy();
/* 1246:1270 */     setDefaultMobileWebServiceProxy(proxy);
/* 1247:1272 */     if (proxy == null) {
/* 1248:1273 */       throw new MobileApplicationException("noproxy");
/* 1249:     */     }
/* 1250:1277 */     proxy.setProperty("maximo.mobile.hostname", getProperty("maximo.mobile.hostname"));
/* 1251:1278 */     proxy.setProperty("maximo.mobile.port", getProperty("maximo.mobile.port"));
/* 1252:1279 */     proxy.setProperty("maximo.mobile.ssl", getProperty("maximo.mobile.ssl"));
/* 1253:1280 */     proxy.setProperty("maximo.mobile.contextname", getProperty("maximo.mobile.contextname"));
/* 1254:     */     
/* 1255:1282 */     proxy.setProperty("APPNAME", this.appName);
/* 1256:1283 */     proxy.setProperty("USERNAME", userName);
/* 1257:1284 */     proxy.setProperty("PASSWORD", password);
/* 1258:1286 */     if (this.metaDataVersion != null) {
/* 1259:1287 */       proxy.setProperty("VERSION", this.metaDataVersion);
/* 1260:     */     }
/* 1261:1290 */     proxy.setProperty("MOBILEID", getMobileDeviceId());
/* 1262:1291 */     verifyUserRemote(userName, password);
/* 1263:1293 */     if (isSnapshotEnabled())
/* 1264:     */     {
/* 1265:1294 */       String alreadyUsedByUser = getAlreadyUsedByUser(userName);
/* 1266:1295 */       if (alreadyUsedByUser != null)
/* 1267:     */       {
/* 1268:1298 */         storeSnapshot(alreadyUsedByUser, userName, observer);
/* 1269:     */         
/* 1270:1300 */         initSystemPersistenceRuntime();
/* 1271:     */       }
/* 1272:1303 */       if (!isUserRegistered(userName)) {
/* 1273:1304 */         retrieveSnapshot(observer);
/* 1274:     */       }
/* 1275:     */     }
/* 1276:1311 */     registerUser(userName, "", "");
/* 1277:1312 */     resetSystemPersistenceRuntime();
/* 1278:     */     
/* 1279:1314 */     RDORuntime.getSystemInstance();
/* 1280:     */     
/* 1281:     */ 
/* 1282:     */ 
/* 1283:1318 */     initializeAppUserRuntime(userName, observer);
/* 1284:1319 */     registerUser(userName, password, userPIN);
/* 1285:     */     
/* 1286:     */ 
/* 1287:1322 */     String serverAuthentication = new Boolean(proxy.isServerAuthentication()).toString();
/* 1288:1323 */     setAppSetting("_SERVERAUTH", serverAuthentication);
/* 1289:     */     
/* 1290:1325 */     this.version = this.mobileWebServiceProxy.getVersion();
/* 1291:     */   }
/* 1292:     */   
/* 1293:     */   public void resetApplication(String userName)
/* 1294:     */     throws MobileApplicationException
/* 1295:     */   {
/* 1296:1337 */     RDORuntime.unregisterInstance(getAppName());
/* 1297:1338 */     this.rdoRuntime = null;
/* 1298:     */     
/* 1299:     */ 
/* 1300:1341 */     initializeAppUserRuntime(userName, null);
/* 1301:1342 */     RDORuntime.getInstance(getAppName()).getRDOTransactionManager().begin();
/* 1302:1343 */     RDORuntime.getInstance(getAppName()).getRDOInfoManager().removeAll();
/* 1303:1344 */     RDORuntime.getInstance(getAppName()).getRDOTransactionManager().commit();
/* 1304:1345 */     RDORuntime.unregisterInstance(getAppName());
/* 1305:     */     
/* 1306:1347 */     initSystemPersistenceRuntime();
/* 1307:1348 */     unregisterUser(userName);
/* 1308:1349 */     resetSystemPersistenceRuntime();
/* 1309:     */   }
/* 1310:     */   
/* 1311:     */   private void resetApplication()
/* 1312:     */     throws MobileApplicationException
/* 1313:     */   {
/* 1314:1359 */     RDORuntime.unregisterInstance(getAppName());
/* 1315:     */     
/* 1316:1361 */     initSystemPersistenceRuntime();
/* 1317:1362 */     Vector users = getAllRegisteredUsers();
/* 1318:1363 */     resetSystemPersistenceRuntime();
/* 1319:     */     
/* 1320:     */ 
/* 1321:1366 */     int userCount = users.size();
/* 1322:1367 */     for (int i = 0; i < userCount; i++)
/* 1323:     */     {
/* 1324:1368 */       String userName = (String)users.elementAt(i);
/* 1325:1369 */       resetApplication(userName);
/* 1326:     */     }
/* 1327:1373 */     initSystemPersistenceRuntime();
/* 1328:     */     
/* 1329:1375 */     this.mobileDeviceId = null;
/* 1330:     */   }
/* 1331:     */   
/* 1332:     */   public void resetMboMetaData()
/* 1333:     */     throws MobileApplicationException
/* 1334:     */   {
/* 1335:1380 */     Enumeration keyEnum = MobileMboUtil.getAllMobileMboNames(getAppName());
/* 1336:1381 */     while (keyEnum.hasMoreElements())
/* 1337:     */     {
/* 1338:1382 */       String name = (String)keyEnum.nextElement();
/* 1339:1383 */       this.rdoRuntime.getRDOInfoManager().removeInfo(name);
/* 1340:     */     }
/* 1341:1386 */     this.rdoRuntime.getRDOInfoManager().removeInfo("MAXOBJECT");
/* 1342:1387 */     setMetaDataObtainedFromServer(false);
/* 1343:     */   }
/* 1344:     */   
/* 1345:     */   public MobileMetaData loadMetaDataFromFile()
/* 1346:     */     throws MobileApplicationException
/* 1347:     */   {
/* 1348:1391 */     InputStream is = null;
/* 1349:     */     try
/* 1350:     */     {
/* 1351:1394 */       is = getClass().getResourceAsStream("/app.res");
/* 1352:1395 */       DataInputStream dinput = new DataInputStream(is);
/* 1353:     */       
/* 1354:1397 */       MobileMetaData mobileMetaData = (MobileMetaData)new MobileMetaData().readInstance(dinput, "MobileMetaData");
/* 1355:     */       
/* 1356:     */ 
/* 1357:1400 */       applyProductCustomizations(mobileMetaData);
/* 1358:     */       
/* 1359:1402 */       return mobileMetaData;
/* 1360:     */     }
/* 1361:     */     catch (Exception e)
/* 1362:     */     {
/* 1363:1404 */       getDefaultLogger().warn("Failed to load metadata from file - does app.res exist?", e);
/* 1364:     */       
/* 1365:     */ 
/* 1366:1407 */       throw new MobileApplicationException(e);
/* 1367:     */     }
/* 1368:     */     finally
/* 1369:     */     {
/* 1370:     */       try
/* 1371:     */       {
/* 1372:1410 */         if (is != null) {
/* 1373:1411 */           is.close();
/* 1374:     */         }
/* 1375:     */       }
/* 1376:     */       catch (Exception ex) {}
/* 1377:     */     }
/* 1378:     */   }
/* 1379:     */   
/* 1380:     */   public void initApplicationFromMetaData(MobileMetaData mobileMetaData)
/* 1381:     */     throws MobileApplicationException
/* 1382:     */   {
/* 1383:1418 */     this.metaDataVersion = mobileMetaData.getVersion();
/* 1384:1419 */     if ((this.metaDataVersion != null) && (this.mobileWebServiceProxy != null)) {
/* 1385:1420 */       this.mobileWebServiceProxy.setProperty("VERSION", this.metaDataVersion);
/* 1386:     */     }
/* 1387:1423 */     MobileMboInfo[] allMboInfo = mobileMetaData.getAllMobileMboInfo();
/* 1388:1424 */     MobileUIControlInfo[] allUIControlInfo = mobileMetaData.getAllMobileUIComponentInfo();
/* 1389:     */     
/* 1390:1426 */     RDOTransactionManager rdoTxnManager = this.rdoRuntime.getRDOTransactionManager();
/* 1391:     */     try
/* 1392:     */     {
/* 1393:1428 */       rdoTxnManager.begin();
/* 1394:1429 */       MobileMboRuntime mobileMboRuntime = MobileMboRuntime.getInstance(this.appName);
/* 1395:1430 */       for (int i = 0; i < allMboInfo.length; i++)
/* 1396:     */       {
/* 1397:1431 */         MobileMboUtil.createMboObjectDef(this.rdoRuntime, allMboInfo[i]);
/* 1398:1432 */         mobileMboRuntime.registerMobileMboInfo(allMboInfo[i]);
/* 1399:     */         
/* 1400:1434 */         DefaultQBE qbe = new DefaultQBE();
/* 1401:1435 */         qbe.setQbeExactMatch(true);
/* 1402:1436 */         qbe.setQBE("NAME", allMboInfo[i].getName());
/* 1403:1437 */         RDOEnumeration rdoEnum = this.rdoRuntime.getRDOManager().getAll("MAXOBJECT", qbe, null);
/* 1404:1438 */         if (rdoEnum.hasMoreElements())
/* 1405:     */         {
/* 1406:1439 */           RDO maxObject = (RDO)rdoEnum.nextElement();
/* 1407:1440 */           if (!maxObject.isNull("LASTDOWNLOADDATE"))
/* 1408:     */           {
/* 1409:1441 */             long lastDownLoadTime = maxObject.getLongValue("LASTDOWNLOADDATE");
/* 1410:1442 */             allMboInfo[i].setLastDownloadTime(new Date(lastDownLoadTime));
/* 1411:     */           }
/* 1412:1444 */           rdoEnum.release();
/* 1413:     */         }
/* 1414:     */       }
/* 1415:1448 */       loadUserIndexProperties("/mobileindex.properties");
/* 1416:1449 */       rdoTxnManager.commit();
/* 1417:     */     }
/* 1418:     */     catch (MobileApplicationException ex)
/* 1419:     */     {
/* 1420:1452 */       rdoTxnManager.rollback();
/* 1421:1453 */       throw ex;
/* 1422:     */     }
/* 1423:     */     catch (Exception ex)
/* 1424:     */     {
/* 1425:1455 */       rdoTxnManager.rollback();
/* 1426:1456 */       throw new MobileApplicationException(ex);
/* 1427:     */     }
/* 1428:     */   }
/* 1429:     */   
/* 1430:     */   public void downloadWorkList(ProgressObserver observer)
/* 1431:     */     throws MobileApplicationException
/* 1432:     */   {
/* 1433:1461 */     Enumeration keyEnum = MobileMboUtil.getAllMobileMboNames(getAppName());
/* 1434:1462 */     while (keyEnum.hasMoreElements())
/* 1435:     */     {
/* 1436:1463 */       String name = (String)keyEnum.nextElement();
/* 1437:     */       
/* 1438:     */ 
/* 1439:     */ 
/* 1440:1467 */       MobileMboInfo mboInfo = MobileMboUtil.getMobileMboInfo(getAppName(), name);
/* 1441:1470 */       if ((mboInfo.getParent() == null) && (mboInfo.isWorkset()))
/* 1442:     */       {
/* 1443:1472 */         downloadMobileMbos(name, observer);
/* 1444:1474 */         if (observer != null)
/* 1445:     */         {
/* 1446:1475 */           observer.updateWorkProgress();
/* 1447:1476 */           if (observer.isWorkStopped()) {
/* 1448:1477 */             return;
/* 1449:     */           }
/* 1450:     */         }
/* 1451:     */       }
/* 1452:     */     }
/* 1453:1483 */     long curTime = System.currentTimeMillis();
/* 1454:1484 */     setSystemSetting("WORKLISTDOWNLOADTIME", curTime + "");
/* 1455:     */   }
/* 1456:     */   
/* 1457:     */   public Date getWorkListDownloadTime()
/* 1458:     */   {
/* 1459:1488 */     String time = getSystemSetting("WORKLISTDOWNLOADTIME");
/* 1460:1490 */     if (time == null) {
/* 1461:1491 */       return null;
/* 1462:     */     }
/* 1463:1494 */     long worklistDownloadTime = Long.parseLong(time);
/* 1464:1495 */     return new Date(worklistDownloadTime);
/* 1465:     */   }
/* 1466:     */   
/* 1467:     */   public void downloadRelatedList(ProgressObserver observer)
/* 1468:     */     throws MobileApplicationException
/* 1469:     */   {
/* 1470:1499 */     Enumeration keyEnum = MobileMboUtil.getAllMobileMboNames(getAppName());
/* 1471:1500 */     while (keyEnum.hasMoreElements())
/* 1472:     */     {
/* 1473:1501 */       String name = (String)keyEnum.nextElement();
/* 1474:     */       
/* 1475:     */ 
/* 1476:     */ 
/* 1477:1505 */       MobileMboInfo mboInfo = MobileMboUtil.getMobileMboInfo(getAppName(), name);
/* 1478:1508 */       if ((mboInfo.getParent() == null) && (!mboInfo.isWorkset()))
/* 1479:     */       {
/* 1480:1510 */         downloadMobileMbos(name, observer);
/* 1481:1512 */         if (observer != null)
/* 1482:     */         {
/* 1483:1513 */           observer.updateWorkProgress();
/* 1484:1514 */           if (observer.isWorkStopped()) {
/* 1485:1515 */             return;
/* 1486:     */           }
/* 1487:     */         }
/* 1488:     */       }
/* 1489:     */     }
/* 1490:1521 */     long curTime = System.currentTimeMillis();
/* 1491:1522 */     setSystemSetting("RELLISTDOWNLOADTIME", curTime + "");
/* 1492:     */   }
/* 1493:     */   
/* 1494:     */   public Date getRelatedListDownloadTime()
/* 1495:     */   {
/* 1496:1526 */     String time = getSystemSetting("RELLISTDOWNLOADTIME");
/* 1497:1528 */     if (time == null) {
/* 1498:1529 */       return null;
/* 1499:     */     }
/* 1500:1532 */     long worklistDownloadTime = Long.parseLong(time);
/* 1501:1533 */     return new Date(worklistDownloadTime);
/* 1502:     */   }
/* 1503:     */   
/* 1504:     */   public void performDataTransaction(MobileMbo mbo)
/* 1505:     */     throws MobileApplicationException
/* 1506:     */   {
/* 1507:1537 */     DefaultMobileWebServiceProxy s = getDefaultMobileWebServiceProxy();
/* 1508:1538 */     MobileMboChange mboChange = new MobileMboChange(mbo);
/* 1509:1539 */     s.performDataTransaction(mboChange);
/* 1510:     */   }
/* 1511:     */   
/* 1512:     */   public void performDataTransaction(MobileMbo[] mbos)
/* 1513:     */     throws MobileApplicationException
/* 1514:     */   {
/* 1515:1545 */     DefaultMobileWebServiceProxy s = getDefaultMobileWebServiceProxy();
/* 1516:1546 */     MobileMboData mbosChange = new MobileMboData();
/* 1517:1547 */     mbosChange.setSize(mbos.length);
/* 1518:1548 */     mbosChange.setMobileMbos(mbos);
/* 1519:1549 */     s.performDataTransaction(mbosChange);
/* 1520:     */   }
/* 1521:     */   
/* 1522:     */   public void performDataTransactionGivenUpOnError(MobileMbo mbo)
/* 1523:     */     throws MobileApplicationException
/* 1524:     */   {
/* 1525:1553 */     DefaultMobileWebServiceProxy s = getDefaultMobileWebServiceProxy();
/* 1526:1554 */     MobileMboChange mboChange = new MobileMboChange(mbo);
/* 1527:1555 */     s.performDataTransactionGivenUpOnError(mboChange);
/* 1528:     */   }
/* 1529:     */   
/* 1530:     */   public void downloadAllMobileMbos()
/* 1531:     */     throws MobileApplicationException
/* 1532:     */   {
/* 1533:1559 */     downloadAllMobileMbos(null);
/* 1534:     */   }
/* 1535:     */   
/* 1536:     */   public void downloadAllMobileMbos(ProgressObserver observer)
/* 1537:     */     throws MobileApplicationException
/* 1538:     */   {
/* 1539:1563 */     Enumeration keyEnum = MobileMboUtil.getAllMobileMboNames(getAppName());
/* 1540:1564 */     while (keyEnum.hasMoreElements())
/* 1541:     */     {
/* 1542:1565 */       String name = (String)keyEnum.nextElement();
/* 1543:     */       
/* 1544:     */ 
/* 1545:     */ 
/* 1546:     */ 
/* 1547:1570 */       MobileMboInfo mboInfo = MobileMboUtil.getMobileMboInfo(getAppName(), name);
/* 1548:1573 */       if (mboInfo.getParent() == null)
/* 1549:     */       {
/* 1550:1574 */         downloadMobileMbos(name, observer);
/* 1551:1576 */         if (observer != null)
/* 1552:     */         {
/* 1553:1577 */           observer.updateWorkProgress();
/* 1554:1578 */           if (observer.isWorkStopped()) {
/* 1555:1579 */             return;
/* 1556:     */           }
/* 1557:     */         }
/* 1558:     */       }
/* 1559:     */     }
/* 1560:1585 */     long curTime = System.currentTimeMillis();
/* 1561:     */     
/* 1562:1587 */     setSystemSetting("WORKLISTDOWNLOADTIME", curTime + "");
/* 1563:1588 */     setSystemSetting("RELLISTDOWNLOADTIME", curTime + "");
/* 1564:     */   }
/* 1565:     */   
/* 1566:     */   public void downloadMobileMbos(String mboName, ProgressObserver observer)
/* 1567:     */     throws MobileApplicationException
/* 1568:     */   {
/* 1569:1592 */     int startIndex = 0;
/* 1570:1593 */     int size = 10;
/* 1571:     */     
/* 1572:1595 */     MobileMboInfo mboInfo = MobileMboUtil.getMobileMboInfo(getAppName(), mboName);
/* 1573:1596 */     if (mboInfo.getParent() != null) {
/* 1574:1597 */       return;
/* 1575:     */     }
/* 1576:1600 */     if (observer != null)
/* 1577:     */     {
/* 1578:1601 */       observer.setWorkProgressMessage("Downloading " + mboName + " data");
/* 1579:1602 */       if (observer.isWorkStopped()) {
/* 1580:1603 */         return;
/* 1581:     */       }
/* 1582:     */     }
/* 1583:     */     try
/* 1584:     */     {
/* 1585:1608 */       MobileMboData mboData = null;
/* 1586:     */       do
/* 1587:     */       {
/* 1588:1612 */         mboData = this.mobileWebServiceProxy.getMobileMbos(mboName, new Integer(startIndex), new Integer(size));
/* 1589:1614 */         if (mboData.isMoreAvailable()) {
/* 1590:1615 */           startIndex += mboData.getSize();
/* 1591:     */         }
/* 1592:1620 */         this.rdoRuntime.getRDOTransactionManager().begin();
/* 1593:1621 */         MobileMbo[] mbos = mboData.getMobileMbos();
/* 1594:1622 */         for (int i = 0; i < mbos.length; i++) {
/* 1595:1623 */           saveCompleteDownloadedMbo(mbos[i], false);
/* 1596:     */         }
/* 1597:1625 */         this.rdoRuntime.getRDOTransactionManager().commit();
/* 1598:1627 */         if (observer != null)
/* 1599:     */         {
/* 1600:1628 */           observer.updateWorkProgress();
/* 1601:1629 */           if (observer.isWorkStopped()) {
/* 1602:1630 */             return;
/* 1603:     */           }
/* 1604:     */         }
/* 1605:1633 */       } while (mboData.isMoreAvailable());
/* 1606:1635 */       this.rdoRuntime.getRDOTransactionManager().begin();
/* 1607:     */       
/* 1608:1637 */       mboInfo.setLastDownloadTime(new Date());
/* 1609:     */       
/* 1610:1639 */       RDO rdo = mboInfo.getRDO();
/* 1611:1640 */       this.rdoRuntime.getRDOManager().update("MAXOBJECT", rdo);
/* 1612:1641 */       this.rdoRuntime.getRDOTransactionManager().commit();
/* 1613:     */     }
/* 1614:     */     catch (Exception ex)
/* 1615:     */     {
/* 1616:     */       try
/* 1617:     */       {
/* 1618:1644 */         this.rdoRuntime.getRDOTransactionManager().rollback();
/* 1619:     */       }
/* 1620:     */       catch (Exception e) {}
/* 1621:1648 */       if ((ex instanceof MobileApplicationException)) {
/* 1622:1649 */         throw ((MobileApplicationException)ex);
/* 1623:     */       }
/* 1624:1651 */       throw new MobileApplicationException(ex);
/* 1625:     */     }
/* 1626:     */   }
/* 1627:     */   
/* 1628:     */   public void downloadMobileMbos(String mboName)
/* 1629:     */     throws MobileApplicationException
/* 1630:     */   {
/* 1631:1657 */     downloadMobileMbos(mboName, null);
/* 1632:     */   }
/* 1633:     */   
/* 1634:     */   public boolean isESigNeeded(String optionName, MobileMbo mobileMbo)
/* 1635:     */     throws MobileApplicationException
/* 1636:     */   {
/* 1637:1661 */     DefaultQBE qbe = new DefaultQBE();
/* 1638:1662 */     qbe.setQBE("OPTIONNAME", "=" + optionName);
/* 1639:     */     
/* 1640:1664 */     RDOEnumeration rdoEnum = getRDORuntime().getRDOManager().getAll("_ESIGOPTION", qbe, null);
/* 1641:1665 */     if (rdoEnum.hasMoreElements())
/* 1642:     */     {
/* 1643:1666 */       if (optionName.equals("SAVE")) {
/* 1644:1667 */         return isESigNeededForSave(mobileMbo);
/* 1645:     */       }
/* 1646:1669 */       return true;
/* 1647:     */     }
/* 1648:1672 */     return false;
/* 1649:     */   }
/* 1650:     */   
/* 1651:     */   protected boolean isESigNeededForSave(MobileMbo mobileMbo)
/* 1652:     */     throws MobileApplicationException
/* 1653:     */   {
/* 1654:1676 */     return mobileMbo.isToBePromptedForESig();
/* 1655:     */   }
/* 1656:     */   
/* 1657:     */   public void logESigVerification(String dataGroupName, String recordId, String reason, boolean attemptResult)
/* 1658:     */     throws MobileApplicationException
/* 1659:     */   {
/* 1660:1680 */     DefaultRDO eSigRDO = new DefaultRDO(getAppName());
/* 1661:1681 */     eSigRDO.setName("_ESIG");
/* 1662:1682 */     MobileMbo eSigMbo = new MobileMbo(eSigRDO);
/* 1663:1683 */     eSigRDO.setStringValue("DATAGROUPNAME", dataGroupName);
/* 1664:1684 */     eSigRDO.setStringValue("RECORDID", recordId);
/* 1665:1685 */     eSigRDO.setStringValue("REASON", reason);
/* 1666:1686 */     eSigMbo.setBooleanValue("ATTEMPTRESULT", attemptResult);
/* 1667:     */     
/* 1668:1688 */     logESigVerification(new MobileMboChange(eSigMbo));
/* 1669:     */   }
/* 1670:     */   
/* 1671:     */   private void logESigVerification(MobileMboChange mboChanges)
/* 1672:     */     throws MobileApplicationException
/* 1673:     */   {
/* 1674:1692 */     getDefaultMobileWebServiceProxy().logESigVerification(mboChanges);
/* 1675:     */   }
/* 1676:     */   
/* 1677:     */   public boolean verifyUserForESig(String userName, String password)
/* 1678:     */   {
/* 1679:1696 */     if ((this.currentUser.equals(userName)) && (this.currentUserPassword.equals(password))) {
/* 1680:1697 */       return true;
/* 1681:     */     }
/* 1682:1700 */     return false;
/* 1683:     */   }
/* 1684:     */   
/* 1685:     */   public void setAppOptionsAuthRefreshNeeded(boolean needed)
/* 1686:     */   {
/* 1687:1704 */     this.appOptionsAuthRefreshNeeded = needed;
/* 1688:     */   }
/* 1689:     */   
/* 1690:     */   public boolean isAppOptionsAuthRefreshNeeded()
/* 1691:     */   {
/* 1692:1708 */     return this.appOptionsAuthRefreshNeeded;
/* 1693:     */   }
/* 1694:     */   
/* 1695:     */   public void refreshAppOptionsAuth()
/* 1696:     */     throws MobileApplicationException
/* 1697:     */   {
/* 1698:1712 */     refreshAppOptionsAuth(null);
/* 1699:     */   }
/* 1700:     */   
/* 1701:     */   public void refreshAppOptionsAuth(ProgressObserver observer)
/* 1702:     */     throws MobileApplicationException
/* 1703:     */   {
/* 1704:1716 */     int startIndex = 0;
/* 1705:1717 */     int size = getRefreshNumberOfRecords();
/* 1706:1719 */     if (observer != null)
/* 1707:     */     {
/* 1708:1721 */       String msg = MobileMessageGenerator.generate("refreshauth", new Object[0]);
/* 1709:1722 */       observer.setWorkProgressMessage(msg);
/* 1710:1724 */       if (observer.isWorkStopped()) {
/* 1711:1725 */         return;
/* 1712:     */       }
/* 1713:     */     }
/* 1714:     */     try
/* 1715:     */     {
/* 1716:1730 */       MobileMboData mboData = null;
/* 1717:     */       do
/* 1718:     */       {
/* 1719:1735 */         mboData = this.mobileWebServiceProxy.getAppOptionsAuth(new Integer(startIndex), new Integer(size));
/* 1720:1737 */         if (mboData.isMoreAvailable()) {
/* 1721:1738 */           startIndex += mboData.getSize();
/* 1722:     */         }
/* 1723:1742 */         this.rdoRuntime.getRDOTransactionManager().begin();
/* 1724:     */         
/* 1725:1744 */         this.rdoRuntime.getRDOManager().removeAll("_APPOPTIONAUTH");
/* 1726:     */         
/* 1727:1746 */         MobileMbo[] mbos = mboData.getMobileMbos();
/* 1728:1747 */         for (int i = 0; i < mbos.length; i++) {
/* 1729:1748 */           saveCompleteDownloadedMbo(mbos[i], false);
/* 1730:     */         }
/* 1731:1750 */         this.rdoRuntime.getRDOTransactionManager().commit();
/* 1732:1752 */         if (observer != null) {
/* 1733:1753 */           observer.updateWorkProgress();
/* 1734:     */         }
/* 1735:1755 */       } while (mboData.isMoreAvailable());
/* 1736:1757 */       setAppOptionsAuthRefreshNeeded(false);
/* 1737:     */       
/* 1738:1759 */       resetAuthorizationCaches();
/* 1739:     */     }
/* 1740:     */     catch (Exception ex)
/* 1741:     */     {
/* 1742:     */       try
/* 1743:     */       {
/* 1744:1762 */         this.rdoRuntime.getRDOTransactionManager().rollback();
/* 1745:     */       }
/* 1746:     */       catch (Exception e) {}
/* 1747:1766 */       if ((ex instanceof MobileApplicationException)) {
/* 1748:1767 */         throw ((MobileApplicationException)ex);
/* 1749:     */       }
/* 1750:1769 */       throw new MobileApplicationException(ex);
/* 1751:     */     }
/* 1752:     */   }
/* 1753:     */   
/* 1754:     */   public boolean isOptionAuthorized(String optionName)
/* 1755:     */     throws MobileApplicationException
/* 1756:     */   {
/* 1757:1775 */     if (!isInitialized()) {
/* 1758:1776 */       return true;
/* 1759:     */     }
/* 1760:1780 */     return checkOptionNameAtAuthorizationsCache(this.systemLevelAuthorizations, optionName, null);
/* 1761:     */   }
/* 1762:     */   
/* 1763:     */   public boolean isOptionAuthorizedAtSite(String optionName, String siteId)
/* 1764:     */     throws MobileApplicationException
/* 1765:     */   {
/* 1766:1786 */     if (!isInitialized()) {
/* 1767:1787 */       return true;
/* 1768:     */     }
/* 1769:1791 */     return checkOptionNameAtAuthorizationsCache(this.siteLevelAuthorizations, optionName, siteId);
/* 1770:     */   }
/* 1771:     */   
/* 1772:     */   public boolean isOptionAuthorizedAtOrg(String optionName, String orgId)
/* 1773:     */     throws MobileApplicationException
/* 1774:     */   {
/* 1775:1797 */     if (!isInitialized()) {
/* 1776:1798 */       return true;
/* 1777:     */     }
/* 1778:1802 */     return checkOptionNameAtAuthorizationsCache(this.orgLevelAuthorizations, optionName, orgId);
/* 1779:     */   }
/* 1780:     */   
/* 1781:     */   private boolean checkOptionNameAtAuthorizationsCache(Hashtable authCache, String optionName, String orgSiteId)
/* 1782:     */   {
/* 1783:1820 */     char separator = ',';
/* 1784:     */     
/* 1785:     */ 
/* 1786:     */ 
/* 1787:     */ 
/* 1788:1825 */     boolean andCondition = true;
/* 1789:1826 */     if (optionName.indexOf(';') >= 0)
/* 1790:     */     {
/* 1791:1827 */       separator = ';';
/* 1792:1828 */       andCondition = false;
/* 1793:     */     }
/* 1794:1831 */     String[] allOptionNames = splitOptionNames(optionName, separator);
/* 1795:1832 */     boolean hasAccess = false;
/* 1796:1833 */     for (int i = 0; i < allOptionNames.length; i++)
/* 1797:     */     {
/* 1798:1834 */       String authorized = (String)authCache.get(allOptionNames[i]);
/* 1799:1836 */       if (authorized == null)
/* 1800:     */       {
/* 1801:1837 */         hasAccess = false;
/* 1802:1838 */         if (andCondition) {
/* 1803:1839 */           return hasAccess;
/* 1804:     */         }
/* 1805:     */       }
/* 1806:1842 */       else if (orgSiteId == null)
/* 1807:     */       {
/* 1808:1843 */         hasAccess = true;
/* 1809:1844 */         if (!andCondition) {
/* 1810:1845 */           return hasAccess;
/* 1811:     */         }
/* 1812:     */       }
/* 1813:1848 */       else if (orgSiteId.equalsIgnoreCase(authorized))
/* 1814:     */       {
/* 1815:1849 */         hasAccess = true;
/* 1816:1850 */         if (!andCondition) {
/* 1817:1851 */           return hasAccess;
/* 1818:     */         }
/* 1819:     */       }
/* 1820:     */       else
/* 1821:     */       {
/* 1822:1854 */         hasAccess = false;
/* 1823:1855 */         if (andCondition) {
/* 1824:1856 */           return hasAccess;
/* 1825:     */         }
/* 1826:     */       }
/* 1827:     */     }
/* 1828:1863 */     return hasAccess;
/* 1829:     */   }
/* 1830:     */   
/* 1831:     */   private static String[] splitOptionNames(String list, char separator)
/* 1832:     */   {
/* 1833:1877 */     List temp = new ArrayList();
/* 1834:1878 */     int end = list.indexOf(separator);
/* 1835:1879 */     while (end >= 0)
/* 1836:     */     {
/* 1837:1880 */       String token = list.substring(0, end).trim();
/* 1838:1881 */       temp.add(token);
/* 1839:1882 */       if (end + 1 >= list.length()) {
/* 1840:     */         break;
/* 1841:     */       }
/* 1842:1883 */       list = list.substring(end + 1, list.length());
/* 1843:1884 */       end = list.indexOf(separator);
/* 1844:     */     }
/* 1845:1889 */     if (list.length() > 0) {
/* 1846:1890 */       temp.add(list.trim());
/* 1847:     */     }
/* 1848:1893 */     String[] array = new String[temp.size()];
/* 1849:1894 */     for (int i = 0; i < array.length; i++) {
/* 1850:1895 */       array[i] = ((String)temp.get(i));
/* 1851:     */     }
/* 1852:1898 */     return array;
/* 1853:     */   }
/* 1854:     */   
/* 1855:     */   protected void resetAuthorizationCaches()
/* 1856:     */     throws MobileApplicationException
/* 1857:     */   {
/* 1858:1902 */     this.systemLevelAuthorizations = new Hashtable();
/* 1859:1903 */     this.siteLevelAuthorizations = new Hashtable();
/* 1860:1904 */     this.orgLevelAuthorizations = new Hashtable();
/* 1861:     */     
/* 1862:     */ 
/* 1863:     */ 
/* 1864:     */ 
/* 1865:     */ 
/* 1866:1910 */     MobileMboDataBeanManager mgrAppAuth = new MobileMboDataBeanManager("_APPOPTIONAUTH");
/* 1867:1911 */     MobileMboDataBean authBean = mgrAppAuth.getDataBean();
/* 1868:1912 */     authBean.getQBE().reset();
/* 1869:1913 */     authBean.reset();
/* 1870:1914 */     for (int i = 0; i < authBean.count(); i++)
/* 1871:     */     {
/* 1872:1915 */       MobileMbo authMbo = authBean.getMobileMbo(i);
/* 1873:1916 */       if (!authMbo.isNull("SITEID")) {
/* 1874:1917 */         this.siteLevelAuthorizations.put(authBean.getValue(i, "OPTIONNAME"), authBean.getValue(i, "SITEID"));
/* 1875:     */       }
/* 1876:1920 */       if ((authMbo.isNull("SITEID")) && (!authMbo.isNull("ORGID"))) {
/* 1877:1921 */         this.orgLevelAuthorizations.put(authBean.getValue(i, "OPTIONNAME"), authBean.getValue(i, "ORGID"));
/* 1878:     */       }
/* 1879:1923 */       if ((authMbo.isNull("SITEID")) && (authMbo.isNull("ORGID"))) {
/* 1880:1924 */         this.systemLevelAuthorizations.put(authBean.getValue(i, "OPTIONNAME"), authBean.getValue(i, "OPTIONNAME"));
/* 1881:     */       }
/* 1882:     */     }
/* 1883:     */   }
/* 1884:     */   
/* 1885:     */   public boolean isSigOption(String optionName)
/* 1886:     */     throws MobileApplicationException
/* 1887:     */   {
/* 1888:1931 */     return isOptionAuthorized(optionName);
/* 1889:     */   }
/* 1890:     */   
/* 1891:     */   public void refreshAllMobileMbos()
/* 1892:     */     throws MobileApplicationException
/* 1893:     */   {
/* 1894:1954 */     refreshAllMobileMbos(null);
/* 1895:     */   }
/* 1896:     */   
/* 1897:     */   public void refreshAllMobileMbos(ProgressObserver observer)
/* 1898:     */     throws MobileApplicationException
/* 1899:     */   {
/* 1900:1958 */     refreshAllMobileMbos(observer, true, true);
/* 1901:     */   }
/* 1902:     */   
/* 1903:     */   public String[] getSmartSystemRefreshOrder()
/* 1904:     */     throws MobileApplicationException
/* 1905:     */   {
/* 1906:1962 */     String[] orderedNames = this.mobileWebServiceProxy.getSmartSystemRefreshOrder();
/* 1907:1963 */     return orderedNames;
/* 1908:     */   }
/* 1909:     */   
/* 1910:     */   public String[] getSystemRefreshOrder()
/* 1911:     */     throws MobileApplicationException
/* 1912:     */   {
/* 1913:1967 */     String[] orderedNames = this.mobileWebServiceProxy.getSystemRefreshOrder();
/* 1914:1968 */     return orderedNames;
/* 1915:     */   }
/* 1916:     */   
/* 1917:     */   public String[] getSmartRefreshOrder(String[] queries)
/* 1918:     */     throws MobileApplicationException
/* 1919:     */   {
/* 1920:1972 */     String[] orderedNames = this.mobileWebServiceProxy.getSmartRefreshOrder(queries);
/* 1921:1973 */     return orderedNames;
/* 1922:     */   }
/* 1923:     */   
/* 1924:     */   public String[] getRefreshOrder()
/* 1925:     */     throws MobileApplicationException
/* 1926:     */   {
/* 1927:1977 */     String[] orderedNames = this.mobileWebServiceProxy.getRefreshOrder();
/* 1928:1978 */     return orderedNames;
/* 1929:     */   }
/* 1930:     */   
/* 1931:     */   public String[] getSmartWorkRefreshOrder(String[] queries)
/* 1932:     */     throws MobileApplicationException
/* 1933:     */   {
/* 1934:1982 */     String[] orderedNames = this.mobileWebServiceProxy.getSmartWorkRefreshOrder(queries);
/* 1935:1983 */     return orderedNames;
/* 1936:     */   }
/* 1937:     */   
/* 1938:     */   public String[] getWorkRefreshOrder()
/* 1939:     */     throws MobileApplicationException
/* 1940:     */   {
/* 1941:1987 */     String[] orderedNames = this.mobileWebServiceProxy.getWorkRefreshOrder();
/* 1942:1988 */     return orderedNames;
/* 1943:     */   }
/* 1944:     */   
/* 1945:     */   public synchronized void refreshAllMobileMbos(ProgressObserver observer, boolean includeWorkList, boolean includeRelatedList)
/* 1946:     */     throws MobileApplicationException
/* 1947:     */   {
/* 1948:1993 */     MobileDeviceAppService appService = this.mobileWebServiceProxy.getService();
/* 1949:1994 */     appService.setProcessDataTransactionResultOnce();
/* 1950:     */     try
/* 1951:     */     {
/* 1952:1997 */       refreshAllMobileMbosOnly(observer, includeWorkList, includeRelatedList);
/* 1953:     */     }
/* 1954:     */     finally
/* 1955:     */     {
/* 1956:1999 */       appService.resetProcessDataTransactionResultOnce();
/* 1957:     */     }
/* 1958:     */   }
/* 1959:     */   
/* 1960:     */   public synchronized void refreshAllMobileMbosOnly(ProgressObserver observer, boolean includeWorkList, boolean includeRelatedList)
/* 1961:     */     throws MobileApplicationException
/* 1962:     */   {
/* 1963:2014 */     if (isAppOptionsAuthRefreshNeeded()) {
/* 1964:2015 */       refreshAppOptionsAuth(observer);
/* 1965:     */     }
/* 1966:2022 */     appPreRefreshMobileMbos(includeWorkList, includeRelatedList);
/* 1967:     */     
/* 1968:2024 */     boolean adHocErrorMgmtEnabled = isAdHocErrorManagementEnabled();
/* 1969:2025 */     if (adHocErrorMgmtEnabled)
/* 1970:     */     {
/* 1971:2029 */       refreshMobileMbos("MOBILEDATATXNQERR", observer);
/* 1972:2030 */       retrieveFailedTxns();
/* 1973:     */     }
/* 1974:2033 */     determineTimeAdjustment(observer);
/* 1975:     */     
/* 1976:2035 */     String[] orderedNames = null;
/* 1977:2037 */     if ((includeWorkList) && (!includeRelatedList))
/* 1978:     */     {
/* 1979:2038 */       if (observer != null)
/* 1980:     */       {
/* 1981:2039 */         String msg = MobileMessageGenerator.generate("refreshwork", new Object[0]);
/* 1982:2040 */         observer.setWorkProgressMessage(msg);
/* 1983:2041 */         if (observer.isWorkStopped()) {
/* 1984:2042 */           return;
/* 1985:     */         }
/* 1986:     */       }
/* 1987:2046 */       orderedNames = getSmartWorkRefreshOrder(getDefaultQueries());
/* 1988:     */       
/* 1989:2048 */       boolean dependentFiltersOnly = true;
/* 1990:     */       
/* 1991:2050 */       setTotalDownloadCount(computeDownloadCount(orderedNames));
/* 1992:     */       
/* 1993:     */ 
/* 1994:     */ 
/* 1995:     */ 
/* 1996:     */ 
/* 1997:2056 */       this.mobileWebServiceProxy.getService().setProcessDataTransactionResultOnce();
/* 1998:2058 */       for (int i = 0; i < orderedNames.length; i++)
/* 1999:     */       {
/* 2000:2059 */         String mobileMboName = orderedNames[i];
/* 2001:2060 */         if (mobileMboName != null) {
/* 2002:2061 */           refreshMobileMbos(mobileMboName, observer, dependentFiltersOnly);
/* 2003:     */         }
/* 2004:     */       }
/* 2005:     */     }
/* 2006:     */     else
/* 2007:     */     {
/* 2008:2065 */       if (observer != null)
/* 2009:     */       {
/* 2010:2066 */         String msg = MobileMessageGenerator.generate("refreshall", new Object[0]);
/* 2011:2067 */         observer.setWorkProgressMessage(msg);
/* 2012:2068 */         if (observer.isWorkStopped()) {
/* 2013:2069 */           return;
/* 2014:     */         }
/* 2015:     */       }
/* 2016:2072 */       orderedNames = getSmartRefreshOrder(getDefaultQueries());
/* 2017:2073 */       for (int i = 0; i < orderedNames.length; i++)
/* 2018:     */       {
/* 2019:2074 */         MobileMboInfo mboInfo = MobileMboUtil.getMobileMboInfo(getAppName(), orderedNames[i]);
/* 2020:2075 */         if ((includeRelatedList) && (!includeWorkList) && 
/* 2021:2076 */           (mboInfo.isWorkset())) {
/* 2022:2077 */           orderedNames[i] = null;
/* 2023:     */         }
/* 2024:     */       }
/* 2025:2082 */       boolean dependentFiltersOnly = true;
/* 2026:     */       
/* 2027:2084 */       setTotalDownloadCount(computeDownloadCount(orderedNames));
/* 2028:2086 */       for (int i = 0; i < orderedNames.length; i++)
/* 2029:     */       {
/* 2030:2087 */         String mobileMboName = orderedNames[i];
/* 2031:2088 */         if (mobileMboName != null) {
/* 2032:2089 */           refreshMobileMbos(mobileMboName, observer);
/* 2033:     */         }
/* 2034:     */       }
/* 2035:     */     }
/* 2036:2096 */     if ((includeWorkList) && 
/* 2037:2097 */       (observer != null) && (!observer.isWorkStopped()))
/* 2038:     */     {
/* 2039:2098 */       long curTime = System.currentTimeMillis();
/* 2040:2099 */       setSystemSetting("WORKLISTDOWNLOADTIME", curTime + "");
/* 2041:     */     }
/* 2042:2103 */     if ((includeRelatedList) && 
/* 2043:2104 */       (observer != null) && (!observer.isWorkStopped()))
/* 2044:     */     {
/* 2045:2105 */       long curTime = System.currentTimeMillis();
/* 2046:2106 */       setSystemSetting("RELLISTDOWNLOADTIME", curTime + "");
/* 2047:     */     }
/* 2048:2110 */     if ((includeWorkList) && 
/* 2049:2111 */       (this.autoRefreshWorker != null)) {
/* 2050:2112 */       this.autoRefreshWorker.reset();
/* 2051:     */     }
/* 2052:2116 */     if ((includeWorkList) && (includeRelatedList) && 
/* 2053:2117 */       (observer != null) && (!observer.isWorkStopped())) {
/* 2054:2118 */       setSystemSetting("REFRESHALLDONEONCE", "true");
/* 2055:     */     }
/* 2056:2126 */     appPostRefreshMobileMbos(includeWorkList, includeRelatedList);
/* 2057:     */   }
/* 2058:     */   
/* 2059:     */   public void retrieveFailedTxns()
/* 2060:     */     throws MobileApplicationException
/* 2061:     */   {
/* 2062:2130 */     MobileMboDataBeanManager dataBeanManager = new MobileMboDataBeanManager("MOBILEDATATXNQERR");
/* 2063:2131 */     MobileMboDataBean userDataBean = dataBeanManager.getDataBean();
/* 2064:2132 */     userDataBean.reset();
/* 2065:     */     
/* 2066:2134 */     DefaultMobileWebServiceProxy proxy = getDefaultMobileWebServiceProxy();
/* 2067:2135 */     int i = 0;
/* 2068:     */     for (;;)
/* 2069:     */     {
/* 2070:2137 */       MobileMbo mobileMbo = userDataBean.getMobileMbo(i);
/* 2071:2138 */       if (mobileMbo == null) {
/* 2072:     */         break;
/* 2073:     */       }
/* 2074:2142 */       String dataGroupName = mobileMbo.getValue("OWNERDATAGROUPNAME");
/* 2075:2143 */       long recordId = mobileMbo.getLongValue("OWNERRECORDID");
/* 2076:     */       
/* 2077:2145 */       RDO existingRDO = this.rdoRuntime.getRDOManager().get(dataGroupName, recordId);
/* 2078:2146 */       if ((existingRDO != null) && (existingRDO.getBooleanValue("_MODIFIED")))
/* 2079:     */       {
/* 2080:2147 */         i++;
/* 2081:     */       }
/* 2082:     */       else
/* 2083:     */       {
/* 2084:2151 */         MobileMbo errMobileMbo = proxy.getLatestTransactionData(mobileMbo);
/* 2085:     */         
/* 2086:2153 */         this.rdoRuntime.getRDOTransactionManager().begin();
/* 2087:2154 */         saveCompleteDownloadedMbo(errMobileMbo);
/* 2088:2155 */         this.rdoRuntime.getRDOTransactionManager().commit();
/* 2089:     */         
/* 2090:2157 */         proxy.cleanupErrTransactionData(errMobileMbo);
/* 2091:     */         
/* 2092:2159 */         i++;
/* 2093:     */       }
/* 2094:     */     }
/* 2095:     */   }
/* 2096:     */   
/* 2097:     */   public boolean isAdHocErrorManagementEnabled()
/* 2098:     */   {
/* 2099:2164 */     return this.adHocErrorMgmtEnabled;
/* 2100:     */   }
/* 2101:     */   
/* 2102:     */   public void determineAdHocErrorManagement()
/* 2103:     */   {
/* 2104:2169 */     this.adHocErrorMgmtEnabled = true;
/* 2105:     */     
/* 2106:2171 */     String adHocErrorMgmtProperty = getProperty("maximo.errmgmt.adhoc");
/* 2107:2172 */     if ((adHocErrorMgmtProperty != null) && (!adHocErrorMgmtProperty.equals("true"))) {
/* 2108:2173 */       this.adHocErrorMgmtEnabled = false;
/* 2109:     */     }
/* 2110:     */   }
/* 2111:     */   
/* 2112:     */   public boolean canSkipRefresh(String mobileMboName)
/* 2113:     */   {
/* 2114:2178 */     if (!isAdHocErrorManagementEnabled()) {
/* 2115:2181 */       if (mobileMboName.equals("MOBILEDATATXNQERR")) {
/* 2116:2182 */         return true;
/* 2117:     */       }
/* 2118:     */     }
/* 2119:2186 */     return false;
/* 2120:     */   }
/* 2121:     */   
/* 2122:     */   public void refreshWorkList()
/* 2123:     */     throws MobileApplicationException
/* 2124:     */   {
/* 2125:2190 */     refreshWorkList(null);
/* 2126:     */   }
/* 2127:     */   
/* 2128:     */   public void refreshWorkList(ProgressObserver observer)
/* 2129:     */     throws MobileApplicationException
/* 2130:     */   {
/* 2131:2194 */     refreshAllMobileMbos(observer, true, false);
/* 2132:     */   }
/* 2133:     */   
/* 2134:     */   public void refreshRelatedList()
/* 2135:     */     throws MobileApplicationException
/* 2136:     */   {
/* 2137:2198 */     refreshRelatedList(null);
/* 2138:     */   }
/* 2139:     */   
/* 2140:     */   public void refreshRelatedList(ProgressObserver observer)
/* 2141:     */     throws MobileApplicationException
/* 2142:     */   {
/* 2143:2202 */     refreshAllMobileMbos(observer, false, true);
/* 2144:     */   }
/* 2145:     */   
/* 2146:     */   public void refreshMobileMbos(String mboName)
/* 2147:     */     throws MobileApplicationException
/* 2148:     */   {
/* 2149:2206 */     refreshMobileMbos(mboName, null);
/* 2150:     */   }
/* 2151:     */   
/* 2152:     */   public void refreshMobileMbos(String mboName, ProgressObserver observer)
/* 2153:     */     throws MobileApplicationException
/* 2154:     */   {
/* 2155:2210 */     refreshMobileMbos(mboName, observer, false);
/* 2156:     */   }
/* 2157:     */   
/* 2158:     */   public void refreshMobileMbos(String mboName, ProgressObserver observer, boolean dependentFilterOnly)
/* 2159:     */     throws MobileApplicationException
/* 2160:     */   {
/* 2161:2217 */     int startIndex = 0;
/* 2162:2218 */     int size = getRefreshNumberOfRecords();
/* 2163:     */     
/* 2164:2220 */     int mboCount2Download = 0;
/* 2165:2221 */     String mboCount2 = "";
/* 2166:2222 */     int hasCount = mboName.indexOf(":");
/* 2167:2223 */     if (hasCount > 0)
/* 2168:     */     {
/* 2169:2224 */       mboCount2 = mboName.substring(hasCount + 1);
/* 2170:2225 */       mboCount2Download = Integer.parseInt(mboCount2);
/* 2171:2226 */       mboName = mboName.substring(0, hasCount);
/* 2172:     */     }
/* 2173:2229 */     MobileMboInfo mboInfo = MobileMboUtil.getMobileMboInfo(getAppName(), mboName);
/* 2174:2230 */     if ((mboInfo.getParent() != null) || (mboInfo.isLocalWorkset()) || (mboInfo.isLocalWorksetUpload())) {
/* 2175:2231 */       return;
/* 2176:     */     }
/* 2177:2235 */     if (canSkipRefresh(mboName)) {
/* 2178:2236 */       return;
/* 2179:     */     }
/* 2180:2239 */     if (observer != null)
/* 2181:     */     {
/* 2182:2240 */       String curStat = "";
/* 2183:2241 */       if (hasCount > 0) {
/* 2184:2242 */         if (mboCount2Download < size) {
/* 2185:2243 */           curStat = String.valueOf(mboCount2Download) + " / " + mboCount2;
/* 2186:     */         } else {
/* 2187:2245 */           curStat = size + " / " + mboCount2;
/* 2188:     */         }
/* 2189:     */       }
/* 2190:2248 */       String msg = MobileMessageGenerator.generate("refreshmbo", new Object[] { mboInfo.getDescription() + " " + curStat });
/* 2191:2249 */       observer.setWorkProgressMessage(msg);
/* 2192:2250 */       if (observer.isWorkStopped()) {
/* 2193:2251 */         return;
/* 2194:     */       }
/* 2195:     */     }
/* 2196:     */     try
/* 2197:     */     {
/* 2198:2256 */       MobileMboData mboData = null;
/* 2199:2257 */       String[] queries = getDefaultQueries(mboName);
/* 2200:2258 */       if (queries == null) {
/* 2201:2259 */         queries = new String[0];
/* 2202:     */       }
/* 2203:     */       do
/* 2204:     */       {
/* 2205:2265 */         int curCount = 0;
/* 2206:2266 */         String countStatus = "";
/* 2207:2267 */         if (queries != null) {
/* 2208:2268 */           mboData = this.mobileWebServiceProxy.getIncrementalUpdateOfMobileMbos(mboName, queries, new Integer(startIndex), new Integer(size), new Boolean(dependentFilterOnly));
/* 2209:     */         }
/* 2210:2272 */         if (mboData.isMoreAvailable())
/* 2211:     */         {
/* 2212:2273 */           startIndex += mboData.getSize();
/* 2213:2274 */           if (hasCount > 0)
/* 2214:     */           {
/* 2215:2275 */             curCount = startIndex + 1;
/* 2216:2276 */             if (mboCount2Download - curCount > size) {
/* 2217:2277 */               countStatus = String.valueOf(curCount + size) + "/" + mboCount2;
/* 2218:     */             } else {
/* 2219:2279 */               countStatus = mboCount2Download + "/" + mboCount2;
/* 2220:     */             }
/* 2221:     */           }
/* 2222:     */         }
/* 2223:2283 */         if (observer != null)
/* 2224:     */         {
/* 2225:2284 */           String msg = MobileMessageGenerator.generate("refreshmbo", new Object[] { mboInfo.getDescription() + " " + countStatus });
/* 2226:2285 */           observer.setWorkProgressMessage(msg);
/* 2227:2286 */           if (observer.isWorkStopped()) {
/* 2228:2287 */             return;
/* 2229:     */           }
/* 2230:     */         }
/* 2231:2290 */         this.rdoRuntime.getRDOTransactionManager().begin();
/* 2232:2291 */         MobileMbo[] mbos = mboData.getMobileMbos();
/* 2233:2292 */         for (int i = 0; i < mbos.length; i++) {
/* 2234:2293 */           saveCompleteDownloadedMbo(mbos[i], true);
/* 2235:     */         }
/* 2236:2295 */         this.rdoRuntime.getRDOTransactionManager().commit();
/* 2237:2296 */         setTotalDownloadCount(getBalanceDownloadCount(mbos.length));
/* 2238:2297 */         if (observer != null)
/* 2239:     */         {
/* 2240:2298 */           observer.updateWorkProgress();
/* 2241:2299 */           if (observer.isWorkStopped()) {
/* 2242:2300 */             return;
/* 2243:     */           }
/* 2244:     */         }
/* 2245:2303 */       } while (mboData.isMoreAvailable());
/* 2246:2305 */       this.mobileWebServiceProxy.acknowledgeIncrementalUpdate(mboName);
/* 2247:     */       
/* 2248:2307 */       this.rdoRuntime.getRDOTransactionManager().begin();
/* 2249:     */       
/* 2250:2309 */       mboInfo.setLastDownloadTime(new Date());
/* 2251:     */       
/* 2252:2311 */       RDO rdo = mboInfo.getRDO();
/* 2253:2312 */       this.rdoRuntime.getRDOManager().update("MAXOBJECT", rdo);
/* 2254:2313 */       this.rdoRuntime.getRDOTransactionManager().commit();
/* 2255:     */     }
/* 2256:     */     catch (Exception ex)
/* 2257:     */     {
/* 2258:     */       try
/* 2259:     */       {
/* 2260:2316 */         this.rdoRuntime.getRDOTransactionManager().rollback();
/* 2261:     */       }
/* 2262:     */       catch (Exception e) {}
/* 2263:2320 */       if ((ex instanceof MobileApplicationException)) {
/* 2264:2321 */         throw ((MobileApplicationException)ex);
/* 2265:     */       }
/* 2266:2323 */       throw new MobileApplicationException(ex);
/* 2267:     */     }
/* 2268:     */   }
/* 2269:     */   
/* 2270:     */   public String[] getDefaultQueries(String mobileMboName)
/* 2271:     */     throws MobileApplicationException
/* 2272:     */   {
/* 2273:2328 */     return new String[0];
/* 2274:     */   }
/* 2275:     */   
/* 2276:     */   public String[] getDefaultWorkQueries()
/* 2277:     */     throws MobileApplicationException
/* 2278:     */   {
/* 2279:2332 */     return new String[0];
/* 2280:     */   }
/* 2281:     */   
/* 2282:     */   public String[] getDefaultQueries()
/* 2283:     */     throws MobileApplicationException
/* 2284:     */   {
/* 2285:2336 */     return new String[0];
/* 2286:     */   }
/* 2287:     */   
/* 2288:     */   public Enumeration getMobileMbosRemote(String mboName, int startIndex, int size)
/* 2289:     */   {
/* 2290:2340 */     Vector mbos = new Vector();
/* 2291:     */     
/* 2292:2342 */     int totalSize = size;
/* 2293:2343 */     int chunkSize = 20;
/* 2294:2344 */     int fetchSize = 0;
/* 2295:     */     try
/* 2296:     */     {
/* 2297:2346 */       MobileMboData mboData = null;
/* 2298:     */       do
/* 2299:     */       {
/* 2300:2348 */         mboData = this.mobileWebServiceProxy.getMobileMbos(mboName, new Integer(startIndex), new Integer(chunkSize));
/* 2301:2350 */         if (mboData.isMoreAvailable()) {
/* 2302:2351 */           startIndex += mboData.getSize();
/* 2303:     */         }
/* 2304:2354 */         MobileMbo[] chunkMbos = mboData.getMobileMbos();
/* 2305:2355 */         for (int i = 0; i < chunkMbos.length; i++) {
/* 2306:2356 */           mbos.addElement(chunkMbos[i]);
/* 2307:     */         }
/* 2308:2358 */         fetchSize += chunkSize;
/* 2309:2359 */         if (!mboData.isMoreAvailable()) {
/* 2310:     */           break;
/* 2311:     */         }
/* 2312:2359 */       } while (fetchSize < totalSize);
/* 2313:     */     }
/* 2314:     */     catch (Exception ex)
/* 2315:     */     {
/* 2316:2361 */       getDefaultLogger().warn("Failed to get mobile mbos", ex);
/* 2317:     */       try
/* 2318:     */       {
/* 2319:2363 */         this.rdoRuntime.getRDOTransactionManager().rollback();
/* 2320:     */       }
/* 2321:     */       catch (Exception e) {}
/* 2322:     */     }
/* 2323:2368 */     return mbos.elements();
/* 2324:     */   }
/* 2325:     */   
/* 2326:     */   public Enumeration getMobileMbosRemote(String mboName, int startIndex, int size, MobileMboQBE filter, MobileMboOrder order)
/* 2327:     */     throws MobileApplicationException
/* 2328:     */   {
/* 2329:2373 */     return getMobileMbosRemote(mboName, startIndex, size, filter, null, order);
/* 2330:     */   }
/* 2331:     */   
/* 2332:     */   public Enumeration getMobileMbosRemote(String mboName, int startIndex, int size, MobileMboQBE filter, MobileWhereClause whereClause, MobileMboOrder order)
/* 2333:     */     throws MobileApplicationException
/* 2334:     */   {
/* 2335:2378 */     Vector mbos = new Vector();
/* 2336:     */     
/* 2337:2380 */     int totalSize = size;
/* 2338:2381 */     int chunkSize = 20;
/* 2339:2382 */     int fetchSize = 0;
/* 2340:     */     try
/* 2341:     */     {
/* 2342:2384 */       MobileMboData mboData = null;
/* 2343:     */       do
/* 2344:     */       {
/* 2345:2386 */         mboData = this.mobileWebServiceProxy.getMobileMbos(mboName, new Integer(startIndex), new Integer(chunkSize), filter, whereClause, order);
/* 2346:2389 */         if (mboData.isMoreAvailable()) {
/* 2347:2390 */           startIndex += mboData.getSize();
/* 2348:     */         }
/* 2349:2393 */         MobileMbo[] chunkMbos = mboData.getMobileMbos();
/* 2350:2394 */         for (int i = 0; i < chunkMbos.length; i++) {
/* 2351:2395 */           mbos.addElement(chunkMbos[i]);
/* 2352:     */         }
/* 2353:2397 */         fetchSize += chunkSize;
/* 2354:2398 */         if (!mboData.isMoreAvailable()) {
/* 2355:     */           break;
/* 2356:     */         }
/* 2357:2398 */       } while (fetchSize < totalSize);
/* 2358:     */     }
/* 2359:     */     catch (Exception ex)
/* 2360:     */     {
/* 2361:2400 */       getDefaultLogger().warn("Failed to get mobile mbos", ex);
/* 2362:     */       try
/* 2363:     */       {
/* 2364:2402 */         this.rdoRuntime.getRDOTransactionManager().rollback();
/* 2365:     */       }
/* 2366:     */       catch (Exception e) {}
/* 2367:     */     }
/* 2368:2407 */     return mbos.elements();
/* 2369:     */   }
/* 2370:     */   
/* 2371:     */   private MobileMboInfo checkInfoExists(String name)
/* 2372:     */     throws MobileApplicationException
/* 2373:     */   {
/* 2374:2411 */     MobileMboInfo info = getMobileMboInfo(name);
/* 2375:2413 */     if (info == null) {
/* 2376:2414 */       throw new MobileApplicationException("unknownmobilembo", new Object[] { name });
/* 2377:     */     }
/* 2378:2417 */     return info;
/* 2379:     */   }
/* 2380:     */   
/* 2381:     */   public MobileMbo createMobileMbo(String name)
/* 2382:     */     throws MobileApplicationException
/* 2383:     */   {
/* 2384:2421 */     checkInfoExists(name);
/* 2385:     */     
/* 2386:2423 */     DefaultRDO rdo = new DefaultRDO(this.appName);
/* 2387:2424 */     rdo.setName(name);
/* 2388:     */     
/* 2389:2426 */     MobileMbo mobileMbo = new MobileMbo(rdo);
/* 2390:     */     
/* 2391:2428 */     return mobileMbo;
/* 2392:     */   }
/* 2393:     */   
/* 2394:     */   public void insertMobileMbo(String name, MobileMbo mbo)
/* 2395:     */     throws MobileApplicationException
/* 2396:     */   {
/* 2397:2432 */     checkInfoExists(name);
/* 2398:     */     try
/* 2399:     */     {
/* 2400:2435 */       this.rdoRuntime.getRDOTransactionManager().begin();
/* 2401:2436 */       this.rdoRuntime.getRDOManager().insert(name, mbo.getRDO());
/* 2402:2437 */       this.rdoRuntime.getRDOTransactionManager().commit();
/* 2403:     */     }
/* 2404:     */     catch (RDOException ex)
/* 2405:     */     {
/* 2406:2439 */       getDefaultLogger().warn("Failed to insert mobile mbo for name: " + name, ex);
/* 2407:     */       try
/* 2408:     */       {
/* 2409:2441 */         this.rdoRuntime.getRDOTransactionManager().rollback();
/* 2410:     */       }
/* 2411:     */       catch (Exception e) {}
/* 2412:2445 */       throw ex;
/* 2413:     */     }
/* 2414:     */   }
/* 2415:     */   
/* 2416:     */   public void updateMobileMbo(String name, MobileMbo mbo)
/* 2417:     */     throws MobileApplicationException
/* 2418:     */   {
/* 2419:2450 */     checkInfoExists(name);
/* 2420:     */     try
/* 2421:     */     {
/* 2422:2453 */       this.rdoRuntime.getRDOTransactionManager().begin();
/* 2423:2454 */       this.rdoRuntime.getRDOManager().update(name, mbo.getRDO());
/* 2424:2455 */       this.rdoRuntime.getRDOTransactionManager().commit();
/* 2425:     */     }
/* 2426:     */     catch (RDOException ex)
/* 2427:     */     {
/* 2428:2457 */       getDefaultLogger().warn("Failed to update mobile mbo for name: " + name, ex);
/* 2429:     */       try
/* 2430:     */       {
/* 2431:2459 */         this.rdoRuntime.getRDOTransactionManager().rollback();
/* 2432:     */       }
/* 2433:     */       catch (Exception e) {}
/* 2434:2463 */       throw ex;
/* 2435:     */     }
/* 2436:     */   }
/* 2437:     */   
/* 2438:     */   public void removeMobileMbo(String name, MobileMbo mbo)
/* 2439:     */     throws MobileApplicationException
/* 2440:     */   {
/* 2441:2468 */     checkInfoExists(name);
/* 2442:     */     try
/* 2443:     */     {
/* 2444:2471 */       this.rdoRuntime.getRDOTransactionManager().begin();
/* 2445:2472 */       this.rdoRuntime.getRDOManager().remove(name, mbo.getRDO());
/* 2446:2473 */       this.rdoRuntime.getRDOTransactionManager().commit();
/* 2447:     */     }
/* 2448:     */     catch (RDOException ex)
/* 2449:     */     {
/* 2450:2475 */       getDefaultLogger().warn("Failed to remove mobile mbo for name: " + name, ex);
/* 2451:     */       try
/* 2452:     */       {
/* 2453:2477 */         this.rdoRuntime.getRDOTransactionManager().rollback();
/* 2454:     */       }
/* 2455:     */       catch (Exception e) {}
/* 2456:2481 */       throw ex;
/* 2457:     */     }
/* 2458:     */   }
/* 2459:     */   
/* 2460:     */   public void saveMobileMbo(String name, MobileMbo mbo)
/* 2461:     */     throws MobileApplicationException
/* 2462:     */   {
/* 2463:2486 */     checkInfoExists(name);
/* 2464:     */     try
/* 2465:     */     {
/* 2466:2489 */       this.rdoRuntime.getRDOTransactionManager().begin();
/* 2467:2490 */       saveMobileMboChanges(mbo);
/* 2468:2491 */       this.rdoRuntime.getRDOTransactionManager().commit();
/* 2469:     */     }
/* 2470:     */     catch (RDOException ex)
/* 2471:     */     {
/* 2472:2493 */       getDefaultLogger().warn("Failed to save mobile mbo for name: " + name, ex);
/* 2473:     */       try
/* 2474:     */       {
/* 2475:2495 */         this.rdoRuntime.getRDOTransactionManager().rollback();
/* 2476:     */       }
/* 2477:     */       catch (Exception e) {}
/* 2478:2499 */       throw ex;
/* 2479:     */     }
/* 2480:     */   }
/* 2481:     */   
/* 2482:     */   protected void saveMobileMboChanges(MobileMbo mbo)
/* 2483:     */     throws MobileApplicationException
/* 2484:     */   {
/* 2485:2504 */     RDO rdo = mbo.getRDO();
/* 2486:2505 */     if (mbo.isNew()) {
/* 2487:2506 */       this.rdoRuntime.getRDOManager().insert(rdo.getName(), rdo);
/* 2488:     */     } else {
/* 2489:2508 */       this.rdoRuntime.getRDOManager().update(rdo.getName(), rdo);
/* 2490:     */     }
/* 2491:2511 */     RDOInfo rdoInfo = this.rdoRuntime.getRDOInfoManager().getInfo(mbo.getName());
/* 2492:2512 */     String[] dependentNames = rdoInfo.getDependentNames();
/* 2493:2514 */     for (int i = 0; i < dependentNames.length; i++)
/* 2494:     */     {
/* 2495:2515 */       Enumeration depEnum = mbo.getDependents(dependentNames[i]);
/* 2496:2516 */       while (depEnum.hasMoreElements())
/* 2497:     */       {
/* 2498:2517 */         MobileMbo dependentMbo = (MobileMbo)depEnum.nextElement();
/* 2499:2518 */         saveMobileMboChanges(dependentMbo);
/* 2500:     */       }
/* 2501:     */     }
/* 2502:2522 */     int depCount = mbo.getDependentSize("CHILDREN");
/* 2503:2523 */     if (depCount > 0)
/* 2504:     */     {
/* 2505:2524 */       Enumeration childEnum = mbo.getDependents("CHILDREN");
/* 2506:2525 */       while (childEnum.hasMoreElements())
/* 2507:     */       {
/* 2508:2526 */         MobileMbo dependentMbo = (MobileMbo)childEnum.nextElement();
/* 2509:2527 */         saveMobileMboChanges(dependentMbo);
/* 2510:     */       }
/* 2511:     */     }
/* 2512:     */   }
/* 2513:     */   
/* 2514:     */   public void removeMobileMbos(String name)
/* 2515:     */     throws MobileApplicationException
/* 2516:     */   {
/* 2517:2533 */     checkInfoExists(name);
/* 2518:     */     
/* 2519:2535 */     this.rdoRuntime.getRDOManager().removeAll(name);
/* 2520:     */   }
/* 2521:     */   
/* 2522:     */   public void removeMobileMbos()
/* 2523:     */     throws MobileApplicationException
/* 2524:     */   {
/* 2525:     */     try
/* 2526:     */     {
/* 2527:2540 */       this.rdoRuntime.getRDOTransactionManager().begin();
/* 2528:     */       
/* 2529:2542 */       Enumeration mboEnum = MobileMboRuntime.getInstance(this.appName).getAllMobileMboNames();
/* 2530:2543 */       while (mboEnum.hasMoreElements())
/* 2531:     */       {
/* 2532:2544 */         String name = (String)mboEnum.nextElement();
/* 2533:2545 */         removeMobileMbos(name);
/* 2534:     */       }
/* 2535:2548 */       this.rdoRuntime.getRDOTransactionManager().commit();
/* 2536:     */     }
/* 2537:     */     catch (RDOException ex)
/* 2538:     */     {
/* 2539:2550 */       getDefaultLogger().warn("Failed to mobile mbos", ex);
/* 2540:     */       try
/* 2541:     */       {
/* 2542:2552 */         this.rdoRuntime.getRDOTransactionManager().rollback();
/* 2543:     */       }
/* 2544:     */       catch (Exception e) {}
/* 2545:2556 */       throw ex;
/* 2546:     */     }
/* 2547:     */   }
/* 2548:     */   
/* 2549:     */   public MobileMboEnumeration getMobileMbos(String name)
/* 2550:     */     throws MobileApplicationException
/* 2551:     */   {
/* 2552:2561 */     checkInfoExists(name);
/* 2553:     */     
/* 2554:2563 */     RDOEnumeration rdoEnum = this.rdoRuntime.getRDOManager().getAll(name);
/* 2555:2564 */     return new MobileMboEnumeration(rdoEnum);
/* 2556:     */   }
/* 2557:     */   
/* 2558:     */   public MobileMboEnumeration getMobileMbos(String name, QBE filter, Order order)
/* 2559:     */     throws MobileApplicationException
/* 2560:     */   {
/* 2561:2568 */     return getMobileMbos(name, filter, null, order);
/* 2562:     */   }
/* 2563:     */   
/* 2564:     */   public MobileMboEnumeration getMobileMbos(String name, QBE filter, MobileWhereClause whereClause, Order order)
/* 2565:     */     throws MobileApplicationException
/* 2566:     */   {
/* 2567:2572 */     checkInfoExists(name);
/* 2568:     */     
/* 2569:2574 */     RDOEnumeration rdoEnum = this.rdoRuntime.getRDOManager().getAll(name, filter, whereClause, order);
/* 2570:2575 */     return new MobileMboEnumeration(rdoEnum);
/* 2571:     */   }
/* 2572:     */   
/* 2573:     */   private MobileMboInfo getMobileMboInfo(String name)
/* 2574:     */   {
/* 2575:2579 */     return MobileMboUtil.getMobileMboInfo(getAppName(), name);
/* 2576:     */   }
/* 2577:     */   
/* 2578:     */   public void saveCompleteDownloadedMbo(MobileMbo mbo)
/* 2579:     */     throws MobileApplicationException
/* 2580:     */   {
/* 2581:2583 */     saveCompleteDownloadedMbo(mbo, false);
/* 2582:     */   }
/* 2583:     */   
/* 2584:     */   protected void saveCompleteDownloadedMbo(MobileMbo mbo, boolean incUpdate)
/* 2585:     */     throws MobileApplicationException
/* 2586:     */   {
/* 2587:2587 */     if (mbo == null) {
/* 2588:2588 */       return;
/* 2589:     */     }
/* 2590:2591 */     RDO rdo = mbo.getRDO();
/* 2591:2592 */     if (incUpdate)
/* 2592:     */     {
/* 2593:2593 */       String changeType = rdo.getStringValue("_CHANGETYPE");
/* 2594:2594 */       if (changeType == null) {
/* 2595:2595 */         changeType = "INSERT";
/* 2596:     */       }
/* 2597:2598 */       RDO existingRDO = this.rdoRuntime.getRDOManager().get(rdo.getName(), rdo.getId());
/* 2598:2599 */       if (existingRDO == null)
/* 2599:     */       {
/* 2600:2600 */         if (changeType.equals("INSERT")) {
/* 2601:2601 */           this.rdoRuntime.getRDOManager().insert(rdo.getName(), rdo);
/* 2602:     */         }
/* 2603:     */       }
/* 2604:2604 */       else if (!existingRDO.getBooleanValue("_MODIFIED"))
/* 2605:     */       {
/* 2606:2605 */         if (changeType.equals("DELETE"))
/* 2607:     */         {
/* 2608:2606 */           this.rdoRuntime.getRDOManager().remove(rdo.getName(), rdo.getId());
/* 2609:2607 */           return;
/* 2610:     */         }
/* 2611:2608 */         if (changeType.equals("UPDATE")) {
/* 2612:2609 */           this.rdoRuntime.getRDOManager().update(rdo.getName(), rdo);
/* 2613:2610 */         } else if (changeType.equals("INSERT")) {
/* 2614:2611 */           this.rdoRuntime.getRDOManager().update(rdo.getName(), rdo);
/* 2615:     */         }
/* 2616:     */       }
/* 2617:2617 */       else if (changeType.equals("DELETE"))
/* 2618:     */       {
/* 2619:2619 */         savePendingRecordToBeDeleted(rdo);
/* 2620:     */       }
/* 2621:     */     }
/* 2622:     */     else
/* 2623:     */     {
/* 2624:2624 */       boolean idAttrExists = false;
/* 2625:2626 */       if (mbo.getMobileMboInfo().getAttributeInfo("_ID") != null)
/* 2626:     */       {
/* 2627:2627 */         RDO existingRDO = this.rdoRuntime.getRDOManager().get(rdo.getName(), rdo.getId());
/* 2628:2628 */         if (existingRDO == null)
/* 2629:     */         {
/* 2630:2629 */           this.rdoRuntime.getRDOManager().insert(rdo.getName(), rdo);
/* 2631:     */         }
/* 2632:2632 */         else if (!existingRDO.getBooleanValue("_MODIFIED"))
/* 2633:     */         {
/* 2634:2633 */           this.rdoRuntime.getRDOManager().remove(rdo.getName(), rdo.getId());
/* 2635:2634 */           this.rdoRuntime.getRDOManager().insert(rdo.getName(), rdo);
/* 2636:     */         }
/* 2637:     */         else
/* 2638:     */         {
/* 2639:2638 */           return;
/* 2640:     */         }
/* 2641:     */       }
/* 2642:     */       else
/* 2643:     */       {
/* 2644:2642 */         if (this.rdoRuntime.getRDOManager().exists(rdo.getName(), rdo.getKey())) {
/* 2645:2645 */           return;
/* 2646:     */         }
/* 2647:2647 */         this.rdoRuntime.getRDOManager().insert(rdo.getName(), rdo);
/* 2648:     */       }
/* 2649:     */     }
/* 2650:2654 */     RDOInfo rdoInfo = this.rdoRuntime.getRDOInfoManager().getInfo(mbo.getName());
/* 2651:2655 */     String[] dependentNames = rdoInfo.getDependentNames();
/* 2652:2657 */     for (int i = 0; i < dependentNames.length; i++)
/* 2653:     */     {
/* 2654:2658 */       Enumeration depEnum = mbo.getDependents(dependentNames[i]);
/* 2655:2659 */       while (depEnum.hasMoreElements())
/* 2656:     */       {
/* 2657:2660 */         MobileMbo dependentMbo = (MobileMbo)depEnum.nextElement();
/* 2658:2661 */         saveCompleteDownloadedDependentMbo(dependentMbo, incUpdate, mbo);
/* 2659:     */       }
/* 2660:     */     }
/* 2661:2665 */     int depCount = mbo.getDependentSize("CHILDREN");
/* 2662:2666 */     if (depCount > 0)
/* 2663:     */     {
/* 2664:2667 */       Enumeration childEnum = mbo.getDependents("CHILDREN");
/* 2665:2668 */       while (childEnum.hasMoreElements())
/* 2666:     */       {
/* 2667:2669 */         MobileMbo dependentMbo = (MobileMbo)childEnum.nextElement();
/* 2668:2670 */         saveCompleteDownloadedDependentMbo(dependentMbo, incUpdate, mbo);
/* 2669:     */       }
/* 2670:     */     }
/* 2671:     */   }
/* 2672:     */   
/* 2673:     */   private void savePendingRecordToBeDeleted(RDO rdo)
/* 2674:     */     throws RDOException, MobileApplicationException
/* 2675:     */   {
/* 2676:2682 */     DefaultQBE qbe = new DefaultQBE();
/* 2677:2683 */     qbe.setQBE("RECORDID", "" + rdo.getId());
/* 2678:2684 */     qbe.setQBE("DATAGROUPNAME", rdo.getName());
/* 2679:2685 */     if (this.rdoRuntime.getRDOManager().size("PENDINGRECORDSTODELETE", qbe) == 0)
/* 2680:     */     {
/* 2681:2687 */       DefaultRDO _rdo = new DefaultRDO(rdo.getAppName(), true);
/* 2682:2688 */       _rdo.setName("PENDINGRECORDSTODELETE");
/* 2683:2689 */       long uid = getUniqueNumber("PENDINGRECORDSTODELETE", "_PENDINGRECORDSTODELETE");
/* 2684:2690 */       _rdo.setLongValue("_ID", uid);
/* 2685:2691 */       _rdo.setLongValue("RECORDID", rdo.getId());
/* 2686:2692 */       _rdo.setStringValue("DATAGROUPNAME", rdo.getName());
/* 2687:2693 */       _rdo.setDateValue("CREATEDWHEN", CurrentTimeProvider.getInstance().getCurrentTime());
/* 2688:2694 */       this.rdoRuntime.getRDOManager().insert(_rdo.getName(), _rdo);
/* 2689:     */     }
/* 2690:     */   }
/* 2691:     */   
/* 2692:     */   protected void saveCompleteDownloadedDependentMbo(MobileMbo mbo, boolean incUpdate, MobileMbo parentMbo)
/* 2693:     */     throws MobileApplicationException
/* 2694:     */   {
/* 2695:2700 */     if (mbo == null) {
/* 2696:2701 */       return;
/* 2697:     */     }
/* 2698:2704 */     long parentId = parentMbo.getRDO().getId();
/* 2699:     */     
/* 2700:2706 */     RDO rdo = mbo.getRDO();
/* 2701:2707 */     if (incUpdate)
/* 2702:     */     {
/* 2703:2708 */       String changeType = rdo.getStringValue("_CHANGETYPE");
/* 2704:2709 */       if (changeType == null) {
/* 2705:2710 */         changeType = "INSERT";
/* 2706:     */       }
/* 2707:2713 */       boolean existingDepRDO = this.rdoRuntime.getRDOManager().existsDependent(rdo.getName(), rdo.getId(), parentId);
/* 2708:2714 */       if (!existingDepRDO)
/* 2709:     */       {
/* 2710:2715 */         if (changeType.equals("INSERT")) {
/* 2711:2716 */           this.rdoRuntime.getRDOManager().insert(rdo.getName(), rdo);
/* 2712:     */         }
/* 2713:     */       }
/* 2714:     */       else
/* 2715:     */       {
/* 2716:2724 */         if (changeType.equals("DELETE"))
/* 2717:     */         {
/* 2718:2725 */           this.rdoRuntime.getRDOManager().removeDependent(rdo.getName(), rdo.getId(), parentId);
/* 2719:2726 */           return;
/* 2720:     */         }
/* 2721:2727 */         if (changeType.equals("UPDATE")) {
/* 2722:2728 */           this.rdoRuntime.getRDOManager().update(rdo.getName(), rdo);
/* 2723:2729 */         } else if (changeType.equals("INSERT")) {
/* 2724:2730 */           this.rdoRuntime.getRDOManager().update(rdo.getName(), rdo);
/* 2725:     */         }
/* 2726:     */       }
/* 2727:     */     }
/* 2728:     */     else
/* 2729:     */     {
/* 2730:2734 */       boolean idAttrExists = false;
/* 2731:2736 */       if ((mbo.getMobileMboInfo().getAttributeInfo("_ID") != null) && (mbo.getMobileMboInfo().getAttributeInfo("_PARENTID") != null))
/* 2732:     */       {
/* 2733:2737 */         boolean existingDepRDO = this.rdoRuntime.getRDOManager().existsDependent(rdo.getName(), rdo.getId(), parentId);
/* 2734:2738 */         if (!existingDepRDO)
/* 2735:     */         {
/* 2736:2739 */           this.rdoRuntime.getRDOManager().insert(rdo.getName(), rdo);
/* 2737:     */         }
/* 2738:     */         else
/* 2739:     */         {
/* 2740:2741 */           this.rdoRuntime.getRDOManager().removeDependent(rdo.getName(), rdo.getId(), parentId);
/* 2741:2742 */           this.rdoRuntime.getRDOManager().insert(rdo.getName(), rdo);
/* 2742:     */         }
/* 2743:     */       }
/* 2744:     */       else
/* 2745:     */       {
/* 2746:2745 */         if (this.rdoRuntime.getRDOManager().exists(rdo.getName(), rdo.getKey())) {
/* 2747:2748 */           return;
/* 2748:     */         }
/* 2749:2750 */         this.rdoRuntime.getRDOManager().insert(rdo.getName(), rdo);
/* 2750:     */       }
/* 2751:     */     }
/* 2752:2757 */     RDOInfo rdoInfo = this.rdoRuntime.getRDOInfoManager().getInfo(mbo.getName());
/* 2753:2758 */     String[] dependentNames = rdoInfo.getDependentNames();
/* 2754:2760 */     for (int i = 0; i < dependentNames.length; i++)
/* 2755:     */     {
/* 2756:2761 */       Enumeration depEnum = mbo.getDependents(dependentNames[i]);
/* 2757:2762 */       while (depEnum.hasMoreElements())
/* 2758:     */       {
/* 2759:2763 */         MobileMbo dependentMbo = (MobileMbo)depEnum.nextElement();
/* 2760:2764 */         saveCompleteDownloadedDependentMbo(dependentMbo, incUpdate, mbo);
/* 2761:     */       }
/* 2762:     */     }
/* 2763:2768 */     int depCount = mbo.getDependentSize("CHILDREN");
/* 2764:2769 */     if (depCount > 0)
/* 2765:     */     {
/* 2766:2770 */       Enumeration childEnum = mbo.getDependents("CHILDREN");
/* 2767:2771 */       while (childEnum.hasMoreElements())
/* 2768:     */       {
/* 2769:2772 */         MobileMbo dependentMbo = (MobileMbo)childEnum.nextElement();
/* 2770:2773 */         saveCompleteDownloadedDependentMbo(dependentMbo, incUpdate, mbo);
/* 2771:     */       }
/* 2772:     */     }
/* 2773:     */   }
/* 2774:     */   
/* 2775:     */   private String getInternalAppSettingPrefix()
/* 2776:     */   {
/* 2777:2779 */     return this.appName + ".";
/* 2778:     */   }
/* 2779:     */   
/* 2780:     */   public String getAppSetting(String name)
/* 2781:     */   {
/* 2782:2783 */     String appSettingName = getInternalAppSettingPrefix() + name;
/* 2783:2784 */     return (String)this.appSettings.get(appSettingName);
/* 2784:     */   }
/* 2785:     */   
/* 2786:     */   public void setAppSetting(String name, String value)
/* 2787:     */     throws MobileApplicationException
/* 2788:     */   {
/* 2789:2788 */     String appSettingName = getInternalAppSettingPrefix() + name;
/* 2790:2789 */     setSetting(appSettingName, value);
/* 2791:2790 */     this.appSettings.put(appSettingName, value);
/* 2792:     */   }
/* 2793:     */   
/* 2794:     */   protected void setSetting(String name, String value)
/* 2795:     */     throws MobileApplicationException
/* 2796:     */   {
/* 2797:2795 */     setSetting(name, value, this.rdoRuntime);
/* 2798:     */   }
/* 2799:     */   
/* 2800:     */   protected void setSetting(String name, String value, RDORuntime rdoRuntime)
/* 2801:     */     throws MobileApplicationException
/* 2802:     */   {
/* 2803:2800 */     DefaultRDO rdo = new DefaultRDO(this.appName);
/* 2804:2801 */     rdo.setName("MAXSYSSETTING");
/* 2805:2802 */     rdo.setStringValue("NAME", name);
/* 2806:2803 */     rdo.setStringValue("VALUE", value);
/* 2807:     */     try
/* 2808:     */     {
/* 2809:2806 */       rdoRuntime.getRDOTransactionManager().begin();
/* 2810:     */       
/* 2811:2808 */       rdoRuntime.getRDOManager().remove("MAXSYSSETTING", rdo);
/* 2812:2809 */       rdoRuntime.getRDOManager().insert("MAXSYSSETTING", rdo);
/* 2813:     */       
/* 2814:2811 */       rdoRuntime.getRDOTransactionManager().commit();
/* 2815:     */     }
/* 2816:     */     catch (RDOException e)
/* 2817:     */     {
/* 2818:     */       try
/* 2819:     */       {
/* 2820:2814 */         rdoRuntime.getRDOTransactionManager().rollback();
/* 2821:     */       }
/* 2822:     */       catch (Exception ex) {}
/* 2823:2818 */       throw new MobileApplicationException(e);
/* 2824:     */     }
/* 2825:     */   }
/* 2826:     */   
/* 2827:     */   protected void setSystemSetting(String name, String value)
/* 2828:     */     throws MobileApplicationException
/* 2829:     */   {
/* 2830:2823 */     setSetting(name, value);
/* 2831:2824 */     this.systemSettings.put(name, value);
/* 2832:     */   }
/* 2833:     */   
/* 2834:     */   public boolean isMetaDataObtainedFromServer()
/* 2835:     */   {
/* 2836:2828 */     return getBooleanSystemSetting("METADATAOBTAINED");
/* 2837:     */   }
/* 2838:     */   
/* 2839:     */   private void setMetaDataObtainedFromServer(boolean obtained)
/* 2840:     */     throws MobileApplicationException
/* 2841:     */   {
/* 2842:2832 */     setSystemSetting("METADATAOBTAINED", "" + obtained);
/* 2843:     */   }
/* 2844:     */   
/* 2845:     */   protected String getSystemSetting(String name)
/* 2846:     */   {
/* 2847:2836 */     return (String)this.systemSettings.get(name);
/* 2848:     */   }
/* 2849:     */   
/* 2850:     */   private boolean getBooleanSystemSetting(String name)
/* 2851:     */   {
/* 2852:2840 */     String value = (String)this.systemSettings.get(name);
/* 2853:2841 */     if (value == null) {
/* 2854:2842 */       return false;
/* 2855:     */     }
/* 2856:2845 */     boolean b = value.equals("true");
/* 2857:2846 */     return b;
/* 2858:     */   }
/* 2859:     */   
/* 2860:     */   public void loadSettings()
/* 2861:     */     throws MobileApplicationException
/* 2862:     */   {
/* 2863:     */     try
/* 2864:     */     {
/* 2865:2851 */       registerSettingsInfo();
/* 2866:     */       
/* 2867:2853 */       this.systemSettings = new Hashtable();
/* 2868:2854 */       this.appSettings = new Hashtable();
/* 2869:     */       
/* 2870:2856 */       Enumeration rdoEnum = this.rdoRuntime.getRDOManager().getAll("MAXSYSSETTING");
/* 2871:2857 */       while (rdoEnum.hasMoreElements())
/* 2872:     */       {
/* 2873:2858 */         RDO rdo = (RDO)rdoEnum.nextElement();
/* 2874:2859 */         String name = rdo.getStringValue("NAME");
/* 2875:2860 */         String value = rdo.getStringValue("VALUE");
/* 2876:     */         
/* 2877:2862 */         String prefix = getInternalAppSettingPrefix();
/* 2878:2863 */         if (name.startsWith(prefix)) {
/* 2879:2864 */           this.appSettings.put(name, value);
/* 2880:     */         } else {
/* 2881:2866 */           this.systemSettings.put(name, value);
/* 2882:     */         }
/* 2883:     */       }
/* 2884:     */     }
/* 2885:     */     catch (RDOException e)
/* 2886:     */     {
/* 2887:2870 */       getDefaultLogger().warn("Failed to load system settings", e);
/* 2888:2871 */       throw new MobileApplicationException("systemsettingloadfailed", e);
/* 2889:     */     }
/* 2890:     */   }
/* 2891:     */   
/* 2892:     */   private void registerSettingsInfo()
/* 2893:     */     throws RDOException
/* 2894:     */   {
/* 2895:2876 */     if (this.rdoRuntime.getRDOInfoManager().infoExists("MAXSYSSETTING")) {
/* 2896:2877 */       return;
/* 2897:     */     }
/* 2898:2880 */     DefaultRDOInfo systemSettingsInfo = new DefaultRDOInfo();
/* 2899:2881 */     systemSettingsInfo.setName("MAXSYSSETTING");
/* 2900:     */     
/* 2901:2883 */     DefaultRDOAttributeInfo attr1 = new DefaultRDOAttributeInfo();
/* 2902:2884 */     attr1.setName("NAME");
/* 2903:2885 */     attr1.setKey(true);
/* 2904:     */     
/* 2905:2887 */     DefaultRDOAttributeInfo attr2 = new DefaultRDOAttributeInfo();
/* 2906:2888 */     attr2.setName("VALUE");
/* 2907:     */     
/* 2908:2890 */     systemSettingsInfo.addAttributeInfo(attr1);
/* 2909:2891 */     systemSettingsInfo.addAttributeInfo(attr2);
/* 2910:     */     
/* 2911:2893 */     this.rdoRuntime.getRDOTransactionManager().begin();
/* 2912:2894 */     this.rdoRuntime.getRDOInfoManager().registerInfo("MAXSYSSETTING", systemSettingsInfo);
/* 2913:2895 */     this.rdoRuntime.getRDOTransactionManager().commit();
/* 2914:     */   }
/* 2915:     */   
/* 2916:     */   public void verifyUserRemote(String userName, String password)
/* 2917:     */     throws MobileApplicationException
/* 2918:     */   {
/* 2919:2901 */     this.mobileWebServiceProxy.hello();
/* 2920:     */   }
/* 2921:     */   
/* 2922:     */   public void verifyUserLocal(String userName, String userPIN)
/* 2923:     */     throws MobileApplicationException
/* 2924:     */   {
/* 2925:2905 */     boolean validUser = false;
/* 2926:     */     try
/* 2927:     */     {
/* 2928:2908 */       registerUserInfo();
/* 2929:     */       
/* 2930:2910 */       Enumeration rdoEnum = this.rdoRuntime.getRDOManager().getAll("REGISTEREDUSER");
/* 2931:2911 */       while (rdoEnum.hasMoreElements())
/* 2932:     */       {
/* 2933:2912 */         RDO rdo = (RDO)rdoEnum.nextElement();
/* 2934:2913 */         String name = rdo.getStringValue("USERNAME");
/* 2935:2915 */         if (name.equals(userName))
/* 2936:     */         {
/* 2937:2916 */           String encPIN = rdo.getStringValue("PIN");
/* 2938:2917 */           String pin = new String(Base64.decode(encPIN));
/* 2939:2918 */           if (pin.equals(userPIN))
/* 2940:     */           {
/* 2941:2919 */             validUser = true;
/* 2942:2920 */             break;
/* 2943:     */           }
/* 2944:     */         }
/* 2945:     */       }
/* 2946:     */     }
/* 2947:     */     catch (RDOException e)
/* 2948:     */     {
/* 2949:2925 */       getDefaultLogger().warn("Failed to verify local user: " + userName, e);
/* 2950:     */     }
/* 2951:2928 */     if (!validUser) {
/* 2952:2929 */       throw new MobileApplicationException("invaliduser");
/* 2953:     */     }
/* 2954:     */   }
/* 2955:     */   
/* 2956:     */   public boolean isUserRegistered(String userName)
/* 2957:     */   {
/* 2958:     */     try
/* 2959:     */     {
/* 2960:2935 */       registerUserInfo();
/* 2961:     */       
/* 2962:2937 */       DefaultQBE qbe = new DefaultQBE();
/* 2963:2938 */       qbe.setQbeExactMatch(true);
/* 2964:2939 */       qbe.setQBE("USERNAME", userName);
/* 2965:2940 */       Enumeration rdoEnum = this.rdoRuntime.getRDOManager().getAll("REGISTEREDUSER", qbe, null);
/* 2966:2941 */       while (rdoEnum.hasMoreElements())
/* 2967:     */       {
/* 2968:2942 */         RDO rdo = (RDO)rdoEnum.nextElement();
/* 2969:2943 */         String name = rdo.getStringValue("USERNAME");
/* 2970:2945 */         if (name.equals(userName)) {
/* 2971:2946 */           return true;
/* 2972:     */         }
/* 2973:     */       }
/* 2974:     */     }
/* 2975:     */     catch (Exception e)
/* 2976:     */     {
/* 2977:2951 */       getDefaultLogger().warn("Failed to determine if user is registered: " + userName, e);
/* 2978:2952 */       return true;
/* 2979:     */     }
/* 2980:2955 */     return false;
/* 2981:     */   }
/* 2982:     */   
/* 2983:     */   private String getPassword(String userName)
/* 2984:     */     throws MobileApplicationException
/* 2985:     */   {
/* 2986:     */     try
/* 2987:     */     {
/* 2988:2960 */       registerUserInfo();
/* 2989:     */       
/* 2990:2962 */       DefaultQBE qbe = new DefaultQBE();
/* 2991:2963 */       qbe.setQbeExactMatch(true);
/* 2992:2964 */       qbe.setQBE("USERNAME", userName);
/* 2993:2965 */       Enumeration rdoEnum = this.rdoRuntime.getRDOManager().getAll("REGISTEREDUSER", qbe, null);
/* 2994:2966 */       while (rdoEnum.hasMoreElements())
/* 2995:     */       {
/* 2996:2967 */         RDO rdo = (RDO)rdoEnum.nextElement();
/* 2997:2968 */         String name = rdo.getStringValue("USERNAME");
/* 2998:2970 */         if (name.equals(userName))
/* 2999:     */         {
/* 3000:2971 */           String encPASSWORD = rdo.getStringValue("PASSWORD");
/* 3001:2972 */           return new String(Base64.decode(encPASSWORD));
/* 3002:     */         }
/* 3003:     */       }
/* 3004:     */     }
/* 3005:     */     catch (RDOException e)
/* 3006:     */     {
/* 3007:2977 */       getDefaultLogger().warn("Failed get password for user: " + userName);
/* 3008:     */     }
/* 3009:2980 */     throw new MobileApplicationException("failtogetpassword", new Object[] { userName });
/* 3010:     */   }
/* 3011:     */   
/* 3012:     */   private Vector getAllRegisteredUsers()
/* 3013:     */     throws MobileApplicationException
/* 3014:     */   {
/* 3015:2984 */     Vector users = new Vector();
/* 3016:     */     try
/* 3017:     */     {
/* 3018:2987 */       registerUserInfo();
/* 3019:     */       
/* 3020:2989 */       Enumeration rdoEnum = this.rdoRuntime.getRDOManager().getAll("REGISTEREDUSER");
/* 3021:2990 */       while (rdoEnum.hasMoreElements())
/* 3022:     */       {
/* 3023:2991 */         RDO rdo = (RDO)rdoEnum.nextElement();
/* 3024:2992 */         String name = rdo.getStringValue("USERNAME");
/* 3025:     */         
/* 3026:2994 */         users.addElement(name);
/* 3027:     */       }
/* 3028:     */     }
/* 3029:     */     catch (RDOException e)
/* 3030:     */     {
/* 3031:2997 */       getDefaultLogger().warn("Failed to get all registered users", e);
/* 3032:     */     }
/* 3033:3000 */     return users;
/* 3034:     */   }
/* 3035:     */   
/* 3036:     */   private void registerUser(String userName, String password, String pin)
/* 3037:     */     throws MobileApplicationException
/* 3038:     */   {
/* 3039:     */     try
/* 3040:     */     {
/* 3041:3005 */       registerUserInfo();
/* 3042:     */       
/* 3043:3007 */       DefaultRDO rdo = new DefaultRDO(this.appName);
/* 3044:3008 */       rdo.setName("REGISTEREDUSER");
/* 3045:3009 */       rdo.setStringValue("USERNAME", userName);
/* 3046:3010 */       rdo.setStringValue("PASSWORD", Base64.encode(password.getBytes()));
/* 3047:3011 */       rdo.setStringValue("PIN", Base64.encode(pin.getBytes()));
/* 3048:     */       
/* 3049:3013 */       this.rdoRuntime.getRDOTransactionManager().begin();
/* 3050:     */       
/* 3051:3015 */       this.rdoRuntime.getRDOManager().remove("REGISTEREDUSER", rdo);
/* 3052:3016 */       this.rdoRuntime.getRDOManager().insert("REGISTEREDUSER", rdo);
/* 3053:     */       
/* 3054:3018 */       this.rdoRuntime.getRDOTransactionManager().commit();
/* 3055:     */     }
/* 3056:     */     catch (RDOException e)
/* 3057:     */     {
/* 3058:     */       try
/* 3059:     */       {
/* 3060:3021 */         this.rdoRuntime.getRDOTransactionManager().rollback();
/* 3061:     */       }
/* 3062:     */       catch (Exception ex) {}
/* 3063:3025 */       throw new MobileApplicationException(e);
/* 3064:     */     }
/* 3065:     */   }
/* 3066:     */   
/* 3067:     */   private void unregisterUser(String userName)
/* 3068:     */     throws MobileApplicationException
/* 3069:     */   {
/* 3070:     */     try
/* 3071:     */     {
/* 3072:3031 */       registerUserInfo();
/* 3073:     */       
/* 3074:3033 */       DefaultQBE qbe = new DefaultQBE();
/* 3075:3034 */       qbe.setQbeExactMatch(true);
/* 3076:3035 */       qbe.setQBE("USERNAME", userName);
/* 3077:3036 */       Enumeration rdoEnum = this.rdoRuntime.getRDOManager().getAll("REGISTEREDUSER", qbe, null);
/* 3078:3037 */       while (rdoEnum.hasMoreElements())
/* 3079:     */       {
/* 3080:3038 */         RDO rdo = (RDO)rdoEnum.nextElement();
/* 3081:     */         
/* 3082:3040 */         String name = rdo.getStringValue("USERNAME");
/* 3083:3041 */         if (name.equals(userName))
/* 3084:     */         {
/* 3085:3042 */           this.rdoRuntime.getRDOTransactionManager().begin();
/* 3086:3043 */           this.rdoRuntime.getRDOManager().remove("REGISTEREDUSER", rdo);
/* 3087:3044 */           this.rdoRuntime.getRDOTransactionManager().commit();
/* 3088:     */         }
/* 3089:     */       }
/* 3090:     */     }
/* 3091:     */     catch (RDOException e)
/* 3092:     */     {
/* 3093:     */       try
/* 3094:     */       {
/* 3095:3049 */         this.rdoRuntime.getRDOTransactionManager().rollback();
/* 3096:     */       }
/* 3097:     */       catch (Exception ex) {}
/* 3098:3053 */       throw new MobileApplicationException(e);
/* 3099:     */     }
/* 3100:     */   }
/* 3101:     */   
/* 3102:     */   private void registerUserInfo()
/* 3103:     */     throws RDOException
/* 3104:     */   {
/* 3105:3058 */     if (this.rdoRuntime.getRDOInfoManager().infoExists("REGISTEREDUSER")) {
/* 3106:3059 */       return;
/* 3107:     */     }
/* 3108:3062 */     DefaultRDOInfo regUserInfo = new DefaultRDOInfo();
/* 3109:3063 */     regUserInfo.setName("REGISTEREDUSER");
/* 3110:     */     
/* 3111:3065 */     DefaultRDOAttributeInfo attr1 = new DefaultRDOAttributeInfo();
/* 3112:3066 */     attr1.setName("USERNAME");
/* 3113:3067 */     attr1.setKey(true);
/* 3114:     */     
/* 3115:3069 */     DefaultRDOAttributeInfo attr2 = new DefaultRDOAttributeInfo();
/* 3116:3070 */     attr2.setName("PASSWORD");
/* 3117:3071 */     attr2.setKey(false);
/* 3118:     */     
/* 3119:3073 */     DefaultRDOAttributeInfo attr3 = new DefaultRDOAttributeInfo();
/* 3120:3074 */     attr3.setName("PIN");
/* 3121:3075 */     attr3.setKey(false);
/* 3122:     */     
/* 3123:3077 */     regUserInfo.addAttributeInfo(attr1);
/* 3124:3078 */     regUserInfo.addAttributeInfo(attr2);
/* 3125:3079 */     regUserInfo.addAttributeInfo(attr3);
/* 3126:     */     
/* 3127:3081 */     this.rdoRuntime.getRDOTransactionManager().begin();
/* 3128:3082 */     this.rdoRuntime.getRDOInfoManager().registerInfo("REGISTEREDUSER", regUserInfo);
/* 3129:3083 */     this.rdoRuntime.getRDOTransactionManager().commit();
/* 3130:     */   }
/* 3131:     */   
/* 3132:     */   public String getNextAutoNumber(String name)
/* 3133:     */     throws MobileApplicationException
/* 3134:     */   {
/* 3135:3087 */     MobileMboInfo info = MobileMboUtil.getMobileMboInfo(getAppName(), name);
/* 3136:3088 */     MobileMboAttributeInfo idAttrInfo = info.getAttributeInfo("_ID");
/* 3137:     */     
/* 3138:3090 */     String lastNumber = getAppSetting(name);
/* 3139:     */     
/* 3140:3092 */     int noOfRetries = 0;
/* 3141:     */     for (;;)
/* 3142:     */     {
/* 3143:3095 */       if (noOfRetries >= 10) {
/* 3144:3096 */         throw new MobileApplicationException("failedtogenerateautonumber");
/* 3145:     */       }
/* 3146:3099 */       if (lastNumber == null)
/* 3147:     */       {
/* 3148:3100 */         lastNumber = "1";
/* 3149:     */       }
/* 3150:     */       else
/* 3151:     */       {
/* 3152:3102 */         long lastNum = Long.parseLong(lastNumber);
/* 3153:3103 */         lastNum += 1L;
/* 3154:3105 */         if (lastNum > 9999L) {
/* 3155:3106 */           lastNum = 1L;
/* 3156:     */         }
/* 3157:3109 */         lastNumber = "" + lastNum;
/* 3158:     */       }
/* 3159:3112 */       if (idAttrInfo == null) {
/* 3160:     */         break;
/* 3161:     */       }
/* 3162:3116 */       long uid = -1L * Long.parseLong(lastNumber);
/* 3163:3117 */       MobileMboDataBeanManager dbManager = new MobileMboDataBeanManager(name);
/* 3164:3118 */       MobileMboDataBean db = dbManager.getDataBean();
/* 3165:3119 */       db.getQBE().setQbeExactMatch(true);
/* 3166:3120 */       db.getQBE().setQBE("_ID", "" + uid);
/* 3167:3121 */       MobileMbo mobileMbo = db.getMobileMbo(0);
/* 3168:3122 */       if (mobileMbo == null) {
/* 3169:     */         break;
/* 3170:     */       }
/* 3171:3126 */       noOfRetries++;
/* 3172:3127 */       setAppSetting(name, lastNumber);
/* 3173:     */     }
/* 3174:3130 */     setAppSetting(name, lastNumber);
/* 3175:     */     
/* 3176:3132 */     return lastNumber;
/* 3177:     */   }
/* 3178:     */   
/* 3179:     */   public long getUniqueNumber(String mobileMboName, String name)
/* 3180:     */     throws MobileApplicationException
/* 3181:     */   {
/* 3182:3136 */     MobileMboInfo info = MobileMboUtil.getMobileMboInfo(getAppName(), mobileMboName);
/* 3183:3137 */     MobileMboAttributeInfo idAttrInfo = info.getAttributeInfo("_ID");
/* 3184:     */     
/* 3185:3139 */     String lastNumber = getAppSetting(name);
/* 3186:     */     
/* 3187:3141 */     int noOfRetries = 0;
/* 3188:     */     for (;;)
/* 3189:     */     {
/* 3190:3144 */       if (noOfRetries >= 10) {
/* 3191:3145 */         throw new MobileApplicationException("failedtogenerateuid");
/* 3192:     */       }
/* 3193:3148 */       if (lastNumber == null)
/* 3194:     */       {
/* 3195:3149 */         lastNumber = "1";
/* 3196:     */       }
/* 3197:     */       else
/* 3198:     */       {
/* 3199:3151 */         long lastNum = Long.parseLong(lastNumber);
/* 3200:3152 */         lastNum += 1L;
/* 3201:     */         
/* 3202:3154 */         lastNumber = "" + lastNum;
/* 3203:     */       }
/* 3204:3157 */       if (idAttrInfo == null) {
/* 3205:     */         break;
/* 3206:     */       }
/* 3207:3161 */       long uid = -1L * Long.parseLong(lastNumber);
/* 3208:3162 */       MobileMboDataBeanManager dbManager = new MobileMboDataBeanManager(mobileMboName);
/* 3209:3163 */       MobileMboDataBean db = dbManager.getDataBean();
/* 3210:3164 */       db.getQBE().setQbeExactMatch(true);
/* 3211:3165 */       db.getQBE().setQBE("_ID", "" + uid);
/* 3212:3166 */       MobileMbo mobileMbo = db.getMobileMbo(0);
/* 3213:3167 */       if (mobileMbo == null) {
/* 3214:     */         break;
/* 3215:     */       }
/* 3216:3171 */       noOfRetries++;
/* 3217:     */     }
/* 3218:3174 */     setAppSetting(name, lastNumber);
/* 3219:3175 */     long uid = -1L * Long.parseLong(lastNumber);
/* 3220:     */     
/* 3221:3177 */     return uid;
/* 3222:     */   }
/* 3223:     */   
/* 3224:     */   public void initPreferences()
/* 3225:     */     throws MobileApplicationException
/* 3226:     */   {
/* 3227:3181 */     if (!isInitialized()) {
/* 3228:3182 */       return;
/* 3229:     */     }
/* 3230:3185 */     MobileMboDataBeanManager preferencesManager = new MobileMboDataBeanManager("PREFERENCES");
/* 3231:3186 */     MobileMboDataBean preferencesBean = preferencesManager.getDataBean();
/* 3232:3187 */     if (preferencesBean.count() == 0)
/* 3233:     */     {
/* 3234:3188 */       preferencesBean.insert();
/* 3235:     */       
/* 3236:3190 */       MobileMbo preferencesMbo = preferencesBean.getMobileMbo();
/* 3237:     */       
/* 3238:3192 */       preferencesMbo.setBooleanValue("AUTOSENDALL", false);
/* 3239:3193 */       preferencesMbo.setBooleanValue("REFONSIGNIN", false);
/* 3240:3194 */       preferencesMbo.setBooleanValue("AUTOREFWORK", false);
/* 3241:3195 */       preferencesMbo.setLongValue("ATTEMPTREFMIN", 3L);
/* 3242:3196 */       preferencesMbo.setBooleanValue("REVIEWWORK", true);
/* 3243:     */       
/* 3244:3198 */       preferencesMbo.setLongValue("PWDURATION", 5L);
/* 3245:     */       
/* 3246:3200 */       setupDefaultPreferences(preferencesMbo);
/* 3247:     */       
/* 3248:3202 */       preferencesManager.save();
/* 3249:     */     }
/* 3250:3205 */     loadPreferences();
/* 3251:     */   }
/* 3252:     */   
/* 3253:     */   public void initAbout()
/* 3254:     */     throws MobileApplicationException
/* 3255:     */   {
/* 3256:3209 */     if (!isInitialized()) {
/* 3257:3210 */       return;
/* 3258:     */     }
/* 3259:3213 */     MobileMboInfo info = MobileMboUtil.getMobileMboInfo(getAppName(), "ABOUT");
/* 3260:3214 */     if (info == null) {
/* 3261:3215 */       return;
/* 3262:     */     }
/* 3263:3218 */     MobileMboDataBeanManager aboutManager = new MobileMboDataBeanManager("ABOUT");
/* 3264:3219 */     MobileMboDataBean aboutBean = aboutManager.getDataBean();
/* 3265:     */     
/* 3266:3221 */     int count = aboutBean.count();
/* 3267:3222 */     if (count > 0)
/* 3268:     */     {
/* 3269:3223 */       aboutBean.deleteLocal(0);
/* 3270:3224 */       aboutBean.getDataBeanManager().save();
/* 3271:     */     }
/* 3272:3227 */     aboutBean.insert();
/* 3273:     */     
/* 3274:3229 */     MobileMbo aboutMbo = aboutBean.getMobileMbo();
/* 3275:     */     
/* 3276:3231 */     aboutMbo.setValue("APPNAME", getAppName());
/* 3277:3232 */     aboutMbo.setValue("APPDESCRIPTION", getAppDescription());
/* 3278:3233 */     aboutMbo.setValue("METADATAVERSION", getMetaDataVersion());
/* 3279:3234 */     aboutMbo.setValue("VERSION", getVersion());
/* 3280:3235 */     aboutMbo.setValue("USERNAME", getCurrentUserDisplayName());
/* 3281:3236 */     aboutMbo.setValue("HOSTNAME", getProperty("maximo.mobile.hostname"));
/* 3282:3237 */     aboutMbo.setValue("PORT", getProperty("maximo.mobile.port"));
/* 3283:3238 */     aboutMbo.setBooleanValue("SSL", getProperty("maximo.mobile.ssl").equals("true"));
/* 3284:3239 */     aboutMbo.setValue("DEVICEID", getMobileDeviceId());
/* 3285:     */     
/* 3286:3241 */     aboutManager.save();
/* 3287:3242 */     this.version = aboutBean.getMobileMbo(0).getValue("VERSION");
/* 3288:     */   }
/* 3289:     */   
/* 3290:     */   public String getCurrentUserDisplayName()
/* 3291:     */     throws MobileApplicationException
/* 3292:     */   {
/* 3293:3247 */     MobileMboDataBeanManager personManager = new MobileMboDataBeanManager("PERSON");
/* 3294:3248 */     MobileMboDataBean personBean = personManager.getDataBean();
/* 3295:3249 */     MobileMbo person = personBean.getMobileMbo(0);
/* 3296:3250 */     if (person == null) {
/* 3297:3251 */       return getCurrentUser();
/* 3298:     */     }
/* 3299:3254 */     return person.getValue("DISPLAYNAME");
/* 3300:     */   }
/* 3301:     */   
/* 3302:     */   public String getPreference(String preferenceName)
/* 3303:     */   {
/* 3304:3258 */     return (String)this.preferences.get(preferenceName);
/* 3305:     */   }
/* 3306:     */   
/* 3307:     */   public boolean getBooleanPreference(String preferenceName)
/* 3308:     */   {
/* 3309:3262 */     String preference = (String)this.preferences.get(preferenceName);
/* 3310:3263 */     if (preference == null) {
/* 3311:3264 */       return false;
/* 3312:     */     }
/* 3313:3267 */     boolean b = (preference.equals("true")) || (preference.equals("1"));
/* 3314:3268 */     return b;
/* 3315:     */   }
/* 3316:     */   
/* 3317:3271 */   Hashtable preferences = new Hashtable();
/* 3318:     */   
/* 3319:     */   public void savePreferences(MobileMboDataBean preferencesDataBean)
/* 3320:     */     throws MobileApplicationException
/* 3321:     */   {
/* 3322:3274 */     setDefaultInsertSite(preferencesDataBean.getMobileMbo().getValue("DEFSITE"));
/* 3323:3275 */     preferencesDataBean.getDataBeanManager().save();
/* 3324:     */     
/* 3325:     */ 
/* 3326:3278 */     loadPreferences();
/* 3327:     */     
/* 3328:3280 */     boolean autoRefreshEnabled = isAutoRefreshEnabled();
/* 3329:3281 */     int autoRefreshInterval = getAutoRefreshInterval();
/* 3330:3282 */     this.autoRefreshWorker.reset(autoRefreshEnabled, autoRefreshInterval);
/* 3331:     */   }
/* 3332:     */   
/* 3333:     */   public void loadPreferences()
/* 3334:     */     throws MobileApplicationException
/* 3335:     */   {
/* 3336:3286 */     this.preferences = new Hashtable();
/* 3337:     */     
/* 3338:3288 */     MobileMboDataBeanManager preferencesManager = new MobileMboDataBeanManager("PREFERENCES");
/* 3339:3289 */     MobileMboDataBean preferencesBean = preferencesManager.getDataBean();
/* 3340:3290 */     if (preferencesBean.count() > 0)
/* 3341:     */     {
/* 3342:3291 */       MobileMbo preferencesMbo = preferencesBean.getMobileMbo(0);
/* 3343:     */       
/* 3344:3293 */       MobileMboInfo preferencesInfo = preferencesBean.getMobileMboInfo();
/* 3345:3294 */       String[] preferenceNames = preferencesInfo.getAttributeNames();
/* 3346:3296 */       for (int i = 0; i < preferenceNames.length; i++)
/* 3347:     */       {
/* 3348:3297 */         String prefName = preferencesInfo.getAttributeInfo(preferenceNames[i]).getName();
/* 3349:3298 */         if (!prefName.equals("_ID")) {
/* 3350:3302 */           if (!preferencesMbo.isNull(prefName)) {
/* 3351:3303 */             this.preferences.put(prefName, preferencesMbo.getValue(prefName));
/* 3352:     */           }
/* 3353:     */         }
/* 3354:     */       }
/* 3355:     */     }
/* 3356:3308 */     initMobileOptions();
/* 3357:     */   }
/* 3358:     */   
/* 3359:     */   public void initMobileOptions()
/* 3360:     */     throws MobileApplicationException
/* 3361:     */   {
/* 3362:3318 */     MobileMboDataBean optionBean = DataBeanCache.getDataBean("MOBILEOPTIONS", "MOBILEOPTIONS");
/* 3363:3319 */     if (optionBean != null)
/* 3364:     */     {
/* 3365:3320 */       int iLoop = 0;
/* 3366:3321 */       MobileMbo optionMbo = optionBean.getMobileMbo(0);
/* 3367:3322 */       while (optionMbo != null)
/* 3368:     */       {
/* 3369:3323 */         String strValue = optionMbo.getValue("VALUE");
/* 3370:3324 */         if ((strValue != null) && (!strValue.equals(""))) {
/* 3371:3325 */           setProperty(optionMbo.getValue("APP") + "." + optionMbo.getValue("NAME"), strValue);
/* 3372:     */         }
/* 3373:3327 */         iLoop++;
/* 3374:3328 */         optionMbo = optionBean.getMobileMbo(iLoop);
/* 3375:     */       }
/* 3376:     */     }
/* 3377:     */   }
/* 3378:     */   
/* 3379:     */   public String getDefaultStoreroom()
/* 3380:     */     throws MobileApplicationException
/* 3381:     */   {
/* 3382:3340 */     MobileMboDataBeanManager dataBeanManager = new MobileMboDataBeanManager("USER");
/* 3383:3341 */     MobileMboDataBean userDataBean = dataBeanManager.getDataBean();
/* 3384:3342 */     userDataBean.reset();
/* 3385:     */     
/* 3386:     */ 
/* 3387:3345 */     MobileMbo siteMbo = userDataBean.getMobileMbo(0);
/* 3388:3346 */     if (siteMbo == null) {
/* 3389:3347 */       return null;
/* 3390:     */     }
/* 3391:3350 */     String defaultSite = siteMbo.getValue("DEFSTOREROOM");
/* 3392:3351 */     return defaultSite;
/* 3393:     */   }
/* 3394:     */   
/* 3395:     */   public String getDefaultInsertSite()
/* 3396:     */     throws MobileApplicationException
/* 3397:     */   {
/* 3398:3356 */     MobileMboDataBeanManager dataBeanManager = new MobileMboDataBeanManager("USER");
/* 3399:3357 */     MobileMboDataBean userDataBean = dataBeanManager.getDataBean();
/* 3400:3358 */     userDataBean.reset();
/* 3401:     */     
/* 3402:     */ 
/* 3403:3361 */     MobileMbo siteMbo = userDataBean.getMobileMbo(0);
/* 3404:3362 */     if (siteMbo == null) {
/* 3405:3363 */       return null;
/* 3406:     */     }
/* 3407:3366 */     String defaultSite = siteMbo.getValue("DEFSITE");
/* 3408:3367 */     return defaultSite;
/* 3409:     */   }
/* 3410:     */   
/* 3411:     */   public void setDefaultInsertSite(String newInsertSite)
/* 3412:     */     throws MobileApplicationException
/* 3413:     */   {
/* 3414:3372 */     MobileMboDataBeanManager dataBeanManager = new MobileMboDataBeanManager("USER");
/* 3415:3373 */     MobileMboDataBean userDataBean = dataBeanManager.getDataBean();
/* 3416:3374 */     userDataBean.reset();
/* 3417:     */     
/* 3418:     */ 
/* 3419:3377 */     MobileMbo siteMbo = userDataBean.getMobileMbo(0);
/* 3420:3378 */     if (siteMbo == null) {
/* 3421:3379 */       return;
/* 3422:     */     }
/* 3423:3382 */     siteMbo.setValue("DEFSITE", newInsertSite);
/* 3424:     */     
/* 3425:3384 */     dataBeanManager.save();
/* 3426:     */   }
/* 3427:     */   
/* 3428:     */   public String getDefaultInsertOrg()
/* 3429:     */     throws MobileApplicationException
/* 3430:     */   {
/* 3431:3389 */     String defaultSite = getDefaultInsertSite();
/* 3432:     */     
/* 3433:3391 */     MobileMboDataBeanManager dataBeanManager = new MobileMboDataBeanManager("SITE");
/* 3434:3392 */     MobileMboDataBean siteDataBean = dataBeanManager.getDataBean();
/* 3435:3393 */     siteDataBean.getQBE().setQbeExactMatch(true);
/* 3436:3394 */     siteDataBean.getQBE().setQBE("SITEID", defaultSite);
/* 3437:3395 */     siteDataBean.reset();
/* 3438:     */     
/* 3439:     */ 
/* 3440:3398 */     MobileMbo siteMbo = siteDataBean.getMobileMbo(0);
/* 3441:3399 */     if (siteMbo == null) {
/* 3442:3400 */       return null;
/* 3443:     */     }
/* 3444:3403 */     String defaultOrg = siteMbo.getValue("ORGID");
/* 3445:3404 */     return defaultOrg;
/* 3446:     */   }
/* 3447:     */   
/* 3448:     */   public boolean isRefreshWorkListOnSignInEnabled()
/* 3449:     */   {
/* 3450:3408 */     return getBooleanPreference("REFONSIGNIN");
/* 3451:     */   }
/* 3452:     */   
/* 3453:     */   public boolean isAutoRefreshEnabled()
/* 3454:     */   {
/* 3455:3412 */     return getBooleanPreference("AUTOREFWORK");
/* 3456:     */   }
/* 3457:     */   
/* 3458:     */   public int getAutoRefreshInterval()
/* 3459:     */   {
/* 3460:3416 */     String value = getPreference("ATTEMPTREFMIN");
/* 3461:3417 */     int interval = Integer.valueOf(value).intValue();
/* 3462:3418 */     return interval;
/* 3463:     */   }
/* 3464:     */   
/* 3465:     */   public boolean isPasswordExpireNotification()
/* 3466:     */   {
/* 3467:3425 */     return this.passwordExpireNotification;
/* 3468:     */   }
/* 3469:     */   
/* 3470:     */   public Date getCurrentTime()
/* 3471:     */   {
/* 3472:3434 */     return CurrentTimeProvider.getInstance().getCurrentTime();
/* 3473:     */   }
/* 3474:     */   
/* 3475:     */   public OperationHandler getOperationHandler(String operationName)
/* 3476:     */   {
/* 3477:3446 */     OperationContainer curOperationContainer = (OperationContainer)this.operationHandlers.get(operationName);
/* 3478:3447 */     if (curOperationContainer == null) {
/* 3479:3448 */       return null;
/* 3480:     */     }
/* 3481:3450 */     return curOperationContainer.getHandler();
/* 3482:     */   }
/* 3483:     */   
/* 3484:     */   public OperationContainer getOperationContainer(String databeanName, String operationName)
/* 3485:     */   {
/* 3486:3465 */     OperationContainer curOperationContainer = null;
/* 3487:3466 */     Vector vector = (Vector)this.beanOperationHandlers.get(databeanName);
/* 3488:3467 */     if (vector != null)
/* 3489:     */     {
/* 3490:3468 */       Enumeration containerIter = vector.elements();
/* 3491:3469 */       while (containerIter.hasMoreElements())
/* 3492:     */       {
/* 3493:3470 */         OperationContainer tmpOperationContainer = (OperationContainer)containerIter.nextElement();
/* 3494:3471 */         if (tmpOperationContainer.getOperationName().equals(operationName))
/* 3495:     */         {
/* 3496:3472 */           curOperationContainer = tmpOperationContainer;
/* 3497:3473 */           break;
/* 3498:     */         }
/* 3499:     */       }
/* 3500:     */     }
/* 3501:3477 */     return curOperationContainer;
/* 3502:     */   }
/* 3503:     */   
/* 3504:     */   public void registerOperationHandler(String operationName, OperationHandler handler)
/* 3505:     */   {
/* 3506:3489 */     this.operationHandlers.put(operationName, new OperationContainer(operationName, handler));
/* 3507:     */   }
/* 3508:     */   
/* 3509:     */   public void registerOperationHandler(String operationName, String dataBeanName, OperationHandler handler)
/* 3510:     */   {
/* 3511:3503 */     Vector vector = (Vector)this.beanOperationHandlers.get(dataBeanName);
/* 3512:3504 */     if (vector == null)
/* 3513:     */     {
/* 3514:3505 */       vector = new Vector();
/* 3515:3506 */       vector.addElement(new OperationContainer(operationName, dataBeanName, handler));
/* 3516:     */     }
/* 3517:     */     else
/* 3518:     */     {
/* 3519:3508 */       vector.addElement(new OperationContainer(operationName, dataBeanName, handler));
/* 3520:     */     }
/* 3521:3510 */     this.beanOperationHandlers.put(dataBeanName, vector);
/* 3522:     */   }
/* 3523:     */   
/* 3524:     */   public void unregisterOperationHandler(String operationName, String dataBeanName)
/* 3525:     */   {
/* 3526:3522 */     Vector vector = (Vector)this.beanOperationHandlers.get(dataBeanName);
/* 3527:3523 */     if (vector != null)
/* 3528:     */     {
/* 3529:3524 */       Enumeration hndlEnum = vector.elements();
/* 3530:3525 */       while (hndlEnum.hasMoreElements())
/* 3531:     */       {
/* 3532:3526 */         Object tmpObj = hndlEnum.nextElement();
/* 3533:3527 */         OperationContainer tmpOperationContainer = (OperationContainer)tmpObj;
/* 3534:3528 */         if (tmpOperationContainer.getOperationName().equals(operationName))
/* 3535:     */         {
/* 3536:3529 */           vector.removeElement(tmpObj);
/* 3537:3530 */           break;
/* 3538:     */         }
/* 3539:     */       }
/* 3540:3533 */       if (vector.isEmpty()) {
/* 3541:3534 */         this.beanOperationHandlers.remove(dataBeanName);
/* 3542:     */       } else {
/* 3543:3536 */         this.beanOperationHandlers.put(dataBeanName, vector);
/* 3544:     */       }
/* 3545:     */     }
/* 3546:     */   }
/* 3547:     */   
/* 3548:     */   public void unregisterOperationHandler(String operationName)
/* 3549:     */   {
/* 3550:3549 */     this.operationHandlers.remove(operationName);
/* 3551:     */   }
/* 3552:     */   
/* 3553:     */   public void autoSendAll(String mobileMboName)
/* 3554:     */     throws MobileApplicationException
/* 3555:     */   {
/* 3556:3560 */     boolean autoSendAll = getBooleanPreference("AUTOSENDALL");
/* 3557:3561 */     if (!autoSendAll) {
/* 3558:3562 */       return;
/* 3559:     */     }
/* 3560:3565 */     MobileMboDataBeanManager dataBeanManager = new MobileMboDataBeanManager(mobileMboName);
/* 3561:3566 */     MobileMboDataBean dataBean = dataBeanManager.getDataBean();
/* 3562:3567 */     dataBean.reset();
/* 3563:3568 */     dataBean.doneAll();
/* 3564:     */   }
/* 3565:     */   
/* 3566:     */   public long getTimeAdjustment()
/* 3567:     */   {
/* 3568:3579 */     String timeDiff = getAppSetting("_TIMEDIFF");
/* 3569:3580 */     if (timeDiff == null) {
/* 3570:3581 */       return 0L;
/* 3571:     */     }
/* 3572:3584 */     long timeDifference = Long.parseLong(timeDiff);
/* 3573:3585 */     return timeDifference;
/* 3574:     */   }
/* 3575:     */   
/* 3576:     */   public boolean isServerAuthentication()
/* 3577:     */   {
/* 3578:3594 */     String serverAuth = getAppSetting("_SERVERAUTH");
/* 3579:3596 */     if (serverAuth == null) {
/* 3580:3597 */       return false;
/* 3581:     */     }
/* 3582:3599 */     return new Boolean(serverAuth).booleanValue();
/* 3583:     */   }
/* 3584:     */   
/* 3585:     */   public void determineTimeAdjustment(ProgressObserver observer)
/* 3586:     */     throws MobileApplicationException
/* 3587:     */   {
/* 3588:3610 */     String msg = MobileMessageGenerator.generate("gettimediff", new Object[0]);
/* 3589:3611 */     if (observer != null) {
/* 3590:3612 */       observer.setWorkProgressMessage(msg);
/* 3591:     */     }
/* 3592:3614 */     long timeDifference = this.mobileWebServiceProxy.getTimeDifference();
/* 3593:3615 */     setAppSetting("_TIMEDIFF", "" + timeDifference);
/* 3594:     */   }
/* 3595:     */   
/* 3596:     */   public void setPasswordExpired()
/* 3597:     */     throws MobileApplicationException
/* 3598:     */   {
/* 3599:3624 */     MobileMboDataBeanManager dataBeanManager = new MobileMboDataBeanManager("USER");
/* 3600:3625 */     MobileMboDataBean userDataBean = dataBeanManager.getDataBean();
/* 3601:3626 */     userDataBean.reset();
/* 3602:     */     
/* 3603:3628 */     MobileMbo userMbo = userDataBean.getMobileMbo(0);
/* 3604:3629 */     if (userMbo == null) {
/* 3605:3630 */       return;
/* 3606:     */     }
/* 3607:3633 */     userMbo.setBooleanValue("FORCEEXPIRATION", true);
/* 3608:3634 */     dataBeanManager.save();
/* 3609:     */   }
/* 3610:     */   
/* 3611:     */   public void appBoot()
/* 3612:     */     throws MobileApplicationException
/* 3613:     */   {
/* 3614:3638 */     if (this.locationProvider != null) {
/* 3615:3639 */       this.locationProvider.initialize();
/* 3616:     */     }
/* 3617:     */   }
/* 3618:     */   
/* 3619:     */   private void loadUserIndexProperties(String fileName)
/* 3620:     */     throws RDOException
/* 3621:     */   {
/* 3622:3647 */     RDOInfoManager dbInfoManager = this.rdoRuntime.getRDOInfoManager();
/* 3623:     */     
/* 3624:3649 */     Vector exIndexes = dbInfoManager.getIndexNames();
/* 3625:     */     
/* 3626:3651 */     InputStream is = null;
/* 3627:     */     
/* 3628:3653 */     is = getClass().getResourceAsStream(fileName);
/* 3629:3655 */     if (is == null) {
/* 3630:3656 */       return;
/* 3631:     */     }
/* 3632:3659 */     InputStreamReader reader = new InputStreamReader(is);
/* 3633:     */     try
/* 3634:     */     {
/* 3635:3662 */       char[] charBuf = new char[1024];
/* 3636:3663 */       StringBuffer lineBuf = new StringBuffer();
/* 3637:3664 */       String line = null;
/* 3638:     */       for (;;)
/* 3639:     */       {
/* 3640:3667 */         int charsRead = reader.read(charBuf, 0, charBuf.length);
/* 3641:3668 */         if (charsRead == -1)
/* 3642:     */         {
/* 3643:3670 */           if (lineBuf.length() <= 0) {
/* 3644:     */             break;
/* 3645:     */           }
/* 3646:3671 */           line = lineBuf.toString();
/* 3647:3672 */           line = line.trim();
/* 3648:3673 */           if ((line.length() <= 0) || (line.startsWith("//"))) {
/* 3649:     */             break;
/* 3650:     */           }
/* 3651:3674 */           processProperty(line, this.properties); break;
/* 3652:     */         }
/* 3653:3681 */         for (int i = 0; i < charsRead; i++) {
/* 3654:3682 */           if ((charBuf[i] == '\n') || (charBuf[i] == '\r'))
/* 3655:     */           {
/* 3656:3683 */             line = lineBuf.toString();
/* 3657:3684 */             lineBuf = new StringBuffer();
/* 3658:     */             
/* 3659:3686 */             line = line.trim();
/* 3660:3687 */             if ((line.length() > 0) && (!line.startsWith("//"))) {
/* 3661:3688 */               processIndexes(line, exIndexes);
/* 3662:     */             }
/* 3663:     */           }
/* 3664:     */           else
/* 3665:     */           {
/* 3666:3691 */             lineBuf.append(charBuf[i]);
/* 3667:     */           }
/* 3668:     */         }
/* 3669:     */       }
/* 3670:     */     }
/* 3671:     */     catch (IOException e) {}
/* 3672:3698 */     if (exIndexes.size() > 0)
/* 3673:     */     {
/* 3674:3699 */       Enumeration indxNames = exIndexes.elements();
/* 3675:3700 */       while (indxNames.hasMoreElements())
/* 3676:     */       {
/* 3677:3701 */         String element = (String)indxNames.nextElement();
/* 3678:3702 */         dbInfoManager.dropIndex(element);
/* 3679:     */       }
/* 3680:     */     }
/* 3681:     */   }
/* 3682:     */   
/* 3683:     */   private void processIndexes(String propertyLine, Vector inExIndexes)
/* 3684:     */     throws RDOException
/* 3685:     */   {
/* 3686:3712 */     int index = propertyLine.indexOf('=');
/* 3687:3713 */     if ((index > 0) && (!propertyLine.startsWith("#")))
/* 3688:     */     {
/* 3689:3714 */       String propertyName = propertyLine.substring(0, index);
/* 3690:3715 */       String propertyValue = propertyLine.substring(index + 1);
/* 3691:3716 */       propertyValue = propertyValue.trim();
/* 3692:3717 */       String mobileMbo = "";
/* 3693:3718 */       if (propertyValue.length() > 0)
/* 3694:     */       {
/* 3695:3719 */         StringTokenizer st = new StringTokenizer(propertyValue, ",");
/* 3696:3720 */         String[] colArray = new String[st.countTokens() - 1];
/* 3697:3721 */         if (st.hasMoreTokens())
/* 3698:     */         {
/* 3699:3722 */           mobileMbo = st.nextToken();
/* 3700:3723 */           int i = 0;
/* 3701:3724 */           while (st.hasMoreTokens())
/* 3702:     */           {
/* 3703:3725 */             colArray[i] = st.nextToken();
/* 3704:3726 */             i++;
/* 3705:     */           }
/* 3706:     */         }
/* 3707:3730 */         RDOInfoManager dbInfoManager = this.rdoRuntime.getRDOInfoManager();
/* 3708:3731 */         dbInfoManager.createIndex(mobileMbo + "_" + propertyName, mobileMbo, colArray);
/* 3709:3732 */         inExIndexes.remove(mobileMbo + "_" + propertyName);
/* 3710:     */       }
/* 3711:     */     }
/* 3712:     */   }
/* 3713:     */   
/* 3714:     */   private void applyProductCustomizations(MobileMetaData mobileMetaData)
/* 3715:     */   {
/* 3716:3741 */     Hashtable product = new Hashtable();
/* 3717:3742 */     int NAME = 0;
/* 3718:3743 */     int ID = 1;
/* 3719:3744 */     int ATTRIBUTE_NAME = 2;
/* 3720:     */     
/* 3721:     */ 
/* 3722:3747 */     loadApplicationProperties("/brand.properties", product);
/* 3723:3748 */     Enumeration it = product.keys();
/* 3724:3749 */     while (it.hasMoreElements())
/* 3725:     */     {
/* 3726:3750 */       String propertyName = it.nextElement().toString();
/* 3727:3751 */       String value = (String)product.get(propertyName);
/* 3728:3752 */       String[] propertyInfo = parseProperty(propertyName);
/* 3729:3753 */       MobileUIControlInfo uiControl = mobileMetaData.getMobileUIComponentInfo(propertyInfo[1]);
/* 3730:3755 */       if ((uiControl != null) && (uiControl.getComponentData().getName().equals(propertyInfo[0]))) {
/* 3731:3757 */         uiControl.getComponentData().putValue(propertyInfo[2], value);
/* 3732:     */       }
/* 3733:     */     }
/* 3734:     */   }
/* 3735:     */   
/* 3736:     */   private String[] parseProperty(String propertyName)
/* 3737:     */   {
/* 3738:3766 */     Vector tokens = new Vector();
/* 3739:3767 */     int end = propertyName.indexOf('.');
/* 3740:3768 */     int begin = 0;
/* 3741:3769 */     while (begin < propertyName.length())
/* 3742:     */     {
/* 3743:3770 */       String token = propertyName.substring(begin, end);
/* 3744:3771 */       tokens.addElement(token);
/* 3745:3772 */       begin = end + 1;
/* 3746:3773 */       if (begin < propertyName.length())
/* 3747:     */       {
/* 3748:3774 */         end = propertyName.indexOf('.', begin);
/* 3749:3775 */         end = end < 0 ? propertyName.length() : end;
/* 3750:     */       }
/* 3751:     */     }
/* 3752:3778 */     String[] parsed = new String[tokens.size()];
/* 3753:3779 */     for (int i = 0; i < tokens.size(); i++) {
/* 3754:3780 */       parsed[i] = tokens.elementAt(i).toString();
/* 3755:     */     }
/* 3756:3782 */     return parsed;
/* 3757:     */   }
/* 3758:     */   
/* 3759:     */   public Vector getDeviceRegisteredUsers()
/* 3760:     */     throws MobileApplicationException
/* 3761:     */   {
/* 3762:3787 */     release(this.currentUser);
/* 3763:3788 */     initSystemPersistenceRuntime();
/* 3764:3789 */     Vector vector = getAllRegisteredUsers();
/* 3765:3790 */     resetSystemPersistenceRuntime();
/* 3766:     */     
/* 3767:     */ 
/* 3768:3793 */     initializeAppUserRuntime(this.currentUser, null);
/* 3769:3794 */     MobileMetaData metaData = MobileDeviceAppSession.getSession().getMobileMetadata();
/* 3770:3795 */     initApplicationFromMetaData(metaData);
/* 3771:3796 */     return vector;
/* 3772:     */   }
/* 3773:     */   
/* 3774:     */   private int computeDownloadCount(String[] orderNames)
/* 3775:     */   {
/* 3776:3803 */     int count = 0;
/* 3777:3804 */     int dataGroupsNum = orderNames.length;
/* 3778:3805 */     for (int i = 0; i < dataGroupsNum; i++)
/* 3779:     */     {
/* 3780:3806 */       int hasCount = orderNames[i].indexOf(":");
/* 3781:3807 */       if (hasCount > 0) {
/* 3782:3808 */         count += Integer.parseInt(orderNames[i].substring(hasCount + 1));
/* 3783:     */       }
/* 3784:     */     }
/* 3785:3811 */     return count;
/* 3786:     */   }
/* 3787:     */   
/* 3788:     */   private int getBalanceDownloadCount(int subCount)
/* 3789:     */   {
/* 3790:3815 */     int tempCount = getTotalDownloadCount();
/* 3791:3816 */     if ((subCount > 0) && (tempCount > 0)) {
/* 3792:3817 */       return tempCount - subCount;
/* 3793:     */     }
/* 3794:3819 */     return tempCount;
/* 3795:     */   }
/* 3796:     */   
/* 3797:     */   private int getTotalDownloadCount()
/* 3798:     */   {
/* 3799:3828 */     return this.totalDownloadCount;
/* 3800:     */   }
/* 3801:     */   
/* 3802:     */   private void setTotalDownloadCount(int totalDownloadCount)
/* 3803:     */   {
/* 3804:3832 */     this.totalDownloadCount = totalDownloadCount;
/* 3805:     */   }
/* 3806:     */   
/* 3807:     */   public void markSplashScreenLockDone()
/* 3808:     */     throws MobileApplicationException
/* 3809:     */   {
/* 3810:3837 */     String splashLockPath = getSplashLockFilePath();
/* 3811:3838 */     if ((splashLockPath != null) && (!"".equals(splashLockPath)))
/* 3812:     */     {
/* 3813:3839 */       File f = new File(splashLockPath);
/* 3814:3840 */       if (f.exists()) {
/* 3815:     */         try
/* 3816:     */         {
/* 3817:3848 */           FileWriter fw = new FileWriter(f);
/* 3818:3849 */           fw.write("DONE");
/* 3819:3850 */           fw.flush();
/* 3820:3851 */           fw.close();
/* 3821:     */         }
/* 3822:     */         catch (IOException e1)
/* 3823:     */         {
/* 3824:3853 */           throw new MobileApplicationException(e1);
/* 3825:     */         }
/* 3826:     */       } else {
/* 3827:3856 */         throw new MobileApplicationException("splashlockfilenotfound");
/* 3828:     */       }
/* 3829:     */     }
/* 3830:     */   }
/* 3831:     */   
/* 3832:     */   public String getSplashLockFilePath()
/* 3833:     */   {
/* 3834:3862 */     return getSystemProperty("com.ibm.maximo.mobile.lockfile.path");
/* 3835:     */   }
/* 3836:     */   
/* 3837:     */   private int getRefreshNumberOfRecords()
/* 3838:     */   {
/* 3839:3867 */     if (this.refreshNumberOfRecords <= 0)
/* 3840:     */     {
/* 3841:3868 */       String value = getProperty("maximo.mobile.refreshdata.numberrec");
/* 3842:     */       try
/* 3843:     */       {
/* 3844:3870 */         if (value != null) {
/* 3845:3871 */           this.refreshNumberOfRecords = Integer.parseInt(value);
/* 3846:     */         }
/* 3847:     */       }
/* 3848:     */       catch (Exception e)
/* 3849:     */       {
/* 3850:3874 */         this.refreshNumberOfRecords = 50;
/* 3851:     */       }
/* 3852:     */     }
/* 3853:3877 */     return this.refreshNumberOfRecords;
/* 3854:     */   }
/* 3855:     */   
/* 3856:     */   public boolean isAutomationModeOn()
/* 3857:     */   {
/* 3858:3881 */     return this.automationMode;
/* 3859:     */   }
/* 3860:     */   
/* 3861:     */   private void determineAutomationMode()
/* 3862:     */   {
/* 3863:3885 */     this.automationMode = false;
/* 3864:3886 */     String automationOn = getProperty("maximo.automationmode_on");
/* 3865:3887 */     if ((automationOn != null) && (automationOn.equals("true"))) {
/* 3866:3888 */       this.automationMode = true;
/* 3867:     */     }
/* 3868:     */   }
/* 3869:     */   
/* 3870:     */   public boolean sendsUserLocationWhenConnected()
/* 3871:     */   {
/* 3872:3899 */     return false;
/* 3873:     */   }
/* 3874:     */   
/* 3875:     */   public void pluginGPSUserLocationProvider(UserLocationProvider locationProvider)
/* 3876:     */   {
/* 3877:3903 */     this.locationProvider = locationProvider;
/* 3878:     */   }
/* 3879:     */   
/* 3880:     */   public UserLocationDataInfo getCurrentUserLocation()
/* 3881:     */   {
/* 3882:3907 */     return this.locationProvider != null ? this.locationProvider.getCurrentUserLocation() : null;
/* 3883:     */   }
/* 3884:     */   
/* 3885:     */   public boolean isUserLocationProfileSet()
/* 3886:     */   {
/* 3887:3911 */     return this.locationProvider != null;
/* 3888:     */   }
/* 3889:     */   
/* 3890:     */   protected void initSystemProperties() {}
/* 3891:     */   
/* 3892:     */   public void storeSnapshot(String alreadyUsedByUserName, String currentUserName, ProgressObserver observer)
/* 3893:     */     throws MobileApplicationException
/* 3894:     */   {}
/* 3895:     */   
/* 3896:     */   public void retrieveSnapshot(ProgressObserver observer)
/* 3897:     */     throws MobileApplicationException
/* 3898:     */   {}
/* 3899:     */   
/* 3900:     */   public void initializeApplication()
/* 3901:     */     throws MobileApplicationException
/* 3902:     */   {}
/* 3903:     */   
/* 3904:     */   public void initProxy(DefaultMobileWebServiceProxy proxy)
/* 3905:     */     throws MobileApplicationException
/* 3906:     */   {}
/* 3907:     */   
/* 3908:     */   protected abstract DefaultMobileWebServiceProxy createMobileWebServiceProxy()
/* 3909:     */     throws MobileApplicationException;
/* 3910:     */   
/* 3911:     */   protected abstract UIEventHandler createEventHandler()
/* 3912:     */     throws MobileApplicationException;
/* 3913:     */   
/* 3914:     */   protected abstract String[] recordsToWatchModifications()
/* 3915:     */     throws MobileApplicationException;
/* 3916:     */   
/* 3917:     */   protected void appPreRefreshMobileMbos(boolean includeWorkList, boolean includeRelatedList)
/* 3918:     */     throws MobileApplicationException
/* 3919:     */   {}
/* 3920:     */   
/* 3921:     */   protected void appPostRefreshMobileMbos(boolean includeWorkList, boolean includeRelatedList)
/* 3922:     */     throws MobileApplicationException
/* 3923:     */   {}
/* 3924:     */   
/* 3925:     */   public void setupDefaultPreferences(MobileMbo preferencesMbo)
/* 3926:     */     throws MobileApplicationException
/* 3927:     */   {}
/* 3928:     */   
/* 3929:     */   public void setupConnectionTimeoutSetttings(HttpURLConnection connection) {}
/* 3930:     */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.AbstractMobileDeviceApplication
 * JD-Core Version:    0.7.0.1
 */