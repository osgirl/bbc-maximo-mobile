/*   1:    */ package com.mro.mobile.app.pluscmobwo;
/*   2:    */ 
/*   3:    */ import com.ibm.tivoli.maximo.util.mboadapter.mobile.MobileMboAdapter;
/*   4:    */ import com.mro.mobile.MobileApplicationException;
/*   5:    */ import com.mro.mobile.app.DefaultMobileMboDataFormatter;
/*   6:    */ import com.mro.mobile.app.mobilewo.WOToolTransEventHandler;
/*   7:    */ import com.mro.mobile.mbo.MobileMbo;
/*   8:    */ import com.mro.mobile.mbo.MobileMboQBE;
/*   9:    */ import com.mro.mobile.persist.RDOException;
/*  10:    */ import com.mro.mobile.ui.MobileMboDataBean;
/*  11:    */ import com.mro.mobile.ui.MobileMboDataBeanManager;
/*  12:    */ import com.mro.mobile.ui.event.UIEvent;
/*  13:    */ import com.mro.mobile.ui.res.UIUtil;
/*  14:    */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*  15:    */ import com.mro.mobile.ui.res.controls.PageControl;
/*  16:    */ import com.mro.mobile.ui.res.controls.TextboxControl;
/*  17:    */ import com.mro.mobileapp.WOApp;
/*  18:    */ import java.util.Date;
/*  19:    */ 
/*  20:    */ public class PlusCMobWOToolTransEventHandler
/*  21:    */   extends WOToolTransEventHandler
/*  22:    */ {
/*  23:    */   public boolean performEvent(UIEvent event)
/*  24:    */     throws MobileApplicationException
/*  25:    */   {
/*  26: 38 */     if (event == null) {
/*  27: 39 */       return false;
/*  28:    */     }
/*  29: 41 */     String eventId = event.getEventName();
/*  30: 43 */     if (eventId.equalsIgnoreCase("pluscfillduedate")) {
/*  31: 45 */       return pluscfillduedate(event);
/*  32:    */     }
/*  33: 49 */     return super.performEvent(event);
/*  34:    */   }
/*  35:    */   
/*  36:    */   public boolean validatepage(UIEvent event)
/*  37:    */     throws MobileApplicationException
/*  38:    */   {
/*  39: 66 */     MobileMboDataBean woToolTransDataBean = UIUtil.getCurrentScreen().getDataBean();
/*  40: 67 */     MobileMbo woToolTransMbo = woToolTransDataBean.getMobileMbo();
/*  41:    */     
/*  42:    */ 
/*  43:    */ 
/*  44:    */ 
/*  45:    */ 
/*  46:    */ 
/*  47:    */ 
/*  48:    */ 
/*  49:    */ 
/*  50:    */ 
/*  51:    */ 
/*  52:    */ 
/*  53:    */ 
/*  54: 81 */     MobileMboDataBeanManager mgrItemDataBean = new MobileMboDataBeanManager("PLUSCITEM");
/*  55: 82 */     mgrItemDataBean.reset();
/*  56: 83 */     MobileMboDataBean itemDataBean = mgrItemDataBean.getDataBean();
/*  57:    */     
/*  58: 85 */     itemDataBean.getQBE().setQbeExactMatch(true);
/*  59: 86 */     itemDataBean.getQBE().setQBE("ITEMNUM", woToolTransMbo.getValue("ITEMNUM"));
/*  60: 87 */     itemDataBean.getQBE().setQBE("ITEMSETID", woToolTransMbo.getValue("ITEMSETID"));
/*  61:    */     
/*  62: 89 */     MobileMbo itemMbo = itemDataBean.getMobileMbo(0);
/*  63: 91 */     if ((woToolTransMbo.isNull("ROTASSETNUM")) || (woToolTransMbo.getValue("ROTASSETNUM").equalsIgnoreCase(""))) {
/*  64: 93 */       if ((itemMbo != null) && (itemMbo.getBooleanValue("ROTATING")))
/*  65:    */       {
/*  66: 95 */         woToolTransMbo.setRequired("ROTASSETNUM", true);
/*  67: 96 */         UIUtil.refreshCurrentScreen();
/*  68: 97 */         return false;
/*  69:    */       }
/*  70:    */     }
/*  71:103 */     MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager("ASSET");
/*  72:104 */     MobileMboDataBean assetBean = mgrDBMgr.getDataBean();
/*  73:105 */     assetBean.getQBE().setQBE("ASSETNUM", (String)event.getValue());
/*  74:106 */     assetBean.getQBE().setQBE("SITEID", woToolTransMbo.getValue("SITEID"));
/*  75:107 */     MobileMbo assetMbo = assetBean.getMobileMbo(0);
/*  76:108 */     if (assetMbo != null) {
/*  77:109 */       woToolTransMbo.setValue("ROTASSETSITE", assetMbo.getValue("SITEID"));
/*  78:    */     }
/*  79:112 */     String workTypeCal = null;
/*  80:    */     
/*  81:114 */     String itemNum = ((TextboxControl)UIUtil.findControl("acttooldetA2")).getControlValue();
/*  82:115 */     String plusctechnician = ((TextboxControl)UIUtil.findControl("acttooldetA6")).getControlValue();
/*  83:    */     
/*  84:117 */     String pluscduedate = ((TextboxControl)UIUtil.findControl("acttooldetA7")).getControlValue();
/*  85:118 */     String plusctoolusedate = ((TextboxControl)UIUtil.findControl("acttooldetA8")).getControlValue();
/*  86:119 */     Date duedate = pluscduedate.equalsIgnoreCase("") ? null : DefaultMobileMboDataFormatter.stringToDateTime(pluscduedate);
/*  87:    */     
/*  88:121 */     Date toolusedate = plusctoolusedate.equalsIgnoreCase("") ? null : DefaultMobileMboDataFormatter.stringToDateTime(plusctoolusedate);
/*  89:    */     
/*  90:    */ 
/*  91:    */ 
/*  92:125 */     String pluscqualtech = ((WOApp)UIUtil.getApplication()).getMaxVar(woToolTransDataBean, "PLUSCQUALTECH");
/*  93:    */     
/*  94:    */ 
/*  95:128 */     String pluscpastdueval = ((WOApp)UIUtil.getApplication()).getMaxVar(woToolTransDataBean, "PLUSCPASTDUEVAL");
/*  96:    */     
/*  97:130 */     MobileMboDataBean woDataBean = woToolTransDataBean.getParentBean();
/*  98:132 */     if (!pluscpastdueval.equals("1")) {
/*  99:135 */       if (woDataBean != null)
/* 100:    */       {
/* 101:137 */         if (woDataBean.getName().equals("WORKORDER")) {
/* 102:139 */           workTypeCal = ((WOApp)UIUtil.getApplication()).getMaxVar(woToolTransDataBean, "PLUSCWORKTYPECAL");
/* 103:    */         }
/* 104:141 */         if (!woDataBean.getMobileMbo().getValue("WORKTYPE").equals(workTypeCal)) {
/* 105:144 */           if (duedate != null)
/* 106:    */           {
/* 107:147 */             if (toolusedate == null) {
/* 108:151 */               toolusedate = woToolTransDataBean.getCurrentTime();
/* 109:    */             }
/* 110:153 */             if (duedate.before(toolusedate)) {
/* 111:155 */               throw new MobileApplicationException("plusctoolpastduecal");
/* 112:    */             }
/* 113:    */           }
/* 114:    */         }
/* 115:    */       }
/* 116:    */     }
/* 117:162 */     if (!pluscqualtech.equalsIgnoreCase("0")) {
/* 118:165 */       if ((!itemNum.equalsIgnoreCase("")) && (!plusctechnician.equalsIgnoreCase("")))
/* 119:    */       {
/* 120:168 */         MobileMboDataBeanManager mgrToolQualDataBean = new MobileMboDataBeanManager("TOOLQUAL");
/* 121:169 */         MobileMboDataBean toolQualDataBean = mgrToolQualDataBean.getDataBean();
/* 122:170 */         toolQualDataBean.reset();
/* 123:171 */         toolQualDataBean.getQBE().setQbeExactMatch(true);
/* 124:172 */         toolQualDataBean.getQBE().setQBE("ITEMNUM", itemNum);
/* 125:173 */         toolQualDataBean.getQBE().setQBE("ITEMSETID", woToolTransMbo.getValue("ITEMSETID"));
/* 126:174 */         toolQualDataBean.reset();
/* 127:    */         
/* 128:176 */         MobileMbo toolQualMbo = null;
/* 129:177 */         int dloop = 0;
/* 130:178 */         boolean tecQualified = true;
/* 131:180 */         while ((toolQualMbo = toolQualDataBean.getMobileMbo(dloop)) != null)
/* 132:    */         {
/* 133:183 */           MobileMboDataBeanManager mgrLaborQualDataBean = new MobileMboDataBeanManager("LABORQUAL");
/* 134:184 */           MobileMboDataBean laborQualDataBean = mgrLaborQualDataBean.getDataBean();
/* 135:    */           
/* 136:186 */           laborQualDataBean.reset();
/* 137:187 */           laborQualDataBean.getQBE().setQbeExactMatch(true);
/* 138:188 */           laborQualDataBean.getQBE().setQBE("QUALIFICATIONID", toolQualMbo.getValue("QUALIFICATIONID"));
/* 139:189 */           laborQualDataBean.getQBE().setQBE("LABORCODE", plusctechnician);
/* 140:190 */           laborQualDataBean.reset();
/* 141:192 */           if (laborQualDataBean.count() == 0) {
/* 142:194 */             tecQualified = false;
/* 143:    */           }
/* 144:196 */           dloop++;
/* 145:    */         }
/* 146:199 */         if (!tecQualified) {
/* 147:201 */           if (pluscqualtech.equalsIgnoreCase("1")) {
/* 148:203 */             UIUtil.showMessageBoxControl("pluscdescbox", "Technician is unqualified to use this Tool.", event);
/* 149:206 */           } else if (pluscqualtech.equalsIgnoreCase("2")) {
/* 150:208 */             throw new MobileApplicationException("pluscqualtechwarn");
/* 151:    */           }
/* 152:    */         }
/* 153:    */       }
/* 154:    */     }
/* 155:217 */     if (!validateRotating(woToolTransDataBean)) {
/* 156:218 */       throw new MobileApplicationException("requiredblank", new String[] { "Rotating Asset" });
/* 157:    */     }
/* 158:224 */     PlusCMobileWOToolTransDelegate toolTrans = new PlusCMobileWOToolTransDelegate(new MobileMboAdapter(woToolTransMbo, woToolTransDataBean));
/* 159:    */     try
/* 160:    */     {
/* 161:227 */       toolTrans.validateBufferSolution();
/* 162:    */       
/* 163:229 */       toolTrans.validateDates();
/* 164:    */     }
/* 165:    */     catch (MobileApplicationException me)
/* 166:    */     {
/* 167:232 */       throw me;
/* 168:    */     }
/* 169:    */     catch (RuntimeException rte)
/* 170:    */     {
/* 171:233 */       throw rte;
/* 172:    */     }
/* 173:    */     catch (Exception e)
/* 174:    */     {
/* 175:235 */       e.printStackTrace();
/* 176:236 */       throw new MobileApplicationException("internalerror", e);
/* 177:    */     }
/* 178:239 */     return super.validatepage(event);
/* 179:    */   }
/* 180:    */   
/* 181:    */   protected boolean validateRotating(MobileMboDataBean woToolTransDataBean)
/* 182:    */     throws MobileApplicationException, RDOException
/* 183:    */   {
/* 184:255 */     boolean retval = true;
/* 185:    */     
/* 186:257 */     String itemNum = woToolTransDataBean.getValue("ITEMNUM");
/* 187:258 */     if (itemNum != null)
/* 188:    */     {
/* 189:260 */       String itemSetId = woToolTransDataBean.getValue("ITEMSETID");
/* 190:    */       
/* 191:262 */       MobileMbo tool = getTool(itemNum, itemSetId);
/* 192:263 */       if ((tool != null) && (tool.getBooleanValue("ROTATING")))
/* 193:    */       {
/* 194:264 */         String rotAsset = woToolTransDataBean.getValue("ROTASSETNUM");
/* 195:265 */         if ((rotAsset == null) || (rotAsset.equals(""))) {
/* 196:266 */           retval = false;
/* 197:    */         }
/* 198:    */       }
/* 199:    */     }
/* 200:271 */     return retval;
/* 201:    */   }
/* 202:    */   
/* 203:    */   protected MobileMbo getTool(String itemNum, String itemSetId)
/* 204:    */     throws MobileApplicationException, RDOException
/* 205:    */   {
/* 206:288 */     MobileMboDataBeanManager toolsDataBeanMgr = new MobileMboDataBeanManager("TOOL");
/* 207:289 */     MobileMboDataBean tools = toolsDataBeanMgr.getDataBean();
/* 208:    */     
/* 209:291 */     tools.reset();
/* 210:292 */     tools.getQBE().setQbeExactMatch(true);
/* 211:293 */     tools.getQBE().setQBE("ITEMSETID", itemSetId);
/* 212:294 */     tools.getQBE().setQBE("ITEMNUM", itemNum);
/* 213:295 */     tools.reset();
/* 214:    */     
/* 215:297 */     MobileMbo tool = tools.getMobileMbo();
/* 216:    */     
/* 217:299 */     return tool;
/* 218:    */   }
/* 219:    */   
/* 220:    */   public boolean pluscfillduedate(UIEvent event)
/* 221:    */     throws MobileApplicationException
/* 222:    */   {
/* 223:314 */     String thisControlValue = (String)event.getValue();
/* 224:316 */     if ((thisControlValue == null) || (thisControlValue.equalsIgnoreCase(""))) {
/* 225:318 */       return true;
/* 226:    */     }
/* 227:322 */     MobileMboDataBean woToolDataBean = UIUtil.getCurrentScreen().getDataBean();
/* 228:323 */     MobileMboDataBean woToolTransDataBean = ((PageControl)UIUtil.getCurrentScreen()).getLaunchingControl().getDataBean();
/* 229:    */     
/* 230:    */ 
/* 231:    */ 
/* 232:    */ 
/* 233:    */ 
/* 234:    */ 
/* 235:    */ 
/* 236:    */ 
/* 237:    */ 
/* 238:    */ 
/* 239:    */ 
/* 240:    */ 
/* 241:    */ 
/* 242:    */ 
/* 243:    */ 
/* 244:    */ 
/* 245:    */ 
/* 246:341 */     MobileMboDataBeanManager mgrPM = new MobileMboDataBeanManager("PM");
/* 247:342 */     MobileMboDataBean pmDataBean = mgrPM.getDataBean();
/* 248:    */     
/* 249:344 */     String workTypeCal = ((WOApp)UIUtil.getApplication()).getMaxVar(pmDataBean, "PLUSCWORKTYPECAL");
/* 250:    */     
/* 251:346 */     pmDataBean.reset();
/* 252:347 */     pmDataBean.getQBE().setQbeExactMatch(true);
/* 253:348 */     pmDataBean.getQBE().setQBE("ASSETNUM", thisControlValue);
/* 254:349 */     pmDataBean.getQBE().setQBE("SITEID", woToolDataBean.getValue("SITEID"));
/* 255:350 */     pmDataBean.getQBE().setQBE("WORKTYPE", workTypeCal);
/* 256:351 */     pmDataBean.reset();
/* 257:353 */     if (pmDataBean.count() != 0)
/* 258:    */     {
/* 259:355 */       MobileMbo pmMbo = pmDataBean.getMobileMbo(0);
/* 260:356 */       if (pmMbo != null)
/* 261:    */       {
/* 262:358 */         Date nextCalDueDate = pmMbo.getDateValue("NEXTDATE");
/* 263:359 */         if (nextCalDueDate != null) {
/* 264:361 */           woToolTransDataBean.getMobileMbo(0).setDateValue("PLUSCDUEDATE", nextCalDueDate, false);
/* 265:    */         }
/* 266:    */       }
/* 267:    */     }
/* 268:368 */     return false;
/* 269:    */   }
/* 270:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.pluscmobwo.PlusCMobWOToolTransEventHandler
 * JD-Core Version:    0.7.0.1
 */