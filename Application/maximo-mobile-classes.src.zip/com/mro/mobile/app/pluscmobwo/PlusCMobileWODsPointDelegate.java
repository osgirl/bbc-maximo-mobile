/*  1:   */ package com.mro.mobile.app.pluscmobwo;
/*  2:   */ 
/*  3:   */ import com.ibm.tivoli.maximo.util.mboadapter.MboAdapter;
/*  4:   */ import com.ibm.tivoli.maximo.util.mboadapter.MboSetAdapter;
/*  5:   */ import com.ibm.tivoli.maximo.util.mboadapter.mobile.MobileMboAdapter;
/*  6:   */ import com.ibm.tivoli.maximo.util.mboadapter.mobile.MobileMboSetAdapter;
/*  7:   */ import com.mro.mobile.MobileApplicationException;
/*  8:   */ import com.mro.mobile.mbo.MobileMbo;
/*  9:   */ import com.mro.mobile.mbo.MobileMboQBE;
/* 10:   */ import com.mro.mobile.ui.MobileMboDataBean;
/* 11:   */ import com.mro.mobile.ui.MobileMboDataBeanManager;
/* 12:   */ import psdi.plusc.app.pluscds.pluscmobilecommon.PlusCWODsInstrDelegate;
/* 13:   */ import psdi.plusc.app.pluscds.pluscmobilecommon.PlusCWODsPointDelegate;
/* 14:   */ 
/* 15:   */ public class PlusCMobileWODsPointDelegate
/* 16:   */   extends PlusCWODsPointDelegate
/* 17:   */ {
/* 18:   */   public PlusCWODsPointDelegate newInstance(MboAdapter mbo, PlusCWODsInstrDelegate woDsInstrDelegate)
/* 19:   */     throws Exception
/* 20:   */   {
/* 21:40 */     return new PlusCMobileWODsPointDelegate(mbo, woDsInstrDelegate);
/* 22:   */   }
/* 23:   */   
/* 24:   */   public PlusCMobileWODsPointDelegate(MboAdapter mbo, PlusCWODsInstrDelegate woDsInstrDelegate)
/* 25:   */   {
/* 26:44 */     super(mbo, woDsInstrDelegate);
/* 27:   */   }
/* 28:   */   
/* 29:   */   protected PlusCWODsInstrDelegate findParentInstrDelegate()
/* 30:   */     throws Exception
/* 31:   */   {
/* 32:49 */     MboSetAdapter parentInstrSet = getParentInstrSet();
/* 33:50 */     return new PlusCMobileWODsInstrDelegate(parentInstrSet.getMbo());
/* 34:   */   }
/* 35:   */   
/* 36:   */   public MboSetAdapter getParentInstrSet()
/* 37:   */     throws MobileApplicationException
/* 38:   */   {
/* 39:56 */     MobileMbo referenceMbo = ((MobileMboAdapter)this.thisMbo).getMbo();
/* 40:   */     
/* 41:58 */     MobileMboDataBeanManager instrmgr = new MobileMboDataBeanManager("PLUSCWODSINSTR");
/* 42:59 */     MobileMboDataBean instrBean = instrmgr.getDataBean();
/* 43:60 */     instrBean.getQBE().reset();
/* 44:61 */     instrBean.getQBE().setQbeExactMatch(true);
/* 45:62 */     instrBean.getQBE().setQBE("DSPLANNUM", referenceMbo.getValue("DSPLANNUM"));
/* 46:63 */     instrBean.getQBE().setQBE("WODSNUM", referenceMbo.getValue("WODSNUM"));
/* 47:64 */     instrBean.getQBE().setQBE("SITEID", referenceMbo.getValue("SITEID"));
/* 48:65 */     instrBean.getQBE().setQBE("REVISIONNUM", referenceMbo.getValue("REVISIONNUM"));
/* 49:66 */     instrBean.getQBE().setQBE("WONUM", referenceMbo.getValue("WONUM"));
/* 50:67 */     instrBean.getQBE().setQBE("INSTRSEQ", referenceMbo.getValue("INSTRSEQ"));
/* 51:68 */     instrBean.reset();
/* 52:   */     
/* 53:70 */     return new MobileMboSetAdapter(instrBean);
/* 54:   */   }
/* 55:   */   
/* 56:   */   protected MboSetAdapter getAveragePointsSet()
/* 57:   */     throws Exception
/* 58:   */   {
/* 59:76 */     MobileMboAdapter thisMobileMboAdapter = (MobileMboAdapter)this.thisMbo;
/* 60:   */     
/* 61:78 */     MobileMboDataBeanManager avgMgr = new MobileMboDataBeanManager("PLUSCWODSPOINT");
/* 62:79 */     MobileMboDataBean avgBean = avgMgr.getDataBean();
/* 63:80 */     avgBean.setParentBean(thisMobileMboAdapter.getDatabean());
/* 64:   */     
/* 65:82 */     avgBean.getQBE().reset();
/* 66:83 */     avgBean.getQBE().setQbeExactMatch(true);
/* 67:84 */     avgBean.getQBE().setQBE("DSPLANNUM", this.thisMbo.getString("DSPLANNUM"));
/* 68:85 */     avgBean.getQBE().setQBE("WODSNUM", this.thisMbo.getString("WODSNUM"));
/* 69:86 */     avgBean.getQBE().setQBE("SITEID", this.thisMbo.getString("SITEID"));
/* 70:87 */     avgBean.getQBE().setQBE("REVISIONNUM", this.thisMbo.getString("REVISIONNUM"));
/* 71:88 */     avgBean.getQBE().setQBE("WONUM", this.thisMbo.getString("WONUM"));
/* 72:89 */     avgBean.getQBE().setQBE("INSTRSEQ", this.thisMbo.getString("INSTRSEQ"));
/* 73:90 */     avgBean.getQBE().setQBE("POINT", this.thisMbo.getString("POINT"));
/* 74:91 */     avgBean.getQBE().setQBE("ISAVERAGE", "1");
/* 75:92 */     avgBean.reset();
/* 76:   */     
/* 77:94 */     avgBean.getMobileMbo().setOwner(((MobileMboAdapter)this.thisMbo).getMbo());
/* 78:   */     
/* 79:96 */     return new MobileMboSetAdapter(avgBean);
/* 80:   */   }
/* 81:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.pluscmobwo.PlusCMobileWODsPointDelegate
 * JD-Core Version:    0.7.0.1
 */