/*  1:   */ package com.mro.mobile.app.pluscmobwo;
/*  2:   */ 
/*  3:   */ import com.ibm.tivoli.maximo.util.mboadapter.MboAdapter;
/*  4:   */ import com.ibm.tivoli.maximo.util.mboadapter.MboSetAdapter;
/*  5:   */ import com.ibm.tivoli.maximo.util.mboadapter.mobile.MobileMboSetAdapter;
/*  6:   */ import com.mro.mobile.mbo.MobileMboQBE;
/*  7:   */ import com.mro.mobile.ui.MobileMboDataBean;
/*  8:   */ import com.mro.mobile.ui.MobileMboDataBeanManager;
/*  9:   */ import psdi.plusc.app.pluscwo.pluscmobilecommon.PlusCWOToolTransDelegate;
/* 10:   */ 
/* 11:   */ public class PlusCMobileWOToolTransDelegate
/* 12:   */   extends PlusCWOToolTransDelegate
/* 13:   */ {
/* 14:   */   public PlusCMobileWOToolTransDelegate(MboAdapter mbo)
/* 15:   */   {
/* 16:35 */     super(mbo);
/* 17:   */   }
/* 18:   */   
/* 19:   */   public MboSetAdapter getToolItemSet()
/* 20:   */     throws Exception
/* 21:   */   {
/* 22:40 */     MobileMboDataBeanManager instrmgr = new MobileMboDataBeanManager("TOOL");
/* 23:41 */     MobileMboDataBean instrBean = instrmgr.getDataBean();
/* 24:42 */     instrBean.getQBE().reset();
/* 25:43 */     instrBean.getQBE().setQbeExactMatch(true);
/* 26:44 */     instrBean.getQBE().setQBE("ITEMSETID", this.thisMbo.getString("ITEMSETID"));
/* 27:45 */     instrBean.getQBE().setQBE("ITEMNUM", this.thisMbo.getString("ITEMNUM"));
/* 28:46 */     instrBean.reset();
/* 29:47 */     return new MobileMboSetAdapter(instrBean);
/* 30:   */   }
/* 31:   */   
/* 32:   */   public MboSetAdapter getAssetSet()
/* 33:   */     throws Exception
/* 34:   */   {
/* 35:51 */     return this.thisMbo.getMboSet("WOTOOLTRANSASSET");
/* 36:   */   }
/* 37:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.pluscmobwo.PlusCMobileWOToolTransDelegate
 * JD-Core Version:    0.7.0.1
 */