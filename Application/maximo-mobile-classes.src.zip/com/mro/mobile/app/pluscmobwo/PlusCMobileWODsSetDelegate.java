/*  1:   */ package com.mro.mobile.app.pluscmobwo;
/*  2:   */ 
/*  3:   */ import com.ibm.tivoli.maximo.util.mboadapter.MboAdapter;
/*  4:   */ import com.ibm.tivoli.maximo.util.mboadapter.MboSetAdapter;
/*  5:   */ import psdi.plusc.app.pluscds.pluscmobilecommon.PlusCWODsDelegate;
/*  6:   */ import psdi.plusc.app.pluscds.pluscmobilecommon.PlusCWODsSetDelegate;
/*  7:   */ 
/*  8:   */ public class PlusCMobileWODsSetDelegate
/*  9:   */   extends PlusCWODsSetDelegate
/* 10:   */ {
/* 11:   */   public PlusCMobileWODsSetDelegate(MboSetAdapter thisMboSet)
/* 12:   */   {
/* 13:33 */     super(thisMboSet);
/* 14:   */   }
/* 15:   */   
/* 16:   */   protected PlusCWODsDelegate getWoDsDelegate(MboAdapter woDsMbo)
/* 17:   */   {
/* 18:37 */     return new PlusCMobileWODsDelegate(woDsMbo);
/* 19:   */   }
/* 20:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.pluscmobwo.PlusCMobileWODsSetDelegate
 * JD-Core Version:    0.7.0.1
 */