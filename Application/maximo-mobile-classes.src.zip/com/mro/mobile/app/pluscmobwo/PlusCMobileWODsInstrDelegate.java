/*   1:    */ package com.mro.mobile.app.pluscmobwo;
/*   2:    */ 
/*   3:    */ import com.ibm.tivoli.maximo.util.mboadapter.MboAdapter;
/*   4:    */ import com.ibm.tivoli.maximo.util.mboadapter.MboSetAdapter;
/*   5:    */ import com.ibm.tivoli.maximo.util.mboadapter.mobile.MobileMboAdapter;
/*   6:    */ import com.ibm.tivoli.maximo.util.mboadapter.mobile.MobileMboSetAdapter;
/*   7:    */ import com.mro.mobile.MobileApplicationException;
/*   8:    */ import com.mro.mobile.mbo.MobileMbo;
/*   9:    */ import com.mro.mobile.mbo.MobileMboQBE;
/*  10:    */ import com.mro.mobile.ui.DataBeanCache;
/*  11:    */ import com.mro.mobile.ui.MobileMboDataBean;
/*  12:    */ import com.mro.mobile.ui.MobileMboDataBeanManager;
/*  13:    */ import psdi.plusc.app.pluscds.pluscmobilecommon.PlusCWODsDelegate;
/*  14:    */ import psdi.plusc.app.pluscds.pluscmobilecommon.PlusCWODsInstrDelegate;
/*  15:    */ import psdi.plusc.app.pluscds.pluscmobilecommon.PlusCWODsPointDelegate;
/*  16:    */ 
/*  17:    */ public class PlusCMobileWODsInstrDelegate
/*  18:    */   extends PlusCWODsInstrDelegate
/*  19:    */ {
/*  20:    */   public PlusCMobileWODsInstrDelegate(MboAdapter mbo)
/*  21:    */   {
/*  22: 42 */     super(mbo);
/*  23:    */   }
/*  24:    */   
/*  25:    */   public MboSetAdapter getWODsPointSet(boolean fromMemory)
/*  26:    */     throws Exception
/*  27:    */   {
/*  28: 47 */     if (fromMemory) {
/*  29: 48 */       return getWODsPointSetFromMemory();
/*  30:    */     }
/*  31: 50 */     return getWODsPointSetFromDB();
/*  32:    */   }
/*  33:    */   
/*  34:    */   private MboSetAdapter getWODsPointSetFromMemory()
/*  35:    */     throws Exception
/*  36:    */   {
/*  37: 56 */     return new MobileMboSetAdapter(DataBeanCache.findDataBean("PLUSCWODSPOINT"));
/*  38:    */   }
/*  39:    */   
/*  40:    */   protected MboSetAdapter getWODsPointSetFromDB()
/*  41:    */     throws MobileApplicationException
/*  42:    */   {
/*  43: 61 */     MobileMbo referenceMbo = ((MobileMboAdapter)this.thisMbo).getMbo();
/*  44:    */     
/*  45: 63 */     MobileMboDataBeanManager pointmgr = new MobileMboDataBeanManager("PLUSCWODSPOINT");
/*  46: 64 */     MobileMboDataBean pointBean = pointmgr.getDataBean();
/*  47: 65 */     pointBean.getQBE().reset();
/*  48: 66 */     pointBean.getQBE().setQbeExactMatch(true);
/*  49: 67 */     pointBean.getQBE().setQBE("WONUM", referenceMbo.getValue("WONUM"));
/*  50: 68 */     pointBean.getQBE().setQBE("SITEID", referenceMbo.getValue("SITEID"));
/*  51: 69 */     pointBean.getQBE().setQBE("DSPLANNUM", referenceMbo.getValue("DSPLANNUM"));
/*  52: 70 */     pointBean.getQBE().setQBE("REVISIONNUM", referenceMbo.getValue("REVISIONNUM"));
/*  53: 71 */     pointBean.getQBE().setQBE("WODSNUM", referenceMbo.getValue("WODSNUM"));
/*  54: 72 */     pointBean.getQBE().setQBE("INSTRSEQ", referenceMbo.getValue("INSTRSEQ"));
/*  55: 73 */     pointBean.reset();
/*  56:    */     
/*  57: 75 */     return new MobileMboSetAdapter(pointBean);
/*  58:    */   }
/*  59:    */   
/*  60:    */   protected PlusCWODsPointDelegate getWoDsPointDelegate(MboAdapter pointMbo)
/*  61:    */     throws Exception
/*  62:    */   {
/*  63: 79 */     return new PlusCMobileWODsPointDelegate(pointMbo, this);
/*  64:    */   }
/*  65:    */   
/*  66:    */   protected PlusCWODsDelegate findParentDsDelegate()
/*  67:    */     throws Exception
/*  68:    */   {
/*  69: 84 */     MboSetAdapter parentDsSet = getParentDsSet();
/*  70: 85 */     return new PlusCMobileWODsDelegate(parentDsSet.getMbo());
/*  71:    */   }
/*  72:    */   
/*  73:    */   public MboSetAdapter getParentDsSet()
/*  74:    */     throws MobileApplicationException
/*  75:    */   {
/*  76: 91 */     MobileMbo referenceMbo = ((MobileMboAdapter)this.thisMbo).getMbo();
/*  77:    */     
/*  78: 93 */     MobileMboDataBeanManager dsmgr = new MobileMboDataBeanManager("PLUSCWODS");
/*  79: 94 */     MobileMboDataBean dsBean = dsmgr.getDataBean();
/*  80: 95 */     dsBean.getQBE().reset();
/*  81: 96 */     dsBean.getQBE().setQbeExactMatch(true);
/*  82: 97 */     dsBean.getQBE().setQBE("DSPLANNUM", referenceMbo.getValue("DSPLANNUM"));
/*  83: 98 */     dsBean.getQBE().setQBE("WODSNUM", referenceMbo.getValue("WODSNUM"));
/*  84: 99 */     dsBean.getQBE().setQBE("SITEID", referenceMbo.getValue("SITEID"));
/*  85:100 */     dsBean.getQBE().setQBE("REVISIONNUM", referenceMbo.getValue("REVISIONNUM"));
/*  86:101 */     dsBean.getQBE().setQBE("WONUM", referenceMbo.getValue("WONUM"));
/*  87:102 */     dsBean.reset();
/*  88:    */     
/*  89:104 */     return new MobileMboSetAdapter(dsBean);
/*  90:    */   }
/*  91:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.pluscmobwo.PlusCMobileWODsInstrDelegate
 * JD-Core Version:    0.7.0.1
 */