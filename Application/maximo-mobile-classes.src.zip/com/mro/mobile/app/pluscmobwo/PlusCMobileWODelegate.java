/*  1:   */ package com.mro.mobile.app.pluscmobwo;
/*  2:   */ 
/*  3:   */ import com.ibm.tivoli.maximo.util.mboadapter.MboAdapter;
/*  4:   */ import com.ibm.tivoli.maximo.util.mboadapter.MboSetAdapter;
/*  5:   */ import com.ibm.tivoli.maximo.util.mboadapter.mobile.MobileMboAdapter;
/*  6:   */ import psdi.plusc.app.pluscds.pluscmobilecommon.PlusCWODsDelegate;
/*  7:   */ import psdi.plusc.app.pluscwo.pluscmobilecommon.PlusCWODelegate;
/*  8:   */ 
/*  9:   */ public class PlusCMobileWODelegate
/* 10:   */   extends PlusCWODelegate
/* 11:   */ {
/* 12:   */   public PlusCMobileWODelegate(MobileMboAdapter mboAdapter)
/* 13:   */   {
/* 14:34 */     super(mboAdapter);
/* 15:   */   }
/* 16:   */   
/* 17:   */   protected MboSetAdapter getWOLocationSet()
/* 18:   */     throws Exception
/* 19:   */   {
/* 20:38 */     MboSetAdapter woLocSet = this.thisMbo.getMboSet("WOLOC");
/* 21:39 */     woLocSet.reset();
/* 22:40 */     return woLocSet;
/* 23:   */   }
/* 24:   */   
/* 25:   */   protected MboSetAdapter getWODsSet()
/* 26:   */     throws Exception
/* 27:   */   {
/* 28:44 */     return this.thisMbo.getMboSet("PLUSCWODS");
/* 29:   */   }
/* 30:   */   
/* 31:   */   public MboSetAdapter getWOToolTransSet()
/* 32:   */     throws Exception
/* 33:   */   {
/* 34:49 */     return this.thisMbo.getMboSet("WOTOOLTRANS");
/* 35:   */   }
/* 36:   */   
/* 37:   */   protected PlusCWODsDelegate getWoDsDelegate(MboAdapter wodsMbo)
/* 38:   */   {
/* 39:53 */     return new PlusCMobileWODsDelegate(wodsMbo);
/* 40:   */   }
/* 41:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.pluscmobwo.PlusCMobileWODelegate
 * JD-Core Version:    0.7.0.1
 */