/*   1:    */ package com.mro.mobile.app.pluscmobwo;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.mbo.MobileMbo;
/*   4:    */ import java.lang.reflect.InvocationTargetException;
/*   5:    */ import java.lang.reflect.Method;
/*   6:    */ import java.util.Enumeration;
/*   7:    */ import java.util.HashSet;
/*   8:    */ import java.util.Iterator;
/*   9:    */ import java.util.Set;
/*  10:    */ import psdi.plusc.app.pluscds.pluscmobilecommon.PlusCMboRemote;
/*  11:    */ import psdi.plusc.app.pluscds.pluscmobilecommon.PlusCToolKitTOCommon;
/*  12:    */ 
/*  13:    */ public final class PlusCToolKitTOMobile
/*  14:    */ {
/*  15: 38 */   public static int MAXFRACTION = 10;
/*  16:    */   
/*  17:    */   public static PlusCMboRemote createTO(MobileMbo mboSource, Class objectType)
/*  18:    */     throws Exception
/*  19:    */   {
/*  20:    */     try
/*  21:    */     {
/*  22: 51 */       Object objectTO = objectType.newInstance();
/*  23: 52 */       Method[] methods = objectTO.getClass().getMethods();
/*  24: 53 */       Set mboAvailableAttributes = new HashSet();
/*  25: 54 */       Enumeration enum_ = mboSource.getAttributeNames();
/*  26: 56 */       while (enum_.hasMoreElements()) {
/*  27: 57 */         mboAvailableAttributes.add(enum_.nextElement().toString());
/*  28:    */       }
/*  29: 60 */       for (int i = 0; i < methods.length; i++) {
/*  30: 61 */         if (isSetMethod(methods[i]))
/*  31:    */         {
/*  32: 62 */           String attribute = getAttributeName(methods[i]);
/*  33: 63 */           if (mboAvailableAttributes.contains(attribute)) {
/*  34: 64 */             methods[i].invoke(objectTO, getValues(mboSource, attribute, methods[i].getParameterTypes()[0]));
/*  35:    */           }
/*  36:    */         }
/*  37:    */       }
/*  38: 69 */       PlusCMboRemote plusCMboRemote = (PlusCMboRemote)objectTO;
/*  39:    */       
/*  40:    */ 
/*  41: 72 */       createNonPersistentFields(plusCMboRemote);
/*  42: 73 */       return plusCMboRemote;
/*  43:    */     }
/*  44:    */     catch (Exception e)
/*  45:    */     {
/*  46: 75 */       throw e;
/*  47:    */     }
/*  48:    */   }
/*  49:    */   
/*  50:    */   private static void createNonPersistentFields(PlusCMboRemote plusCMboRemote)
/*  51:    */   {
/*  52: 88 */     for (Iterator iter = plusCMboRemote.getNonPersistentFieldsName().iterator(); iter.hasNext();)
/*  53:    */     {
/*  54: 89 */       String nonPersistentName = (String)iter.next();
/*  55: 90 */       int endName = nonPersistentName.lastIndexOf("_NP");
/*  56: 91 */       if (endName >= 0)
/*  57:    */       {
/*  58: 94 */         String originalName = nonPersistentName.substring(0, endName);
/*  59: 95 */         plusCMboRemote.setValue(nonPersistentName, plusCMboRemote.getObject(originalName), false);
/*  60:    */       }
/*  61:    */     }
/*  62:    */   }
/*  63:    */   
/*  64:    */   private static boolean isSetMethod(Method method)
/*  65:    */   {
/*  66:104 */     return method.getName().indexOf("set") == 0;
/*  67:    */   }
/*  68:    */   
/*  69:    */   private static String getAttributeName(Method method)
/*  70:    */   {
/*  71:112 */     return method.getName().substring(3);
/*  72:    */   }
/*  73:    */   
/*  74:    */   private static Object[] getValues(MobileMbo mboSource, String attributeName, Class attributeClazz)
/*  75:    */     throws IllegalArgumentException, SecurityException, IllegalAccessException, InvocationTargetException, NoSuchMethodException
/*  76:    */   {
/*  77:132 */     Object[] value = new Object[1];
/*  78:133 */     String methodName = getMboMethodName(attributeClazz);
/*  79:134 */     value[0] = mboSource.getClass().getMethod(methodName, new Class[] { String.class }).invoke(mboSource, new Object[] { attributeName });
/*  80:137 */     if (((value[0] != null) && (value[0].getClass().equals(Long.TYPE))) || (value[0].getClass().equals(Long.class))) {
/*  81:138 */       value[0] = new Integer(Integer.parseInt(value[0].toString()));
/*  82:    */     }
/*  83:140 */     return value;
/*  84:    */   }
/*  85:    */   
/*  86:    */   private static String getMboMethodName(Class attributeClazz)
/*  87:    */   {
/*  88:148 */     String tempName = attributeClazz.getName();
/*  89:149 */     int index = tempName.lastIndexOf(".") + 1;
/*  90:    */     
/*  91:151 */     String name = null;
/*  92:152 */     if (tempName.indexOf("String") == -1) {
/*  93:153 */       name = "get" + tempName.substring(index) + "Value";
/*  94:    */     } else {
/*  95:156 */       name = "getValue";
/*  96:    */     }
/*  97:162 */     if (name.indexOf("getIntegerValue") != -1) {
/*  98:163 */       name = "getLongValue";
/*  99:    */     }
/* 100:165 */     return name;
/* 101:    */   }
/* 102:    */   
/* 103:    */   private static void executeMobileMboSetMethod(MobileMbo target, String methodName, Object[] params)
/* 104:    */     throws Exception
/* 105:    */   {
/* 106:177 */     Class[] classes = new Class[params.length];
/* 107:178 */     for (int i = 0; i < classes.length; i++) {
/* 108:179 */       if (params[i].getClass().equals(Long.class)) {
/* 109:180 */         classes[i] = Long.TYPE;
/* 110:183 */       } else if (params[i].getClass().equals(Integer.class)) {
/* 111:184 */         classes[i] = Long.TYPE;
/* 112:186 */       } else if (params[i].getClass().equals(Boolean.class)) {
/* 113:187 */         classes[i] = Boolean.TYPE;
/* 114:    */       } else {
/* 115:190 */         classes[i] = params[i].getClass();
/* 116:    */       }
/* 117:    */     }
/* 118:193 */     target.getClass().getMethod(methodName, classes).invoke(target, params);
/* 119:    */   }
/* 120:    */   
/* 121:    */   public static void setMboValues(MobileMbo target, PlusCMboRemote source, boolean accessCheck)
/* 122:    */     throws Exception
/* 123:    */   {
/* 124:205 */     for (Iterator changedAttributes = source.getChangedFields().iterator(); changedAttributes.hasNext();)
/* 125:    */     {
/* 126:206 */       String attribute = (String)changedAttributes.next();
/* 127:207 */       if (!skipAttribute(attribute))
/* 128:    */       {
/* 129:210 */         Object object = getMethodResult(source, getPlusCMboRemoteMethodName(attribute));
/* 130:211 */         Object[] params = { attribute, object, new Boolean(accessCheck) };
/* 131:212 */         String setMethod = getMobileMboSetMethodName(object.getClass());
/* 132:213 */         executeMobileMboSetMethod(target, setMethod, params);
/* 133:    */       }
/* 134:    */     }
/* 135:    */   }
/* 136:    */   
/* 137:    */   private static String getPlusCMboRemoteMethodName(String attribute)
/* 138:    */   {
/* 139:223 */     return "get" + attribute.substring(0, 1).toUpperCase() + attribute.substring(1);
/* 140:    */   }
/* 141:    */   
/* 142:    */   private static Object getMethodResult(PlusCMboRemote source, String methodName)
/* 143:    */     throws Exception
/* 144:    */   {
/* 145:234 */     return source.getClass().getMethod(methodName, new Class[0]).invoke(source, new Object[0]);
/* 146:    */   }
/* 147:    */   
/* 148:    */   private static String getMobileMboSetMethodName(Class attributeClazz)
/* 149:    */   {
/* 150:243 */     String name = attributeClazz.getName();
/* 151:244 */     int lastPoint = name.lastIndexOf(".");
/* 152:    */     
/* 153:246 */     name = name.substring(lastPoint + 1);
/* 154:247 */     name = PlusCToolKitTOCommon.replace(name, "String", "");
/* 155:    */     
/* 156:249 */     String returnString = "set" + PlusCToolKitTOCommon.replace(name, "Integer", "Long") + "Value";
/* 157:    */     
/* 158:251 */     return returnString;
/* 159:    */   }
/* 160:    */   
/* 161:    */   private static boolean skipAttribute(String attribute)
/* 162:    */   {
/* 163:259 */     return attribute.indexOf("_NP") >= 0;
/* 164:    */   }
/* 165:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.pluscmobwo.PlusCToolKitTOMobile
 * JD-Core Version:    0.7.0.1
 */