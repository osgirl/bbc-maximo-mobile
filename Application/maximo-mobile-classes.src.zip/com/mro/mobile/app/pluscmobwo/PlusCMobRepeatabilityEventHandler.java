/*   1:    */ package com.mro.mobile.app.pluscmobwo;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.MobileMessageGenerator;
/*   5:    */ import com.mro.mobile.app.AppEventHandler;
/*   6:    */ import com.mro.mobile.app.BasicMobileDeviceUIApplication;
/*   7:    */ import com.mro.mobile.mbo.MobileMbo;
/*   8:    */ import com.mro.mobile.mbo.MobileMboQBE;
/*   9:    */ import com.mro.mobile.persist.QBE;
/*  10:    */ import com.mro.mobile.ui.DataBeanCache;
/*  11:    */ import com.mro.mobile.ui.MobileMboDataBean;
/*  12:    */ import com.mro.mobile.ui.event.UIEvent;
/*  13:    */ import com.mro.mobile.ui.res.ControlData;
/*  14:    */ import com.mro.mobile.ui.res.UIUtil;
/*  15:    */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*  16:    */ import com.mro.mobile.ui.res.controls.LabelControl;
/*  17:    */ import com.mro.mobile.ui.res.controls.PageControl;
/*  18:    */ import java.util.Enumeration;
/*  19:    */ 
/*  20:    */ public class PlusCMobRepeatabilityEventHandler
/*  21:    */   extends AppEventHandler
/*  22:    */ {
/*  23:    */   public static final String AVERAGES_BEAN_NAME = "PLUSCWODSPOINTAVERAGE";
/*  24:    */   public static final String AVERAGES_MBO_NAME = "PLUSCWODSPOINT";
/*  25:    */   
/*  26:    */   public boolean performEvent(UIEvent event)
/*  27:    */     throws MobileApplicationException
/*  28:    */   {
/*  29: 49 */     if (event == null) {
/*  30: 50 */       return false;
/*  31:    */     }
/*  32: 52 */     String eventId = event.getEventName();
/*  33: 54 */     if (eventId.equalsIgnoreCase("initAveragesPage")) {
/*  34: 55 */       return initAveragesPage(event);
/*  35:    */     }
/*  36: 56 */     if (eventId.equalsIgnoreCase("pluscGotoAsFoundAveragesPage")) {
/*  37: 57 */       return pluscGotoAsFoundAveragesPage(event);
/*  38:    */     }
/*  39: 58 */     if (eventId.equalsIgnoreCase("pluscGotoAsLeftAveragesPage")) {
/*  40: 59 */       return pluscGotoAsLeftAveragesPage(event);
/*  41:    */     }
/*  42: 60 */     if (eventId.equalsIgnoreCase("initAverageDataBean")) {
/*  43: 61 */       return initAverageDataBean(event);
/*  44:    */     }
/*  45: 62 */     if (eventId.equalsIgnoreCase("updateToolbarPositionLabel")) {
/*  46: 63 */       return updateToolbarPositionLabel(event);
/*  47:    */     }
/*  48: 64 */     if (eventId.equalsIgnoreCase("pluscnextrec")) {
/*  49: 65 */       return pluscnextrec(event);
/*  50:    */     }
/*  51: 67 */     return false;
/*  52:    */   }
/*  53:    */   
/*  54:    */   public MobileMboDataBean getAveragesBean()
/*  55:    */     throws MobileApplicationException
/*  56:    */   {
/*  57: 81 */     return DataBeanCache.getDataBean("PLUSCWODSPOINTAVERAGE", "PLUSCWODSPOINT");
/*  58:    */   }
/*  59:    */   
/*  60:    */   public boolean pluscGotoAsFoundAveragesPage(UIEvent event)
/*  61:    */     throws MobileApplicationException
/*  62:    */   {
/*  63: 93 */     initAverageDataBean(event);
/*  64: 94 */     UIUtil.gotoPage("pluscAvgAsfoundvaluespage", (AbstractMobileControl)event.getSource());
/*  65: 95 */     return true;
/*  66:    */   }
/*  67:    */   
/*  68:    */   public boolean pluscGotoAsLeftAveragesPage(UIEvent event)
/*  69:    */     throws MobileApplicationException
/*  70:    */   {
/*  71:107 */     initAverageDataBean(event);
/*  72:108 */     UIUtil.gotoPage("pluscAvgAsleftvaluespage", (AbstractMobileControl)event.getSource());
/*  73:109 */     return true;
/*  74:    */   }
/*  75:    */   
/*  76:    */   private boolean initAveragesPage(UIEvent event)
/*  77:    */     throws MobileApplicationException
/*  78:    */   {
/*  79:118 */     updateToolbarPositionLabel(event);
/*  80:    */     
/*  81:120 */     return true;
/*  82:    */   }
/*  83:    */   
/*  84:    */   private boolean initAverageDataBean(UIEvent event)
/*  85:    */     throws MobileApplicationException
/*  86:    */   {
/*  87:129 */     MobileMboDataBean avgPointsDataBean = getAveragesBean();
/*  88:130 */     MobileMboDataBean pointsDataBean = DataBeanCache.getDataBean("PLUSCWODSPOINT", "PLUSCWODSPOINT");
/*  89:    */     
/*  90:132 */     copyFilterFromCachedPointBean(avgPointsDataBean, pointsDataBean);
/*  91:133 */     avgPointsDataBean.getQBE().setQBE("ISAVERAGE", "1");
/*  92:134 */     avgPointsDataBean.getQBE().setQBE("WONUM", pointsDataBean.getMobileMbo().getValue("WONUM"));
/*  93:135 */     avgPointsDataBean.getQBE().setQBE("WODSNUM", pointsDataBean.getMobileMbo().getValue("WODSNUM"));
/*  94:136 */     setAvgDatabeanPosition(avgPointsDataBean, pointsDataBean);
/*  95:    */     
/*  96:138 */     return true;
/*  97:    */   }
/*  98:    */   
/*  99:    */   private void copyFilterFromCachedPointBean(MobileMboDataBean avgPointsDataBean, MobileMboDataBean pointsDataBean)
/* 100:    */     throws MobileApplicationException
/* 101:    */   {
/* 102:149 */     avgPointsDataBean.getQBE().reset();
/* 103:150 */     avgPointsDataBean.getQBE().setQbeExactMatch(true);
/* 104:    */     
/* 105:152 */     QBE pointsQBE = pointsDataBean.getQBE();
/* 106:153 */     Enumeration attribs = pointsQBE.getQBEAttributes();
/* 107:154 */     while (attribs.hasMoreElements())
/* 108:    */     {
/* 109:155 */       String key = (String)attribs.nextElement();
/* 110:156 */       avgPointsDataBean.getQBE().setQBE(key, pointsQBE.getQBE(key));
/* 111:    */     }
/* 112:    */   }
/* 113:    */   
/* 114:    */   private void setAvgDatabeanPosition(MobileMboDataBean avgPointsDataBean, MobileMboDataBean pointsDataBean)
/* 115:    */     throws MobileApplicationException
/* 116:    */   {
/* 117:168 */     String[] matchAttributes = { "WONUM", "DSPLANNUM", "REVISIONNUM", "WODSNUM", "SITEID", "INSTRSEQ", "POINT" };
/* 118:    */     
/* 119:    */ 
/* 120:171 */     MobileMbo currentPoint = pointsDataBean.getMobileMbo();
/* 121:    */     
/* 122:173 */     avgPointsDataBean.reset();
/* 123:    */     MobileMbo avgMbo;
/* 124:174 */     for (int i = 0; (avgMbo = avgPointsDataBean.getMobileMbo(i)) != null; i++) {
/* 125:175 */       if (PlusCMobUtil.mboEquals(avgMbo, currentPoint, matchAttributes))
/* 126:    */       {
/* 127:176 */         avgPointsDataBean.setCurrentPosition(i);
/* 128:177 */         break;
/* 129:    */       }
/* 130:    */     }
/* 131:    */   }
/* 132:    */   
/* 133:    */   private boolean updateToolbarPositionLabel(UIEvent event)
/* 134:    */     throws MobileApplicationException
/* 135:    */   {
/* 136:188 */     MobileMboDataBean databean = getAveragesBean();
/* 137:190 */     if (databean.getCurrentPosition() < 0) {
/* 138:191 */       databean.setCurrentPosition(0);
/* 139:    */     }
/* 140:201 */     String[] params = { Integer.toString(databean.getCurrentPosition() + 1), Integer.toString(databean.count()) };
/* 141:202 */     String label = MobileMessageGenerator.generate("pluscwt_PageNumber", params);
/* 142:203 */     PageControl pageControl = (PageControl)UIUtil.getCurrentScreen();
/* 143:204 */     AbstractMobileControl toolBar = pageControl.getToolBar();
/* 144:205 */     AbstractMobileControl ctrl = PlusCMobUtil.getControlByPath(toolBar, "pluscafpgtabletbar_left/pluscdialogbar_label1");
/* 145:206 */     ctrl.getControlData().putValue("label", label);
/* 146:207 */     if ((ctrl instanceof LabelControl)) {
/* 147:208 */       ((LabelControl)ctrl).setTextValueOnWidget(label);
/* 148:    */     }
/* 149:211 */     return true;
/* 150:    */   }
/* 151:    */   
/* 152:    */   public boolean pluscnextrec(UIEvent event)
/* 153:    */     throws MobileApplicationException
/* 154:    */   {
/* 155:216 */     PageControl thisPage = (PageControl)UIUtil.getCurrentScreen();
/* 156:    */     
/* 157:218 */     String pageId = thisPage.getControlData().getValue("id");
/* 158:219 */     String asLeftValuesPageId = "pluscAvgAsleftvaluespage";
/* 159:    */     
/* 160:221 */     MobileMboDataBean dataBean = getAveragesBean();
/* 161:    */     
/* 162:    */ 
/* 163:224 */     MobileMbo thisMobileMbo = dataBean.getMobileMbo();
/* 164:225 */     UIUtil.getApplication().updateMobileMbo("PLUSCWODSPOINT", thisMobileMbo);
/* 165:    */     
/* 166:227 */     int nextPosition = dataBean.getCurrentPosition() + 1;
/* 167:229 */     if ((nextPosition >= 0) && (nextPosition >= dataBean.count()))
/* 168:    */     {
/* 169:231 */       if (pageId.equalsIgnoreCase("pluscAvgAsleftvaluespage"))
/* 170:    */       {
/* 171:234 */         UIUtil.getApplication().removeCurrentScreen(true);
/* 172:    */       }
/* 173:    */       else
/* 174:    */       {
/* 175:239 */         UIUtil.refreshCurrentScreen();
/* 176:240 */         UIUtil.getApplication().removeCurrentScreen(true);
/* 177:241 */         UIUtil.gotoPage("pluscAvgAsleftvaluespage", thisPage);
/* 178:    */         
/* 179:243 */         thisPage = (PageControl)UIUtil.getCurrentScreen();
/* 180:244 */         dataBean = getAveragesBean();
/* 181:245 */         dataBean.setCurrentPosition(0);
/* 182:    */       }
/* 183:248 */       UIUtil.refreshCurrentScreen();
/* 184:    */       
/* 185:250 */       return true;
/* 186:    */     }
/* 187:255 */     return thisPage.nextrec(event);
/* 188:    */   }
/* 189:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.pluscmobwo.PlusCMobRepeatabilityEventHandler
 * JD-Core Version:    0.7.0.1
 */