/*   1:    */ package com.mro.mobile.app.pluscmobwo;
/*   2:    */ 
/*   3:    */ import com.ibm.tivoli.maximo.util.mboadapter.MboAdapter;
/*   4:    */ import com.ibm.tivoli.maximo.util.mboadapter.mobile.MobileMboAdapter;
/*   5:    */ import com.mro.mobile.MobileApplicationException;
/*   6:    */ import com.mro.mobile.app.BasicMobileDeviceUIApplication;
/*   7:    */ import com.mro.mobile.mbo.MobileMbo;
/*   8:    */ import com.mro.mobile.persist.RDO;
/*   9:    */ import com.mro.mobile.ui.res.ControlData;
/*  10:    */ import com.mro.mobile.ui.res.UIUtil;
/*  11:    */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*  12:    */ import java.io.ByteArrayInputStream;
/*  13:    */ import java.io.ByteArrayOutputStream;
/*  14:    */ import java.io.DataInputStream;
/*  15:    */ import java.io.DataOutputStream;
/*  16:    */ import java.io.IOException;
/*  17:    */ import java.lang.reflect.Field;
/*  18:    */ import java.util.HashSet;
/*  19:    */ import java.util.Iterator;
/*  20:    */ import java.util.Set;
/*  21:    */ import java.util.Vector;
/*  22:    */ 
/*  23:    */ public class PlusCMobUtil
/*  24:    */ {
/*  25:    */   public static boolean mboEquals(MobileMbo oneMbo, MobileMbo anotherMbo, String[] matchAttributes)
/*  26:    */     throws MobileApplicationException
/*  27:    */   {
/*  28: 57 */     for (int i = 0; i < matchAttributes.length; i++)
/*  29:    */     {
/*  30: 58 */       String attr = matchAttributes[i];
/*  31: 59 */       String oneValue = oneMbo.getValue(attr);
/*  32: 60 */       String anotherValue = anotherMbo.getValue(attr);
/*  33: 61 */       if (((oneValue == null) && (anotherValue != null)) || ((oneValue != null) && (!oneValue.equals(anotherValue)))) {
/*  34: 63 */         return false;
/*  35:    */       }
/*  36:    */     }
/*  37: 67 */     return true;
/*  38:    */   }
/*  39:    */   
/*  40:    */   public static AbstractMobileControl getControlByPath(AbstractMobileControl rootControl, String controlPath)
/*  41:    */   {
/*  42: 99 */     if ((controlPath == null) || (controlPath.equals("")) || (controlPath.equals("/"))) {
/*  43:100 */       return rootControl;
/*  44:    */     }
/*  45:103 */     int idx = controlPath.indexOf('/');
/*  46:    */     String newControlPath;
/*  47:    */     String id;
/*  48:    */     String newControlPath;
/*  49:106 */     if (idx > 0)
/*  50:    */     {
/*  51:107 */       String id = controlPath.substring(0, idx);
/*  52:108 */       newControlPath = controlPath.substring(idx + 1);
/*  53:    */     }
/*  54:    */     else
/*  55:    */     {
/*  56:110 */       id = controlPath;
/*  57:111 */       newControlPath = null;
/*  58:    */     }
/*  59:114 */     Iterator iterator = rootControl.getChildren();
/*  60:115 */     if (iterator != null) {
/*  61:116 */       while (iterator.hasNext())
/*  62:    */       {
/*  63:117 */         AbstractMobileControl child = (AbstractMobileControl)iterator.next();
/*  64:118 */         if (child.getId().equalsIgnoreCase(id)) {
/*  65:119 */           return getControlByPath(child, newControlPath);
/*  66:    */         }
/*  67:    */       }
/*  68:    */     }
/*  69:123 */     return null;
/*  70:    */   }
/*  71:    */   
/*  72:    */   public static AbstractMobileControl getControlByAttribute(AbstractMobileControl rootControl, String attributeName)
/*  73:    */   {
/*  74:155 */     String curAttr = rootControl.getControlData().getValue("dataattribute");
/*  75:157 */     if (attributeName.equalsIgnoreCase(curAttr)) {
/*  76:158 */       return rootControl;
/*  77:    */     }
/*  78:161 */     Iterator iterator = rootControl.getChildren();
/*  79:162 */     if (iterator != null) {
/*  80:163 */       while (iterator.hasNext())
/*  81:    */       {
/*  82:164 */         AbstractMobileControl child = (AbstractMobileControl)iterator.next();
/*  83:165 */         AbstractMobileControl childResult = getControlByAttribute(child, attributeName);
/*  84:166 */         if (childResult != null) {
/*  85:167 */           return childResult;
/*  86:    */         }
/*  87:    */       }
/*  88:    */     }
/*  89:171 */     return null;
/*  90:    */   }
/*  91:    */   
/*  92:    */   public static MobileMbo[] mboAdapterToMobileMboArray(MboAdapter[] mboAdapterArray)
/*  93:    */   {
/*  94:175 */     MobileMbo[] retval = new MobileMbo[mboAdapterArray.length];
/*  95:176 */     for (int i = 0; i < mboAdapterArray.length; i++) {
/*  96:177 */       retval[i] = ((MobileMboAdapter)mboAdapterArray[i]).getMbo();
/*  97:    */     }
/*  98:179 */     return retval;
/*  99:    */   }
/* 100:    */   
/* 101:    */   public static void setMobileMboAttrInfoFieldsReadOnly(MobileMbo mbo, String[] names, boolean state, boolean forceMboReset)
/* 102:    */     throws MobileApplicationException
/* 103:    */   {
/* 104:187 */     RDO rdo = mbo.getRDO();
/* 105:188 */     byte[] readOnlyAttrData = rdo.getBinaryValue("_READONLYATTRS");
/* 106:189 */     if ((readOnlyAttrData != null) && (readOnlyAttrData.length > 0))
/* 107:    */     {
/* 108:190 */       ByteArrayInputStream bis = new ByteArrayInputStream(readOnlyAttrData);
/* 109:191 */       DataInputStream dis = new DataInputStream(bis);
/* 110:    */       
/* 111:193 */       Vector readOnlyAttributes = new Vector();
/* 112:    */       
/* 113:195 */       Set set = new HashSet();
/* 114:196 */       for (int i = 0; i < names.length; i++) {
/* 115:197 */         set.add(names[i]);
/* 116:    */       }
/* 117:    */       try
/* 118:    */       {
/* 119:204 */         int noOfReadOnlyAttributes = dis.readInt();
/* 120:205 */         for (int i = 0; i < noOfReadOnlyAttributes; i++)
/* 121:    */         {
/* 122:207 */           String readOnlyAttributeName = dis.readUTF();
/* 123:208 */           if (!state)
/* 124:    */           {
/* 125:209 */             if (!set.contains(readOnlyAttributeName)) {
/* 126:210 */               readOnlyAttributes.addElement(readOnlyAttributeName);
/* 127:    */             }
/* 128:    */           }
/* 129:    */           else
/* 130:    */           {
/* 131:213 */             set.remove(readOnlyAttributeName);
/* 132:214 */             readOnlyAttributes.addElement(readOnlyAttributeName);
/* 133:    */           }
/* 134:    */         }
/* 135:218 */         if (state)
/* 136:    */         {
/* 137:219 */           Iterator setIterator = set.iterator();
/* 138:220 */           while (setIterator.hasNext()) {
/* 139:221 */             readOnlyAttributes.add((String)setIterator.next());
/* 140:    */           }
/* 141:    */         }
/* 142:    */       }
/* 143:    */       catch (IOException e)
/* 144:    */       {
/* 145:227 */         throw new MobileApplicationException("operationfailed", e);
/* 146:    */       }
/* 147:231 */       ByteArrayOutputStream bos = new ByteArrayOutputStream();
/* 148:232 */       DataOutputStream dos = new DataOutputStream(bos);
/* 149:    */       try
/* 150:    */       {
/* 151:235 */         dos.write(readOnlyAttributes.size());
/* 152:236 */         Iterator it = readOnlyAttributes.iterator();
/* 153:237 */         while (it.hasNext()) {
/* 154:238 */           dos.writeUTF((String)it.next());
/* 155:    */         }
/* 156:    */       }
/* 157:    */       catch (IOException e)
/* 158:    */       {
/* 159:241 */         throw new MobileApplicationException("operationfailed", e);
/* 160:    */       }
/* 161:245 */       rdo.setBinaryValue("_READONLYATTRS", bos.toByteArray());
/* 162:246 */       UIUtil.getApplication().updateMobileMbo(mbo.getName(), mbo);
/* 163:249 */       if (forceMboReset) {
/* 164:    */         try
/* 165:    */         {
/* 166:252 */           Field field = MobileMbo.class.getDeclaredField("readOnlyAttributes");
/* 167:253 */           field.setAccessible(true);
/* 168:254 */           field.set(mbo, null);
/* 169:255 */           field.setAccessible(false);
/* 170:    */         }
/* 171:    */         catch (Exception e)
/* 172:    */         {
/* 173:257 */           throw new MobileApplicationException("operationfailed", e);
/* 174:    */         }
/* 175:    */       }
/* 176:    */     }
/* 177:    */   }
/* 178:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.pluscmobwo.PlusCMobUtil
 * JD-Core Version:    0.7.0.1
 */