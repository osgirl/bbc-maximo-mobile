/*  1:   */ package com.mro.mobile.app.pluscmobwo;
/*  2:   */ 
/*  3:   */ import com.ibm.tivoli.maximo.util.mboadapter.MboAdapter;
/*  4:   */ import com.ibm.tivoli.maximo.util.mboadapter.MboSetAdapter;
/*  5:   */ import com.ibm.tivoli.maximo.util.mboadapter.mobile.MobileMboAdapter;
/*  6:   */ import com.mro.mobile.MobileApplicationException;
/*  7:   */ import com.mro.mobile.mbo.MobileMbo;
/*  8:   */ import com.mro.mobile.ui.MobileMboDataBean;
/*  9:   */ import com.mro.mobile.ui.res.UIUtil;
/* 10:   */ import com.mro.mobileapp.WOApp;
/* 11:   */ import psdi.plusc.app.pluscds.pluscmobilecommon.PlusCWODsDelegate;
/* 12:   */ import psdi.plusc.app.pluscds.pluscmobilecommon.PlusCWODsInstrDelegate;
/* 13:   */ 
/* 14:   */ public class PlusCMobileWODsDelegate
/* 15:   */   extends PlusCWODsDelegate
/* 16:   */ {
/* 17:   */   public PlusCMobileWODsDelegate(MboAdapter mbo)
/* 18:   */   {
/* 19:39 */     super(mbo);
/* 20:   */   }
/* 21:   */   
/* 22:   */   protected MboSetAdapter getWODsInstrSet()
/* 23:   */     throws Exception
/* 24:   */   {
/* 25:43 */     return this.thisMbo.getMboSet("PLUSCWODSINSTR");
/* 26:   */   }
/* 27:   */   
/* 28:   */   protected MboSetAdapter getWODsLocationSet()
/* 29:   */     throws Exception
/* 30:   */   {
/* 31:47 */     return this.thisMbo.getMboSet("PLUSCWODSLOCATION");
/* 32:   */   }
/* 33:   */   
/* 34:   */   protected String getTranslatedAsLeftStatus()
/* 35:   */     throws MobileApplicationException
/* 36:   */   {
/* 37:51 */     return getTranslatedStatus("ASLEFTCALSTATUS");
/* 38:   */   }
/* 39:   */   
/* 40:   */   protected String getTranslatedAsFoundStatus()
/* 41:   */     throws MobileApplicationException
/* 42:   */   {
/* 43:55 */     return getTranslatedStatus("ASFOUNDCALSTATUS");
/* 44:   */   }
/* 45:   */   
/* 46:   */   public String getTranslatedStatus(String fieldName)
/* 47:   */     throws MobileApplicationException
/* 48:   */   {
/* 49:66 */     MobileMboAdapter thisMobileMbo = (MobileMboAdapter)this.thisMbo;
/* 50:67 */     MobileMboDataBean databean = thisMobileMbo.getDatabean();
/* 51:68 */     MobileMbo instrMbo = thisMobileMbo.getMbo();
/* 52:   */     
/* 53:   */ 
/* 54:   */ 
/* 55:   */ 
/* 56:   */ 
/* 57:   */ 
/* 58:75 */     String calStatus = instrMbo.getValue(fieldName);
/* 59:77 */     if (!calStatus.equalsIgnoreCase("")) {
/* 60:78 */       calStatus = ((WOApp)UIUtil.getApplication()).getInternalValue(databean, "PLUSCCALSTATUS", calStatus);
/* 61:   */     }
/* 62:82 */     return calStatus;
/* 63:   */   }
/* 64:   */   
/* 65:   */   protected PlusCWODsInstrDelegate getWoDsInstrDelegate(MboAdapter instrMbo)
/* 66:   */   {
/* 67:86 */     return new PlusCMobileWODsInstrDelegate(instrMbo);
/* 68:   */   }
/* 69:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.pluscmobwo.PlusCMobileWODsDelegate
 * JD-Core Version:    0.7.0.1
 */