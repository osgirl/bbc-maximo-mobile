/*  1:   */ package com.mro.mobile.app;
/*  2:   */ 
/*  3:   */ import com.mro.mobile.MobileApplicationException;
/*  4:   */ import com.mro.mobile.ui.event.UIEvent;
/*  5:   */ import com.mro.mobile.ui.event.UIEventHandler;
/*  6:   */ import com.mro.mobile.util.MobileLogger;
/*  7:   */ import com.mro.mobile.util.MobileLoggerFactory;
/*  8:   */ 
/*  9:   */ public abstract class DefaultEventHandler
/* 10:   */   implements UIEventHandler
/* 11:   */ {
/* 12:25 */   protected MobileLogger log = MobileLoggerFactory.getLogger("maximo.mobile.communication");
/* 13:   */   
/* 14:   */   public void initializeScreen(String screenId)
/* 15:   */     throws MobileApplicationException
/* 16:   */   {}
/* 17:   */   
/* 18:   */   public void refreshScreen(String screenId)
/* 19:   */     throws MobileApplicationException
/* 20:   */   {}
/* 21:   */   
/* 22:   */   protected String getEventId(Object event)
/* 23:   */   {
/* 24:37 */     if ((event instanceof UIEvent)) {
/* 25:39 */       return ((UIEvent)event).getEventName();
/* 26:   */     }
/* 27:42 */     if ((event instanceof String)) {
/* 28:44 */       return (String)event;
/* 29:   */     }
/* 30:46 */     return event.toString();
/* 31:   */   }
/* 32:   */   
/* 33:   */   public boolean performEvent(Object event)
/* 34:   */     throws MobileApplicationException
/* 35:   */   {
/* 36:51 */     if ((event instanceof UIEvent)) {
/* 37:53 */       return performEvent((UIEvent)event);
/* 38:   */     }
/* 39:56 */     if ((event instanceof String)) {
/* 40:58 */       return performEvent(new UIEvent(null, (String)event, null, null));
/* 41:   */     }
/* 42:60 */     return false;
/* 43:   */   }
/* 44:   */   
/* 45:   */   public abstract boolean performEvent(UIEvent paramUIEvent)
/* 46:   */     throws MobileApplicationException;
/* 47:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.DefaultEventHandler
 * JD-Core Version:    0.7.0.1
 */