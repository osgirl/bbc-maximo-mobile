/*    1:     */ package com.mro.mobile.app;
/*    2:     */ 
/*    3:     */ import com.mro.mobile.MobileApplicationException;
/*    4:     */ import com.mro.mobile.MobileMessageGenerator;
/*    5:     */ import com.mro.mobile.ProgressObserver;
/*    6:     */ import com.mro.mobile.mbo.MobileMbo;
/*    7:     */ import com.mro.mobile.mbo.MobileMboData;
/*    8:     */ import com.mro.mobile.mbo.MobileMboInfo;
/*    9:     */ import com.mro.mobile.mbo.MobileMboQBE;
/*   10:     */ import com.mro.mobile.mbo.MobileMboUtil;
/*   11:     */ import com.mro.mobile.persist.RDOException;
/*   12:     */ import com.mro.mobile.persist.RDOInfoManager;
/*   13:     */ import com.mro.mobile.persist.RDOManager;
/*   14:     */ import com.mro.mobile.persist.RDORuntime;
/*   15:     */ import com.mro.mobile.persist.RDOTransactionManager;
/*   16:     */ import com.mro.mobile.ui.MobileMboDataBean;
/*   17:     */ import com.mro.mobile.ui.MobileMboDataBeanManager;
/*   18:     */ import com.mro.mobile.ui.res.UIUtil;
/*   19:     */ import com.mro.mobile.util.MaximoMobileConstants;
/*   20:     */ import com.mro.mobile.util.MobileLogger;
/*   21:     */ import com.mro.mobile.util.MobileLoggerFactory;
/*   22:     */ import java.io.BufferedInputStream;
/*   23:     */ import java.io.BufferedOutputStream;
/*   24:     */ import java.io.ByteArrayInputStream;
/*   25:     */ import java.io.ByteArrayOutputStream;
/*   26:     */ import java.io.File;
/*   27:     */ import java.io.FileInputStream;
/*   28:     */ import java.io.FileOutputStream;
/*   29:     */ import java.io.IOException;
/*   30:     */ import java.io.InputStream;
/*   31:     */ import java.net.ConnectException;
/*   32:     */ import java.util.Enumeration;
/*   33:     */ import java.util.Locale;
/*   34:     */ import java.util.TimeZone;
/*   35:     */ import java.util.zip.ZipEntry;
/*   36:     */ import java.util.zip.ZipFile;
/*   37:     */ import java.util.zip.ZipOutputStream;
/*   38:     */ 
/*   39:     */ public abstract class BasicMobileDeviceApplication
/*   40:     */   extends AbstractMobileDeviceApplication
/*   41:     */ {
/*   42:     */   public static final String UPDATE_SUFFIX = "_upd";
/*   43:     */   private static final int _2KB = 2048;
/*   44:     */   public static final int _500KB = 512000;
/*   45:     */   private MobileSoftwareUpdateHelper softwareUpdateHelper;
/*   46:     */   
/*   47:     */   protected void ensureAllDepenciesAreSetBeforeBoot()
/*   48:     */   {
/*   49:  59 */     super.ensureAllDepenciesAreSetBeforeBoot();
/*   50:  60 */     if (this.softwareUpdateHelper == null) {
/*   51:  61 */       throw new IllegalStateException("SoftwareUpdateHelper is not set.");
/*   52:     */     }
/*   53:     */   }
/*   54:     */   
/*   55:     */   public void initSystemProperties()
/*   56:     */   {
/*   57:  68 */     String dbHome = getSystemProperty("database.home");
/*   58:  69 */     if (dbHome == null)
/*   59:     */     {
/*   60:  70 */       String dbFolderProperty = getProperty("maximo.mobile.database.rootfolder");
/*   61:  71 */       if (dbFolderProperty != null)
/*   62:     */       {
/*   63:  72 */         String appDatabaseFolder = getSystemProperty("mobiledb");
/*   64:  73 */         if (appDatabaseFolder != null)
/*   65:     */         {
/*   66:  74 */           appDatabaseFolder = appDatabaseFolder.trim();
/*   67:  76 */           if ((dbFolderProperty.endsWith(File.separator)) || (appDatabaseFolder.startsWith(File.separator)))
/*   68:     */           {
/*   69:  77 */             setSystemProperty("database.home", dbFolderProperty + appDatabaseFolder);
/*   70:  78 */             dbHome = dbFolderProperty + appDatabaseFolder;
/*   71:     */           }
/*   72:     */           else
/*   73:     */           {
/*   74:  80 */             setSystemProperty("database.home", dbFolderProperty + File.separator + appDatabaseFolder);
/*   75:  81 */             dbHome = dbFolderProperty + File.separator + appDatabaseFolder;
/*   76:     */           }
/*   77:     */         }
/*   78:     */       }
/*   79:     */     }
/*   80:     */   }
/*   81:     */   
/*   82:     */   public void initProxy(DefaultMobileWebServiceProxy proxy)
/*   83:     */     throws MobileApplicationException
/*   84:     */   {
/*   85:  89 */     super.initProxy(proxy);
/*   86:     */     
/*   87:     */ 
/*   88:     */ 
/*   89:     */ 
/*   90:     */ 
/*   91:  95 */     proxy.setProperty("LANGUAGE", getPackageLanguage());
/*   92:  96 */     proxy.setProperty("COUNTRY", Locale.getDefault().getCountry());
/*   93:  97 */     proxy.setProperty("VARIANT", "");
/*   94:     */     
/*   95:  99 */     String timeZone = TimeZone.getDefault().getID();
/*   96: 100 */     proxy.setProperty("TIMEZONE", timeZone);
/*   97:     */   }
/*   98:     */   
/*   99:     */   public String[] getDefaultQueries(String mobileMboName)
/*  100:     */     throws MobileApplicationException
/*  101:     */   {
/*  102: 105 */     MobileMboInfo mboInfo = MobileMboUtil.getMobileMboInfo(getAppName(), mobileMboName);
/*  103:     */     
/*  104: 107 */     String queryTable = "RELATEDQUERY";
/*  105: 108 */     if (mboInfo.isWorkset()) {
/*  106: 109 */       queryTable = "WORKQUERY";
/*  107:     */     }
/*  108: 111 */     MobileMboDataBeanManager mgrAppAuth = new MobileMboDataBeanManager(queryTable);
/*  109: 112 */     MobileMboDataBean authBean = mgrAppAuth.getDataBean();
/*  110: 113 */     authBean.getQBE().setQBE("DATAGROUPID", "=" + mobileMboName);
/*  111: 114 */     authBean.getQBE().setQBE("DOWNLOADDEFAULT", "true");
/*  112: 115 */     authBean.reset();
/*  113:     */     
/*  114: 117 */     int count = authBean.count();
/*  115: 118 */     String[] queries = new String[count];
/*  116: 119 */     int i = 0;
/*  117:     */     for (;;)
/*  118:     */     {
/*  119: 121 */       MobileMbo authMbo = authBean.getMobileMbo(i);
/*  120: 122 */       if (authMbo == null) {
/*  121:     */         break;
/*  122:     */       }
/*  123: 126 */       queries[i] = authMbo.getValue("_ID");
/*  124: 127 */       i++;
/*  125:     */     }
/*  126: 130 */     return queries;
/*  127:     */   }
/*  128:     */   
/*  129:     */   public String[] getDefaultWorkQueries()
/*  130:     */     throws MobileApplicationException
/*  131:     */   {
/*  132: 134 */     String queryTable = "WORKQUERY";
/*  133: 135 */     MobileMboDataBeanManager mgrAppAuth = new MobileMboDataBeanManager(queryTable);
/*  134: 136 */     MobileMboDataBean authBean = mgrAppAuth.getDataBean();
/*  135: 137 */     authBean.getQBE().setQBE("DOWNLOADDEFAULT", "true");
/*  136: 138 */     authBean.reset();
/*  137:     */     
/*  138: 140 */     int count = authBean.count();
/*  139: 141 */     String[] queries = new String[count];
/*  140: 142 */     int i = 0;
/*  141:     */     for (;;)
/*  142:     */     {
/*  143: 144 */       MobileMbo authMbo = authBean.getMobileMbo(i);
/*  144: 145 */       if (authMbo == null) {
/*  145:     */         break;
/*  146:     */       }
/*  147: 149 */       queries[i] = authMbo.getValue("_ID");
/*  148: 150 */       i++;
/*  149:     */     }
/*  150: 153 */     return queries;
/*  151:     */   }
/*  152:     */   
/*  153:     */   public String[] getDefaultQueries()
/*  154:     */     throws MobileApplicationException
/*  155:     */   {
/*  156: 157 */     String relQueryTable = "RELATEDQUERY";
/*  157: 158 */     MobileMboDataBeanManager relQueryBeanMgr = new MobileMboDataBeanManager(relQueryTable);
/*  158: 159 */     MobileMboDataBean relQueryBean = relQueryBeanMgr.getDataBean();
/*  159: 160 */     relQueryBean.getQBE().setQBE("DOWNLOADDEFAULT", "true");
/*  160: 161 */     relQueryBean.reset();
/*  161:     */     
/*  162: 163 */     String workQueryTable = "WORKQUERY";
/*  163: 164 */     MobileMboDataBeanManager workQueryBeanMgr = new MobileMboDataBeanManager(workQueryTable);
/*  164: 165 */     MobileMboDataBean workQueryBean = workQueryBeanMgr.getDataBean();
/*  165: 166 */     workQueryBean.getQBE().setQBE("DOWNLOADDEFAULT", "true");
/*  166: 167 */     workQueryBean.reset();
/*  167:     */     
/*  168: 169 */     int count = relQueryBean.count() + workQueryBean.count();
/*  169: 170 */     String[] queries = new String[count];
/*  170: 171 */     int i = 0;
/*  171:     */     for (;;)
/*  172:     */     {
/*  173: 173 */       MobileMbo relQueryMbo = relQueryBean.getMobileMbo(i);
/*  174: 174 */       if (relQueryMbo == null) {
/*  175:     */         break;
/*  176:     */       }
/*  177: 178 */       queries[i] = relQueryMbo.getValue("_ID");
/*  178: 179 */       i++;
/*  179:     */     }
/*  180: 182 */     int j = 0;
/*  181:     */     for (;;)
/*  182:     */     {
/*  183: 184 */       MobileMbo workQueryMbo = workQueryBean.getMobileMbo(j);
/*  184: 185 */       if (workQueryMbo == null) {
/*  185:     */         break;
/*  186:     */       }
/*  187: 189 */       queries[i] = workQueryMbo.getValue("_ID");
/*  188: 190 */       i++;
/*  189: 191 */       j++;
/*  190:     */     }
/*  191: 194 */     return queries;
/*  192:     */   }
/*  193:     */   
/*  194:     */   protected void appPreRefreshMobileMbos(boolean includeWorkList, boolean includeRelatedList)
/*  195:     */     throws MobileApplicationException
/*  196:     */   {
/*  197: 202 */     if (!isAdHocDataPresent())
/*  198:     */     {
/*  199: 203 */       boolean hasAdHocData = getDefaultMobileWebServiceProxy().hasAdHocData();
/*  200: 204 */       if (hasAdHocData) {
/*  201: 205 */         setAppSetting("ADHOCRECORDSEXIST", "1");
/*  202:     */       }
/*  203:     */     }
/*  204: 209 */     invokeRemoveAllAdHocMobileMbos();
/*  205:     */   }
/*  206:     */   
/*  207:     */   protected void appPostRefreshMobileMbos(boolean includeWorkList, boolean includeRelatedList)
/*  208:     */     throws MobileApplicationException
/*  209:     */   {
/*  210: 216 */     if ((includeWorkList) && (includeRelatedList))
/*  211:     */     {
/*  212: 217 */       String docFolder = getProperty("MOBILEWO.DOCEXTRACTFOLDER");
/*  213: 218 */       if ((docFolder == null) || (docFolder.trim().length() <= 0)) {
/*  214: 219 */         docFolder = MaximoMobileConstants.ATTACHDOCDEFAULTFOLDER;
/*  215:     */       }
/*  216: 221 */       File f = new File(docFolder);
/*  217: 222 */       cleanupAttachDocFolderContents(f);
/*  218:     */     }
/*  219:     */   }
/*  220:     */   
/*  221:     */   protected void cleanupAttachDocFolderContents(File f)
/*  222:     */   {
/*  223: 227 */     File[] folderContents = f.listFiles();
/*  224: 228 */     if (folderContents == null) {
/*  225: 229 */       return;
/*  226:     */     }
/*  227: 232 */     for (int i = 0; i < folderContents.length; i++)
/*  228:     */     {
/*  229: 233 */       File fe = folderContents[i];
/*  230: 234 */       if (fe.isDirectory()) {
/*  231: 235 */         cleanupAttachDocFolderContents(fe);
/*  232:     */       }
/*  233: 237 */       fe.delete();
/*  234:     */     }
/*  235:     */   }
/*  236:     */   
/*  237:     */   protected void invokeRemoveAllAdHocMobileMbos()
/*  238:     */     throws MobileApplicationException
/*  239:     */   {
/*  240: 247 */     String removeAllAdHoc = getAppSetting("REMOVEALLADHOC");
/*  241: 248 */     if ((removeAllAdHoc != null) && (removeAllAdHoc.equals("1")))
/*  242:     */     {
/*  243: 249 */       getDefaultMobileWebServiceProxy().removeAdHocQueryList();
/*  244: 250 */       setAppSetting("REMOVEALLADHOC", "0");
/*  245: 251 */       setAppSetting("ADHOCRECORDSEXIST", "0");
/*  246:     */     }
/*  247:     */   }
/*  248:     */   
/*  249:     */   public void removeAllAdHocMobileMbos(boolean removeAll)
/*  250:     */     throws MobileApplicationException
/*  251:     */   {
/*  252: 266 */     if (removeAll) {
/*  253: 267 */       setAppSetting("REMOVEALLADHOC", "1");
/*  254:     */     } else {
/*  255: 269 */       setAppSetting("REMOVEALLADHOC", "0");
/*  256:     */     }
/*  257:     */   }
/*  258:     */   
/*  259:     */   public boolean isAdHocDataPresent()
/*  260:     */     throws MobileApplicationException
/*  261:     */   {
/*  262: 274 */     String adHocDataExists = getAppSetting("ADHOCRECORDSEXIST");
/*  263: 275 */     if (adHocDataExists == null) {
/*  264: 276 */       return false;
/*  265:     */     }
/*  266: 279 */     if (adHocDataExists.equals("1")) {
/*  267: 280 */       return true;
/*  268:     */     }
/*  269: 283 */     return false;
/*  270:     */   }
/*  271:     */   
/*  272:     */   public synchronized void downloadAdHocMobileMbo(ProgressObserver observer, String dataGroupName, String recordId)
/*  273:     */     throws MobileApplicationException
/*  274:     */   {
/*  275: 295 */     downloadAdHocMobileMbo(observer, dataGroupName, null, recordId);
/*  276:     */   }
/*  277:     */   
/*  278:     */   public synchronized void downloadAdHocMobileMbo(ProgressObserver observer, String dataGroupName, String description, String recordId)
/*  279:     */     throws MobileApplicationException
/*  280:     */   {
/*  281: 300 */     if (observer != null)
/*  282:     */     {
/*  283: 301 */       String msg = MobileMessageGenerator.generate("determineadhoc", new Object[0]);
/*  284: 302 */       observer.setWorkProgressMessage(msg);
/*  285: 303 */       if (observer.isWorkStopped()) {
/*  286: 304 */         return;
/*  287:     */       }
/*  288:     */     }
/*  289: 308 */     invokeRemoveAllAdHocMobileMbos();
/*  290:     */     
/*  291: 310 */     getDefaultMobileWebServiceProxy().createAdHocQuery(dataGroupName, recordId);
/*  292: 315 */     if (isAdHocDataPresent(dataGroupName, recordId)) {
/*  293: 316 */       return;
/*  294:     */     }
/*  295: 319 */     refreshAdHocMobileMbos(observer, dataGroupName, recordId);
/*  296:     */     
/*  297: 321 */     setAppSetting("ADHOCRECORDSEXIST", "1");
/*  298:     */   }
/*  299:     */   
/*  300:     */   public boolean isAdHocDataPresent(String dataGroupName, String recordId)
/*  301:     */     throws MobileApplicationException
/*  302:     */   {
/*  303: 325 */     MobileMboDataBeanManager dataBeanManager = new MobileMboDataBeanManager(dataGroupName);
/*  304: 326 */     MobileMboDataBean dataBean = dataBeanManager.getDataBean();
/*  305: 327 */     dataBean.getQBE().setQbeExactMatch(true);
/*  306: 328 */     dataBean.getQBE().setQBE("_ID", recordId);
/*  307: 329 */     dataBean.reset();
/*  308:     */     
/*  309: 331 */     MobileMbo mobileMbo = dataBean.getMobileMbo(0);
/*  310: 332 */     dataBean.reset();
/*  311: 333 */     if (mobileMbo != null) {
/*  312: 334 */       return true;
/*  313:     */     }
/*  314: 337 */     return false;
/*  315:     */   }
/*  316:     */   
/*  317:     */   public synchronized void refreshAdHocMobileMbos(ProgressObserver observer, String dataGroupName, String recordId)
/*  318:     */     throws MobileApplicationException
/*  319:     */   {
/*  320: 341 */     if (isAppOptionsAuthRefreshNeeded()) {
/*  321: 342 */       refreshAppOptionsAuth(observer);
/*  322:     */     }
/*  323: 345 */     String[] orderedNames = null;
/*  324: 347 */     if (observer != null)
/*  325:     */     {
/*  326: 348 */       String msg = MobileMessageGenerator.generate("refreshwork", new Object[0]);
/*  327: 349 */       observer.setWorkProgressMessage(msg);
/*  328: 350 */       if (observer.isWorkStopped()) {
/*  329: 351 */         return;
/*  330:     */       }
/*  331:     */     }
/*  332: 355 */     orderedNames = getAdHocRefreshOrder(dataGroupName);
/*  333:     */     
/*  334: 357 */     boolean dependentFiltersOnly = true;
/*  335: 358 */     for (int i = 0; i < orderedNames.length; i++)
/*  336:     */     {
/*  337: 359 */       String mobileMboName = orderedNames[i];
/*  338: 360 */       if (mobileMboName != null) {
/*  339: 361 */         if (i == 0) {
/*  340: 362 */           refreshAdHocMobileMbos(mobileMboName, observer, recordId);
/*  341:     */         } else {
/*  342: 364 */           refreshMobileMbos(mobileMboName, observer, dependentFiltersOnly);
/*  343:     */         }
/*  344:     */       }
/*  345:     */     }
/*  346:     */   }
/*  347:     */   
/*  348:     */   public String[] getAdHocRefreshOrder(String dataGroupName)
/*  349:     */     throws MobileApplicationException
/*  350:     */   {
/*  351: 379 */     String[] orderedNames = getDefaultMobileWebServiceProxy().getAdHocRefreshOrder(dataGroupName);
/*  352: 380 */     return orderedNames;
/*  353:     */   }
/*  354:     */   
/*  355:     */   public void refreshAdHocMobileMbos(String mboName, ProgressObserver observer, String recordId)
/*  356:     */     throws MobileApplicationException
/*  357:     */   {
/*  358: 386 */     checkUpdateError();
/*  359:     */     
/*  360: 388 */     MobileMboInfo mboInfo = MobileMboUtil.getMobileMboInfo(getAppName(), mboName);
/*  361: 389 */     if ((mboInfo.getParent() != null) || (mboInfo.isLocalWorkset()) || (mboInfo.isLocalWorksetUpload())) {
/*  362: 390 */       return;
/*  363:     */     }
/*  364: 393 */     if (observer != null)
/*  365:     */     {
/*  366: 394 */       String msg = MobileMessageGenerator.generate("refreshmbo", new Object[] { mboInfo.getDescription() });
/*  367: 395 */       observer.setWorkProgressMessage(msg);
/*  368: 396 */       if (observer.isWorkStopped()) {
/*  369: 397 */         return;
/*  370:     */       }
/*  371:     */     }
/*  372:     */     try
/*  373:     */     {
/*  374: 402 */       MobileMboData mboData = null;
/*  375:     */       
/*  376: 404 */       mboData = getDefaultMobileWebServiceProxy().getAdHocMobileMbo(mboName, recordId);
/*  377: 407 */       if (mboData.getStartIndex() == -1) {
/*  378: 408 */         throw new MobileApplicationException("invalidmobilembo", new String[] { mboName });
/*  379:     */       }
/*  380: 410 */       if (mboData.getStartIndex() == -2) {
/*  381: 411 */         throw new MobileApplicationException("invalidmboset", new String[] { mboName });
/*  382:     */       }
/*  383: 413 */       if (mboData.getStartIndex() == -3) {
/*  384: 414 */         throw new MobileApplicationException("mobilemboprocessing");
/*  385:     */       }
/*  386: 417 */       getRDORuntime().getRDOTransactionManager().begin();
/*  387: 418 */       MobileMbo[] mbos = mboData.getMobileMbos();
/*  388: 419 */       for (int i = 0; i < mbos.length; i++) {
/*  389: 420 */         saveCompleteDownloadedMbo(mbos[i], true);
/*  390:     */       }
/*  391: 422 */       getRDORuntime().getRDOTransactionManager().commit();
/*  392: 424 */       if (observer != null)
/*  393:     */       {
/*  394: 425 */         observer.updateWorkProgress();
/*  395: 426 */         if (observer.isWorkStopped()) {
/*  396: 427 */           return;
/*  397:     */         }
/*  398:     */       }
/*  399: 431 */       getDefaultMobileWebServiceProxy().acknowledgeAdHocRecordData(mboName, recordId);
/*  400:     */     }
/*  401:     */     catch (Exception ex)
/*  402:     */     {
/*  403:     */       try
/*  404:     */       {
/*  405: 434 */         getRDORuntime().getRDOTransactionManager().rollback();
/*  406:     */       }
/*  407:     */       catch (Exception e) {}
/*  408: 438 */       if ((ex instanceof MobileApplicationException)) {
/*  409: 439 */         throw ((MobileApplicationException)ex);
/*  410:     */       }
/*  411: 441 */       throw new MobileApplicationException(ex);
/*  412:     */     }
/*  413:     */   }
/*  414:     */   
/*  415:     */   public void releaseApplication()
/*  416:     */   {
/*  417: 447 */     super.releaseApplication();
/*  418: 448 */     releaseRDORuntime();
/*  419:     */   }
/*  420:     */   
/*  421:     */   private void releaseRDORuntime()
/*  422:     */   {
/*  423:     */     try
/*  424:     */     {
/*  425: 453 */       RDORuntime runtime = getRDORuntime();
/*  426: 454 */       if (runtime != null) {
/*  427: 455 */         runtime.getRDOInfoManager().release();
/*  428:     */       }
/*  429:     */     }
/*  430:     */     catch (RDOException e)
/*  431:     */     {
/*  432: 458 */       getDefaultLogger().warn("Failed to release RDO runtime", e);
/*  433:     */     }
/*  434:     */   }
/*  435:     */   
/*  436:     */   public boolean isSnapshotEnabled()
/*  437:     */   {
/*  438: 469 */     String snapshotProperty = getProperty("maximo.mobile.snapshot");
/*  439: 470 */     if ((snapshotProperty != null) && (snapshotProperty.equals("true"))) {
/*  440: 471 */       return true;
/*  441:     */     }
/*  442: 474 */     return false;
/*  443:     */   }
/*  444:     */   
/*  445:     */   public int getSnapshotChunkSize()
/*  446:     */   {
/*  447: 485 */     int DEFAULT_CHUNK_SIZE = 512000;
/*  448:     */     
/*  449: 487 */     String snapshotChunkSizeProperty = getProperty("maximo.mobile.snapshot.chunksizekb");
/*  450: 488 */     if (snapshotChunkSizeProperty != null) {
/*  451:     */       try
/*  452:     */       {
/*  453: 490 */         int chunkSize = Integer.valueOf(snapshotChunkSizeProperty).intValue();
/*  454: 491 */         return chunkSize * 1024;
/*  455:     */       }
/*  456:     */       catch (NumberFormatException ex) {}
/*  457:     */     }
/*  458: 497 */     return DEFAULT_CHUNK_SIZE;
/*  459:     */   }
/*  460:     */   
/*  461:     */   public void storeSnapshot(String alreadyUsedByUserName, String currentUserName, ProgressObserver observer)
/*  462:     */     throws MobileApplicationException
/*  463:     */   {
/*  464: 504 */     if (!isSnapshotEnabled()) {
/*  465: 505 */       return;
/*  466:     */     }
/*  467: 508 */     if (observer != null)
/*  468:     */     {
/*  469: 509 */       String msg = MobileMessageGenerator.generate("storesnapshotprogress", new Object[0]);
/*  470: 510 */       observer.setWorkProgressMessage(msg);
/*  471:     */     }
/*  472: 513 */     MobileLogger mobileLogger = MobileLoggerFactory.getLogger("maximo.mobile.snapshot");
/*  473: 514 */     if (mobileLogger.isInfoEnabled()) {
/*  474: 515 */       mobileLogger.info("storeSnapshot: BEGIN");
/*  475:     */     }
/*  476: 518 */     String dbHome = getDatabaseHome();
/*  477:     */     
/*  478: 520 */     MobileDeviceAppService appService = getDefaultMobileWebServiceProxy().getService();
/*  479:     */     try
/*  480:     */     {
/*  481: 522 */       appService.enableProcessDataTxn(false);
/*  482: 523 */       appService.suspendProcessPendingRequests();
/*  483: 524 */       appService.suspendUpdateLastCommunication();
/*  484: 526 */       if (mobileLogger.isInfoEnabled()) {
/*  485: 527 */         mobileLogger.info("storeSnapshot: calling getSnapshotChunkSize");
/*  486:     */       }
/*  487: 530 */       int chunkSize = getSnapshotChunkSize();
/*  488: 532 */       if (mobileLogger.isInfoEnabled()) {
/*  489: 533 */         mobileLogger.info("storeSnapshot: DONE calling getSnapshotChunkSize, chunkSize = " + chunkSize);
/*  490:     */       }
/*  491: 540 */       getRDORuntime().getRDOManager().release();
/*  492: 542 */       if (mobileLogger.isInfoEnabled()) {
/*  493: 543 */         mobileLogger.info("storeSnapshot: Released local database connections.");
/*  494:     */       }
/*  495: 546 */       int chunkIndex = createZipDataAndSend(dbHome, chunkSize);
/*  496: 548 */       if (mobileLogger.isInfoEnabled()) {
/*  497: 549 */         mobileLogger.info("storeSnapshot: Sent zipped data in chunks. noOfChunksSent = " + (chunkIndex + 1));
/*  498:     */       }
/*  499: 552 */       getDefaultMobileWebServiceProxy().storeSnapshotChunks(alreadyUsedByUserName);
/*  500: 554 */       if (mobileLogger.isInfoEnabled()) {
/*  501: 555 */         mobileLogger.info("storeSnapshot: Finished asking the server to store the snapshot sent.");
/*  502:     */       }
/*  503: 558 */       unregisterAppRuntime();
/*  504: 560 */       if (mobileLogger.isInfoEnabled()) {
/*  505: 561 */         mobileLogger.info("storeSnapshot: Unregistered application runtime.");
/*  506:     */       }
/*  507: 564 */       deleteAllFilesFromFolder(new File(dbHome));
/*  508: 566 */       if (mobileLogger.isInfoEnabled()) {
/*  509: 567 */         mobileLogger.info("storeSnapshot: Deleted all files from folder: " + dbHome);
/*  510:     */       }
/*  511: 570 */       resetSystemPersistenceRuntime();
/*  512: 572 */       if (mobileLogger.isInfoEnabled()) {
/*  513: 573 */         mobileLogger.info("storeSnapshot: Reset system runtime.");
/*  514:     */       }
/*  515:     */     }
/*  516:     */     catch (Throwable e)
/*  517:     */     {
/*  518: 576 */       if (mobileLogger.isErrorEnabled()) {
/*  519: 577 */         mobileLogger.error("Failed to store snapshot", e);
/*  520:     */       }
/*  521: 580 */       throw new MobileApplicationException("failedtostoresnapshot", e);
/*  522:     */     }
/*  523:     */     finally
/*  524:     */     {
/*  525: 582 */       appService.enableProcessDataTxn(true);
/*  526: 583 */       appService.resumeProcessPendingRequests();
/*  527: 584 */       appService.resumeUpdateLastCommunication();
/*  528: 586 */       if (mobileLogger.isInfoEnabled()) {
/*  529: 587 */         mobileLogger.info("storeSnapshot: DONE");
/*  530:     */       }
/*  531:     */     }
/*  532:     */   }
/*  533:     */   
/*  534:     */   public void retrieveSnapshot(ProgressObserver observer)
/*  535:     */     throws MobileApplicationException
/*  536:     */   {
/*  537: 596 */     if (!isSnapshotEnabled()) {
/*  538: 597 */       return;
/*  539:     */     }
/*  540: 600 */     if (observer != null)
/*  541:     */     {
/*  542: 601 */       String msg = MobileMessageGenerator.generate("retrievesnapshotprogress", new Object[0]);
/*  543: 602 */       observer.setWorkProgressMessage(msg);
/*  544:     */     }
/*  545: 605 */     MobileLogger mobileLogger = MobileLoggerFactory.getLogger("maximo.mobile.snapshot");
/*  546: 607 */     if (mobileLogger.isInfoEnabled()) {
/*  547: 608 */       mobileLogger.info("retrieveSnapshot: BEGIN");
/*  548:     */     }
/*  549: 611 */     String dbHome = getDatabaseHome();
/*  550:     */     
/*  551: 613 */     MobileDeviceAppService appService = getDefaultMobileWebServiceProxy().getService();
/*  552:     */     try
/*  553:     */     {
/*  554: 615 */       appService.enableProcessDataTxn(false);
/*  555: 616 */       appService.suspendProcessPendingRequests();
/*  556: 617 */       appService.suspendUpdateLastCommunication();
/*  557: 619 */       if (mobileLogger.isInfoEnabled()) {
/*  558: 620 */         mobileLogger.info("retrieveSnapshot: releasing current db runtime");
/*  559:     */       }
/*  560: 623 */       if (mobileLogger.isInfoEnabled()) {
/*  561: 624 */         mobileLogger.info("retrieveSnapshot: calling getSnapshotChunkSize");
/*  562:     */       }
/*  563: 627 */       int chunkSize = getSnapshotChunkSize();
/*  564: 629 */       if (mobileLogger.isInfoEnabled()) {
/*  565: 630 */         mobileLogger.info("retrieveSnapshot: DONE calling getSnapshotChunkSize, chunkSize = " + chunkSize);
/*  566:     */       }
/*  567: 633 */       int noOfChunks = getDefaultMobileWebServiceProxy().getSnapshotChunks(chunkSize);
/*  568: 634 */       if (noOfChunks == 0)
/*  569:     */       {
/*  570: 635 */         if (mobileLogger.isInfoEnabled()) {
/*  571: 636 */           mobileLogger.info("retrieveSnapshot: Number of chunks = 0, i.e, no data on server.");
/*  572:     */         }
/*  573:     */       }
/*  574:     */       else
/*  575:     */       {
/*  576: 650 */         getRDORuntime().getRDOManager().release();
/*  577: 652 */         if (mobileLogger.isInfoEnabled()) {
/*  578: 653 */           mobileLogger.info("retrieveSnapshot: Number of chunks = 0, i.e, no data on server.");
/*  579:     */         }
/*  580: 656 */         deleteAllFilesFromFolder(new File(dbHome));
/*  581: 658 */         if (mobileLogger.isInfoEnabled()) {
/*  582: 659 */           mobileLogger.info("retrieveSnapshot: Deleted all files from folder: " + dbHome);
/*  583:     */         }
/*  584: 662 */         new File(dbHome).mkdirs();
/*  585: 664 */         if (mobileLogger.isInfoEnabled()) {
/*  586: 665 */           mobileLogger.info("retrieveSnapshot: Getting snapshot data from server in chunks.");
/*  587:     */         }
/*  588: 668 */         byte[] snapshotDataChunk = null;
/*  589: 669 */         for (int i = 0; i < noOfChunks; i++)
/*  590:     */         {
/*  591: 670 */           snapshotDataChunk = getDefaultMobileWebServiceProxy().retrieveSnapshotChunk(i);
/*  592:     */           
/*  593: 672 */           ByteArrayInputStream bis = new ByteArrayInputStream(snapshotDataChunk);
/*  594: 674 */           if (i == 0) {
/*  595: 675 */             createFileFromStream(new File(dbHome + "\\snapshot.aaa"), bis);
/*  596:     */           } else {
/*  597: 677 */             createFileFromStream(new File(dbHome + "\\snapshot.aaa"), bis, true);
/*  598:     */           }
/*  599:     */         }
/*  600: 681 */         if (mobileLogger.isInfoEnabled()) {
/*  601: 682 */           mobileLogger.info("retrieveSnapshot: Got snapshot data from server and saved to temp snapshot data file.");
/*  602:     */         }
/*  603: 685 */         resetSystemPersistenceRuntime();
/*  604: 687 */         if (mobileLogger.isInfoEnabled()) {
/*  605: 688 */           mobileLogger.info("retrieveSnapshot: Reset system runtime.");
/*  606:     */         }
/*  607: 691 */         extractSnapshotData(new File(dbHome + "\\snapshot.aaa"), dbHome);
/*  608: 693 */         if (mobileLogger.isInfoEnabled()) {
/*  609: 694 */           mobileLogger.info("retrieveSnapshot: Extracted snapshot data.");
/*  610:     */         }
/*  611: 697 */         new File(dbHome + "\\snapshot.aaa").delete();
/*  612: 699 */         if (mobileLogger.isInfoEnabled()) {
/*  613: 700 */           mobileLogger.info("retrieveSnapshot: Deleted the temporary snapshot data file.");
/*  614:     */         }
/*  615: 704 */         initSystemPersistenceRuntime();
/*  616: 706 */         if (mobileLogger.isInfoEnabled()) {
/*  617: 707 */           mobileLogger.info("retrieveSnapshot: Initialized system runtime.");
/*  618:     */         }
/*  619: 710 */         getDefaultMobileWebServiceProxy().removeSnapshot();
/*  620: 712 */         if (mobileLogger.isInfoEnabled()) {
/*  621: 713 */           mobileLogger.info("retrieveSnapshot: Asked the server to remove the snapshot.");
/*  622:     */         }
/*  623: 718 */         resetSystemPersistenceRuntime();
/*  624: 720 */         if (mobileLogger.isInfoEnabled()) {
/*  625: 721 */           mobileLogger.info("retrieveSnapshot: Reset system runtime AGAIN.");
/*  626:     */         }
/*  627: 725 */         initSystemPersistenceRuntime();
/*  628: 726 */         if (mobileLogger.isInfoEnabled()) {
/*  629: 727 */           mobileLogger.info("retrieveSnapshot: Initialized system runtime.");
/*  630:     */         }
/*  631:     */       }
/*  632:     */     }
/*  633:     */     catch (Throwable e)
/*  634:     */     {
/*  635: 730 */       if (mobileLogger.isErrorEnabled()) {
/*  636: 731 */         mobileLogger.error("Failed to retrieve snapshot", e);
/*  637:     */       }
/*  638: 734 */       if (mobileLogger.isInfoEnabled()) {
/*  639: 735 */         mobileLogger.info("retrieveSnapshot: Deleting all files form folder.");
/*  640:     */       }
/*  641: 742 */       deleteAllFilesFromFolder(new File(dbHome));
/*  642: 744 */       if (mobileLogger.isInfoEnabled()) {
/*  643: 745 */         mobileLogger.info("retrieveSnapshot: Throwing the failed to retrieve snapshot error.");
/*  644:     */       }
/*  645: 748 */       throw new MobileApplicationException("failedtoretrievesnapshot", e);
/*  646:     */     }
/*  647:     */     finally
/*  648:     */     {
/*  649: 750 */       appService.enableProcessDataTxn(true);
/*  650: 751 */       appService.resumeProcessPendingRequests();
/*  651: 752 */       appService.resumeUpdateLastCommunication();
/*  652: 754 */       if (mobileLogger.isInfoEnabled()) {
/*  653: 755 */         mobileLogger.info("retrieveSnapshot: DONE");
/*  654:     */       }
/*  655:     */     }
/*  656:     */   }
/*  657:     */   
/*  658:     */   private int createZipDataAndSend(String folderName, int chunkSize)
/*  659:     */     throws IOException, MobileApplicationException
/*  660:     */   {
/*  661: 761 */     ByteArrayOutputStream bos = new ByteArrayOutputStream();
/*  662: 762 */     ZipOutputStream out = new ZipOutputStream(new BufferedOutputStream(bos));
/*  663:     */     
/*  664: 764 */     int chunkIndex = createZipEntryAndSend(null, folderName, out, bos, 0, chunkSize);
/*  665:     */     
/*  666: 766 */     out.flush();
/*  667: 767 */     out.finish();
/*  668: 768 */     out.close();
/*  669:     */     
/*  670: 770 */     MobileLogger mobileLogger = MobileLoggerFactory.getLogger("maximo.mobile.snapshot");
/*  671: 771 */     if (mobileLogger.isInfoEnabled())
/*  672:     */     {
/*  673: 772 */       mobileLogger.info("createZipEntryAndSend: calling addSnapshotChunk with chunkIndex " + chunkIndex);
/*  674: 773 */       mobileLogger.info("createZipEntryAndSend: calling addSnapshotChunk with snapshotData length " + bos.toByteArray().length);
/*  675:     */     }
/*  676: 776 */     getDefaultMobileWebServiceProxy().addSnapshotChunk(new Integer(chunkIndex), bos.toByteArray());
/*  677:     */     
/*  678: 778 */     return chunkIndex;
/*  679:     */   }
/*  680:     */   
/*  681:     */   private int createZipEntryAndSend(String entryName, String folderName, ZipOutputStream out, ByteArrayOutputStream bos, int chunkIndex, int chunkSize)
/*  682:     */     throws IOException, MobileApplicationException
/*  683:     */   {
/*  684: 783 */     int BUFFER_SIZE = 2048;
/*  685:     */     
/*  686: 785 */     byte[] data = new byte[BUFFER_SIZE];
/*  687: 786 */     File f = new File(folderName);
/*  688: 787 */     File[] fileNames = f.listFiles();
/*  689:     */     
/*  690: 789 */     String zipEntryName = "";
/*  691: 790 */     if (entryName != null) {
/*  692: 791 */       zipEntryName = entryName + "/";
/*  693:     */     }
/*  694: 794 */     int noOfFiles = fileNames.length;
/*  695: 796 */     if (noOfFiles == 0)
/*  696:     */     {
/*  697: 797 */       ZipEntry entry = new ZipEntry(zipEntryName);
/*  698: 798 */       out.putNextEntry(entry);
/*  699:     */       
/*  700: 800 */       return chunkIndex;
/*  701:     */     }
/*  702: 803 */     for (int i = 0; i < noOfFiles; i++) {
/*  703: 804 */       if (fileNames[i].isDirectory())
/*  704:     */       {
/*  705: 805 */         if (entryName == null) {
/*  706: 806 */           chunkIndex = createZipEntryAndSend(fileNames[i].getName(), fileNames[i].getAbsolutePath(), out, bos, chunkIndex, chunkSize);
/*  707:     */         } else {
/*  708: 808 */           chunkIndex = createZipEntryAndSend(zipEntryName + fileNames[i].getName(), fileNames[i].getAbsolutePath(), out, bos, chunkIndex, chunkSize);
/*  709:     */         }
/*  710:     */       }
/*  711:     */       else
/*  712:     */       {
/*  713: 811 */         ZipEntry entry = new ZipEntry(zipEntryName + fileNames[i].getName());
/*  714: 812 */         out.putNextEntry(entry);
/*  715:     */         
/*  716: 814 */         FileInputStream fis = new FileInputStream(fileNames[i]);
/*  717: 815 */         BufferedInputStream origin = new BufferedInputStream(fis, BUFFER_SIZE);
/*  718:     */         int count;
/*  719: 818 */         while ((count = origin.read(data, 0, BUFFER_SIZE)) != -1)
/*  720:     */         {
/*  721: 819 */           out.write(data, 0, count);
/*  722:     */           
/*  723: 821 */           out.flush();
/*  724: 823 */           if (bos.toByteArray().length >= 204800)
/*  725:     */           {
/*  726: 824 */             MobileLogger mobileLogger = MobileLoggerFactory.getLogger("maximo.mobile.snapshot");
/*  727: 825 */             if (mobileLogger.isInfoEnabled())
/*  728:     */             {
/*  729: 826 */               mobileLogger.info("createZipEntryAndSend: calling addSnapshotChunk with chunkIndex " + chunkIndex);
/*  730: 827 */               mobileLogger.info("createZipEntryAndSend: calling addSnapshotChunk with snapshotData length " + bos.toByteArray().length);
/*  731:     */             }
/*  732: 830 */             getDefaultMobileWebServiceProxy().addSnapshotChunk(new Integer(chunkIndex), bos.toByteArray());
/*  733:     */             
/*  734: 832 */             bos.reset();
/*  735: 833 */             chunkIndex++;
/*  736:     */           }
/*  737:     */         }
/*  738: 837 */         origin.close();
/*  739:     */       }
/*  740:     */     }
/*  741: 841 */     return chunkIndex;
/*  742:     */   }
/*  743:     */   
/*  744:     */   protected byte[] createZipData(String folderName, ByteArrayOutputStream bos2)
/*  745:     */     throws Exception
/*  746:     */   {
/*  747: 845 */     ByteArrayOutputStream bos = new ByteArrayOutputStream();
/*  748: 846 */     ZipOutputStream out = new ZipOutputStream(new BufferedOutputStream(bos));
/*  749:     */     
/*  750: 848 */     createZipData(null, folderName, out, bos, bos2);
/*  751:     */     
/*  752: 850 */     out.flush();
/*  753: 851 */     out.finish();
/*  754: 852 */     out.close();
/*  755:     */     
/*  756: 854 */     bos2.write(bos.toByteArray());
/*  757:     */     
/*  758: 856 */     return bos.toByteArray();
/*  759:     */   }
/*  760:     */   
/*  761:     */   private void createZipData(String entryName, String folderName, ZipOutputStream out, ByteArrayOutputStream bos, ByteArrayOutputStream bos2)
/*  762:     */     throws Exception
/*  763:     */   {
/*  764: 861 */     byte[] data = new byte[2048];
/*  765: 862 */     File f = new File(folderName);
/*  766: 863 */     File[] fileNames = f.listFiles();
/*  767:     */     
/*  768: 865 */     String zipEntryName = "";
/*  769: 866 */     if (entryName != null) {
/*  770: 867 */       zipEntryName = entryName + "/";
/*  771:     */     }
/*  772: 870 */     int noOfFiles = fileNames.length;
/*  773: 872 */     if (noOfFiles == 0)
/*  774:     */     {
/*  775: 873 */       ZipEntry entry = new ZipEntry(zipEntryName);
/*  776: 874 */       out.putNextEntry(entry);
/*  777:     */       
/*  778: 876 */       return;
/*  779:     */     }
/*  780: 879 */     for (int i = 0; i < noOfFiles; i++) {
/*  781: 880 */       if (fileNames[i].isDirectory())
/*  782:     */       {
/*  783: 881 */         if (entryName == null) {
/*  784: 882 */           createZipData(fileNames[i].getName(), fileNames[i].getAbsolutePath(), out, bos, bos2);
/*  785:     */         } else {
/*  786: 884 */           createZipData(zipEntryName + fileNames[i].getName(), fileNames[i].getAbsolutePath(), out, bos, bos2);
/*  787:     */         }
/*  788:     */       }
/*  789:     */       else
/*  790:     */       {
/*  791: 887 */         ZipEntry entry = new ZipEntry(zipEntryName + fileNames[i].getName());
/*  792: 888 */         out.putNextEntry(entry);
/*  793:     */         
/*  794: 890 */         FileInputStream fis = new FileInputStream(fileNames[i]);
/*  795: 891 */         BufferedInputStream origin = new BufferedInputStream(fis, 2048);
/*  796:     */         int count;
/*  797: 894 */         while ((count = origin.read(data, 0, 2048)) != -1)
/*  798:     */         {
/*  799: 895 */           out.write(data, 0, count);
/*  800: 896 */           out.flush();
/*  801: 898 */           if (bos.toByteArray().length >= 204800)
/*  802:     */           {
/*  803: 899 */             bos2.write(bos.toByteArray());
/*  804:     */             
/*  805: 901 */             bos.reset();
/*  806:     */           }
/*  807:     */         }
/*  808: 906 */         origin.close();
/*  809:     */       }
/*  810:     */     }
/*  811:     */   }
/*  812:     */   
/*  813:     */   private void extractSnapshotData(File snapshotDataZipFile, String dbFolder)
/*  814:     */     throws IOException
/*  815:     */   {
/*  816: 912 */     ZipFile zFile = new ZipFile(snapshotDataZipFile);
/*  817: 913 */     Enumeration zipEnum = zFile.entries();
/*  818:     */     
/*  819: 915 */     String outputFolder = dbFolder;
/*  820: 916 */     while (zipEnum.hasMoreElements())
/*  821:     */     {
/*  822: 917 */       ZipEntry zipEntry = (ZipEntry)zipEnum.nextElement();
/*  823: 918 */       InputStream zipEntryInputStream = zFile.getInputStream(zipEntry);
/*  824:     */       
/*  825: 920 */       String zipEntryName = zipEntry.getName();
/*  826: 921 */       boolean isDir = zipEntry.isDirectory();
/*  827: 923 */       if (isDir)
/*  828:     */       {
/*  829: 924 */         File f = new File(outputFolder + File.separator + zipEntryName);
/*  830: 925 */         f.mkdirs();
/*  831:     */       }
/*  832:     */       else
/*  833:     */       {
/*  834: 927 */         File f = new File(outputFolder + File.separator + zipEntryName);
/*  835: 928 */         f.getParentFile().mkdirs();
/*  836:     */         
/*  837: 930 */         createFileFromStream(f, zipEntryInputStream);
/*  838:     */       }
/*  839:     */     }
/*  840: 934 */     zFile.close();
/*  841:     */   }
/*  842:     */   
/*  843:     */   void createFileFromStream(File file, InputStream inputStream)
/*  844:     */     throws IOException
/*  845:     */   {
/*  846: 938 */     createFileFromStream(file, inputStream, false);
/*  847:     */   }
/*  848:     */   
/*  849:     */   void createFileFromStream(File file, InputStream inputStream, boolean append)
/*  850:     */     throws IOException
/*  851:     */   {
/*  852: 942 */     FileOutputStream fos = new FileOutputStream(file, append);
/*  853:     */     
/*  854: 944 */     byte[] buf = new byte[1024];
/*  855:     */     for (;;)
/*  856:     */     {
/*  857: 946 */       int bytesRead = inputStream.read(buf);
/*  858: 947 */       if (bytesRead <= 0) {
/*  859:     */         break;
/*  860:     */       }
/*  861: 950 */       fos.write(buf, 0, bytesRead);
/*  862:     */     }
/*  863: 953 */     fos.flush();
/*  864: 954 */     fos.close();
/*  865:     */   }
/*  866:     */   
/*  867:     */   public String getDatabaseHome()
/*  868:     */   {
/*  869: 958 */     String dbHome = getSystemProperty("database.home");
/*  870: 959 */     if (dbHome == null)
/*  871:     */     {
/*  872: 960 */       BasicMobileDeviceUIApplication app = UIUtil.getApplication();
/*  873:     */       
/*  874: 962 */       String dbFolderProperty = app.getProperty("maximo.mobile.database.rootfolder");
/*  875: 963 */       if (dbFolderProperty != null)
/*  876:     */       {
/*  877: 964 */         String appDatabaseFolder = getSystemProperty("mobiledb");
/*  878: 965 */         if (appDatabaseFolder != null)
/*  879:     */         {
/*  880: 966 */           appDatabaseFolder = appDatabaseFolder.trim();
/*  881: 968 */           if ((dbFolderProperty.endsWith(File.separator)) || (appDatabaseFolder.startsWith(File.separator)))
/*  882:     */           {
/*  883: 969 */             setSystemProperty("database.home", dbFolderProperty + appDatabaseFolder);
/*  884: 970 */             dbHome = dbFolderProperty + appDatabaseFolder;
/*  885:     */           }
/*  886:     */           else
/*  887:     */           {
/*  888: 972 */             setSystemProperty("database.home", dbFolderProperty + File.separator + appDatabaseFolder);
/*  889: 973 */             dbHome = dbFolderProperty + File.separator + appDatabaseFolder;
/*  890:     */           }
/*  891:     */         }
/*  892:     */       }
/*  893:     */     }
/*  894: 979 */     return dbHome;
/*  895:     */   }
/*  896:     */   
/*  897:     */   private void deleteAllFilesFromFolder(File folder)
/*  898:     */   {
/*  899: 983 */     deleteAllFilesFromFolderX(folder);
/*  900:     */     
/*  901:     */ 
/*  902:     */ 
/*  903: 987 */     deleteAllFilesFromFolderX(folder);
/*  904:     */   }
/*  905:     */   
/*  906:     */   private void deleteAllFilesFromFolderX(File folder)
/*  907:     */   {
/*  908: 991 */     File[] files = folder.listFiles();
/*  909: 992 */     if (files != null) {
/*  910: 993 */       for (int i = 0; i < files.length; i++)
/*  911:     */       {
/*  912: 994 */         File f = files[i];
/*  913: 995 */         if (f.isDirectory())
/*  914:     */         {
/*  915: 996 */           deleteAllFilesFromFolderX(f);
/*  916: 997 */           f.delete();
/*  917:     */         }
/*  918:     */         else
/*  919:     */         {
/*  920: 999 */           f.delete();
/*  921:     */         }
/*  922:     */       }
/*  923:     */     }
/*  924:     */   }
/*  925:     */   
/*  926:     */   public int checkForUpdateIgnoreCommFailure()
/*  927:     */     throws MobileApplicationException
/*  928:     */   {
/*  929:     */     try
/*  930:     */     {
/*  931:1007 */       return checkForUpdate();
/*  932:     */     }
/*  933:     */     catch (MobileApplicationException e)
/*  934:     */     {
/*  935:1009 */       if ((e.getNestedException() instanceof ConnectException)) {
/*  936:1010 */         return 0;
/*  937:     */       }
/*  938:1012 */       throw e;
/*  939:     */     }
/*  940:     */   }
/*  941:     */   
/*  942:     */   public int checkForUpdate()
/*  943:     */     throws MobileApplicationException
/*  944:     */   {
/*  945:1018 */     File currentFile = this.softwareUpdateHelper.getAppJarOrApkFileLocationToSaveDownloadedFile();
/*  946:1019 */     if (currentFile != null)
/*  947:     */     {
/*  948:1020 */       String version = getProperty("maximo.mobile.version");
/*  949:1021 */       String language = getProperty("maximo.mobile.packagelanguage");
/*  950:1022 */       String profile = getProperty("maximo.mobile.profile");
/*  951:1023 */       return getDefaultMobileWebServiceProxy().checkForUpdate(language, version, profile);
/*  952:     */     }
/*  953:1025 */     return 0;
/*  954:     */   }
/*  955:     */   
/*  956:     */   public synchronized void downloadUpdateFile()
/*  957:     */     throws MobileApplicationException
/*  958:     */   {
/*  959:1030 */     this.softwareUpdateHelper.downloadUpdateFile();
/*  960:     */   }
/*  961:     */   
/*  962:     */   public synchronized int getUpdateStatus(boolean displayResponse, boolean sync)
/*  963:     */     throws MobileApplicationException
/*  964:     */   {
/*  965:1035 */     int updateStatus = 0;
/*  966:1036 */     String updateStatusStr = getAppSetting("_UPDATEAVAILABLE");
/*  967:1038 */     if ((updateStatusStr != null) && (!"".equals(updateStatusStr))) {
/*  968:1039 */       updateStatus = Integer.parseInt(getAppSetting("_UPDATEAVAILABLE"));
/*  969:     */     }
/*  970:1042 */     if ((sync) && 
/*  971:1043 */       (updateStatus == 0))
/*  972:     */     {
/*  973:1044 */       if (displayResponse) {
/*  974:1045 */         updateStatus = checkForUpdate();
/*  975:     */       } else {
/*  976:1047 */         updateStatus = checkForUpdateIgnoreCommFailure();
/*  977:     */       }
/*  978:1048 */       setAppSetting("_UPDATEAVAILABLE", "" + updateStatus);
/*  979:     */     }
/*  980:1052 */     return updateStatus;
/*  981:     */   }
/*  982:     */   
/*  983:     */   public void checkUpdateError()
/*  984:     */     throws MobileApplicationException
/*  985:     */   {
/*  986:1057 */     BasicMobileDeviceApplication app = MobileDeviceAppSession.getSession().getApplicationAsUIApplication();
/*  987:1058 */     if (app != null)
/*  988:     */     {
/*  989:1059 */       String updateStatus = app.getAppSetting("_UPDATEAVAILABLE");
/*  990:1060 */       if ((updateStatus != null) && (!updateStatus.equals("")) && (!updateStatus.equalsIgnoreCase("0")))
/*  991:     */       {
/*  992:1061 */         String message = MobileMessageGenerator.generate("updateneeded", null);
/*  993:1062 */         throw new MobileApplicationException(message);
/*  994:     */       }
/*  995:     */     }
/*  996:     */   }
/*  997:     */   
/*  998:     */   public void refreshMobileMbos(String mboName, ProgressObserver observer, boolean dependentFilterOnly)
/*  999:     */     throws MobileApplicationException
/* 1000:     */   {
/* 1001:1069 */     checkUpdateError();
/* 1002:     */     
/* 1003:1071 */     super.refreshMobileMbos(mboName, observer, dependentFilterOnly);
/* 1004:     */   }
/* 1005:     */   
/* 1006:     */   public synchronized void refreshAllMobileMbosOnly(ProgressObserver observer, boolean includeWorkList, boolean includeRelatedList)
/* 1007:     */     throws MobileApplicationException
/* 1008:     */   {
/* 1009:1076 */     checkUpdateError();
/* 1010:1077 */     super.refreshAllMobileMbosOnly(observer, includeWorkList, includeRelatedList);
/* 1011:     */   }
/* 1012:     */   
/* 1013:     */   public void refreshAppOptionsAuth(ProgressObserver observer)
/* 1014:     */     throws MobileApplicationException
/* 1015:     */   {
/* 1016:1081 */     checkUpdateError();
/* 1017:1082 */     super.refreshAppOptionsAuth(observer);
/* 1018:     */   }
/* 1019:     */   
/* 1020:     */   public MobileSoftwareUpdateHelper getSoftwareUpdateHelper()
/* 1021:     */   {
/* 1022:1089 */     return this.softwareUpdateHelper;
/* 1023:     */   }
/* 1024:     */   
/* 1025:     */   public void setSoftwareUpdateHelper(MobileSoftwareUpdateHelper softwareUpdateHelper)
/* 1026:     */   {
/* 1027:1096 */     this.softwareUpdateHelper = softwareUpdateHelper;
/* 1028:     */   }
/* 1029:     */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.BasicMobileDeviceApplication
 * JD-Core Version:    0.7.0.1
 */