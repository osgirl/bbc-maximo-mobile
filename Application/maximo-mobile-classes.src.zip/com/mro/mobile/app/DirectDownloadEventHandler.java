/*   1:    */ package com.mro.mobile.app;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.MobileMessageGenerator;
/*   5:    */ import com.mro.mobile.mbo.MobileMbo;
/*   6:    */ import com.mro.mobile.mbo.MobileMboQBE;
/*   7:    */ import com.mro.mobile.persist.RDOException;
/*   8:    */ import com.mro.mobile.ui.MobileMboDataBean;
/*   9:    */ import com.mro.mobile.ui.MobileMboDataBeanManager;
/*  10:    */ import com.mro.mobile.ui.event.UIEvent;
/*  11:    */ import com.mro.mobile.ui.res.ControlData;
/*  12:    */ import com.mro.mobile.ui.res.UIUtil;
/*  13:    */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*  14:    */ import com.mro.mobile.ui.res.controls.LookupControl;
/*  15:    */ import com.mro.mobile.ui.res.controls.PageControl;
/*  16:    */ 
/*  17:    */ public abstract class DirectDownloadEventHandler
/*  18:    */   extends AppEventHandler
/*  19:    */ {
/*  20:    */   private String mobileMboName;
/*  21:    */   private String mboDescription;
/*  22:    */   private String lookupPageId;
/*  23:    */   private String mainPageId;
/*  24:    */   private String recordClass;
/*  25:    */   private String internalRecordClass;
/*  26:    */   private String recordClassAttribute;
/*  27:    */   private String recordKeyAttribute;
/*  28:    */   private String alreadyDownloadedMsgKey;
/*  29:    */   
/*  30:    */   protected String getMobileMboName()
/*  31:    */   {
/*  32:102 */     return this.mobileMboName;
/*  33:    */   }
/*  34:    */   
/*  35:    */   protected void setMobileMboName(String mobileMboName)
/*  36:    */   {
/*  37:106 */     this.mobileMboName = mobileMboName;
/*  38:    */   }
/*  39:    */   
/*  40:    */   protected String getMboDescription()
/*  41:    */   {
/*  42:110 */     return this.mboDescription;
/*  43:    */   }
/*  44:    */   
/*  45:    */   protected void setMboDescription(String mboDescription)
/*  46:    */   {
/*  47:114 */     this.mboDescription = mboDescription;
/*  48:    */   }
/*  49:    */   
/*  50:    */   protected String getLookupPageId()
/*  51:    */   {
/*  52:118 */     return this.lookupPageId;
/*  53:    */   }
/*  54:    */   
/*  55:    */   protected void setLookupPageId(String lookupPageId)
/*  56:    */   {
/*  57:122 */     this.lookupPageId = lookupPageId;
/*  58:    */   }
/*  59:    */   
/*  60:    */   protected String getMainPageId()
/*  61:    */   {
/*  62:126 */     return this.mainPageId;
/*  63:    */   }
/*  64:    */   
/*  65:    */   protected void setMainPageId(String mainPageId)
/*  66:    */   {
/*  67:130 */     this.mainPageId = mainPageId;
/*  68:    */   }
/*  69:    */   
/*  70:    */   protected String getRecordClass()
/*  71:    */   {
/*  72:134 */     return this.recordClass;
/*  73:    */   }
/*  74:    */   
/*  75:    */   protected void setRecordClass(String recordClass)
/*  76:    */   {
/*  77:138 */     this.recordClass = recordClass;
/*  78:    */   }
/*  79:    */   
/*  80:    */   protected String getInternalRecordClass()
/*  81:    */   {
/*  82:142 */     return this.internalRecordClass;
/*  83:    */   }
/*  84:    */   
/*  85:    */   protected void setInternalRecordClass(String internalRecordClass)
/*  86:    */   {
/*  87:146 */     this.internalRecordClass = internalRecordClass;
/*  88:    */   }
/*  89:    */   
/*  90:    */   protected String getRecordClassAttribute()
/*  91:    */   {
/*  92:150 */     return this.recordClassAttribute;
/*  93:    */   }
/*  94:    */   
/*  95:    */   protected void setRecordClassAttribute(String recordClassAttribute)
/*  96:    */   {
/*  97:154 */     this.recordClassAttribute = recordClassAttribute;
/*  98:    */   }
/*  99:    */   
/* 100:    */   protected String getRecordKeyAttribute()
/* 101:    */   {
/* 102:158 */     return this.recordKeyAttribute;
/* 103:    */   }
/* 104:    */   
/* 105:    */   protected void setRecordKeyAttribute(String recordKeyAttribute)
/* 106:    */   {
/* 107:162 */     this.recordKeyAttribute = recordKeyAttribute;
/* 108:    */   }
/* 109:    */   
/* 110:    */   protected String getAlreadyDownloadedMsgKey()
/* 111:    */   {
/* 112:166 */     return this.alreadyDownloadedMsgKey;
/* 113:    */   }
/* 114:    */   
/* 115:    */   protected void setAlreadyDownloadedMsgKey(String alreadyDownloadedMsgKey)
/* 116:    */   {
/* 117:170 */     this.alreadyDownloadedMsgKey = alreadyDownloadedMsgKey;
/* 118:    */   }
/* 119:    */   
/* 120:    */   public boolean performEvent(UIEvent event)
/* 121:    */     throws MobileApplicationException
/* 122:    */   {
/* 123:187 */     if (event == null) {
/* 124:188 */       return super.performEvent(event);
/* 125:    */     }
/* 126:191 */     String eventId = event.getEventName();
/* 127:193 */     if (eventId.equalsIgnoreCase("initpage")) {
/* 128:194 */       return initpage(event);
/* 129:    */     }
/* 130:195 */     if (eventId.equalsIgnoreCase("setsiteid")) {
/* 131:196 */       return setsiteid(event);
/* 132:    */     }
/* 133:197 */     if (eventId.equalsIgnoreCase("saveclose")) {
/* 134:198 */       return saveclose(event);
/* 135:    */     }
/* 136:199 */     if (eventId.equalsIgnoreCase("cancelpage")) {
/* 137:200 */       return cancelpage(event);
/* 138:    */     }
/* 139:201 */     if (eventId.equalsIgnoreCase("downloadRecord")) {
/* 140:202 */       return downloadRecord(event);
/* 141:    */     }
/* 142:203 */     if (eventId.equalsIgnoreCase("initLookup")) {
/* 143:204 */       return initLookup(event);
/* 144:    */     }
/* 145:205 */     if (eventId.equalsIgnoreCase("lookup")) {
/* 146:206 */       return lookup(event);
/* 147:    */     }
/* 148:208 */     return super.performEvent(event);
/* 149:    */   }
/* 150:    */   
/* 151:    */   protected boolean initpage(UIEvent event)
/* 152:    */     throws MobileApplicationException
/* 153:    */   {
/* 154:219 */     MobileMboDataBean dataBean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/* 155:222 */     if (dataBean.count() == 0) {
/* 156:223 */       dataBean.insert();
/* 157:    */     }
/* 158:226 */     setAlreadyDownloadedMsgKey(null);
/* 159:227 */     setLookupPageId(null);
/* 160:228 */     setMainPageId(null);
/* 161:229 */     setMboDescription(null);
/* 162:230 */     setMobileMboName(null);
/* 163:231 */     setRecordClass(null);
/* 164:232 */     setInternalRecordClass(null);
/* 165:233 */     setRecordClassAttribute(null);
/* 166:234 */     setRecordKeyAttribute(null);
/* 167:    */     
/* 168:    */ 
/* 169:237 */     selectRecordType(event);
/* 170:    */     
/* 171:    */ 
/* 172:240 */     resetRecord(dataBean);
/* 173:    */     
/* 174:242 */     dataBean.getMobileMbo().setReadOnly("ORGID", true);
/* 175:    */     
/* 176:244 */     return true;
/* 177:    */   }
/* 178:    */   
/* 179:    */   protected boolean lookup(UIEvent event)
/* 180:    */   {
/* 181:254 */     AbstractMobileControl textbox = (AbstractMobileControl)event.getCreatingObject();
/* 182:    */     
/* 183:256 */     ControlData data = textbox.getControlData();
/* 184:257 */     data.putValue("lookup", getLookupPageId());
/* 185:258 */     textbox.setControlData(data);
/* 186:    */     
/* 187:260 */     return false;
/* 188:    */   }
/* 189:    */   
/* 190:    */   protected boolean initLookup(UIEvent event)
/* 191:    */     throws MobileApplicationException
/* 192:    */   {
/* 193:270 */     MobileMboDataBean downloadPageDataBean = ((PageControl)event.getCreatingObject()).getLaunchingControl().getPage().getDataBean();
/* 194:271 */     MobileMbo downloadPageMbo = downloadPageDataBean.getMobileMbo();
/* 195:    */     
/* 196:273 */     MobileMboDataBean lookupDataBean = ((LookupControl)event.getCreatingObject()).getDataBean();
/* 197:    */     
/* 198:    */ 
/* 199:276 */     lookupDataBean.setOnline(true);
/* 200:    */     
/* 201:    */ 
/* 202:279 */     lookupDataBean.getQBE().reset();
/* 203:    */     
/* 204:    */ 
/* 205:282 */     lookupDataBean.getQBE().setQbeExactMatch(false);
/* 206:    */     
/* 207:284 */     lookupDataBean.getQBE().setQBE("SITEID", downloadPageMbo.getValue("SITEID"));
/* 208:285 */     if (getRecordClassAttribute() != null) {
/* 209:287 */       lookupDataBean.getQBE().setQBE(getRecordClassAttribute(), getInternalRecordClass());
/* 210:    */     }
/* 211:289 */     lookupDataBean.reset();
/* 212:    */     
/* 213:291 */     return true;
/* 214:    */   }
/* 215:    */   
/* 216:    */   public boolean saveclose(UIEvent event)
/* 217:    */     throws MobileApplicationException
/* 218:    */   {
/* 219:302 */     AbstractMobileControl creatingControl = (AbstractMobileControl)event.getCreatingObject();
/* 220:303 */     MobileMbo mbo = creatingControl.getDataBean().getMobileMbo();
/* 221:305 */     if (!mbo.isNull("RECORDKEY"))
/* 222:    */     {
/* 223:307 */       String recordKey = mbo.getValue("RECORDKEY");
/* 224:308 */       String siteId = mbo.getValue("SITEID");
/* 225:310 */       if (isAlreadyDownloaded(recordKey, siteId)) {
/* 226:313 */         UIUtil.showInfoMessageBox(MobileMessageGenerator.generate(getAlreadyDownloadedMsgKey(), new Object[] { getMboDescription(), recordKey }));
/* 227:319 */       } else if (!existsInServer(recordKey, siteId)) {
/* 228:322 */         UIUtil.showInfoMessageBox(MobileMessageGenerator.generate("notfound", new Object[] { getMboDescription(), recordKey, siteId }));
/* 229:    */       } else {
/* 230:329 */         creatingControl.handleEvent("downloadRecord", null, null);
/* 231:    */       }
/* 232:    */     }
/* 233:337 */     return true;
/* 234:    */   }
/* 235:    */   
/* 236:    */   protected abstract boolean downloadRecord(UIEvent paramUIEvent)
/* 237:    */     throws MobileApplicationException;
/* 238:    */   
/* 239:    */   protected boolean setsiteid(UIEvent event)
/* 240:    */     throws MobileApplicationException
/* 241:    */   {
/* 242:352 */     MobileMboDataBean dataBean = ((AbstractMobileControl)event.getCreatingObject()).getDataBean();
/* 243:    */     
/* 244:354 */     String siteId = (String)event.getValue();
/* 245:    */     
/* 246:    */ 
/* 247:    */ 
/* 248:    */ 
/* 249:359 */     MobileMbo siteMbo = getSiteByKey(siteId);
/* 250:360 */     if (siteMbo == null) {
/* 251:362 */       return true;
/* 252:    */     }
/* 253:365 */     if ((siteId == null) || (siteId.equals("")))
/* 254:    */     {
/* 255:366 */       resetRecord(dataBean);
/* 256:367 */       siteId = dataBean.getValue("SITEID");
/* 257:368 */       event.setValue(siteId);
/* 258:    */     }
/* 259:372 */     String orgId = siteMbo.getValue("ORGID");
/* 260:    */     
/* 261:374 */     dataBean.setValue("ORGID", orgId, false);
/* 262:    */     
/* 263:376 */     return true;
/* 264:    */   }
/* 265:    */   
/* 266:    */   protected String loadMboDescription(String mboName, String recordClass)
/* 267:    */   {
/* 268:397 */     String messageKey = "desc_" + mboName + (recordClass != null ? "_" + recordClass : "");
/* 269:    */     
/* 270:399 */     return MobileMessageGenerator.generate(messageKey, null);
/* 271:    */   }
/* 272:    */   
/* 273:    */   protected abstract void selectRecordType(UIEvent paramUIEvent)
/* 274:    */     throws MobileApplicationException;
/* 275:    */   
/* 276:    */   protected void resetRecord(MobileMboDataBean dataBean)
/* 277:    */     throws MobileApplicationException
/* 278:    */   {
/* 279:417 */     dataBean.setValue("RECORDKEY", null, false);
/* 280:418 */     dataBean.setValue("ORGID", UIUtil.getApplication().getDefaultInsertOrg(), false);
/* 281:419 */     dataBean.setValue("SITEID", UIUtil.getApplication().getDefaultInsertSite(), false);
/* 282:    */   }
/* 283:    */   
/* 284:    */   protected boolean isAlreadyDownloaded(String recordKey, String siteId)
/* 285:    */     throws MobileApplicationException
/* 286:    */   {
/* 287:438 */     MobileMbo mbo = getRecordByKey(recordKey, siteId, false);
/* 288:440 */     if (mbo != null) {
/* 289:441 */       return true;
/* 290:    */     }
/* 291:443 */     return false;
/* 292:    */   }
/* 293:    */   
/* 294:    */   protected boolean existsInServer(String recordKey, String siteId)
/* 295:    */     throws MobileApplicationException
/* 296:    */   {
/* 297:456 */     MobileMbo mbo = getRecordByKey(recordKey, siteId, true);
/* 298:458 */     if (mbo != null) {
/* 299:459 */       return true;
/* 300:    */     }
/* 301:461 */     return false;
/* 302:    */   }
/* 303:    */   
/* 304:    */   protected String getRecordID(String recordKey, String siteId)
/* 305:    */     throws RDOException, MobileApplicationException
/* 306:    */   {
/* 307:474 */     MobileMbo mbo = getRecordByKey(recordKey, siteId, true);
/* 308:476 */     if (mbo != null) {
/* 309:477 */       return mbo.getValue("_ID");
/* 310:    */     }
/* 311:479 */     return null;
/* 312:    */   }
/* 313:    */   
/* 314:    */   protected MobileMbo getRecordByKey(String recordKey, String siteId, boolean getOnline)
/* 315:    */     throws MobileApplicationException, RDOException
/* 316:    */   {
/* 317:493 */     MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager(getMobileMboName());
/* 318:494 */     MobileMboDataBean bean = mgrDBMgr.getDataBean();
/* 319:495 */     bean.getQBE().reset();
/* 320:496 */     bean.getQBE().setQbeExactMatch(true);
/* 321:497 */     bean.getQBE().setQBE(getRecordKeyAttribute(), recordKey);
/* 322:498 */     if (getRecordClassAttribute() != null) {
/* 323:500 */       bean.getQBE().setQBE(getRecordClassAttribute(), getInternalRecordClass());
/* 324:    */     }
/* 325:502 */     bean.getQBE().setQBE("SITEID", siteId);
/* 326:503 */     bean.setOnline(getOnline);
/* 327:504 */     bean.reset();
/* 328:506 */     if (bean.count() > 0) {
/* 329:507 */       return bean.getMobileMbo();
/* 330:    */     }
/* 331:509 */     return null;
/* 332:    */   }
/* 333:    */   
/* 334:    */   protected MobileMbo getRecordById(String mobileMboName, String recordId, boolean getOnline)
/* 335:    */     throws MobileApplicationException, RDOException
/* 336:    */   {
/* 337:523 */     MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager(mobileMboName);
/* 338:524 */     MobileMboDataBean bean = mgrDBMgr.getDataBean();
/* 339:525 */     bean.getQBE().reset();
/* 340:526 */     bean.getQBE().setQbeExactMatch(true);
/* 341:527 */     bean.getQBE().setQBE("_ID", recordId);
/* 342:528 */     bean.setOnline(getOnline);
/* 343:529 */     bean.reset();
/* 344:530 */     return bean.getMobileMbo();
/* 345:    */   }
/* 346:    */   
/* 347:    */   public static MobileMbo getSiteByKey(String siteId)
/* 348:    */     throws MobileApplicationException
/* 349:    */   {
/* 350:541 */     MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager("SITE");
/* 351:542 */     MobileMboDataBean bean = mgrDBMgr.getDataBean();
/* 352:543 */     bean.getQBE().reset();
/* 353:544 */     bean.getQBE().setQbeExactMatch(true);
/* 354:545 */     bean.getQBE().setQBE("SITEID", siteId);
/* 355:546 */     bean.reset();
/* 356:548 */     if (bean.count() > 0) {
/* 357:549 */       return bean.getMobileMbo();
/* 358:    */     }
/* 359:551 */     return null;
/* 360:    */   }
/* 361:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.DirectDownloadEventHandler
 * JD-Core Version:    0.7.0.1
 */