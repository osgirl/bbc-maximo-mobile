package com.mro.mobile.app.userlocation;

import com.mro.mobile.userlocation.UserLocationDataInfo;

public abstract interface UserLocationProvider
{
  public abstract boolean hasLocationProviderEnabled();
  
  public abstract void initialize();
  
  public abstract void shutdown();
  
  public abstract UserLocationDataInfo getCurrentUserLocation();
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.app.userlocation.UserLocationProvider
 * JD-Core Version:    0.7.0.1
 */