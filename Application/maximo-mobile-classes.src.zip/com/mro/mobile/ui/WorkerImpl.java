/*  1:   */ package com.mro.mobile.ui;
/*  2:   */ 
/*  3:   */ import com.mro.mobile.ProgressObserver;
/*  4:   */ import com.mro.mobile.app.MobileDeviceAppSession;
/*  5:   */ import com.mro.mobile.app.async.AsynchronousExecutor;
/*  6:   */ import com.mro.mobile.util.MobileLogger;
/*  7:   */ import com.mro.mobile.util.MobileLoggerFactory;
/*  8:   */ 
/*  9:   */ public class WorkerImpl
/* 10:   */   implements Runnable
/* 11:   */ {
/* 12:24 */   private Worker worker = null;
/* 13:25 */   private WorkDetails workDetails = null;
/* 14:26 */   private ProgressObserver observer = null;
/* 15:   */   private AsynchronousExecutor executor;
/* 16:   */   
/* 17:   */   public WorkerImpl(Worker worker, WorkDetails workDetails, ProgressObserver observer, AsynchronousExecutor executor)
/* 18:   */   {
/* 19:30 */     this.worker = worker;
/* 20:31 */     this.workDetails = workDetails;
/* 21:32 */     this.observer = observer;
/* 22:33 */     this.executor = executor;
/* 23:   */   }
/* 24:   */   
/* 25:   */   public void run()
/* 26:   */   {
/* 27:   */     try
/* 28:   */     {
/* 29:38 */       Throwable workFailedWithException = null;
/* 30:   */       try
/* 31:   */       {
/* 32:40 */         MobileDeviceAppSession.getSession().setBackgroudThread(true);
/* 33:   */         
/* 34:   */ 
/* 35:   */ 
/* 36:   */ 
/* 37:45 */         this.worker.doWork(this.workDetails, this.observer);
/* 38:   */       }
/* 39:   */       catch (Throwable e)
/* 40:   */       {
/* 41:48 */         workFailedWithException = e;
/* 42:   */       }
/* 43:51 */       if (this.observer.isWorkStopped()) {
/* 44:52 */         this.executor.scheduleForAsyncExecution(new WorkStatusNotifier(1, this.workDetails, null));
/* 45:53 */       } else if (workFailedWithException != null) {
/* 46:54 */         this.executor.scheduleForAsyncExecution(new WorkStatusNotifier(2, this.workDetails, workFailedWithException));
/* 47:   */       } else {
/* 48:56 */         this.executor.scheduleForAsyncExecution(new WorkStatusNotifier(3, this.workDetails, workFailedWithException));
/* 49:   */       }
/* 50:   */     }
/* 51:   */     finally
/* 52:   */     {
/* 53:60 */       MobileDeviceAppSession.getSession().setBackgroudThread(false);
/* 54:   */     }
/* 55:   */   }
/* 56:   */   
/* 57:   */   class WorkStatusNotifier
/* 58:   */     implements Runnable
/* 59:   */   {
/* 60:65 */     private int status = 0;
/* 61:66 */     private WorkDetails workDetails = null;
/* 62:67 */     private Throwable t = null;
/* 63:   */     
/* 64:   */     public WorkStatusNotifier(int status, WorkDetails workDetails, Throwable t)
/* 65:   */     {
/* 66:70 */       this.status = status;
/* 67:71 */       this.workDetails = workDetails;
/* 68:72 */       this.t = t;
/* 69:   */     }
/* 70:   */     
/* 71:   */     public void run()
/* 72:   */     {
/* 73:   */       try
/* 74:   */       {
/* 75:77 */         if (this.status == 1) {
/* 76:78 */           WorkerImpl.this.worker.workStopped(this.workDetails);
/* 77:79 */         } else if (this.status == 2) {
/* 78:80 */           WorkerImpl.this.worker.workFailed(this.workDetails, this.t);
/* 79:81 */         } else if (this.status == 3) {
/* 80:82 */           WorkerImpl.this.worker.workCompleted(this.workDetails);
/* 81:   */         }
/* 82:   */       }
/* 83:   */       catch (Exception ex)
/* 84:   */       {
/* 85:85 */         MobileLoggerFactory.getDefaultLogger().warn("Error encountered during work status notifier", ex);
/* 86:   */       }
/* 87:   */     }
/* 88:   */   }
/* 89:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.WorkerImpl
 * JD-Core Version:    0.7.0.1
 */