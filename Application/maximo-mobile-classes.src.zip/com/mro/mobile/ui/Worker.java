package com.mro.mobile.ui;

import com.mro.mobile.MobileApplicationException;
import com.mro.mobile.ProgressObserver;

public abstract interface Worker
{
  public abstract void doWork(WorkDetails paramWorkDetails, ProgressObserver paramProgressObserver)
    throws MobileApplicationException;
  
  public abstract void workCompleted(WorkDetails paramWorkDetails)
    throws MobileApplicationException;
  
  public abstract void workStopped(WorkDetails paramWorkDetails)
    throws MobileApplicationException;
  
  public abstract void workFailed(WorkDetails paramWorkDetails, Throwable paramThrowable)
    throws MobileApplicationException;
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.Worker
 * JD-Core Version:    0.7.0.1
 */