/*   1:    */ package com.mro.mobile.ui;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.MobileMessageGenerator;
/*   5:    */ import com.mro.mobile.mbo.MobileMbo;
/*   6:    */ import com.mro.mobile.util.MobileLogger;
/*   7:    */ import com.mro.mobile.util.MobileLoggerFactory;
/*   8:    */ import java.util.Hashtable;
/*   9:    */ import java.util.Vector;
/*  10:    */ 
/*  11:    */ public class MobileMboDataBeanIndexer
/*  12:    */ {
/*  13: 30 */   private Hashtable map = new Hashtable();
/*  14:    */   
/*  15:    */   MobileMboDataBeanIndexer(MobileMboDataBean bean, String[] attributes, boolean closed)
/*  16:    */     throws MobileApplicationException
/*  17:    */   {
/*  18: 42 */     if (!closed)
/*  19:    */     {
/*  20: 44 */       String formattedMsg = MobileMessageGenerator.generate("databeanmustbeclose", null);
/*  21: 45 */       throw new IllegalArgumentException(formattedMsg);
/*  22:    */     }
/*  23: 47 */     int i = 0;
/*  24: 49 */     if (bean.isOnline())
/*  25:    */     {
/*  26: 51 */       Exception realException = new Exception("Connected databean cannot be indexed.");
/*  27: 52 */       MobileLoggerFactory.getDefaultLogger().warn("Connected databean cannont be indexed", realException);
/*  28: 53 */       throw new MobileApplicationException("internalerror", realException);
/*  29:    */     }
/*  30:    */     for (;;)
/*  31:    */     {
/*  32: 57 */       MobileMbo mbo = bean.getMobileMbo(i++);
/*  33: 58 */       if (mbo == null) {
/*  34:    */         break;
/*  35:    */       }
/*  36: 61 */       indexMobileMbo(this.map, mbo, attributes, 0);
/*  37:    */     }
/*  38:    */   }
/*  39:    */   
/*  40:    */   private void indexMobileMbo(Hashtable cache, MobileMbo mbo, String[] attributes, int position)
/*  41:    */     throws MobileApplicationException
/*  42:    */   {
/*  43: 66 */     if (position < attributes.length)
/*  44:    */     {
/*  45: 67 */       StringKey key = new StringKey(mbo.getValue(attributes[position]));
/*  46: 68 */       Node node = (Node)cache.get(key);
/*  47: 69 */       if (node == null)
/*  48:    */       {
/*  49: 70 */         node = new Node(null);
/*  50: 71 */         cache.put(key, node);
/*  51:    */       }
/*  52: 73 */       node.addMobileMbo(mbo);
/*  53: 74 */       indexMobileMbo(node.getChildren(), mbo, attributes, position + 1);
/*  54:    */     }
/*  55:    */   }
/*  56:    */   
/*  57:    */   public Vector getIndexedMobileMbos(String[] values)
/*  58:    */   {
/*  59: 85 */     Node target = null;
/*  60: 86 */     Hashtable cache = this.map;
/*  61: 87 */     for (int i = 0; i < values.length; i++)
/*  62:    */     {
/*  63: 88 */       StringKey key = new StringKey(values[i]);
/*  64:    */       
/*  65: 90 */       target = (Node)cache.get(key);
/*  66: 91 */       if (target != null) {
/*  67: 92 */         cache = target.getChildren();
/*  68:    */       } else {
/*  69: 94 */         return new Vector();
/*  70:    */       }
/*  71:    */     }
/*  72: 97 */     if (target != null) {
/*  73: 98 */       return target.getMobileMbos();
/*  74:    */     }
/*  75:100 */     return new Vector();
/*  76:    */   }
/*  77:    */   
/*  78:    */   public MobileMbo getIndexedMobileMbo(String[] uniqueValue)
/*  79:    */   {
/*  80:110 */     Vector vector = getIndexedMobileMbos(uniqueValue);
/*  81:111 */     if (vector.size() != 1) {
/*  82:112 */       return null;
/*  83:    */     }
/*  84:114 */     return (MobileMbo)vector.get(0);
/*  85:    */   }
/*  86:    */   
/*  87:    */   private static class Node
/*  88:    */   {
/*  89:119 */     private Vector mobileMbos = new Vector();
/*  90:121 */     private Hashtable children = new Hashtable(0);
/*  91:    */     
/*  92:    */     Vector getMobileMbos()
/*  93:    */     {
/*  94:124 */       return this.mobileMbos;
/*  95:    */     }
/*  96:    */     
/*  97:    */     Hashtable getChildren()
/*  98:    */     {
/*  99:129 */       return this.children;
/* 100:    */     }
/* 101:    */     
/* 102:    */     boolean hasChildren()
/* 103:    */     {
/* 104:133 */       return !this.children.isEmpty();
/* 105:    */     }
/* 106:    */     
/* 107:    */     void addMobileMbo(MobileMbo mbo)
/* 108:    */     {
/* 109:137 */       this.mobileMbos.add(mbo);
/* 110:    */     }
/* 111:    */   }
/* 112:    */   
/* 113:    */   private static class StringKey
/* 114:    */   {
/* 115:143 */     String key = null;
/* 116:    */     
/* 117:    */     StringKey(String key)
/* 118:    */     {
/* 119:147 */       this.key = key;
/* 120:    */     }
/* 121:    */     
/* 122:    */     public int hashCode()
/* 123:    */     {
/* 124:151 */       int result = 0;
/* 125:152 */       String tempKey = this.key;
/* 126:153 */       result = this.key == null ? 0 : tempKey.hashCode();
/* 127:154 */       return result;
/* 128:    */     }
/* 129:    */     
/* 130:    */     public boolean equals(Object obj)
/* 131:    */     {
/* 132:158 */       if (this == obj) {
/* 133:159 */         return true;
/* 134:    */       }
/* 135:161 */       if (obj == null) {
/* 136:162 */         return false;
/* 137:    */       }
/* 138:164 */       if (!(obj instanceof StringKey)) {
/* 139:165 */         return false;
/* 140:    */       }
/* 141:167 */       StringKey other = (StringKey)obj;
/* 142:168 */       if (this.key == null)
/* 143:    */       {
/* 144:169 */         if (other.key != null) {
/* 145:170 */           return false;
/* 146:    */         }
/* 147:    */       }
/* 148:    */       else {
/* 149:174 */         return this.key.equalsIgnoreCase(other.key);
/* 150:    */       }
/* 151:176 */       return true;
/* 152:    */     }
/* 153:    */     
/* 154:    */     public String toString()
/* 155:    */     {
/* 156:181 */       return this.key;
/* 157:    */     }
/* 158:    */   }
/* 159:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.MobileMboDataBeanIndexer
 * JD-Core Version:    0.7.0.1
 */