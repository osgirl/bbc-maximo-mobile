/*  1:   */ package com.mro.mobile.ui;
/*  2:   */ 
/*  3:   */ import java.util.Hashtable;
/*  4:   */ 
/*  5:   */ public class UIDGenerator
/*  6:   */ {
/*  7:20 */   private static Hashtable idMap = new Hashtable();
/*  8:   */   
/*  9:   */   public static long generateID(String name)
/* 10:   */   {
/* 11:25 */     synchronized (idMap)
/* 12:   */     {
/* 13:27 */       Object obj = idMap.get(name);
/* 14:28 */       if (obj == null)
/* 15:   */       {
/* 16:30 */         long id = -1L * System.currentTimeMillis();
/* 17:   */         
/* 18:32 */         idMap.put(name.toUpperCase(), new Long(id));
/* 19:33 */         return id;
/* 20:   */       }
/* 21:37 */       Long lastId = (Long)obj;
/* 22:38 */       long id = lastId.longValue() + -1L;
/* 23:39 */       idMap.put(name.toUpperCase(), new Long(id));
/* 24:40 */       return id;
/* 25:   */     }
/* 26:   */   }
/* 27:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.UIDGenerator
 * JD-Core Version:    0.7.0.1
 */