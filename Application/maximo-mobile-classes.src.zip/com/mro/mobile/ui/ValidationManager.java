/*  1:   */ package com.mro.mobile.ui;
/*  2:   */ 
/*  3:   */ import com.mro.mobile.MobileApplicationException;
/*  4:   */ import com.mro.mobile.mbo.MobileMbo;
/*  5:   */ import com.mro.mobile.mbo.MobileMboInfo;
/*  6:   */ import com.mro.mobile.mbo.MobileMboQBE;
/*  7:   */ 
/*  8:   */ public class ValidationManager
/*  9:   */ {
/* 10:   */   public void validate(MobileMboDataBean sourceDataBean, String sourceAttribute, String valueToValidate, String domainName, String domainAttribute)
/* 11:   */     throws MobileApplicationException
/* 12:   */   {
/* 13:38 */     LookupManager lookupManager = new LookupManager();
/* 14:39 */     MobileMboDataBean domainDataBean = lookupManager.createLookupDomainBean(domainName);
/* 15:   */     
/* 16:   */ 
/* 17:42 */     MobileMboDataFormatter formatter = MobileMboDataFormatter.getInstance();
/* 18:43 */     if (formatter != null) {
/* 19:45 */       valueToValidate = formatter.formatDisplayToInternal(valueToValidate, sourceDataBean.getMobileMboInfo().getAttributeInfo(sourceAttribute));
/* 20:   */     }
/* 21:49 */     lookupManager.applyMultisiteFilter(domainDataBean, sourceDataBean);
/* 22:   */     
/* 23:51 */     domainDataBean.getQBE().setQBE(domainAttribute, "=" + valueToValidate);
/* 24:52 */     domainDataBean.reset();
/* 25:53 */     MobileMbo domainMobileMbo = domainDataBean.getMobileMbo(0);
/* 26:54 */     if (domainMobileMbo == null)
/* 27:   */     {
/* 28:56 */       domainDataBean.reset();
/* 29:57 */       throw new MobileApplicationException("invalidvalue");
/* 30:   */     }
/* 31:60 */     domainDataBean.reset();
/* 32:   */   }
/* 33:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.ValidationManager
 * JD-Core Version:    0.7.0.1
 */