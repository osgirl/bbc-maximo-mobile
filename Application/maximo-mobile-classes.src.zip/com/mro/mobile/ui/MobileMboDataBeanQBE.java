/*   1:    */ package com.mro.mobile.ui;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.MobileMessageGenerator;
/*   5:    */ import com.mro.mobile.mbo.MobileMboAttributeInfo;
/*   6:    */ import com.mro.mobile.mbo.MobileMboInfo;
/*   7:    */ import com.mro.mobile.mbo.MobileMboQBE;
/*   8:    */ import com.mro.mobile.mbo.MobileMboUtil;
/*   9:    */ import com.mro.mobile.persist.QBE;
/*  10:    */ import com.mro.mobile.persist.RDOException;
/*  11:    */ import java.util.ArrayList;
/*  12:    */ import java.util.Date;
/*  13:    */ import java.util.Enumeration;
/*  14:    */ import java.util.Hashtable;
/*  15:    */ 
/*  16:    */ public class MobileMboDataBeanQBE
/*  17:    */   extends MobileMboQBE
/*  18:    */ {
/*  19: 33 */   private String appName = null;
/*  20: 34 */   private String name = null;
/*  21: 35 */   private Hashtable qbeDisplayValues = new Hashtable();
/*  22: 36 */   private Hashtable qbeBackupValues = null;
/*  23: 37 */   private Hashtable qbeDefaultValues = null;
/*  24: 38 */   private Hashtable backupQbeDisplayValues = null;
/*  25: 40 */   private boolean filtered = false;
/*  26:    */   
/*  27:    */   protected void saveSpecificState()
/*  28:    */   {
/*  29: 45 */     this.backupQbeDisplayValues = ((Hashtable)this.qbeDisplayValues.clone());
/*  30:    */   }
/*  31:    */   
/*  32:    */   protected void restoreSpecificState()
/*  33:    */   {
/*  34: 50 */     this.qbeDisplayValues = this.backupQbeDisplayValues;
/*  35: 51 */     this.backupQbeDisplayValues = null;
/*  36:    */   }
/*  37:    */   
/*  38:    */   public MobileMboDataBeanQBE(String appName, String name)
/*  39:    */   {
/*  40: 56 */     this.appName = appName;
/*  41: 57 */     this.name = name;
/*  42:    */   }
/*  43:    */   
/*  44:    */   public String getQBE(String attributeName)
/*  45:    */     throws RDOException
/*  46:    */   {
/*  47: 63 */     return (String)this.qbeDisplayValues.get(attributeName);
/*  48:    */   }
/*  49:    */   
/*  50:    */   public String getInternalQBE(String attributeName)
/*  51:    */     throws RDOException
/*  52:    */   {
/*  53: 68 */     return super.getQBE(attributeName);
/*  54:    */   }
/*  55:    */   
/*  56:    */   public void setQBE(String attributeName, String value)
/*  57:    */     throws RDOException
/*  58:    */   {
/*  59: 73 */     if ((value == null) || (value.trim().length() == 0))
/*  60:    */     {
/*  61: 75 */       this.qbeDisplayValues.remove(attributeName);
/*  62: 76 */       setInternalQBE(attributeName, value);
/*  63: 77 */       return;
/*  64:    */     }
/*  65: 81 */     value = value.trim();
/*  66:    */     
/*  67:    */ 
/*  68: 84 */     MobileMboInfo mboInfo = MobileMboUtil.getMobileMboInfo(this.appName, this.name);
/*  69: 85 */     MobileMboAttributeInfo attrInfo = mboInfo.getAttributeInfo(attributeName);
/*  70: 86 */     if (attrInfo.getDataType() == 9)
/*  71:    */     {
/*  72: 88 */       int conditionIndex = getConditionExpression(value);
/*  73:    */       
/*  74: 90 */       String valueWithoutCondition = value;
/*  75: 92 */       if (conditionIndex >= 0) {
/*  76: 95 */         valueWithoutCondition = value.substring(QBE.EXPRLIST[conditionIndex].length());
/*  77:    */       }
/*  78: 98 */       MobileMboDataFormatter formatter = MobileMboDataFormatter.getInstance();
/*  79: 99 */       if (formatter != null) {
/*  80:    */         try
/*  81:    */         {
/*  82:103 */           Date dateQbeValue = formatter.convertStringToDate(valueWithoutCondition);
/*  83:105 */           if (conditionIndex >= 0) {
/*  84:107 */             super.setDateQBE(attributeName, value, dateQbeValue, QBE.EXPRLIST[conditionIndex]);
/*  85:    */           } else {
/*  86:111 */             super.setDateQBE(attributeName, value, dateQbeValue, "");
/*  87:    */           }
/*  88:114 */           this.qbeDisplayValues.put(attributeName, value);
/*  89:    */         }
/*  90:    */         catch (MobileApplicationException e)
/*  91:    */         {
/*  92:118 */           throw new RDOException(e.getKey(), e.getParams(), e.getNestedException());
/*  93:    */         }
/*  94:    */       }
/*  95:    */     }
/*  96:122 */     else if (attrInfo.getDataType() == 11)
/*  97:    */     {
/*  98:124 */       int conditionIndex = getConditionExpression(value);
/*  99:    */       
/* 100:126 */       String valueWithoutCondition = value;
/* 101:128 */       if (conditionIndex >= 0) {
/* 102:131 */         valueWithoutCondition = value.substring(QBE.EXPRLIST[conditionIndex].length());
/* 103:    */       }
/* 104:134 */       MobileMboDataFormatter formatter = MobileMboDataFormatter.getInstance();
/* 105:135 */       if (formatter != null) {
/* 106:    */         try
/* 107:    */         {
/* 108:139 */           Date dateQbeValue = formatter.convertStringToDateTime(valueWithoutCondition);
/* 109:140 */           if (conditionIndex >= 0) {
/* 110:142 */             super.setDateQBE(attributeName, value, dateQbeValue, QBE.EXPRLIST[conditionIndex]);
/* 111:    */           } else {
/* 112:146 */             super.setDateQBE(attributeName, value, dateQbeValue, "");
/* 113:    */           }
/* 114:149 */           this.qbeDisplayValues.put(attributeName, value);
/* 115:    */         }
/* 116:    */         catch (MobileApplicationException e)
/* 117:    */         {
/* 118:153 */           throw new RDOException(e.getKey(), e.getParams(), e.getNestedException());
/* 119:    */         }
/* 120:    */       }
/* 121:    */     }
/* 122:157 */     else if (attrInfo.getDataType() == 10)
/* 123:    */     {
/* 124:159 */       int conditionIndex = getConditionExpression(value);
/* 125:    */       
/* 126:161 */       String valueWithoutCondition = value;
/* 127:163 */       if (conditionIndex >= 0) {
/* 128:166 */         valueWithoutCondition = value.substring(QBE.EXPRLIST[conditionIndex].length());
/* 129:    */       }
/* 130:169 */       MobileMboDataFormatter formatter = MobileMboDataFormatter.getInstance();
/* 131:170 */       if (formatter != null) {
/* 132:    */         try
/* 133:    */         {
/* 134:174 */           Date dateQbeValue = formatter.convertStringToTime(valueWithoutCondition);
/* 135:176 */           if (conditionIndex >= 0) {
/* 136:178 */             super.setDateQBE(attributeName, value, dateQbeValue, QBE.EXPRLIST[conditionIndex]);
/* 137:    */           } else {
/* 138:182 */             super.setDateQBE(attributeName, value, dateQbeValue, "");
/* 139:    */           }
/* 140:184 */           this.qbeDisplayValues.put(attributeName, value);
/* 141:    */         }
/* 142:    */         catch (MobileApplicationException e)
/* 143:    */         {
/* 144:188 */           throw new RDOException(e.getKey(), e.getParams(), e.getNestedException());
/* 145:    */         }
/* 146:    */       }
/* 147:    */     }
/* 148:192 */     else if (attrInfo.getDataType() == 8)
/* 149:    */     {
/* 150:194 */       String yesValue = MobileMessageGenerator.generate("YES", new Object[0]);
/* 151:195 */       String noValue = MobileMessageGenerator.generate("NO", new Object[0]);
/* 152:197 */       if ((value.equals("true")) || (value.equals("1")) || (value.equalsIgnoreCase(yesValue)))
/* 153:    */       {
/* 154:199 */         setInternalQBE(attributeName, "1");
/* 155:200 */         this.qbeDisplayValues.put(attributeName, yesValue);
/* 156:    */       }
/* 157:    */       else
/* 158:    */       {
/* 159:204 */         setInternalQBE(attributeName, "0");
/* 160:205 */         this.qbeDisplayValues.put(attributeName, noValue);
/* 161:    */       }
/* 162:    */     }
/* 163:    */     else
/* 164:    */     {
/* 165:211 */       int conditionIndex = getConditionExpression(value);
/* 166:    */       
/* 167:213 */       String valueWithoutCondition = value;
/* 168:    */       
/* 169:    */ 
/* 170:216 */       String conditionStr = "";
/* 171:217 */       if (conditionIndex >= 0)
/* 172:    */       {
/* 173:220 */         valueWithoutCondition = value.substring(QBE.EXPRLIST[conditionIndex].length());
/* 174:221 */         conditionStr = value.substring(0, QBE.EXPRLIST[conditionIndex].length());
/* 175:    */       }
/* 176:224 */       MobileMboDataFormatter formatter = MobileMboDataFormatter.getInstance();
/* 177:225 */       if (formatter != null) {
/* 178:    */         try
/* 179:    */         {
/* 180:230 */           String qbeInternalValue = null;
/* 181:231 */           if (!"~NULL~".equalsIgnoreCase(valueWithoutCondition))
/* 182:    */           {
/* 183:236 */             if ((attrInfo.getDataType() == 4) || (attrInfo.getDataType() == 5) || (attrInfo.getDataType() == 6) || (attrInfo.getDataType() == 7))
/* 184:    */             {
/* 185:240 */               if (valueWithoutCondition.indexOf(";") >= 0)
/* 186:    */               {
/* 187:241 */                 String[] values = split(valueWithoutCondition, ';');
/* 188:242 */                 StringBuffer buff = new StringBuffer("");
/* 189:243 */                 for (int i = 0; i < values.length; i++)
/* 190:    */                 {
/* 191:244 */                   buff.append(formatter.formatDisplayToInternal(values[i], attrInfo, false));
/* 192:245 */                   buff.append(",");
/* 193:    */                 }
/* 194:247 */                 buff.deleteCharAt(buff.length() - 1);
/* 195:248 */                 qbeInternalValue = buff.toString();
/* 196:    */               }
/* 197:    */               else
/* 198:    */               {
/* 199:251 */                 qbeInternalValue = conditionStr + formatter.formatDisplayToInternal(valueWithoutCondition, attrInfo, false);
/* 200:    */               }
/* 201:    */             }
/* 202:    */             else {
/* 203:255 */               qbeInternalValue = conditionStr + formatter.formatDisplayToInternal(valueWithoutCondition, attrInfo, false);
/* 204:    */             }
/* 205:259 */             if (attrInfo.getDataType() == 13)
/* 206:    */             {
/* 207:261 */               int separatorIndex = qbeInternalValue.indexOf(".");
/* 208:262 */               if (separatorIndex == -1) {
/* 209:264 */                 separatorIndex = qbeInternalValue.indexOf(",");
/* 210:    */               }
/* 211:266 */               int precision = 4;
/* 212:267 */               if ((separatorIndex > -1) && (separatorIndex + precision < qbeInternalValue.length())) {
/* 213:269 */                 qbeInternalValue = qbeInternalValue.substring(0, separatorIndex + precision + 1);
/* 214:    */               }
/* 215:    */             }
/* 216:    */           }
/* 217:    */           else
/* 218:    */           {
/* 219:275 */             qbeInternalValue = value;
/* 220:    */           }
/* 221:277 */           setInternalQBE(attributeName, qbeInternalValue);
/* 222:278 */           this.qbeDisplayValues.put(attributeName, value);
/* 223:    */         }
/* 224:    */         catch (MobileApplicationException e)
/* 225:    */         {
/* 226:282 */           throw new RDOException(e.getKey(), e.getParams(), e.getNestedException());
/* 227:    */         }
/* 228:    */       }
/* 229:    */     }
/* 230:    */   }
/* 231:    */   
/* 232:    */   private String[] split(String value, char c)
/* 233:    */   {
/* 234:289 */     ArrayList list = new ArrayList();
/* 235:290 */     int pos = -1;
/* 236:291 */     while ((pos = value.indexOf(c)) >= 0)
/* 237:    */     {
/* 238:292 */       String token = value.substring(0, pos);
/* 239:293 */       value = value.substring(pos + 1);
/* 240:294 */       list.add(token);
/* 241:    */     }
/* 242:296 */     list.add(value);
/* 243:297 */     String[] result = new String[list.size()];
/* 244:298 */     for (int i = 0; i < list.size(); i++) {
/* 245:299 */       result[i] = ((String)list.get(i));
/* 246:    */     }
/* 247:301 */     return result;
/* 248:    */   }
/* 249:    */   
/* 250:    */   public void setInternalQBE(String attributeName, String value)
/* 251:    */     throws RDOException
/* 252:    */   {
/* 253:306 */     super.setQBE(attributeName, value);
/* 254:    */   }
/* 255:    */   
/* 256:    */   public MobileMboQBE getInternal()
/* 257:    */     throws RDOException
/* 258:    */   {
/* 259:311 */     MobileMboQBE internal = new MobileMboQBE();
/* 260:    */     
/* 261:313 */     Enumeration attrEnum = getQBEAttributes();
/* 262:314 */     while (attrEnum.hasMoreElements())
/* 263:    */     {
/* 264:316 */       String attributeName = (String)attrEnum.nextElement();
/* 265:317 */       internal.setQBE(attributeName, getInternalQBE(attributeName));
/* 266:    */     }
/* 267:320 */     copyLookupParameters(internal);
/* 268:321 */     internal.setQbeExactMatch(isQbeExactMatch());
/* 269:    */     
/* 270:323 */     return internal;
/* 271:    */   }
/* 272:    */   
/* 273:    */   private int getConditionExpression(String qbeValue)
/* 274:    */   {
/* 275:328 */     for (int i = 0; i < QBE.EXPRLIST.length; i++)
/* 276:    */     {
/* 277:330 */       String condition = QBE.EXPRLIST[i];
/* 278:331 */       if (qbeValue.length() >= condition.length()) {
/* 279:333 */         if (qbeValue.startsWith(condition)) {
/* 280:335 */           return i;
/* 281:    */         }
/* 282:    */       }
/* 283:    */     }
/* 284:340 */     return -1;
/* 285:    */   }
/* 286:    */   
/* 287:    */   public void saveCurrentQBEValues()
/* 288:    */   {
/* 289:345 */     this.qbeBackupValues = new Hashtable();
/* 290:346 */     boolean saveDefaults = this.qbeDefaultValues == null;
/* 291:347 */     if (saveDefaults) {
/* 292:348 */       this.qbeDefaultValues = new Hashtable();
/* 293:    */     }
/* 294:350 */     Enumeration e = this.qbeDisplayValues.keys();
/* 295:351 */     while (e.hasMoreElements())
/* 296:    */     {
/* 297:353 */       Object key = e.nextElement();
/* 298:354 */       String val = (String)this.qbeDisplayValues.get(key);
/* 299:355 */       this.qbeBackupValues.put(key, val);
/* 300:356 */       if (saveDefaults) {
/* 301:357 */         this.qbeDefaultValues.put(key, val);
/* 302:    */       }
/* 303:    */     }
/* 304:    */   }
/* 305:    */   
/* 306:    */   public void restoreSavedQBEValues()
/* 307:    */     throws RDOException
/* 308:    */   {
/* 309:363 */     if (this.qbeDisplayValues != null)
/* 310:    */     {
/* 311:365 */       Enumeration attrs = this.qbeDisplayValues.keys();
/* 312:366 */       while (attrs.hasMoreElements()) {
/* 313:367 */         setQBE((String)attrs.nextElement(), null);
/* 314:    */       }
/* 315:    */     }
/* 316:369 */     if (this.qbeBackupValues != null)
/* 317:    */     {
/* 318:371 */       Enumeration attrs = this.qbeBackupValues.keys();
/* 319:372 */       Enumeration values = this.qbeBackupValues.elements();
/* 320:373 */       while (attrs.hasMoreElements()) {
/* 321:374 */         setQBE((String)attrs.nextElement(), (String)values.nextElement());
/* 322:    */       }
/* 323:    */     }
/* 324:376 */     this.qbeBackupValues = null;
/* 325:    */   }
/* 326:    */   
/* 327:    */   public void restoreDefaultQBEValues(boolean keepBackup)
/* 328:    */     throws RDOException
/* 329:    */   {
/* 330:383 */     if (this.qbeDisplayValues != null)
/* 331:    */     {
/* 332:385 */       Enumeration attrs = this.qbeDisplayValues.keys();
/* 333:386 */       while (attrs.hasMoreElements()) {
/* 334:387 */         setQBE((String)attrs.nextElement(), null);
/* 335:    */       }
/* 336:    */     }
/* 337:389 */     if (this.qbeDefaultValues != null)
/* 338:    */     {
/* 339:391 */       Enumeration attrs = this.qbeDefaultValues.keys();
/* 340:392 */       Enumeration values = this.qbeDefaultValues.elements();
/* 341:393 */       while (attrs.hasMoreElements()) {
/* 342:394 */         setQBE((String)attrs.nextElement(), (String)values.nextElement());
/* 343:    */       }
/* 344:    */     }
/* 345:396 */     if (!keepBackup) {
/* 346:398 */       this.qbeBackupValues = null;
/* 347:    */     }
/* 348:    */   }
/* 349:    */   
/* 350:    */   public void restoreDefaultQBEValues()
/* 351:    */     throws RDOException
/* 352:    */   {
/* 353:405 */     restoreDefaultQBEValues(false);
/* 354:    */   }
/* 355:    */   
/* 356:    */   public void reset()
/* 357:    */     throws RDOException
/* 358:    */   {
/* 359:410 */     super.reset();
/* 360:411 */     this.qbeDisplayValues = new Hashtable();
/* 361:412 */     this.qbeBackupValues = null;
/* 362:413 */     setFiltered(false);
/* 363:    */   }
/* 364:    */   
/* 365:    */   public boolean isFiltered()
/* 366:    */   {
/* 367:421 */     return this.filtered;
/* 368:    */   }
/* 369:    */   
/* 370:    */   public void setFiltered(boolean filtered)
/* 371:    */   {
/* 372:428 */     this.filtered = filtered;
/* 373:    */   }
/* 374:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.MobileMboDataBeanQBE
 * JD-Core Version:    0.7.0.1
 */