/*   1:    */ package com.mro.mobile.ui;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.ProgressObserver;
/*   5:    */ import com.mro.mobile.ProgressWindow;
/*   6:    */ import com.mro.mobile.app.BasicMobileDeviceUIApplication;
/*   7:    */ import com.mro.mobile.app.DefaultEventHandler;
/*   8:    */ import com.mro.mobile.app.async.AsynchronousExecutor;
/*   9:    */ import com.mro.mobile.ui.event.UIEvent;
/*  10:    */ import com.mro.mobile.ui.res.UIUtil;
/*  11:    */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*  12:    */ 
/*  13:    */ public class DelegateWorker
/*  14:    */   implements Worker
/*  15:    */ {
/*  16:    */   private DefaultEventHandler defEventHandler;
/*  17:    */   private UIEvent event;
/*  18:    */   private AsynchronousExecutor executor;
/*  19:    */   
/*  20:    */   public DelegateWorker(DefaultEventHandler defEventHandler, UIEvent event, AsynchronousExecutor executor)
/*  21:    */   {
/*  22: 37 */     this.defEventHandler = defEventHandler;
/*  23: 38 */     this.event = event;
/*  24: 39 */     this.executor = executor;
/*  25:    */   }
/*  26:    */   
/*  27:    */   public void startWork()
/*  28:    */     throws MobileApplicationException
/*  29:    */   {
/*  30: 43 */     ProgressObserver observer = UIUtil.getApplication().showProgressScreen((AbstractMobileControl)this.event.getCreatingObject(), this.event);
/*  31: 44 */     this.event.setProgressObserver(observer);
/*  32: 45 */     WorkerImpl impl = new WorkerImpl(this, new DefaultWorkDetails((String)getEvent().getValue()), observer, this.executor);
/*  33: 46 */     Thread thread = this.executor.start(impl);
/*  34:    */     
/*  35: 48 */     observer.setBackgroundThread(thread);
/*  36:    */   }
/*  37:    */   
/*  38:    */   public void doWork(WorkDetails workDetails, ProgressObserver observer)
/*  39:    */     throws MobileApplicationException
/*  40:    */   {
/*  41: 58 */     getEvent().setThreadStatus(1);
/*  42: 59 */     getEventHandler().performEvent(getEvent());
/*  43:    */   }
/*  44:    */   
/*  45:    */   public void workCompleted(WorkDetails workDetails)
/*  46:    */     throws MobileApplicationException
/*  47:    */   {
/*  48: 69 */     getEvent().getProgressObserver().getProgressWindow().closeWindow();
/*  49: 70 */     getEvent().setThreadStatus(2);
/*  50: 71 */     getEventHandler().performEvent(getEvent());
/*  51:    */   }
/*  52:    */   
/*  53:    */   public void workStopped(WorkDetails workDetails)
/*  54:    */     throws MobileApplicationException
/*  55:    */   {
/*  56: 80 */     getEvent().getProgressObserver().getProgressWindow().closeWindow();
/*  57: 81 */     getEvent().setThreadStatus(0);
/*  58: 82 */     getEventHandler().performEvent(getEvent());
/*  59:    */   }
/*  60:    */   
/*  61:    */   public void workFailed(WorkDetails workDetails, Throwable exception)
/*  62:    */     throws MobileApplicationException
/*  63:    */   {
/*  64: 92 */     getEvent().getProgressObserver().getProgressWindow().closeWindow();
/*  65: 93 */     getEvent().setThreadStatus(3);
/*  66: 94 */     if ((exception instanceof MobileApplicationException)) {
/*  67: 95 */       getEvent().setException((MobileApplicationException)exception);
/*  68:    */     } else {
/*  69: 97 */       getEvent().setException(new MobileApplicationException(exception));
/*  70:    */     }
/*  71: 99 */     getEventHandler().performEvent(getEvent());
/*  72:    */   }
/*  73:    */   
/*  74:    */   public DefaultEventHandler getEventHandler()
/*  75:    */   {
/*  76:106 */     return this.defEventHandler;
/*  77:    */   }
/*  78:    */   
/*  79:    */   public void setEventHandler(DefaultEventHandler defEventHandler)
/*  80:    */   {
/*  81:114 */     this.defEventHandler = defEventHandler;
/*  82:    */   }
/*  83:    */   
/*  84:    */   public UIEvent getEvent()
/*  85:    */   {
/*  86:121 */     return this.event;
/*  87:    */   }
/*  88:    */   
/*  89:    */   public void setEvent(UIEvent event)
/*  90:    */   {
/*  91:129 */     this.event = event;
/*  92:    */   }
/*  93:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.DelegateWorker
 * JD-Core Version:    0.7.0.1
 */