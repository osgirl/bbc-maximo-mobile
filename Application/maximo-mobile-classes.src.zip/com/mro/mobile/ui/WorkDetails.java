package com.mro.mobile.ui;

public abstract interface WorkDetails
{
  public abstract String getName();
  
  public abstract Object getAdditionalInfo();
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.WorkDetails
 * JD-Core Version:    0.7.0.1
 */