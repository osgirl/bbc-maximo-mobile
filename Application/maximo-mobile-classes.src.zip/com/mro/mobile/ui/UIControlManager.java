/*  1:   */ package com.mro.mobile.ui;
/*  2:   */ 
/*  3:   */ import com.mro.mobile.MobileApplicationException;
/*  4:   */ import com.mro.mobile.MobileMetaData;
/*  5:   */ import com.mro.mobile.MobileScreenRegistry;
/*  6:   */ import com.mro.mobile.app.MobileDeviceAppSession;
/*  7:   */ import com.mro.mobile.ui.res.ControlData;
/*  8:   */ import java.util.Hashtable;
/*  9:   */ 
/* 10:   */ public class UIControlManager
/* 11:   */ {
/* 12:25 */   private static final UIControlManager infoManager = new UIControlManager();
/* 13:   */   
/* 14:   */   public static UIControlManager getInstance()
/* 15:   */   {
/* 16:28 */     return infoManager;
/* 17:   */   }
/* 18:   */   
/* 19:31 */   private Hashtable composers = new Hashtable();
/* 20:   */   
/* 21:   */   public void registerControl(String name, ControlComposer composer)
/* 22:   */   {
/* 23:34 */     this.composers.put(name, composer);
/* 24:   */   }
/* 25:   */   
/* 26:   */   public ControlComposer getControlComposer(String name)
/* 27:   */   {
/* 28:38 */     return (ControlComposer)this.composers.get(name);
/* 29:   */   }
/* 30:   */   
/* 31:   */   public ControlData getControlData(String id)
/* 32:   */   {
/* 33:42 */     MobileUIControlInfo controlInfo = getControlInfo(id);
/* 34:43 */     if (controlInfo != null) {
/* 35:44 */       return controlInfo.getComponentData();
/* 36:   */     }
/* 37:46 */     MobileScreenRegistry registry = MobileScreenRegistry.getInstance();
/* 38:47 */     return registry.getScreenData(id);
/* 39:   */   }
/* 40:   */   
/* 41:   */   public Object getController(String id)
/* 42:   */     throws MobileApplicationException
/* 43:   */   {
/* 44:59 */     MobileUIControlInfo controlInfo = getControlInfo(id);
/* 45:60 */     if (controlInfo != null) {
/* 46:61 */       return getController(getControlData(id));
/* 47:   */     }
/* 48:64 */     return null;
/* 49:   */   }
/* 50:   */   
/* 51:   */   public Object getController(ControlData controlData)
/* 52:   */     throws MobileApplicationException
/* 53:   */   {
/* 54:76 */     if (controlData != null)
/* 55:   */     {
/* 56:77 */       String controlType = controlData.getName();
/* 57:78 */       ControlComposer cc = getControlComposer(controlType);
/* 58:79 */       if (cc != null) {
/* 59:80 */         return cc.compose(controlData);
/* 60:   */       }
/* 61:   */     }
/* 62:83 */     return null;
/* 63:   */   }
/* 64:   */   
/* 65:   */   public Object getScreen(String id)
/* 66:   */     throws MobileApplicationException
/* 67:   */   {
/* 68:87 */     MobileScreenRegistry registry = MobileScreenRegistry.getInstance();
/* 69:88 */     return getController(registry.getScreenData(id));
/* 70:   */   }
/* 71:   */   
/* 72:   */   private MobileUIControlInfo getControlInfo(String controlID)
/* 73:   */   {
/* 74:93 */     MobileMetaData mobileMetaData = MobileDeviceAppSession.getSession().getMobileMetadata();
/* 75:94 */     MobileUIControlInfo controlInfo = mobileMetaData.getMobileUIComponentInfo(controlID);
/* 76:95 */     return controlInfo;
/* 77:   */   }
/* 78:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.UIControlManager
 * JD-Core Version:    0.7.0.1
 */