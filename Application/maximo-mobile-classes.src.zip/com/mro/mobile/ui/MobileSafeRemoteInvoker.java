/*   1:    */ package com.mro.mobile.ui;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.app.MobileDeviceAppSession;
/*   5:    */ 
/*   6:    */ public abstract class MobileSafeRemoteInvoker
/*   7:    */   extends Thread
/*   8:    */ {
/*   9:    */   private Object result;
/*  10:    */   private MobileApplicationException exception;
/*  11:    */   
/*  12:    */   public abstract void remoteCall()
/*  13:    */     throws MobileApplicationException;
/*  14:    */   
/*  15:    */   public void run()
/*  16:    */   {
/*  17:    */     try
/*  18:    */     {
/*  19: 44 */       MobileDeviceAppSession.getSession().setBackgroudThread(true);
/*  20: 45 */       remoteCall();
/*  21:    */     }
/*  22:    */     catch (MobileApplicationException e)
/*  23:    */     {
/*  24: 47 */       this.exception = e;
/*  25:    */     }
/*  26:    */     catch (Exception e2)
/*  27:    */     {
/*  28: 49 */       this.exception = new MobileApplicationException(e2.getMessage(), e2);
/*  29:    */     }
/*  30:    */     finally
/*  31:    */     {
/*  32: 52 */       MobileDeviceAppSession.getSession().setBackgroudThread(false);
/*  33:    */     }
/*  34:    */   }
/*  35:    */   
/*  36:    */   public Object getResult()
/*  37:    */   {
/*  38: 57 */     return this.result;
/*  39:    */   }
/*  40:    */   
/*  41:    */   protected void setResult(Object result)
/*  42:    */   {
/*  43: 64 */     this.result = result;
/*  44: 65 */     this.exception = null;
/*  45:    */   }
/*  46:    */   
/*  47:    */   public boolean isFailed()
/*  48:    */   {
/*  49: 73 */     return this.exception != null;
/*  50:    */   }
/*  51:    */   
/*  52:    */   public boolean isCompleted()
/*  53:    */   {
/*  54: 80 */     return (this.exception != null) || (this.result != null);
/*  55:    */   }
/*  56:    */   
/*  57:    */   public MobileApplicationException getMobileApplicationException()
/*  58:    */   {
/*  59: 84 */     return this.exception;
/*  60:    */   }
/*  61:    */   
/*  62:    */   public void executeWithinSeconds(int seconds)
/*  63:    */   {
/*  64: 93 */     start();
/*  65:    */     try
/*  66:    */     {
/*  67: 95 */       join(seconds * 1000);
/*  68:    */     }
/*  69:    */     catch (InterruptedException e)
/*  70:    */     {
/*  71: 97 */       this.exception = new MobileApplicationException(e.getMessage(), e);
/*  72:    */     }
/*  73:    */   }
/*  74:    */   
/*  75:    */   public void execute()
/*  76:    */   {
/*  77:107 */     start();
/*  78:    */     try
/*  79:    */     {
/*  80:109 */       join();
/*  81:    */     }
/*  82:    */     catch (InterruptedException e)
/*  83:    */     {
/*  84:111 */       this.exception = new MobileApplicationException(e.getMessage(), e);
/*  85:    */     }
/*  86:    */   }
/*  87:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.MobileSafeRemoteInvoker
 * JD-Core Version:    0.7.0.1
 */