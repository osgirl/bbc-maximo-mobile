/*  1:   */ package com.mro.mobile.ui;
/*  2:   */ 
/*  3:   */ public class DefaultWorkDetails
/*  4:   */   implements WorkDetails
/*  5:   */ {
/*  6:18 */   private String name = null;
/*  7:19 */   private Object additionalInfo = null;
/*  8:   */   
/*  9:   */   public DefaultWorkDetails(String name)
/* 10:   */   {
/* 11:23 */     this.name = name;
/* 12:   */   }
/* 13:   */   
/* 14:   */   public DefaultWorkDetails(String name, Object additionalInfo)
/* 15:   */   {
/* 16:28 */     this.name = name;
/* 17:29 */     this.additionalInfo = additionalInfo;
/* 18:   */   }
/* 19:   */   
/* 20:   */   public Object getAdditionalInfo()
/* 21:   */   {
/* 22:34 */     return this.additionalInfo;
/* 23:   */   }
/* 24:   */   
/* 25:   */   public void setAdditionalInfo(Object additionalInfo)
/* 26:   */   {
/* 27:39 */     this.additionalInfo = additionalInfo;
/* 28:   */   }
/* 29:   */   
/* 30:   */   public String getName()
/* 31:   */   {
/* 32:44 */     return this.name;
/* 33:   */   }
/* 34:   */   
/* 35:   */   public void setName(String name)
/* 36:   */   {
/* 37:49 */     this.name = name;
/* 38:   */   }
/* 39:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.DefaultWorkDetails
 * JD-Core Version:    0.7.0.1
 */