/*   1:    */ package com.mro.mobile.ui;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileScreenRegistry;
/*   4:    */ import com.mro.mobile.type.Serializer;
/*   5:    */ import com.mro.mobile.type.TypeRegistry;
/*   6:    */ import com.mro.mobile.ui.res.ControlData;
/*   7:    */ import java.io.DataInput;
/*   8:    */ import java.io.DataOutput;
/*   9:    */ import java.io.IOException;
/*  10:    */ import java.util.Enumeration;
/*  11:    */ import java.util.Hashtable;
/*  12:    */ 
/*  13:    */ public class MobileUIControlData
/*  14:    */   implements ControlData, Serializer
/*  15:    */ {
/*  16:    */   public static final String UICOMPONENTDATA = "UIComponentData";
/*  17: 31 */   protected Hashtable values = new Hashtable();
/*  18: 32 */   protected ControlData[] childComponentData = null;
/*  19: 33 */   protected ControlData parentComponentData = null;
/*  20: 35 */   protected String componentName = null;
/*  21:    */   
/*  22:    */   public String getName()
/*  23:    */   {
/*  24: 39 */     return this.componentName;
/*  25:    */   }
/*  26:    */   
/*  27:    */   public void setName(String name)
/*  28:    */   {
/*  29: 44 */     this.componentName = name;
/*  30:    */   }
/*  31:    */   
/*  32:    */   public String getValue(String attribute)
/*  33:    */   {
/*  34: 49 */     String v = (String)this.values.get(attribute);
/*  35:    */     
/*  36: 51 */     return v;
/*  37:    */   }
/*  38:    */   
/*  39:    */   public void putValue(String attribute, String value)
/*  40:    */   {
/*  41: 56 */     this.values.put(attribute, value);
/*  42:    */   }
/*  43:    */   
/*  44:    */   public void setValues(Hashtable values)
/*  45:    */   {
/*  46: 61 */     this.values = values;
/*  47:    */   }
/*  48:    */   
/*  49:    */   public ControlData[] getChildControlData()
/*  50:    */   {
/*  51: 66 */     return this.childComponentData;
/*  52:    */   }
/*  53:    */   
/*  54:    */   public void setChildComponentData(ControlData[] childComponentData)
/*  55:    */   {
/*  56: 71 */     this.childComponentData = childComponentData;
/*  57:    */   }
/*  58:    */   
/*  59:    */   public static void initSerializer()
/*  60:    */   {
/*  61: 76 */     MobileUIControlData i = new MobileUIControlData();
/*  62: 77 */     TypeRegistry.getTypeRegistry().addType("UIComponentData", i.getClass(), i);
/*  63:    */   }
/*  64:    */   
/*  65:    */   public Object readInstance(DataInput input, String name)
/*  66:    */     throws IOException
/*  67:    */   {
/*  68: 85 */     if (name.equals("UIComponentData"))
/*  69:    */     {
/*  70: 87 */       MobileUIControlData cData = new MobileUIControlData();
/*  71:    */       
/*  72: 89 */       String componentName = input.readUTF();
/*  73:    */       
/*  74: 91 */       int noOfValues = input.readInt();
/*  75:    */       
/*  76: 93 */       Hashtable v = new Hashtable();
/*  77:    */       
/*  78:    */ 
/*  79: 96 */       String id = null;
/*  80: 99 */       for (int i = 0; i < noOfValues; i++)
/*  81:    */       {
/*  82:102 */         String attrName = input.readUTF();
/*  83:103 */         String value = input.readUTF();
/*  84:104 */         if ((id == null) && (attrName.equals("id"))) {
/*  85:105 */           id = value;
/*  86:    */         }
/*  87:106 */         v.put(attrName, value);
/*  88:    */       }
/*  89:109 */       int noOfChildComponents = input.readInt();
/*  90:110 */       MobileUIControlData[] cChildComponentsData = new MobileUIControlData[noOfChildComponents];
/*  91:111 */       for (int i = 0; i < noOfChildComponents; i++)
/*  92:    */       {
/*  93:113 */         cChildComponentsData[i] = ((MobileUIControlData)readInstance(input, "UIComponentData"));
/*  94:114 */         cChildComponentsData[i].setParentComponentData(cData);
/*  95:    */       }
/*  96:117 */       cData.setName(componentName);
/*  97:118 */       cData.setValues(v);
/*  98:119 */       cData.setChildComponentData(cChildComponentsData);
/*  99:121 */       if ((MobileUIControlTypeMapper.getUIComponentType(componentName) == 1) && (id != null))
/* 100:    */       {
/* 101:123 */         MobileScreenRegistry registry = MobileScreenRegistry.getInstance();
/* 102:124 */         registry.registerScreen(id, cData);
/* 103:    */       }
/* 104:127 */       return cData;
/* 105:    */     }
/* 106:130 */     throw new RuntimeException("The type " + name + " not supported.");
/* 107:    */   }
/* 108:    */   
/* 109:    */   public void writeInstance(DataOutput output, Object obj)
/* 110:    */     throws IOException
/* 111:    */   {
/* 112:138 */     if ((obj instanceof MobileUIControlData))
/* 113:    */     {
/* 114:140 */       MobileUIControlData cData = (MobileUIControlData)obj;
/* 115:    */       
/* 116:142 */       output.writeUTF(cData.getName());
/* 117:    */       
/* 118:144 */       int noOfValues = 0;
/* 119:145 */       if (cData.values != null) {
/* 120:147 */         noOfValues = cData.values.size();
/* 121:    */       }
/* 122:149 */       output.writeInt(noOfValues);
/* 123:151 */       if (cData.values != null)
/* 124:    */       {
/* 125:153 */         Enumeration attrEnum = cData.values.keys();
/* 126:154 */         for (int i = 0; i < noOfValues; i++)
/* 127:    */         {
/* 128:156 */           String attrName = (String)attrEnum.nextElement();
/* 129:157 */           output.writeUTF(attrName);
/* 130:158 */           output.writeUTF((String)cData.values.get(attrName));
/* 131:    */         }
/* 132:    */       }
/* 133:162 */       int noOfChildComponents = 0;
/* 134:163 */       if (cData.childComponentData != null) {
/* 135:165 */         noOfChildComponents = cData.childComponentData.length;
/* 136:    */       }
/* 137:167 */       output.writeInt(noOfChildComponents);
/* 138:168 */       for (int i = 0; i < noOfChildComponents; i++) {
/* 139:170 */         writeInstance(output, cData.childComponentData[i]);
/* 140:    */       }
/* 141:    */     }
/* 142:    */   }
/* 143:    */   
/* 144:    */   public ControlData getParentComponentData()
/* 145:    */   {
/* 146:180 */     return this.parentComponentData;
/* 147:    */   }
/* 148:    */   
/* 149:    */   public void setParentComponentData(ControlData parentComponentData)
/* 150:    */   {
/* 151:187 */     this.parentComponentData = parentComponentData;
/* 152:    */   }
/* 153:    */   
/* 154:    */   public MobileUIControlData cloneThis()
/* 155:    */   {
/* 156:192 */     MobileUIControlData clone = new MobileUIControlData();
/* 157:193 */     clone.setName(getName());
/* 158:194 */     Hashtable clonedValues = new Hashtable();
/* 159:195 */     if (this.values != null)
/* 160:    */     {
/* 161:197 */       Enumeration e = this.values.keys();
/* 162:198 */       while (e.hasMoreElements())
/* 163:    */       {
/* 164:200 */         Object key = e.nextElement();
/* 165:201 */         clonedValues.put(key, this.values.get(key));
/* 166:    */       }
/* 167:    */     }
/* 168:204 */     clone.setValues(clonedValues);
/* 169:205 */     if ((this.childComponentData != null) && (this.childComponentData.length > 0))
/* 170:    */     {
/* 171:207 */       ControlData[] clonedChildren = new ControlData[this.childComponentData.length];
/* 172:208 */       for (int i = 0; i < this.childComponentData.length; i++) {
/* 173:210 */         clonedChildren[i] = ((MobileUIControlData)this.childComponentData[i]).cloneThis();
/* 174:    */       }
/* 175:212 */       clone.setChildComponentData(clonedChildren);
/* 176:    */     }
/* 177:214 */     return clone;
/* 178:    */   }
/* 179:    */   
/* 180:    */   public void resetValue(String attribute)
/* 181:    */   {
/* 182:218 */     this.values.remove(attribute);
/* 183:    */   }
/* 184:    */   
/* 185:    */   public void rebuildControlDataTree(ControlData parentControlData, String[] valuesToBeRemoved)
/* 186:    */   {
/* 187:233 */     ControlData[] controlData = getChildControlData();
/* 188:234 */     if ((controlData != null) && (parentControlData != null))
/* 189:    */     {
/* 190:235 */       int i = 0;
/* 191:236 */       for (i = 0; i < controlData.length; i++) {
/* 192:237 */         if ((controlData[i] instanceof MobileUIControlData))
/* 193:    */         {
/* 194:238 */           if (valuesToBeRemoved != null)
/* 195:    */           {
/* 196:239 */             int j = 0;
/* 197:240 */             for (j = 0; j < valuesToBeRemoved.length; j++) {
/* 198:241 */               controlData[i].resetValue(valuesToBeRemoved[j]);
/* 199:    */             }
/* 200:    */           }
/* 201:244 */           ControlData currentParent = ((MobileUIControlData)controlData[i]).getParentComponentData();
/* 202:245 */           if (currentParent != parentControlData) {
/* 203:246 */             ((MobileUIControlData)controlData[i]).setParentComponentData(parentControlData);
/* 204:    */           }
/* 205:248 */           ((MobileUIControlData)controlData[i]).rebuildControlDataTree(this, valuesToBeRemoved);
/* 206:    */         }
/* 207:    */       }
/* 208:    */     }
/* 209:    */   }
/* 210:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.MobileUIControlData
 * JD-Core Version:    0.7.0.1
 */