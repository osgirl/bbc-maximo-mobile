/*   1:    */ package com.mro.mobile.ui;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import java.util.Enumeration;
/*   5:    */ import java.util.Hashtable;
/*   6:    */ import java.util.Vector;
/*   7:    */ 
/*   8:    */ public class DataBeanCache
/*   9:    */ {
/*  10: 24 */   static Hashtable beanCache = new Hashtable();
/*  11:    */   
/*  12:    */   public static MobileMboDataBean getDataBean(String beanName, String mobileMboName)
/*  13:    */     throws MobileApplicationException
/*  14:    */   {
/*  15: 29 */     if ((beanName == null) || (mobileMboName == null)) {
/*  16: 31 */       return null;
/*  17:    */     }
/*  18: 34 */     Object obj = beanCache.get(beanName);
/*  19: 35 */     if (obj != null)
/*  20:    */     {
/*  21: 37 */       DataBeanCacheItem item = (DataBeanCacheItem)obj;
/*  22: 38 */       return item.getBean();
/*  23:    */     }
/*  24: 41 */     MobileMboDataBeanManager mgr = new MobileMboDataBeanManager(mobileMboName);
/*  25: 42 */     MobileMboDataBean bean = mgr.getDataBean();
/*  26:    */     
/*  27: 44 */     DataBeanCacheItem item = new DataBeanCacheItem(beanName, mobileMboName, bean);
/*  28:    */     
/*  29: 46 */     beanCache.put(beanName, item);
/*  30:    */     
/*  31: 48 */     return bean;
/*  32:    */   }
/*  33:    */   
/*  34:    */   public static MobileMboDataBean findDataBean(String beanName)
/*  35:    */   {
/*  36: 53 */     if (beanName == null) {
/*  37: 55 */       return null;
/*  38:    */     }
/*  39: 58 */     Object obj = beanCache.get(beanName);
/*  40: 59 */     if (obj != null)
/*  41:    */     {
/*  42: 61 */       DataBeanCacheItem item = (DataBeanCacheItem)obj;
/*  43: 62 */       return item.getBean();
/*  44:    */     }
/*  45: 65 */     return null;
/*  46:    */   }
/*  47:    */   
/*  48:    */   public static void removeDataBean(String beanName)
/*  49:    */   {
/*  50: 70 */     beanCache.remove(beanName);
/*  51:    */   }
/*  52:    */   
/*  53:    */   public static void cacheDataBean(String beanName, MobileMboDataBean dataBean)
/*  54:    */   {
/*  55: 77 */     DataBeanCacheItem item = new DataBeanCacheItem(beanName, dataBean.getName(), dataBean);
/*  56: 78 */     beanCache.put(beanName, item);
/*  57:    */   }
/*  58:    */   
/*  59:    */   public static void cacheDataBean(String beanName, DataBeanCacheItem item)
/*  60:    */   {
/*  61: 83 */     beanCache.put(beanName, item);
/*  62:    */   }
/*  63:    */   
/*  64:    */   public static void removeAllDataBeans()
/*  65:    */   {
/*  66: 88 */     if (!beanCache.isEmpty())
/*  67:    */     {
/*  68: 90 */       Enumeration e = beanCache.elements();
/*  69: 91 */       while (e.hasMoreElements())
/*  70:    */       {
/*  71: 93 */         DataBeanCacheItem item = (DataBeanCacheItem)e.nextElement();
/*  72: 94 */         MobileMboDataBean bean = item.getBean();
/*  73:    */         try
/*  74:    */         {
/*  75: 97 */           if (bean != null)
/*  76:    */           {
/*  77: 99 */             bean.reset();
/*  78:100 */             bean.close();
/*  79:    */           }
/*  80:    */         }
/*  81:    */         catch (MobileApplicationException e1) {}
/*  82:    */       }
/*  83:    */     }
/*  84:109 */     beanCache.clear();
/*  85:    */   }
/*  86:    */   
/*  87:    */   public static void rebuild()
/*  88:    */     throws MobileApplicationException
/*  89:    */   {
/*  90:114 */     Vector topLevelBeans = new Vector();
/*  91:    */     
/*  92:116 */     Enumeration keys = beanCache.keys();
/*  93:117 */     while (keys.hasMoreElements())
/*  94:    */     {
/*  95:119 */       String beanId = (String)keys.nextElement();
/*  96:120 */       DataBeanCacheItem item = (DataBeanCacheItem)beanCache.get(beanId);
/*  97:122 */       if (item.getParentBeanId() == null) {
/*  98:124 */         topLevelBeans.addElement(beanId);
/*  99:    */       }
/* 100:    */     }
/* 101:128 */     Vector itemsToUpdate = new Vector();
/* 102:    */     
/* 103:    */ 
/* 104:    */ 
/* 105:132 */     Enumeration topKeys = topLevelBeans.elements();
/* 106:133 */     while (topKeys.hasMoreElements())
/* 107:    */     {
/* 108:135 */       String topBeanId = (String)topKeys.nextElement();
/* 109:136 */       rebuild(topBeanId, itemsToUpdate);
/* 110:    */     }
/* 111:140 */     Enumeration itemsToUpdateEnum = itemsToUpdate.elements();
/* 112:141 */     while (itemsToUpdateEnum.hasMoreElements())
/* 113:    */     {
/* 114:143 */       DataBeanCacheItem newItem = (DataBeanCacheItem)itemsToUpdateEnum.nextElement();
/* 115:144 */       beanCache.put(newItem.getBeanId(), newItem);
/* 116:    */     }
/* 117:    */   }
/* 118:    */   
/* 119:    */   private static void rebuild(String parentBeanId, Vector itemsToUpdate)
/* 120:    */     throws MobileApplicationException
/* 121:    */   {
/* 122:151 */     Vector beansWithParent = new Vector();
/* 123:    */     
/* 124:153 */     Enumeration keys = beanCache.keys();
/* 125:154 */     while (keys.hasMoreElements())
/* 126:    */     {
/* 127:156 */       String beanId = (String)keys.nextElement();
/* 128:157 */       DataBeanCacheItem item = (DataBeanCacheItem)beanCache.get(beanId);
/* 129:159 */       if (item.getParentBeanId() != null) {
/* 130:164 */         if (item.getParentBeanId().equals(parentBeanId)) {
/* 131:166 */           beansWithParent.addElement(beanId);
/* 132:    */         }
/* 133:    */       }
/* 134:    */     }
/* 135:173 */     DataBeanCacheItem cachedParentItem = (DataBeanCacheItem)beanCache.get(parentBeanId);
/* 136:174 */     MobileMboDataBean parentBean = cachedParentItem.getBean();
/* 137:    */     
/* 138:176 */     Enumeration beansWithParentKeys = beansWithParent.elements();
/* 139:177 */     while (beansWithParentKeys.hasMoreElements())
/* 140:    */     {
/* 141:179 */       String childBeanId = (String)beansWithParentKeys.nextElement();
/* 142:    */       
/* 143:181 */       DataBeanCacheItem item = (DataBeanCacheItem)beanCache.get(childBeanId);
/* 144:182 */       String childMobileMboName = item.getMobileMboName();
/* 145:    */       
/* 146:    */ 
/* 147:    */ 
/* 148:186 */       MobileMboDataBean newDataBean = parentBean.getDataBean(childMobileMboName);
/* 149:187 */       DataBeanCacheItem newItem = new DataBeanCacheItem(childBeanId, parentBeanId, childMobileMboName, newDataBean);
/* 150:188 */       itemsToUpdate.addElement(newItem);
/* 151:    */       
/* 152:    */ 
/* 153:191 */       rebuild(childBeanId, itemsToUpdate);
/* 154:    */     }
/* 155:    */   }
/* 156:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.DataBeanCache
 * JD-Core Version:    0.7.0.1
 */