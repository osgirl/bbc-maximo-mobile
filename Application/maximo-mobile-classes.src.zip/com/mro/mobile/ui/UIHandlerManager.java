/*  1:   */ package com.mro.mobile.ui;
/*  2:   */ 
/*  3:   */ import com.mro.mobile.ui.event.UIEventHandler;
/*  4:   */ import java.util.Hashtable;
/*  5:   */ 
/*  6:   */ public class UIHandlerManager
/*  7:   */ {
/*  8:22 */   private static final UIHandlerManager handlerManager = new UIHandlerManager();
/*  9:   */   
/* 10:   */   public static UIHandlerManager getInstance()
/* 11:   */   {
/* 12:26 */     return handlerManager;
/* 13:   */   }
/* 14:   */   
/* 15:29 */   private Hashtable handlers = new Hashtable();
/* 16:   */   
/* 17:   */   public void registerHandler(String name, UIEventHandler handler)
/* 18:   */   {
/* 19:33 */     this.handlers.put(name, handler);
/* 20:   */   }
/* 21:   */   
/* 22:   */   public UIEventHandler getUIHandler(String name)
/* 23:   */   {
/* 24:38 */     if (name != null) {
/* 25:39 */       return (UIEventHandler)this.handlers.get(name);
/* 26:   */     }
/* 27:41 */     return null;
/* 28:   */   }
/* 29:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.UIHandlerManager
 * JD-Core Version:    0.7.0.1
 */