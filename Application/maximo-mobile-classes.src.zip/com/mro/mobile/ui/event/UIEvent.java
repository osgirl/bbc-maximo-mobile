/*   1:    */ package com.mro.mobile.ui.event;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.ProgressObserver;
/*   5:    */ 
/*   6:    */ public class UIEvent
/*   7:    */ {
/*   8: 33 */   private String eventName = null;
/*   9: 34 */   private String targetID = null;
/*  10: 35 */   private Object value = null;
/*  11: 36 */   private Object source = null;
/*  12: 37 */   private Object creatingObject = null;
/*  13: 38 */   private boolean eventErrored = false;
/*  14: 39 */   private boolean passedESig = false;
/*  15: 40 */   private UIEvent initialEvent = null;
/*  16: 45 */   private MobileApplicationException mex = null;
/*  17: 46 */   private int threadStatus = -1;
/*  18: 47 */   private ProgressObserver progressObserver = null;
/*  19: 52 */   private String msgResponse = "-1";
/*  20:    */   
/*  21:    */   public UIEvent(Object creatingObject, String eventName, String targetID, Object value)
/*  22:    */   {
/*  23: 56 */     this.creatingObject = creatingObject;
/*  24: 57 */     this.eventName = eventName;
/*  25: 58 */     this.targetID = targetID;
/*  26: 59 */     this.value = value;
/*  27:    */   }
/*  28:    */   
/*  29:    */   public Object getValue()
/*  30:    */   {
/*  31: 67 */     return this.value;
/*  32:    */   }
/*  33:    */   
/*  34:    */   public void setValue(Object value)
/*  35:    */   {
/*  36: 74 */     this.value = value;
/*  37:    */   }
/*  38:    */   
/*  39:    */   public String getEventName()
/*  40:    */   {
/*  41: 81 */     return this.eventName;
/*  42:    */   }
/*  43:    */   
/*  44:    */   public String getTargetID()
/*  45:    */   {
/*  46: 88 */     return this.targetID;
/*  47:    */   }
/*  48:    */   
/*  49:    */   public Object getSource()
/*  50:    */   {
/*  51: 95 */     return this.source;
/*  52:    */   }
/*  53:    */   
/*  54:    */   public void setSource(Object source)
/*  55:    */   {
/*  56:102 */     this.source = source;
/*  57:    */   }
/*  58:    */   
/*  59:    */   public void clearTarget()
/*  60:    */   {
/*  61:109 */     this.targetID = null;
/*  62:    */   }
/*  63:    */   
/*  64:    */   public Object getCreatingObject()
/*  65:    */   {
/*  66:116 */     return this.creatingObject;
/*  67:    */   }
/*  68:    */   
/*  69:    */   public void setCreatingObject(Object creatingObject)
/*  70:    */   {
/*  71:123 */     this.creatingObject = creatingObject;
/*  72:    */   }
/*  73:    */   
/*  74:    */   public void setEventName(String eventName)
/*  75:    */   {
/*  76:130 */     this.eventName = eventName;
/*  77:    */   }
/*  78:    */   
/*  79:    */   public void setTargetID(String targetID)
/*  80:    */   {
/*  81:137 */     this.targetID = targetID;
/*  82:    */   }
/*  83:    */   
/*  84:    */   public boolean errorOccured()
/*  85:    */   {
/*  86:145 */     return this.eventErrored;
/*  87:    */   }
/*  88:    */   
/*  89:    */   public void setEventErrored(boolean b)
/*  90:    */   {
/*  91:153 */     this.eventErrored = b;
/*  92:    */   }
/*  93:    */   
/*  94:    */   public void setEventErrored()
/*  95:    */   {
/*  96:161 */     this.eventErrored = true;
/*  97:    */   }
/*  98:    */   
/*  99:    */   public String getMsgResponse()
/* 100:    */   {
/* 101:169 */     return this.msgResponse;
/* 102:    */   }
/* 103:    */   
/* 104:    */   public void setMsgResponse(String msgResponse)
/* 105:    */   {
/* 106:176 */     this.msgResponse = msgResponse;
/* 107:    */   }
/* 108:    */   
/* 109:    */   public MobileApplicationException getException()
/* 110:    */   {
/* 111:182 */     return this.mex;
/* 112:    */   }
/* 113:    */   
/* 114:    */   public void setException(MobileApplicationException mex)
/* 115:    */   {
/* 116:188 */     this.mex = mex;
/* 117:    */   }
/* 118:    */   
/* 119:    */   public ProgressObserver getProgressObserver()
/* 120:    */   {
/* 121:194 */     return this.progressObserver;
/* 122:    */   }
/* 123:    */   
/* 124:    */   public void setProgressObserver(ProgressObserver progressObserver)
/* 125:    */   {
/* 126:200 */     this.progressObserver = progressObserver;
/* 127:    */   }
/* 128:    */   
/* 129:    */   public int getThreadStatus()
/* 130:    */   {
/* 131:206 */     return this.threadStatus;
/* 132:    */   }
/* 133:    */   
/* 134:    */   public void setThreadStatus(int threadStatus)
/* 135:    */   {
/* 136:212 */     this.threadStatus = threadStatus;
/* 137:    */   }
/* 138:    */   
/* 139:    */   public boolean hasPassedESig()
/* 140:    */   {
/* 141:219 */     return this.passedESig;
/* 142:    */   }
/* 143:    */   
/* 144:    */   public void setPassedESig(boolean passedESig)
/* 145:    */   {
/* 146:226 */     this.passedESig = passedESig;
/* 147:    */   }
/* 148:    */   
/* 149:    */   public UIEvent getInitialEvent()
/* 150:    */   {
/* 151:235 */     return this.initialEvent;
/* 152:    */   }
/* 153:    */   
/* 154:    */   public void setInitialEvent(UIEvent initialEvent)
/* 155:    */   {
/* 156:247 */     this.initialEvent = initialEvent;
/* 157:    */   }
/* 158:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.event.UIEvent
 * JD-Core Version:    0.7.0.1
 */