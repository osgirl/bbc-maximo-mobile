package com.mro.mobile.ui.event;

import com.mro.mobile.MobileApplicationException;

public abstract interface UIEventHandler
{
  public static final boolean EVENT_HANDLED = true;
  public static final boolean EVENT_CONTINUE = false;
  
  public abstract void initializeScreen(String paramString)
    throws MobileApplicationException;
  
  public abstract void refreshScreen(String paramString)
    throws MobileApplicationException;
  
  public abstract boolean performEvent(Object paramObject)
    throws MobileApplicationException;
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.event.UIEventHandler
 * JD-Core Version:    0.7.0.1
 */