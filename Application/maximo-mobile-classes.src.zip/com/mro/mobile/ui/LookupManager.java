/*  1:   */ package com.mro.mobile.ui;
/*  2:   */ 
/*  3:   */ import com.mro.mobile.MobileApplicationException;
/*  4:   */ import com.mro.mobile.mbo.MobileMboInfo;
/*  5:   */ 
/*  6:   */ public class LookupManager
/*  7:   */ {
/*  8:22 */   private MultiSiteFilter multiSiteFilter = new MultiSiteFilter();
/*  9:   */   
/* 10:   */   public void applySelectedLookupValue(MobileMboDataBean lookupDataBean, String lookupAttribute, MobileMboDataBean sourceDataBean, String sourceAttribute)
/* 11:   */     throws MobileApplicationException
/* 12:   */   {
/* 13:42 */     if (lookupDataBean.getCurrentPosition() < 0) {
/* 14:45 */       return;
/* 15:   */     }
/* 16:48 */     String lookupAttributeValue = lookupDataBean.getValue(lookupAttribute);
/* 17:54 */     if ((sourceDataBean.getMobileMboInfo() != null) && (sourceDataBean.getMobileMboInfo().getAttributeInfo(sourceAttribute) != null)) {
/* 18:58 */       sourceDataBean.setValue(sourceAttribute, lookupAttributeValue);
/* 19:   */     }
/* 20:62 */     this.multiSiteFilter.applySelectedMultiSiteValue(lookupDataBean, sourceDataBean);
/* 21:   */   }
/* 22:   */   
/* 23:   */   public void applyMultisiteFilter(MobileMboDataBean lookupDataBean, MobileMboDataBean sourceDataBean)
/* 24:   */     throws MobileApplicationException
/* 25:   */   {
/* 26:77 */     this.multiSiteFilter.applyMultiSiteFilter(lookupDataBean, sourceDataBean);
/* 27:   */   }
/* 28:   */   
/* 29:   */   public MobileMboDataBean createLookupDomainBean(String mobileMboName)
/* 30:   */     throws MobileApplicationException
/* 31:   */   {
/* 32:92 */     MobileMboDataBeanManager dataBeanManager = new MobileMboDataBeanManager(mobileMboName);
/* 33:   */     
/* 34:94 */     return dataBeanManager.getDataBean();
/* 35:   */   }
/* 36:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.LookupManager
 * JD-Core Version:    0.7.0.1
 */