/*  1:   */ package com.mro.mobile.ui;
/*  2:   */ 
/*  3:   */ import com.mro.mobile.MobileApplicationException;
/*  4:   */ import com.mro.mobile.app.AbstractMobileDeviceApplication;
/*  5:   */ import com.mro.mobile.app.MobileDeviceAppSession;
/*  6:   */ import com.mro.mobile.mbo.MobileMboAttributeInfo;
/*  7:   */ import java.util.Date;
/*  8:   */ 
/*  9:   */ public abstract class MobileMboDataFormatter
/* 10:   */ {
/* 11:63 */   private static MobileMboDataFormatter formatter = null;
/* 12:   */   
/* 13:   */   public abstract String formatInternalToDispaly(String paramString, MobileMboAttributeInfo paramMobileMboAttributeInfo)
/* 14:   */     throws MobileApplicationException;
/* 15:   */   
/* 16:   */   public abstract String formatDisplayToInternal(String paramString, MobileMboAttributeInfo paramMobileMboAttributeInfo, boolean paramBoolean)
/* 17:   */     throws MobileApplicationException;
/* 18:   */   
/* 19:   */   public abstract String formatDisplayToInternal(String paramString, MobileMboAttributeInfo paramMobileMboAttributeInfo)
/* 20:   */     throws MobileApplicationException;
/* 21:   */   
/* 22:   */   public abstract Date convertStringToDate(String paramString)
/* 23:   */     throws MobileApplicationException;
/* 24:   */   
/* 25:   */   public abstract Date convertStringToDateTime(String paramString)
/* 26:   */     throws MobileApplicationException;
/* 27:   */   
/* 28:   */   public abstract Date convertStringToTime(String paramString)
/* 29:   */     throws MobileApplicationException;
/* 30:   */   
/* 31:   */   public static MobileMboDataFormatter getInstance()
/* 32:   */   {
/* 33:68 */     if (formatter != null) {
/* 34:70 */       return formatter;
/* 35:   */     }
/* 36:73 */     MobileDeviceAppSession deviceAppSession = MobileDeviceAppSession.getSession();
/* 37:74 */     AbstractMobileDeviceApplication app = deviceAppSession.getApplication();
/* 38:   */     
/* 39:   */ 
/* 40:   */ 
/* 41:78 */     formatter = app.getMobileMboDataFormatter();
/* 42:   */     
/* 43:80 */     return formatter;
/* 44:   */   }
/* 45:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.MobileMboDataFormatter
 * JD-Core Version:    0.7.0.1
 */