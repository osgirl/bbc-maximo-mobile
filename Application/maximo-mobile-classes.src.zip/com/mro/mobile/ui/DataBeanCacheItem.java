/*  1:   */ package com.mro.mobile.ui;
/*  2:   */ 
/*  3:   */ public class DataBeanCacheItem
/*  4:   */ {
/*  5:18 */   private String beanId = null;
/*  6:19 */   private String mobileMboName = null;
/*  7:20 */   private String parentBeanId = null;
/*  8:21 */   private MobileMboDataBean bean = null;
/*  9:   */   
/* 10:   */   public DataBeanCacheItem(String beanId, String mobileMboName, MobileMboDataBean bean)
/* 11:   */   {
/* 12:26 */     this.beanId = beanId;
/* 13:27 */     this.mobileMboName = mobileMboName;
/* 14:28 */     this.bean = bean;
/* 15:   */   }
/* 16:   */   
/* 17:   */   public DataBeanCacheItem(String beanId, String parentBeanId, String mobileMboName, MobileMboDataBean bean)
/* 18:   */   {
/* 19:33 */     this.beanId = beanId;
/* 20:34 */     this.mobileMboName = mobileMboName;
/* 21:35 */     this.bean = bean;
/* 22:36 */     this.parentBeanId = parentBeanId;
/* 23:   */   }
/* 24:   */   
/* 25:   */   public String getBeanId()
/* 26:   */   {
/* 27:41 */     return this.beanId;
/* 28:   */   }
/* 29:   */   
/* 30:   */   public MobileMboDataBean getBean()
/* 31:   */   {
/* 32:46 */     return this.bean;
/* 33:   */   }
/* 34:   */   
/* 35:   */   public String getMobileMboName()
/* 36:   */   {
/* 37:51 */     return this.mobileMboName;
/* 38:   */   }
/* 39:   */   
/* 40:   */   public String getParentBeanId()
/* 41:   */   {
/* 42:56 */     return this.parentBeanId;
/* 43:   */   }
/* 44:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.DataBeanCacheItem
 * JD-Core Version:    0.7.0.1
 */