package com.mro.mobile.ui;

public abstract interface MobileUIControlType
{
  public static final int SCREEN = 1;
  public static final int TOOLBAR = 2;
  public static final int MENU = 3;
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.MobileUIControlType
 * JD-Core Version:    0.7.0.1
 */