package com.mro.mobile.ui;

import com.mro.mobile.ui.res.ControlData;

public abstract interface ControlComposer
{
  public abstract Object compose(ControlData paramControlData);
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.ControlComposer
 * JD-Core Version:    0.7.0.1
 */