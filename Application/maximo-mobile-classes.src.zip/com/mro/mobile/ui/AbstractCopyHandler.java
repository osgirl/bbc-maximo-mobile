/*  1:   */ package com.mro.mobile.ui;
/*  2:   */ 
/*  3:   */ public class AbstractCopyHandler
/*  4:   */   implements CopyHandler
/*  5:   */ {
/*  6:   */   public boolean skipCopyField(String mobileMboName, String attributeName)
/*  7:   */   {
/*  8:20 */     return false;
/*  9:   */   }
/* 10:   */   
/* 11:   */   public boolean skipCopyDependent(String dependentMboName)
/* 12:   */   {
/* 13:25 */     return false;
/* 14:   */   }
/* 15:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.AbstractCopyHandler
 * JD-Core Version:    0.7.0.1
 */