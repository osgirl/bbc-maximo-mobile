package com.mro.mobile.ui;

public abstract interface CopyHandler
{
  public abstract boolean skipCopyField(String paramString1, String paramString2);
  
  public abstract boolean skipCopyDependent(String paramString);
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.CopyHandler
 * JD-Core Version:    0.7.0.1
 */