/*    1:     */ package com.mro.mobile.ui;
/*    2:     */ 
/*    3:     */ import com.mro.mobile.MobileApplicationException;
/*    4:     */ import com.mro.mobile.app.AbstractMobileDeviceApplication;
/*    5:     */ import com.mro.mobile.app.CurrentTimeProvider;
/*    6:     */ import com.mro.mobile.app.MobileDeviceAppSession;
/*    7:     */ import com.mro.mobile.app.OperationContainer;
/*    8:     */ import com.mro.mobile.app.OperationHandler;
/*    9:     */ import com.mro.mobile.mbo.MobileMbo;
/*   10:     */ import com.mro.mobile.mbo.MobileMboAttributeInfo;
/*   11:     */ import com.mro.mobile.mbo.MobileMboInfo;
/*   12:     */ import com.mro.mobile.mbo.MobileMboOrder;
/*   13:     */ import com.mro.mobile.mbo.MobileMboQBE;
/*   14:     */ import com.mro.mobile.mbo.MobileMboUtil;
/*   15:     */ import com.mro.mobile.persist.DefaultRDO;
/*   16:     */ import com.mro.mobile.persist.RDOEnumeration;
/*   17:     */ import com.mro.mobile.persist.RDORuntime;
/*   18:     */ import com.mro.mobile.persist.RDOTransactionManager;
/*   19:     */ import com.mro.mobile.persist.sql.MobileWhereClause;
/*   20:     */ import com.mro.mobile.util.BitFlags;
/*   21:     */ import com.mro.mobile.util.MobileLogger;
/*   22:     */ import com.mro.mobile.util.MobileLoggerFactory;
/*   23:     */ import java.net.ConnectException;
/*   24:     */ import java.util.Date;
/*   25:     */ import java.util.Enumeration;
/*   26:     */ import java.util.Hashtable;
/*   27:     */ import java.util.Vector;
/*   28:     */ 
/*   29:     */ public final class MobileMboDataBean
/*   30:     */ {
/*   31:  53 */   protected MobileLogger log = MobileLoggerFactory.getLogger("maximo.mobile.communication");
/*   32:     */   public static final int MOBILE_AND_SERVER = 0;
/*   33:     */   public static final int MOBILE_ONLY = 1;
/*   34:     */   public static final int SERVER_ONLY = 2;
/*   35:     */   private static final int ONLINE = 1;
/*   36:     */   private static final int DEPENDENT = 2;
/*   37:     */   private static final int READONLY = 3;
/*   38:     */   private static final int FILTERED = 4;
/*   39:     */   private static final int SECONDARY_FILTER = 5;
/*   40:  68 */   private String name = null;
/*   41:  72 */   private int currentPosition = -1;
/*   42:  76 */   private Vector data = new Vector();
/*   43:  80 */   private boolean closed = false;
/*   44:  84 */   private Enumeration dataEnumeration = null;
/*   45:  89 */   private MobileMboDataBeanManager dataBeanManager = null;
/*   46:  92 */   private MobileMboQBE qbe = null;
/*   47:  95 */   private MobileMboQBE internalQBE = null;
/*   48:  98 */   private MobileMboOrder order = null;
/*   49: 102 */   private MobileMboDataBean parentBean = null;
/*   50:     */   private AbstractMobileDeviceApplication app;
/*   51: 108 */   private BitFlags flags = new BitFlags(4);
/*   52: 113 */   private Vector dependents = new Vector();
/*   53: 117 */   private MobileMbo owner = null;
/*   54: 120 */   private int count = -1;
/*   55: 123 */   Hashtable originalMobileMbos = new Hashtable();
/*   56: 126 */   private boolean ignoreDefaultWorkSetFilter = false;
/*   57: 129 */   private Hashtable indexers = new Hashtable();
/*   58: 132 */   private MobileWhereClause whereClause = null;
/*   59: 135 */   private int whereClauseScope = 0;
/*   60:     */   
/*   61:     */   public void setAdditionalWhere(String whereClause)
/*   62:     */   {
/*   63: 150 */     setAdditionalWhere(whereClause, null);
/*   64:     */   }
/*   65:     */   
/*   66:     */   public void setAdditionalWhere(String whereClause, Object[] parameters)
/*   67:     */   {
/*   68: 168 */     if ((whereClause != null) && (whereClause.length() > 0)) {
/*   69: 170 */       this.whereClause = MobileWhereClause.createWhereClause(whereClause, parameters);
/*   70:     */     } else {
/*   71: 174 */       this.whereClause = null;
/*   72:     */     }
/*   73:     */   }
/*   74:     */   
/*   75:     */   public String getAdditionalWhere()
/*   76:     */   {
/*   77: 180 */     if (this.whereClause != null) {
/*   78: 182 */       return this.whereClause.getOriginalWhere();
/*   79:     */     }
/*   80: 186 */     return null;
/*   81:     */   }
/*   82:     */   
/*   83:     */   public Object[] getAdditionalWhereParams()
/*   84:     */   {
/*   85: 192 */     if (this.whereClause != null) {
/*   86: 194 */       return this.whereClause.getParameters();
/*   87:     */     }
/*   88: 198 */     return null;
/*   89:     */   }
/*   90:     */   
/*   91:     */   public void setAditionalWhereScope(int flag)
/*   92:     */   {
/*   93: 210 */     if ((flag < 0) || (flag > 2)) {
/*   94: 211 */       throw new IllegalArgumentException("Invalid availability type: " + flag);
/*   95:     */     }
/*   96: 213 */     this.whereClauseScope = flag;
/*   97:     */   }
/*   98:     */   
/*   99:     */   public int getAditionalWhereScope()
/*  100:     */   {
/*  101: 223 */     return this.whereClauseScope;
/*  102:     */   }
/*  103:     */   
/*  104:     */   public MobileMboDataBean(AbstractMobileDeviceApplication app, String name)
/*  105:     */   {
/*  106: 228 */     this(app, name, false);
/*  107:     */   }
/*  108:     */   
/*  109:     */   private MobileMboDataBean(AbstractMobileDeviceApplication app, String name, Enumeration mboEnum)
/*  110:     */   {
/*  111: 233 */     this(app, name, false);
/*  112: 234 */     setDataEnumeration(mboEnum);
/*  113:     */   }
/*  114:     */   
/*  115:     */   private MobileMboDataBean(AbstractMobileDeviceApplication app, String name, boolean online)
/*  116:     */   {
/*  117: 239 */     this.name = name;
/*  118: 240 */     this.app = app;
/*  119: 241 */     setOnline(online);
/*  120: 242 */     setQBE(new MobileMboDataBeanQBE(app.getAppName(), name));
/*  121: 243 */     this.internalQBE = new MobileMboDataBeanQBE(app.getAppName(), name);
/*  122:     */     try
/*  123:     */     {
/*  124: 247 */       setDefaultOrder();
/*  125: 248 */       setDefaultWorkSetFilter();
/*  126:     */       
/*  127: 250 */       MobileMboInfo info = MobileMboUtil.getMobileMboInfo(app.getAppName(), getName());
/*  128: 251 */       if ((info.isWorkset()) && (info.isAssociatedWithMbo())) {
/*  129: 253 */         if (!isOptionAuthorized("SAVE")) {
/*  130: 255 */           setReadOnly(true);
/*  131:     */         }
/*  132:     */       }
/*  133:     */     }
/*  134:     */     catch (Exception e)
/*  135:     */     {
/*  136: 261 */       MobileLoggerFactory.getDefaultLogger().warn("Failed creating new data bean", e);
/*  137:     */     }
/*  138:     */   }
/*  139:     */   
/*  140:     */   public void setDefaultOrder()
/*  141:     */     throws MobileApplicationException
/*  142:     */   {
/*  143: 273 */     MobileMboInfo info = MobileMboUtil.getMobileMboInfo(this.app.getAppName(), getName());
/*  144:     */     
/*  145: 275 */     MobileMboOrder curOrder = new MobileMboOrder();
/*  146: 276 */     MobileMboOrder defOrder = info.getDefaultOrder();
/*  147: 277 */     Enumeration defAttrOrder = defOrder.getOrderedAttributes();
/*  148: 278 */     while (defAttrOrder.hasMoreElements())
/*  149:     */     {
/*  150: 280 */       String attr = (String)defAttrOrder.nextElement();
/*  151: 281 */       curOrder.setOrder(attr, defOrder.getOrder(attr));
/*  152:     */     }
/*  153: 284 */     setOrder(curOrder);
/*  154:     */   }
/*  155:     */   
/*  156:     */   public void setIgnoreDefaultWorkSetFilter(boolean ignore)
/*  157:     */   {
/*  158: 293 */     this.ignoreDefaultWorkSetFilter = ignore;
/*  159:     */   }
/*  160:     */   
/*  161:     */   private void setDefaultWorkSetFilter()
/*  162:     */     throws MobileApplicationException
/*  163:     */   {
/*  164: 304 */     if (this.ignoreDefaultWorkSetFilter)
/*  165:     */     {
/*  166: 306 */       this.internalQBE.setQBE("_DONE", null);
/*  167: 307 */       getQBE().setQBE("_DONE", null);
/*  168: 308 */       return;
/*  169:     */     }
/*  170: 311 */     MobileMboInfo mobileMboInfo = getMobileMboInfo();
/*  171: 314 */     if (((mobileMboInfo.isWorkset()) || (mobileMboInfo.isLocalWorksetUpload())) && (mobileMboInfo.getParent() == null)) {
/*  172: 317 */       setInternalQBE("_DONE", "0");
/*  173:     */     }
/*  174:     */   }
/*  175:     */   
/*  176:     */   public void setModifiedFilter()
/*  177:     */     throws MobileApplicationException
/*  178:     */   {
/*  179: 328 */     MobileMboInfo mobileMboInfo = getMobileMboInfo();
/*  180: 331 */     if (((mobileMboInfo.isWorkset()) || (mobileMboInfo.isLocalWorksetUpload())) && (mobileMboInfo.getParent() == null))
/*  181:     */     {
/*  182: 334 */       setInternalQBE("_MODIFIED", "1");
/*  183: 335 */       setInternalQBE("_ERR", "0");
/*  184: 336 */       reset();
/*  185:     */     }
/*  186:     */   }
/*  187:     */   
/*  188:     */   private void setDataEnumeration(Enumeration mboEnum)
/*  189:     */   {
/*  190: 348 */     this.dataEnumeration = mboEnum;
/*  191:     */   }
/*  192:     */   
/*  193:     */   private Enumeration getDataEnumeration()
/*  194:     */   {
/*  195: 358 */     return this.dataEnumeration;
/*  196:     */   }
/*  197:     */   
/*  198:     */   public String getName()
/*  199:     */   {
/*  200: 368 */     return this.name;
/*  201:     */   }
/*  202:     */   
/*  203:     */   public void setOnline(boolean online)
/*  204:     */   {
/*  205: 379 */     this.flags.set(1, online);
/*  206:     */   }
/*  207:     */   
/*  208:     */   public boolean isOnline()
/*  209:     */   {
/*  210: 390 */     return this.flags.isSet(1);
/*  211:     */   }
/*  212:     */   
/*  213:     */   private void setDependent(boolean dependent)
/*  214:     */   {
/*  215: 400 */     this.flags.set(2, dependent);
/*  216:     */   }
/*  217:     */   
/*  218:     */   public boolean isDependent()
/*  219:     */   {
/*  220: 410 */     return this.flags.isSet(2);
/*  221:     */   }
/*  222:     */   
/*  223:     */   public void setReadOnly(boolean readOnly)
/*  224:     */     throws MobileApplicationException
/*  225:     */   {
/*  226: 422 */     this.flags.set(3, readOnly);
/*  227:     */     
/*  228:     */ 
/*  229: 425 */     int currentSize = getCurrentSize();
/*  230: 426 */     for (int i = 0; i < currentSize; i++)
/*  231:     */     {
/*  232: 428 */       MobileMbo mobileMbo = getMobileMbo(i);
/*  233: 429 */       mobileMbo.setFlag(1, readOnly);
/*  234:     */     }
/*  235:     */   }
/*  236:     */   
/*  237:     */   public boolean isReadOnly()
/*  238:     */   {
/*  239: 440 */     return this.flags.isSet(3);
/*  240:     */   }
/*  241:     */   
/*  242:     */   public boolean isMobileMboReadOnly()
/*  243:     */     throws MobileApplicationException
/*  244:     */   {
/*  245: 451 */     if (getCurrentPosition() == -1) {
/*  246: 454 */       setCurrentPosition(0);
/*  247:     */     }
/*  248: 457 */     return isMobileMboReadOnly(getCurrentPosition());
/*  249:     */   }
/*  250:     */   
/*  251:     */   public boolean isMobileMboReadOnly(int index)
/*  252:     */     throws MobileApplicationException
/*  253:     */   {
/*  254: 469 */     MobileMbo mobileMbo = getMobileMbo(index);
/*  255: 470 */     if (mobileMbo == null) {
/*  256: 472 */       return isReadOnly();
/*  257:     */     }
/*  258: 475 */     return mobileMbo.isReadOnly();
/*  259:     */   }
/*  260:     */   
/*  261:     */   public boolean isMobileMboModified()
/*  262:     */     throws MobileApplicationException
/*  263:     */   {
/*  264: 486 */     if (getCurrentPosition() == -1) {
/*  265: 489 */       setCurrentPosition(0);
/*  266:     */     }
/*  267: 492 */     return isMobileMboModified(getCurrentPosition());
/*  268:     */   }
/*  269:     */   
/*  270:     */   public boolean isMobileMboModified(int index)
/*  271:     */     throws MobileApplicationException
/*  272:     */   {
/*  273: 504 */     MobileMbo mobileMbo = getMobileMbo(index);
/*  274: 505 */     if (mobileMbo == null) {
/*  275: 507 */       return false;
/*  276:     */     }
/*  277: 510 */     return mobileMbo.isModified();
/*  278:     */   }
/*  279:     */   
/*  280:     */   private void setQBE(MobileMboQBE qbe)
/*  281:     */   {
/*  282: 520 */     this.qbe = qbe;
/*  283:     */   }
/*  284:     */   
/*  285:     */   public MobileMboQBE getQBE()
/*  286:     */   {
/*  287: 530 */     return this.qbe;
/*  288:     */   }
/*  289:     */   
/*  290:     */   public void setInternalQBE(String attributeName, String value)
/*  291:     */     throws MobileApplicationException
/*  292:     */   {
/*  293: 542 */     this.internalQBE.setQBE(attributeName, value);
/*  294: 543 */     getQBE().setQBE(attributeName, value);
/*  295:     */   }
/*  296:     */   
/*  297:     */   public void setOrder(MobileMboOrder order)
/*  298:     */   {
/*  299: 553 */     this.order = order;
/*  300:     */   }
/*  301:     */   
/*  302:     */   public MobileMboOrder getOrder()
/*  303:     */   {
/*  304: 563 */     return this.order;
/*  305:     */   }
/*  306:     */   
/*  307:     */   public int getCurrentSize()
/*  308:     */   {
/*  309: 574 */     return this.data.size();
/*  310:     */   }
/*  311:     */   
/*  312:     */   public boolean isToBeSaved()
/*  313:     */     throws MobileApplicationException
/*  314:     */   {
/*  315: 583 */     for (int i = 0; i < getCurrentSize(); i++)
/*  316:     */     {
/*  317: 585 */       MobileMbo mbo = getMobileMbo(i);
/*  318: 586 */       if ((mbo != null) && (mbo.isToBeSaved())) {
/*  319: 587 */         return true;
/*  320:     */       }
/*  321:     */     }
/*  322: 589 */     return false;
/*  323:     */   }
/*  324:     */   
/*  325:     */   public int count()
/*  326:     */     throws MobileApplicationException
/*  327:     */   {
/*  328: 600 */     if (this.closed)
/*  329:     */     {
/*  330: 602 */       this.count = getCurrentSize();
/*  331: 603 */       return this.count;
/*  332:     */     }
/*  333: 606 */     final MobileWhereClause whereClauseToUse = getWhereClauseForScope();
/*  334: 608 */     if (this.count == -1) {
/*  335: 610 */       if (this.owner != null) {
/*  336: 612 */         this.count = this.owner.getDependentSize(getName(), getQBE(), whereClauseToUse);
/*  337: 616 */       } else if (isOnline()) {
/*  338:     */         try
/*  339:     */         {
/*  340: 622 */           MobileSafeRemoteInvoker invoker = new MobileSafeRemoteInvoker()
/*  341:     */           {
/*  342:     */             public void remoteCall()
/*  343:     */               throws MobileApplicationException
/*  344:     */             {
/*  345: 624 */               Integer result = new Integer(MobileMboDataBean.this.app.getMobileMboCountRemote(MobileMboDataBean.this.getName(), ((MobileMboDataBeanQBE)MobileMboDataBean.this.getQBE()).getInternal(), whereClauseToUse));
/*  346: 625 */               setResult(result);
/*  347:     */             }
/*  348: 627 */           };
/*  349: 628 */           invoker.execute();
/*  350: 629 */           if (invoker.isCompleted())
/*  351:     */           {
/*  352: 630 */             if (!invoker.isFailed()) {
/*  353: 631 */               this.count = ((Integer)invoker.getResult()).intValue();
/*  354:     */             } else {
/*  355: 633 */               throw invoker.getMobileApplicationException();
/*  356:     */             }
/*  357:     */           }
/*  358:     */           else {
/*  359: 639 */             throw new MobileApplicationException("commfailure");
/*  360:     */           }
/*  361:     */         }
/*  362:     */         catch (MobileApplicationException e)
/*  363:     */         {
/*  364: 644 */           if ((e.getNestedException() instanceof ConnectException))
/*  365:     */           {
/*  366: 649 */             setOnline(false);
/*  367: 650 */             throw new MobileApplicationException("commfailure", e.getNestedException());
/*  368:     */           }
/*  369: 654 */           throw e;
/*  370:     */         }
/*  371:     */       } else {
/*  372: 660 */         this.count = this.app.getMobileMboCount(getName(), getQBE(), whereClauseToUse);
/*  373:     */       }
/*  374:     */     }
/*  375: 665 */     if (this.count == 0)
/*  376:     */     {
/*  377: 667 */       this.closed = true;
/*  378: 668 */       if (this.owner != null) {
/*  379: 670 */         this.owner.setDependentDataFetched(getName());
/*  380:     */       }
/*  381:     */     }
/*  382: 673 */     return this.count;
/*  383:     */   }
/*  384:     */   
/*  385:     */   protected MobileWhereClause getWhereClauseForScope()
/*  386:     */   {
/*  387: 678 */     switch (this.whereClauseScope)
/*  388:     */     {
/*  389:     */     case 1: 
/*  390: 681 */       if (isOnline()) {
/*  391:     */         break;
/*  392:     */       }
/*  393:     */     case 2: 
/*  394: 684 */       if (!isOnline()) {
/*  395:     */         break;
/*  396:     */       }
/*  397:     */     case 0: 
/*  398: 687 */       return this.whereClause;
/*  399:     */     }
/*  400: 689 */     return null;
/*  401:     */   }
/*  402:     */   
/*  403:     */   public int getModifiedCount()
/*  404:     */     throws MobileApplicationException
/*  405:     */   {
/*  406: 702 */     if (isOnline()) {
/*  407: 704 */       return 0;
/*  408:     */     }
/*  409: 707 */     if (this.owner != null)
/*  410:     */     {
/*  411: 709 */       if (this.owner.isModified()) {
/*  412: 711 */         return this.owner.getDependentSize(getName(), getQBE());
/*  413:     */       }
/*  414: 714 */       return 0;
/*  415:     */     }
/*  416: 717 */     return this.app.getMobileMboModifiedCount(getName());
/*  417:     */   }
/*  418:     */   
/*  419:     */   public int getErrorCount()
/*  420:     */     throws MobileApplicationException
/*  421:     */   {
/*  422: 729 */     if (isOnline()) {
/*  423: 731 */       return 0;
/*  424:     */     }
/*  425: 734 */     if (this.owner != null) {
/*  426: 736 */       return 0;
/*  427:     */     }
/*  428: 739 */     if (getMobileMboInfo().isLocalWorkset()) {
/*  429: 741 */       return 0;
/*  430:     */     }
/*  431: 744 */     return this.app.getMobileMboErrorCount(getName());
/*  432:     */   }
/*  433:     */   
/*  434:     */   public int getCurrentPosition()
/*  435:     */   {
/*  436: 754 */     return this.currentPosition;
/*  437:     */   }
/*  438:     */   
/*  439:     */   public boolean setCurrentPosition(int index)
/*  440:     */     throws MobileApplicationException
/*  441:     */   {
/*  442: 769 */     if (this.currentPosition == index) {
/*  443: 771 */       return true;
/*  444:     */     }
/*  445: 775 */     fetchData(index);
/*  446: 779 */     if ((index >= 0) && (index < this.data.size()))
/*  447:     */     {
/*  448: 781 */       this.currentPosition = index;
/*  449: 782 */       return true;
/*  450:     */     }
/*  451: 785 */     return false;
/*  452:     */   }
/*  453:     */   
/*  454:     */   public boolean dataExists(int index)
/*  455:     */     throws MobileApplicationException
/*  456:     */   {
/*  457: 800 */     fetchData(index);
/*  458: 804 */     if ((index >= 0) && (index < this.data.size())) {
/*  459: 806 */       return true;
/*  460:     */     }
/*  461: 809 */     return false;
/*  462:     */   }
/*  463:     */   
/*  464:     */   private void fetchData(final int index)
/*  465:     */     throws MobileApplicationException
/*  466:     */   {
/*  467: 817 */     final MobileWhereClause whereClauseToUse = getWhereClauseForScope();
/*  468: 818 */     if (this.closed) {
/*  469: 820 */       return;
/*  470:     */     }
/*  471: 823 */     if (index < getCurrentSize()) {
/*  472: 825 */       return;
/*  473:     */     }
/*  474: 828 */     if ((getDataEnumeration() == null) || (isOnline())) {
/*  475: 830 */       if (isOnline())
/*  476:     */       {
/*  477: 832 */         if (this.owner != null)
/*  478:     */         {
/*  479: 834 */           setDataEnumeration(this.owner.getDependents(getName()));
/*  480:     */         }
/*  481:     */         else
/*  482:     */         {
/*  483: 839 */           MobileSafeRemoteInvoker invoker = new MobileSafeRemoteInvoker()
/*  484:     */           {
/*  485:     */             public void remoteCall()
/*  486:     */               throws MobileApplicationException
/*  487:     */             {
/*  488: 841 */               int startIndex = MobileMboDataBean.this.getCurrentSize();
/*  489: 842 */               int dataSize = index - startIndex + 30;
/*  490: 843 */               Enumeration result = MobileMboDataBean.this.app.getMobileMbosRemote(MobileMboDataBean.this.getName(), startIndex, dataSize, ((MobileMboDataBeanQBE)MobileMboDataBean.this.getQBE()).getInternal(), whereClauseToUse, MobileMboDataBean.this.getOrder());
/*  491: 844 */               setResult(result);
/*  492:     */             }
/*  493: 846 */           };
/*  494: 847 */           invoker.execute();
/*  495: 848 */           if (invoker.isCompleted())
/*  496:     */           {
/*  497: 849 */             if (!invoker.isFailed()) {
/*  498: 850 */               setDataEnumeration((Enumeration)invoker.getResult());
/*  499:     */             } else {
/*  500: 852 */               throw invoker.getMobileApplicationException();
/*  501:     */             }
/*  502:     */           }
/*  503:     */           else {
/*  504: 858 */             throw new MobileApplicationException("commfailure");
/*  505:     */           }
/*  506: 861 */           if (!getDataEnumeration().hasMoreElements()) {
/*  507: 863 */             this.closed = true;
/*  508:     */           }
/*  509:     */         }
/*  510:     */       }
/*  511: 869 */       else if (this.owner != null) {
/*  512: 871 */         setDataEnumeration(this.owner.getDependents(getName(), getQBE(), whereClauseToUse, getOrder()));
/*  513:     */       } else {
/*  514: 876 */         setDataEnumeration(this.app.getMobileMbos(getName(), getQBE(), whereClauseToUse, getOrder()));
/*  515:     */       }
/*  516:     */     }
/*  517: 882 */     while (this.dataEnumeration.hasMoreElements())
/*  518:     */     {
/*  519: 886 */       if ((!isOnline()) && 
/*  520:     */       
/*  521: 888 */         (index < this.data.size())) {
/*  522:     */         break;
/*  523:     */       }
/*  524: 894 */       Object obj = this.dataEnumeration.nextElement();
/*  525:     */       
/*  526: 896 */       MobileMbo mobileMbo = (MobileMbo)obj;
/*  527: 897 */       if (isReadOnly()) {
/*  528: 899 */         mobileMbo.setFlag(1, true);
/*  529:     */       }
/*  530: 901 */       mobileMbo.setOwner(this.owner);
/*  531: 902 */       this.data.addElement(obj);
/*  532:     */     }
/*  533: 905 */     if (canClose()) {
/*  534: 907 */       this.closed = true;
/*  535:     */     }
/*  536:     */   }
/*  537:     */   
/*  538:     */   public void close()
/*  539:     */   {
/*  540: 916 */     this.closed = true;
/*  541:     */   }
/*  542:     */   
/*  543:     */   private boolean canClose()
/*  544:     */   {
/*  545: 926 */     if (this.closed) {
/*  546: 928 */       return true;
/*  547:     */     }
/*  548: 931 */     if (isOnline()) {
/*  549: 933 */       return false;
/*  550:     */     }
/*  551: 936 */     if (!getDataEnumeration().hasMoreElements()) {
/*  552: 938 */       return true;
/*  553:     */     }
/*  554: 941 */     return false;
/*  555:     */   }
/*  556:     */   
/*  557:     */   public String getValue(String attribute)
/*  558:     */     throws MobileApplicationException
/*  559:     */   {
/*  560: 955 */     if (getCurrentPosition() == -1) {
/*  561: 958 */       setCurrentPosition(0);
/*  562:     */     }
/*  563: 961 */     return getValue(this.currentPosition, attribute);
/*  564:     */   }
/*  565:     */   
/*  566:     */   public String getValue(int index, String attribute)
/*  567:     */     throws MobileApplicationException
/*  568:     */   {
/*  569: 976 */     MobileMbo mbo = (MobileMbo)getDataObject(index);
/*  570: 977 */     if (mbo == null) {
/*  571: 979 */       return "";
/*  572:     */     }
/*  573: 987 */     int dotIndex = attribute.indexOf(".");
/*  574: 988 */     if (dotIndex > 0)
/*  575:     */     {
/*  576: 990 */       String dependentName = attribute.substring(0, dotIndex);
/*  577: 991 */       String dependentAttribute = attribute.substring(dotIndex + 1);
/*  578:     */       
/*  579: 993 */       MobileMboDataBean dependentDataBean = getDataBean(index, dependentName);
/*  580: 994 */       if (dependentDataBean == null) {
/*  581: 996 */         return "";
/*  582:     */       }
/*  583: 998 */       String dependentAttrValue = dependentDataBean.getValue(0, dependentAttribute);
/*  584: 999 */       return dependentAttrValue;
/*  585:     */     }
/*  586:1002 */     String value = mbo.getValue(attribute);
/*  587:     */     
/*  588:1004 */     MobileMboDataFormatter formatter = MobileMboDataFormatter.getInstance();
/*  589:1005 */     if (formatter != null) {
/*  590:1007 */       value = formatter.formatInternalToDispaly(value, getMobileMboInfo().getAttributeInfo(attribute));
/*  591:     */     }
/*  592:1010 */     return value;
/*  593:     */   }
/*  594:     */   
/*  595:     */   public void setValue(String attribute, String value)
/*  596:     */     throws MobileApplicationException
/*  597:     */   {
/*  598:1027 */     if (getCurrentPosition() == -1) {
/*  599:1030 */       setCurrentPosition(0);
/*  600:     */     }
/*  601:1033 */     setValue(this.currentPosition, attribute, value, true);
/*  602:     */   }
/*  603:     */   
/*  604:     */   public void setValue(String attribute, String value, boolean accessCheck)
/*  605:     */     throws MobileApplicationException
/*  606:     */   {
/*  607:1051 */     if (getCurrentPosition() == -1) {
/*  608:1054 */       setCurrentPosition(0);
/*  609:     */     }
/*  610:1057 */     setValue(this.currentPosition, attribute, value, accessCheck);
/*  611:     */   }
/*  612:     */   
/*  613:     */   public void setValue(int index, String attribute, String value)
/*  614:     */     throws MobileApplicationException
/*  615:     */   {
/*  616:1075 */     setValue(index, attribute, value, true);
/*  617:     */   }
/*  618:     */   
/*  619:     */   public void setValue(int index, String attribute, String value, boolean accessCheck)
/*  620:     */     throws MobileApplicationException
/*  621:     */   {
/*  622:1094 */     MobileMbo mbo = (MobileMbo)getDataObject(index);
/*  623:1095 */     if (mbo == null) {
/*  624:1097 */       return;
/*  625:     */     }
/*  626:1100 */     if (value != null) {
/*  627:1103 */       value = value.trim();
/*  628:     */     }
/*  629:1106 */     MobileMboDataFormatter formatter = MobileMboDataFormatter.getInstance();
/*  630:1107 */     if (formatter != null) {
/*  631:1109 */       value = formatter.formatDisplayToInternal(value, getMobileMboInfo().getAttributeInfo(attribute));
/*  632:     */     }
/*  633:1112 */     if (!mbo.isReadOnly(attribute)) {
/*  634:1114 */       if (this.originalMobileMbos.get(new Integer(index)) == null)
/*  635:     */       {
/*  636:1116 */         MobileMbo cloneMbo = mbo.simpleClone();
/*  637:     */         
/*  638:1118 */         this.originalMobileMbos.put(new Integer(index), cloneMbo);
/*  639:     */       }
/*  640:     */     }
/*  641:1122 */     mbo.setValue(attribute, value, accessCheck);
/*  642:     */   }
/*  643:     */   
/*  644:     */   Enumeration getCurrentDependents(int index)
/*  645:     */     throws MobileApplicationException
/*  646:     */   {
/*  647:1135 */     if (index >= this.dependents.size()) {
/*  648:1137 */       return null;
/*  649:     */     }
/*  650:1140 */     Object obj = this.dependents.elementAt(index);
/*  651:1141 */     if (obj == null) {
/*  652:1143 */       return null;
/*  653:     */     }
/*  654:1145 */     Hashtable dependentBeans = null;
/*  655:1146 */     dependentBeans = (Hashtable)obj;
/*  656:     */     
/*  657:1148 */     return dependentBeans.keys();
/*  658:     */   }
/*  659:     */   
/*  660:     */   public MobileMboDataBean getDataBean(String dependentName)
/*  661:     */     throws MobileApplicationException
/*  662:     */   {
/*  663:1161 */     if (getCurrentPosition() == -1) {
/*  664:1164 */       setCurrentPosition(0);
/*  665:     */     }
/*  666:1167 */     return getDataBean(this.currentPosition, dependentName);
/*  667:     */   }
/*  668:     */   
/*  669:     */   public MobileMboDataBean getDataBean(int index, String dependentName)
/*  670:     */     throws MobileApplicationException
/*  671:     */   {
/*  672:1181 */     MobileMbo mbo = (MobileMbo)getDataObject(index);
/*  673:1182 */     if (mbo == null) {
/*  674:1184 */       return null;
/*  675:     */     }
/*  676:1188 */     if (index >= this.dependents.size()) {
/*  677:1191 */       for (int i = this.dependents.size() - 1; i < index + 1; i++) {
/*  678:1193 */         this.dependents.addElement(null);
/*  679:     */       }
/*  680:     */     }
/*  681:1197 */     Object obj = this.dependents.elementAt(index);
/*  682:1198 */     Hashtable dependentBeans = null;
/*  683:1199 */     if (obj == null)
/*  684:     */     {
/*  685:1201 */       dependentBeans = new Hashtable();
/*  686:1202 */       this.dependents.setElementAt(dependentBeans, index);
/*  687:     */     }
/*  688:     */     else
/*  689:     */     {
/*  690:1206 */       dependentBeans = (Hashtable)obj;
/*  691:     */     }
/*  692:1209 */     if (dependentBeans.get(dependentName) != null) {
/*  693:1211 */       return (MobileMboDataBean)dependentBeans.get(dependentName);
/*  694:     */     }
/*  695:1214 */     MobileMboInfo depInfo = MobileMboUtil.getMobileMboInfo(this.app.getAppName(), dependentName);
/*  696:1215 */     Enumeration mboEnum = mbo.getDependents(dependentName, null, depInfo.getDefaultOrder());
/*  697:     */     
/*  698:1217 */     String depDataBeanName = dependentName;
/*  699:1218 */     if (dependentName.equals("CHILDREN")) {
/*  700:1220 */       depDataBeanName = getName();
/*  701:     */     }
/*  702:1222 */     MobileMboDataBean dataBean = new MobileMboDataBean(this.app, depDataBeanName, mboEnum);
/*  703:1223 */     dataBean.setDependent(true);
/*  704:1224 */     dataBean.setDataBeanManager(getDataBeanManager());
/*  705:1225 */     dataBean.setOwner(mbo);
/*  706:1226 */     dependentBeans.put(dependentName, dataBean);
/*  707:1227 */     dataBean.setParentBean(this);
/*  708:1228 */     return dataBean;
/*  709:     */   }
/*  710:     */   
/*  711:     */   private void setOwner(MobileMbo owner)
/*  712:     */   {
/*  713:1238 */     this.owner = owner;
/*  714:     */   }
/*  715:     */   
/*  716:     */   public MobileMbo getOwner()
/*  717:     */   {
/*  718:1249 */     return this.owner;
/*  719:     */   }
/*  720:     */   
/*  721:     */   public MobileMbo getTopOwner()
/*  722:     */   {
/*  723:1259 */     if (this.owner == null) {
/*  724:1261 */       return null;
/*  725:     */     }
/*  726:1264 */     return getTopOwner(this.owner);
/*  727:     */   }
/*  728:     */   
/*  729:     */   private MobileMbo getTopOwner(MobileMbo mobileMbo)
/*  730:     */   {
/*  731:1269 */     if (mobileMbo == null) {
/*  732:1271 */       return null;
/*  733:     */     }
/*  734:1274 */     MobileMbo mboOwner = mobileMbo.getOwner();
/*  735:1275 */     if (mboOwner == null) {
/*  736:1277 */       return mobileMbo;
/*  737:     */     }
/*  738:1280 */     return getTopOwner(mboOwner);
/*  739:     */   }
/*  740:     */   
/*  741:     */   public void insert()
/*  742:     */     throws MobileApplicationException
/*  743:     */   {
/*  744:1290 */     if (isReadOnly())
/*  745:     */     {
/*  746:1292 */       MobileMboInfo info = MobileMboUtil.getMobileMboInfo(this.app.getAppName(), getName());
/*  747:1293 */       throw new MobileApplicationException("readonly", new Object[] { info.getDescription() });
/*  748:     */     }
/*  749:1296 */     if (getCurrentPosition() == -1) {
/*  750:1298 */       insert(0);
/*  751:     */     } else {
/*  752:1302 */       insert(getCurrentPosition());
/*  753:     */     }
/*  754:     */   }
/*  755:     */   
/*  756:     */   public void insert(int index)
/*  757:     */     throws MobileApplicationException
/*  758:     */   {
/*  759:1315 */     if ((index < 0) || (index > this.data.size())) {
/*  760:1317 */       throw new MobileApplicationException("Invalid index " + index);
/*  761:     */     }
/*  762:1320 */     MobileMbo mbo = null;
/*  763:1322 */     if (getOwner() == null)
/*  764:     */     {
/*  765:1324 */       DefaultRDO rdo = new DefaultRDO(this.app.getAppName(), true);
/*  766:1325 */       rdo.setName(this.name);
/*  767:1326 */       long uid = this.app.getUniqueNumber(getName(), "_" + getName());
/*  768:1327 */       rdo.setLongValue("_ID", uid);
/*  769:     */       
/*  770:1329 */       mbo = new MobileMbo(rdo);
/*  771:1330 */       mbo.setOwner(getOwner());
/*  772:1331 */       mbo.setNew();
/*  773:     */     }
/*  774:     */     else
/*  775:     */     {
/*  776:1336 */       int i = 0;
/*  777:     */       for (;;)
/*  778:     */       {
/*  779:1339 */         MobileMbo mboDep = getMobileMbo(i);
/*  780:1340 */         if (mboDep == null) {
/*  781:     */           break;
/*  782:     */         }
/*  783:1345 */         i++;
/*  784:     */       }
/*  785:1347 */       count();
/*  786:     */       
/*  787:1349 */       MobileMbo ownerMbo = getOwner();
/*  788:1350 */       mbo = ownerMbo.createDependent(getName());
/*  789:1351 */       long uid = this.app.getUniqueNumber(getName(), "_" + getName());
/*  790:1352 */       mbo.setNew();
/*  791:1353 */       mbo.setLongValue("_ID", uid);
/*  792:1355 */       if (getOwner() != null) {
/*  793:1357 */         mbo.setLongValue("_PARENTID", getOwner().getLongValue("_ID"));
/*  794:     */       }
/*  795:     */     }
/*  796:1362 */     applyDefaultMultiSiteValues(mbo);
/*  797:     */     
/*  798:1364 */     this.data.insertElementAt(mbo, index);
/*  799:1367 */     if (index >= this.dependents.size()) {
/*  800:1370 */       for (int i = this.dependents.size() - 1; i < index + 1; i++) {
/*  801:1372 */         this.dependents.addElement(null);
/*  802:     */       }
/*  803:     */     }
/*  804:1375 */     this.dependents.insertElementAt(null, index);
/*  805:     */     
/*  806:1377 */     setCurrentPosition(index);
/*  807:     */     
/*  808:1379 */     count();
/*  809:1380 */     this.count += 1;
/*  810:1383 */     if (this.originalMobileMbos != null)
/*  811:     */     {
/*  812:1385 */       Hashtable newOriginalMbos = new Hashtable();
/*  813:1386 */       int curSize = this.data.size();
/*  814:1387 */       for (int i = index; i < curSize; i++)
/*  815:     */       {
/*  816:1389 */         Object originalMbo = this.originalMobileMbos.get(new Integer(i));
/*  817:1390 */         if (originalMbo != null) {
/*  818:1392 */           newOriginalMbos.put(new Integer(i + 1), originalMbo);
/*  819:     */         }
/*  820:     */       }
/*  821:1395 */       this.originalMobileMbos = newOriginalMbos;
/*  822:     */     }
/*  823:     */   }
/*  824:     */   
/*  825:     */   private void applyDefaultMultiSiteValues(MobileMbo mbo)
/*  826:     */     throws MobileApplicationException
/*  827:     */   {
/*  828:1408 */     String defaultSite = getDefaultInsertSite();
/*  829:1409 */     MobileMboInfo mobileMboInfo = getMobileMboInfo();
/*  830:1411 */     if (mobileMboInfo.isSystemLevel())
/*  831:     */     {
/*  832:1413 */       if (mobileMboInfo.getSiteAttribute() != null) {
/*  833:1415 */         if ((defaultSite == null) || (defaultSite.length() == 0)) {
/*  834:1418 */           throw new MobileApplicationException("nodefaultsite");
/*  835:     */         }
/*  836:     */       }
/*  837:     */     }
/*  838:1424 */     else if (mobileMboInfo.getSiteAttribute() != null) {
/*  839:1426 */       if ((defaultSite == null) || (defaultSite.length() == 0)) {
/*  840:1429 */         throw new MobileApplicationException("nodefaultsite");
/*  841:     */       }
/*  842:     */     }
/*  843:1434 */     if ((defaultSite == null) || (defaultSite.length() == 0)) {
/*  844:1436 */       return;
/*  845:     */     }
/*  846:1439 */     MultiSiteFilter msFilter = new MultiSiteFilter();
/*  847:     */     
/*  848:1441 */     String defaultOrgId = msFilter.getOrgId(defaultSite);
/*  849:1442 */     String defaultItemSetId = msFilter.getItemSetIdOfOrg(defaultOrgId);
/*  850:1443 */     String defaultCompanySetId = msFilter.getCompanySetIdOfOrg(defaultOrgId);
/*  851:     */     
/*  852:1445 */     String siteAttribute = mobileMboInfo.getSiteAttribute();
/*  853:1446 */     if (siteAttribute != null) {
/*  854:1448 */       mbo.setValue(siteAttribute, defaultSite);
/*  855:     */     }
/*  856:1451 */     String orgAttribute = mobileMboInfo.getOrgAttribute();
/*  857:1452 */     if (orgAttribute != null) {
/*  858:1454 */       mbo.setValue(orgAttribute, defaultOrgId);
/*  859:     */     }
/*  860:1457 */     String itemSetAttribute = mobileMboInfo.getItemSetAttribute();
/*  861:1458 */     if (itemSetAttribute != null) {
/*  862:1460 */       mbo.setValue(itemSetAttribute, defaultItemSetId);
/*  863:     */     }
/*  864:1463 */     String companySetAttribute = mobileMboInfo.getCompanySetAttribute();
/*  865:1464 */     if (companySetAttribute != null) {
/*  866:1466 */       mbo.setValue(companySetAttribute, defaultCompanySetId);
/*  867:     */     }
/*  868:     */   }
/*  869:     */   
/*  870:     */   private String getDefaultInsertSite()
/*  871:     */     throws MobileApplicationException
/*  872:     */   {
/*  873:1479 */     MobileMboDataBeanManager dataBeanManager = new MobileMboDataBeanManager("USER");
/*  874:1480 */     MobileMboDataBean userDataBean = dataBeanManager.getDataBean();
/*  875:1481 */     userDataBean.reset();
/*  876:     */     
/*  877:     */ 
/*  878:1484 */     MobileMbo siteMbo = userDataBean.getMobileMbo(0);
/*  879:1485 */     if (siteMbo == null) {
/*  880:1487 */       return null;
/*  881:     */     }
/*  882:1490 */     String defaultSite = siteMbo.getValue("DEFSITE");
/*  883:1491 */     return defaultSite;
/*  884:     */   }
/*  885:     */   
/*  886:     */   public void delete()
/*  887:     */     throws MobileApplicationException
/*  888:     */   {
/*  889:1503 */     if (getCurrentPosition() == -1) {
/*  890:1506 */       setCurrentPosition(0);
/*  891:     */     }
/*  892:1509 */     delete(getCurrentPosition());
/*  893:     */   }
/*  894:     */   
/*  895:     */   public void delete(int index)
/*  896:     */     throws MobileApplicationException
/*  897:     */   {
/*  898:1523 */     MobileMbo mobileMbo = getMobileMbo(index);
/*  899:1524 */     if (mobileMbo == null) {
/*  900:1526 */       return;
/*  901:     */     }
/*  902:1529 */     mobileMbo.delete();
/*  903:     */   }
/*  904:     */   
/*  905:     */   public void deleteLocal()
/*  906:     */     throws MobileApplicationException
/*  907:     */   {
/*  908:1542 */     if (getCurrentPosition() == -1) {
/*  909:1545 */       setCurrentPosition(0);
/*  910:     */     }
/*  911:1548 */     deleteLocal(getCurrentPosition());
/*  912:     */   }
/*  913:     */   
/*  914:     */   public void deleteLocal(int index)
/*  915:     */     throws MobileApplicationException
/*  916:     */   {
/*  917:1562 */     MobileMbo mobileMbo = getMobileMbo(index);
/*  918:1563 */     if (mobileMbo == null) {
/*  919:1565 */       return;
/*  920:     */     }
/*  921:1568 */     mobileMbo.deleteLocal();
/*  922:     */   }
/*  923:     */   
/*  924:     */   public void remove()
/*  925:     */     throws MobileApplicationException
/*  926:     */   {
/*  927:1578 */     if (getCurrentPosition() == -1) {
/*  928:1581 */       setCurrentPosition(0);
/*  929:     */     }
/*  930:1584 */     remove(getCurrentPosition());
/*  931:     */   }
/*  932:     */   
/*  933:     */   public void remove(int index)
/*  934:     */     throws MobileApplicationException
/*  935:     */   {
/*  936:1595 */     if (index < this.data.size())
/*  937:     */     {
/*  938:1597 */       int curPos = getCurrentPosition();
/*  939:     */       
/*  940:1599 */       MobileMbo mbo = (MobileMbo)this.data.elementAt(index);
/*  941:1600 */       if (this.owner != null) {
/*  942:1602 */         this.owner.removeDependent(getName(), mbo);
/*  943:     */       }
/*  944:1604 */       this.data.removeElementAt(index);
/*  945:1605 */       if ((this.dependents != null) && (index < this.dependents.size())) {
/*  946:1607 */         this.dependents.removeElementAt(index);
/*  947:     */       }
/*  948:1609 */       if (curPos >= index)
/*  949:     */       {
/*  950:1611 */         curPos -= 1;
/*  951:1612 */         setCurrentPosition(curPos);
/*  952:     */       }
/*  953:1614 */       count();
/*  954:1615 */       this.count -= 1;
/*  955:     */     }
/*  956:     */   }
/*  957:     */   
/*  958:     */   public MobileMbo getMobileMbo()
/*  959:     */     throws MobileApplicationException
/*  960:     */   {
/*  961:1627 */     if (getCurrentPosition() == -1) {
/*  962:1630 */       setCurrentPosition(0);
/*  963:     */     }
/*  964:1633 */     return getMobileMbo(getCurrentPosition());
/*  965:     */   }
/*  966:     */   
/*  967:     */   public MobileMbo getMobileMbo(int index)
/*  968:     */     throws MobileApplicationException
/*  969:     */   {
/*  970:1645 */     MobileMbo mbo = (MobileMbo)getDataObject(index);
/*  971:     */     
/*  972:1647 */     return mbo;
/*  973:     */   }
/*  974:     */   
/*  975:     */   public MobileMboInfo getMobileMboInfo()
/*  976:     */   {
/*  977:1657 */     return MobileMboUtil.getMobileMboInfo(this.app.getAppName(), getName());
/*  978:     */   }
/*  979:     */   
/*  980:     */   public void reset()
/*  981:     */     throws MobileApplicationException
/*  982:     */   {
/*  983:1672 */     Enumeration mboEnum = getDataEnumeration();
/*  984:1674 */     if ((mboEnum != null) && ((mboEnum instanceof RDOEnumeration))) {
/*  985:1676 */       ((RDOEnumeration)mboEnum).release();
/*  986:     */     }
/*  987:1679 */     this.data = new Vector();
/*  988:1680 */     this.currentPosition = -1;
/*  989:1681 */     this.closed = false;
/*  990:1682 */     this.dataEnumeration = null;
/*  991:1683 */     this.count = -1;
/*  992:     */     
/*  993:1685 */     this.dependents = new Vector();
/*  994:1687 */     if (this.owner != null) {
/*  995:1689 */       this.owner.resetDependent(getName());
/*  996:     */     }
/*  997:1693 */     setDefaultWorkSetFilter();
/*  998:     */     
/*  999:     */ 
/* 1000:1696 */     Enumeration internalQBEAttrEnum = this.internalQBE.getQBEAttributes();
/* 1001:1697 */     while (internalQBEAttrEnum.hasMoreElements())
/* 1002:     */     {
/* 1003:1699 */       String internalQBEAttr = (String)internalQBEAttrEnum.nextElement();
/* 1004:1700 */       getQBE().setQBE(internalQBEAttr, this.internalQBE.getQBE(internalQBEAttr));
/* 1005:     */     }
/* 1006:1703 */     this.originalMobileMbos = new Hashtable();
/* 1007:1704 */     this.indexers = new Hashtable();
/* 1008:     */   }
/* 1009:     */   
/* 1010:     */   public void resetWithoutSite()
/* 1011:     */     throws MobileApplicationException
/* 1012:     */   {
/* 1013:1711 */     reset();
/* 1014:     */     
/* 1015:1713 */     getQBE().setQBE("SITEID", "");
/* 1016:     */   }
/* 1017:     */   
/* 1018:     */   public MobileMboDataBeanManager getDataBeanManager()
/* 1019:     */   {
/* 1020:1723 */     return this.dataBeanManager;
/* 1021:     */   }
/* 1022:     */   
/* 1023:     */   void setDataBeanManager(MobileMboDataBeanManager dataBeanManager)
/* 1024:     */   {
/* 1025:1733 */     this.dataBeanManager = dataBeanManager;
/* 1026:     */   }
/* 1027:     */   
/* 1028:     */   private Object getDataObject(int index)
/* 1029:     */     throws MobileApplicationException
/* 1030:     */   {
/* 1031:1746 */     fetchData(index);
/* 1032:1749 */     if ((index >= 0) && (index < this.data.size()))
/* 1033:     */     {
/* 1034:1751 */       Object obj = this.data.elementAt(index);
/* 1035:     */       
/* 1036:1753 */       return obj;
/* 1037:     */     }
/* 1038:1755 */     return null;
/* 1039:     */   }
/* 1040:     */   
/* 1041:     */   public boolean isOptionAuthorized(String optionName)
/* 1042:     */     throws MobileApplicationException
/* 1043:     */   {
/* 1044:1772 */     return isOptionAuthorized(getCurrentPosition(), optionName);
/* 1045:     */   }
/* 1046:     */   
/* 1047:     */   public boolean isOptionAuthorized(int index, String optionName)
/* 1048:     */     throws MobileApplicationException
/* 1049:     */   {
/* 1050:1786 */     if (getMobileMbo(index) == null) {
/* 1051:1788 */       return this.app.isOptionAuthorized(optionName);
/* 1052:     */     }
/* 1053:1793 */     boolean isAuth = false;
/* 1054:1794 */     MobileMboInfo info = getMobileMboInfo();
/* 1055:1795 */     optionName = optionName.toUpperCase();
/* 1056:1798 */     if (info.isSiteLevel())
/* 1057:     */     {
/* 1058:1800 */       String siteAttribute = info.getSiteAttribute();
/* 1059:1801 */       if (siteAttribute != null)
/* 1060:     */       {
/* 1061:1803 */         String siteId = getMobileMbo(index).getValue(siteAttribute);
/* 1062:1804 */         isAuth = this.app.isOptionAuthorizedAtSite(optionName, siteId);
/* 1063:1805 */         if (isAuth) {
/* 1064:1807 */           return true;
/* 1065:     */         }
/* 1066:     */       }
/* 1067:     */     }
/* 1068:1813 */     if (info.isOrgLevel())
/* 1069:     */     {
/* 1070:1815 */       String orgLevel = info.getOrgAttribute();
/* 1071:1816 */       if (orgLevel != null)
/* 1072:     */       {
/* 1073:1818 */         String orgId = getMobileMbo(index).getValue(orgLevel);
/* 1074:1819 */         isAuth = this.app.isOptionAuthorizedAtOrg(optionName, orgId);
/* 1075:1820 */         if (isAuth) {
/* 1076:1822 */           return true;
/* 1077:     */         }
/* 1078:     */       }
/* 1079:     */     }
/* 1080:1828 */     return this.app.isOptionAuthorized(optionName);
/* 1081:     */   }
/* 1082:     */   
/* 1083:     */   public void doneAll()
/* 1084:     */     throws MobileApplicationException
/* 1085:     */   {
/* 1086:1837 */     MobileDeviceAppSession deviceAppSession = MobileDeviceAppSession.getSession();
/* 1087:     */     
/* 1088:     */ 
/* 1089:1840 */     Object doneAllInitiator = deviceAppSession.getAttribute("_DONEALL");
/* 1090:1842 */     if (doneAllInitiator != null) {
/* 1091:1844 */       deviceAppSession.setAttribute("_DONEALL", this);
/* 1092:     */     }
/* 1093:1847 */     RDORuntime rdoRuntime = this.app.getRDORuntime();
/* 1094:     */     
/* 1095:     */ 
/* 1096:1850 */     RDOTransactionManager txnManager = rdoRuntime.getRDOTransactionManager();
/* 1097:     */     
/* 1098:     */ 
/* 1099:     */ 
/* 1100:     */ 
/* 1101:     */ 
/* 1102:     */ 
/* 1103:1857 */     getOrder().reset();
/* 1104:1858 */     getOrder().setOrder("_ID", false);
/* 1105:     */     
/* 1106:     */ 
/* 1107:1861 */     boolean activeTimerError = false;
/* 1108:     */     try
/* 1109:     */     {
/* 1110:1864 */       if (doneAllInitiator == this)
/* 1111:     */       {
/* 1112:1866 */         this.app.setBatchAsyncMode(true);
/* 1113:1867 */         txnManager.begin();
/* 1114:     */       }
/* 1115:1871 */       deviceAppSession.setAttribute("_DONTSHOWDEPSCREEN", "1");
/* 1116:     */       
/* 1117:     */ 
/* 1118:1874 */       getQBE().reset();
/* 1119:1875 */       getQBE().setQBE("_MODIFIED", "1");
/* 1120:1876 */       getQBE().setQBE("_DONE", "0");
/* 1121:1877 */       getQBE().setQbeExactMatch(true);
/* 1122:1878 */       reset();
/* 1123:     */       
/* 1124:1880 */       int currentCount = count();
/* 1125:1881 */       for (int i = 0; i < currentCount; i++)
/* 1126:     */       {
/* 1127:1884 */         if ((getName().equals("WORKORDER")) || (getName().equals("TICKET"))) {
/* 1128:1886 */           if (hasTimerRunning(i))
/* 1129:     */           {
/* 1130:1888 */             activeTimerError = true;
/* 1131:1889 */             throw new MobileApplicationException("activetimerexist");
/* 1132:     */           }
/* 1133:     */         }
/* 1134:1892 */         doneWithoutReset(i);
/* 1135:     */       }
/* 1136:1895 */       getQBE().reset();
/* 1137:1896 */       reset();
/* 1138:1898 */       if (doneAllInitiator == this) {
/* 1139:1900 */         txnManager.commit();
/* 1140:     */       }
/* 1141:1904 */       deviceAppSession.setAttribute("_DONTSHOWDEPSCREEN", "0");
/* 1142:     */       
/* 1143:1906 */       reset();
/* 1144:1932 */       if (doneAllInitiator == this) {
/* 1145:1934 */         this.app.setBatchAsyncMode(false);
/* 1146:     */       }
/* 1147:     */     }
/* 1148:     */     catch (Throwable ex)
/* 1149:     */     {
/* 1150:1910 */       MobileLoggerFactory.getDefaultLogger().warn("Error encountered marking all records as DONE", ex);
/* 1151:     */       try
/* 1152:     */       {
/* 1153:1914 */         txnManager.rollback();
/* 1154:     */       }
/* 1155:     */       catch (Exception ex1) {}
/* 1156:1917 */       if (doneAllInitiator == this) {
/* 1157:1919 */         deviceAppSession.removeAttribute("_DONEALL");
/* 1158:     */       }
/* 1159:1923 */       if (activeTimerError) {
/* 1160:1925 */         throw new MobileApplicationException("activetimerexist");
/* 1161:     */       }
/* 1162:1928 */       throw new MobileApplicationException("savefailed");
/* 1163:     */     }
/* 1164:     */     finally
/* 1165:     */     {
/* 1166:1932 */       if (doneAllInitiator == this) {
/* 1167:1934 */         this.app.setBatchAsyncMode(false);
/* 1168:     */       }
/* 1169:     */     }
/* 1170:1938 */     if (doneAllInitiator == this)
/* 1171:     */     {
/* 1172:     */       try
/* 1173:     */       {
/* 1174:1942 */         MobileSafeRemoteInvoker invoker = new MobileSafeRemoteInvoker()
/* 1175:     */         {
/* 1176:     */           public void remoteCall()
/* 1177:     */             throws MobileApplicationException
/* 1178:     */           {
/* 1179:1944 */             MobileMboDataBean.this.app.sendQueuedMessages();
/* 1180:1945 */             setResult(new Object());
/* 1181:     */           }
/* 1182:1947 */         };
/* 1183:1948 */         invoker.execute();
/* 1184:1949 */         if ((!invoker.isCompleted()) || (invoker.isFailed())) {
/* 1185:1950 */           throw new MobileApplicationException("commfailure");
/* 1186:     */         }
/* 1187:     */       }
/* 1188:     */       catch (Throwable ex) {}
/* 1189:1958 */       deviceAppSession.removeAttribute("_DONEALL");
/* 1190:     */     }
/* 1191:     */   }
/* 1192:     */   
/* 1193:     */   public void done()
/* 1194:     */     throws MobileApplicationException
/* 1195:     */   {
/* 1196:1967 */     if (getCurrentPosition() == -1) {
/* 1197:1970 */       setCurrentPosition(0);
/* 1198:     */     }
/* 1199:1976 */     if (this.app.getAppName().equalsIgnoreCase("MOBILEWO")) {
/* 1200:1979 */       if ((getName().equals("WORKORDER")) || (getName().equals("TICKET"))) {
/* 1201:1981 */         if (hasTimerRunning(getCurrentPosition())) {
/* 1202:1983 */           throw new MobileApplicationException("activetimerexist");
/* 1203:     */         }
/* 1204:     */       }
/* 1205:     */     }
/* 1206:1988 */     done(getCurrentPosition());
/* 1207:     */   }
/* 1208:     */   
/* 1209:     */   private boolean hasTimerRunning(int position)
/* 1210:     */     throws MobileApplicationException
/* 1211:     */   {
/* 1212:1996 */     if (position == -1) {
/* 1213:1998 */       position = 0;
/* 1214:     */     }
/* 1215:2001 */     String name = "WOLABTRANS";
/* 1216:2002 */     if (getName().equals("TICKET")) {
/* 1217:2004 */       name = "TKLABTRANS";
/* 1218:     */     }
/* 1219:2007 */     MobileMboDataBean labTransBean = getDataBean(position, name);
/* 1220:2008 */     if (labTransBean != null)
/* 1221:     */     {
/* 1222:2010 */       String activeTimerValue = getActiveTimerDefaultValue();
/* 1223:2011 */       MobileMbo labTransMbo = labTransBean.getMobileMbo(0);
/* 1224:2012 */       int i = 0;
/* 1225:2013 */       while (labTransMbo != null)
/* 1226:     */       {
/* 1227:2015 */         if (labTransMbo.getValue("TIMERSTATUS").equals(activeTimerValue)) {
/* 1228:2017 */           return true;
/* 1229:     */         }
/* 1230:2019 */         labTransMbo = labTransBean.getMobileMbo(++i);
/* 1231:     */       }
/* 1232:     */     }
/* 1233:2023 */     return false;
/* 1234:     */   }
/* 1235:     */   
/* 1236:     */   private String getActiveTimerDefaultValue()
/* 1237:     */     throws MobileApplicationException
/* 1238:     */   {
/* 1239:2028 */     MobileMbo listMbo = null;
/* 1240:     */     
/* 1241:2030 */     MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager("TIMERSTATUS");
/* 1242:2031 */     MobileMboDataBean listBean = mgrDBMgr.getDataBean();
/* 1243:     */     
/* 1244:2033 */     listBean.getQBE().reset();
/* 1245:2034 */     listBean.getQBE().setQbeExactMatch(true);
/* 1246:2035 */     listBean.getQBE().setQBE("SITEID", getValue("SITEID"));
/* 1247:2036 */     listBean.getQBE().setQBE("MAXVALUE", "ACTIVE");
/* 1248:2037 */     listBean.getQBE().setQBE("DEFAULTS", "1");
/* 1249:2038 */     listBean.reset();
/* 1250:2039 */     listMbo = listBean.getMobileMbo(0);
/* 1251:2040 */     if (listMbo != null) {
/* 1252:2042 */       return listMbo.getValue("VALUE");
/* 1253:     */     }
/* 1254:2045 */     listBean.getQBE().reset();
/* 1255:2046 */     listBean.getQBE().setQbeExactMatch(true);
/* 1256:2047 */     listBean.getQBE().setQBE("ORGID", getValue("ORGID"));
/* 1257:2048 */     listBean.getQBE().setQBE("SITEID", "~NULL~");
/* 1258:2049 */     listBean.getQBE().setQBE("MAXVALUE", "ACTIVE");
/* 1259:2050 */     listBean.reset();
/* 1260:2051 */     listMbo = listBean.getMobileMbo(0);
/* 1261:2052 */     if (listMbo != null) {
/* 1262:2054 */       return listMbo.getValue("VALUE");
/* 1263:     */     }
/* 1264:2057 */     listBean.getQBE().reset();
/* 1265:2058 */     listBean.getQBE().setQbeExactMatch(true);
/* 1266:2059 */     listBean.getQBE().setQBE("SITEID", "~NULL~");
/* 1267:2060 */     listBean.getQBE().setQBE("ORGID", "~NULL~");
/* 1268:2061 */     listBean.getQBE().setQBE("MAXVALUE", "ACTIVE");
/* 1269:2062 */     listBean.reset();
/* 1270:2063 */     listMbo = listBean.getMobileMbo(0);
/* 1271:2064 */     if (listMbo != null) {
/* 1272:2066 */       return listMbo.getValue("VALUE");
/* 1273:     */     }
/* 1274:2069 */     return "";
/* 1275:     */   }
/* 1276:     */   
/* 1277:     */   public void done(int index)
/* 1278:     */     throws MobileApplicationException
/* 1279:     */   {
/* 1280:2079 */     boolean shouldContinue = doneWithoutReset(index);
/* 1281:2080 */     if (shouldContinue) {
/* 1282:2081 */       reset();
/* 1283:     */     }
/* 1284:     */   }
/* 1285:     */   
/* 1286:     */   private boolean doneWithoutReset(int index)
/* 1287:     */     throws MobileApplicationException
/* 1288:     */   {
/* 1289:2091 */     if ((!getMobileMboInfo().isWorkset()) && (!getMobileMboInfo().isLocalWorksetUpload())) {
/* 1290:2093 */       return true;
/* 1291:     */     }
/* 1292:2097 */     if (getDataBeanManager().getDataBean() != this) {
/* 1293:2099 */       return true;
/* 1294:     */     }
/* 1295:2102 */     MobileMbo mobileMbo = getMobileMbo(index);
/* 1296:2103 */     if (mobileMbo == null) {
/* 1297:2105 */       return true;
/* 1298:     */     }
/* 1299:2109 */     if (mobileMbo.getOwner() != null) {
/* 1300:2111 */       return true;
/* 1301:     */     }
/* 1302:2114 */     if (!mobileMbo.isModified()) {
/* 1303:2117 */       return true;
/* 1304:     */     }
/* 1305:2121 */     OperationContainer oc = this.app.getOperationContainer(getName(), "done");
/* 1306:2122 */     OperationHandler operHandler = null;
/* 1307:2123 */     if (oc != null) {
/* 1308:2125 */       operHandler = oc.getHandler();
/* 1309:     */     } else {
/* 1310:2129 */       operHandler = this.app.getOperationHandler("done");
/* 1311:     */     }
/* 1312:2133 */     boolean shouldContinue = true;
/* 1313:2134 */     if (operHandler != null) {
/* 1314:2136 */       shouldContinue = operHandler.beforeOperation("done", this, index);
/* 1315:     */     }
/* 1316:2139 */     if (shouldContinue)
/* 1317:     */     {
/* 1318:2141 */       mobileMbo.setBooleanValue("_DONE", true);
/* 1319:2142 */       getDataBeanManager().save();
/* 1320:2143 */       this.app.performDataTransaction(mobileMbo);
/* 1321:2145 */       if (operHandler != null) {
/* 1322:2147 */         operHandler.handleOperation("done", this, index);
/* 1323:     */       }
/* 1324:     */     }
/* 1325:2150 */     return shouldContinue;
/* 1326:     */   }
/* 1327:     */   
/* 1328:     */   public void giveup()
/* 1329:     */     throws MobileApplicationException
/* 1330:     */   {
/* 1331:2160 */     if (getCurrentPosition() == -1) {
/* 1332:2163 */       setCurrentPosition(0);
/* 1333:     */     }
/* 1334:2166 */     giveup(getCurrentPosition());
/* 1335:     */   }
/* 1336:     */   
/* 1337:     */   public void giveup(int index)
/* 1338:     */     throws MobileApplicationException
/* 1339:     */   {
/* 1340:2176 */     if ((!getMobileMboInfo().isWorkset()) && (!getMobileMboInfo().isLocalWorksetUpload())) {
/* 1341:2178 */       return;
/* 1342:     */     }
/* 1343:2182 */     if (getDataBeanManager().getDataBean() != this) {
/* 1344:2184 */       return;
/* 1345:     */     }
/* 1346:2187 */     MobileMbo mobileMbo = getMobileMbo(index);
/* 1347:2188 */     if (mobileMbo == null) {
/* 1348:2190 */       return;
/* 1349:     */     }
/* 1350:2194 */     if (mobileMbo.getOwner() != null) {
/* 1351:2196 */       return;
/* 1352:     */     }
/* 1353:2199 */     if (!mobileMbo.isModified()) {
/* 1354:2202 */       return;
/* 1355:     */     }
/* 1356:2205 */     mobileMbo.setBooleanValue("_DONE", true);
/* 1357:2206 */     getDataBeanManager().save();
/* 1358:2207 */     this.app.performDataTransactionGivenUpOnError(mobileMbo);
/* 1359:2208 */     reset();
/* 1360:     */   }
/* 1361:     */   
/* 1362:     */   public boolean isComplete()
/* 1363:     */     throws MobileApplicationException
/* 1364:     */   {
/* 1365:2217 */     if (getCurrentPosition() == -1) {
/* 1366:2220 */       setCurrentPosition(0);
/* 1367:     */     }
/* 1368:2223 */     return isComplete(getCurrentPosition());
/* 1369:     */   }
/* 1370:     */   
/* 1371:     */   public boolean isComplete(int index)
/* 1372:     */     throws MobileApplicationException
/* 1373:     */   {
/* 1374:2232 */     if ((!getMobileMboInfo().isWorkset()) && (!getMobileMboInfo().isLocalWorksetUpload())) {
/* 1375:2234 */       return true;
/* 1376:     */     }
/* 1377:2237 */     MobileMbo mobileMbo = getMobileMbo(index);
/* 1378:2238 */     if (mobileMbo == null) {
/* 1379:2240 */       return true;
/* 1380:     */     }
/* 1381:2243 */     boolean isComplete = mobileMbo.getBooleanValue("_INCOMPLETE");
/* 1382:     */     
/* 1383:2245 */     return !isComplete;
/* 1384:     */   }
/* 1385:     */   
/* 1386:     */   public void markComplete()
/* 1387:     */     throws MobileApplicationException
/* 1388:     */   {
/* 1389:2255 */     if (getCurrentPosition() == -1) {
/* 1390:2258 */       setCurrentPosition(0);
/* 1391:     */     }
/* 1392:2261 */     markComplete(getCurrentPosition());
/* 1393:     */   }
/* 1394:     */   
/* 1395:     */   public void markComplete(int index)
/* 1396:     */     throws MobileApplicationException
/* 1397:     */   {
/* 1398:2271 */     if ((!getMobileMboInfo().isWorkset()) && (!getMobileMboInfo().isLocalWorksetUpload())) {
/* 1399:2273 */       return;
/* 1400:     */     }
/* 1401:2276 */     MobileMbo mobileMbo = getMobileMbo(index);
/* 1402:2277 */     if (mobileMbo == null) {
/* 1403:2279 */       return;
/* 1404:     */     }
/* 1405:2282 */     mobileMbo.setBooleanValue("_INCOMPLETE", false);
/* 1406:     */   }
/* 1407:     */   
/* 1408:     */   public void markIncomplete()
/* 1409:     */     throws MobileApplicationException
/* 1410:     */   {
/* 1411:2292 */     if (getCurrentPosition() == -1) {
/* 1412:2295 */       setCurrentPosition(0);
/* 1413:     */     }
/* 1414:2298 */     markIncomplete(getCurrentPosition());
/* 1415:     */   }
/* 1416:     */   
/* 1417:     */   public void markIncomplete(int index)
/* 1418:     */     throws MobileApplicationException
/* 1419:     */   {
/* 1420:2308 */     if ((!getMobileMboInfo().isWorkset()) && (!getMobileMboInfo().isLocalWorksetUpload())) {
/* 1421:2310 */       return;
/* 1422:     */     }
/* 1423:2313 */     MobileMbo mobileMbo = getMobileMbo(index);
/* 1424:2314 */     if (mobileMbo == null) {
/* 1425:2316 */       return;
/* 1426:     */     }
/* 1427:2319 */     mobileMbo.setBooleanValue("_INCOMPLETE", true);
/* 1428:     */   }
/* 1429:     */   
/* 1430:     */   public boolean hasError()
/* 1431:     */     throws MobileApplicationException
/* 1432:     */   {
/* 1433:2328 */     if (getCurrentPosition() == -1) {
/* 1434:2331 */       setCurrentPosition(0);
/* 1435:     */     }
/* 1436:2334 */     return hasError(getCurrentPosition());
/* 1437:     */   }
/* 1438:     */   
/* 1439:     */   public boolean hasError(int index)
/* 1440:     */     throws MobileApplicationException
/* 1441:     */   {
/* 1442:2343 */     if ((!getMobileMboInfo().isWorkset()) && (!getMobileMboInfo().isLocalWorksetUpload())) {
/* 1443:2345 */       return false;
/* 1444:     */     }
/* 1445:2348 */     MobileMbo mobileMbo = getMobileMbo(index);
/* 1446:2349 */     if (mobileMbo == null) {
/* 1447:2351 */       return false;
/* 1448:     */     }
/* 1449:2354 */     boolean hasError = mobileMbo.getBooleanValue("_ERR");
/* 1450:     */     
/* 1451:2356 */     return hasError;
/* 1452:     */   }
/* 1453:     */   
/* 1454:     */   public String getErrorMessage()
/* 1455:     */     throws MobileApplicationException
/* 1456:     */   {
/* 1457:2365 */     if (getCurrentPosition() == -1) {
/* 1458:2368 */       setCurrentPosition(0);
/* 1459:     */     }
/* 1460:2371 */     return getErrorMessage(getCurrentPosition());
/* 1461:     */   }
/* 1462:     */   
/* 1463:     */   public String getErrorMessage(int index)
/* 1464:     */     throws MobileApplicationException
/* 1465:     */   {
/* 1466:2380 */     if ((!getMobileMboInfo().isWorkset()) && (!getMobileMboInfo().isLocalWorksetUpload())) {
/* 1467:2382 */       return "";
/* 1468:     */     }
/* 1469:2385 */     MobileMbo mobileMbo = getMobileMbo(index);
/* 1470:2386 */     if (mobileMbo == null) {
/* 1471:2388 */       return "";
/* 1472:     */     }
/* 1473:2391 */     String errorMessage = mobileMbo.getValue("_ERRMSG");
/* 1474:     */     
/* 1475:2393 */     return errorMessage;
/* 1476:     */   }
/* 1477:     */   
/* 1478:     */   public boolean isESigNeeded(String optionName)
/* 1479:     */     throws MobileApplicationException
/* 1480:     */   {
/* 1481:2405 */     if (getCurrentPosition() == -1) {
/* 1482:2408 */       setCurrentPosition(0);
/* 1483:     */     }
/* 1484:2411 */     return isESigNeeded(getCurrentPosition(), optionName);
/* 1485:     */   }
/* 1486:     */   
/* 1487:     */   public boolean isESigNeeded(int index, String optionName)
/* 1488:     */     throws MobileApplicationException
/* 1489:     */   {
/* 1490:2424 */     MobileMbo mobileMbo = getMobileMbo(index);
/* 1491:2427 */     if ((mobileMbo == null) && ("SAVE".equals(optionName))) {
/* 1492:2429 */       return false;
/* 1493:     */     }
/* 1494:2432 */     return this.app.isESigNeeded(optionName, mobileMbo);
/* 1495:     */   }
/* 1496:     */   
/* 1497:     */   public boolean verifyESig(String loginid, String password, String reason)
/* 1498:     */     throws MobileApplicationException
/* 1499:     */   {
/* 1500:2447 */     if (getCurrentPosition() == -1) {
/* 1501:2450 */       setCurrentPosition(0);
/* 1502:     */     }
/* 1503:2453 */     return verifyESig(getCurrentPosition(), loginid, password, reason);
/* 1504:     */   }
/* 1505:     */   
/* 1506:     */   public boolean verifyESig(int index, String loginid, String password, String reason)
/* 1507:     */     throws MobileApplicationException
/* 1508:     */   {
/* 1509:2469 */     boolean authenticatedSuccessfully = false;
/* 1510:2470 */     authenticatedSuccessfully = this.app.verifyUserForESig(loginid, password);
/* 1511:2471 */     if (!authenticatedSuccessfully) {
/* 1512:2472 */       throw new MobileApplicationException("invaliduser");
/* 1513:     */     }
/* 1514:2475 */     MobileMbo mobileMbo = getMobileMbo(index);
/* 1515:2476 */     String recordId = null;
/* 1516:2479 */     if (mobileMbo != null) {
/* 1517:2481 */       recordId = mobileMbo.getValue("_ID");
/* 1518:     */     }
/* 1519:2483 */     this.app.logESigVerification(getName(), recordId, reason, authenticatedSuccessfully);
/* 1520:     */     
/* 1521:     */ 
/* 1522:2486 */     return authenticatedSuccessfully;
/* 1523:     */   }
/* 1524:     */   
/* 1525:     */   public void select()
/* 1526:     */     throws MobileApplicationException
/* 1527:     */   {
/* 1528:2496 */     if (getCurrentPosition() == -1) {
/* 1529:2499 */       setCurrentPosition(0);
/* 1530:     */     }
/* 1531:2502 */     select(getCurrentPosition());
/* 1532:     */   }
/* 1533:     */   
/* 1534:     */   public void select(int index)
/* 1535:     */     throws MobileApplicationException
/* 1536:     */   {
/* 1537:2513 */     MobileMbo mobileMbo = getMobileMbo(index);
/* 1538:2514 */     if (mobileMbo == null) {
/* 1539:2516 */       return;
/* 1540:     */     }
/* 1541:2519 */     mobileMbo.select();
/* 1542:     */   }
/* 1543:     */   
/* 1544:     */   public void unselect()
/* 1545:     */     throws MobileApplicationException
/* 1546:     */   {
/* 1547:2529 */     if (getCurrentPosition() == -1) {
/* 1548:2532 */       setCurrentPosition(0);
/* 1549:     */     }
/* 1550:2535 */     unselect(getCurrentPosition());
/* 1551:     */   }
/* 1552:     */   
/* 1553:     */   public void unselect(int index)
/* 1554:     */     throws MobileApplicationException
/* 1555:     */   {
/* 1556:2546 */     MobileMbo mobileMbo = getMobileMbo(index);
/* 1557:2547 */     if (mobileMbo == null) {
/* 1558:2549 */       return;
/* 1559:     */     }
/* 1560:2552 */     mobileMbo.unselect();
/* 1561:     */   }
/* 1562:     */   
/* 1563:     */   public Vector getSelection()
/* 1564:     */     throws MobileApplicationException
/* 1565:     */   {
/* 1566:2563 */     Vector selectedMbos = new Vector();
/* 1567:     */     
/* 1568:2565 */     int currentSize = getCurrentSize();
/* 1569:2566 */     for (int i = 0; i < currentSize; i++)
/* 1570:     */     {
/* 1571:2568 */       MobileMbo mobileMbo = getMobileMbo(i);
/* 1572:2569 */       if ((mobileMbo != null) && (mobileMbo.isSelected())) {
/* 1573:2571 */         selectedMbos.addElement(mobileMbo);
/* 1574:     */       }
/* 1575:     */     }
/* 1576:2575 */     return selectedMbos;
/* 1577:     */   }
/* 1578:     */   
/* 1579:     */   public MobileMboDataBean getParentBean()
/* 1580:     */   {
/* 1581:2583 */     return this.parentBean;
/* 1582:     */   }
/* 1583:     */   
/* 1584:     */   public void setParentBean(MobileMboDataBean parentBean)
/* 1585:     */   {
/* 1586:2590 */     this.parentBean = parentBean;
/* 1587:     */   }
/* 1588:     */   
/* 1589:     */   void saveCompleted()
/* 1590:     */   {
/* 1591:2596 */     this.originalMobileMbos = new Hashtable();
/* 1592:     */   }
/* 1593:     */   
/* 1594:     */   void cancel()
/* 1595:     */     throws MobileApplicationException
/* 1596:     */   {
/* 1597:2607 */     int cPos = getCurrentPosition();
/* 1598:     */     
/* 1599:2609 */     Enumeration indexEnum = this.originalMobileMbos.keys();
/* 1600:2610 */     while (indexEnum.hasMoreElements())
/* 1601:     */     {
/* 1602:2612 */       Integer index = (Integer)indexEnum.nextElement();
/* 1603:2613 */       MobileMbo originalMobileMbo = (MobileMbo)this.originalMobileMbos.get(index);
/* 1604:2614 */       MobileMbo modifiedMobileMbo = getMobileMbo(index.intValue());
/* 1605:2616 */       if (originalMobileMbo.getOwner() != null)
/* 1606:     */       {
/* 1607:2618 */         MobileMbo owner = originalMobileMbo.getOwner();
/* 1608:2619 */         owner.replaceDependent(getName(), modifiedMobileMbo, originalMobileMbo);
/* 1609:     */       }
/* 1610:2622 */       this.data.setElementAt(originalMobileMbo, index.intValue());
/* 1611:     */     }
/* 1612:2628 */     int cSize = getCurrentSize();
/* 1613:2629 */     int index = 0;
/* 1614:2632 */     while (index < cSize)
/* 1615:     */     {
/* 1616:2637 */       MobileMbo mbo = getMobileMbo(index);
/* 1617:2638 */       if (mbo == null) {
/* 1618:     */         break;
/* 1619:     */       }
/* 1620:2643 */       if (mbo.isToBeInserted()) {
/* 1621:2645 */         remove(index);
/* 1622:     */       } else {
/* 1623:2648 */         index++;
/* 1624:     */       }
/* 1625:     */     }
/* 1626:2653 */     this.originalMobileMbos = new Hashtable();
/* 1627:     */     
/* 1628:     */ 
/* 1629:2656 */     cSize = getCurrentSize();
/* 1630:2657 */     if (cSize == 0) {
/* 1631:2659 */       this.currentPosition = -1;
/* 1632:2661 */     } else if (cPos < cSize) {
/* 1633:2663 */       setCurrentPosition(cPos);
/* 1634:     */     } else {
/* 1635:2667 */       setCurrentPosition(cSize - 1);
/* 1636:     */     }
/* 1637:2670 */     this.count = -1;
/* 1638:     */   }
/* 1639:     */   
/* 1640:     */   public void copy()
/* 1641:     */     throws MobileApplicationException
/* 1642:     */   {
/* 1643:2682 */     if (getCurrentPosition() == -1) {
/* 1644:2685 */       setCurrentPosition(0);
/* 1645:     */     }
/* 1646:2688 */     copy(getCurrentPosition());
/* 1647:     */   }
/* 1648:     */   
/* 1649:     */   public void copy(CopyHandler copyHandler)
/* 1650:     */     throws MobileApplicationException
/* 1651:     */   {
/* 1652:2702 */     if (getCurrentPosition() == -1) {
/* 1653:2705 */       setCurrentPosition(0);
/* 1654:     */     }
/* 1655:2708 */     copy(getCurrentPosition(), copyHandler);
/* 1656:     */   }
/* 1657:     */   
/* 1658:     */   public void copy(int index)
/* 1659:     */     throws MobileApplicationException
/* 1660:     */   {
/* 1661:2721 */     copy(index, null);
/* 1662:     */   }
/* 1663:     */   
/* 1664:     */   public void copy(int index, CopyHandler copyHandler)
/* 1665:     */     throws MobileApplicationException
/* 1666:     */   {
/* 1667:2736 */     if (isReadOnly()) {
/* 1668:2738 */       throw new MobileApplicationException("readonly", new Object[] { getMobileMboInfo().getDescription() });
/* 1669:     */     }
/* 1670:2741 */     MobileMbo mbo = getMobileMbo(index);
/* 1671:2742 */     if (mbo == null) {
/* 1672:2744 */       return;
/* 1673:     */     }
/* 1674:2747 */     insert();
/* 1675:     */     
/* 1676:2749 */     int copyPosition = getCurrentPosition();
/* 1677:     */     
/* 1678:     */ 
/* 1679:2752 */     index += 1;
/* 1680:     */     
/* 1681:2754 */     MobileMbo copyMbo = getMobileMbo();
/* 1682:     */     
/* 1683:2756 */     MobileMboInfo info = getMobileMboInfo();
/* 1684:     */     
/* 1685:     */ 
/* 1686:2759 */     copyAttributeValues(info, mbo, copyMbo, copyHandler);
/* 1687:     */     
/* 1688:2761 */     String[] depNames = info.getDependentNames();
/* 1689:2762 */     for (int j = 0; j < depNames.length; j++)
/* 1690:     */     {
/* 1691:2764 */       String depName = depNames[j];
/* 1692:2766 */       if (copyHandler != null) {
/* 1693:2768 */         if (!copyHandler.skipCopyDependent(depName)) {
/* 1694:2770 */           copyDependentMbos(index, depName, copyPosition, this, copyMbo, copyHandler);
/* 1695:     */         }
/* 1696:     */       }
/* 1697:     */     }
/* 1698:     */   }
/* 1699:     */   
/* 1700:     */   void copyDependentMbos(int index, String dependentName, int copyIndex, MobileMboDataBean parentDataBean, MobileMbo ownerMbo, CopyHandler copyHandler)
/* 1701:     */     throws MobileApplicationException
/* 1702:     */   {
/* 1703:2784 */     MobileMboDataBean depDataBean = getDataBean(index, dependentName);
/* 1704:     */     
/* 1705:2786 */     String refMobileMboName = depDataBean.getMobileMboInfo().getMobileMboName();
/* 1706:2787 */     if ((refMobileMboName != null) && (refMobileMboName.length() > 0)) {
/* 1707:2790 */       return;
/* 1708:     */     }
/* 1709:2793 */     MobileMboDataBean copyDepDataBean = parentDataBean.getDataBean(copyIndex, dependentName);
/* 1710:     */     
/* 1711:2795 */     int i = 0;
/* 1712:     */     for (;;)
/* 1713:     */     {
/* 1714:2799 */       MobileMbo depMobileMbo = depDataBean.getMobileMbo(i);
/* 1715:2800 */       if (depMobileMbo == null) {
/* 1716:     */         break;
/* 1717:     */       }
/* 1718:2806 */       copyDepDataBean.insert();
/* 1719:2807 */       MobileMbo copyDepMobileMbo = copyDepDataBean.getMobileMbo();
/* 1720:     */       
/* 1721:     */ 
/* 1722:2810 */       copyAttributeValues(depDataBean.getMobileMboInfo(), depMobileMbo, copyDepMobileMbo, copyHandler);
/* 1723:     */       
/* 1724:     */ 
/* 1725:     */ 
/* 1726:2814 */       MobileMboInfo depInfo = depDataBean.getMobileMboInfo();
/* 1727:2815 */       String[] depNames = depInfo.getDependentNames();
/* 1728:2816 */       for (int j = 0; j < depNames.length; j++)
/* 1729:     */       {
/* 1730:2818 */         String depName = depNames[j];
/* 1731:2820 */         if (copyHandler != null) {
/* 1732:2822 */           if (!copyHandler.skipCopyDependent(depName)) {
/* 1733:2824 */             depDataBean.copyDependentMbos(i, depName, i, copyDepDataBean, copyDepMobileMbo, copyHandler);
/* 1734:     */           }
/* 1735:     */         }
/* 1736:     */       }
/* 1737:2830 */       i++;
/* 1738:     */     }
/* 1739:     */   }
/* 1740:     */   
/* 1741:     */   void copyAttributeValues(MobileMboInfo info, MobileMbo sourceMobileMbo, MobileMbo destMobileMbo, CopyHandler copyHandler)
/* 1742:     */     throws MobileApplicationException
/* 1743:     */   {
/* 1744:2841 */     String[] attrNames = info.getAttributeNames();
/* 1745:2842 */     for (int i = 0; i < attrNames.length; i++)
/* 1746:     */     {
/* 1747:2844 */       MobileMboAttributeInfo attrInfo = info.getAttributeInfo(attrNames[i]);
/* 1748:2846 */       if ((!attrInfo.isKey()) && (attrInfo.isPersistent())) {
/* 1749:2851 */         if (!attrInfo.getName().startsWith("_")) {
/* 1750:2856 */           if (copyHandler != null) {
/* 1751:2858 */             if (!copyHandler.skipCopyField(destMobileMbo.getName(), attrInfo.getName())) {
/* 1752:2860 */               sourceMobileMbo.copyAttributeValue(destMobileMbo, attrInfo.getName());
/* 1753:     */             }
/* 1754:     */           }
/* 1755:     */         }
/* 1756:     */       }
/* 1757:     */     }
/* 1758:     */   }
/* 1759:     */   
/* 1760:     */   public void setErrorFilter()
/* 1761:     */     throws MobileApplicationException
/* 1762:     */   {
/* 1763:2874 */     getQBE().reset();
/* 1764:     */     
/* 1765:2876 */     getQBE().setQBE("_ERR", "1");
/* 1766:2877 */     reset();
/* 1767:2878 */     setSecondaryFilter(true);
/* 1768:     */   }
/* 1769:     */   
/* 1770:     */   public void setNoErrorFilter()
/* 1771:     */     throws MobileApplicationException
/* 1772:     */   {
/* 1773:2889 */     getQBE().reset();
/* 1774:     */     
/* 1775:2891 */     getQBE().setQBE("_ERR", "0");
/* 1776:2892 */     reset();
/* 1777:2893 */     setSecondaryFilter(true);
/* 1778:     */   }
/* 1779:     */   
/* 1780:     */   public void clearErrorFilter()
/* 1781:     */     throws MobileApplicationException
/* 1782:     */   {
/* 1783:2904 */     getQBE().reset();
/* 1784:     */     
/* 1785:     */ 
/* 1786:2907 */     setSecondaryFilter(false);
/* 1787:     */   }
/* 1788:     */   
/* 1789:     */   public void setFiltered(boolean filtered)
/* 1790:     */   {
/* 1791:2917 */     MobileMboQBE qbe = getQBE();
/* 1792:2918 */     if ((qbe instanceof MobileMboDataBeanQBE)) {
/* 1793:2920 */       ((MobileMboDataBeanQBE)qbe).setFiltered(filtered);
/* 1794:     */     } else {
/* 1795:2923 */       this.flags.set(4, filtered);
/* 1796:     */     }
/* 1797:     */   }
/* 1798:     */   
/* 1799:     */   public boolean isFiltered()
/* 1800:     */   {
/* 1801:2933 */     MobileMboQBE qbe = getQBE();
/* 1802:2934 */     if ((qbe instanceof MobileMboDataBeanQBE)) {
/* 1803:2936 */       return ((MobileMboDataBeanQBE)qbe).isFiltered();
/* 1804:     */     }
/* 1805:2939 */     return this.flags.isSet(4);
/* 1806:     */   }
/* 1807:     */   
/* 1808:     */   public void setSecondaryFilter(boolean filtered)
/* 1809:     */   {
/* 1810:2949 */     this.flags.set(5, filtered);
/* 1811:     */   }
/* 1812:     */   
/* 1813:     */   public boolean isSecondaryFilterOn()
/* 1814:     */   {
/* 1815:2959 */     return this.flags.isSet(5);
/* 1816:     */   }
/* 1817:     */   
/* 1818:     */   public Date getCurrentTime()
/* 1819:     */   {
/* 1820:2969 */     return CurrentTimeProvider.getInstance().getCurrentTime();
/* 1821:     */   }
/* 1822:     */   
/* 1823:     */   public void undoChanges()
/* 1824:     */     throws MobileApplicationException
/* 1825:     */   {
/* 1826:2978 */     if (getCurrentPosition() == -1) {
/* 1827:2981 */       setCurrentPosition(0);
/* 1828:     */     }
/* 1829:2984 */     undoChanges(getCurrentPosition());
/* 1830:     */   }
/* 1831:     */   
/* 1832:     */   public void undoChanges(int index)
/* 1833:     */     throws MobileApplicationException
/* 1834:     */   {
/* 1835:2996 */     OperationContainer oc = this.app.getOperationContainer(getName(), "undo");
/* 1836:2997 */     OperationHandler operHandler = null;
/* 1837:2998 */     if (oc != null) {
/* 1838:3000 */       operHandler = oc.getHandler();
/* 1839:     */     } else {
/* 1840:3004 */       operHandler = this.app.getOperationHandler("undo");
/* 1841:     */     }
/* 1842:3008 */     boolean shouldContinue = true;
/* 1843:3009 */     if (operHandler != null) {
/* 1844:3011 */       shouldContinue = operHandler.beforeOperation("undo", this, index);
/* 1845:     */     }
/* 1846:3014 */     if (!shouldContinue) {
/* 1847:3016 */       return;
/* 1848:     */     }
/* 1849:3019 */     MobileMbo mobileMbo = getMobileMbo(index);
/* 1850:3021 */     if (mobileMbo == null) {
/* 1851:3023 */       return;
/* 1852:     */     }
/* 1853:3026 */     if (!mobileMbo.isModified()) {
/* 1854:3028 */       return;
/* 1855:     */     }
/* 1856:3031 */     MobileDeviceAppSession deviceAppSession = MobileDeviceAppSession.getSession();
/* 1857:3032 */     AbstractMobileDeviceApplication app = deviceAppSession.getApplication();
/* 1858:     */     
/* 1859:3034 */     RDORuntime rdoRuntime = app.getRDORuntime();
/* 1860:     */     
/* 1861:     */ 
/* 1862:3037 */     RDOTransactionManager txnManager = rdoRuntime.getRDOTransactionManager();
/* 1863:     */     try
/* 1864:     */     {
/* 1865:3041 */       txnManager.begin();
/* 1866:     */       
/* 1867:3043 */       mobileMbo.restoreOriginal();
/* 1868:     */       
/* 1869:3045 */       MobileMboInfo info = getMobileMboInfo();
/* 1870:     */       
/* 1871:3047 */       String[] depNames = info.getDependentNames();
/* 1872:3048 */       for (int j = 0; j < depNames.length; j++)
/* 1873:     */       {
/* 1874:3050 */         String depName = depNames[j];
/* 1875:     */         
/* 1876:3052 */         undoChanges(index, depName, mobileMbo, this);
/* 1877:     */       }
/* 1878:3059 */       if (operHandler != null) {
/* 1879:3061 */         operHandler.handleOperation("undo", this, index);
/* 1880:     */       }
/* 1881:3064 */       getDataBeanManager().save();
/* 1882:3065 */       reset();
/* 1883:     */       
/* 1884:3067 */       txnManager.commit();
/* 1885:     */     }
/* 1886:     */     catch (Exception ex)
/* 1887:     */     {
/* 1888:3071 */       MobileLoggerFactory.getDefaultLogger().warn("Error encountered undoing changes made to record", ex);
/* 1889:     */       try
/* 1890:     */       {
/* 1891:3075 */         txnManager.rollback();
/* 1892:     */       }
/* 1893:     */       catch (Exception ex1) {}
/* 1894:3078 */       throw new MobileApplicationException("savefailed");
/* 1895:     */     }
/* 1896:     */   }
/* 1897:     */   
/* 1898:     */   void undoChanges(int index, String dependentName, MobileMbo ownerMbo, MobileMboDataBean parentDataBean)
/* 1899:     */     throws MobileApplicationException
/* 1900:     */   {
/* 1901:3087 */     OperationHandler operHandler = this.app.getOperationHandler("undo");
/* 1902:3088 */     MobileMboDataBean depDataBean = parentDataBean.getDataBean(index, dependentName);
/* 1903:     */     
/* 1904:3090 */     int i = 0;
/* 1905:     */     for (;;)
/* 1906:     */     {
/* 1907:3093 */       MobileMbo depMobileMbo = depDataBean.getMobileMbo(i);
/* 1908:3094 */       if (depMobileMbo == null) {
/* 1909:     */         break;
/* 1910:     */       }
/* 1911:3100 */       boolean shouldContinue = true;
/* 1912:3101 */       if (operHandler != null) {
/* 1913:3103 */         shouldContinue = operHandler.beforeOperation("undo", depDataBean, i);
/* 1914:     */       }
/* 1915:3106 */       if (!shouldContinue)
/* 1916:     */       {
/* 1917:3108 */         i++;
/* 1918:     */       }
/* 1919:     */       else
/* 1920:     */       {
/* 1921:3112 */         if (depMobileMbo.isNew())
/* 1922:     */         {
/* 1923:3114 */           depMobileMbo.delete();
/* 1924:     */         }
/* 1925:     */         else
/* 1926:     */         {
/* 1927:3121 */           if (depMobileMbo.isModified()) {
/* 1928:3123 */             depDataBean.undoChanges(i);
/* 1929:     */           }
/* 1930:3128 */           depMobileMbo.restoreOriginal();
/* 1931:     */         }
/* 1932:3131 */         i++;
/* 1933:     */       }
/* 1934:     */     }
/* 1935:     */   }
/* 1936:     */   
/* 1937:     */   public void indexMobileMboDataBean(String indexName, String[] attributes, boolean overrides)
/* 1938:     */     throws MobileApplicationException
/* 1939:     */   {
/* 1940:3146 */     if ((this.indexers.contains(indexName)) && (!overrides)) {
/* 1941:3147 */       return;
/* 1942:     */     }
/* 1943:3149 */     this.indexers.put(indexName, new MobileMboDataBeanIndexer(this, attributes, this.closed));
/* 1944:     */   }
/* 1945:     */   
/* 1946:     */   public void indexMobileMboDataBean(String indexName, String[] attributes)
/* 1947:     */     throws MobileApplicationException
/* 1948:     */   {
/* 1949:3160 */     indexMobileMboDataBean(indexName, attributes, true);
/* 1950:     */   }
/* 1951:     */   
/* 1952:     */   public MobileMbo getIndexedMobileMbo(String indexName, String[] values)
/* 1953:     */   {
/* 1954:3170 */     if (!existsIndex(indexName)) {
/* 1955:3171 */       return null;
/* 1956:     */     }
/* 1957:3173 */     MobileMboDataBeanIndexer indexer = (MobileMboDataBeanIndexer)this.indexers.get(indexName);
/* 1958:3174 */     return indexer.getIndexedMobileMbo(values);
/* 1959:     */   }
/* 1960:     */   
/* 1961:     */   public Vector getIndexedMobileMbos(String indexName, String[] values)
/* 1962:     */   {
/* 1963:3185 */     if (!existsIndex(indexName)) {
/* 1964:3186 */       return null;
/* 1965:     */     }
/* 1966:3188 */     MobileMboDataBeanIndexer indexer = (MobileMboDataBeanIndexer)this.indexers.get(indexName);
/* 1967:3189 */     return indexer.getIndexedMobileMbos(values);
/* 1968:     */   }
/* 1969:     */   
/* 1970:     */   public boolean existsIndex(String indexName)
/* 1971:     */   {
/* 1972:3197 */     return this.indexers.containsKey(indexName);
/* 1973:     */   }
/* 1974:     */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.MobileMboDataBean
 * JD-Core Version:    0.7.0.1
 */