/*   1:    */ package com.mro.mobile.ui;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.MobileMessageGenerator;
/*   5:    */ import com.mro.mobile.app.AbstractMobileDeviceApplication;
/*   6:    */ import com.mro.mobile.app.MobileDeviceAppSession;
/*   7:    */ import com.mro.mobile.mbo.MobileMboAttributeInfo;
/*   8:    */ import com.mro.mobile.mbo.MobileMboInfo;
/*   9:    */ import com.mro.mobile.mbo.MobileMboUtil;
/*  10:    */ 
/*  11:    */ public class AutoKeyGenerator
/*  12:    */ {
/*  13:    */   /**
/*  14:    */    * @deprecated
/*  15:    */    */
/*  16:    */   public static String generateKey(String name)
/*  17:    */     throws MobileApplicationException
/*  18:    */   {
/*  19: 32 */     MobileDeviceAppSession deviceAppSession = MobileDeviceAppSession.getSession();
/*  20: 33 */     AbstractMobileDeviceApplication app = deviceAppSession.getApplication();
/*  21:    */     
/*  22: 35 */     String nextAutoNumber = app.getNextAutoNumber(name);
/*  23:    */     
/*  24: 37 */     String key = MobileMessageGenerator.generate("autokeyprefix", new Object[] { nextAutoNumber });
/*  25:    */     
/*  26: 39 */     return key;
/*  27:    */   }
/*  28:    */   
/*  29:    */   public static String generateKey(String name, String targetAttribute)
/*  30:    */     throws MobileApplicationException
/*  31:    */   {
/*  32: 45 */     MobileDeviceAppSession deviceAppSession = MobileDeviceAppSession.getSession();
/*  33: 46 */     AbstractMobileDeviceApplication app = deviceAppSession.getApplication();
/*  34:    */     
/*  35: 48 */     String nextAutoNumber = app.getNextAutoNumber(name);
/*  36:    */     
/*  37: 50 */     String key = MobileMessageGenerator.generate("autokeyprefix", new Object[] { nextAutoNumber });
/*  38:    */     
/*  39: 52 */     MobileMboInfo mboInfo = MobileMboUtil.getMobileMboInfo(app.getAppName(), name);
/*  40: 53 */     MobileMboAttributeInfo attributeInfo = mboInfo.getAttributeInfo(targetAttribute);
/*  41:    */     
/*  42: 55 */     int maxFieldLen = attributeInfo.getLength();
/*  43:    */     
/*  44: 57 */     key = fitKey(maxFieldLen, key, nextAutoNumber);
/*  45:    */     
/*  46: 59 */     return key;
/*  47:    */   }
/*  48:    */   
/*  49:    */   private static String fitKey(int fieldLen, String stringToFit, String numberToPreserve)
/*  50:    */     throws MobileApplicationException
/*  51:    */   {
/*  52: 75 */     int stringLen = stringToFit.length();
/*  53: 76 */     if (stringLen <= fieldLen) {
/*  54: 78 */       return stringToFit;
/*  55:    */     }
/*  56: 80 */     int numPosStart = stringToFit.indexOf(numberToPreserve);
/*  57: 81 */     int numPosEnd = numPosStart + numberToPreserve.length();
/*  58: 82 */     int charsBefore = numPosStart;
/*  59: 83 */     int charsAfter = stringToFit.length() - numPosEnd;
/*  60:    */     
/*  61: 85 */     int maxCharsToReduce = stringToFit.length() - numberToPreserve.length();
/*  62: 87 */     if (stringLen - maxCharsToReduce > fieldLen) {
/*  63: 89 */       throw new MobileApplicationException("maximumlength");
/*  64:    */     }
/*  65: 92 */     StringBuffer result = new StringBuffer(stringToFit);
/*  66: 93 */     boolean fromBefore = true;
/*  67: 94 */     while (stringLen > fieldLen)
/*  68:    */     {
/*  69: 96 */       if (fromBefore)
/*  70:    */       {
/*  71: 98 */         if (charsBefore > 0)
/*  72:    */         {
/*  73:100 */           result.deleteCharAt(0);
/*  74:101 */           charsBefore--;
/*  75:102 */           stringLen--;
/*  76:    */         }
/*  77:    */       }
/*  78:107 */       else if (charsAfter > 0)
/*  79:    */       {
/*  80:109 */         result.deleteCharAt(stringLen - 1);
/*  81:110 */         charsAfter--;
/*  82:111 */         stringLen--;
/*  83:    */       }
/*  84:115 */       fromBefore = !fromBefore;
/*  85:    */     }
/*  86:118 */     return result.toString();
/*  87:    */   }
/*  88:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.AutoKeyGenerator
 * JD-Core Version:    0.7.0.1
 */