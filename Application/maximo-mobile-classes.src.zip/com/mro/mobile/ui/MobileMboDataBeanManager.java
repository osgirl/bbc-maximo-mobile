/*   1:    */ package com.mro.mobile.ui;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.app.AbstractMobileDeviceApplication;
/*   5:    */ import com.mro.mobile.app.MobileDeviceAppSession;
/*   6:    */ import com.mro.mobile.app.OperationContainer;
/*   7:    */ import com.mro.mobile.app.OperationHandler;
/*   8:    */ import com.mro.mobile.mbo.MobileMbo;
/*   9:    */ import com.mro.mobile.mbo.MobileMboInfo;
/*  10:    */ import com.mro.mobile.mbo.MobileMboUtil;
/*  11:    */ import com.mro.mobile.persist.RDO;
/*  12:    */ import com.mro.mobile.persist.RDOManager;
/*  13:    */ import com.mro.mobile.persist.RDORuntime;
/*  14:    */ import com.mro.mobile.persist.RDOTransactionManager;
/*  15:    */ import com.mro.mobile.util.MobileLogger;
/*  16:    */ import com.mro.mobile.util.MobileLoggerFactory;
/*  17:    */ import java.util.Enumeration;
/*  18:    */ import java.util.Hashtable;
/*  19:    */ 
/*  20:    */ public class MobileMboDataBeanManager
/*  21:    */ {
/*  22: 43 */   private MobileMboDataBean dataBean = null;
/*  23: 46 */   private String name = null;
/*  24:    */   
/*  25:    */   public MobileMboDataBeanManager(String name)
/*  26:    */   {
/*  27: 52 */     this.name = name;
/*  28:    */   }
/*  29:    */   
/*  30:    */   public String getName()
/*  31:    */   {
/*  32: 62 */     return this.name;
/*  33:    */   }
/*  34:    */   
/*  35:    */   public MobileMboDataBean getDataBean()
/*  36:    */     throws MobileApplicationException
/*  37:    */   {
/*  38: 73 */     if (this.dataBean == null)
/*  39:    */     {
/*  40: 75 */       MobileDeviceAppSession deviceAppSession = MobileDeviceAppSession.getSession();
/*  41: 76 */       AbstractMobileDeviceApplication app = deviceAppSession.getApplication();
/*  42:    */       
/*  43: 78 */       MobileMboInfo info = MobileMboUtil.getMobileMboInfo(app.getAppName(), this.name);
/*  44: 79 */       if (info == null) {
/*  45: 81 */         throw new MobileApplicationException("invalidmobilembo", new Object[] { this.name });
/*  46:    */       }
/*  47: 84 */       this.dataBean = new MobileMboDataBean(app, this.name);
/*  48: 85 */       this.dataBean.setDataBeanManager(this);
/*  49:    */     }
/*  50: 88 */     return this.dataBean;
/*  51:    */   }
/*  52:    */   
/*  53:    */   public void save()
/*  54:    */     throws MobileApplicationException
/*  55:    */   {
/*  56: 98 */     if (this.dataBean == null) {
/*  57:100 */       return;
/*  58:    */     }
/*  59:103 */     MobileDeviceAppSession deviceAppSession = MobileDeviceAppSession.getSession();
/*  60:104 */     AbstractMobileDeviceApplication app = deviceAppSession.getApplication();
/*  61:    */     
/*  62:106 */     RDORuntime rdoRuntime = app.getRDORuntime();
/*  63:107 */     RDOManager rdoManager = rdoRuntime.getRDOManager();
/*  64:108 */     RDOTransactionManager txnManager = rdoRuntime.getRDOTransactionManager();
/*  65:    */     try
/*  66:    */     {
/*  67:112 */       DependentPosition depPosition = recordDependentPositions(this.dataBean);
/*  68:    */       
/*  69:114 */       txnManager.begin();
/*  70:115 */       saveDataBean(this.dataBean, rdoManager);
/*  71:116 */       txnManager.commit();
/*  72:    */       
/*  73:    */ 
/*  74:    */ 
/*  75:    */ 
/*  76:    */ 
/*  77:122 */       clearDataBeanFlags(this.dataBean);
/*  78:    */       
/*  79:124 */       restoreDependentPositions(this.dataBean, depPosition);
/*  80:    */       
/*  81:126 */       DataBeanCache.rebuild();
/*  82:    */     }
/*  83:    */     catch (Exception ex)
/*  84:    */     {
/*  85:130 */       MobileLoggerFactory.getDefaultLogger().warn("Failed to save", ex);
/*  86:    */       try
/*  87:    */       {
/*  88:134 */         txnManager.rollback();
/*  89:    */       }
/*  90:    */       catch (Exception ex1) {}
/*  91:137 */       throw new MobileApplicationException("savefailed");
/*  92:    */     }
/*  93:    */   }
/*  94:    */   
/*  95:    */   private void saveDataBean(MobileMboDataBean dataBean, RDOManager rdoManager)
/*  96:    */     throws MobileApplicationException
/*  97:    */   {
/*  98:152 */     int currentSize = dataBean.getCurrentSize();
/*  99:    */     
/* 100:    */ 
/* 101:155 */     MobileDeviceAppSession deviceAppSession = MobileDeviceAppSession.getSession();
/* 102:156 */     AbstractMobileDeviceApplication app = deviceAppSession.getApplication();
/* 103:157 */     OperationContainer curOperationContainer = app.getOperationContainer(dataBean.getName(), "save");
/* 104:158 */     OperationHandler operHandler = null;
/* 105:159 */     if (curOperationContainer != null) {
/* 106:161 */       operHandler = curOperationContainer.getHandler();
/* 107:    */     }
/* 108:163 */     for (int i = 0; i < currentSize; i++)
/* 109:    */     {
/* 110:165 */       MobileMbo mbo = dataBean.getMobileMbo(i);
/* 111:166 */       if (mbo.isToBeSaved())
/* 112:    */       {
/* 113:172 */         boolean shouldContinue = true;
/* 114:173 */         if (operHandler != null) {
/* 115:175 */           shouldContinue = operHandler.beforeOperation("save", dataBean, i);
/* 116:    */         }
/* 117:177 */         if (shouldContinue)
/* 118:    */         {
/* 119:179 */           RDO rdo = mbo.getRDO();
/* 120:180 */           if (mbo.isToBeDeleted())
/* 121:    */           {
/* 122:186 */             if (!mbo.isToBeInserted()) {
/* 123:188 */               rdoManager.remove(rdo.getName(), rdo);
/* 124:    */             }
/* 125:    */           }
/* 126:191 */           else if (mbo.isToBeInserted()) {
/* 127:193 */             rdoManager.insert(rdo.getName(), rdo);
/* 128:195 */           } else if (mbo.isToBeUpdated()) {
/* 129:197 */             rdoManager.update(rdo.getName(), rdo);
/* 130:    */           }
/* 131:200 */           if (operHandler != null) {
/* 132:202 */             operHandler.handleOperation("save", dataBean, i);
/* 133:    */           }
/* 134:    */         }
/* 135:    */       }
/* 136:    */     }
/* 137:208 */     for (int i = 0; i < currentSize; i++)
/* 138:    */     {
/* 139:210 */       MobileMbo mbo = dataBean.getMobileMbo(i);
/* 140:    */       
/* 141:212 */       Enumeration depEnum = dataBean.getCurrentDependents(i);
/* 142:213 */       if (depEnum != null) {
/* 143:218 */         while (depEnum.hasMoreElements())
/* 144:    */         {
/* 145:220 */           String dependentName = (String)depEnum.nextElement();
/* 146:221 */           MobileMboDataBean depDataBean = dataBean.getDataBean(i, dependentName);
/* 147:222 */           saveDataBean(depDataBean, rdoManager);
/* 148:    */         }
/* 149:    */       }
/* 150:    */     }
/* 151:226 */     dataBean.saveCompleted();
/* 152:230 */     if (dataBean.getMobileMboInfo().getParent() != null)
/* 153:    */     {
/* 154:232 */       int currentPos = dataBean.getCurrentPosition();
/* 155:233 */       dataBean.reset();
/* 156:234 */       dataBean.setCurrentPosition(currentPos);
/* 157:    */     }
/* 158:    */   }
/* 159:    */   
/* 160:    */   static class DependentPosition
/* 161:    */   {
/* 162:242 */     private String name = null;
/* 163:243 */     private int position = -1;
/* 164:245 */     Hashtable dependentPositions = new Hashtable();
/* 165:    */     
/* 166:    */     public DependentPosition(String name, int position)
/* 167:    */     {
/* 168:249 */       this.name = name;
/* 169:250 */       this.position = position;
/* 170:    */     }
/* 171:    */     
/* 172:    */     public String getName()
/* 173:    */     {
/* 174:255 */       return this.name;
/* 175:    */     }
/* 176:    */     
/* 177:    */     public int getPosition()
/* 178:    */     {
/* 179:260 */       return this.position;
/* 180:    */     }
/* 181:    */     
/* 182:    */     public void addDependentPosition(String dependentName, DependentPosition dependentPosition)
/* 183:    */     {
/* 184:265 */       this.dependentPositions.put(dependentName, dependentPosition);
/* 185:    */     }
/* 186:    */     
/* 187:    */     public DependentPosition getDependentPosition(String dependentName)
/* 188:    */     {
/* 189:270 */       return (DependentPosition)this.dependentPositions.get(dependentName);
/* 190:    */     }
/* 191:    */     
/* 192:    */     public Enumeration getDependentPositions()
/* 193:    */     {
/* 194:275 */       return this.dependentPositions.elements();
/* 195:    */     }
/* 196:    */   }
/* 197:    */   
/* 198:    */   private DependentPosition recordDependentPositions(MobileMboDataBean dataBean)
/* 199:    */     throws MobileApplicationException
/* 200:    */   {
/* 201:285 */     int currentPos = dataBean.getCurrentPosition();
/* 202:    */     
/* 203:287 */     DependentPosition depPosition = new DependentPosition(dataBean.getName(), currentPos);
/* 204:288 */     if (currentPos == -1) {
/* 205:290 */       return depPosition;
/* 206:    */     }
/* 207:293 */     Enumeration depEnum = dataBean.getCurrentDependents(currentPos);
/* 208:294 */     if (depEnum == null) {
/* 209:296 */       return depPosition;
/* 210:    */     }
/* 211:299 */     while (depEnum.hasMoreElements())
/* 212:    */     {
/* 213:301 */       String depName = (String)depEnum.nextElement();
/* 214:    */       
/* 215:303 */       MobileMboDataBean depDataBean = dataBean.getDataBean(currentPos, depName);
/* 216:    */       
/* 217:305 */       int depCurrentPos = depDataBean.getCurrentPosition();
/* 218:306 */       if (depCurrentPos != -1)
/* 219:    */       {
/* 220:311 */         DependentPosition depPosition1 = recordDependentPositions(depDataBean);
/* 221:    */         
/* 222:313 */         depPosition.addDependentPosition(depDataBean.getName(), depPosition1);
/* 223:    */       }
/* 224:    */     }
/* 225:316 */     return depPosition;
/* 226:    */   }
/* 227:    */   
/* 228:    */   private void restoreDependentPositions(MobileMboDataBean dataBean, DependentPosition depPosition)
/* 229:    */     throws MobileApplicationException
/* 230:    */   {
/* 231:326 */     int curPosition = depPosition.getPosition();
/* 232:327 */     dataBean.setCurrentPosition(curPosition);
/* 233:    */     
/* 234:329 */     Enumeration enumDepPositions = depPosition.getDependentPositions();
/* 235:330 */     while (enumDepPositions.hasMoreElements())
/* 236:    */     {
/* 237:332 */       DependentPosition depPosition1 = (DependentPosition)enumDepPositions.nextElement();
/* 238:333 */       String depName = depPosition1.getName();
/* 239:334 */       MobileMboDataBean depDataBean = dataBean.getDataBean(curPosition, depName);
/* 240:336 */       if (depDataBean != null) {
/* 241:337 */         restoreDependentPositions(depDataBean, depPosition1);
/* 242:    */       }
/* 243:    */     }
/* 244:    */   }
/* 245:    */   
/* 246:    */   private void clearDataBeanFlags(MobileMboDataBean dataBean)
/* 247:    */     throws MobileApplicationException
/* 248:    */   {
/* 249:350 */     int currentSize = dataBean.getCurrentSize();
/* 250:    */     
/* 251:352 */     int index = 0;
/* 252:355 */     while (index < currentSize)
/* 253:    */     {
/* 254:360 */       MobileMbo mbo = dataBean.getMobileMbo(index);
/* 255:361 */       if (mbo == null) {
/* 256:    */         break;
/* 257:    */       }
/* 258:366 */       if (!mbo.isToBeSaved())
/* 259:    */       {
/* 260:368 */         index++;
/* 261:    */       }
/* 262:    */       else
/* 263:    */       {
/* 264:372 */         if (mbo.isToBeInserted())
/* 265:    */         {
/* 266:374 */           mbo.setToBeInserted(false);
/* 267:    */         }
/* 268:376 */         else if (mbo.isToBeUpdated())
/* 269:    */         {
/* 270:378 */           mbo.setToBeUpdated(false);
/* 271:    */         }
/* 272:380 */         else if (mbo.isToBeDeleted())
/* 273:    */         {
/* 274:382 */           dataBean.remove(index);
/* 275:383 */           continue;
/* 276:    */         }
/* 277:385 */         index++;
/* 278:    */       }
/* 279:    */     }
/* 280:389 */     for (int i = 0; i < currentSize; i++)
/* 281:    */     {
/* 282:391 */       MobileMbo mbo = dataBean.getMobileMbo(i);
/* 283:    */       
/* 284:393 */       Enumeration depEnum = dataBean.getCurrentDependents(i);
/* 285:394 */       if (depEnum != null) {
/* 286:399 */         while (depEnum.hasMoreElements())
/* 287:    */         {
/* 288:401 */           String dependentName = (String)depEnum.nextElement();
/* 289:402 */           MobileMboDataBean depDataBean = dataBean.getDataBean(i, dependentName);
/* 290:403 */           clearDataBeanFlags(depDataBean);
/* 291:    */         }
/* 292:    */       }
/* 293:    */     }
/* 294:    */   }
/* 295:    */   
/* 296:    */   public void reset()
/* 297:    */     throws MobileApplicationException
/* 298:    */   {
/* 299:415 */     this.dataBean = null;
/* 300:    */   }
/* 301:    */   
/* 302:    */   public void cancel()
/* 303:    */     throws MobileApplicationException
/* 304:    */   {
/* 305:426 */     cancelDataBean(this.dataBean);
/* 306:427 */     clearDataBeanFlags(this.dataBean);
/* 307:    */   }
/* 308:    */   
/* 309:    */   private void cancelDataBean(MobileMboDataBean dataBean)
/* 310:    */     throws MobileApplicationException
/* 311:    */   {
/* 312:439 */     if (dataBean == null) {
/* 313:441 */       return;
/* 314:    */     }
/* 315:445 */     int currentSize = dataBean.getCurrentSize();
/* 316:446 */     dataBean.cancel();
/* 317:449 */     for (int i = 0; i < currentSize; i++)
/* 318:    */     {
/* 319:451 */       MobileMbo mbo = dataBean.getMobileMbo(i);
/* 320:    */       
/* 321:453 */       Enumeration depEnum = dataBean.getCurrentDependents(i);
/* 322:454 */       if (depEnum != null) {
/* 323:459 */         while (depEnum.hasMoreElements())
/* 324:    */         {
/* 325:461 */           String dependentName = (String)depEnum.nextElement();
/* 326:462 */           MobileMboDataBean depDataBean = dataBean.getDataBean(i, dependentName);
/* 327:463 */           cancelDataBean(depDataBean);
/* 328:    */         }
/* 329:    */       }
/* 330:    */     }
/* 331:    */   }
/* 332:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.MobileMboDataBeanManager
 * JD-Core Version:    0.7.0.1
 */