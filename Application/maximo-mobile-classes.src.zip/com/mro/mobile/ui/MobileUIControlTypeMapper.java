/*  1:   */ package com.mro.mobile.ui;
/*  2:   */ 
/*  3:   */ public class MobileUIControlTypeMapper
/*  4:   */ {
/*  5:   */   public static int getUIComponentType(String typeName)
/*  6:   */   {
/*  7:20 */     if ((typeName.equals("mobilescreen")) || (typeName.equals("page")) || (typeName.equals("lookup"))) {
/*  8:22 */       return 1;
/*  9:   */     }
/* 10:25 */     return 0;
/* 11:   */   }
/* 12:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.MobileUIControlTypeMapper
 * JD-Core Version:    0.7.0.1
 */