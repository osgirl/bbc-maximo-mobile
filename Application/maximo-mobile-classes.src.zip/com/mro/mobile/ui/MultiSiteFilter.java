/*   1:    */ package com.mro.mobile.ui;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.mbo.MobileMbo;
/*   5:    */ import com.mro.mobile.mbo.MobileMboAttributeInfo;
/*   6:    */ import com.mro.mobile.mbo.MobileMboInfo;
/*   7:    */ import com.mro.mobile.mbo.MobileMboQBE;
/*   8:    */ 
/*   9:    */ public class MultiSiteFilter
/*  10:    */ {
/*  11:    */   public void applyMultiSiteFilter(MobileMboDataBean domainDataBean, MobileMboDataBean sourceDataBean)
/*  12:    */     throws MobileApplicationException
/*  13:    */   {
/*  14: 37 */     boolean sourceSiteAttrExists = false;
/*  15: 38 */     boolean sourceOrgAttrExists = false;
/*  16: 39 */     boolean sourceItemSetAttrExists = false;
/*  17: 40 */     boolean sourceCompanySetAttrExists = false;
/*  18:    */     
/*  19: 42 */     MobileMboInfo domainMboInfo = domainDataBean.getMobileMboInfo();
/*  20:    */     
/*  21: 44 */     MobileMboInfo sourceMboInfo = sourceDataBean.getMobileMboInfo();
/*  22: 47 */     if (sourceMboInfo.getSiteAttribute() != null) {
/*  23: 49 */       sourceSiteAttrExists = true;
/*  24:    */     }
/*  25: 52 */     if (sourceMboInfo.getOrgAttribute() != null) {
/*  26: 54 */       sourceOrgAttrExists = true;
/*  27:    */     }
/*  28: 57 */     if (sourceMboInfo.getItemSetAttribute() != null) {
/*  29: 59 */       sourceItemSetAttrExists = true;
/*  30:    */     }
/*  31: 62 */     if (sourceMboInfo.getCompanySetAttribute() != null) {
/*  32: 64 */       sourceCompanySetAttrExists = true;
/*  33:    */     }
/*  34: 67 */     MobileMbo sourceMobileMbo = sourceDataBean.getMobileMbo();
/*  35: 69 */     if (sourceMobileMbo == null) {
/*  36: 70 */       return;
/*  37:    */     }
/*  38: 72 */     MobileMboAttributeInfo siteInfo = null;
/*  39: 74 */     if (sourceMboInfo.getSiteAttribute() != null) {
/*  40: 75 */       siteInfo = sourceMboInfo.getAttributeInfo(sourceMboInfo.getSiteAttribute());
/*  41:    */     }
/*  42: 78 */     if ((siteInfo != null) && (siteInfo.isRequired()))
/*  43:    */     {
/*  44: 80 */       if ((sourceMboInfo.isSiteLevel()) && (sourceSiteAttrExists) && (sourceMobileMbo.isNull(sourceMboInfo.getSiteAttribute())) && (domainMboInfo.isSiteLevel())) {
/*  45: 92 */         throw new MobileApplicationException("siteidnull");
/*  46:    */       }
/*  47: 95 */       if ((sourceMboInfo.isOrgLevel()) && (sourceOrgAttrExists) && (sourceMobileMbo.isNull(sourceMboInfo.getOrgAttribute())) && (domainMboInfo.isOrgLevel())) {
/*  48:106 */         throw new MobileApplicationException("orgidnull");
/*  49:    */       }
/*  50:109 */       if ((sourceMboInfo.isItemSetLevel()) && (sourceItemSetAttrExists) && (sourceMobileMbo.isNull(sourceMboInfo.getItemSetAttribute())) && (domainMboInfo.isItemSetLevel())) {
/*  51:120 */         throw new MobileApplicationException("itemsetidnull");
/*  52:    */       }
/*  53:123 */       if ((sourceMboInfo.isCompanySetLevel()) && (sourceCompanySetAttrExists) && (sourceMobileMbo.isNull(sourceMboInfo.getCompanySetAttribute())) && (domainMboInfo.isCompanySetLevel())) {
/*  54:134 */         throw new MobileApplicationException("companysetidnull");
/*  55:    */       }
/*  56:    */     }
/*  57:138 */     if (sourceMboInfo.isSiteLevel())
/*  58:    */     {
/*  59:141 */       String siteId = sourceMobileMbo.getValue(sourceMboInfo.getSiteAttribute());
/*  60:143 */       if (domainMboInfo.isSiteLevel())
/*  61:    */       {
/*  62:145 */         domainDataBean.setInternalQBE(domainMboInfo.getSiteAttribute(), "=" + siteId);
/*  63:    */       }
/*  64:147 */       else if (domainMboInfo.isOrgLevel())
/*  65:    */       {
/*  66:149 */         String orgId = null;
/*  67:151 */         if ((sourceOrgAttrExists) && (!sourceMobileMbo.isNull(sourceMboInfo.getOrgAttribute()))) {
/*  68:154 */           orgId = sourceMobileMbo.getValue(sourceMboInfo.getOrgAttribute());
/*  69:    */         } else {
/*  70:158 */           orgId = getOrgId(siteId);
/*  71:    */         }
/*  72:161 */         domainDataBean.setInternalQBE(domainMboInfo.getOrgAttribute(), "=" + orgId);
/*  73:    */       }
/*  74:163 */       else if (domainMboInfo.isItemSetLevel())
/*  75:    */       {
/*  76:165 */         String itemSetId = null;
/*  77:167 */         if ((sourceItemSetAttrExists) && (!sourceMobileMbo.isNull(sourceMboInfo.getItemSetAttribute()))) {
/*  78:170 */           itemSetId = sourceMobileMbo.getValue(sourceMboInfo.getItemSetAttribute());
/*  79:    */         } else {
/*  80:174 */           itemSetId = getItemSetIdOfSite(siteId);
/*  81:    */         }
/*  82:177 */         domainDataBean.setInternalQBE(domainMboInfo.getItemSetAttribute(), "=" + itemSetId);
/*  83:    */       }
/*  84:179 */       else if (domainMboInfo.isCompanySetLevel())
/*  85:    */       {
/*  86:181 */         String companySetId = null;
/*  87:184 */         if ((sourceCompanySetAttrExists) && (!sourceMobileMbo.isNull(sourceMboInfo.getCompanySetAttribute()))) {
/*  88:187 */           companySetId = sourceMobileMbo.getValue(sourceMboInfo.getCompanySetAttribute());
/*  89:    */         } else {
/*  90:191 */           companySetId = getCompanySetIdOfSite(siteId);
/*  91:    */         }
/*  92:194 */         domainDataBean.setInternalQBE(domainMboInfo.getCompanySetAttribute(), "=" + companySetId);
/*  93:    */       }
/*  94:200 */       if (domainMboInfo.isDomain())
/*  95:    */       {
/*  96:203 */         String siteAttribute = domainMboInfo.getSiteAttribute();
/*  97:204 */         if (siteAttribute != null)
/*  98:    */         {
/*  99:206 */           domainDataBean.setInternalQBE(siteAttribute, siteId);
/* 100:207 */           domainDataBean.reset();
/* 101:208 */           if (domainDataBean.count() > 0) {
/* 102:210 */             return;
/* 103:    */           }
/* 104:    */         }
/* 105:215 */         String orgAttribute = domainMboInfo.getOrgAttribute();
/* 106:216 */         if (orgAttribute != null)
/* 107:    */         {
/* 108:218 */           String orgId = getOrgId(siteId);
/* 109:219 */           domainDataBean.setInternalQBE(orgAttribute, orgId);
/* 110:220 */           if (siteAttribute != null) {
/* 111:222 */             domainDataBean.setInternalQBE(siteAttribute, "~NULL~");
/* 112:    */           }
/* 113:224 */           domainDataBean.reset();
/* 114:225 */           if (domainDataBean.count() > 0) {
/* 115:227 */             return;
/* 116:    */           }
/* 117:    */         }
/* 118:232 */         if (orgAttribute != null) {
/* 119:234 */           domainDataBean.setInternalQBE(orgAttribute, "~NULL~");
/* 120:    */         }
/* 121:236 */         if (siteAttribute != null) {
/* 122:238 */           domainDataBean.setInternalQBE(siteAttribute, "~NULL~");
/* 123:    */         }
/* 124:240 */         domainDataBean.reset();
/* 125:    */       }
/* 126:    */     }
/* 127:246 */     else if (sourceMboInfo.isOrgLevel())
/* 128:    */     {
/* 129:249 */       String orgId = sourceMobileMbo.getValue(sourceMboInfo.getOrgAttribute());
/* 130:251 */       if (domainMboInfo.isSiteLevel())
/* 131:    */       {
/* 132:254 */         if ((sourceSiteAttrExists) && (!sourceMobileMbo.isNull(sourceMboInfo.getSiteAttribute()))) {
/* 133:256 */           domainDataBean.setInternalQBE(domainMboInfo.getSiteAttribute(), "=" + sourceMobileMbo.getValue(sourceMboInfo.getSiteAttribute()));
/* 134:    */         }
/* 135:    */       }
/* 136:264 */       else if (domainMboInfo.isOrgLevel())
/* 137:    */       {
/* 138:266 */         domainDataBean.setInternalQBE(domainMboInfo.getOrgAttribute(), "=" + orgId);
/* 139:    */       }
/* 140:268 */       else if (domainMboInfo.isItemSetLevel())
/* 141:    */       {
/* 142:270 */         String itemSetId = null;
/* 143:273 */         if ((sourceItemSetAttrExists) && (!sourceMobileMbo.isNull(sourceMboInfo.getItemSetAttribute()))) {
/* 144:276 */           itemSetId = sourceMobileMbo.getValue(sourceMboInfo.getItemSetAttribute());
/* 145:    */         } else {
/* 146:280 */           itemSetId = getItemSetIdOfOrg(orgId);
/* 147:    */         }
/* 148:283 */         domainDataBean.setInternalQBE(domainMboInfo.getItemSetAttribute(), "=" + itemSetId);
/* 149:    */       }
/* 150:285 */       else if (domainMboInfo.isCompanySetLevel())
/* 151:    */       {
/* 152:287 */         String companySetId = null;
/* 153:289 */         if ((sourceCompanySetAttrExists) && (!sourceMobileMbo.isNull(sourceMboInfo.getCompanySetAttribute()))) {
/* 154:292 */           companySetId = sourceMobileMbo.getValue(sourceMboInfo.getCompanySetAttribute());
/* 155:    */         } else {
/* 156:296 */           companySetId = getCompanySetIdOfOrg(orgId);
/* 157:    */         }
/* 158:299 */         domainDataBean.setInternalQBE(domainMboInfo.getCompanySetAttribute(), "=" + companySetId);
/* 159:    */       }
/* 160:305 */       if (domainMboInfo.isDomain())
/* 161:    */       {
/* 162:308 */         String orgAttribute = domainMboInfo.getOrgAttribute();
/* 163:309 */         if (orgAttribute != null)
/* 164:    */         {
/* 165:311 */           domainDataBean.setInternalQBE(orgAttribute, orgId);
/* 166:312 */           String siteAttribute = domainMboInfo.getSiteAttribute();
/* 167:313 */           if (siteAttribute != null) {
/* 168:315 */             domainDataBean.setInternalQBE(siteAttribute, "~NULL~");
/* 169:    */           }
/* 170:317 */           domainDataBean.reset();
/* 171:318 */           if (domainDataBean.count() > 0) {
/* 172:320 */             return;
/* 173:    */           }
/* 174:    */         }
/* 175:325 */         String siteAttribute = domainMboInfo.getSiteAttribute();
/* 176:326 */         if (siteAttribute != null) {
/* 177:328 */           domainDataBean.setInternalQBE(siteAttribute, "~NULL~");
/* 178:    */         }
/* 179:331 */         if (orgAttribute != null) {
/* 180:333 */           domainDataBean.setInternalQBE(orgAttribute, "~NULL~");
/* 181:    */         }
/* 182:336 */         domainDataBean.reset();
/* 183:    */       }
/* 184:    */     }
/* 185:    */     else
/* 186:    */     {
/* 187:343 */       if (sourceMboInfo.isItemSetLevel()) {
/* 188:345 */         throw new MobileApplicationException("unsupported");
/* 189:    */       }
/* 190:348 */       if (sourceMboInfo.isCompanySetLevel()) {
/* 191:350 */         throw new MobileApplicationException("unsupported");
/* 192:    */       }
/* 193:353 */       if (sourceMboInfo.isSystemLevel())
/* 194:    */       {
/* 195:355 */         if (domainMboInfo.isSiteLevel())
/* 196:    */         {
/* 197:358 */           if ((sourceSiteAttrExists) && (!sourceMobileMbo.isNull(sourceMboInfo.getSiteAttribute())))
/* 198:    */           {
/* 199:361 */             String siteId = sourceMobileMbo.getValue(sourceMboInfo.getSiteAttribute());
/* 200:362 */             domainDataBean.setInternalQBE(domainMboInfo.getSiteAttribute(), "=" + siteId);
/* 201:    */           }
/* 202:364 */           else if ((sourceOrgAttrExists) && (!sourceMobileMbo.isNull(sourceMboInfo.getOrgAttribute())))
/* 203:    */           {
/* 204:366 */             String orgId = sourceMobileMbo.getValue(sourceMboInfo.getOrgAttribute());
/* 205:367 */             domainDataBean.setInternalQBE(domainMboInfo.getOrgAttribute(), "=" + orgId);
/* 206:    */           }
/* 207:    */         }
/* 208:370 */         else if (domainMboInfo.isOrgLevel())
/* 209:    */         {
/* 210:373 */           String orgId = null;
/* 211:374 */           if ((sourceOrgAttrExists) && (!sourceMobileMbo.isNull(sourceMboInfo.getOrgAttribute())))
/* 212:    */           {
/* 213:377 */             orgId = sourceMobileMbo.getValue(sourceMboInfo.getOrgAttribute());
/* 214:378 */             domainDataBean.setInternalQBE(domainMboInfo.getOrgAttribute(), "=" + orgId);
/* 215:    */           }
/* 216:    */         }
/* 217:381 */         else if (domainMboInfo.isItemSetLevel())
/* 218:    */         {
/* 219:384 */           String itemSetId = null;
/* 220:386 */           if (sourceItemSetAttrExists)
/* 221:    */           {
/* 222:389 */             itemSetId = sourceMobileMbo.getValue(sourceMboInfo.getItemSetAttribute());
/* 223:390 */             domainDataBean.setInternalQBE(domainMboInfo.getItemSetAttribute(), "=" + itemSetId);
/* 224:    */           }
/* 225:    */         }
/* 226:393 */         else if (domainMboInfo.isCompanySetLevel())
/* 227:    */         {
/* 228:396 */           String companySetId = null;
/* 229:398 */           if (sourceCompanySetAttrExists)
/* 230:    */           {
/* 231:401 */             companySetId = sourceMobileMbo.getValue(sourceMboInfo.getCompanySetAttribute());
/* 232:402 */             domainDataBean.setInternalQBE(domainMboInfo.getCompanySetAttribute(), "=" + companySetId);
/* 233:    */           }
/* 234:    */         }
/* 235:409 */         if (domainMboInfo.isDomain())
/* 236:    */         {
/* 237:412 */           String siteAttribute = domainMboInfo.getSiteAttribute();
/* 238:413 */           if (siteAttribute != null) {
/* 239:415 */             domainDataBean.setInternalQBE(siteAttribute, "~NULL~");
/* 240:    */           }
/* 241:418 */           String orgAttribute = domainMboInfo.getOrgAttribute();
/* 242:419 */           if (orgAttribute != null) {
/* 243:421 */             domainDataBean.setInternalQBE(orgAttribute, "~NULL~");
/* 244:    */           }
/* 245:424 */           domainDataBean.reset();
/* 246:    */         }
/* 247:    */       }
/* 248:    */     }
/* 249:    */   }
/* 250:    */   
/* 251:    */   public void applySelectedMultiSiteValue(MobileMboDataBean domainDataBean, MobileMboDataBean sourceDataBean)
/* 252:    */     throws MobileApplicationException
/* 253:    */   {
/* 254:445 */     if (domainDataBean.getCurrentPosition() < 0) {
/* 255:448 */       return;
/* 256:    */     }
/* 257:452 */     MobileMboInfo domainMboInfo = domainDataBean.getMobileMboInfo();
/* 258:453 */     MobileMboInfo sourceMboInfo = sourceDataBean.getMobileMboInfo();
/* 259:454 */     if (sourceMboInfo.isSiteLevel()) {
/* 260:456 */       if (domainMboInfo.isSiteLevel())
/* 261:    */       {
/* 262:458 */         String sourceSiteAttribute = sourceMboInfo.getSiteAttribute();
/* 263:460 */         if ((sourceSiteAttribute != null) && (sourceDataBean.getMobileMbo().isNull(sourceSiteAttribute)))
/* 264:    */         {
/* 265:464 */           String domainSiteId = domainDataBean.getValue(domainMboInfo.getSiteAttribute());
/* 266:465 */           sourceDataBean.setValue(sourceMboInfo.getSiteAttribute(), domainSiteId);
/* 267:    */         }
/* 268:    */       }
/* 269:    */     }
/* 270:469 */     if (sourceMboInfo.isOrgLevel())
/* 271:    */     {
/* 272:471 */       if (domainMboInfo.isSiteLevel())
/* 273:    */       {
/* 274:473 */         String domainSiteId = domainDataBean.getValue(domainMboInfo.getSiteAttribute());
/* 275:    */         
/* 276:475 */         String sourceSiteAttribute = sourceMboInfo.getSiteAttribute();
/* 277:476 */         if ((sourceSiteAttribute != null) && (sourceDataBean.getMobileMbo().isNull(sourceSiteAttribute))) {
/* 278:479 */           sourceDataBean.setValue(sourceSiteAttribute, domainSiteId);
/* 279:    */         }
/* 280:482 */         String sourceOrgAttribute = sourceMboInfo.getOrgAttribute();
/* 281:483 */         if ((sourceOrgAttribute != null) && (sourceDataBean.getMobileMbo().isNull(sourceOrgAttribute)))
/* 282:    */         {
/* 283:487 */           String domainOrgId = getOrgId(domainSiteId);
/* 284:488 */           sourceDataBean.setValue(sourceOrgAttribute, domainOrgId);
/* 285:    */         }
/* 286:    */       }
/* 287:509 */       else if (domainMboInfo.isOrgLevel())
/* 288:    */       {
/* 289:511 */         String sourceOrgAttribute = sourceMboInfo.getOrgAttribute();
/* 290:513 */         if ((sourceOrgAttribute != null) && (sourceDataBean.getMobileMbo().isNull(sourceOrgAttribute)))
/* 291:    */         {
/* 292:517 */           String domainOrgId = domainDataBean.getValue(domainMboInfo.getOrgAttribute());
/* 293:518 */           sourceDataBean.setValue(sourceMboInfo.getOrgAttribute(), domainOrgId);
/* 294:    */         }
/* 295:    */       }
/* 296:    */     }
/* 297:522 */     else if (sourceMboInfo.isSystemLevel()) {
/* 298:524 */       if (domainMboInfo.isSiteLevel())
/* 299:    */       {
/* 300:526 */         String domainSiteId = domainDataBean.getValue(domainMboInfo.getSiteAttribute());
/* 301:    */         
/* 302:528 */         String sourceSiteAttribute = sourceMboInfo.getSiteAttribute();
/* 303:529 */         if ((sourceSiteAttribute != null) && (sourceDataBean.getMobileMbo().isNull(sourceSiteAttribute))) {
/* 304:532 */           sourceDataBean.setValue(sourceSiteAttribute, domainSiteId);
/* 305:    */         }
/* 306:    */       }
/* 307:560 */       else if (domainMboInfo.isOrgLevel())
/* 308:    */       {
/* 309:562 */         String domainOrgId = domainDataBean.getValue(domainMboInfo.getOrgAttribute());
/* 310:    */         
/* 311:564 */         String sourceOrgAttribute = sourceMboInfo.getOrgAttribute();
/* 312:565 */         if ((sourceOrgAttribute != null) && (sourceDataBean.getMobileMbo().isNull(sourceOrgAttribute))) {
/* 313:568 */           sourceDataBean.setValue(sourceOrgAttribute, domainOrgId);
/* 314:    */         }
/* 315:    */       }
/* 316:587 */       else if (domainMboInfo.isItemSetLevel())
/* 317:    */       {
/* 318:589 */         String sourceItemSetAttribute = sourceMboInfo.getItemSetAttribute();
/* 319:590 */         if ((sourceItemSetAttribute != null) && (sourceDataBean.getMobileMbo().isNull(sourceItemSetAttribute)))
/* 320:    */         {
/* 321:593 */           String domainItemSetId = domainDataBean.getValue(domainMboInfo.getItemSetAttribute());
/* 322:594 */           sourceDataBean.setValue(sourceMboInfo.getItemSetAttribute(), domainItemSetId);
/* 323:    */         }
/* 324:    */       }
/* 325:597 */       else if (domainMboInfo.isCompanySetLevel())
/* 326:    */       {
/* 327:599 */         String sourceCompanySetAttribute = sourceMboInfo.getCompanySetAttribute();
/* 328:600 */         if ((sourceCompanySetAttribute != null) && (sourceDataBean.getMobileMbo().isNull(sourceCompanySetAttribute)))
/* 329:    */         {
/* 330:603 */           String domainCompanySetId = domainDataBean.getValue(domainMboInfo.getCompanySetAttribute());
/* 331:604 */           sourceDataBean.setValue(sourceMboInfo.getCompanySetAttribute(), domainCompanySetId);
/* 332:    */         }
/* 333:    */       }
/* 334:    */     }
/* 335:    */   }
/* 336:    */   
/* 337:    */   public String getOrgId(String siteId)
/* 338:    */     throws MobileApplicationException
/* 339:    */   {
/* 340:617 */     MobileMboDataBeanManager dataBeanManager = new MobileMboDataBeanManager("SITE");
/* 341:618 */     MobileMboDataBean siteDataBean = dataBeanManager.getDataBean();
/* 342:619 */     siteDataBean.getQBE().setQBE("SITEID", "=" + siteId);
/* 343:    */     
/* 344:621 */     siteDataBean.getQBE().setQbeExactMatch(true);
/* 345:622 */     siteDataBean.reset();
/* 346:    */     
/* 347:    */ 
/* 348:625 */     MobileMbo siteMbo = siteDataBean.getMobileMbo(0);
/* 349:626 */     if (siteMbo == null) {
/* 350:628 */       return null;
/* 351:    */     }
/* 352:631 */     String orgId = siteMbo.getValue("ORGID");
/* 353:632 */     return orgId;
/* 354:    */   }
/* 355:    */   
/* 356:    */   public String getItemSetIdOfSite(String siteId)
/* 357:    */     throws MobileApplicationException
/* 358:    */   {
/* 359:637 */     String orgId = getOrgId(siteId);
/* 360:638 */     if (orgId == null) {
/* 361:640 */       return null;
/* 362:    */     }
/* 363:643 */     return getItemSetIdOfOrg(orgId);
/* 364:    */   }
/* 365:    */   
/* 366:    */   public String getItemSetIdOfOrg(String orgId)
/* 367:    */     throws MobileApplicationException
/* 368:    */   {
/* 369:649 */     MobileMboDataBeanManager dataBeanManager = new MobileMboDataBeanManager("ORGANIZATION");
/* 370:650 */     MobileMboDataBean orgDataBean = dataBeanManager.getDataBean();
/* 371:651 */     orgDataBean.getQBE().setQBE("ORGID", "=" + orgId);
/* 372:    */     
/* 373:653 */     orgDataBean.getQBE().setQbeExactMatch(true);
/* 374:654 */     orgDataBean.reset();
/* 375:    */     
/* 376:    */ 
/* 377:657 */     MobileMbo orgMbo = orgDataBean.getMobileMbo(0);
/* 378:658 */     if (orgMbo == null) {
/* 379:660 */       return null;
/* 380:    */     }
/* 381:663 */     String itemSetId = orgMbo.getValue("ITEMSETID");
/* 382:664 */     return itemSetId;
/* 383:    */   }
/* 384:    */   
/* 385:    */   public String getCompanySetIdOfSite(String siteId)
/* 386:    */     throws MobileApplicationException
/* 387:    */   {
/* 388:669 */     String orgId = getOrgId(siteId);
/* 389:670 */     if (orgId == null) {
/* 390:672 */       return null;
/* 391:    */     }
/* 392:675 */     return getCompanySetIdOfOrg(orgId);
/* 393:    */   }
/* 394:    */   
/* 395:    */   public String getCompanySetIdOfOrg(String orgId)
/* 396:    */     throws MobileApplicationException
/* 397:    */   {
/* 398:681 */     MobileMboDataBeanManager dataBeanManager = new MobileMboDataBeanManager("ORGANIZATION");
/* 399:682 */     MobileMboDataBean orgDataBean = dataBeanManager.getDataBean();
/* 400:683 */     orgDataBean.getQBE().setQBE("ORGID", "=" + orgId);
/* 401:    */     
/* 402:685 */     orgDataBean.getQBE().setQbeExactMatch(true);
/* 403:686 */     orgDataBean.reset();
/* 404:    */     
/* 405:    */ 
/* 406:689 */     MobileMbo orgMbo = orgDataBean.getMobileMbo(0);
/* 407:690 */     if (orgMbo == null) {
/* 408:692 */       return null;
/* 409:    */     }
/* 410:695 */     String companySetId = orgMbo.getValue("COMPANYSETID");
/* 411:696 */     return companySetId;
/* 412:    */   }
/* 413:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.MultiSiteFilter
 * JD-Core Version:    0.7.0.1
 */