package com.mro.mobile.ui.res;

public abstract interface MobileUIPropertiesSupport
{
  public abstract boolean getBooleanValue(String paramString);
  
  public abstract String getStringValue(String paramString);
  
  public abstract int getIntValue(String paramString, int paramInt);
  
  public abstract Object getValue(String paramString);
  
  public abstract Object get(String paramString);
  
  public abstract Object getValue(String paramString, boolean paramBoolean);
  
  public abstract void putValue(String paramString, Object paramObject);
  
  public abstract void put(String paramString, Object paramObject);
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.MobileUIPropertiesSupport
 * JD-Core Version:    0.7.0.1
 */