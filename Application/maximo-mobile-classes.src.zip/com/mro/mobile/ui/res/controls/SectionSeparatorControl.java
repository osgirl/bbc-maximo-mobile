/*   1:    */ package com.mro.mobile.ui.res.controls;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.app.BasicMobileDeviceUIApplication;
/*   5:    */ import com.mro.mobile.ui.event.UIEvent;
/*   6:    */ import com.mro.mobile.ui.res.ControlData;
/*   7:    */ import com.mro.mobile.ui.res.UIUtil;
/*   8:    */ import com.mro.mobile.ui.res.widgets.def.AbstractWidget;
/*   9:    */ import com.mro.mobile.ui.res.widgets.def.SectionSeparatorWidget;
/*  10:    */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  11:    */ import com.mro.mobile.ui.res.widgets.def.WidgetCreator;
/*  12:    */ 
/*  13:    */ public class SectionSeparatorControl
/*  14:    */   extends AbstractMobileControl
/*  15:    */ {
/*  16:    */   protected SectionSeparatorWidget getSectionSeparatorWidget()
/*  17:    */   {
/*  18: 44 */     return (SectionSeparatorWidget)super.getWidget();
/*  19:    */   }
/*  20:    */   
/*  21: 47 */   private int leftMargin = 0;
/*  22: 48 */   private int rightMargin = 0;
/*  23:    */   
/*  24:    */   public UIComponent[] composeComponents()
/*  25:    */     throws MobileApplicationException
/*  26:    */   {
/*  27: 55 */     SectionSeparatorWidget widget = getSectionSeparatorWidget();
/*  28: 56 */     widget.createSectionSeparator(this);
/*  29: 57 */     this.leftMargin = getIntValue("indents");
/*  30: 58 */     this.rightMargin = this.leftMargin;
/*  31: 59 */     int indents = this.leftMargin;
/*  32: 60 */     AbstractMobileControl ctrl = this;
/*  33: 61 */     while ((ctrl = ctrl.getParentControl()) != null) {
/*  34: 63 */       indents += ctrl.getIntValue("indents");
/*  35:    */     }
/*  36: 65 */     if (indents == 0)
/*  37:    */     {
/*  38: 67 */       this.rightMargin = 1;
/*  39: 68 */       this.leftMargin = 1;
/*  40:    */     }
/*  41:    */     else
/*  42:    */     {
/*  43: 72 */       this.rightMargin = indents;
/*  44:    */     }
/*  45: 74 */     this.rightMargin *= 10;
/*  46: 75 */     this.leftMargin *= 10;
/*  47: 76 */     widget.setOpaque(false);
/*  48:    */     
/*  49: 78 */     widget.setInsets(6, this.leftMargin, 8, this.rightMargin);
/*  50: 79 */     int fWidth = UIUtil.getApplication().getWindowWidth();
/*  51: 80 */     widget.setPreferredSize(fWidth - (this.leftMargin + this.rightMargin), 15);
/*  52:    */     
/*  53: 82 */     return widget.resolveSectionSeparatorWidgetComponents();
/*  54:    */   }
/*  55:    */   
/*  56:    */   protected boolean performEvent(UIEvent event)
/*  57:    */     throws MobileApplicationException
/*  58:    */   {
/*  59: 92 */     return false;
/*  60:    */   }
/*  61:    */   
/*  62:    */   protected boolean handleException(UIEvent event, Exception exception)
/*  63:    */   {
/*  64:100 */     return false;
/*  65:    */   }
/*  66:    */   
/*  67:    */   protected boolean refreshControl(UIEvent event)
/*  68:    */     throws MobileApplicationException
/*  69:    */   {
/*  70:111 */     return false;
/*  71:    */   }
/*  72:    */   
/*  73:    */   public AbstractMobileControl createControl(ControlData controlData)
/*  74:    */     throws MobileApplicationException
/*  75:    */   {
/*  76:119 */     return new SectionSeparatorControl();
/*  77:    */   }
/*  78:    */   
/*  79:122 */   private static WidgetCreator widgetCreator = null;
/*  80:    */   
/*  81:    */   public static void registerWidgetCreator(WidgetCreator wc)
/*  82:    */   {
/*  83:125 */     widgetCreator = wc;
/*  84:    */   }
/*  85:    */   
/*  86:    */   protected AbstractWidget createWidget()
/*  87:    */   {
/*  88:129 */     return widgetCreator.createWidget();
/*  89:    */   }
/*  90:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.controls.SectionSeparatorControl
 * JD-Core Version:    0.7.0.1
 */