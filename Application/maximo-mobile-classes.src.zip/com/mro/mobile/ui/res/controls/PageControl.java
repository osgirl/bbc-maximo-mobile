/*   1:    */ package com.mro.mobile.ui.res.controls;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.MobileMessageGenerator;
/*   5:    */ import com.mro.mobile.app.BasicMobileDeviceUIApplication;
/*   6:    */ import com.mro.mobile.mbo.MobileMbo;
/*   7:    */ import com.mro.mobile.ui.DataBeanCache;
/*   8:    */ import com.mro.mobile.ui.MobileMboDataBean;
/*   9:    */ import com.mro.mobile.ui.MobileMboDataBeanManager;
/*  10:    */ import com.mro.mobile.ui.event.UIEvent;
/*  11:    */ import com.mro.mobile.ui.res.ControlData;
/*  12:    */ import com.mro.mobile.ui.res.UIUtil;
/*  13:    */ import com.mro.mobile.ui.res.widgets.def.AbstractWidget;
/*  14:    */ import com.mro.mobile.ui.res.widgets.def.PageWidget;
/*  15:    */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  16:    */ import com.mro.mobile.ui.res.widgets.def.WidgetCreator;
/*  17:    */ import java.util.ArrayList;
/*  18:    */ import java.util.Collection;
/*  19:    */ import java.util.Enumeration;
/*  20:    */ import java.util.HashMap;
/*  21:    */ import java.util.Iterator;
/*  22:    */ import java.util.List;
/*  23:    */ 
/*  24:    */ public class PageControl
/*  25:    */   extends AbstractMobileControl
/*  26:    */ {
/*  27: 50 */   private UIComponent container = null;
/*  28: 51 */   private HashMap controlList = new HashMap();
/*  29: 55 */   private AbstractMobileControl launchingControl = null;
/*  30: 56 */   private boolean scrollableSection = true;
/*  31: 57 */   private ArrayList beanList = new ArrayList();
/*  32: 58 */   private ArrayList createdBeans = new ArrayList();
/*  33: 59 */   private AbstractMobileControl currentInput = null;
/*  34: 60 */   protected boolean autoSave = true;
/*  35: 61 */   private boolean toBeRemoved = false;
/*  36: 62 */   private AbstractMobileControl shownToolBar = null;
/*  37: 63 */   private AbstractMobileControl useToolBar = null;
/*  38: 64 */   private AbstractMobileControl shownMenuBar = null;
/*  39: 65 */   private AbstractMobileControl useMenuBar = null;
/*  40: 66 */   private AbstractMobileControl scanTable = null;
/*  41:    */   
/*  42:    */   public AbstractMobileControl createControl(ControlData controlData)
/*  43:    */     throws MobileApplicationException
/*  44:    */   {
/*  45: 73 */     return new PageControl();
/*  46:    */   }
/*  47:    */   
/*  48:    */   protected PageWidget getPageWidget()
/*  49:    */   {
/*  50: 80 */     return (PageWidget)super.getWidget();
/*  51:    */   }
/*  52:    */   
/*  53:    */   public UIComponent[] composeComponents()
/*  54:    */     throws MobileApplicationException
/*  55:    */   {
/*  56: 85 */     if (isAttributeSet("autosave")) {
/*  57: 87 */       this.autoSave = getBooleanValue("autosave");
/*  58:    */     }
/*  59: 89 */     inheritControlAttribute("titleinappbar");
/*  60: 90 */     addToolbar(inheritControlAttribute("toolbar"));
/*  61:    */     
/*  62:    */ 
/*  63: 93 */     UIComponent container = getPageWidget().createPagePanel();
/*  64: 94 */     getPageWidget().setOpaque(true);
/*  65:    */     
/*  66: 96 */     getPageWidget().setId(getId());
/*  67:    */     
/*  68: 98 */     String backgroundImageName = getStringValue("backgroundimage");
/*  69:    */     
/*  70:100 */     getPageWidget().setBackgroundColor(backgroundImageName);
/*  71:    */     
/*  72:102 */     composeChildren();
/*  73:    */     
/*  74:104 */     getPageWidget().setDefaultPageLayout();
/*  75:    */     
/*  76:106 */     AbstractMobileControl toolBar = getToolBar();
/*  77:107 */     this.shownToolBar = toolBar;
/*  78:108 */     if (toolBar != null)
/*  79:    */     {
/*  80:110 */       UIComponent[] comp = toolBar.getComponents();
/*  81:111 */       if (comp != null) {
/*  82:113 */         getPageWidget().addToolbarComponents(comp);
/*  83:    */       }
/*  84:    */     }
/*  85:117 */     if (this.scrollableSection)
/*  86:    */     {
/*  87:119 */       getPageWidget().createCenterPanel();
/*  88:    */       
/*  89:121 */       getPageWidget().setDefaultCenterLayout();
/*  90:    */       
/*  91:123 */       boolean centerSet = false;
/*  92:124 */       ArrayList south = null;
/*  93:125 */       Iterator i = getChildren();
/*  94:126 */       if (i != null)
/*  95:    */       {
/*  96:128 */         while (i.hasNext())
/*  97:    */         {
/*  98:130 */           AbstractMobileControl control = (AbstractMobileControl)i.next();
/*  99:131 */           if (!(control instanceof MenuBarControl)) {
/* 100:135 */             if (!centerSet)
/* 101:    */             {
/* 102:137 */               UIComponent[] components = control.getComponents();
/* 103:138 */               if (components != null)
/* 104:    */               {
/* 105:140 */                 centerSet = true;
/* 106:141 */                 getPageWidget().addChildComponentsToCenterPanel(components);
/* 107:    */               }
/* 108:    */             }
/* 109:    */             else
/* 110:    */             {
/* 111:147 */               if (south == null) {
/* 112:148 */                 south = new ArrayList();
/* 113:    */               }
/* 114:149 */               south.add(control);
/* 115:    */             }
/* 116:    */           }
/* 117:    */         }
/* 118:153 */         getPageWidget().addCenterPanelToPagePanel();
/* 119:155 */         if (south != null)
/* 120:    */         {
/* 121:158 */           getPageWidget().addControlsToSouthPanel(south);
/* 122:    */           
/* 123:160 */           getPageWidget().setSouthPanelTopBorders();
/* 124:    */           
/* 125:162 */           getPageWidget().addSouthPanelToCenterPanel();
/* 126:    */         }
/* 127:    */       }
/* 128:    */     }
/* 129:    */     else
/* 130:    */     {
/* 131:170 */       getPageWidget().addPanelToPagePanel(getPageWidget().addControlsToPanel(this.childControls));
/* 132:    */     }
/* 133:173 */     addMenubar(inheritControlAttribute("menubar"));
/* 134:174 */     this.components = new UIComponent[1];
/* 135:175 */     this.components[0] = container;
/* 136:176 */     return this.components;
/* 137:    */   }
/* 138:    */   
/* 139:    */   protected boolean performEvent(UIEvent event)
/* 140:    */     throws MobileApplicationException
/* 141:    */   {
/* 142:184 */     String eventType = event.getEventName();
/* 143:185 */     if (eventType.equals("nextrec")) {
/* 144:187 */       return nextrec(event);
/* 145:    */     }
/* 146:189 */     if (eventType.equals("prevrec")) {
/* 147:191 */       return prevrec(event);
/* 148:    */     }
/* 149:193 */     if (eventType.equals("togglenextrec")) {
/* 150:195 */       return togglenextrec(event);
/* 151:    */     }
/* 152:197 */     if (eventType.equals("toggleprevrec")) {
/* 153:199 */       return toggleprevrec(event);
/* 154:    */     }
/* 155:201 */     if (eventType.equals("insert")) {
/* 156:203 */       return insert(event);
/* 157:    */     }
/* 158:205 */     if ((eventType.equalsIgnoreCase("moveUp")) || (eventType.equalsIgnoreCase("moveDown")) || (eventType.equalsIgnoreCase("moveLeft")) || (eventType.equalsIgnoreCase("moveRight"))) {
/* 159:210 */       return getPageWidget().move(eventType);
/* 160:    */     }
/* 161:212 */     if (event.getEventName().equalsIgnoreCase("barcoderead")) {
/* 162:214 */       return barcoderead(event);
/* 163:    */     }
/* 164:216 */     if (eventType.equals("isluconnected")) {
/* 165:221 */       return isluconnected(event);
/* 166:    */     }
/* 167:223 */     return false;
/* 168:    */   }
/* 169:    */   
/* 170:    */   public MobileMboDataBean getGroupOrPageBean()
/* 171:    */     throws MobileApplicationException
/* 172:    */   {
/* 173:234 */     MobileMboDataBean dataBean = null;
/* 174:235 */     if (getParentControl() != null)
/* 175:    */     {
/* 176:237 */       dataBean = getParentControl().getDataBean();
/* 177:238 */       if (dataBean == null) {
/* 178:239 */         dataBean = getDataBean();
/* 179:    */       }
/* 180:    */     }
/* 181:    */     else
/* 182:    */     {
/* 183:242 */       dataBean = getDataBean();
/* 184:    */     }
/* 185:243 */     return dataBean;
/* 186:    */   }
/* 187:    */   
/* 188:    */   public boolean nextrec(UIEvent event)
/* 189:    */     throws MobileApplicationException
/* 190:    */   {
/* 191:248 */     MobileMboDataBean dataBean = null;
/* 192:249 */     AbstractMobileControl stButton = ((AbstractMobileControl)event.getCreatingObject()).getParentControl();
/* 193:250 */     String dataSrc = stButton.getValue("datasrcname");
/* 194:251 */     if (dataSrc != null) {
/* 195:253 */       dataBean = stButton.getDataBean();
/* 196:    */     }
/* 197:255 */     if (dataBean == null) {
/* 198:257 */       dataBean = getGroupOrPageBean();
/* 199:    */     }
/* 200:259 */     if (dataBean != null) {
/* 201:261 */       if (sendSaveEvent())
/* 202:    */       {
/* 203:263 */         if (!dataBean.setCurrentPosition(dataBean.getCurrentPosition() + 1)) {
/* 204:265 */           UIUtil.showInfoMessageBox(MobileMessageGenerator.generate("lastrec", null));
/* 205:    */         } else {
/* 206:269 */           clearBeanCache();
/* 207:    */         }
/* 208:271 */         UIUtil.refreshCurrentScreen();
/* 209:    */       }
/* 210:    */     }
/* 211:274 */     return true;
/* 212:    */   }
/* 213:    */   
/* 214:    */   public boolean prevrec(UIEvent event)
/* 215:    */     throws MobileApplicationException
/* 216:    */   {
/* 217:279 */     MobileMboDataBean dataBean = null;
/* 218:280 */     AbstractMobileControl stButton = ((AbstractMobileControl)event.getCreatingObject()).getParentControl();
/* 219:281 */     String dataSrc = stButton.getValue("datasrcname");
/* 220:282 */     if (dataSrc != null) {
/* 221:284 */       dataBean = stButton.getDataBean();
/* 222:    */     }
/* 223:286 */     if (dataBean == null) {
/* 224:288 */       dataBean = getGroupOrPageBean();
/* 225:    */     }
/* 226:290 */     if (dataBean != null) {
/* 227:292 */       if (sendSaveEvent())
/* 228:    */       {
/* 229:294 */         int row = dataBean.getCurrentPosition();
/* 230:295 */         if ((row == 0) || (!dataBean.setCurrentPosition(row - 1))) {
/* 231:297 */           UIUtil.showInfoMessageBox(MobileMessageGenerator.generate("firstrec", null));
/* 232:    */         } else {
/* 233:301 */           clearBeanCache();
/* 234:    */         }
/* 235:303 */         UIUtil.refreshCurrentScreen();
/* 236:    */       }
/* 237:    */     }
/* 238:306 */     return true;
/* 239:    */   }
/* 240:    */   
/* 241:    */   public boolean togglenextrec(UIEvent event)
/* 242:    */     throws MobileApplicationException
/* 243:    */   {
/* 244:311 */     MobileMboDataBean dataBean = null;
/* 245:312 */     AbstractMobileControl stButton = (AbstractMobileControl)event.getCreatingObject();
/* 246:313 */     String dataSrc = stButton.getValue("datasrcname");
/* 247:314 */     if (dataSrc != null) {
/* 248:316 */       dataBean = stButton.getDataBean();
/* 249:    */     }
/* 250:318 */     if (dataBean == null) {
/* 251:320 */       dataBean = getGroupOrPageBean();
/* 252:    */     }
/* 253:322 */     if (dataBean != null)
/* 254:    */     {
/* 255:324 */       StateControl state = (StateControl)event.getCreatingObject();
/* 256:325 */       if (dataBean.getMobileMbo(dataBean.getCurrentPosition() + 1) == null) {
/* 257:326 */         state.setStateViaState("off");
/* 258:    */       } else {
/* 259:328 */         state.setStateViaState("on");
/* 260:    */       }
/* 261:    */     }
/* 262:330 */     return true;
/* 263:    */   }
/* 264:    */   
/* 265:    */   public boolean toggleprevrec(UIEvent event)
/* 266:    */     throws MobileApplicationException
/* 267:    */   {
/* 268:335 */     MobileMboDataBean dataBean = null;
/* 269:336 */     AbstractMobileControl stButton = (AbstractMobileControl)event.getCreatingObject();
/* 270:337 */     String dataSrc = stButton.getValue("datasrcname");
/* 271:338 */     if (dataSrc != null) {
/* 272:340 */       dataBean = stButton.getDataBean();
/* 273:    */     }
/* 274:342 */     if (dataBean == null) {
/* 275:344 */       dataBean = getGroupOrPageBean();
/* 276:    */     }
/* 277:346 */     if (dataBean != null)
/* 278:    */     {
/* 279:348 */       StateControl state = (StateControl)event.getCreatingObject();
/* 280:349 */       if (dataBean.getCurrentPosition() < 1) {
/* 281:350 */         state.setStateViaState("off");
/* 282:    */       } else {
/* 283:352 */         state.setStateViaState("on");
/* 284:    */       }
/* 285:    */     }
/* 286:354 */     return true;
/* 287:    */   }
/* 288:    */   
/* 289:    */   public boolean insert(UIEvent event)
/* 290:    */     throws MobileApplicationException
/* 291:    */   {
/* 292:359 */     MobileMboDataBean dataBean = getGroupOrPageBean();
/* 293:360 */     if ((dataBean != null) && (sendSaveEvent()))
/* 294:    */     {
/* 295:362 */       dataBean.insert();
/* 296:363 */       UIUtil.refreshCurrentScreen();
/* 297:    */     }
/* 298:365 */     return true;
/* 299:    */   }
/* 300:    */   
/* 301:    */   protected boolean handleException(UIEvent event, Exception exception)
/* 302:    */   {
/* 303:373 */     return false;
/* 304:    */   }
/* 305:    */   
/* 306:    */   public void refresh(UIEvent clientEvent)
/* 307:    */     throws MobileApplicationException
/* 308:    */   {
/* 309:380 */     if (this.scanTable != null) {
/* 310:381 */       ((TableControl)this.scanTable).removeLastScan(true);
/* 311:    */     }
/* 312:382 */     sendRefreshEvent();
/* 313:383 */     super.refresh(clientEvent);
/* 314:386 */     if (UIUtil.getCurrentScreen().equals(this)) {
/* 315:388 */       refreshMenuBar();
/* 316:    */     }
/* 317:390 */     refreshToolBar(clientEvent);
/* 318:391 */     setPageFocus();
/* 319:    */   }
/* 320:    */   
/* 321:    */   protected void refreshToolBar(UIEvent event)
/* 322:    */     throws MobileApplicationException
/* 323:    */   {
/* 324:396 */     AbstractMobileControl toolBar = getToolBar();
/* 325:397 */     if (toolBar != null) {
/* 326:398 */       toolBar.refresh(event);
/* 327:    */     }
/* 328:399 */     if (toolBar != this.shownToolBar)
/* 329:    */     {
/* 330:401 */       if (this.shownToolBar != null)
/* 331:    */       {
/* 332:403 */         UIComponent[] comps = this.shownToolBar.getComponents();
/* 333:404 */         if (comps != null) {
/* 334:406 */           getPageWidget().removeFromToolBarContainer(comps[0]);
/* 335:    */         }
/* 336:    */       }
/* 337:409 */       if (toolBar != null)
/* 338:    */       {
/* 339:411 */         UIComponent[] comps = toolBar.getComponents();
/* 340:412 */         if (comps != null) {
/* 341:414 */           getPageWidget().addToolBarToContainer(comps[0]);
/* 342:    */         }
/* 343:    */       }
/* 344:417 */       this.shownToolBar = toolBar;
/* 345:    */     }
/* 346:    */   }
/* 347:    */   
/* 348:    */   protected void refreshMenuBar()
/* 349:    */     throws MobileApplicationException
/* 350:    */   {
/* 351:423 */     AbstractMobileControl mb = getMenuBar();
/* 352:424 */     if (mb != this.shownMenuBar)
/* 353:    */     {
/* 354:426 */       if (mb == null)
/* 355:    */       {
/* 356:428 */         this.app.removeMenuBar();
/* 357:429 */         return;
/* 358:    */       }
/* 359:432 */       this.shownMenuBar = mb;
/* 360:    */     }
/* 361:434 */     if (this.shownMenuBar != null) {
/* 362:436 */       this.shownMenuBar.refresh(null);
/* 363:    */     }
/* 364:    */   }
/* 365:    */   
/* 366:    */   protected boolean refreshControl(UIEvent event)
/* 367:    */     throws MobileApplicationException
/* 368:    */   {
/* 369:445 */     this.scanTable = null;
/* 370:447 */     if ((!this.toBeRemoved) && (getComponents() != null) && (this.app.getCurrentScreen() == this))
/* 371:    */     {
/* 372:449 */       String menuBar = getStringValue("menubar");
/* 373:450 */       if (menuBar == null) {
/* 374:452 */         this.app.removeMenuBar();
/* 375:    */       }
/* 376:454 */       if (getBooleanValue("titleinappbar")) {
/* 377:455 */         this.app.setTitle(getTitle());
/* 378:    */       }
/* 379:456 */       return true;
/* 380:    */     }
/* 381:459 */     return false;
/* 382:    */   }
/* 383:    */   
/* 384:    */   protected boolean forceRefreshControl(UIEvent event)
/* 385:    */     throws MobileApplicationException
/* 386:    */   {
/* 387:466 */     this.scanTable = null;
/* 388:468 */     if ((!this.toBeRemoved) && (getComponents() != null))
/* 389:    */     {
/* 390:470 */       String menuBar = getStringValue("menubar");
/* 391:471 */       if (menuBar == null) {
/* 392:473 */         this.app.removeMenuBar();
/* 393:    */       }
/* 394:475 */       return true;
/* 395:    */     }
/* 396:478 */     return false;
/* 397:    */   }
/* 398:    */   
/* 399:    */   public String getTitle()
/* 400:    */     throws MobileApplicationException
/* 401:    */   {
/* 402:483 */     String title = getStringValue("title");
/* 403:484 */     if (title == null)
/* 404:    */     {
/* 405:486 */       if (this.parentControl != null) {
/* 406:488 */         title = this.parentControl.getTitle();
/* 407:    */       }
/* 408:490 */       if (title == null) {
/* 409:491 */         title = getLabel();
/* 410:    */       }
/* 411:    */     }
/* 412:    */     else
/* 413:    */     {
/* 414:495 */       title = generateLabel(title, getStringValue("titleattribute"), getStringValue("titledatasrc"));
/* 415:    */     }
/* 416:497 */     return title;
/* 417:    */   }
/* 418:    */   
/* 419:    */   protected boolean init()
/* 420:    */   {
/* 421:506 */     return true;
/* 422:    */   }
/* 423:    */   
/* 424:    */   protected void registerControl(AbstractMobileControl control)
/* 425:    */   {
/* 426:511 */     this.controlList.put(control.getId(), control);
/* 427:    */   }
/* 428:    */   
/* 429:    */   public AbstractMobileControl findChild(String ctrlId)
/* 430:    */   {
/* 431:516 */     return (AbstractMobileControl)this.controlList.get(ctrlId);
/* 432:    */   }
/* 433:    */   
/* 434:    */   protected ArrayList createChildren()
/* 435:    */     throws MobileApplicationException
/* 436:    */   {
/* 437:521 */     super.createChildren();
/* 438:522 */     return this.childControls;
/* 439:    */   }
/* 440:    */   
/* 441:    */   public AbstractMobileControl getLaunchingControl()
/* 442:    */   {
/* 443:531 */     return this.launchingControl;
/* 444:    */   }
/* 445:    */   
/* 446:    */   public void setLaunchingControl(AbstractMobileControl launchingControl)
/* 447:    */   {
/* 448:538 */     this.launchingControl = launchingControl;
/* 449:539 */     if (launchingControl != null)
/* 450:    */     {
/* 451:541 */       String dataSrc = null;
/* 452:544 */       if (getId().equalsIgnoreCase("longdesc"))
/* 453:    */       {
/* 454:546 */         dataSrc = launchingControl.inheritControlAttribute("datasrcname");
/* 455:547 */         if (dataSrc != null)
/* 456:    */         {
/* 457:549 */           this.controlAttributes.putValue("datasrcname", dataSrc);
/* 458:550 */           registerBean(dataSrc, false);
/* 459:    */         }
/* 460:552 */         return;
/* 461:    */       }
/* 462:554 */       dataSrc = inheritControlAttribute("datasrcname");
/* 463:557 */       if (dataSrc == null)
/* 464:    */       {
/* 465:559 */         dataSrc = launchingControl.inheritControlAttribute("datasrcname");
/* 466:560 */         if (dataSrc != null)
/* 467:    */         {
/* 468:562 */           this.controlAttributes.putValue("datasrcname", dataSrc);
/* 469:563 */           registerBean(dataSrc, false);
/* 470:    */         }
/* 471:    */       }
/* 472:    */     }
/* 473:    */   }
/* 474:    */   
/* 475:    */   public void setEnabled(boolean b)
/* 476:    */   {
/* 477:575 */     getPageWidget().setEnabled(b);
/* 478:    */   }
/* 479:    */   
/* 480:    */   public void setMenuBar(AbstractMobileControl menuBar)
/* 481:    */   {
/* 482:580 */     this.useMenuBar = menuBar;
/* 483:    */   }
/* 484:    */   
/* 485:    */   public AbstractMobileControl getMenuBar()
/* 486:    */   {
/* 487:585 */     if (this.useMenuBar != null) {
/* 488:586 */       return this.useMenuBar;
/* 489:    */     }
/* 490:587 */     if (this.menuBar != null) {
/* 491:588 */       return this.menuBar;
/* 492:    */     }
/* 493:590 */     return null;
/* 494:    */   }
/* 495:    */   
/* 496:    */   public AbstractMobileControl getToolBar()
/* 497:    */   {
/* 498:597 */     if (this.useToolBar != null) {
/* 499:598 */       return this.useToolBar;
/* 500:    */     }
/* 501:599 */     if (this.parentControl != null) {
/* 502:600 */       return this.parentControl.getToolBar();
/* 503:    */     }
/* 504:601 */     return null;
/* 505:    */   }
/* 506:    */   
/* 507:    */   public void setToolBar(AbstractMobileControl toolBar)
/* 508:    */   {
/* 509:609 */     if ((toolBar == null) && (this.myToolBar != null)) {
/* 510:610 */       this.useToolBar = this.myToolBar;
/* 511:    */     } else {
/* 512:612 */       this.useToolBar = toolBar;
/* 513:    */     }
/* 514:    */   }
/* 515:    */   
/* 516:    */   public void setScrollableSection(boolean scrollableSection)
/* 517:    */   {
/* 518:620 */     this.scrollableSection = scrollableSection;
/* 519:    */   }
/* 520:    */   
/* 521:    */   public ArrayList getPageBeans()
/* 522:    */   {
/* 523:625 */     return this.beanList;
/* 524:    */   }
/* 525:    */   
/* 526:    */   public void registerBean(String bean, boolean created)
/* 527:    */   {
/* 528:630 */     if (bean != null)
/* 529:    */     {
/* 530:632 */       if (!this.beanList.contains(bean)) {
/* 531:633 */         this.beanList.add(bean);
/* 532:    */       }
/* 533:634 */       if ((created) && (!this.createdBeans.contains(bean))) {
/* 534:635 */         this.createdBeans.add(bean);
/* 535:    */       }
/* 536:    */     }
/* 537:    */   }
/* 538:    */   
/* 539:    */   public void clearBeanCache()
/* 540:    */   {
/* 541:641 */     Iterator i = this.createdBeans.iterator();
/* 542:642 */     while (i.hasNext())
/* 543:    */     {
/* 544:644 */       String beanid = (String)i.next();
/* 545:645 */       if (beanid != null) {
/* 546:647 */         DataBeanCache.removeDataBean(beanid);
/* 547:    */       }
/* 548:    */     }
/* 549:652 */     List childPages = findChildPages();
/* 550:653 */     i = childPages.iterator();
/* 551:654 */     while (i.hasNext()) {
/* 552:656 */       ((PageControl)i.next()).clearBeanCache();
/* 553:    */     }
/* 554:    */   }
/* 555:    */   
/* 556:    */   private List findChildPages()
/* 557:    */   {
/* 558:664 */     List childPages = new ArrayList();
/* 559:665 */     Iterator i = this.controlList.values().iterator();
/* 560:666 */     while (i.hasNext())
/* 561:    */     {
/* 562:668 */       AbstractMobileControl child = (AbstractMobileControl)i.next();
/* 563:669 */       if ((child instanceof PageControl)) {
/* 564:671 */         childPages.add((PageControl)child);
/* 565:    */       }
/* 566:    */     }
/* 567:674 */     return childPages;
/* 568:    */   }
/* 569:    */   
/* 570:    */   public boolean usesBean(String bean)
/* 571:    */   {
/* 572:679 */     if (this.beanList == null) {
/* 573:681 */       return false;
/* 574:    */     }
/* 575:683 */     return this.beanList.contains(bean);
/* 576:    */   }
/* 577:    */   
/* 578:    */   public boolean savePage(UIEvent event)
/* 579:    */     throws MobileApplicationException
/* 580:    */   {
/* 581:693 */     MobileMboDataBean dataBean = getGroupOrPageBean();
/* 582:694 */     if (dataBean != null) {
/* 583:696 */       if (dataBean.getMobileMbo() != null) {
/* 584:698 */         if (validateControl())
/* 585:    */         {
/* 586:700 */           if (dataBean.isToBeSaved())
/* 587:    */           {
/* 588:703 */             String sigoption = getStringValue("sigoption");
/* 589:704 */             boolean ignoreEsig = getBooleanValue("noesig");
/* 590:705 */             if (dataBean.getMobileMbo().isToBeInserted())
/* 591:    */             {
/* 592:707 */               String insertSigOption = getStringValue("insertesigoption");
/* 593:708 */               if (insertSigOption != null)
/* 594:    */               {
/* 595:710 */                 ignoreEsig = false;
/* 596:711 */                 sigoption = sigoption + "," + insertSigOption;
/* 597:    */               }
/* 598:    */             }
/* 599:715 */             boolean canSave = true;
/* 600:717 */             if ("SAVE".equalsIgnoreCase(sigoption)) {
/* 601:720 */               canSave = UIUtil.checkESignatureWithSave(UIUtil.getApplication().getUserEvent(), dataBean, sigoption);
/* 602:722 */             } else if (ignoreEsig)
/* 603:    */             {
/* 604:725 */               if (sigoption.indexOf("SAVE") >= 0) {
/* 605:728 */                 canSave = UIUtil.checkESignatureWithSave(UIUtil.getApplication().getUserEvent(), dataBean, "SAVE");
/* 606:    */               }
/* 607:    */             }
/* 608:    */             else {
/* 609:733 */               canSave = UIUtil.checkESignatureWithSave(UIUtil.getApplication().getUserEvent(), dataBean, sigoption);
/* 610:    */             }
/* 611:736 */             if (canSave)
/* 612:    */             {
/* 613:737 */               dataBean.getDataBeanManager().save();
/* 614:    */             }
/* 615:    */             else
/* 616:    */             {
/* 617:740 */               event.setEventErrored();
/* 618:741 */               return false;
/* 619:    */             }
/* 620:    */           }
/* 621:    */           else
/* 622:    */           {
/* 623:746 */             return false;
/* 624:    */           }
/* 625:    */         }
/* 626:    */         else
/* 627:    */         {
/* 628:751 */           event.setEventErrored();
/* 629:752 */           return false;
/* 630:    */         }
/* 631:    */       }
/* 632:    */     }
/* 633:757 */     return true;
/* 634:    */   }
/* 635:    */   
/* 636:    */   public boolean sendSaveEvent()
/* 637:    */     throws MobileApplicationException
/* 638:    */   {
/* 639:768 */     if (this.autoSave)
/* 640:    */     {
/* 641:770 */       UIEvent event = new UIEvent(this, "save", null, "norefresh");
/* 642:771 */       handleEvent(event);
/* 643:772 */       return !event.errorOccured();
/* 644:    */     }
/* 645:778 */     return validateControl();
/* 646:    */   }
/* 647:    */   
/* 648:    */   public AbstractMobileControl getCurrentInput()
/* 649:    */   {
/* 650:788 */     return this.currentInput;
/* 651:    */   }
/* 652:    */   
/* 653:    */   public void setCurrentInput(AbstractMobileControl currentInput)
/* 654:    */   {
/* 655:795 */     this.currentInput = currentInput;
/* 656:    */   }
/* 657:    */   
/* 658:    */   public void setPageFocus()
/* 659:    */   {
/* 660:800 */     if ((this.currentInput != null) && ((this.currentInput instanceof FocusableControl))) {
/* 661:802 */       ((FocusableControl)this.currentInput).setFocus();
/* 662:    */     } else {
/* 663:806 */       getPageWidget().setPageFocus(this);
/* 664:    */     }
/* 665:    */   }
/* 666:    */   
/* 667:    */   public boolean validateControl(UIEvent event, Object value)
/* 668:    */   {
/* 669:815 */     boolean validate = false;
/* 670:816 */     if (super.validateControl(event, value)) {
/* 671:818 */       validate = checkRequiredFields();
/* 672:    */     }
/* 673:821 */     if (!validate) {
/* 674:822 */       setToBeRemoved(false);
/* 675:    */     }
/* 676:824 */     return validate;
/* 677:    */   }
/* 678:    */   
/* 679:    */   public void setToBeRemoved(boolean toBeRemoved)
/* 680:    */   {
/* 681:832 */     this.toBeRemoved = toBeRemoved;
/* 682:    */   }
/* 683:    */   
/* 684:    */   public void setParentControl(AbstractMobileControl parentControl)
/* 685:    */   {
/* 686:841 */     super.setParentControl(parentControl);
/* 687:842 */     if (parentControl != null)
/* 688:    */     {
/* 689:844 */       String dataSrc = parentControl.getStringValue("datasrcname");
/* 690:845 */       if (dataSrc != null) {
/* 691:846 */         registerBean(dataSrc, false);
/* 692:    */       }
/* 693:    */     }
/* 694:    */   }
/* 695:    */   
/* 696:    */   public AbstractMobileControl getPage()
/* 697:    */   {
/* 698:852 */     return this;
/* 699:    */   }
/* 700:    */   
/* 701:    */   public void showMenuBar()
/* 702:    */   {
/* 703:857 */     this.shownMenuBar = getMenuBar();
/* 704:858 */     if (this.shownMenuBar != null) {
/* 705:860 */       ((MenuBarControl)this.shownMenuBar).showMenuBar();
/* 706:    */     } else {
/* 707:864 */       this.app.removeMenuBar();
/* 708:    */     }
/* 709:    */   }
/* 710:    */   
/* 711:    */   private void removeController(UIComponent component)
/* 712:    */   {
/* 713:871 */     component.setController(null);
/* 714:872 */     Enumeration e = component.getChildren();
/* 715:873 */     if (e != null) {
/* 716:875 */       while (e.hasMoreElements()) {
/* 717:877 */         removeController((UIComponent)e.nextElement());
/* 718:    */       }
/* 719:    */     }
/* 720:    */   }
/* 721:    */   
/* 722:    */   public void clearComponents()
/* 723:    */   {
/* 724:884 */     if (this.components != null)
/* 725:    */     {
/* 726:886 */       for (int i = 0; i < this.components.length; i++)
/* 727:    */       {
/* 728:888 */         UIComponent component = this.components[i];
/* 729:889 */         removeController(component);
/* 730:    */       }
/* 731:891 */       this.components = null;
/* 732:    */     }
/* 733:    */   }
/* 734:    */   
/* 735:    */   public void cleanup()
/* 736:    */   {
/* 737:898 */     clearComponents();
/* 738:900 */     if (this.container != null) {
/* 739:902 */       this.container.setController(null);
/* 740:    */     }
/* 741:904 */     this.controlList = new HashMap();
/* 742:905 */     this.container = null;
/* 743:906 */     this.launchingControl = null;
/* 744:907 */     this.beanList = new ArrayList();
/* 745:908 */     this.createdBeans = null;
/* 746:909 */     this.currentInput = null;
/* 747:910 */     this.shownToolBar = null;
/* 748:911 */     this.useToolBar = null;
/* 749:912 */     this.shownMenuBar = null;
/* 750:913 */     this.useMenuBar = null;
/* 751:    */     
/* 752:915 */     super.cleanup();
/* 753:    */   }
/* 754:    */   
/* 755:    */   public boolean barcoderead(UIEvent event)
/* 756:    */     throws MobileApplicationException
/* 757:    */   {
/* 758:921 */     if (this.scanTable != null) {
/* 759:922 */       return this.scanTable.processEvent(event);
/* 760:    */     }
/* 761:924 */     return getPageWidget().barcoderead(event);
/* 762:    */   }
/* 763:    */   
/* 764:    */   public AbstractMobileControl getScanTable()
/* 765:    */   {
/* 766:933 */     return this.scanTable;
/* 767:    */   }
/* 768:    */   
/* 769:    */   public void setScanTable(AbstractMobileControl scanTable)
/* 770:    */   {
/* 771:942 */     this.scanTable = scanTable;
/* 772:    */   }
/* 773:    */   
/* 774:    */   public boolean isluconnected(UIEvent event)
/* 775:    */     throws MobileApplicationException
/* 776:    */   {
/* 777:947 */     MobileMboDataBean dataBean = getDataBean();
/* 778:949 */     if (getToolBar() != null)
/* 779:    */     {
/* 780:950 */       AbstractMobileControl embeddedControl = getToolBar().getParentControl();
/* 781:951 */       if (embeddedControl != null) {
/* 782:953 */         dataBean = embeddedControl.getDataBean();
/* 783:    */       }
/* 784:    */     }
/* 785:956 */     if (dataBean != null)
/* 786:    */     {
/* 787:958 */       StateControl state = (StateControl)event.getCreatingObject();
/* 788:959 */       if (dataBean.isOnline()) {
/* 789:960 */         state.setStateViaState("connected");
/* 790:    */       } else {
/* 791:962 */         state.setStateViaState("disconnected");
/* 792:    */       }
/* 793:    */     }
/* 794:964 */     return true;
/* 795:    */   }
/* 796:    */   
/* 797:967 */   private static WidgetCreator widgetCreator = null;
/* 798:    */   
/* 799:    */   public static void registerWidgetCreator(WidgetCreator wc)
/* 800:    */   {
/* 801:970 */     widgetCreator = wc;
/* 802:    */   }
/* 803:    */   
/* 804:    */   protected AbstractWidget createWidget()
/* 805:    */   {
/* 806:974 */     return widgetCreator.createWidget();
/* 807:    */   }
/* 808:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.controls.PageControl
 * JD-Core Version:    0.7.0.1
 */