/*   1:    */ package com.mro.mobile.ui.res.controls.utils;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.ui.res.MobileUIProperties;
/*   4:    */ import java.util.HashMap;
/*   5:    */ import java.util.Map;
/*   6:    */ 
/*   7:    */ public class ControlStyle
/*   8:    */ {
/*   9: 26 */   private HashMap settings = null;
/*  10: 27 */   private Object font = null;
/*  11:    */   private String name;
/*  12: 29 */   private static FontCreator fontCreator = null;
/*  13:    */   
/*  14:    */   public ControlStyle(String name)
/*  15:    */   {
/*  16: 33 */     this(name, new HashMap());
/*  17:    */   }
/*  18:    */   
/*  19:    */   public String getStyleName()
/*  20:    */   {
/*  21: 37 */     return this.name;
/*  22:    */   }
/*  23:    */   
/*  24:    */   public ControlStyle(String name, Map settings)
/*  25:    */   {
/*  26: 41 */     this.settings = new HashMap();
/*  27: 42 */     this.settings.putAll(settings);
/*  28: 43 */     this.name = name;
/*  29:    */   }
/*  30:    */   
/*  31:    */   public void setSettings(Map settings)
/*  32:    */   {
/*  33: 47 */     this.settings.putAll(settings);
/*  34:    */   }
/*  35:    */   
/*  36:    */   public Object getFont()
/*  37:    */   {
/*  38: 51 */     if (this.font == null) {
/*  39:    */       try
/*  40:    */       {
/*  41: 53 */         this.font = fontCreator.createFont(this.settings);
/*  42:    */       }
/*  43:    */       catch (Throwable t)
/*  44:    */       {
/*  45: 55 */         this.font = StyleManager.getDefaultFont();
/*  46:    */       }
/*  47:    */     }
/*  48: 58 */     return this.font;
/*  49:    */   }
/*  50:    */   
/*  51:    */   public Object getSetting(String setting)
/*  52:    */   {
/*  53: 62 */     if (this.settings != null) {
/*  54: 63 */       return this.settings.get(setting);
/*  55:    */     }
/*  56: 65 */     return null;
/*  57:    */   }
/*  58:    */   
/*  59:    */   public Object getColor(String colorStr)
/*  60:    */   {
/*  61: 69 */     if (this.settings != null)
/*  62:    */     {
/*  63: 70 */       Object obj = this.settings.get(colorStr);
/*  64: 71 */       if (fontCreator.isAlreadyColor(obj)) {
/*  65: 72 */         return obj;
/*  66:    */       }
/*  67: 74 */       Object color = MobileUIProperties.createColor((String)obj);
/*  68: 75 */       if (color != null) {
/*  69: 76 */         this.settings.put(colorStr, color);
/*  70:    */       }
/*  71: 78 */       return color;
/*  72:    */     }
/*  73: 81 */     return null;
/*  74:    */   }
/*  75:    */   
/*  76:    */   public Object getBgColor()
/*  77:    */   {
/*  78: 85 */     return getColor("bgcolor");
/*  79:    */   }
/*  80:    */   
/*  81:    */   public Object getFgColor()
/*  82:    */   {
/*  83: 89 */     return getColor("fgcolor");
/*  84:    */   }
/*  85:    */   
/*  86:    */   public Object getBorderColor()
/*  87:    */   {
/*  88: 93 */     return getColor("border-color");
/*  89:    */   }
/*  90:    */   
/*  91:    */   public String getBackground()
/*  92:    */   {
/*  93: 97 */     if (this.settings != null) {
/*  94: 98 */       return (String)this.settings.get("background");
/*  95:    */     }
/*  96:100 */     return null;
/*  97:    */   }
/*  98:    */   
/*  99:    */   public int getBorder()
/* 100:    */   {
/* 101:104 */     if (this.settings != null) {
/* 102:    */       try
/* 103:    */       {
/* 104:106 */         return Integer.parseInt((String)this.settings.get("border"));
/* 105:    */       }
/* 106:    */       catch (Throwable t) {}
/* 107:    */     }
/* 108:113 */     return 0;
/* 109:    */   }
/* 110:    */   
/* 111:    */   public boolean isOpaque()
/* 112:    */   {
/* 113:117 */     if (this.settings != null)
/* 114:    */     {
/* 115:118 */       String opaque = (String)this.settings.get("opaque");
/* 116:119 */       return (opaque != null) && (opaque.equals("1"));
/* 117:    */     }
/* 118:122 */     return false;
/* 119:    */   }
/* 120:    */   
/* 121:    */   public boolean hasUnderline()
/* 122:    */   {
/* 123:126 */     if (this.settings != null)
/* 124:    */     {
/* 125:127 */       String underline = (String)this.settings.get("underline");
/* 126:128 */       return (underline != null) && (underline.equals("1"));
/* 127:    */     }
/* 128:131 */     return false;
/* 129:    */   }
/* 130:    */   
/* 131:    */   public static void registerFontCreator(FontCreator fc)
/* 132:    */   {
/* 133:135 */     fontCreator = fc;
/* 134:    */   }
/* 135:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.controls.utils.ControlStyle
 * JD-Core Version:    0.7.0.1
 */