/*   1:    */ package com.mro.mobile.ui.res.controls;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileMessageGenerator;
/*   4:    */ import com.mro.mobile.ui.MobileUIControlData;
/*   5:    */ import com.mro.mobile.ui.UIControlManager;
/*   6:    */ import com.mro.mobile.ui.event.UIEvent;
/*   7:    */ import com.mro.mobile.ui.res.ControlData;
/*   8:    */ import com.mro.mobile.ui.res.MobileUIProperties;
/*   9:    */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  10:    */ import java.util.Vector;
/*  11:    */ 
/*  12:    */ public class MessageBox
/*  13:    */ {
/*  14:    */   public static final int OK_BUTTON = 1;
/*  15:    */   public static final int CANCEL_BUTTON = 2;
/*  16:    */   public static final int YES_BUTTON = 4;
/*  17:    */   public static final int NO_BUTTON = 8;
/*  18:    */   public static final int CLOSE_BUTTON = 16;
/*  19:    */   public static final int OK_CANCEL = 3;
/*  20:    */   public static final int YES_NO = 12;
/*  21:    */   public static final int YES_NO_CANCEL = 14;
/*  22:    */   public static final String ICON_INFO = "info";
/*  23:    */   public static final String ICON_QUESTION = "question";
/*  24:    */   public static final String ICON_WARNING = "warning";
/*  25: 53 */   protected MobileUIControlData controlData = null;
/*  26: 54 */   protected UIEvent event = null;
/*  27: 55 */   protected String message = null;
/*  28: 56 */   protected String icon = "info";
/*  29: 57 */   protected int buttons = 1;
/*  30: 59 */   private MessageBoxAdapter adapter = null;
/*  31:    */   
/*  32:    */   public MessageBox() {}
/*  33:    */   
/*  34:    */   public MessageBox(String message, UIEvent event)
/*  35:    */   {
/*  36: 65 */     this(message, "info", 1, event);
/*  37:    */   }
/*  38:    */   
/*  39:    */   public MessageBox(String message, String icon, UIEvent event)
/*  40:    */   {
/*  41: 69 */     this(message, icon, 1, event);
/*  42:    */   }
/*  43:    */   
/*  44:    */   public MessageBox(String message, String icon, int buttons, UIEvent event)
/*  45:    */   {
/*  46: 73 */     this.message = message;
/*  47: 74 */     this.icon = icon;
/*  48: 75 */     this.buttons = buttons;
/*  49: 76 */     this.event = event;
/*  50:    */     
/*  51: 78 */     this.adapter = messageBoxAdapterFactory.create(this);
/*  52:    */   }
/*  53:    */   
/*  54:    */   public void setMessage(String message)
/*  55:    */   {
/*  56: 83 */     this.message = message;
/*  57:    */   }
/*  58:    */   
/*  59:    */   public String getMessage()
/*  60:    */   {
/*  61: 88 */     return this.message;
/*  62:    */   }
/*  63:    */   
/*  64:    */   public void setButttons(int buttons)
/*  65:    */   {
/*  66: 93 */     this.buttons = buttons;
/*  67:    */   }
/*  68:    */   
/*  69:    */   public void setIcon(String icon)
/*  70:    */   {
/*  71: 98 */     this.icon = icon;
/*  72:    */   }
/*  73:    */   
/*  74:    */   public void setControlData(String controlId)
/*  75:    */   {
/*  76:103 */     this.controlData = getControlData(controlId);
/*  77:104 */     if (this.controlData != null)
/*  78:    */     {
/*  79:106 */       String temp = this.controlData.getValue("message");
/*  80:107 */       if (temp != null) {
/*  81:108 */         this.message = temp;
/*  82:    */       }
/*  83:109 */       temp = this.controlData.getValue("icon");
/*  84:110 */       if (temp != null) {
/*  85:111 */         this.icon = temp;
/*  86:    */       }
/*  87:112 */       temp = this.controlData.getValue("buttons");
/*  88:113 */       if (temp != null) {
/*  89:114 */         this.buttons = Integer.parseInt(temp);
/*  90:    */       }
/*  91:    */     }
/*  92:    */   }
/*  93:    */   
/*  94:    */   public void setEvent(UIEvent event)
/*  95:    */   {
/*  96:120 */     this.event = event;
/*  97:    */   }
/*  98:    */   
/*  99:    */   public UIEvent getEvent()
/* 100:    */   {
/* 101:125 */     return this.event;
/* 102:    */   }
/* 103:    */   
/* 104:    */   private MobileUIControlData getControlData(String id)
/* 105:    */   {
/* 106:130 */     UIControlManager controlManager = UIControlManager.getInstance();
/* 107:131 */     return (MobileUIControlData)controlManager.getControlData(id);
/* 108:    */   }
/* 109:    */   
/* 110:    */   protected UIComponent createButton(int buttonType, String label, boolean setmsgresponse)
/* 111:    */   {
/* 112:136 */     String value = null;
/* 113:137 */     switch (buttonType)
/* 114:    */     {
/* 115:    */     case 1: 
/* 116:141 */       if (label == null) {
/* 117:142 */         label = MobileMessageGenerator.generate("MSG_BTNOK", null);
/* 118:    */       }
/* 119:143 */       value = "1";
/* 120:144 */       break;
/* 121:    */     case 2: 
/* 122:148 */       if (label == null) {
/* 123:149 */         label = MobileMessageGenerator.generate("MSG_BTNCANCEL", null);
/* 124:    */       }
/* 125:150 */       value = "2";
/* 126:151 */       break;
/* 127:    */     case 4: 
/* 128:155 */       if (label == null) {
/* 129:156 */         label = MobileMessageGenerator.generate("MSG_BTNYES", null);
/* 130:    */       }
/* 131:157 */       value = "1";
/* 132:158 */       break;
/* 133:    */     case 8: 
/* 134:162 */       if (label == null) {
/* 135:163 */         label = MobileMessageGenerator.generate("MSG_BTNNO", null);
/* 136:    */       }
/* 137:164 */       value = "0";
/* 138:165 */       break;
/* 139:    */     case 16: 
/* 140:169 */       if (label == null) {
/* 141:170 */         label = MobileMessageGenerator.generate("MSG_BTNCLOSE", null);
/* 142:    */       }
/* 143:171 */       value = "1";
/* 144:    */     }
/* 145:176 */     return this.adapter.createLinkImageAndAddListener(label, setmsgresponse, value);
/* 146:    */   }
/* 147:    */   
/* 148:    */   public Vector createButtons()
/* 149:    */   {
/* 150:181 */     Vector btns = new Vector();
/* 151:182 */     if (this.controlData != null)
/* 152:    */     {
/* 153:184 */       ControlData[] buttonData = this.controlData.getChildControlData();
/* 154:185 */       if (buttonData != null) {
/* 155:187 */         for (int i = 0; i < buttonData.length; i++)
/* 156:    */         {
/* 157:189 */           String controlType = buttonData[i].getName();
/* 158:190 */           String label = buttonData[i].getValue("label");
/* 159:191 */           String s = buttonData[i].getValue("seteventresponse");
/* 160:192 */           boolean setmsgresponse = s == null ? true : Boolean.valueOf(s).booleanValue();
/* 161:194 */           if (controlType.equals("msgboxok"))
/* 162:    */           {
/* 163:196 */             btns.add(createButton(1, label, setmsgresponse));
/* 164:    */           }
/* 165:198 */           else if (controlType.equals("msgboxcancel"))
/* 166:    */           {
/* 167:200 */             btns.add(createButton(2, label, setmsgresponse));
/* 168:    */           }
/* 169:202 */           else if (controlType.equals("msgboxyes"))
/* 170:    */           {
/* 171:204 */             btns.add(createButton(4, label, setmsgresponse));
/* 172:    */           }
/* 173:206 */           else if (controlType.equals("msgboxno"))
/* 174:    */           {
/* 175:208 */             btns.add(createButton(8, label, setmsgresponse));
/* 176:    */           }
/* 177:210 */           else if (controlType.equals("msgboxclose"))
/* 178:    */           {
/* 179:212 */             btns.add(createButton(16, label, setmsgresponse));
/* 180:    */           }
/* 181:214 */           else if (controlType.equals("msgboxlink"))
/* 182:    */           {
/* 183:216 */             LinkControl linkCtrl = new LinkControl();
/* 184:217 */             linkCtrl.setControlData(buttonData[i]);
/* 185:    */             try
/* 186:    */             {
/* 187:220 */               if (this.event != null) {
/* 188:221 */                 linkCtrl.setParentControl((AbstractMobileControl)this.event.getCreatingObject());
/* 189:    */               }
/* 190:222 */               UIComponent[] comps = linkCtrl.composeComponents();
/* 191:223 */               if (comps != null)
/* 192:    */               {
/* 193:225 */                 linkCtrl.setComponents(comps);
/* 194:226 */                 this.adapter.addListenerToLinkImageAndAppendComponent(linkCtrl, comps[0], btns);
/* 195:    */               }
/* 196:    */             }
/* 197:    */             catch (Throwable t) {}
/* 198:    */           }
/* 199:    */         }
/* 200:    */       }
/* 201:    */     }
/* 202:236 */     else if (this.buttons > 0)
/* 203:    */     {
/* 204:238 */       if ((0x1 & this.buttons) == 1) {
/* 205:240 */         btns.add(createButton(1, null, this.event != null));
/* 206:    */       }
/* 207:242 */       if ((0x4 & this.buttons) == 4) {
/* 208:244 */         btns.add(createButton(4, null, this.event != null));
/* 209:    */       }
/* 210:246 */       if ((0x8 & this.buttons) == 8) {
/* 211:248 */         btns.add(createButton(8, null, this.event != null));
/* 212:    */       }
/* 213:250 */       if ((0x2 & this.buttons) == 2) {
/* 214:252 */         btns.add(createButton(2, null, this.event != null));
/* 215:    */       }
/* 216:254 */       if ((0x10 & this.buttons) == 16) {
/* 217:256 */         btns.add(createButton(16, null, this.event != null));
/* 218:    */       }
/* 219:    */     }
/* 220:259 */     if (btns.isEmpty()) {
/* 221:261 */       btns.add(createButton(1, null, this.event != null));
/* 222:    */     }
/* 223:263 */     return btns;
/* 224:    */   }
/* 225:    */   
/* 226:    */   public UIComponent getIcon()
/* 227:    */   {
/* 228:268 */     if ((this.icon == null) && (this.controlData != null)) {
/* 229:269 */       this.icon = this.controlData.getValue("icon");
/* 230:    */     }
/* 231:270 */     if (this.icon != null)
/* 232:    */     {
/* 233:272 */       if (this.icon.equals("info")) {
/* 234:273 */         this.icon = MobileUIProperties.getStringValue("messagebox.infoicon");
/* 235:274 */       } else if (this.icon.equals("warning")) {
/* 236:275 */         this.icon = MobileUIProperties.getStringValue("messagebox.warningicon");
/* 237:276 */       } else if (this.icon.equals("question")) {
/* 238:277 */         this.icon = MobileUIProperties.getStringValue("messagebox.questionicon");
/* 239:    */       }
/* 240:278 */       return this.adapter.createIconImage(this.icon);
/* 241:    */     }
/* 242:280 */     return null;
/* 243:    */   }
/* 244:    */   
/* 245:    */   public void show()
/* 246:    */   {
/* 247:284 */     this.adapter.show();
/* 248:    */   }
/* 249:    */   
/* 250:287 */   private static MessageBoxAdapterFactory messageBoxAdapterFactory = null;
/* 251:    */   
/* 252:    */   public static void resgiterMessageBoxAdapterFactory(MessageBoxAdapterFactory factory)
/* 253:    */   {
/* 254:290 */     messageBoxAdapterFactory = factory;
/* 255:    */   }
/* 256:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.controls.MessageBox
 * JD-Core Version:    0.7.0.1
 */