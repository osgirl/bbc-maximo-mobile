/*   1:    */ package com.mro.mobile.ui.res.controls;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.ui.MobileUIControlData;
/*   5:    */ import com.mro.mobile.ui.res.ControlData;
/*   6:    */ import com.mro.mobile.ui.res.controls.utils.ControlNodeData;
/*   7:    */ import com.mro.mobile.ui.res.widgets.def.AbstractWidget;
/*   8:    */ import com.mro.mobile.ui.res.widgets.def.MenuViewWidget;
/*   9:    */ import com.mro.mobile.ui.res.widgets.def.MenuWidget;
/*  10:    */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  11:    */ import com.mro.mobile.ui.res.widgets.def.WidgetCreator;
/*  12:    */ import java.util.ArrayList;
/*  13:    */ import java.util.Iterator;
/*  14:    */ 
/*  15:    */ public class MenuViewControl
/*  16:    */   extends MenuControl
/*  17:    */ {
/*  18: 34 */   private ArrayList nodedata = new ArrayList();
/*  19: 35 */   private String currentpagelabel = "";
/*  20: 36 */   private ArrayList menuContents = null;
/*  21:    */   
/*  22:    */   protected MenuViewWidget getMenuViewWidget()
/*  23:    */   {
/*  24: 42 */     return (MenuViewWidget)super.getWidget();
/*  25:    */   }
/*  26:    */   
/*  27: 45 */   private static WidgetCreator widgetCreator = null;
/*  28:    */   
/*  29:    */   public static void registerWidgetCreator(WidgetCreator wc)
/*  30:    */   {
/*  31: 48 */     widgetCreator = wc;
/*  32:    */   }
/*  33:    */   
/*  34:    */   public boolean init()
/*  35:    */     throws MobileApplicationException
/*  36:    */   {
/*  37: 53 */     this.menuContents = getViewNodeData();
/*  38: 54 */     if (this.menuContents != null) {
/*  39: 56 */       if (this.menuContents.size() > 0)
/*  40:    */       {
/*  41: 58 */         Iterator i = this.menuContents.iterator();
/*  42: 59 */         int xx = 1;
/*  43: 60 */         while (i.hasNext())
/*  44:    */         {
/*  45: 62 */           MenuItemControl mic = new MenuItemControl();
/*  46: 63 */           ControlNodeData nodedata = (ControlNodeData)i.next();
/*  47: 64 */           String displayEvent = nodedata.getDisplayevent();
/*  48: 65 */           boolean proceed = true;
/*  49: 67 */           if ((displayEvent != null) && (nodedata.getController() != null))
/*  50:    */           {
/*  51: 69 */             nodedata.getController().sendDisplayEvent();
/*  52: 70 */             proceed = nodedata.getController().isVisible();
/*  53:    */           }
/*  54: 72 */           if (proceed)
/*  55:    */           {
/*  56: 74 */             ControlData cd = new MobileUIControlData();
/*  57: 75 */             cd.putValue("id", nodedata.getId() + xx);
/*  58: 76 */             cd.putValue("label", nodedata.getLabel());
/*  59: 77 */             cd.putValue("value", (String)nodedata.getValue());
/*  60: 78 */             cd.putValue("targetid", nodedata.getTargetid());
/*  61: 79 */             cd.putValue("event", nodedata.getEvent());
/*  62: 80 */             mic.setControlData(cd);
/*  63: 81 */             addChildControl(mic);
/*  64:    */           }
/*  65: 83 */           xx++;
/*  66:    */         }
/*  67:    */       }
/*  68:    */     }
/*  69: 87 */     getMenuWidget().setMenuLabel(getLabel() + " (" + this.currentpagelabel + ")");
/*  70: 88 */     return true;
/*  71:    */   }
/*  72:    */   
/*  73:    */   public ArrayList createChildren()
/*  74:    */     throws MobileApplicationException
/*  75:    */   {
/*  76: 94 */     getMenuWidget().setMenuLabel(getMenuWidget().getMenuLabel() + " (" + this.currentpagelabel + ")");
/*  77: 95 */     return this.childControls;
/*  78:    */   }
/*  79:    */   
/*  80:    */   public UIComponent[] composeComponents()
/*  81:    */     throws MobileApplicationException
/*  82:    */   {
/*  83:103 */     UIComponent[] ret = super.composeComponents();
/*  84:104 */     if (this.childControls == null) {
/*  85:106 */       return null;
/*  86:    */     }
/*  87:108 */     return ret;
/*  88:    */   }
/*  89:    */   
/*  90:    */   private ArrayList getViewNodeData()
/*  91:    */     throws MobileApplicationException
/*  92:    */   {
/*  93:119 */     PageGroupControl pageGroup = (PageGroupControl)getPageGroup();
/*  94:120 */     if (pageGroup != null)
/*  95:    */     {
/*  96:122 */       this.currentpagelabel = ((pageGroup.getCurrentPage().getLabel() == null) || (pageGroup.getCurrentPage().getLabel().equals("")) ? pageGroup.getCurrentPage().getId() : pageGroup.getCurrentPage().getLabel());
/*  97:    */       
/*  98:    */ 
/*  99:    */ 
/* 100:    */ 
/* 101:127 */       int size = pageGroup.childControls.size();
/* 102:129 */       for (int ii = 0; ii < size; ii++)
/* 103:    */       {
/* 104:131 */         AbstractMobileControl page = (AbstractMobileControl)pageGroup.childControls.get(ii);
/* 105:132 */         if (((page instanceof PageControl)) && (page.isAuthorizedToCompose()))
/* 106:    */         {
/* 107:134 */           page = (PageControl)page;
/* 108:135 */           ControlNodeData cnd = new ControlNodeData();
/* 109:136 */           cnd.setId(page.getId());
/* 110:137 */           cnd.setEvent("showpage");
/* 111:    */           
/* 112:139 */           cnd.setLabel((page.getLabel() == null) || (page.getLabel().equals("")) ? page.getId() : page.getLabel());
/* 113:140 */           cnd.setValue(page.getId());
/* 114:141 */           cnd.setDisplayevent(page.getDisplayEvent());
/* 115:142 */           cnd.setController(page);
/* 116:143 */           this.nodedata.add(cnd);
/* 117:    */         }
/* 118:    */       }
/* 119:    */     }
/* 120:147 */     return this.nodedata;
/* 121:    */   }
/* 122:    */   
/* 123:    */   protected void setMenuItems(UIComponent comp, int index)
/* 124:    */   {
/* 125:158 */     Iterator i = getChildren();
/* 126:    */     Object o;
/* 127:159 */     while (i.hasNext()) {
/* 128:161 */       o = i.next();
/* 129:    */     }
/* 130:    */   }
/* 131:    */   
/* 132:    */   public AbstractMobileControl createControl(ControlData controlData)
/* 133:    */     throws MobileApplicationException
/* 134:    */   {
/* 135:170 */     return new MenuViewControl();
/* 136:    */   }
/* 137:    */   
/* 138:    */   protected AbstractWidget createWidget()
/* 139:    */   {
/* 140:174 */     return widgetCreator.createWidget();
/* 141:    */   }
/* 142:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.controls.MenuViewControl
 * JD-Core Version:    0.7.0.1
 */