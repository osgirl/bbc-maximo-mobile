/*   1:    */ package com.mro.mobile.ui.res.controls;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.ui.event.UIEvent;
/*   5:    */ import com.mro.mobile.ui.res.ControlData;
/*   6:    */ import com.mro.mobile.ui.res.widgets.def.AbstractWidget;
/*   7:    */ import com.mro.mobile.ui.res.widgets.def.MenuWidget;
/*   8:    */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*   9:    */ import com.mro.mobile.ui.res.widgets.def.WidgetCreator;
/*  10:    */ 
/*  11:    */ public class MenuControl
/*  12:    */   extends AbstractMobileControl
/*  13:    */ {
/*  14:    */   public MenuWidget getMenuWidget()
/*  15:    */   {
/*  16: 39 */     return (MenuWidget)super.getWidget();
/*  17:    */   }
/*  18:    */   
/*  19: 42 */   private static WidgetCreator widgetCreator = null;
/*  20:    */   
/*  21:    */   public static void registerWidgetCreator(WidgetCreator wc)
/*  22:    */   {
/*  23: 45 */     widgetCreator = wc;
/*  24:    */   }
/*  25:    */   
/*  26:    */   public boolean init()
/*  27:    */     throws MobileApplicationException
/*  28:    */   {
/*  29: 50 */     getMenuWidget().createMenu(getStringValue("id"), getStringValue("label"));
/*  30: 51 */     return true;
/*  31:    */   }
/*  32:    */   
/*  33:    */   private void buildMenu()
/*  34:    */     throws MobileApplicationException
/*  35:    */   {
/*  36: 56 */     getMenuWidget().buildMenu();
/*  37:    */   }
/*  38:    */   
/*  39:    */   public UIComponent[] composeComponents()
/*  40:    */     throws MobileApplicationException
/*  41:    */   {
/*  42: 62 */     init();
/*  43: 63 */     return getMenuWidget().resolveMenuComponents();
/*  44:    */   }
/*  45:    */   
/*  46:    */   protected boolean performEvent(UIEvent event)
/*  47:    */     throws MobileApplicationException
/*  48:    */   {
/*  49: 69 */     return false;
/*  50:    */   }
/*  51:    */   
/*  52:    */   protected boolean handleException(UIEvent event, Exception exception)
/*  53:    */   {
/*  54: 75 */     return false;
/*  55:    */   }
/*  56:    */   
/*  57:    */   public void refresh(UIEvent clientEvent)
/*  58:    */     throws MobileApplicationException
/*  59:    */   {
/*  60: 84 */     super.refresh(clientEvent);
/*  61: 85 */     getMenuWidget().refreshMenu();
/*  62: 86 */     buildMenu();
/*  63:    */   }
/*  64:    */   
/*  65:    */   protected boolean refreshControl(UIEvent event)
/*  66:    */   {
/*  67: 91 */     return true;
/*  68:    */   }
/*  69:    */   
/*  70:    */   public AbstractMobileControl createControl(ControlData controlData)
/*  71:    */     throws MobileApplicationException
/*  72:    */   {
/*  73: 97 */     return new MenuControl();
/*  74:    */   }
/*  75:    */   
/*  76:    */   protected AbstractWidget createWidget()
/*  77:    */   {
/*  78:101 */     return widgetCreator.createWidget();
/*  79:    */   }
/*  80:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.controls.MenuControl
 * JD-Core Version:    0.7.0.1
 */