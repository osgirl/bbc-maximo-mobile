/*   1:    */ package com.mro.mobile.ui.res.controls;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.ui.MobileMboDataBean;
/*   5:    */ import com.mro.mobile.ui.event.UIEvent;
/*   6:    */ import com.mro.mobile.ui.res.ControlData;
/*   7:    */ import com.mro.mobile.ui.res.widgets.def.AbstractWidget;
/*   8:    */ import com.mro.mobile.ui.res.widgets.def.SpinWidget;
/*   9:    */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  10:    */ import com.mro.mobile.ui.res.widgets.def.WidgetCreator;
/*  11:    */ 
/*  12:    */ public class SpinControl
/*  13:    */   extends InputControl
/*  14:    */ {
/*  15: 37 */   protected SpinWidget spinWidget = null;
/*  16:    */   
/*  17:    */   protected SpinWidget getSpinWidget()
/*  18:    */   {
/*  19: 43 */     return (SpinWidget)super.getWidget();
/*  20:    */   }
/*  21:    */   
/*  22:    */   public AbstractMobileControl createControl(ControlData controlData)
/*  23:    */     throws MobileApplicationException
/*  24:    */   {
/*  25: 48 */     return new SpinControl();
/*  26:    */   }
/*  27:    */   
/*  28:    */   public UIComponent[] composeComponents()
/*  29:    */     throws MobileApplicationException
/*  30:    */   {
/*  31: 56 */     String attribValue = getStringValue("minvalue");
/*  32: 57 */     int minValue = attribValue == null ? 0 : new Integer(attribValue).intValue();
/*  33: 58 */     attribValue = getStringValue("maxvalue");
/*  34: 59 */     int maxValue = attribValue == null ? 100 : new Integer(attribValue).intValue();
/*  35: 60 */     attribValue = getStringValue("initvalue");
/*  36: 61 */     int initValue = attribValue == null ? 0 : new Integer(attribValue).intValue();
/*  37:    */     
/*  38: 63 */     this.spinWidget = getSpinWidget().createSpinWidget(minValue, maxValue, initValue, true);
/*  39: 64 */     this.spinWidget.setSpinId(getStringValue("id"));
/*  40: 65 */     this.spinWidget.setEvent(getStringValue("event"));
/*  41: 66 */     this.spinWidget.setController(this);
/*  42: 67 */     this.spinWidget.setDataBeanName(inheritControlAttribute("datasrcname", ""));
/*  43: 68 */     this.spinWidget.setMobileMboAttributeName(getStringValue("mobilembo"));
/*  44:    */     
/*  45: 70 */     UIComponent[] components = this.spinWidget.resolveCheckBoxComponents(getBoundLabel());
/*  46:    */     
/*  47: 72 */     refreshControl(null);
/*  48: 73 */     return components;
/*  49:    */   }
/*  50:    */   
/*  51:    */   protected boolean handleException(UIEvent event, Exception exception)
/*  52:    */   {
/*  53: 82 */     return false;
/*  54:    */   }
/*  55:    */   
/*  56:    */   protected boolean refreshControl(UIEvent event)
/*  57:    */     throws MobileApplicationException
/*  58:    */   {
/*  59: 89 */     MobileMboDataBean dataBean = getDataBean();
/*  60: 90 */     if (dataBean == null)
/*  61:    */     {
/*  62: 92 */       this.spinWidget.setValue(this.spinWidget.getInitValue());
/*  63:    */     }
/*  64:    */     else
/*  65:    */     {
/*  66: 96 */       String inVal = dataBean.getValue(getStringValue("dataattribute"));
/*  67: 97 */       if ((inVal != null) && (!inVal.equals(""))) {
/*  68: 99 */         this.spinWidget.setValue(new Integer(inVal).intValue());
/*  69:    */       }
/*  70:    */     }
/*  71:102 */     return true;
/*  72:    */   }
/*  73:    */   
/*  74:    */   protected boolean init()
/*  75:    */   {
/*  76:111 */     return true;
/*  77:    */   }
/*  78:    */   
/*  79:    */   public String getControlValue()
/*  80:    */   {
/*  81:119 */     return new Integer(this.spinWidget.getValue()).toString();
/*  82:    */   }
/*  83:    */   
/*  84:122 */   private static WidgetCreator widgetCreator = null;
/*  85:    */   
/*  86:    */   public static void registerWidgetCreator(WidgetCreator wc)
/*  87:    */   {
/*  88:125 */     widgetCreator = wc;
/*  89:    */   }
/*  90:    */   
/*  91:    */   protected AbstractWidget createWidget()
/*  92:    */   {
/*  93:129 */     return widgetCreator.createWidget();
/*  94:    */   }
/*  95:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.controls.SpinControl
 * JD-Core Version:    0.7.0.1
 */