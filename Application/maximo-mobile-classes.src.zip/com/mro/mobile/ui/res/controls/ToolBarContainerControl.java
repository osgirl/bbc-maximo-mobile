/*   1:    */ package com.mro.mobile.ui.res.controls;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.ui.event.UIEvent;
/*   5:    */ import com.mro.mobile.ui.res.ControlData;
/*   6:    */ import com.mro.mobile.ui.res.MobileUIProperties;
/*   7:    */ import com.mro.mobile.ui.res.widgets.def.AbstractWidget;
/*   8:    */ import com.mro.mobile.ui.res.widgets.def.ToolBarContainerWidget;
/*   9:    */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  10:    */ import com.mro.mobile.ui.res.widgets.def.WidgetCreator;
/*  11:    */ import java.util.ArrayList;
/*  12:    */ import java.util.Iterator;
/*  13:    */ 
/*  14:    */ public class ToolBarContainerControl
/*  15:    */   extends AbstractMobileControl
/*  16:    */ {
/*  17:    */   protected ToolBarContainerWidget getToolBarContainerWidget()
/*  18:    */   {
/*  19: 44 */     return (ToolBarContainerWidget)super.getWidget();
/*  20:    */   }
/*  21:    */   
/*  22: 47 */   private static WidgetCreator widgetCreator = null;
/*  23:    */   
/*  24:    */   public static void registerWidgetCreator(WidgetCreator wc)
/*  25:    */   {
/*  26: 50 */     widgetCreator = wc;
/*  27:    */   }
/*  28:    */   
/*  29:    */   public UIComponent[] composeComponents()
/*  30:    */     throws MobileApplicationException
/*  31:    */   {
/*  32: 58 */     ToolBarContainerWidget toolbarWidget = getToolBarContainerWidget();
/*  33:    */     
/*  34: 60 */     toolbarWidget.createToolBarContainer();
/*  35:    */     
/*  36: 62 */     toolbarWidget.setId(getStringValue("id"));
/*  37:    */     
/*  38: 64 */     toolbarWidget.setBgImage(MobileUIProperties.getStringValue("toolbar.background"));
/*  39:    */     
/*  40: 66 */     ArrayList toolBarContents = composeChildren();
/*  41: 67 */     if (toolBarContents != null)
/*  42:    */     {
/*  43: 69 */       int size = toolBarContents.size();
/*  44: 70 */       if (size > 0)
/*  45:    */       {
/*  46: 72 */         toolbarWidget.setLayout(size);
/*  47: 73 */         Iterator i = toolBarContents.iterator();
/*  48: 74 */         while (i.hasNext())
/*  49:    */         {
/*  50: 76 */           UIComponent[] comps = (UIComponent[])i.next();
/*  51: 77 */           UIComponent comp = comps[0];
/*  52: 78 */           toolbarWidget.addComponent(comp);
/*  53:    */         }
/*  54:    */       }
/*  55:    */     }
/*  56: 83 */     return toolbarWidget.resolveToolBarContainerComponents();
/*  57:    */   }
/*  58:    */   
/*  59:    */   public void setControlData(ControlData controlAttributes)
/*  60:    */   {
/*  61: 91 */     if (controlAttributes.getValue("styleoverride") == null) {
/*  62: 93 */       controlAttributes.putValue("styleoverride", "toolbar-text");
/*  63:    */     }
/*  64: 96 */     super.setControlData(controlAttributes);
/*  65:    */   }
/*  66:    */   
/*  67:    */   public UIComponent[] getToolbar(String direction)
/*  68:    */     throws MobileApplicationException
/*  69:    */   {
/*  70:106 */     ToolBarContainerWidget toolbarWidget = getToolBarContainerWidget();
/*  71:    */     
/*  72:108 */     toolbarWidget.createToolBarContainer();
/*  73:    */     
/*  74:110 */     ArrayList toolBarContents = composeChildren();
/*  75:111 */     if (toolBarContents != null)
/*  76:    */     {
/*  77:113 */       int size = toolBarContents.size();
/*  78:114 */       if (size > 0)
/*  79:    */       {
/*  80:116 */         toolbarWidget.setLayout(size);
/*  81:117 */         Iterator i = toolBarContents.iterator();
/*  82:118 */         while (i.hasNext())
/*  83:    */         {
/*  84:120 */           UIComponent[] components = (UIComponent[])i.next();
/*  85:121 */           UIComponent component = components[0];
/*  86:122 */           toolbarWidget.addComponent(component, direction);
/*  87:    */         }
/*  88:    */       }
/*  89:    */     }
/*  90:127 */     return toolbarWidget.resolveToolBarContainerComponents();
/*  91:    */   }
/*  92:    */   
/*  93:    */   protected boolean performEvent(UIEvent event)
/*  94:    */     throws MobileApplicationException
/*  95:    */   {
/*  96:135 */     return false;
/*  97:    */   }
/*  98:    */   
/*  99:    */   protected boolean handleException(UIEvent event, Exception exception)
/* 100:    */   {
/* 101:144 */     return false;
/* 102:    */   }
/* 103:    */   
/* 104:    */   protected boolean refreshControl(UIEvent event)
/* 105:    */   {
/* 106:153 */     return true;
/* 107:    */   }
/* 108:    */   
/* 109:    */   public AbstractMobileControl createControl(ControlData controlData)
/* 110:    */     throws MobileApplicationException
/* 111:    */   {
/* 112:162 */     return new ToolBarContainerControl();
/* 113:    */   }
/* 114:    */   
/* 115:    */   protected boolean init()
/* 116:    */   {
/* 117:170 */     return false;
/* 118:    */   }
/* 119:    */   
/* 120:    */   protected AbstractWidget createWidget()
/* 121:    */   {
/* 122:174 */     return widgetCreator.createWidget();
/* 123:    */   }
/* 124:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.controls.ToolBarContainerControl
 * JD-Core Version:    0.7.0.1
 */