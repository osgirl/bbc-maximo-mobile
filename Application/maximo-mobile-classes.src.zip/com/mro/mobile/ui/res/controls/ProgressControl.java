/*  1:   */ package com.mro.mobile.ui.res.controls;
/*  2:   */ 
/*  3:   */ import com.mro.mobile.MobileApplicationException;
/*  4:   */ import com.mro.mobile.ui.event.UIEvent;
/*  5:   */ import com.mro.mobile.ui.res.ControlData;
/*  6:   */ import com.mro.mobile.ui.res.widgets.def.AbstractWidget;
/*  7:   */ import com.mro.mobile.ui.res.widgets.def.ProgressWidget;
/*  8:   */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  9:   */ import com.mro.mobile.ui.res.widgets.def.WidgetCreator;
/* 10:   */ 
/* 11:   */ public class ProgressControl
/* 12:   */   extends AbstractMobileControl
/* 13:   */ {
/* 14:37 */   protected ProgressWidget progressWidget = null;
/* 15:   */   
/* 16:   */   protected ProgressWidget getProgressWidget()
/* 17:   */   {
/* 18:43 */     return (ProgressWidget)super.getWidget();
/* 19:   */   }
/* 20:   */   
/* 21:   */   public AbstractMobileControl createControl(ControlData controlData)
/* 22:   */     throws MobileApplicationException
/* 23:   */   {
/* 24:48 */     return new ProgressControl();
/* 25:   */   }
/* 26:   */   
/* 27:   */   public UIComponent[] composeComponents()
/* 28:   */     throws MobileApplicationException
/* 29:   */   {
/* 30:56 */     this.progressWidget = getProgressWidget().createProgressWidget();
/* 31:57 */     this.progressWidget.setProgressId(getStringValue("id"));
/* 32:58 */     this.progressWidget.setController(this);
/* 33:59 */     return this.progressWidget.resolveProgressComponents();
/* 34:   */   }
/* 35:   */   
/* 36:   */   protected boolean performEvent(UIEvent event)
/* 37:   */     throws MobileApplicationException
/* 38:   */   {
/* 39:67 */     return true;
/* 40:   */   }
/* 41:   */   
/* 42:   */   protected boolean handleException(UIEvent event, Exception exception)
/* 43:   */   {
/* 44:76 */     return false;
/* 45:   */   }
/* 46:   */   
/* 47:   */   protected boolean refreshControl(UIEvent event)
/* 48:   */     throws MobileApplicationException
/* 49:   */   {
/* 50:83 */     return true;
/* 51:   */   }
/* 52:   */   
/* 53:86 */   private static WidgetCreator widgetCreator = null;
/* 54:   */   
/* 55:   */   public static void registerWidgetCreator(WidgetCreator wc)
/* 56:   */   {
/* 57:89 */     widgetCreator = wc;
/* 58:   */   }
/* 59:   */   
/* 60:   */   protected AbstractWidget createWidget()
/* 61:   */   {
/* 62:93 */     return widgetCreator.createWidget();
/* 63:   */   }
/* 64:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.controls.ProgressControl
 * JD-Core Version:    0.7.0.1
 */