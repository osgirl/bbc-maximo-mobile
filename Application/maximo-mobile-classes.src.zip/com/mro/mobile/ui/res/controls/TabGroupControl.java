/*   1:    */ package com.mro.mobile.ui.res.controls;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.app.BasicMobileDeviceUIApplication;
/*   5:    */ import com.mro.mobile.ui.event.UIEvent;
/*   6:    */ import com.mro.mobile.ui.res.ControlData;
/*   7:    */ import com.mro.mobile.ui.res.UIUtil;
/*   8:    */ import com.mro.mobile.ui.res.controls.utils.ControlStyle;
/*   9:    */ import com.mro.mobile.ui.res.widgets.def.AbstractWidget;
/*  10:    */ import com.mro.mobile.ui.res.widgets.def.TabGroupWidget;
/*  11:    */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  12:    */ import com.mro.mobile.ui.res.widgets.def.WidgetCreator;
/*  13:    */ import java.util.ArrayList;
/*  14:    */ import java.util.Iterator;
/*  15:    */ import java.util.ListIterator;
/*  16:    */ import java.util.Vector;
/*  17:    */ 
/*  18:    */ public class TabGroupControl
/*  19:    */   extends AbstractMobileControl
/*  20:    */ {
/*  21: 46 */   private Vector tabVector = new Vector();
/*  22: 47 */   private static String STYLE = "tab";
/*  23: 48 */   protected ControlStyle style = null;
/*  24: 49 */   protected ArrayList visibleTabs = new ArrayList();
/*  25:    */   
/*  26:    */   protected TabGroupWidget getTabGroupWidget()
/*  27:    */   {
/*  28: 55 */     return (TabGroupWidget)super.getWidget();
/*  29:    */   }
/*  30:    */   
/*  31: 58 */   private static WidgetCreator widgetCreator = null;
/*  32:    */   
/*  33:    */   public static void registerWidgetCreator(WidgetCreator wc)
/*  34:    */   {
/*  35: 61 */     widgetCreator = wc;
/*  36:    */   }
/*  37:    */   
/*  38:    */   protected boolean init()
/*  39:    */   {
/*  40: 66 */     return true;
/*  41:    */   }
/*  42:    */   
/*  43:    */   public AbstractMobileControl createControl(ControlData controlData)
/*  44:    */     throws MobileApplicationException
/*  45:    */   {
/*  46: 71 */     return new TabGroupControl();
/*  47:    */   }
/*  48:    */   
/*  49:    */   public UIComponent[] composeComponents()
/*  50:    */     throws MobileApplicationException
/*  51:    */   {
/*  52: 76 */     String tabgroupID = getStringValue("id");
/*  53: 77 */     if (!isUiTestMode()) {
/*  54: 78 */       this.style = getStyle(STYLE);
/*  55:    */     }
/*  56: 81 */     TabGroupWidget widget = getTabGroupWidget();
/*  57: 82 */     widget.createTabGroup(this.style);
/*  58:    */     
/*  59:    */ 
/*  60: 85 */     composeChildren();
/*  61: 86 */     Iterator i = getChildren();
/*  62: 87 */     int curTab = -1;
/*  63: 89 */     while (i.hasNext())
/*  64:    */     {
/*  65: 91 */       AbstractMobileControl child = (AbstractMobileControl)i.next();
/*  66: 92 */       UIComponent[] components = child.getComponents();
/*  67: 93 */       int compCount = components.length;
/*  68: 94 */       curTab++;
/*  69: 95 */       for (int j = 0; j < compCount; j++)
/*  70:    */       {
/*  71: 97 */         curTab++;
/*  72: 98 */         this.tabVector.add(components[j]);
/*  73:    */       }
/*  74:    */     }
/*  75:101 */     widget.applyLayoutConstraints();
/*  76:    */     
/*  77:103 */     renderTabs(this.tabVector, true);
/*  78:    */     
/*  79:105 */     return widget.resolveTabGroupComponents();
/*  80:    */   }
/*  81:    */   
/*  82:    */   protected boolean performEvent(UIEvent event)
/*  83:    */     throws MobileApplicationException
/*  84:    */   {
/*  85:110 */     String eventName = event.getEventName();
/*  86:112 */     if (eventName.equalsIgnoreCase("refreshTab"))
/*  87:    */     {
/*  88:114 */       UIUtil.refreshScreen(UIUtil.getCurrentScreen(), event);
/*  89:115 */       ((PageControl)this.app.getCurrentScreen()).setCurrentInput(null);
/*  90:116 */       return false;
/*  91:    */     }
/*  92:118 */     if (eventName.equalsIgnoreCase("gototab")) {
/*  93:120 */       return gototab(event);
/*  94:    */     }
/*  95:122 */     return false;
/*  96:    */   }
/*  97:    */   
/*  98:    */   public void refresh(UIEvent clientEvent)
/*  99:    */     throws MobileApplicationException
/* 100:    */   {
/* 101:131 */     boolean tabslazyrefresh = getBooleanValue("tabslazyrefresh");
/* 102:    */     
/* 103:133 */     sendDisplayEvent();
/* 104:134 */     if (hasChildren()) {
/* 105:136 */       if (tabslazyrefresh)
/* 106:    */       {
/* 107:138 */         TabControl tab = getCurrentTab();
/* 108:139 */         if (tab != null)
/* 109:    */         {
/* 110:140 */           tab.sendRefreshEvent();
/* 111:141 */           tab.sendDisplayEvent();
/* 112:    */         }
/* 113:    */       }
/* 114:    */       else
/* 115:    */       {
/* 116:145 */         Iterator i = getChildren();
/* 117:146 */         while (i.hasNext())
/* 118:    */         {
/* 119:148 */           AbstractMobileControl tab = (AbstractMobileControl)i.next();
/* 120:149 */           tab.sendRefreshEvent();
/* 121:150 */           tab.sendDisplayEvent();
/* 122:    */         }
/* 123:    */       }
/* 124:    */     }
/* 125:154 */     renderTabs(this.tabVector, getTabGroupWidget().needFullCleanUpDuringRefresh());
/* 126:155 */     TabControl tab = getCurrentTab();
/* 127:156 */     if (tab != null) {
/* 128:157 */       tab.refresh(clientEvent);
/* 129:    */     }
/* 130:    */   }
/* 131:    */   
/* 132:    */   protected boolean refreshControl(UIEvent event)
/* 133:    */   {
/* 134:162 */     return true;
/* 135:    */   }
/* 136:    */   
/* 137:    */   public boolean gototab(UIEvent event)
/* 138:    */     throws MobileApplicationException
/* 139:    */   {
/* 140:167 */     String value = (String)event.getValue();
/* 141:168 */     for (int i = 0; i < this.childControls.size(); i++)
/* 142:    */     {
/* 143:170 */       AbstractMobileControl tab = (AbstractMobileControl)this.childControls.get(i);
/* 144:171 */       if (tab.getId().equalsIgnoreCase(value))
/* 145:    */       {
/* 146:173 */         setCurrentTab((TabControl)tab);
/* 147:174 */         UIUtil.refreshScreen(UIUtil.getCurrentScreen(), event);
/* 148:175 */         break;
/* 149:    */       }
/* 150:    */     }
/* 151:178 */     return true;
/* 152:    */   }
/* 153:    */   
/* 154:    */   protected boolean handleException(UIEvent event, Exception exception)
/* 155:    */   {
/* 156:183 */     return false;
/* 157:    */   }
/* 158:    */   
/* 159:    */   private int getSelectedTab()
/* 160:    */   {
/* 161:188 */     return getTabGroupWidget().getSelectedTab();
/* 162:    */   }
/* 163:    */   
/* 164:    */   public TabControl getCurrentTab()
/* 165:    */   {
/* 166:193 */     if (getSelectedTab() >= 0) {
/* 167:194 */       return (TabControl)this.visibleTabs.get(getSelectedTab());
/* 168:    */     }
/* 169:195 */     return null;
/* 170:    */   }
/* 171:    */   
/* 172:    */   public void renderTabs(Vector tabVector, boolean cleanUpFirst)
/* 173:    */     throws MobileApplicationException
/* 174:    */   {
/* 175:200 */     TabGroupWidget widget = getTabGroupWidget();
/* 176:201 */     TabControl curSelTab = getCurrentTab();
/* 177:202 */     TabControl newCurTab = null;
/* 178:203 */     ListIterator tabEnum = null;
/* 179:205 */     if (cleanUpFirst)
/* 180:    */     {
/* 181:206 */       if (tabVector.size() > 0)
/* 182:    */       {
/* 183:208 */         tabEnum = tabVector.listIterator();
/* 184:209 */         widget.removeAllTabs();
/* 185:    */       }
/* 186:212 */       this.visibleTabs.clear();
/* 187:214 */       while ((tabEnum != null) && (tabEnum.hasNext()))
/* 188:    */       {
/* 189:216 */         UIComponent component = (UIComponent)tabEnum.next();
/* 190:217 */         TabControl tabControl = (TabControl)component.getController();
/* 191:219 */         if (tabControl.isVisible())
/* 192:    */         {
/* 193:221 */           this.visibleTabs.add(tabControl);
/* 194:223 */           if (tabControl.isAttributeSet("tabimage"))
/* 195:    */           {
/* 196:224 */             widget.addImageTab(component, tabControl.getId(), tabControl.getStringValue("tabimage"));
/* 197:    */           }
/* 198:    */           else
/* 199:    */           {
/* 200:226 */             String tag = "";
/* 201:227 */             if (tabControl.getStringValue("label") != null) {
/* 202:228 */               tag = tabControl.getStringValue("label");
/* 203:    */             }
/* 204:230 */             widget.addTextTab(component, tabControl.getId(), tag);
/* 205:    */           }
/* 206:232 */           if (tabControl.getBooleanValue("default")) {
/* 207:233 */             newCurTab = tabControl;
/* 208:    */           }
/* 209:    */         }
/* 210:    */       }
/* 211:    */     }
/* 212:237 */     if ((curSelTab != null) && (curSelTab.isVisible())) {
/* 213:239 */       newCurTab = curSelTab;
/* 214:241 */     } else if ((newCurTab == null) && (!this.visibleTabs.isEmpty())) {
/* 215:243 */       newCurTab = (TabControl)this.visibleTabs.get(0);
/* 216:    */     }
/* 217:246 */     if (newCurTab != null)
/* 218:    */     {
/* 219:248 */       setCurrentTab(newCurTab);
/* 220:249 */       setToolBar(newCurTab.getToolBar());
/* 221:250 */       if (!isUiTestMode()) {
/* 222:251 */         ((PageControl)getPage()).setMenuBar(newCurTab.getMenuBar());
/* 223:    */       }
/* 224:    */     }
/* 225:    */   }
/* 226:    */   
/* 227:    */   public void setCurrentTab(TabControl tab)
/* 228:    */     throws MobileApplicationException
/* 229:    */   {
/* 230:259 */     if (!tab.isTabRendered())
/* 231:    */     {
/* 232:260 */       tab.renderCurrentTab();
/* 233:261 */       tab.setTabRendered(true);
/* 234:    */     }
/* 235:263 */     int i = this.visibleTabs.indexOf(tab);
/* 236:264 */     TabGroupWidget widget = getTabGroupWidget();
/* 237:265 */     if ((i >= 0) && (i < widget.getTabCount())) {
/* 238:266 */       widget.selectTab(i);
/* 239:    */     }
/* 240:    */   }
/* 241:    */   
/* 242:    */   public boolean sendEventDown(UIEvent event)
/* 243:    */     throws MobileApplicationException
/* 244:    */   {
/* 245:272 */     boolean ret = false;
/* 246:273 */     TabControl tab = getCurrentTab();
/* 247:274 */     if (tab != null)
/* 248:    */     {
/* 249:276 */       ret = tab.processEvent(event);
/* 250:277 */       if (!ret) {
/* 251:279 */         ret = tab.sendEventDown(event);
/* 252:    */       }
/* 253:    */     }
/* 254:282 */     return ret;
/* 255:    */   }
/* 256:    */   
/* 257:    */   public boolean validateControl()
/* 258:    */   {
/* 259:290 */     if (super.validateControl()) {
/* 260:292 */       return checkRequiredFields();
/* 261:    */     }
/* 262:294 */     return true;
/* 263:    */   }
/* 264:    */   
/* 265:    */   protected AbstractWidget createWidget()
/* 266:    */   {
/* 267:298 */     return widgetCreator.createWidget();
/* 268:    */   }
/* 269:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.controls.TabGroupControl
 * JD-Core Version:    0.7.0.1
 */