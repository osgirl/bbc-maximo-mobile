/*  1:   */ package com.mro.mobile.ui.res.controls.utils;
/*  2:   */ 
/*  3:   */ public abstract interface StandardEvents
/*  4:   */ {
/*  5:   */   public static final String SHOW_PAGE = "showpage";
/*  6:   */   public static final String GOTO_PAGE = "gotopage";
/*  7:   */   public static final String START_CENTER = "startcenter";
/*  8:   */   public static final String CLOSE_PAGE = "closepage";
/*  9:   */   public static final String FILTER = "filter";
/* 10:   */   public static final String MANAGEDATA = "managedata";
/* 11:   */   public static final String PREFERENCES = "preferences";
/* 12:   */   public static final String SAVEQUERIES = "savequeries";
/* 13:   */   public static final String REFRESH_WORKSET = "refreshworkset";
/* 14:   */   public static final String REFRESH_RELATEDSET = "refreshrelatedset";
/* 15:   */   public static final String REFRESH_ALL_DATA = "refreshalldata";
/* 16:   */   public static final String POPUP_PAGE = "popuppage";
/* 17:   */   public static final String EVENT_EXECUTE = "execute";
/* 18:   */   public static final String EVENT_SIGNATURE = "showsignature";
/* 19:   */   public static final String EVENT_SAVESIGNATURE = "savesignature";
/* 20:48 */   public static final String[] events = { "showpage", "gotopage", "startcenter", "closepage", "filter", "managedata", "savequeries", "refreshworkset", "refreshrelatedset", "refreshalldata", "popuppage", "execute", "showsignature", "savesignature" };
/* 21:55 */   public static final String[] nonSigoptionEvents = { "showpage", "gotopage" };
/* 22:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.controls.utils.StandardEvents
 * JD-Core Version:    0.7.0.1
 */