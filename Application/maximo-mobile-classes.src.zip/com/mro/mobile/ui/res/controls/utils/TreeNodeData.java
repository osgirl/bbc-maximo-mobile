/*   1:    */ package com.mro.mobile.ui.res.controls.utils;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.ui.MobileMboDataBean;
/*   4:    */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*   5:    */ 
/*   6:    */ public class TreeNodeData
/*   7:    */ {
/*   8: 37 */   private int index = -1;
/*   9: 38 */   private int actualParentIndex = -1;
/*  10: 39 */   private boolean extra = false;
/*  11: 40 */   private boolean rootParent = false;
/*  12: 41 */   private boolean hasChildren = true;
/*  13: 42 */   private String type = "";
/*  14: 43 */   private String displayValue = null;
/*  15: 44 */   private UIComponent displayPanel = null;
/*  16: 45 */   private MobileMboDataBean childDataBean = null;
/*  17: 47 */   private int depth = 0;
/*  18: 49 */   private Object referenceItem = null;
/*  19: 50 */   private String additionalValue = null;
/*  20: 52 */   private int labelLength = 0;
/*  21:    */   
/*  22:    */   public TreeNodeData(int index, String type, String displayValue, boolean isRootParent)
/*  23:    */   {
/*  24: 62 */     this(index, type, displayValue, isRootParent, false);
/*  25:    */   }
/*  26:    */   
/*  27:    */   public TreeNodeData(int index, String type, String displayValue, boolean isRootParent, boolean isExtra)
/*  28:    */   {
/*  29: 67 */     this.index = index;
/*  30: 68 */     this.type = type;
/*  31: 69 */     this.displayValue = displayValue;
/*  32: 70 */     this.rootParent = isRootParent;
/*  33: 71 */     this.extra = isExtra;
/*  34:    */   }
/*  35:    */   
/*  36:    */   public String getDisplayValue()
/*  37:    */   {
/*  38: 78 */     return this.displayValue;
/*  39:    */   }
/*  40:    */   
/*  41:    */   public int getIndex()
/*  42:    */   {
/*  43: 84 */     return this.index;
/*  44:    */   }
/*  45:    */   
/*  46:    */   public String getType()
/*  47:    */   {
/*  48: 90 */     return this.type;
/*  49:    */   }
/*  50:    */   
/*  51:    */   public MobileMboDataBean getChildDataBean()
/*  52:    */   {
/*  53: 97 */     return this.childDataBean;
/*  54:    */   }
/*  55:    */   
/*  56:    */   public void setChildDataBean(MobileMboDataBean childDataBean)
/*  57:    */   {
/*  58:103 */     this.childDataBean = childDataBean;
/*  59:    */   }
/*  60:    */   
/*  61:    */   public UIComponent getDisplayPanel()
/*  62:    */   {
/*  63:109 */     return this.displayPanel;
/*  64:    */   }
/*  65:    */   
/*  66:    */   public void setDisplayPanel(UIComponent displayPanel)
/*  67:    */   {
/*  68:115 */     this.displayPanel = displayPanel;
/*  69:    */   }
/*  70:    */   
/*  71:    */   public boolean isRootParent()
/*  72:    */   {
/*  73:121 */     return this.rootParent;
/*  74:    */   }
/*  75:    */   
/*  76:    */   public boolean look4Children()
/*  77:    */   {
/*  78:128 */     return this.hasChildren;
/*  79:    */   }
/*  80:    */   
/*  81:    */   public void setHasChildren(boolean hasChildren)
/*  82:    */   {
/*  83:134 */     this.hasChildren = hasChildren;
/*  84:    */   }
/*  85:    */   
/*  86:    */   public boolean isExtra()
/*  87:    */   {
/*  88:140 */     return this.extra;
/*  89:    */   }
/*  90:    */   
/*  91:    */   public int getActualParentIndex()
/*  92:    */   {
/*  93:147 */     return this.actualParentIndex;
/*  94:    */   }
/*  95:    */   
/*  96:    */   public void setActualParentIndex(Object actualParentIndex)
/*  97:    */   {
/*  98:153 */     if (actualParentIndex != null) {
/*  99:155 */       this.actualParentIndex = ((Integer)actualParentIndex).intValue();
/* 100:    */     }
/* 101:    */   }
/* 102:    */   
/* 103:    */   public int getDepth()
/* 104:    */   {
/* 105:160 */     return this.depth;
/* 106:    */   }
/* 107:    */   
/* 108:    */   public void setDepth(int depth)
/* 109:    */   {
/* 110:164 */     this.depth = depth;
/* 111:    */   }
/* 112:    */   
/* 113:    */   public Object getReferenceItem()
/* 114:    */   {
/* 115:168 */     return this.referenceItem;
/* 116:    */   }
/* 117:    */   
/* 118:    */   public void setReferenceItem(Object item)
/* 119:    */   {
/* 120:172 */     this.referenceItem = item;
/* 121:    */   }
/* 122:    */   
/* 123:    */   public int getLabelLength()
/* 124:    */   {
/* 125:176 */     return this.labelLength;
/* 126:    */   }
/* 127:    */   
/* 128:    */   public void setLabelLength(int labelLength)
/* 129:    */   {
/* 130:180 */     this.labelLength = labelLength;
/* 131:    */   }
/* 132:    */   
/* 133:    */   public void setAdditionalValue(String additionalValue)
/* 134:    */   {
/* 135:184 */     this.additionalValue = additionalValue;
/* 136:    */   }
/* 137:    */   
/* 138:    */   public String getAdditionalValue()
/* 139:    */   {
/* 140:188 */     return this.additionalValue;
/* 141:    */   }
/* 142:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.controls.utils.TreeNodeData
 * JD-Core Version:    0.7.0.1
 */