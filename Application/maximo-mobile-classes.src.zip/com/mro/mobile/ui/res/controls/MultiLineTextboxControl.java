/*  1:   */ package com.mro.mobile.ui.res.controls;
/*  2:   */ 
/*  3:   */ import com.mro.mobile.MobileApplicationException;
/*  4:   */ import com.mro.mobile.ui.res.ControlData;
/*  5:   */ import com.mro.mobile.ui.res.widgets.def.AbstractWidget;
/*  6:   */ import com.mro.mobile.ui.res.widgets.def.MultiLineTextboxWidget;
/*  7:   */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  8:   */ import com.mro.mobile.ui.res.widgets.def.WidgetCreator;
/*  9:   */ 
/* 10:   */ public class MultiLineTextboxControl
/* 11:   */   extends TextboxControl
/* 12:   */ {
/* 13:   */   protected MultiLineTextboxWidget getMultiLineTextboxWidget()
/* 14:   */   {
/* 15:41 */     return (MultiLineTextboxWidget)super.getWidget();
/* 16:   */   }
/* 17:   */   
/* 18:   */   public AbstractMobileControl createControl(ControlData controlData)
/* 19:   */     throws MobileApplicationException
/* 20:   */   {
/* 21:49 */     return new MultiLineTextboxControl();
/* 22:   */   }
/* 23:   */   
/* 24:   */   public UIComponent[] composeComponents()
/* 25:   */     throws MobileApplicationException
/* 26:   */   {
/* 27:57 */     return getMultiLineTextboxWidget().resolveMultiLineTextboxComponents();
/* 28:   */   }
/* 29:   */   
/* 30:60 */   private static WidgetCreator widgetCreator = null;
/* 31:   */   
/* 32:   */   public static void registerWidgetCreator(WidgetCreator wc)
/* 33:   */   {
/* 34:63 */     widgetCreator = wc;
/* 35:   */   }
/* 36:   */   
/* 37:   */   protected AbstractWidget createWidget()
/* 38:   */   {
/* 39:67 */     return widgetCreator.createWidget();
/* 40:   */   }
/* 41:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.controls.MultiLineTextboxControl
 * JD-Core Version:    0.7.0.1
 */