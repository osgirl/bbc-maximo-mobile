/*  1:   */ package com.mro.mobile.ui.res.controls.utils.android;
/*  2:   */ 
/*  3:   */ import android.graphics.Typeface;
/*  4:   */ import com.mro.mobile.ui.res.controls.utils.FontCreator;
/*  5:   */ import java.util.Map;
/*  6:   */ 
/*  7:   */ public class ADFontCreatorImpl
/*  8:   */   implements FontCreator
/*  9:   */ {
/* 10:   */   public Object createFont(Map settings)
/* 11:   */   {
/* 12:25 */     return Typeface.create(Typeface.SANS_SERIF, 0);
/* 13:   */   }
/* 14:   */   
/* 15:   */   public boolean isAlreadyColor(Object obj)
/* 16:   */   {
/* 17:29 */     return obj instanceof Integer;
/* 18:   */   }
/* 19:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.controls.utils.android.ADFontCreatorImpl
 * JD-Core Version:    0.7.0.1
 */