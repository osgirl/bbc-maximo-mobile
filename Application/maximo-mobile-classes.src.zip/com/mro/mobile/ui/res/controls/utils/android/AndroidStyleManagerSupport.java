/*  1:   */ package com.mro.mobile.ui.res.controls.utils.android;
/*  2:   */ 
/*  3:   */ import com.mro.mobile.ui.res.controls.utils.ControlStyle;
/*  4:   */ import com.mro.mobile.ui.res.controls.utils.StyleManagerSupport;
/*  5:   */ import java.util.HashMap;
/*  6:   */ 
/*  7:   */ public class AndroidStyleManagerSupport
/*  8:   */   implements StyleManagerSupport
/*  9:   */ {
/* 10:22 */   private ControlStyle defaultStyle = new ControlStyle("default", new HashMap());
/* 11:   */   
/* 12:   */   public ControlStyle getStyle(String style, String override)
/* 13:   */   {
/* 14:26 */     String name = style;
/* 15:27 */     if (override != null) {
/* 16:28 */       name = name + "_" + override;
/* 17:   */     }
/* 18:30 */     name = name.replaceAll("\\.|-", "_");
/* 19:31 */     return new ControlStyle(name, new HashMap());
/* 20:   */   }
/* 21:   */   
/* 22:   */   public Object getDefaultFont()
/* 23:   */   {
/* 24:36 */     return this.defaultStyle.getFont();
/* 25:   */   }
/* 26:   */   
/* 27:   */   public Object getDefaultBgColor()
/* 28:   */   {
/* 29:41 */     return this.defaultStyle.getBgColor();
/* 30:   */   }
/* 31:   */   
/* 32:   */   public Object getDefaultFgColor()
/* 33:   */   {
/* 34:46 */     return this.defaultStyle.getFgColor();
/* 35:   */   }
/* 36:   */   
/* 37:   */   public Object getDefaultSetting(String setting)
/* 38:   */   {
/* 39:51 */     return null;
/* 40:   */   }
/* 41:   */   
/* 42:   */   public ControlStyle getDefaultStyle()
/* 43:   */   {
/* 44:55 */     return this.defaultStyle;
/* 45:   */   }
/* 46:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.controls.utils.android.AndroidStyleManagerSupport
 * JD-Core Version:    0.7.0.1
 */