/*   1:    */ package com.mro.mobile.ui.res.controls;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.ui.event.UIEvent;
/*   5:    */ import com.mro.mobile.ui.res.ControlData;
/*   6:    */ import com.mro.mobile.ui.res.widgets.def.AbstractWidget;
/*   7:    */ import com.mro.mobile.ui.res.widgets.def.SectionColWidget;
/*   8:    */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*   9:    */ import com.mro.mobile.ui.res.widgets.def.WidgetCreator;
/*  10:    */ import java.util.ArrayList;
/*  11:    */ import java.util.Iterator;
/*  12:    */ 
/*  13:    */ public class SectionColControl
/*  14:    */   extends AbstractMobileControl
/*  15:    */ {
/*  16: 43 */   protected int numCols = 0;
/*  17:    */   private static final int DEFAULT_COLSPACING = 5;
/*  18:    */   private static final int DEFAULT_ROWSPACING = 0;
/*  19:    */   
/*  20:    */   protected SectionColWidget getSectionColWidget()
/*  21:    */   {
/*  22: 53 */     return (SectionColWidget)super.getWidget();
/*  23:    */   }
/*  24:    */   
/*  25:    */   public AbstractMobileControl createControl(ControlData controlData)
/*  26:    */     throws MobileApplicationException
/*  27:    */   {
/*  28: 61 */     return new SectionColControl();
/*  29:    */   }
/*  30:    */   
/*  31:    */   public UIComponent[] composeComponents()
/*  32:    */     throws MobileApplicationException
/*  33:    */   {
/*  34: 66 */     String align = getValue("align");
/*  35: 67 */     SectionColWidget widget = getSectionColWidget();
/*  36: 68 */     widget.createSectionCol(getStringValue("id"), align);
/*  37:    */     
/*  38: 70 */     ArrayList childComps = composeChildren();
/*  39: 71 */     if (childComps != null)
/*  40:    */     {
/*  41: 73 */       Iterator i = childComps.iterator();
/*  42: 74 */       while (i.hasNext())
/*  43:    */       {
/*  44: 76 */         UIComponent[] comps = (UIComponent[])i.next();
/*  45: 77 */         for (int j = 0; j < comps.length; j++)
/*  46:    */         {
/*  47: 79 */           UIComponent component = comps[j];
/*  48: 80 */           widget.addComponent(component);
/*  49:    */         }
/*  50:    */       }
/*  51:    */     }
/*  52: 88 */     String colspacing = null;
/*  53: 89 */     if ((!isUiTestMode()) || (getParentControl() != null)) {
/*  54: 90 */       colspacing = getParentControl().getValue("colspacing");
/*  55:    */     }
/*  56: 93 */     int colspacInt = 5;
/*  57: 94 */     if ((colspacing != null) && (colspacing.length() > 0)) {
/*  58: 96 */       colspacInt = Integer.parseInt(colspacing);
/*  59:    */     }
/*  60:100 */     String rowspacing = null;
/*  61:    */     try
/*  62:    */     {
/*  63:102 */       if ((!isUiTestMode()) || (getParentControl() != null)) {
/*  64:103 */         rowspacing = getParentControl().getParentControl().getValue("rowspacing");
/*  65:    */       }
/*  66:    */     }
/*  67:    */     catch (NullPointerException ne) {}
/*  68:110 */     int rowspacInt = 0;
/*  69:111 */     if ((rowspacing != null) && (rowspacing.length() > 0)) {
/*  70:113 */       rowspacInt = Integer.parseInt(rowspacing);
/*  71:    */     }
/*  72:116 */     widget.setPadding(rowspacInt, colspacInt);
/*  73:    */     
/*  74:118 */     this.components = widget.resolveSectionColComponents();
/*  75:119 */     return this.components;
/*  76:    */   }
/*  77:    */   
/*  78:    */   protected boolean performEvent(UIEvent event)
/*  79:    */     throws MobileApplicationException
/*  80:    */   {
/*  81:127 */     return false;
/*  82:    */   }
/*  83:    */   
/*  84:    */   public void addColumn()
/*  85:    */   {
/*  86:132 */     this.numCols += 1;
/*  87:    */   }
/*  88:    */   
/*  89:    */   protected boolean handleException(UIEvent event, Exception exception)
/*  90:    */   {
/*  91:141 */     return false;
/*  92:    */   }
/*  93:    */   
/*  94:    */   protected boolean refreshControl(UIEvent event)
/*  95:    */   {
/*  96:149 */     return true;
/*  97:    */   }
/*  98:    */   
/*  99:    */   protected boolean init()
/* 100:    */   {
/* 101:157 */     return true;
/* 102:    */   }
/* 103:    */   
/* 104:    */   public void setParentControl(AbstractMobileControl parentControl)
/* 105:    */   {
/* 106:164 */     super.setParentControl(parentControl);
/* 107:165 */     if ((parentControl instanceof SectionRowControl)) {
/* 108:167 */       ((SectionRowControl)parentControl).addColumn();
/* 109:    */     }
/* 110:    */   }
/* 111:    */   
/* 112:171 */   private static WidgetCreator widgetCreator = null;
/* 113:    */   
/* 114:    */   public static void registerWidgetCreator(WidgetCreator wc)
/* 115:    */   {
/* 116:174 */     widgetCreator = wc;
/* 117:    */   }
/* 118:    */   
/* 119:    */   protected AbstractWidget createWidget()
/* 120:    */   {
/* 121:178 */     return widgetCreator.createWidget();
/* 122:    */   }
/* 123:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.controls.SectionColControl
 * JD-Core Version:    0.7.0.1
 */