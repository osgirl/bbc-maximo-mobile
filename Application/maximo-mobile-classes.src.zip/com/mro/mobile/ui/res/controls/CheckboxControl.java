/*   1:    */ package com.mro.mobile.ui.res.controls;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.mbo.MobileMbo;
/*   5:    */ import com.mro.mobile.ui.MobileMboDataBean;
/*   6:    */ import com.mro.mobile.ui.event.UIEvent;
/*   7:    */ import com.mro.mobile.ui.res.ControlData;
/*   8:    */ import com.mro.mobile.ui.res.widgets.def.AbstractWidget;
/*   9:    */ import com.mro.mobile.ui.res.widgets.def.CheckboxWidget;
/*  10:    */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  11:    */ import com.mro.mobile.ui.res.widgets.def.WidgetCreator;
/*  12:    */ 
/*  13:    */ public class CheckboxControl
/*  14:    */   extends InputControl
/*  15:    */   implements FocusableControl
/*  16:    */ {
/*  17: 38 */   private CheckboxWidget checkboxWidget = null;
/*  18:    */   public static final String STYLEKEY = "checkbox";
/*  19:    */   
/*  20:    */   protected CheckboxWidget getCheckboxWidget()
/*  21:    */   {
/*  22: 45 */     return (CheckboxWidget)super.getWidget();
/*  23:    */   }
/*  24:    */   
/*  25:    */   public AbstractMobileControl createControl(ControlData controlData)
/*  26:    */     throws MobileApplicationException
/*  27:    */   {
/*  28: 50 */     return new CheckboxControl();
/*  29:    */   }
/*  30:    */   
/*  31:    */   public UIComponent[] composeComponents()
/*  32:    */     throws MobileApplicationException
/*  33:    */   {
/*  34: 58 */     this.checkboxWidget = getCheckboxWidget().createCheckBoxField(null, isReadOnly());
/*  35: 59 */     this.checkboxWidget.setCheckBoxId(getStringValue("id"));
/*  36: 60 */     this.checkboxWidget.setEvent(getStringValue("event"));
/*  37: 61 */     this.checkboxWidget.setController(this);
/*  38: 62 */     this.checkboxWidget.setDataBeanName(inheritControlAttribute("datasrcname", ""));
/*  39: 63 */     this.checkboxWidget.setMobileMboAttributeName(getStringValue("dataattribute"));
/*  40: 64 */     this.checkboxWidget.setState(getBooleanValue());
/*  41: 65 */     this.checkboxWidget.setInputMode(this.inputMode);
/*  42: 66 */     this.checkboxWidget.setEnabled(!isReadOnly());
/*  43:    */     
/*  44: 68 */     this.components = this.checkboxWidget.resolveCheckBoxComponents();
/*  45:    */     
/*  46: 70 */     return this.components;
/*  47:    */   }
/*  48:    */   
/*  49:    */   private boolean getBooleanValue()
/*  50:    */     throws MobileApplicationException
/*  51:    */   {
/*  52: 75 */     MobileMboDataBean dataBean = getDataBean();
/*  53: 76 */     if ((dataBean == null) && (this.dataAttribute == null)) {
/*  54: 78 */       return false;
/*  55:    */     }
/*  56: 80 */     if (isQuery()) {
/*  57: 83 */       return false;
/*  58:    */     }
/*  59: 85 */     MobileMbo mbo = dataBean.getMobileMbo();
/*  60: 86 */     if (mbo != null) {
/*  61: 87 */       return mbo.getBooleanValue(this.dataAttribute);
/*  62:    */     }
/*  63: 89 */     return false;
/*  64:    */   }
/*  65:    */   
/*  66:    */   protected boolean handleException(UIEvent event, Exception exception)
/*  67:    */   {
/*  68: 97 */     return false;
/*  69:    */   }
/*  70:    */   
/*  71:    */   protected boolean refreshControl(UIEvent event)
/*  72:    */     throws MobileApplicationException
/*  73:    */   {
/*  74:104 */     MobileMboDataBean dataBean = getDataBean();
/*  75:105 */     this.checkboxWidget.setEnabled(!isReadOnly());
/*  76:106 */     if (dataBean == null)
/*  77:    */     {
/*  78:108 */       this.checkboxWidget.setState(false);
/*  79:109 */       return true;
/*  80:    */     }
/*  81:112 */     this.checkboxWidget.setState(getBooleanValue());
/*  82:113 */     return true;
/*  83:    */   }
/*  84:    */   
/*  85:    */   protected boolean init()
/*  86:    */   {
/*  87:121 */     return true;
/*  88:    */   }
/*  89:    */   
/*  90:    */   public String getControlValue()
/*  91:    */   {
/*  92:129 */     return "" + this.checkboxWidget.getState();
/*  93:    */   }
/*  94:    */   
/*  95:    */   public void setFocus()
/*  96:    */   {
/*  97:134 */     if (this.checkboxWidget != null) {
/*  98:135 */       this.checkboxWidget.requestFocus();
/*  99:    */     }
/* 100:    */   }
/* 101:    */   
/* 102:140 */   private static WidgetCreator widgetCreator = null;
/* 103:    */   
/* 104:    */   public static void registerWidgetCreator(WidgetCreator wc)
/* 105:    */   {
/* 106:143 */     widgetCreator = wc;
/* 107:    */   }
/* 108:    */   
/* 109:    */   public void setStateOnCheckBoxWidget(boolean value)
/* 110:    */   {
/* 111:152 */     this.checkboxWidget.setState(value);
/* 112:    */   }
/* 113:    */   
/* 114:    */   protected AbstractWidget createWidget()
/* 115:    */   {
/* 116:156 */     return widgetCreator.createWidget();
/* 117:    */   }
/* 118:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.controls.CheckboxControl
 * JD-Core Version:    0.7.0.1
 */