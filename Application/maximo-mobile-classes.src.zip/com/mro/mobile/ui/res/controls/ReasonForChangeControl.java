/*   1:    */ package com.mro.mobile.ui.res.controls;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.ui.LookupManager;
/*   5:    */ import com.mro.mobile.ui.MobileMboDataBean;
/*   6:    */ import com.mro.mobile.ui.event.UIEvent;
/*   7:    */ import com.mro.mobile.ui.res.ControlData;
/*   8:    */ import com.mro.mobile.ui.res.UIUtil;
/*   9:    */ import com.mro.mobile.ui.res.widgets.def.AbstractWidget;
/*  10:    */ import com.mro.mobile.ui.res.widgets.def.ReasonForChangeWidget;
/*  11:    */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  12:    */ import com.mro.mobile.ui.res.widgets.def.WidgetCreator;
/*  13:    */ import java.util.Iterator;
/*  14:    */ import java.util.Vector;
/*  15:    */ 
/*  16:    */ public class ReasonForChangeControl
/*  17:    */   extends InputControl
/*  18:    */   implements FocusableControl
/*  19:    */ {
/*  20: 40 */   Vector changeReasonList = new Vector();
/*  21: 41 */   private static String STYLEKEY = "dropdown";
/*  22:    */   
/*  23:    */   protected ReasonForChangeWidget getReasonForChangeWidget()
/*  24:    */   {
/*  25: 47 */     return (ReasonForChangeWidget)super.getWidget();
/*  26:    */   }
/*  27:    */   
/*  28:    */   public UIComponent[] composeComponents()
/*  29:    */     throws MobileApplicationException
/*  30:    */   {
/*  31: 52 */     ReasonForChangeWidget widget = getReasonForChangeWidget();
/*  32:    */     
/*  33: 54 */     populateChangeReasonList();
/*  34: 56 */     if (this.changeReasonList.size() > 1)
/*  35:    */     {
/*  36: 58 */       widget.createReasonForChange(getStringValue("id"));
/*  37: 59 */       return getChangeReasonDropDown(this.changeReasonList);
/*  38:    */     }
/*  39: 61 */     int size = getIntValue("size");
/*  40: 62 */     widget.createChangeReasonTextBox(size);
/*  41:    */     
/*  42: 64 */     return widget.resolveReasonForChangeComponents();
/*  43:    */   }
/*  44:    */   
/*  45:    */   protected boolean performEvent(UIEvent event)
/*  46:    */     throws MobileApplicationException
/*  47:    */   {
/*  48: 71 */     return false;
/*  49:    */   }
/*  50:    */   
/*  51:    */   protected boolean handleException(UIEvent event, Exception exception)
/*  52:    */   {
/*  53: 78 */     return false;
/*  54:    */   }
/*  55:    */   
/*  56:    */   protected boolean refreshControl(UIEvent event)
/*  57:    */     throws MobileApplicationException
/*  58:    */   {
/*  59: 89 */     return true;
/*  60:    */   }
/*  61:    */   
/*  62:    */   private void populateChangeReasonList()
/*  63:    */     throws MobileApplicationException
/*  64:    */   {
/*  65: 94 */     this.changeReasonList.clear();
/*  66: 95 */     MobileMboDataBean domainbean = UIUtil.getLookupManager().createLookupDomainBean("ESIGREASON");
/*  67:    */     
/*  68:    */ 
/*  69: 98 */     String domainid = null;
/*  70: 99 */     if ((domainbean == null) || (domainbean.count() < 1)) {
/*  71:101 */       return;
/*  72:    */     }
/*  73:104 */     int cnt = domainbean.count();
/*  74:105 */     for (int i = 0; i < cnt; i++)
/*  75:    */     {
/*  76:107 */       domainbean.setCurrentPosition(i);
/*  77:108 */       String desc = domainbean.getValue("DESCRIPTION");
/*  78:109 */       this.changeReasonList.add(desc);
/*  79:    */     }
/*  80:    */   }
/*  81:    */   
/*  82:    */   private UIComponent[] getChangeReasonDropDown(Vector chgReasonList)
/*  83:    */     throws MobileApplicationException
/*  84:    */   {
/*  85:117 */     Iterator i = chgReasonList.iterator();
/*  86:119 */     if (i.hasNext()) {
/*  87:121 */       i.next();
/*  88:    */     }
/*  89:123 */     while (i.hasNext()) {
/*  90:125 */       getReasonForChangeWidget().addItemToReasonDropdown((String)i.next(), getStyle(STYLEKEY));
/*  91:    */     }
/*  92:128 */     String label = getLabel();
/*  93:129 */     return getReasonForChangeWidget().resolveChangeReasonDropDownComponents(label);
/*  94:    */   }
/*  95:    */   
/*  96:    */   public AbstractMobileControl createControl(ControlData controlData)
/*  97:    */     throws MobileApplicationException
/*  98:    */   {
/*  99:135 */     return new ReasonForChangeControl();
/* 100:    */   }
/* 101:    */   
/* 102:    */   public String getControlValue()
/* 103:    */   {
/* 104:140 */     return getReasonForChangeWidget().getControlValue();
/* 105:    */   }
/* 106:    */   
/* 107:    */   public void setFocus()
/* 108:    */   {
/* 109:148 */     getReasonForChangeWidget().setChangeReasonTextBoxFocus();
/* 110:    */   }
/* 111:    */   
/* 112:151 */   private static WidgetCreator widgetCreator = null;
/* 113:    */   
/* 114:    */   public static void registerWidgetCreator(WidgetCreator wc)
/* 115:    */   {
/* 116:154 */     widgetCreator = wc;
/* 117:    */   }
/* 118:    */   
/* 119:    */   protected AbstractWidget createWidget()
/* 120:    */   {
/* 121:158 */     return widgetCreator.createWidget();
/* 122:    */   }
/* 123:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.controls.ReasonForChangeControl
 * JD-Core Version:    0.7.0.1
 */