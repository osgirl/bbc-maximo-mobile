/*   1:    */ package com.mro.mobile.ui.res.controls;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.ui.event.UIEvent;
/*   5:    */ import com.mro.mobile.ui.res.ControlData;
/*   6:    */ import com.mro.mobile.ui.res.widgets.def.AbstractWidget;
/*   7:    */ import com.mro.mobile.ui.res.widgets.def.ToolBarRightWidget;
/*   8:    */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*   9:    */ import com.mro.mobile.ui.res.widgets.def.WidgetCreator;
/*  10:    */ 
/*  11:    */ public class ToolBarRightControl
/*  12:    */   extends ToolBarContainerControl
/*  13:    */ {
/*  14:    */   protected ToolBarRightWidget getToolBarRightWidget()
/*  15:    */   {
/*  16: 39 */     return (ToolBarRightWidget)super.getWidget();
/*  17:    */   }
/*  18:    */   
/*  19: 42 */   private static WidgetCreator widgetCreator = null;
/*  20:    */   
/*  21:    */   public static void registerWidgetCreator(WidgetCreator wc)
/*  22:    */   {
/*  23: 45 */     widgetCreator = wc;
/*  24:    */   }
/*  25:    */   
/*  26:    */   public UIComponent[] composeComponents()
/*  27:    */     throws MobileApplicationException
/*  28:    */   {
/*  29: 51 */     return getToolbar("right");
/*  30:    */   }
/*  31:    */   
/*  32:    */   protected boolean performEvent(UIEvent event)
/*  33:    */     throws MobileApplicationException
/*  34:    */   {
/*  35: 62 */     return false;
/*  36:    */   }
/*  37:    */   
/*  38:    */   protected boolean handleException(UIEvent event, Exception exception)
/*  39:    */   {
/*  40: 71 */     return false;
/*  41:    */   }
/*  42:    */   
/*  43:    */   protected boolean refreshControl(UIEvent event)
/*  44:    */   {
/*  45: 80 */     return true;
/*  46:    */   }
/*  47:    */   
/*  48:    */   public AbstractMobileControl createControl(ControlData controlData)
/*  49:    */     throws MobileApplicationException
/*  50:    */   {
/*  51: 89 */     return new ToolBarRightControl();
/*  52:    */   }
/*  53:    */   
/*  54:    */   protected boolean init()
/*  55:    */   {
/*  56: 98 */     return false;
/*  57:    */   }
/*  58:    */   
/*  59:    */   protected AbstractWidget createWidget()
/*  60:    */   {
/*  61:102 */     return widgetCreator.createWidget();
/*  62:    */   }
/*  63:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.controls.ToolBarRightControl
 * JD-Core Version:    0.7.0.1
 */