/*   1:    */ package com.mro.mobile.ui.res.controls;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.ui.event.UIEvent;
/*   5:    */ import com.mro.mobile.ui.res.ControlData;
/*   6:    */ import com.mro.mobile.ui.res.widgets.def.AbstractWidget;
/*   7:    */ import com.mro.mobile.ui.res.widgets.def.TabWidget;
/*   8:    */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*   9:    */ import com.mro.mobile.ui.res.widgets.def.WidgetCreator;
/*  10:    */ import java.util.ArrayList;
/*  11:    */ import java.util.Iterator;
/*  12:    */ 
/*  13:    */ public class TabControl
/*  14:    */   extends AbstractMobileControl
/*  15:    */ {
/*  16: 41 */   private AbstractMobileControl shownToolBar = null;
/*  17: 42 */   private boolean scrollableSection = true;
/*  18: 43 */   private boolean tabRendered = false;
/*  19:    */   
/*  20:    */   protected TabWidget getTabWidget()
/*  21:    */   {
/*  22: 49 */     return (TabWidget)super.getWidget();
/*  23:    */   }
/*  24:    */   
/*  25: 52 */   private static WidgetCreator widgetCreator = null;
/*  26:    */   
/*  27:    */   public static void registerWidgetCreator(WidgetCreator wc)
/*  28:    */   {
/*  29: 55 */     widgetCreator = wc;
/*  30:    */   }
/*  31:    */   
/*  32:    */   protected boolean init()
/*  33:    */   {
/*  34: 60 */     return true;
/*  35:    */   }
/*  36:    */   
/*  37:    */   public AbstractMobileControl createControl(ControlData controlData)
/*  38:    */     throws MobileApplicationException
/*  39:    */   {
/*  40: 65 */     return new TabControl();
/*  41:    */   }
/*  42:    */   
/*  43:    */   public UIComponent[] composeComponents()
/*  44:    */     throws MobileApplicationException
/*  45:    */   {
/*  46: 70 */     sendInitEvent();
/*  47:    */     
/*  48:    */ 
/*  49:    */ 
/*  50: 74 */     TabWidget widget = getTabWidget();
/*  51: 75 */     widget.createTabPanel(getStringValue("id"));
/*  52: 76 */     return widget.resolveTabComponents();
/*  53:    */   }
/*  54:    */   
/*  55:    */   public void renderCurrentTab()
/*  56:    */     throws MobileApplicationException
/*  57:    */   {
/*  58: 85 */     TabWidget widget = getTabWidget();
/*  59: 86 */     composeChildren();
/*  60: 87 */     addToolbar();
/*  61: 88 */     addMenubar();
/*  62: 89 */     if (this.scrollableSection)
/*  63:    */     {
/*  64: 91 */       if (!isUiTestMode()) {
/*  65: 92 */         this.parentControl.setScrollableSection(false);
/*  66:    */       }
/*  67: 94 */       widget.setPanelLayoutForCurrentTab();
/*  68:    */       
/*  69: 96 */       boolean centerSet = false;
/*  70: 97 */       ArrayList south = null;
/*  71: 98 */       Iterator i = getChildren();
/*  72: 99 */       if (i != null)
/*  73:    */       {
/*  74:101 */         while (i.hasNext())
/*  75:    */         {
/*  76:103 */           AbstractMobileControl control = (AbstractMobileControl)i.next();
/*  77:104 */           if (!centerSet)
/*  78:    */           {
/*  79:106 */             if (!(control instanceof MenuBarControl))
/*  80:    */             {
/*  81:112 */               UIComponent[] components = control.getComponents();
/*  82:113 */               if (components != null)
/*  83:    */               {
/*  84:115 */                 centerSet = true;
/*  85:116 */                 widget.addComponentToCurrentTab(components[0]);
/*  86:    */               }
/*  87:    */             }
/*  88:    */           }
/*  89:    */           else
/*  90:    */           {
/*  91:122 */             if (south == null) {
/*  92:123 */               south = new ArrayList();
/*  93:    */             }
/*  94:124 */             south.add(control);
/*  95:    */           }
/*  96:    */         }
/*  97:128 */         if (south != null) {
/*  98:130 */           widget.addControlsToSouthPanel(south);
/*  99:    */         }
/* 100:    */       }
/* 101:133 */       widget.addControlsToTab();
/* 102:    */     }
/* 103:    */     else
/* 104:    */     {
/* 105:137 */       widget.addControlsToTabPanel(this.childControls);
/* 106:    */     }
/* 107:    */   }
/* 108:    */   
/* 109:    */   protected boolean performEvent(UIEvent event)
/* 110:    */     throws MobileApplicationException
/* 111:    */   {
/* 112:142 */     return getTabWidget().performEvent(event);
/* 113:    */   }
/* 114:    */   
/* 115:    */   public void refresh(UIEvent clientEvent)
/* 116:    */     throws MobileApplicationException
/* 117:    */   {
/* 118:152 */     if (((this.parentControl instanceof TabGroupControl)) && (((TabGroupControl)this.parentControl).getCurrentTab() == this))
/* 119:    */     {
/* 120:154 */       if ((refreshControl(clientEvent)) && (hasChildren()))
/* 121:    */       {
/* 122:156 */         Iterator i = getChildren();
/* 123:157 */         while (i.hasNext())
/* 124:    */         {
/* 125:159 */           AbstractMobileControl child = (AbstractMobileControl)i.next();
/* 126:160 */           child.refresh(clientEvent);
/* 127:    */         }
/* 128:    */       }
/* 129:    */     }
/* 130:    */     else {
/* 131:165 */       sendDisplayEvent();
/* 132:    */     }
/* 133:    */   }
/* 134:    */   
/* 135:    */   protected boolean refreshControl(UIEvent event)
/* 136:    */   {
/* 137:170 */     return true;
/* 138:    */   }
/* 139:    */   
/* 140:    */   protected boolean handleException(UIEvent event, Exception exception)
/* 141:    */   {
/* 142:175 */     return false;
/* 143:    */   }
/* 144:    */   
/* 145:    */   public boolean isVisible()
/* 146:    */   {
/* 147:180 */     return getTabWidget().isTabPanelVisible();
/* 148:    */   }
/* 149:    */   
/* 150:    */   public AbstractMobileControl getToolBar()
/* 151:    */   {
/* 152:188 */     return this.shownToolBar;
/* 153:    */   }
/* 154:    */   
/* 155:    */   public void setToolBar(AbstractMobileControl toolBar)
/* 156:    */   {
/* 157:195 */     if ((toolBar == null) && (this.myToolBar != null)) {
/* 158:196 */       this.shownToolBar = this.myToolBar;
/* 159:    */     } else {
/* 160:198 */       this.shownToolBar = toolBar;
/* 161:    */     }
/* 162:    */   }
/* 163:    */   
/* 164:    */   public void setScrollableSection(boolean scrollableSection)
/* 165:    */   {
/* 166:206 */     this.scrollableSection = scrollableSection;
/* 167:    */   }
/* 168:    */   
/* 169:    */   public boolean isTabRendered()
/* 170:    */   {
/* 171:213 */     return this.tabRendered;
/* 172:    */   }
/* 173:    */   
/* 174:    */   public void setTabRendered(boolean tabRendered)
/* 175:    */   {
/* 176:219 */     this.tabRendered = tabRendered;
/* 177:    */   }
/* 178:    */   
/* 179:    */   protected AbstractWidget createWidget()
/* 180:    */   {
/* 181:223 */     return widgetCreator.createWidget();
/* 182:    */   }
/* 183:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.controls.TabControl
 * JD-Core Version:    0.7.0.1
 */