/*   1:    */ package com.mro.mobile.ui.res.controls;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.ui.event.UIEvent;
/*   5:    */ import com.mro.mobile.ui.res.ControlData;
/*   6:    */ import com.mro.mobile.ui.res.widgets.def.AbstractWidget;
/*   7:    */ import com.mro.mobile.ui.res.widgets.def.LinkWidget;
/*   8:    */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*   9:    */ import com.mro.mobile.ui.res.widgets.def.WidgetCreator;
/*  10:    */ 
/*  11:    */ public class LinkControl
/*  12:    */   extends AbstractMobileControl
/*  13:    */ {
/*  14:    */   protected LinkWidget getLinkWidget()
/*  15:    */   {
/*  16: 41 */     return (LinkWidget)super.getWidget();
/*  17:    */   }
/*  18:    */   
/*  19:    */   public UIComponent addLine(UIComponent link)
/*  20:    */   {
/*  21: 46 */     return getLinkWidget().addLinkLine(link);
/*  22:    */   }
/*  23:    */   
/*  24:    */   public UIComponent[] composeComponents()
/*  25:    */     throws MobileApplicationException
/*  26:    */   {
/*  27: 51 */     getLinkWidget().createLinkField(getStringValue("label"), this);
/*  28: 52 */     getLinkWidget().setController(this);
/*  29: 53 */     getLinkWidget().setControlID(getStringValue("id"));
/*  30: 54 */     getLinkWidget().setDisplayAttribute(getStringValue("displayattribute"));
/*  31: 55 */     getLinkWidget().setDisplayEvent(getStringValue("displayevent"));
/*  32: 56 */     getLinkWidget().setDataAttribute(getStringValue("dataattribute"));
/*  33: 57 */     getLinkWidget().setDisplayCount(getBooleanValue("displaycount"));
/*  34:    */     
/*  35: 59 */     return getLinkWidget().resolveLinkComponents();
/*  36:    */   }
/*  37:    */   
/*  38:    */   public boolean handleEvent(UIEvent event)
/*  39:    */   {
/*  40: 67 */     String eventType = event.getEventName();
/*  41: 68 */     event.setValue(getLinkWidget().getLinkValue());
/*  42: 69 */     return super.handleEvent(event);
/*  43:    */   }
/*  44:    */   
/*  45:    */   protected boolean performEvent(UIEvent event)
/*  46:    */     throws MobileApplicationException
/*  47:    */   {
/*  48: 77 */     return false;
/*  49:    */   }
/*  50:    */   
/*  51:    */   protected boolean isButtonDisplayable(String displayattr, String displayevent)
/*  52:    */     throws MobileApplicationException
/*  53:    */   {
/*  54: 90 */     if (displayevent != null) {
/*  55: 92 */       return handleEvent(displayevent, null, null);
/*  56:    */     }
/*  57: 97 */     return true;
/*  58:    */   }
/*  59:    */   
/*  60:    */   protected boolean handleException(UIEvent event, Exception exception)
/*  61:    */   {
/*  62:106 */     return false;
/*  63:    */   }
/*  64:    */   
/*  65:    */   protected boolean refreshControl(UIEvent event)
/*  66:    */     throws MobileApplicationException
/*  67:    */   {
/*  68:114 */     getLinkWidget().refreshLink(getLabel());
/*  69:115 */     return true;
/*  70:    */   }
/*  71:    */   
/*  72:    */   public AbstractMobileControl createControl(ControlData controlData)
/*  73:    */     throws MobileApplicationException
/*  74:    */   {
/*  75:120 */     return new LinkControl();
/*  76:    */   }
/*  77:    */   
/*  78:    */   protected boolean init()
/*  79:    */   {
/*  80:130 */     return false;
/*  81:    */   }
/*  82:    */   
/*  83:    */   public Object getLink()
/*  84:    */   {
/*  85:137 */     return getLinkWidget().getLinkField();
/*  86:    */   }
/*  87:    */   
/*  88:140 */   private static WidgetCreator widgetCreator = null;
/*  89:    */   
/*  90:    */   public static void registerWidgetCreator(WidgetCreator wc)
/*  91:    */   {
/*  92:143 */     widgetCreator = wc;
/*  93:    */   }
/*  94:    */   
/*  95:    */   protected AbstractWidget createWidget()
/*  96:    */   {
/*  97:147 */     return widgetCreator.createWidget();
/*  98:    */   }
/*  99:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.controls.LinkControl
 * JD-Core Version:    0.7.0.1
 */