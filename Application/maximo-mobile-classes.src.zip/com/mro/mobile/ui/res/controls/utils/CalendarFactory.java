/*  1:   */ package com.mro.mobile.ui.res.controls.utils;
/*  2:   */ 
/*  3:   */ import java.util.ArrayList;
/*  4:   */ import java.util.Calendar;
/*  5:   */ import java.util.Date;
/*  6:   */ 
/*  7:   */ public class CalendarFactory
/*  8:   */ {
/*  9:   */   private static ArrayList getCurrentCalendar(long inDateTimeMillis, int StartofTheWeek)
/* 10:   */   {
/* 11:40 */     Calendar cal = Calendar.getInstance();
/* 12:41 */     cal.setTime(new Date(inDateTimeMillis));
/* 13:   */     
/* 14:43 */     cal.set(5, 1);
/* 15:44 */     ArrayList calendarList = new ArrayList();
/* 16:45 */     int startPosition = cal.get(7) - 1 * StartofTheWeek;
/* 17:47 */     if (startPosition < 0) {
/* 18:49 */       startPosition = 7 + startPosition;
/* 19:   */     }
/* 20:51 */     int curMonth = cal.get(2);
/* 21:52 */     for (int i = 0; i < 7; i++) {
/* 22:53 */       for (int j = 0; j < 7; j++)
/* 23:   */       {
/* 24:54 */         if ((j < startPosition) && (i == 0))
/* 25:   */         {
/* 26:55 */           calendarList.add(new Integer(0));
/* 27:   */         }
/* 28:   */         else
/* 29:   */         {
/* 30:57 */           calendarList.add(new Integer(cal.get(5)));
/* 31:58 */           cal.add(5, 1);
/* 32:   */         }
/* 33:60 */         if (curMonth != cal.get(2))
/* 34:   */         {
/* 35:61 */           j = 99;
/* 36:62 */           i = 99;
/* 37:   */         }
/* 38:   */       }
/* 39:   */     }
/* 40:66 */     return calendarList;
/* 41:   */   }
/* 42:   */   
/* 43:   */   public static ArrayList getCalendarData(long timeMillis, int stOfWeek)
/* 44:   */   {
/* 45:71 */     return getCurrentCalendar(timeMillis, stOfWeek);
/* 46:   */   }
/* 47:   */   
/* 48:   */   public static ArrayList getCalendarData(int stOfWeek)
/* 49:   */   {
/* 50:77 */     return getCurrentCalendar(System.currentTimeMillis(), stOfWeek);
/* 51:   */   }
/* 52:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.controls.utils.CalendarFactory
 * JD-Core Version:    0.7.0.1
 */