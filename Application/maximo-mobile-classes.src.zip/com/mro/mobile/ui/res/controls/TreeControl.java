/*   1:    */ package com.mro.mobile.ui.res.controls;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.mbo.MobileMboQBE;
/*   5:    */ import com.mro.mobile.persist.QBEData;
/*   6:    */ import com.mro.mobile.ui.MobileMboDataBean;
/*   7:    */ import com.mro.mobile.ui.event.UIEvent;
/*   8:    */ import com.mro.mobile.ui.res.ControlData;
/*   9:    */ import com.mro.mobile.ui.res.controls.utils.TreeNodeData;
/*  10:    */ import com.mro.mobile.ui.res.widgets.def.AbstractWidget;
/*  11:    */ import com.mro.mobile.ui.res.widgets.def.TreeWidget;
/*  12:    */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  13:    */ import com.mro.mobile.ui.res.widgets.def.WidgetCreator;
/*  14:    */ import com.mro.mobile.util.MobileLogger;
/*  15:    */ import java.util.Enumeration;
/*  16:    */ import java.util.Hashtable;
/*  17:    */ import java.util.Iterator;
/*  18:    */ import java.util.Vector;
/*  19:    */ 
/*  20:    */ public class TreeControl
/*  21:    */   extends AbstractMobileControl
/*  22:    */ {
/*  23:    */   public static final String STYLEKEY = "tree";
/*  24: 46 */   private Hashtable savePointQBESet = new Hashtable();
/*  25: 47 */   private boolean reason4ExitTreeSelect = false;
/*  26:    */   
/*  27:    */   public AbstractMobileControl createControl(ControlData controlData)
/*  28:    */     throws MobileApplicationException
/*  29:    */   {
/*  30: 51 */     return new TreeControl();
/*  31:    */   }
/*  32:    */   
/*  33:    */   public TreeWidget getTreeWidget()
/*  34:    */   {
/*  35: 58 */     return (TreeWidget)super.getWidget();
/*  36:    */   }
/*  37:    */   
/*  38:    */   public UIComponent[] composeComponents()
/*  39:    */     throws MobileApplicationException
/*  40:    */   {
/*  41: 67 */     String label = getLabel();
/*  42: 68 */     return getTreeWidget().createBaseTree(label, this);
/*  43:    */   }
/*  44:    */   
/*  45:    */   protected boolean performEvent(UIEvent event)
/*  46:    */     throws MobileApplicationException
/*  47:    */   {
/*  48: 76 */     String eventName = event.getEventName();
/*  49: 77 */     if (eventName.equalsIgnoreCase("scan4Children"))
/*  50:    */     {
/*  51: 79 */       Object selItem = event.getValue();
/*  52: 80 */       if (selItem != null)
/*  53:    */       {
/*  54: 82 */         setReason4ExitTreeSelect(false);
/*  55: 83 */         getTreeWidget().selectTreeRoot();
/*  56:    */         
/*  57: 85 */         TreeNodeData selectedTreeNode = getTreeWidget().getSelectedTreeNodeData(selItem);
/*  58: 87 */         if (selectedTreeNode.look4Children())
/*  59:    */         {
/*  60: 89 */           getDataBean().setCurrentPosition(selectedTreeNode.getIndex());
/*  61:    */           
/*  62:    */ 
/*  63: 92 */           buildBranchTreeModel(selItem, selectedTreeNode);
/*  64:    */         }
/*  65:    */       }
/*  66: 97 */       return true;
/*  67:    */     }
/*  68: 99 */     if (eventName.equalsIgnoreCase("gotopage"))
/*  69:    */     {
/*  70:101 */       if ((event.getCreatingObject() instanceof MenuItemControl))
/*  71:    */       {
/*  72:103 */         Object selItem = getTreeWidget().getSelectedItem();
/*  73:104 */         if (selItem != null)
/*  74:    */         {
/*  75:106 */           setReason4ExitTreeSelect(true);
/*  76:107 */           setSavePointQBE();
/*  77:108 */           TreeNodeData selectedTreeNode = getTreeWidget().getSelectedTreeNodeData(selItem);
/*  78:    */           
/*  79:110 */           selectedTreeNode.setActualParentIndex(getTreeWidget().getActualIndex().get(selectedTreeNode.getDisplayValue()));
/*  80:111 */           UIEvent uievent = new UIEvent(this, getStringValue("treenodeevent"), null, selectedTreeNode);
/*  81:112 */           handleEvent(uievent);
/*  82:    */         }
/*  83:    */       }
/*  84:115 */       return false;
/*  85:    */     }
/*  86:117 */     if (eventName.equalsIgnoreCase("treeselect"))
/*  87:    */     {
/*  88:119 */       Object selItem = event.getValue();
/*  89:120 */       if (selItem != null)
/*  90:    */       {
/*  91:122 */         TreeNodeData selectedTreeNode = getTreeWidget().getSelectedTreeNodeData(selItem);
/*  92:    */         
/*  93:124 */         selectedTreeNode.setActualParentIndex(getTreeWidget().getActualIndex().get(selectedTreeNode.getDisplayValue()));
/*  94:125 */         UIEvent uievent = new UIEvent(this, getStringValue("treenodeevent"), null, selectedTreeNode);
/*  95:126 */         setSavePointQBE();
/*  96:127 */         handleEvent(uievent);
/*  97:    */       }
/*  98:129 */       return true;
/*  99:    */     }
/* 100:131 */     return false;
/* 101:    */   }
/* 102:    */   
/* 103:    */   private void buildBaseTreeModel()
/* 104:    */     throws MobileApplicationException
/* 105:    */   {
/* 106:136 */     getTreeWidget().buildBaseTreeModel();
/* 107:    */   }
/* 108:    */   
/* 109:    */   private void buildBranchTreeModel(Object curItem, TreeNodeData inTreeNode)
/* 110:    */     throws MobileApplicationException
/* 111:    */   {
/* 112:142 */     UIEvent uievent = new UIEvent(this, getStringValue("treebranchevent"), null, inTreeNode);
/* 113:143 */     if (handleEvent(uievent))
/* 114:    */     {
/* 115:145 */       Enumeration treeNodes = ((Vector)uievent.getValue()).elements();
/* 116:146 */       int iCount = -1;
/* 117:147 */       while (treeNodes.hasMoreElements())
/* 118:    */       {
/* 119:149 */         iCount++;
/* 120:150 */         getTreeWidget().addElementToBranchTree(curItem, treeNodes.nextElement(), iCount);
/* 121:    */       }
/* 122:    */     }
/* 123:    */   }
/* 124:    */   
/* 125:    */   public Object getPopUpContrl(String controlId)
/* 126:    */   {
/* 127:159 */     Iterator i = getChildren();
/* 128:160 */     AbstractMobileControl child = null;
/* 129:161 */     while ((i != null) && (i.hasNext()))
/* 130:    */     {
/* 131:163 */       child = (AbstractMobileControl)i.next();
/* 132:164 */       if (child.getId().equalsIgnoreCase(controlId)) {
/* 133:    */         break;
/* 134:    */       }
/* 135:    */     }
/* 136:    */     try
/* 137:    */     {
/* 138:172 */       UIComponent[] childComps = child.composeComponents();
/* 139:173 */       if (childComps != null) {
/* 140:174 */         return childComps[0];
/* 141:    */       }
/* 142:    */     }
/* 143:    */     catch (MobileApplicationException e)
/* 144:    */     {
/* 145:178 */       getDefaultLogger().warn("Failed to get PopUp control for controlId: " + controlId, e);
/* 146:    */     }
/* 147:181 */     return null;
/* 148:    */   }
/* 149:    */   
/* 150:    */   protected boolean handleException(UIEvent event, Exception exception)
/* 151:    */   {
/* 152:186 */     return false;
/* 153:    */   }
/* 154:    */   
/* 155:    */   protected boolean refreshControl(UIEvent event)
/* 156:    */     throws MobileApplicationException
/* 157:    */   {
/* 158:195 */     if (getTreeWidget().isTreeValid())
/* 159:    */     {
/* 160:197 */       getTreeWidget().removeChildren();
/* 161:199 */       if (isReason4ExitTreeSelect()) {
/* 162:201 */         resetSavePointQBE();
/* 163:    */       } else {
/* 164:203 */         setSavePointQBE();
/* 165:    */       }
/* 166:205 */       buildBaseTreeModel();
/* 167:    */       
/* 168:207 */       setReason4ExitTreeSelect(false);
/* 169:    */     }
/* 170:209 */     return false;
/* 171:    */   }
/* 172:    */   
/* 173:    */   public void setSavePointQBE()
/* 174:    */     throws MobileApplicationException
/* 175:    */   {
/* 176:215 */     this.savePointQBESet.clear();
/* 177:216 */     MobileMboQBE curQBE = getDataBean().getQBE();
/* 178:217 */     Enumeration e = curQBE.getQBEAttributes();
/* 179:218 */     while (e.hasMoreElements())
/* 180:    */     {
/* 181:220 */       String key = (String)e.nextElement();
/* 182:221 */       this.savePointQBESet.put(key, curQBE.getQBEData(key).getInternalValue());
/* 183:    */     }
/* 184:    */   }
/* 185:    */   
/* 186:    */   public void resetSavePointQBE()
/* 187:    */     throws MobileApplicationException
/* 188:    */   {
/* 189:227 */     if (this.savePointQBESet.size() > 0)
/* 190:    */     {
/* 191:229 */       getDataBean().getQBE().reset();
/* 192:230 */       Enumeration attrs = this.savePointQBESet.keys();
/* 193:231 */       while (attrs.hasMoreElements())
/* 194:    */       {
/* 195:233 */         String key = (String)attrs.nextElement();
/* 196:234 */         getDataBean().getQBE().setQBE(key, (String)this.savePointQBESet.get(key));
/* 197:    */       }
/* 198:236 */       this.savePointQBESet.clear();
/* 199:237 */       getDataBean().reset();
/* 200:    */     }
/* 201:    */   }
/* 202:    */   
/* 203:    */   public boolean isReason4ExitTreeSelect()
/* 204:    */   {
/* 205:245 */     return this.reason4ExitTreeSelect;
/* 206:    */   }
/* 207:    */   
/* 208:    */   public void setReason4ExitTreeSelect(boolean reason4ExitTreeSelect)
/* 209:    */   {
/* 210:251 */     this.reason4ExitTreeSelect = reason4ExitTreeSelect;
/* 211:    */   }
/* 212:    */   
/* 213:254 */   private static WidgetCreator widgetCreator = null;
/* 214:    */   
/* 215:    */   public static void registerWidgetCreator(WidgetCreator wc)
/* 216:    */   {
/* 217:257 */     widgetCreator = wc;
/* 218:    */   }
/* 219:    */   
/* 220:    */   protected AbstractWidget createWidget()
/* 221:    */   {
/* 222:261 */     return widgetCreator.createWidget();
/* 223:    */   }
/* 224:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.controls.TreeControl
 * JD-Core Version:    0.7.0.1
 */