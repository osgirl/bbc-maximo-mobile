/*   1:    */ package com.mro.mobile.ui.res.controls;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.mbo.MobileMbo;
/*   5:    */ import com.mro.mobile.ui.MobileMboDataBean;
/*   6:    */ import com.mro.mobile.ui.MobileMboDataBeanManager;
/*   7:    */ import com.mro.mobile.ui.event.UIEvent;
/*   8:    */ import com.mro.mobile.ui.res.ControlData;
/*   9:    */ import com.mro.mobile.ui.res.UIUtil;
/*  10:    */ import com.mro.mobile.ui.res.widgets.def.AbstractWidget;
/*  11:    */ import com.mro.mobile.ui.res.widgets.def.SignatureCaptureWidget;
/*  12:    */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  13:    */ import com.mro.mobile.ui.res.widgets.def.WidgetCreator;
/*  14:    */ 
/*  15:    */ public class SignatureCaptureControl
/*  16:    */   extends AbstractMobileControl
/*  17:    */ {
/*  18:    */   protected SignatureCaptureWidget getSignatureCaptureWidget()
/*  19:    */   {
/*  20: 43 */     return (SignatureCaptureWidget)super.getWidget();
/*  21:    */   }
/*  22:    */   
/*  23:    */   public UIComponent[] composeComponents()
/*  24:    */     throws MobileApplicationException
/*  25:    */   {
/*  26: 48 */     return getSignatureCaptureWidget().createSignatureCaptureWidget();
/*  27:    */   }
/*  28:    */   
/*  29:    */   protected boolean performEvent(UIEvent event)
/*  30:    */     throws MobileApplicationException
/*  31:    */   {
/*  32: 54 */     if (event.getEventName().equalsIgnoreCase("savesignature"))
/*  33:    */     {
/*  34: 56 */       byte[] byteArr = getSignatureCaptureWidget().getImageData();
/*  35:    */       
/*  36: 58 */       AbstractMobileControl tempCtrl = ((PageControl)UIUtil.getCurrentScreen()).getLaunchingControl();
/*  37: 59 */       if ((tempCtrl instanceof LinkControl))
/*  38:    */       {
/*  39: 61 */         String setAttr = tempCtrl.getStringValue("dataattribute");
/*  40: 62 */         if (setAttr != null)
/*  41:    */         {
/*  42: 64 */           tempCtrl.getDataBean().getMobileMbo().setBinaryValue(setAttr, byteArr);
/*  43:    */           
/*  44:    */ 
/*  45: 67 */           MobileMboDataBean parentDataBean = tempCtrl.getDataBean().getParentBean();
/*  46: 69 */           if ((parentDataBean != null) && (!parentDataBean.getMobileMbo().getBooleanValue("_MODIFIED"))) {
/*  47: 71 */             parentDataBean.getMobileMbo().setBooleanValue("_MODIFIED", true);
/*  48:    */           }
/*  49: 75 */           tempCtrl.getDataBean().getDataBeanManager().save();
/*  50:    */         }
/*  51:    */       }
/*  52: 78 */       UIUtil.closePage();
/*  53: 79 */       return true;
/*  54:    */     }
/*  55: 80 */     if (event.getEventName().equalsIgnoreCase("clearsignature"))
/*  56:    */     {
/*  57: 82 */       getSignatureCaptureWidget().erase();
/*  58: 83 */       return true;
/*  59:    */     }
/*  60: 85 */     return false;
/*  61:    */   }
/*  62:    */   
/*  63:    */   protected boolean handleException(UIEvent event, Exception exception)
/*  64:    */   {
/*  65: 94 */     return false;
/*  66:    */   }
/*  67:    */   
/*  68:    */   protected boolean refreshControl(UIEvent event)
/*  69:    */     throws MobileApplicationException
/*  70:    */   {
/*  71:104 */     return false;
/*  72:    */   }
/*  73:    */   
/*  74:    */   public AbstractMobileControl createControl(ControlData controlData)
/*  75:    */     throws MobileApplicationException
/*  76:    */   {
/*  77:113 */     return new SignatureCaptureControl();
/*  78:    */   }
/*  79:    */   
/*  80:116 */   private static WidgetCreator widgetCreator = null;
/*  81:    */   
/*  82:    */   public static void registerWidgetCreator(WidgetCreator wc)
/*  83:    */   {
/*  84:119 */     widgetCreator = wc;
/*  85:    */   }
/*  86:    */   
/*  87:    */   protected AbstractWidget createWidget()
/*  88:    */   {
/*  89:123 */     return widgetCreator.createWidget();
/*  90:    */   }
/*  91:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.controls.SignatureCaptureControl
 * JD-Core Version:    0.7.0.1
 */