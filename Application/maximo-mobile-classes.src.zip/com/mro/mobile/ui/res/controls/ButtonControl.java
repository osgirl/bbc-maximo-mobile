/*   1:    */ package com.mro.mobile.ui.res.controls;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.ui.event.UIEvent;
/*   5:    */ import com.mro.mobile.ui.res.ControlData;
/*   6:    */ import com.mro.mobile.ui.res.widgets.def.AbstractWidget;
/*   7:    */ import com.mro.mobile.ui.res.widgets.def.ButtonWidget;
/*   8:    */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*   9:    */ import com.mro.mobile.ui.res.widgets.def.WidgetCreator;
/*  10:    */ 
/*  11:    */ public class ButtonControl
/*  12:    */   extends AbstractMobileControl
/*  13:    */ {
/*  14:    */   protected ButtonWidget getButtonWidget()
/*  15:    */   {
/*  16: 40 */     return (ButtonWidget)super.getWidget();
/*  17:    */   }
/*  18:    */   
/*  19:    */   public UIComponent[] composeComponents()
/*  20:    */     throws MobileApplicationException
/*  21:    */   {
/*  22: 49 */     String displayattribute = getStringValue("displayattribute");
/*  23: 50 */     String datasrc = getStringValue("datasrcname");
/*  24: 51 */     String displayevent = getStringValue("displayevent");
/*  25:    */     
/*  26:    */ 
/*  27: 54 */     getButtonWidget().createButtonField(getStringValue("image"), getStringValue("label"));
/*  28:    */     
/*  29: 56 */     getButtonWidget().setAttributeID(getStringValue("id"));
/*  30: 57 */     getButtonWidget().setAttributeValue(getStringValue("value"));
/*  31: 58 */     getButtonWidget().setAttributeTargetId(getStringValue("targetid"));
/*  32: 59 */     getButtonWidget().setAtrributeEvent(getStringValue("event"));
/*  33: 60 */     getButtonWidget().setDefaultButton(getBooleanValue("defaultbutton"));
/*  34:    */     
/*  35: 62 */     return getButtonWidget().resolveButtonComponents();
/*  36:    */   }
/*  37:    */   
/*  38:    */   protected boolean isButtonDisplayable(String displayattr, String displayevent)
/*  39:    */     throws MobileApplicationException
/*  40:    */   {
/*  41: 74 */     if (displayevent != null) {
/*  42: 76 */       return handleEvent(displayevent, null, null);
/*  43:    */     }
/*  44: 81 */     return true;
/*  45:    */   }
/*  46:    */   
/*  47:    */   public boolean handleEvent(UIEvent event)
/*  48:    */   {
/*  49: 89 */     event.setValue(getButtonWidget().getLinkValue());
/*  50: 90 */     return super.handleEvent(event);
/*  51:    */   }
/*  52:    */   
/*  53:    */   protected boolean performEvent(UIEvent event)
/*  54:    */     throws MobileApplicationException
/*  55:    */   {
/*  56: 97 */     return false;
/*  57:    */   }
/*  58:    */   
/*  59:    */   protected boolean handleException(UIEvent event, Exception exception)
/*  60:    */   {
/*  61:106 */     return false;
/*  62:    */   }
/*  63:    */   
/*  64:    */   protected boolean refreshControl(UIEvent event)
/*  65:    */   {
/*  66:114 */     return true;
/*  67:    */   }
/*  68:    */   
/*  69:    */   public AbstractMobileControl createControl(ControlData controlData)
/*  70:    */     throws MobileApplicationException
/*  71:    */   {
/*  72:122 */     return new ButtonControl();
/*  73:    */   }
/*  74:    */   
/*  75:    */   protected boolean init()
/*  76:    */   {
/*  77:128 */     return false;
/*  78:    */   }
/*  79:    */   
/*  80:131 */   private static WidgetCreator widgetCreator = null;
/*  81:    */   
/*  82:    */   public static void registerWidgetCreator(WidgetCreator wc)
/*  83:    */   {
/*  84:134 */     widgetCreator = wc;
/*  85:    */   }
/*  86:    */   
/*  87:    */   protected AbstractWidget createWidget()
/*  88:    */   {
/*  89:138 */     return widgetCreator.createWidget();
/*  90:    */   }
/*  91:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.controls.ButtonControl
 * JD-Core Version:    0.7.0.1
 */