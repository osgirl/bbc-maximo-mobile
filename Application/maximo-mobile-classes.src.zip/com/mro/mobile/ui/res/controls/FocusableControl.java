package com.mro.mobile.ui.res.controls;

public abstract interface FocusableControl
{
  public abstract void setFocus();
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.controls.FocusableControl
 * JD-Core Version:    0.7.0.1
 */