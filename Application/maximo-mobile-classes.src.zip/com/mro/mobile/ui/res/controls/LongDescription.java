/*   1:    */ package com.mro.mobile.ui.res.controls;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.app.BasicMobileDeviceUIApplication;
/*   5:    */ import com.mro.mobile.ui.MobileMboDataBean;
/*   6:    */ import com.mro.mobile.ui.event.UIEvent;
/*   7:    */ import com.mro.mobile.ui.res.ControlData;
/*   8:    */ import com.mro.mobile.ui.res.widgets.def.AbstractWidget;
/*   9:    */ import com.mro.mobile.ui.res.widgets.def.LongDescriptionWidget;
/*  10:    */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  11:    */ import com.mro.mobile.ui.res.widgets.def.WidgetCreator;
/*  12:    */ 
/*  13:    */ public class LongDescription
/*  14:    */   extends MultiLineTextboxControl
/*  15:    */ {
/*  16: 30 */   private static WidgetCreator widgetCreator = null;
/*  17:    */   
/*  18:    */   protected LongDescriptionWidget getLongDescriptionWidget()
/*  19:    */   {
/*  20: 36 */     return (LongDescriptionWidget)super.getWidget();
/*  21:    */   }
/*  22:    */   
/*  23:    */   public AbstractMobileControl createControl(ControlData controlData)
/*  24:    */     throws MobileApplicationException
/*  25:    */   {
/*  26: 40 */     return new LongDescription();
/*  27:    */   }
/*  28:    */   
/*  29:    */   protected boolean performEvent(UIEvent event)
/*  30:    */     throws MobileApplicationException
/*  31:    */   {
/*  32: 44 */     if (super.performEvent(event) == true) {
/*  33: 45 */       return true;
/*  34:    */     }
/*  35: 46 */     String eventType = event.getEventName();
/*  36: 47 */     if (eventType.equalsIgnoreCase("barcoderead")) {
/*  37: 48 */       return barcoderead(event);
/*  38:    */     }
/*  39: 49 */     if (eventType.equalsIgnoreCase("rfidread")) {
/*  40: 50 */       return rfidread(event);
/*  41:    */     }
/*  42: 53 */     return false;
/*  43:    */   }
/*  44:    */   
/*  45:    */   public UIComponent[] composeComponents()
/*  46:    */     throws MobileApplicationException
/*  47:    */   {
/*  48: 58 */     if (!isAttributeSet("enablebarcode")) {
/*  49: 60 */       this.useBarCode = true;
/*  50:    */     }
/*  51: 63 */     if (!isAttributeSet("enablerfid")) {
/*  52: 65 */       this.useRFID = false;
/*  53:    */     }
/*  54: 68 */     String text = null;
/*  55: 69 */     boolean readonly = false;
/*  56: 70 */     AbstractMobileControl ctrl = null;
/*  57: 71 */     if (this.dataAttribute == null)
/*  58:    */     {
/*  59: 72 */       PageControl page = (PageControl)getPage();
/*  60: 73 */       page.setCurrentInput(this);
/*  61:    */       
/*  62: 75 */       ctrl = page.getLaunchingControl();
/*  63: 76 */       if ((ctrl instanceof InputControl))
/*  64:    */       {
/*  65: 77 */         InputControl input = (InputControl)ctrl;
/*  66: 78 */         if ((input.isLongDescReadOnly()) || (input.isReadOnly()))
/*  67:    */         {
/*  68: 79 */           text = input.getLongDesc();
/*  69: 80 */           readonly = true;
/*  70:    */         }
/*  71:    */         else
/*  72:    */         {
/*  73: 82 */           this.dataAttribute = ctrl.getStringValue("longdescattribute");
/*  74: 83 */           text = ctrl.getDataBean().getValue(this.dataAttribute);
/*  75: 84 */           readonly = false;
/*  76:    */         }
/*  77:    */       }
/*  78:    */     }
/*  79: 88 */     if (readonly) {
/*  80: 89 */       addToolbar("ldreadonlybar");
/*  81:    */     } else {
/*  82: 91 */       addToolbar();
/*  83:    */     }
/*  84: 93 */     if (!isUiTestMode()) {
/*  85: 94 */       getPage().setScrollableSection(false);
/*  86:    */     }
/*  87: 97 */     int width = 0;
/*  88: 98 */     if (!isUiTestMode()) {
/*  89: 99 */       width = this.app.getWindowWidth() - 10;
/*  90:    */     } else {
/*  91:102 */       width = 200;
/*  92:    */     }
/*  93:107 */     String textToSet = text == null ? getValue() : text;
/*  94:    */     
/*  95:109 */     return getLongDescriptionWidget().resolveLongDescriptionComponents(textToSet, width, readonly);
/*  96:    */   }
/*  97:    */   
/*  98:    */   public static void registerWidgetCreator(WidgetCreator wc)
/*  99:    */   {
/* 100:113 */     widgetCreator = wc;
/* 101:    */   }
/* 102:    */   
/* 103:    */   protected AbstractWidget createWidget()
/* 104:    */   {
/* 105:117 */     return widgetCreator.createWidget();
/* 106:    */   }
/* 107:    */   
/* 108:    */   public boolean barcoderead(UIEvent event)
/* 109:    */     throws MobileApplicationException
/* 110:    */   {
/* 111:121 */     boolean ret = true;
/* 112:122 */     String val = (String)event.getValue();
/* 113:123 */     String content = getLongDescriptionWidget().getText();
/* 114:124 */     if (val != null)
/* 115:    */     {
/* 116:125 */       content = content + val;
/* 117:126 */       getLongDescriptionWidget().setText(content);
/* 118:    */     }
/* 119:129 */     String scanEvent = getStringValue("scanevent");
/* 120:130 */     if (scanEvent != null)
/* 121:    */     {
/* 122:131 */       UIEvent initEvent = new UIEvent(this, scanEvent, null, getDataBean());
/* 123:132 */       handleEvent(initEvent);
/* 124:    */     }
/* 125:135 */     if (this.dataAttribute != null)
/* 126:    */     {
/* 127:136 */       event.setValue(content);
/* 128:137 */       ret = setvalue(event);
/* 129:    */     }
/* 130:139 */     return ret;
/* 131:    */   }
/* 132:    */   
/* 133:    */   public boolean rfidread(UIEvent event)
/* 134:    */     throws MobileApplicationException
/* 135:    */   {
/* 136:143 */     boolean ret = true;
/* 137:144 */     String val = (String)event.getValue();
/* 138:145 */     String content = getLongDescriptionWidget().getText();
/* 139:146 */     if (val != null)
/* 140:    */     {
/* 141:147 */       content = content + val;
/* 142:148 */       getLongDescriptionWidget().setText(content);
/* 143:    */     }
/* 144:150 */     if (this.dataAttribute != null)
/* 145:    */     {
/* 146:151 */       event.setValue(content);
/* 147:152 */       ret = setvalue(event);
/* 148:    */     }
/* 149:154 */     return ret;
/* 150:    */   }
/* 151:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.controls.LongDescription
 * JD-Core Version:    0.7.0.1
 */