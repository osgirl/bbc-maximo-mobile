/*   1:    */ package com.mro.mobile.ui.res.controls;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.ui.DataBeanCache;
/*   5:    */ import com.mro.mobile.ui.LookupManager;
/*   6:    */ import com.mro.mobile.ui.MobileMboDataBean;
/*   7:    */ import com.mro.mobile.ui.event.UIEvent;
/*   8:    */ import com.mro.mobile.ui.res.ControlData;
/*   9:    */ import com.mro.mobile.ui.res.UIUtil;
/*  10:    */ import com.mro.mobile.ui.res.widgets.def.AbstractWidget;
/*  11:    */ import com.mro.mobile.ui.res.widgets.def.LookupWidget;
/*  12:    */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  13:    */ import com.mro.mobile.ui.res.widgets.def.WidgetCreator;
/*  14:    */ import java.util.StringTokenizer;
/*  15:    */ 
/*  16:    */ public class LookupControl
/*  17:    */   extends PageControl
/*  18:    */ {
/*  19: 46 */   private AbstractMobileControl retInput = null;
/*  20: 47 */   private MobileMboDataBean retBean = null;
/*  21: 48 */   private MobileMboDataBean lookupBean = null;
/*  22:    */   
/*  23:    */   protected LookupWidget getLookupWidget()
/*  24:    */   {
/*  25: 57 */     return (LookupWidget)super.getWidget();
/*  26:    */   }
/*  27:    */   
/*  28:    */   public AbstractMobileControl createControl(ControlData controlData)
/*  29:    */     throws MobileApplicationException
/*  30:    */   {
/*  31: 62 */     return new LookupControl();
/*  32:    */   }
/*  33:    */   
/*  34:    */   public UIComponent[] composeComponents()
/*  35:    */     throws MobileApplicationException
/*  36:    */   {
/*  37: 70 */     UIComponent[] comps = super.composeComponents();
/*  38: 71 */     if (!isAttributeSet("autosave")) {
/*  39: 73 */       this.autoSave = false;
/*  40:    */     }
/*  41: 75 */     return comps;
/*  42:    */   }
/*  43:    */   
/*  44:    */   public MobileMboDataBean getDataBean()
/*  45:    */     throws MobileApplicationException
/*  46:    */   {
/*  47: 81 */     String dataSrc = getStringValue("datasrcname");
/*  48: 82 */     this.lookupBean = DataBeanCache.findDataBean(dataSrc);
/*  49: 83 */     LookupManager luMan = UIUtil.getLookupManager();
/*  50: 84 */     if (this.lookupBean == null)
/*  51:    */     {
/*  52: 86 */       String mobileMboName = getValue("mobilembo");
/*  53: 87 */       this.lookupBean = luMan.createLookupDomainBean(mobileMboName);
/*  54: 88 */       DataBeanCache.cacheDataBean(dataSrc, this.lookupBean);
/*  55:    */     }
/*  56: 90 */     if (this.retInput == null)
/*  57:    */     {
/*  58: 91 */       this.retInput = getLaunchingControl();
/*  59: 92 */       this.retBean = this.retInput.getDataBean();
/*  60: 93 */       this.lookupBean.setParentBean(this.retBean);
/*  61: 94 */       luMan.applyMultisiteFilter(this.lookupBean, this.retBean);
/*  62:    */     }
/*  63: 96 */     return this.lookupBean;
/*  64:    */   }
/*  65:    */   
/*  66:    */   public boolean closepage(UIEvent event)
/*  67:    */     throws MobileApplicationException
/*  68:    */   {
/*  69:102 */     String dataSrc = getStringValue("datasrcname");
/*  70:103 */     if (this.lookupBean != null)
/*  71:    */     {
/*  72:105 */       this.lookupBean.reset();
/*  73:106 */       this.lookupBean.close();
/*  74:107 */       DataBeanCache.removeDataBean(dataSrc);
/*  75:108 */       this.lookupBean = null;
/*  76:    */     }
/*  77:110 */     UIUtil.closePage();
/*  78:111 */     return true;
/*  79:    */   }
/*  80:    */   
/*  81:    */   public boolean select(UIEvent event)
/*  82:    */     throws MobileApplicationException
/*  83:    */   {
/*  84:116 */     MobileMboDataBean dataBean = getDataBean();
/*  85:117 */     if (dataBean != null)
/*  86:    */     {
/*  87:119 */       String returnAttr = getStringValue("returnattribute");
/*  88:120 */       if ((returnAttr != null) && ((!(this.retInput instanceof InputControl)) || (!((InputControl)this.retInput).isReadOnly())))
/*  89:    */       {
/*  90:122 */         if (!this.retInput.validateControl(event, dataBean.getValue(returnAttr)))
/*  91:    */         {
/*  92:124 */           event.setEventErrored();
/*  93:125 */           return true;
/*  94:    */         }
/*  95:127 */         String setAttr = this.retInput.getStringValue("dataattribute");
/*  96:128 */         if (setAttr != null)
/*  97:    */         {
/*  98:130 */           LookupManager luMan = UIUtil.getLookupManager();
/*  99:131 */           luMan.applySelectedLookupValue(dataBean, returnAttr, this.retBean, setAttr);
/* 100:    */           
/* 101:133 */           AbstractMobileControl control = getLaunchingControl();
/* 102:134 */           if ((control instanceof TextboxControl)) {
/* 103:135 */             ((TextboxControl)control).updateForcedAccepted(dataBean.getValue(returnAttr));
/* 104:    */           }
/* 105:    */         }
/* 106:    */       }
/* 107:    */     }
/* 108:140 */     closepage(event);
/* 109:141 */     return true;
/* 110:    */   }
/* 111:    */   
/* 112:    */   public boolean multiselect(UIEvent event)
/* 113:    */     throws MobileApplicationException
/* 114:    */   {
/* 115:146 */     MobileMboDataBean dataBean = getDataBean();
/* 116:147 */     if (dataBean != null)
/* 117:    */     {
/* 118:149 */       String returnAttr = getStringValue("returnattribute");
/* 119:151 */       if ((returnAttr != null) && ((!(this.retInput instanceof InputControl)) || (!((InputControl)this.retInput).isReadOnly())))
/* 120:    */       {
/* 121:153 */         LookupManager luMan = UIUtil.getLookupManager();
/* 122:    */         
/* 123:155 */         String nextsetAttr = getStringValue("nextsetattributes");
/* 124:156 */         String nextreturnAttr = getStringValue("nextreturnattributes");
/* 125:157 */         if (nextsetAttr != null)
/* 126:    */         {
/* 127:159 */           StringTokenizer nextSAtr = new StringTokenizer(nextsetAttr, ",");
/* 128:160 */           StringTokenizer nextRetAtr = new StringTokenizer(nextreturnAttr, ",");
/* 129:161 */           while (nextSAtr.hasMoreTokens()) {
/* 130:163 */             luMan.applySelectedLookupValue(dataBean, nextRetAtr.nextToken().trim(), this.retBean, nextSAtr.nextToken().trim());
/* 131:    */           }
/* 132:    */         }
/* 133:167 */         if (!this.retInput.validateControl(event, dataBean.getValue(returnAttr)))
/* 134:    */         {
/* 135:169 */           event.setEventErrored();
/* 136:170 */           return true;
/* 137:    */         }
/* 138:172 */         String setAttr = this.retInput.getStringValue("dataattribute");
/* 139:173 */         if (setAttr != null) {
/* 140:175 */           luMan.applySelectedLookupValue(dataBean, returnAttr, this.retBean, setAttr);
/* 141:    */         }
/* 142:178 */         AbstractMobileControl control = getLaunchingControl();
/* 143:179 */         if ((control instanceof TextboxControl)) {
/* 144:180 */           ((TextboxControl)control).updateForcedAccepted(dataBean.getValue(returnAttr));
/* 145:    */         }
/* 146:    */       }
/* 147:    */     }
/* 148:184 */     closepage(event);
/* 149:185 */     return true;
/* 150:    */   }
/* 151:    */   
/* 152:    */   public boolean luconnect(UIEvent event)
/* 153:    */     throws MobileApplicationException
/* 154:    */   {
/* 155:191 */     MobileMboDataBean dataBean = getDataBean();
/* 156:193 */     if (getToolBar() != null)
/* 157:    */     {
/* 158:194 */       AbstractMobileControl embeddedControl = getToolBar().getParentControl();
/* 159:195 */       if (embeddedControl != null) {
/* 160:197 */         dataBean = embeddedControl.getDataBean();
/* 161:    */       }
/* 162:    */     }
/* 163:200 */     if (dataBean != null)
/* 164:    */     {
/* 165:202 */       event.setSource(dataBean);
/* 166:203 */       return false;
/* 167:    */     }
/* 168:205 */     return true;
/* 169:    */   }
/* 170:    */   
/* 171:    */   protected boolean performEvent(UIEvent event)
/* 172:    */     throws MobileApplicationException
/* 173:    */   {
/* 174:210 */     String eventType = event.getEventName();
/* 175:211 */     if (eventType.equals("closepage")) {
/* 176:213 */       return closepage(event);
/* 177:    */     }
/* 178:215 */     if (eventType.equals("select")) {
/* 179:217 */       return select(event);
/* 180:    */     }
/* 181:219 */     if (eventType.equals("multiselect")) {
/* 182:221 */       return multiselect(event);
/* 183:    */     }
/* 184:223 */     if (eventType.equals("luconnect")) {
/* 185:225 */       return luconnect(event);
/* 186:    */     }
/* 187:229 */     return super.performEvent(event);
/* 188:    */   }
/* 189:    */   
/* 190:    */   public String getTitle()
/* 191:    */     throws MobileApplicationException
/* 192:    */   {
/* 193:236 */     String title = super.getTitle();
/* 194:237 */     String connected = null;
/* 195:238 */     MobileMboDataBean dataBean = getDataBean();
/* 196:239 */     if (dataBean != null) {
/* 197:241 */       connected = dataBean.isOnline() ? " (Connected)" : " (Disconnected)";
/* 198:    */     }
/* 199:244 */     return title + (connected == null ? "" : connected);
/* 200:    */   }
/* 201:    */   
/* 202:247 */   private static WidgetCreator widgetCreator = null;
/* 203:    */   
/* 204:    */   public static void registerWidgetCreator(WidgetCreator wc)
/* 205:    */   {
/* 206:250 */     widgetCreator = wc;
/* 207:    */   }
/* 208:    */   
/* 209:    */   protected AbstractWidget createWidget()
/* 210:    */   {
/* 211:254 */     return widgetCreator.createWidget();
/* 212:    */   }
/* 213:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.controls.LookupControl
 * JD-Core Version:    0.7.0.1
 */