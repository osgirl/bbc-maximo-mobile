/*   1:    */ package com.mro.mobile.ui.res.controls;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.ui.event.UIEvent;
/*   5:    */ import com.mro.mobile.ui.res.ControlData;
/*   6:    */ import com.mro.mobile.ui.res.widgets.def.AbstractWidget;
/*   7:    */ import com.mro.mobile.ui.res.widgets.def.LabelWidget;
/*   8:    */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*   9:    */ import com.mro.mobile.ui.res.widgets.def.WidgetCreator;
/*  10:    */ 
/*  11:    */ public class LabelControl
/*  12:    */   extends AbstractMobileControl
/*  13:    */ {
/*  14:    */   protected LabelWidget getLabelWidget()
/*  15:    */   {
/*  16: 43 */     return (LabelWidget)super.getWidget();
/*  17:    */   }
/*  18:    */   
/*  19:    */   public AbstractMobileControl createControl(ControlData controlData)
/*  20:    */     throws MobileApplicationException
/*  21:    */   {
/*  22: 48 */     return new LabelControl();
/*  23:    */   }
/*  24:    */   
/*  25:    */   public UIComponent[] composeComponents()
/*  26:    */     throws MobileApplicationException
/*  27:    */   {
/*  28: 56 */     getLabelWidget().createLabelField(getLabel(), this, getIntValue("width"), getBooleanValue("wrap"));
/*  29:    */     
/*  30: 58 */     this.components = getLabelWidget().setLabelAttributes(this);
/*  31:    */     
/*  32: 60 */     return this.components;
/*  33:    */   }
/*  34:    */   
/*  35:    */   protected boolean performEvent(UIEvent event)
/*  36:    */     throws MobileApplicationException
/*  37:    */   {
/*  38: 68 */     return false;
/*  39:    */   }
/*  40:    */   
/*  41:    */   protected boolean handleException(UIEvent event, Exception exception)
/*  42:    */   {
/*  43: 75 */     return false;
/*  44:    */   }
/*  45:    */   
/*  46:    */   protected boolean refreshControl(UIEvent event)
/*  47:    */     throws MobileApplicationException
/*  48:    */   {
/*  49: 83 */     if (this.components != null) {
/*  50: 85 */       getLabelWidget().setText(getLabel());
/*  51:    */     }
/*  52: 88 */     return false;
/*  53:    */   }
/*  54:    */   
/*  55:    */   protected boolean init()
/*  56:    */   {
/*  57: 96 */     return false;
/*  58:    */   }
/*  59:    */   
/*  60: 99 */   private static WidgetCreator widgetCreator = null;
/*  61:    */   
/*  62:    */   public static void registerWidgetCreator(WidgetCreator wc)
/*  63:    */   {
/*  64:102 */     widgetCreator = wc;
/*  65:    */   }
/*  66:    */   
/*  67:    */   public void setTextValueOnWidget(String newValue)
/*  68:    */   {
/*  69:106 */     getLabelWidget().setText(newValue);
/*  70:    */   }
/*  71:    */   
/*  72:    */   protected AbstractWidget createWidget()
/*  73:    */   {
/*  74:110 */     return widgetCreator.createWidget();
/*  75:    */   }
/*  76:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.controls.LabelControl
 * JD-Core Version:    0.7.0.1
 */