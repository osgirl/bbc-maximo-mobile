package com.mro.mobile.ui.res.controls.utils;

public abstract interface StyleManagerSupport
{
  public abstract ControlStyle getStyle(String paramString1, String paramString2);
  
  public abstract Object getDefaultFont();
  
  public abstract Object getDefaultBgColor();
  
  public abstract Object getDefaultFgColor();
  
  public abstract Object getDefaultSetting(String paramString);
  
  public abstract ControlStyle getDefaultStyle();
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.controls.utils.StyleManagerSupport
 * JD-Core Version:    0.7.0.1
 */