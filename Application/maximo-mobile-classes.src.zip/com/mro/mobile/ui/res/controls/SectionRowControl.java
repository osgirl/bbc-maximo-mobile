/*   1:    */ package com.mro.mobile.ui.res.controls;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.ui.event.UIEvent;
/*   5:    */ import com.mro.mobile.ui.res.ControlData;
/*   6:    */ import com.mro.mobile.ui.res.widgets.def.AbstractWidget;
/*   7:    */ import com.mro.mobile.ui.res.widgets.def.SectionRowWidget;
/*   8:    */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*   9:    */ import com.mro.mobile.ui.res.widgets.def.WidgetCreator;
/*  10:    */ import java.util.ArrayList;
/*  11:    */ import java.util.Iterator;
/*  12:    */ 
/*  13:    */ public class SectionRowControl
/*  14:    */   extends AbstractMobileControl
/*  15:    */ {
/*  16: 42 */   protected int numCols = 0;
/*  17:    */   
/*  18:    */   protected SectionRowWidget getSectionRowWidget()
/*  19:    */   {
/*  20: 48 */     return (SectionRowWidget)super.getWidget();
/*  21:    */   }
/*  22:    */   
/*  23:    */   public AbstractMobileControl createControl(ControlData controlData)
/*  24:    */     throws MobileApplicationException
/*  25:    */   {
/*  26: 56 */     return new SectionRowControl();
/*  27:    */   }
/*  28:    */   
/*  29:    */   public UIComponent[] composeComponents()
/*  30:    */     throws MobileApplicationException
/*  31:    */   {
/*  32: 61 */     boolean center = getBooleanValue("center");
/*  33:    */     
/*  34: 63 */     SectionRowWidget widget = getSectionRowWidget();
/*  35: 64 */     widget.createSectionRow(getStringValue("id"));
/*  36:    */     
/*  37: 66 */     int indent = 0;
/*  38: 67 */     if (isAttributeSet("indents"))
/*  39:    */     {
/*  40: 69 */       indent = getIntValue("indents");
/*  41: 70 */       indent *= 10;
/*  42:    */     }
/*  43: 73 */     int offsettop = 0;
/*  44: 74 */     if (isAttributeSet("padding-top")) {
/*  45: 76 */       offsettop = getIntValue("padding-top");
/*  46:    */     }
/*  47: 80 */     if (this.numCols == 0) {
/*  48: 81 */       this.numCols = this.childControls.size();
/*  49:    */     }
/*  50: 83 */     widget.initializeLayout(this.numCols);
/*  51:    */     
/*  52: 85 */     ArrayList childComps = composeChildren();
/*  53: 86 */     if (childComps != null)
/*  54:    */     {
/*  55: 88 */       Iterator i = childComps.iterator();
/*  56: 89 */       while (i.hasNext())
/*  57:    */       {
/*  58: 91 */         UIComponent[] comps = (UIComponent[])i.next();
/*  59: 92 */         if (this.numCols == 0)
/*  60:    */         {
/*  61: 94 */           for (int j = 0; j < comps.length; j++)
/*  62:    */           {
/*  63: 96 */             UIComponent component = comps[j];
/*  64: 97 */             widget.addComponent(component);
/*  65:    */           }
/*  66:    */         }
/*  67:    */         else
/*  68:    */         {
/*  69:103 */           UIComponent component = comps[0];
/*  70:104 */           widget.addComponentWithDefaultLayoutConstraints(component);
/*  71:    */         }
/*  72:    */       }
/*  73:    */     }
/*  74:109 */     widget.setLayoutConstraints(offsettop, indent);
/*  75:    */     
/*  76:111 */     this.components = widget.resolveSectionRowComponents();
/*  77:    */     
/*  78:113 */     return this.components;
/*  79:    */   }
/*  80:    */   
/*  81:    */   protected boolean performEvent(UIEvent event)
/*  82:    */     throws MobileApplicationException
/*  83:    */   {
/*  84:121 */     return false;
/*  85:    */   }
/*  86:    */   
/*  87:    */   public void addColumn()
/*  88:    */   {
/*  89:126 */     this.numCols += 1;
/*  90:    */   }
/*  91:    */   
/*  92:    */   protected boolean handleException(UIEvent event, Exception exception)
/*  93:    */   {
/*  94:135 */     return false;
/*  95:    */   }
/*  96:    */   
/*  97:    */   protected boolean refreshControl(UIEvent event)
/*  98:    */   {
/*  99:143 */     return true;
/* 100:    */   }
/* 101:    */   
/* 102:    */   protected boolean init()
/* 103:    */   {
/* 104:151 */     return true;
/* 105:    */   }
/* 106:    */   
/* 107:154 */   private static WidgetCreator widgetCreator = null;
/* 108:    */   
/* 109:    */   public static void registerWidgetCreator(WidgetCreator wc)
/* 110:    */   {
/* 111:157 */     widgetCreator = wc;
/* 112:    */   }
/* 113:    */   
/* 114:    */   protected AbstractWidget createWidget()
/* 115:    */   {
/* 116:161 */     return widgetCreator.createWidget();
/* 117:    */   }
/* 118:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.controls.SectionRowControl
 * JD-Core Version:    0.7.0.1
 */