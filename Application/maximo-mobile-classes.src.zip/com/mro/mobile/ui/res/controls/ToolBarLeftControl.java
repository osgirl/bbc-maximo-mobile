/*  1:   */ package com.mro.mobile.ui.res.controls;
/*  2:   */ 
/*  3:   */ import com.mro.mobile.MobileApplicationException;
/*  4:   */ import com.mro.mobile.ui.event.UIEvent;
/*  5:   */ import com.mro.mobile.ui.res.ControlData;
/*  6:   */ import com.mro.mobile.ui.res.widgets.def.AbstractWidget;
/*  7:   */ import com.mro.mobile.ui.res.widgets.def.ToolBarLeftWidget;
/*  8:   */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  9:   */ import com.mro.mobile.ui.res.widgets.def.WidgetCreator;
/* 10:   */ 
/* 11:   */ public class ToolBarLeftControl
/* 12:   */   extends ToolBarContainerControl
/* 13:   */ {
/* 14:   */   protected ToolBarLeftWidget getToolBarLeftWidget()
/* 15:   */   {
/* 16:38 */     return (ToolBarLeftWidget)super.getWidget();
/* 17:   */   }
/* 18:   */   
/* 19:41 */   private static WidgetCreator widgetCreator = null;
/* 20:   */   
/* 21:   */   public static void registerWidgetCreator(WidgetCreator wc)
/* 22:   */   {
/* 23:44 */     widgetCreator = wc;
/* 24:   */   }
/* 25:   */   
/* 26:   */   public UIComponent[] composeComponents()
/* 27:   */     throws MobileApplicationException
/* 28:   */   {
/* 29:49 */     return getToolbar("left");
/* 30:   */   }
/* 31:   */   
/* 32:   */   protected boolean performEvent(UIEvent event)
/* 33:   */     throws MobileApplicationException
/* 34:   */   {
/* 35:55 */     return false;
/* 36:   */   }
/* 37:   */   
/* 38:   */   protected boolean handleException(UIEvent event, Exception exception)
/* 39:   */   {
/* 40:62 */     return false;
/* 41:   */   }
/* 42:   */   
/* 43:   */   protected boolean refreshControl(UIEvent event)
/* 44:   */   {
/* 45:69 */     return true;
/* 46:   */   }
/* 47:   */   
/* 48:   */   public AbstractMobileControl createControl(ControlData controlData)
/* 49:   */     throws MobileApplicationException
/* 50:   */   {
/* 51:75 */     return new ToolBarLeftControl();
/* 52:   */   }
/* 53:   */   
/* 54:   */   protected boolean init()
/* 55:   */   {
/* 56:82 */     return false;
/* 57:   */   }
/* 58:   */   
/* 59:   */   protected AbstractWidget createWidget()
/* 60:   */   {
/* 61:86 */     return widgetCreator.createWidget();
/* 62:   */   }
/* 63:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.controls.ToolBarLeftControl
 * JD-Core Version:    0.7.0.1
 */