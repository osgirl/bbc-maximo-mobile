/*  1:   */ package com.mro.mobile.ui.res.controls;
/*  2:   */ 
/*  3:   */ import com.mro.mobile.MobileApplicationException;
/*  4:   */ import com.mro.mobile.ui.event.UIEvent;
/*  5:   */ import com.mro.mobile.ui.res.ControlData;
/*  6:   */ import com.mro.mobile.ui.res.widgets.def.AbstractWidget;
/*  7:   */ import com.mro.mobile.ui.res.widgets.def.CalendarWidget;
/*  8:   */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  9:   */ import com.mro.mobile.ui.res.widgets.def.WidgetCreator;
/* 10:   */ import java.util.Calendar;
/* 11:   */ 
/* 12:   */ public class CalendarControl
/* 13:   */   extends AbstractMobileControl
/* 14:   */ {
/* 15:37 */   private int STARTOFTHEWEEK = 1;
/* 16:   */   
/* 17:   */   protected CalendarWidget getCalendarWidget()
/* 18:   */   {
/* 19:43 */     return (CalendarWidget)super.getWidget();
/* 20:   */   }
/* 21:   */   
/* 22:46 */   private static WidgetCreator widgetCreator = null;
/* 23:   */   
/* 24:   */   public static void registerWidgetCreator(WidgetCreator wc)
/* 25:   */   {
/* 26:49 */     widgetCreator = wc;
/* 27:   */   }
/* 28:   */   
/* 29:   */   public AbstractMobileControl createControl(ControlData controlData)
/* 30:   */     throws MobileApplicationException
/* 31:   */   {
/* 32:57 */     return new CalendarControl();
/* 33:   */   }
/* 34:   */   
/* 35:   */   public UIComponent[] composeComponents()
/* 36:   */     throws MobileApplicationException
/* 37:   */   {
/* 38:65 */     this.STARTOFTHEWEEK = Calendar.getInstance().getFirstDayOfWeek();
/* 39:   */     
/* 40:67 */     CalendarWidget widget = getCalendarWidget();
/* 41:68 */     widget.createCalendar(this.STARTOFTHEWEEK);
/* 42:   */     
/* 43:70 */     return widget.resolveCalendarComponents();
/* 44:   */   }
/* 45:   */   
/* 46:   */   protected boolean performEvent(UIEvent event)
/* 47:   */     throws MobileApplicationException
/* 48:   */   {
/* 49:75 */     return getCalendarWidget().performEvent(event);
/* 50:   */   }
/* 51:   */   
/* 52:   */   protected boolean handleException(UIEvent event, Exception exception)
/* 53:   */   {
/* 54:82 */     return false;
/* 55:   */   }
/* 56:   */   
/* 57:   */   protected boolean refreshControl(UIEvent event)
/* 58:   */     throws MobileApplicationException
/* 59:   */   {
/* 60:90 */     getCalendarWidget().refreshCalendar();
/* 61:91 */     return true;
/* 62:   */   }
/* 63:   */   
/* 64:   */   protected AbstractWidget createWidget()
/* 65:   */   {
/* 66:95 */     return widgetCreator.createWidget();
/* 67:   */   }
/* 68:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.controls.CalendarControl
 * JD-Core Version:    0.7.0.1
 */