/*  1:   */ package com.mro.mobile.ui.res.controls.utils;
/*  2:   */ 
/*  3:   */ public class StyleManager
/*  4:   */ {
/*  5:   */   public static final String STYLE_FONTNAME = "font";
/*  6:   */   public static final String STYLE_FONTSTYLE = "font-style";
/*  7:   */   public static final String STYLE_FONTSIZE = "font-size";
/*  8:   */   public static final String STYLE_BGCOLOR = "bgcolor";
/*  9:   */   public static final String STYLE_FGCOLOR = "fgcolor";
/* 10:   */   public static final String STYLE_BORDER = "border";
/* 11:   */   public static final String STYLE_BORDERCOLOR = "border-color";
/* 12:   */   public static final String STYLE_OPAQUE = "opaque";
/* 13:   */   public static final String STYLE_UNDERLINE = "underline";
/* 14:   */   public static final String STYLE_BACKGROUND = "background";
/* 15:   */   private static StyleManagerSupport styleSupport;
/* 16:   */   
/* 17:   */   public static void registerStyleManagerSupport(StyleManagerSupport support)
/* 18:   */   {
/* 19:37 */     styleSupport = support;
/* 20:   */   }
/* 21:   */   
/* 22:   */   public static ControlStyle getStyle(String style, String override)
/* 23:   */   {
/* 24:41 */     return styleSupport.getStyle(style, override);
/* 25:   */   }
/* 26:   */   
/* 27:   */   public static Object getDefaultFont()
/* 28:   */   {
/* 29:45 */     return styleSupport.getDefaultFont();
/* 30:   */   }
/* 31:   */   
/* 32:   */   public static Object getDefaultBgColor()
/* 33:   */   {
/* 34:49 */     return styleSupport.getDefaultBgColor();
/* 35:   */   }
/* 36:   */   
/* 37:   */   public static Object getDefaultFgColor()
/* 38:   */   {
/* 39:53 */     return styleSupport.getDefaultFgColor();
/* 40:   */   }
/* 41:   */   
/* 42:   */   public static Object getDefaultSetting(String setting)
/* 43:   */   {
/* 44:57 */     return styleSupport.getDefaultSetting(setting);
/* 45:   */   }
/* 46:   */   
/* 47:   */   public static ControlStyle getDefaultStyle()
/* 48:   */   {
/* 49:61 */     return styleSupport.getDefaultStyle();
/* 50:   */   }
/* 51:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.controls.utils.StyleManager
 * JD-Core Version:    0.7.0.1
 */