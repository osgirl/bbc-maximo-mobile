/*   1:    */ package com.mro.mobile.ui.res.controls;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.ui.event.UIEvent;
/*   5:    */ import com.mro.mobile.ui.res.ControlData;
/*   6:    */ import com.mro.mobile.ui.res.widgets.def.AbstractWidget;
/*   7:    */ import com.mro.mobile.ui.res.widgets.def.SectionWidget;
/*   8:    */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*   9:    */ import com.mro.mobile.ui.res.widgets.def.WidgetCreator;
/*  10:    */ import java.util.ArrayList;
/*  11:    */ import java.util.Iterator;
/*  12:    */ import java.util.Vector;
/*  13:    */ 
/*  14:    */ public class SectionControl
/*  15:    */   extends AbstractMobileControl
/*  16:    */ {
/*  17: 41 */   UIComponent section = null;
/*  18: 43 */   int rows = 1;
/*  19: 44 */   int cols = 1;
/*  20: 45 */   boolean scrollable = false;
/*  21: 47 */   private Vector columns = new Vector();
/*  22:    */   
/*  23:    */   protected SectionWidget getSectionWidget()
/*  24:    */   {
/*  25: 53 */     return (SectionWidget)super.getWidget();
/*  26:    */   }
/*  27:    */   
/*  28:    */   public AbstractMobileControl createControl(ControlData controlData)
/*  29:    */     throws MobileApplicationException
/*  30:    */   {
/*  31: 61 */     return new SectionControl();
/*  32:    */   }
/*  33:    */   
/*  34:    */   public UIComponent[] composeComponents()
/*  35:    */     throws MobileApplicationException
/*  36:    */   {
/*  37: 67 */     if (isAttributeSet("scrollable"))
/*  38:    */     {
/*  39: 69 */       this.scrollable = getBooleanValue("scrollable");
/*  40: 70 */       if (!this.scrollable) {
/*  41: 72 */         setScrollableSection(false);
/*  42:    */       }
/*  43:    */     }
/*  44: 75 */     String backgroundImageName = getStringValue("backgroundimage");
/*  45:    */     
/*  46: 77 */     getSectionWidget().createMainPanel();
/*  47: 78 */     getSectionWidget().setMainPanelSectionId(getStringValue("id"));
/*  48: 80 */     if (backgroundImageName != null) {
/*  49: 82 */       getSectionWidget().setBgImage(backgroundImageName);
/*  50: 84 */     } else if (isAttributeSet("backgroundcolor")) {
/*  51: 86 */       getSectionWidget().setBgColor(getColorValue("backgroundcolor"));
/*  52:    */     }
/*  53: 89 */     int offsettop = 0;
/*  54: 90 */     if (((this.parentControl instanceof PageControl)) || ((this.parentControl instanceof TabControl))) {
/*  55: 92 */       if ((this.childControls != null) && (!(this.childControls.get(0) instanceof TableControl))) {
/*  56: 94 */         offsettop = 4;
/*  57:    */       }
/*  58:    */     }
/*  59: 99 */     if (isAttributeSet("padding-top")) {
/*  60:101 */       offsettop = getIntValue("padding-top");
/*  61:    */     }
/*  62:104 */     int indent = 0;
/*  63:105 */     if (isAttributeSet("indents"))
/*  64:    */     {
/*  65:107 */       indent = getIntValue("indents");
/*  66:108 */       indent *= 10;
/*  67:    */     }
/*  68:111 */     this.components = new UIComponent[1];
/*  69:    */     
/*  70:113 */     Vector displayList = new Vector();
/*  71:114 */     String label = getStringValue("label");
/*  72:115 */     if (label != null) {
/*  73:117 */       displayList.add(getSectionWidget().createLabel(label));
/*  74:    */     }
/*  75:120 */     ArrayList childComps = composeChildren();
/*  76:121 */     if ((childComps != null) && (!childComps.isEmpty()))
/*  77:    */     {
/*  78:123 */       getSectionWidget().configDefaultConstraints(0, 0, 2, 0);
/*  79:    */       
/*  80:125 */       int i = 0;
/*  81:126 */       int startIndex = i;
/*  82:127 */       int gridRows = 0;
/*  83:128 */       int tempcols = ((UIComponent[])childComps.get(i)).length;
/*  84:129 */       int numRows = childComps.size();
/*  85:    */       do
/*  86:    */       {
/*  87:133 */         UIComponent[] currentComps = (UIComponent[])childComps.get(i);
/*  88:134 */         if ((startIndex == i) || (tempcols == currentComps.length))
/*  89:    */         {
/*  90:136 */           gridRows++;
/*  91:137 */           i++;
/*  92:138 */           if (i < numRows) {}
/*  93:    */         }
/*  94:    */         else
/*  95:    */         {
/*  96:145 */           UIComponent panel = getSectionWidget().createOnePanel();
/*  97:146 */           getSectionWidget().setPanelLayout(panel, gridRows, tempcols);
/*  98:147 */           for (int row = startIndex; row < startIndex + gridRows; row++)
/*  99:    */           {
/* 100:149 */             UIComponent[] comps = (UIComponent[])childComps.get(row);
/* 101:    */             
/* 102:    */ 
/* 103:152 */             getSectionWidget().addComponentsAsOneRow(comps, panel, tempcols);
/* 104:    */           }
/* 105:154 */           displayList.add(panel);
/* 106:155 */           startIndex = i;
/* 107:156 */           gridRows = 0;
/* 108:157 */           tempcols = currentComps.length;
/* 109:    */         }
/* 110:158 */       } while (i < numRows);
/* 111:160 */       getSectionWidget().setPanelLayout(getSectionWidget().getMainPanel(), displayList.size(), 1);
/* 112:    */       
/* 113:162 */       Object c = getSectionWidget().createRowLevelConstraints(0, 0, 0, 0);
/* 114:    */       
/* 115:164 */       Iterator it = displayList.iterator();
/* 116:165 */       while (it.hasNext())
/* 117:    */       {
/* 118:167 */         UIComponent comp = (UIComponent)it.next();
/* 119:168 */         getSectionWidget().addOneComponentToPanel(getSectionWidget().getMainPanel(), comp, c);
/* 120:    */       }
/* 121:    */     }
/* 122:171 */     if (((this.parentControl instanceof PageControl)) && (indent == 0)) {
/* 123:173 */       indent = 2;
/* 124:    */     }
/* 125:176 */     Object pageConstraints = getSectionWidget().createPageLevelConstraints(offsettop, indent, 0, 0);
/* 126:177 */     getSectionWidget().setPanelConstraints(getSectionWidget().getMainPanel(), pageConstraints);
/* 127:    */     
/* 128:179 */     this.components[0] = getSectionWidget().getMainPanel();
/* 129:180 */     return this.components;
/* 130:    */   }
/* 131:    */   
/* 132:    */   protected boolean performEvent(UIEvent event)
/* 133:    */     throws MobileApplicationException
/* 134:    */   {
/* 135:188 */     return false;
/* 136:    */   }
/* 137:    */   
/* 138:    */   public void addColumn(int colIndex, Object constraint)
/* 139:    */   {
/* 140:193 */     if (this.columns.get(colIndex) == null) {
/* 141:195 */       this.columns.add(colIndex, constraint == null ? getSectionWidget().getDefaultConstraints() : constraint);
/* 142:    */     }
/* 143:    */   }
/* 144:    */   
/* 145:    */   protected boolean handleException(UIEvent event, Exception exception)
/* 146:    */   {
/* 147:205 */     return false;
/* 148:    */   }
/* 149:    */   
/* 150:    */   protected boolean refreshControl(UIEvent event)
/* 151:    */   {
/* 152:213 */     return true;
/* 153:    */   }
/* 154:    */   
/* 155:    */   protected boolean init()
/* 156:    */   {
/* 157:221 */     return true;
/* 158:    */   }
/* 159:    */   
/* 160:    */   public boolean isScrollable()
/* 161:    */   {
/* 162:228 */     return this.scrollable;
/* 163:    */   }
/* 164:    */   
/* 165:231 */   private static WidgetCreator widgetCreator = null;
/* 166:    */   
/* 167:    */   public static void registerWidgetCreator(WidgetCreator wc)
/* 168:    */   {
/* 169:234 */     widgetCreator = wc;
/* 170:    */   }
/* 171:    */   
/* 172:    */   protected AbstractWidget createWidget()
/* 173:    */   {
/* 174:238 */     return widgetCreator.createWidget();
/* 175:    */   }
/* 176:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.controls.SectionControl
 * JD-Core Version:    0.7.0.1
 */