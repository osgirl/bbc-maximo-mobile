/*   1:    */ package com.mro.mobile.ui.res.controls.utils;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*   4:    */ 
/*   5:    */ public class TableColumnData
/*   6:    */ {
/*   7: 31 */   private String caption = "";
/*   8: 32 */   private String displaymode = "";
/*   9: 33 */   private String dataAttribute = "";
/*  10: 34 */   private String showdataAttribute = "";
/*  11: 35 */   private int colwidth = 20;
/*  12: 36 */   private int sortState = 0;
/*  13: 37 */   private int colIndex = 0;
/*  14: 38 */   private AbstractMobileControl ctrl = null;
/*  15: 39 */   private boolean sortable = true;
/*  16:    */   
/*  17:    */   public TableColumnData(int colIndex, String dataAttribute, int sortState, boolean sortable, AbstractMobileControl ctrl, String caption, String displaymode, String showDataAtr, int colwidth)
/*  18:    */   {
/*  19: 53 */     this.caption = caption;
/*  20: 54 */     this.displaymode = displaymode;
/*  21: 55 */     this.dataAttribute = dataAttribute;
/*  22: 56 */     this.sortState = sortState;
/*  23: 57 */     this.colIndex = colIndex;
/*  24: 58 */     this.ctrl = ctrl;
/*  25: 59 */     this.showdataAttribute = showDataAtr;
/*  26: 60 */     this.colwidth = colwidth;
/*  27: 61 */     this.sortable = sortable;
/*  28:    */   }
/*  29:    */   
/*  30:    */   public int getColIndex()
/*  31:    */   {
/*  32: 68 */     return this.colIndex;
/*  33:    */   }
/*  34:    */   
/*  35:    */   public void setColIndex(int colIndex)
/*  36:    */   {
/*  37: 74 */     this.colIndex = colIndex;
/*  38:    */   }
/*  39:    */   
/*  40:    */   public String getDataAttribute()
/*  41:    */   {
/*  42: 80 */     return this.dataAttribute;
/*  43:    */   }
/*  44:    */   
/*  45:    */   public void setDataAttribute(String dataAttribute)
/*  46:    */   {
/*  47: 86 */     this.dataAttribute = dataAttribute;
/*  48:    */   }
/*  49:    */   
/*  50:    */   public int getSortState()
/*  51:    */   {
/*  52: 92 */     return this.sortState;
/*  53:    */   }
/*  54:    */   
/*  55:    */   public void setSortState(int sortState)
/*  56:    */   {
/*  57: 98 */     this.sortState = sortState;
/*  58:    */   }
/*  59:    */   
/*  60:    */   public AbstractMobileControl getController()
/*  61:    */   {
/*  62:104 */     return this.ctrl;
/*  63:    */   }
/*  64:    */   
/*  65:    */   public void setController(AbstractMobileControl ctrl)
/*  66:    */   {
/*  67:110 */     this.ctrl = ctrl;
/*  68:    */   }
/*  69:    */   
/*  70:    */   public String getCaption()
/*  71:    */   {
/*  72:116 */     return this.caption;
/*  73:    */   }
/*  74:    */   
/*  75:    */   public void setCaption(String caption)
/*  76:    */   {
/*  77:122 */     this.caption = caption;
/*  78:    */   }
/*  79:    */   
/*  80:    */   public String getDisplaymode()
/*  81:    */   {
/*  82:128 */     return this.displaymode;
/*  83:    */   }
/*  84:    */   
/*  85:    */   public void setDisplaymode(String displaymode)
/*  86:    */   {
/*  87:134 */     this.displaymode = displaymode;
/*  88:    */   }
/*  89:    */   
/*  90:    */   public String getShowdataAttribute()
/*  91:    */   {
/*  92:140 */     return this.showdataAttribute;
/*  93:    */   }
/*  94:    */   
/*  95:    */   public void setShowdataAttribute(String showdataAttribute)
/*  96:    */   {
/*  97:146 */     this.showdataAttribute = showdataAttribute;
/*  98:    */   }
/*  99:    */   
/* 100:    */   public int getColwidth()
/* 101:    */   {
/* 102:152 */     return this.colwidth;
/* 103:    */   }
/* 104:    */   
/* 105:    */   public void setColwidth(int colwidth)
/* 106:    */   {
/* 107:158 */     this.colwidth = colwidth;
/* 108:    */   }
/* 109:    */   
/* 110:    */   public boolean isSortable()
/* 111:    */   {
/* 112:164 */     return this.sortable;
/* 113:    */   }
/* 114:    */   
/* 115:    */   public void setSortable(boolean sortable)
/* 116:    */   {
/* 117:170 */     this.sortable = sortable;
/* 118:    */   }
/* 119:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.controls.utils.TableColumnData
 * JD-Core Version:    0.7.0.1
 */