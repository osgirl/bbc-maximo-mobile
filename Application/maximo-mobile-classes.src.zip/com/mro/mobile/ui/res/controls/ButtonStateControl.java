/*   1:    */ package com.mro.mobile.ui.res.controls;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.ui.event.UIEvent;
/*   5:    */ import com.mro.mobile.ui.res.ControlData;
/*   6:    */ import com.mro.mobile.ui.res.widgets.def.AbstractWidget;
/*   7:    */ import com.mro.mobile.ui.res.widgets.def.ButtonStateWidget;
/*   8:    */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*   9:    */ import com.mro.mobile.ui.res.widgets.def.WidgetCreator;
/*  10:    */ 
/*  11:    */ public class ButtonStateControl
/*  12:    */   extends AbstractMobileControl
/*  13:    */ {
/*  14: 36 */   private ButtonStateWidget buttonStateWidget = null;
/*  15: 37 */   private String value = null;
/*  16: 38 */   private String targetid = null;
/*  17:    */   
/*  18:    */   protected ButtonStateWidget getButtonStateWidget()
/*  19:    */   {
/*  20: 44 */     return (ButtonStateWidget)super.getWidget();
/*  21:    */   }
/*  22:    */   
/*  23:    */   public UIComponent[] composeComponents()
/*  24:    */     throws MobileApplicationException
/*  25:    */   {
/*  26: 52 */     String controlID = getStringValue("id");
/*  27: 53 */     String displayattribute = getStringValue("displayattribute");
/*  28: 54 */     String displayevent = getStringValue("displayevent");
/*  29:    */     
/*  30: 56 */     this.value = getStringValue("value");
/*  31: 57 */     this.targetid = getStringValue("targetid");
/*  32:    */     
/*  33: 59 */     String imgon = getStringValue("imageon");
/*  34: 60 */     String imgoff = getStringValue("imageoff");
/*  35: 61 */     this.buttonStateWidget = getButtonStateWidget().createButtonState(imgon, imgoff);
/*  36: 62 */     this.buttonStateWidget.setVisible(isButtonDisplayable(displayattribute, displayevent));
/*  37: 63 */     this.buttonStateWidget.setValue(this.value);
/*  38: 64 */     this.buttonStateWidget.setTargetId(this.targetid);
/*  39:    */     
/*  40: 66 */     return this.buttonStateWidget.resolveButtonStateComponents();
/*  41:    */   }
/*  42:    */   
/*  43:    */   protected boolean isButtonDisplayable(String displayattr, String displayevent)
/*  44:    */     throws MobileApplicationException
/*  45:    */   {
/*  46: 78 */     if (displayevent != null) {
/*  47: 80 */       return handleEvent(displayevent, null, null);
/*  48:    */     }
/*  49: 85 */     return true;
/*  50:    */   }
/*  51:    */   
/*  52:    */   public boolean handleEvent(UIEvent event)
/*  53:    */   {
/*  54: 95 */     String eventType = event.getEventName();
/*  55: 96 */     event.setValue(this.value);
/*  56: 97 */     return super.handleEvent(event);
/*  57:    */   }
/*  58:    */   
/*  59:    */   protected boolean performEvent(UIEvent event)
/*  60:    */     throws MobileApplicationException
/*  61:    */   {
/*  62:105 */     return false;
/*  63:    */   }
/*  64:    */   
/*  65:    */   protected boolean handleException(UIEvent event, Exception exception)
/*  66:    */   {
/*  67:113 */     return false;
/*  68:    */   }
/*  69:    */   
/*  70:    */   protected boolean refreshControl(UIEvent event)
/*  71:    */   {
/*  72:121 */     return true;
/*  73:    */   }
/*  74:    */   
/*  75:    */   public AbstractMobileControl createControl(ControlData controlData)
/*  76:    */     throws MobileApplicationException
/*  77:    */   {
/*  78:130 */     return new ButtonStateControl();
/*  79:    */   }
/*  80:    */   
/*  81:    */   protected boolean init()
/*  82:    */   {
/*  83:136 */     return false;
/*  84:    */   }
/*  85:    */   
/*  86:139 */   private static WidgetCreator widgetCreator = null;
/*  87:    */   
/*  88:    */   public static void registerWidgetCreator(WidgetCreator wc)
/*  89:    */   {
/*  90:142 */     widgetCreator = wc;
/*  91:    */   }
/*  92:    */   
/*  93:    */   protected AbstractWidget createWidget()
/*  94:    */   {
/*  95:146 */     return widgetCreator.createWidget();
/*  96:    */   }
/*  97:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.controls.ButtonStateControl
 * JD-Core Version:    0.7.0.1
 */