/*    1:     */ package com.mro.mobile.ui.res.controls;
/*    2:     */ 
/*    3:     */ import com.mro.mobile.MobileApplicationException;
/*    4:     */ import com.mro.mobile.MobileMessageGenerator;
/*    5:     */ import com.mro.mobile.app.BasicMobileDeviceUIApplication;
/*    6:     */ import com.mro.mobile.app.MobileDeviceAppSession;
/*    7:     */ import com.mro.mobile.mbo.MobileMbo;
/*    8:     */ import com.mro.mobile.mbo.MobileMboAttributeInfo;
/*    9:     */ import com.mro.mobile.mbo.MobileMboInfo;
/*   10:     */ import com.mro.mobile.mbo.MobileMboOrder;
/*   11:     */ import com.mro.mobile.mbo.MobileMboQBE;
/*   12:     */ import com.mro.mobile.ui.MobileMboDataBean;
/*   13:     */ import com.mro.mobile.ui.MobileMboDataBeanManager;
/*   14:     */ import com.mro.mobile.ui.MobileMboDataBeanQBE;
/*   15:     */ import com.mro.mobile.ui.event.UIEvent;
/*   16:     */ import com.mro.mobile.ui.res.ControlData;
/*   17:     */ import com.mro.mobile.ui.res.MobileUIManager;
/*   18:     */ import com.mro.mobile.ui.res.MobileUIProperties;
/*   19:     */ import com.mro.mobile.ui.res.UIUtil;
/*   20:     */ import com.mro.mobile.ui.res.controls.utils.ControlStyle;
/*   21:     */ import com.mro.mobile.ui.res.controls.utils.StyleManager;
/*   22:     */ import com.mro.mobile.ui.res.controls.utils.TableColumnData;
/*   23:     */ import com.mro.mobile.ui.res.widgets.def.AbstractWidget;
/*   24:     */ import com.mro.mobile.ui.res.widgets.def.TableWidget;
/*   25:     */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*   26:     */ import com.mro.mobile.ui.res.widgets.def.WidgetCreator;
/*   27:     */ import com.mro.mobile.util.MobileLogger;
/*   28:     */ import java.util.ArrayList;
/*   29:     */ import java.util.Enumeration;
/*   30:     */ import java.util.HashMap;
/*   31:     */ import java.util.HashSet;
/*   32:     */ import java.util.Hashtable;
/*   33:     */ import java.util.Iterator;
/*   34:     */ import java.util.Map;
/*   35:     */ import java.util.Set;
/*   36:     */ import java.util.Vector;
/*   37:     */ 
/*   38:     */ public class TableControl
/*   39:     */   extends AbstractMobileControl
/*   40:     */ {
/*   41:  61 */   protected String inputMode = null;
/*   42:  62 */   protected String dataAttribute = null;
/*   43:  63 */   protected int curFirstRow = -1;
/*   44:  64 */   protected int curLastRow = 0;
/*   45:  65 */   protected int prevFirstRow = 0;
/*   46:  66 */   protected int prevLastRow = 0;
/*   47:  67 */   protected int numofColumns = 0;
/*   48:  68 */   private int totalNumofColumns = 0;
/*   49:  69 */   protected int displayRows = 0;
/*   50:  70 */   protected int maxRows = 0;
/*   51:  71 */   protected TableColumnData tcoldata = null;
/*   52:  72 */   protected Vector tcoldataVector = new Vector();
/*   53:  73 */   private MobileMboDataBean tabColSelectBean = null;
/*   54:  74 */   private int textWidth = 0;
/*   55:  75 */   private boolean multiselect = false;
/*   56:  76 */   private String event = null;
/*   57:  77 */   private String filterPage = null;
/*   58:  78 */   private boolean colorCode = true;
/*   59:  79 */   private ControlStyle style = null;
/*   60:  80 */   private int customColWidth = -1;
/*   61:     */   public static final String STYLEKEY = "table";
/*   62:  82 */   private int dataFetchSize = 999999;
/*   63:  85 */   private int lastActiveColumnIndex = -1;
/*   64:  87 */   private String primaryAttr = null;
/*   65:  88 */   private String secondaryAttr = null;
/*   66:  89 */   private String pInsertAttr = null;
/*   67:  90 */   private String sInsertAttr = null;
/*   68:  91 */   private String primaryLabel = null;
/*   69:  92 */   private String secondaryLabel = null;
/*   70:  93 */   private int scanstate = -1;
/*   71:  94 */   MobileMboDataBean colSelDataBean = null;
/*   72:  96 */   private static String REMOVE_SCAN = "_removescan";
/*   73:     */   protected static final int SCAN_INSERT_OFF = 0;
/*   74:     */   protected static final int SCAN_INSERT_ON = 1;
/*   75:     */   protected static final int SCAN_INSERT_INSTANT = 2;
/*   76:     */   protected static final int SCAN_INSERT_INSTANT_ASK = 3;
/*   77: 104 */   protected int scaninsertflag = 0;
/*   78: 106 */   private ControlData scanViewEvent = null;
/*   79: 107 */   private ControlData scanInsertEvent = null;
/*   80: 109 */   private Map visibleControls = new Hashtable();
/*   81: 112 */   private static final String[] checkboxColumnObjects = { "TABCOLSEL", "RELATEDQUERY", "WORKQUERY" };
/*   82:     */   
/*   83:     */   public TableWidget getTableWidget()
/*   84:     */   {
/*   85: 118 */     return (TableWidget)super.getWidget();
/*   86:     */   }
/*   87:     */   
/*   88: 121 */   private static WidgetCreator widgetCreator = null;
/*   89:     */   
/*   90:     */   public static void registerWidgetCreator(WidgetCreator wc)
/*   91:     */   {
/*   92: 124 */     widgetCreator = wc;
/*   93:     */   }
/*   94:     */   
/*   95:     */   public AbstractMobileControl createControl(ControlData controlData)
/*   96:     */     throws MobileApplicationException
/*   97:     */   {
/*   98: 128 */     return new TableControl();
/*   99:     */   }
/*  100:     */   
/*  101:     */   public UIComponent[] composeComponents()
/*  102:     */     throws MobileApplicationException
/*  103:     */   {
/*  104: 139 */     String sfetch = null;
/*  105: 140 */     if (!isUiTestMode()) {
/*  106: 141 */       sfetch = UIUtil.getApplication().getProperty("maximo.mobile.datafetchsize");
/*  107:     */     }
/*  108: 143 */     if (sfetch != null) {
/*  109: 144 */       this.dataFetchSize = Integer.valueOf(sfetch).intValue();
/*  110:     */     }
/*  111: 146 */     removeLastScan(true);
/*  112: 147 */     sendInitEvent();
/*  113: 148 */     this.style = getStyle("table");
/*  114: 149 */     String tableID = getStringValue("id");
/*  115:     */     
/*  116:     */ 
/*  117: 152 */     String colorCode = getStringValue("colorcode") == null ? "true" : getStringValue("colorcode");
/*  118: 153 */     setColorCode(colorCode.equalsIgnoreCase("true"));
/*  119:     */     
/*  120:     */ 
/*  121: 156 */     computeActiveColumns();
/*  122: 157 */     this.maxRows = getIntValue("rowsperpage");
/*  123: 158 */     setDisplayRows();
/*  124:     */     
/*  125: 160 */     TableWidget widget = getTableWidget();
/*  126:     */     
/*  127:     */ 
/*  128: 163 */     widget.createTable(tableID, this.displayRows);
/*  129:     */     
/*  130:     */ 
/*  131: 166 */     setTableColumn(false);
/*  132:     */     
/*  133:     */ 
/*  134: 169 */     setTableRows();
/*  135:     */     
/*  136: 171 */     widget.setEvent(getStringValue("event"));
/*  137: 172 */     widget.setValue(getStringValue("value"));
/*  138: 173 */     widget.setDataBeanName(getStringValue("datasrcname"));
/*  139: 174 */     widget.setMobileMboName(getStringValue("mobilembo"));
/*  140: 175 */     ((PageControl)UIUtil.getCurrentScreen()).setScrollableSection(false);
/*  141: 176 */     UIComponent[] ret = widget.resolveTableComponents();
/*  142: 177 */     setupTableScanning();
/*  143: 178 */     addToolbar();
/*  144: 179 */     saveColSettings(null);
/*  145: 180 */     widget.setTrackColSizing(true);
/*  146: 181 */     return ret;
/*  147:     */   }
/*  148:     */   
/*  149:     */   protected boolean performEvent(UIEvent event)
/*  150:     */     throws MobileApplicationException
/*  151:     */   {
/*  152: 192 */     TableWidget tableWidget = getTableWidget();
/*  153: 194 */     if (event.getEventName().equalsIgnoreCase("showPrev"))
/*  154:     */     {
/*  155: 195 */       showPrev();
/*  156: 196 */       refreshToolBar(event);
/*  157:     */       
/*  158: 198 */       setTableRows();
/*  159: 199 */       return true;
/*  160:     */     }
/*  161: 200 */     if (event.getEventName().equalsIgnoreCase("showNext"))
/*  162:     */     {
/*  163: 201 */       showNext();
/*  164: 202 */       refreshToolBar(event);
/*  165:     */       
/*  166: 204 */       setTableRows();
/*  167: 205 */       return true;
/*  168:     */     }
/*  169: 206 */     if (event.getEventName().equalsIgnoreCase("columnselector"))
/*  170:     */     {
/*  171: 207 */       showColSelector();
/*  172: 208 */       return true;
/*  173:     */     }
/*  174: 209 */     if (event.getEventName().equalsIgnoreCase("savecolsetting"))
/*  175:     */     {
/*  176: 210 */       saveColSettings((String)event.getValue());
/*  177: 211 */       return true;
/*  178:     */     }
/*  179: 212 */     if (event.getEventName().equalsIgnoreCase("sort"))
/*  180:     */     {
/*  181: 213 */       if ((((Integer)event.getValue()).intValue() > -1) && 
/*  182: 214 */         (sortTable(((Integer)event.getValue()).intValue()))) {
/*  183: 215 */         refreshToolBar(event);
/*  184:     */       }
/*  185: 218 */       return true;
/*  186:     */     }
/*  187: 219 */     if (event.getEventName().equalsIgnoreCase("showInfo"))
/*  188:     */     {
/*  189: 221 */       String showAttr = getTableColumVectorValue(tableWidget.getCurrentColumn()).getShowdataAttribute();
/*  190: 222 */       if (showAttr != null)
/*  191:     */       {
/*  192: 223 */         UIUtil.showInfoMessageBox(getDataBean().getValue(showAttr));
/*  193:     */       }
/*  194:     */       else
/*  195:     */       {
/*  196: 225 */         String stabValue = (String)event.getValue();
/*  197: 226 */         if (getTextWidth() * stabValue.length() > tableWidget.getTableColumnWidth(tableWidget.getCurrentColumn())) {
/*  198: 227 */           UIUtil.showInfoMessageBox(stabValue);
/*  199:     */         }
/*  200:     */       }
/*  201: 230 */       return true;
/*  202:     */     }
/*  203: 231 */     if (event.getEventName().equalsIgnoreCase("datamultiselect"))
/*  204:     */     {
/*  205: 233 */       Object value = event.getValue();
/*  206: 234 */       boolean realValue = (value != null) && (Boolean.valueOf(value.toString()).booleanValue());
/*  207: 235 */       if (realValue) {
/*  208: 236 */         getDataBean().select();
/*  209:     */       } else {
/*  210: 238 */         getDataBean().unselect();
/*  211:     */       }
/*  212: 240 */       return true;
/*  213:     */     }
/*  214: 241 */     if (event.getEventName().equalsIgnoreCase("showfilter"))
/*  215:     */     {
/*  216: 242 */       if (this.filterPage == null) {
/*  217: 243 */         this.filterPage = getStringValue("filterpage");
/*  218:     */       }
/*  219: 244 */       if (this.filterPage != null)
/*  220:     */       {
/*  221: 245 */         ((MobileMboDataBeanQBE)getDataBean().getQBE()).saveCurrentQBEValues();
/*  222: 246 */         UIUtil.gotoPage(this.filterPage, this);
/*  223:     */       }
/*  224: 248 */       return true;
/*  225:     */     }
/*  226: 249 */     if (event.getEventName().equalsIgnoreCase("toggleshownext")) {
/*  227: 250 */       return toggleshownext(event);
/*  228:     */     }
/*  229: 251 */     if (event.getEventName().equalsIgnoreCase("toggleshowprev")) {
/*  230: 252 */       return toggleshowprev(event);
/*  231:     */     }
/*  232: 254 */     if (event.getEventName().equalsIgnoreCase("moveUp")) {
/*  233: 255 */       return tableWidget.performVerticalMove(-1);
/*  234:     */     }
/*  235: 258 */     if (event.getEventName().equalsIgnoreCase("moveDown")) {
/*  236: 259 */       return tableWidget.performVerticalMove(1);
/*  237:     */     }
/*  238: 261 */     if (event.getEventName().equalsIgnoreCase("moveLeft")) {
/*  239: 262 */       return tableWidget.performHorizontalMove(-1);
/*  240:     */     }
/*  241: 265 */     if (event.getEventName().equalsIgnoreCase("moveRight")) {
/*  242: 266 */       return tableWidget.performHorizontalMove(1);
/*  243:     */     }
/*  244: 267 */     if (event.getEventName().equalsIgnoreCase("primarycheck")) {
/*  245: 268 */       return primarycheck(event);
/*  246:     */     }
/*  247: 269 */     if (event.getEventName().equalsIgnoreCase("secondarycheck")) {
/*  248: 270 */       return secondarycheck(event);
/*  249:     */     }
/*  250: 271 */     if (event.getEventName().equalsIgnoreCase("barcoderead")) {
/*  251: 272 */       return barcoderead(event);
/*  252:     */     }
/*  253: 273 */     if (event.getEventName().equalsIgnoreCase("togglescanbutton")) {
/*  254: 274 */       return togglescanbutton(event);
/*  255:     */     }
/*  256: 275 */     if (event.getEventName().equalsIgnoreCase("scaninfo")) {
/*  257: 276 */       return scaninfo(event);
/*  258:     */     }
/*  259: 277 */     if (event.getEventName().equalsIgnoreCase("hasscanned")) {
/*  260: 278 */       return hasscanned(event);
/*  261:     */     }
/*  262: 279 */     if (event.getEventName().equalsIgnoreCase("clearscan")) {
/*  263: 280 */       return clearscan(event);
/*  264:     */     }
/*  265: 283 */     return false;
/*  266:     */   }
/*  267:     */   
/*  268:     */   public boolean toggleshownext(UIEvent event)
/*  269:     */     throws MobileApplicationException
/*  270:     */   {
/*  271: 287 */     MobileMboDataBean dataBean = getDataBean();
/*  272: 288 */     if (dataBean != null)
/*  273:     */     {
/*  274: 289 */       if (((UIUtil.getCurrentScreen() instanceof LookupControl)) && (dataBean.count() > this.dataFetchSize)) {
/*  275: 290 */         return true;
/*  276:     */       }
/*  277: 292 */       StateControl state = (StateControl)event.getCreatingObject();
/*  278: 293 */       if (dataBean.getMobileMbo(this.curLastRow) == null) {
/*  279: 294 */         state.setStateViaState("off");
/*  280:     */       } else {
/*  281: 296 */         state.setStateViaState("on");
/*  282:     */       }
/*  283:     */     }
/*  284: 298 */     return true;
/*  285:     */   }
/*  286:     */   
/*  287:     */   public boolean toggleshowprev(UIEvent event)
/*  288:     */     throws MobileApplicationException
/*  289:     */   {
/*  290: 302 */     MobileMboDataBean dataBean = getDataBean();
/*  291: 303 */     if (dataBean != null)
/*  292:     */     {
/*  293: 304 */       StateControl state = (StateControl)event.getCreatingObject();
/*  294: 305 */       if (this.curFirstRow < 1) {
/*  295: 306 */         state.setStateViaState("off");
/*  296:     */       } else {
/*  297: 308 */         state.setStateViaState("on");
/*  298:     */       }
/*  299:     */     }
/*  300: 310 */     return true;
/*  301:     */   }
/*  302:     */   
/*  303:     */   private void setupTableScanning()
/*  304:     */     throws MobileApplicationException
/*  305:     */   {
/*  306: 314 */     String bcEnableEvent = getStringValue("enablebcevent");
/*  307: 315 */     if (bcEnableEvent != null) {
/*  308: 316 */       handleEvent(bcEnableEvent, null, null);
/*  309:     */     }
/*  310: 317 */     if (barCodingEnabled())
/*  311:     */     {
/*  312: 319 */       ControlData[] childrenData = this.controlAttributes.getChildControlData();
/*  313: 320 */       for (int i = 0; i < childrenData.length; i++)
/*  314:     */       {
/*  315: 321 */         ControlData childData = childrenData[i];
/*  316: 322 */         boolean isscanevent = childData.getName().equalsIgnoreCase("scanevent");
/*  317: 323 */         if (!isscanevent)
/*  318:     */         {
/*  319: 324 */           if (this.scanViewEvent == null)
/*  320:     */           {
/*  321: 325 */             ControlData[] colChildren = childData.getChildControlData();
/*  322: 326 */             if ((colChildren != null) && (colChildren.length > 0) && (colChildren[0].getValue("event") != null)) {
/*  323: 327 */               this.scanViewEvent = colChildren[0];
/*  324:     */             }
/*  325:     */           }
/*  326:     */         }
/*  327:     */         else
/*  328:     */         {
/*  329: 332 */           String type = childData.getValue("type");
/*  330: 333 */           if (type.equalsIgnoreCase("insert")) {
/*  331: 334 */             this.scanInsertEvent = childData;
/*  332:     */           } else {
/*  333: 336 */             this.scanViewEvent = childData;
/*  334:     */           }
/*  335:     */         }
/*  336:     */       }
/*  337: 339 */       if (this.scanInsertEvent == null) {
/*  338: 340 */         this.scanInsertEvent = this.scanViewEvent;
/*  339:     */       }
/*  340: 343 */       if (!getDataBean().isFiltered()) {
/*  341: 344 */         setScanState(0);
/*  342:     */       }
/*  343: 347 */       String insertOnScan = getStringValue("insertonscan");
/*  344: 348 */       if ((insertOnScan != null) && (this.scanInsertEvent != null)) {
/*  345: 349 */         if (insertOnScan.equalsIgnoreCase("notfound"))
/*  346:     */         {
/*  347: 350 */           String option = this.scanInsertEvent.getValue("sigoption");
/*  348: 351 */           if ((option == null) || (this.app.isOptionAuthorized(option))) {
/*  349: 352 */             this.scaninsertflag = 1;
/*  350:     */           }
/*  351:     */         }
/*  352: 353 */         else if (insertOnScan.equalsIgnoreCase("instant"))
/*  353:     */         {
/*  354: 354 */           this.scaninsertflag = 2;
/*  355:     */         }
/*  356: 355 */         else if (insertOnScan.equalsIgnoreCase("instantask"))
/*  357:     */         {
/*  358: 356 */           this.scaninsertflag = 3;
/*  359:     */         }
/*  360:     */       }
/*  361:     */     }
/*  362:     */   }
/*  363:     */   
/*  364:     */   public void setupTableModel(int rows)
/*  365:     */     throws MobileApplicationException
/*  366:     */   {
/*  367: 369 */     TableWidget tableWidget = getTableWidget();
/*  368: 370 */     ControlData[] childrenData = this.controlAttributes.getChildControlData();
/*  369: 371 */     int cols = childrenData.length;
/*  370:     */     
/*  371:     */ 
/*  372: 374 */     Map cache = new HashMap();
/*  373: 375 */     for (int i = 0; i < cols; i++) {
/*  374: 376 */       cache.put(childrenData[i], new Boolean(checkDisplayMode(childrenData[i])));
/*  375:     */     }
/*  376: 379 */     if (isMultiselect()) {
/*  377: 380 */       tableWidget.createTableModel(rows, getActiveColumns() + 1);
/*  378:     */     } else {
/*  379: 382 */       tableWidget.createTableModel(rows, getActiveColumns());
/*  380:     */     }
/*  381: 386 */     if (((UIUtil.getCurrentScreen() instanceof LookupControl)) && (getDataBean().count() > this.dataFetchSize)) {
/*  382: 387 */       return;
/*  383:     */     }
/*  384: 390 */     getDataBean().dataExists(this.curFirstRow + (rows - 1));
/*  385: 391 */     this.curLastRow = (this.curFirstRow < 0 ? 0 : this.curFirstRow);
/*  386: 392 */     for (int i = 0; i < rows; i++)
/*  387:     */     {
/*  388: 394 */       if (getDataBean().setCurrentPosition(this.curLastRow))
/*  389:     */       {
/*  390: 395 */         ControlStyle curRowStyle = getRowStyle();
/*  391: 396 */         if (isColorCode())
/*  392:     */         {
/*  393: 397 */           String rowrenderEvent = getStringValue("rowstyleevent");
/*  394: 398 */           if (rowrenderEvent != null)
/*  395:     */           {
/*  396: 399 */             UIEvent renderEvent = new UIEvent(this, rowrenderEvent, null, curRowStyle);
/*  397: 400 */             if (sendEventUp(renderEvent)) {
/*  398: 401 */               curRowStyle = (ControlStyle)renderEvent.getValue();
/*  399:     */             }
/*  400:     */           }
/*  401:     */         }
/*  402: 406 */         ArrayList colChildren = composeChildren();
/*  403:     */         
/*  404: 408 */         Iterator allcoliter = colChildren != null ? colChildren.iterator() : null;
/*  405: 409 */         int tempIndex = 0;
/*  406: 410 */         if (isMultiselect())
/*  407:     */         {
/*  408: 411 */           boolean selected = getDataBean().getMobileMbo().isSelected();
/*  409: 412 */           tableWidget.putCheckboxToTableModel(i, tempIndex, selected, "datamultiselect");
/*  410: 413 */           tempIndex++;
/*  411:     */         }
/*  412: 415 */         String textValue = null;
/*  413: 416 */         for (int j = 0; j < cols; j++)
/*  414:     */         {
/*  415: 418 */           ControlData tempCtrlData = childrenData[j];
/*  416: 421 */           if (checkDisplayControl(tempCtrlData, cache))
/*  417:     */           {
/*  418: 423 */             ControlData[] tempChildCtrlData = tempCtrlData.getChildControlData();
/*  419: 424 */             if (tempChildCtrlData.length > 0)
/*  420:     */             {
/*  421: 425 */               if (allcoliter != null) {
/*  422: 426 */                 while (allcoliter.hasNext())
/*  423:     */                 {
/*  424: 427 */                   UIComponent[] comps = (UIComponent[])allcoliter.next();
/*  425: 428 */                   UIComponent comp = comps[0];
/*  426: 430 */                   if ((tableWidget.isToolbarComponent(comp)) || (!checkDisplayControl(comp.getController().getControlData(), cache)))
/*  427:     */                   {
/*  428: 431 */                     allcoliter.remove();
/*  429:     */                   }
/*  430:     */                   else
/*  431:     */                   {
/*  432: 434 */                     if (comp.getChildren().hasMoreElements())
/*  433:     */                     {
/*  434: 435 */                       if (tableWidget.isPanelComponent(comp)) {
/*  435: 436 */                         tableWidget.setStyleIntoPanel(comp, curRowStyle);
/*  436:     */                       }
/*  437: 439 */                       if (tableWidget.isComponentNotVisible(comp))
/*  438:     */                       {
/*  439: 440 */                         textValue = getValue(this.curLastRow, tempCtrlData.getValue("dataattribute"));
/*  440: 441 */                         tableWidget.putLabelToTableModel(i, tempIndex, textValue, curRowStyle);
/*  441:     */                       }
/*  442:     */                       else
/*  443:     */                       {
/*  444: 443 */                         tableWidget.putComponentToTableModel(i, tempIndex, comp);
/*  445:     */                       }
/*  446: 445 */                       allcoliter.remove();
/*  447: 446 */                       break;
/*  448:     */                     }
/*  449: 449 */                     allcoliter.remove();
/*  450:     */                   }
/*  451:     */                 }
/*  452:     */               }
/*  453:     */             }
/*  454:     */             else
/*  455:     */             {
/*  456: 456 */               textValue = getValue(this.curLastRow, tempCtrlData.getValue("dataattribute"));
/*  457: 457 */               tableWidget.putLabelToTableModel(i, tempIndex, textValue, curRowStyle);
/*  458:     */             }
/*  459: 459 */             tempIndex++;
/*  460:     */           }
/*  461:     */         }
/*  462: 462 */         this.curLastRow += 1;
/*  463:     */       }
/*  464:     */       else
/*  465:     */       {
/*  466: 465 */         tableWidget.removeNotNeededTableModelRows();
/*  467:     */       }
/*  468: 467 */       if (i == 0) {
/*  469: 468 */         this.curFirstRow = getDataBean().getCurrentPosition();
/*  470:     */       }
/*  471:     */     }
/*  472: 472 */     if (this.curFirstRow > -1) {
/*  473: 473 */       getDataBean().setCurrentPosition(this.curFirstRow);
/*  474:     */     }
/*  475:     */   }
/*  476:     */   
/*  477:     */   private boolean checkDisplayControl(ControlData ctrl, Map cache)
/*  478:     */   {
/*  479: 479 */     return ((Boolean)cache.get(ctrl)).booleanValue();
/*  480:     */   }
/*  481:     */   
/*  482:     */   private String getValue(int row, String colName)
/*  483:     */     throws MobileApplicationException
/*  484:     */   {
/*  485: 483 */     MobileMboDataBean dataBean = getDataBean();
/*  486: 484 */     if ((dataBean == null) || (colName == null)) {
/*  487: 485 */       return "";
/*  488:     */     }
/*  489: 487 */     dataBean.setCurrentPosition(row);
/*  490: 488 */     return dataBean.getValue(colName);
/*  491:     */   }
/*  492:     */   
/*  493:     */   public boolean setvalue(UIEvent event)
/*  494:     */     throws MobileApplicationException
/*  495:     */   {
/*  496: 492 */     return true;
/*  497:     */   }
/*  498:     */   
/*  499:     */   public MobileMboDataBean getDataBean()
/*  500:     */     throws MobileApplicationException
/*  501:     */   {
/*  502: 503 */     return super.getDataBean();
/*  503:     */   }
/*  504:     */   
/*  505:     */   protected boolean handleException(UIEvent event, Exception exception)
/*  506:     */   {
/*  507: 507 */     return false;
/*  508:     */   }
/*  509:     */   
/*  510:     */   protected boolean refreshControl(UIEvent event)
/*  511:     */     throws MobileApplicationException
/*  512:     */   {
/*  513: 518 */     String bcEnableEvent = getStringValue("enablebcevent");
/*  514: 519 */     if (bcEnableEvent != null) {
/*  515: 520 */       handleEvent(bcEnableEvent, null, null);
/*  516:     */     }
/*  517: 521 */     MobileMboDataBean bean = getDataBean();
/*  518: 522 */     sendRefreshEvent();
/*  519:     */     
/*  520: 524 */     TableWidget tableWidget = getTableWidget();
/*  521:     */     
/*  522:     */ 
/*  523:     */ 
/*  524: 528 */     int currow = 0;
/*  525: 529 */     if (bean != null) {
/*  526: 530 */       currow = bean.getCurrentPosition();
/*  527:     */     }
/*  528: 531 */     tableWidget.setTrackColSizing(false);
/*  529: 532 */     setDisplayRows();
/*  530: 533 */     computeActiveColumns();
/*  531: 535 */     if ((bean != null) && (bean.count() <= this.curFirstRow))
/*  532:     */     {
/*  533: 536 */       currow = 0;
/*  534: 537 */       this.curLastRow = 0;
/*  535: 538 */       this.curFirstRow = 0;
/*  536:     */     }
/*  537: 541 */     tableWidget.setupTableModelAndPopulateIntoTable(getDisplayRows());
/*  538:     */     
/*  539: 543 */     setTableColumn(true);
/*  540:     */     
/*  541: 545 */     setTableRows();
/*  542:     */     
/*  543: 547 */     tableWidget.setCurrrentModelBeanFirstRow(this.curFirstRow);
/*  544: 548 */     tableWidget.setTrackColSizing(true);
/*  545: 549 */     if (bean != null) {
/*  546: 550 */       bean.setCurrentPosition(currow);
/*  547:     */     }
/*  548: 552 */     return false;
/*  549:     */   }
/*  550:     */   
/*  551:     */   protected boolean refreshAfterSort(int colIndex)
/*  552:     */     throws MobileApplicationException
/*  553:     */   {
/*  554: 556 */     sendRefreshEvent();
/*  555: 557 */     this.curFirstRow = 0;
/*  556: 558 */     this.curLastRow = 0;
/*  557:     */     
/*  558: 560 */     TableWidget tableWidget = getTableWidget();
/*  559: 561 */     tableWidget.setupTableModelAndPopulateIntoTable(this.displayRows);
/*  560: 562 */     tableWidget.setCurrrentModelBeanFirstRow(this.curFirstRow);
/*  561: 563 */     return false;
/*  562:     */   }
/*  563:     */   
/*  564:     */   protected ArrayList createChildren()
/*  565:     */     throws MobileApplicationException
/*  566:     */   {
/*  567: 568 */     super.createChildren();
/*  568: 569 */     return this.childControls;
/*  569:     */   }
/*  570:     */   
/*  571:     */   protected boolean showPrev()
/*  572:     */     throws MobileApplicationException
/*  573:     */   {
/*  574: 580 */     if (this.curFirstRow <= 0) {
/*  575: 581 */       return false;
/*  576:     */     }
/*  577: 582 */     this.curFirstRow = this.prevFirstRow;
/*  578: 583 */     this.curLastRow = this.prevFirstRow;
/*  579: 584 */     this.prevFirstRow -= this.maxRows;
/*  580:     */     
/*  581:     */ 
/*  582:     */ 
/*  583: 588 */     TableWidget tableWidget = getTableWidget();
/*  584: 589 */     tableWidget.setupTableModelAndPopulateIntoTable(getDisplayRows());
/*  585: 590 */     tableWidget.setCurrrentModelBeanFirstRow(this.curFirstRow);
/*  586: 591 */     return true;
/*  587:     */   }
/*  588:     */   
/*  589:     */   protected boolean showNext()
/*  590:     */     throws MobileApplicationException
/*  591:     */   {
/*  592: 595 */     MobileMboDataBean dataBean = getDataBean();
/*  593: 596 */     if (this.curLastRow >= dataBean.count()) {
/*  594: 597 */       return false;
/*  595:     */     }
/*  596: 598 */     this.prevFirstRow = this.curFirstRow;
/*  597: 599 */     this.prevLastRow = this.curLastRow;
/*  598: 600 */     this.curFirstRow = this.curLastRow;
/*  599:     */     
/*  600: 602 */     TableWidget tableWidget = getTableWidget();
/*  601: 603 */     tableWidget.setupTableModelAndPopulateIntoTable(getDisplayRows());
/*  602: 604 */     tableWidget.setCurrrentModelBeanFirstRow(this.curFirstRow);
/*  603: 605 */     return true;
/*  604:     */   }
/*  605:     */   
/*  606:     */   private void addColumnData(MobileMboDataBean colSelDataBean)
/*  607:     */     throws MobileApplicationException
/*  608:     */   {
/*  609: 609 */     int primary = -1;
/*  610: 610 */     int secondary = -1;
/*  611: 611 */     ControlData[] childrenData = this.controlAttributes.getChildControlData();
/*  612: 612 */     int totalCols = childrenData.length;
/*  613: 613 */     int tempIndex = 0;
/*  614: 614 */     String colLabel = null;
/*  615: 615 */     String overideLabel = null;
/*  616: 616 */     boolean primaryset = false;boolean secondaryset = false;
/*  617: 617 */     for (int i = 0; i < totalCols; i++) {
/*  618: 618 */       if (!childrenData[i].getName().equalsIgnoreCase("scanevent"))
/*  619:     */       {
/*  620: 621 */         String dispAttr = childrenData[i].getValue("displaymode");
/*  621: 622 */         if (dispAttr == null) {
/*  622: 623 */           dispAttr = "visible";
/*  623:     */         }
/*  624: 625 */         if (childrenData[i].getValue("dataattribute") != null)
/*  625:     */         {
/*  626: 627 */           colSelDataBean.insert(tempIndex);
/*  627: 628 */           if ((!primaryset) || (!secondaryset))
/*  628:     */           {
/*  629: 629 */             String scanType = childrenData[i].getValue("scantype");
/*  630: 630 */             if (scanType != null)
/*  631:     */             {
/*  632: 631 */               if ((!primaryset) && (scanType.equalsIgnoreCase("primary")))
/*  633:     */               {
/*  634: 632 */                 colSelDataBean.setValue("PRIMARYSCAN", "1");
/*  635: 633 */                 colSelDataBean.setValue("SECONDARYSCAN", "0");
/*  636: 634 */                 primaryset = true;
/*  637: 635 */                 primary = i;
/*  638:     */               }
/*  639: 636 */               else if ((!secondaryset) && (scanType.equalsIgnoreCase("secondary")))
/*  640:     */               {
/*  641: 637 */                 colSelDataBean.setValue("PRIMARYSCAN", "0");
/*  642: 638 */                 colSelDataBean.setValue("SECONDARYSCAN", "1");
/*  643: 639 */                 secondaryset = true;
/*  644: 640 */                 secondary = i;
/*  645:     */               }
/*  646:     */               else
/*  647:     */               {
/*  648: 642 */                 colSelDataBean.setValue("PRIMARYSCAN", "0");
/*  649: 643 */                 colSelDataBean.setValue("SECONDARYSCAN", "0");
/*  650:     */               }
/*  651:     */             }
/*  652:     */             else
/*  653:     */             {
/*  654: 646 */               colSelDataBean.setValue("PRIMARYSCAN", "0");
/*  655: 647 */               colSelDataBean.setValue("SECONDARYSCAN", "0");
/*  656:     */             }
/*  657:     */           }
/*  658: 650 */           colSelDataBean.getMobileMbo().setIntValue("DISPLAYORDER", i + 1);
/*  659: 651 */           colSelDataBean.setValue("CTRLID", getValue("id"));
/*  660: 652 */           colSelDataBean.setValue("TABLEID", getStringValue("datasrcname"));
/*  661: 653 */           colSelDataBean.setValue("COLID", childrenData[i].getValue("id"));
/*  662: 654 */           colSelDataBean.setValue("COLUMNNAME", childrenData[i].getValue("dataattribute"));
/*  663: 655 */           colLabel = getBoundLabel(childrenData[i].getValue("dataattribute"));
/*  664: 656 */           overideLabel = childrenData[i].getValue("label");
/*  665: 657 */           colSelDataBean.setValue("COLTITLE", (overideLabel == null) || (overideLabel.trim().equals("")) ? colLabel : overideLabel);
/*  666: 658 */           String colwidth = childrenData[i].getValue("colwidth");
/*  667: 661 */           if (UIUtil.getApplication().getMobileUIManager().supportsTableColumnResizer()) {
/*  668: 662 */             colwidth = "0";
/*  669:     */           }
/*  670: 665 */           if (UIUtil.isNull(colwidth)) {
/*  671: 666 */             colwidth = "0";
/*  672:     */           }
/*  673: 667 */           colSelDataBean.setValue("COLWIDTH", colwidth);
/*  674: 668 */           colSelDataBean.setValue("DISPLAY", "0");
/*  675: 669 */           colSelDataBean.setValue("FIXED", "0");
/*  676: 670 */           if (dispAttr.equals("visible")) {
/*  677: 671 */             colSelDataBean.setValue("DISPLAY", "1");
/*  678:     */           }
/*  679: 673 */           if (dispAttr.equals("fixed"))
/*  680:     */           {
/*  681: 674 */             colSelDataBean.setValue("FIXED", "1");
/*  682: 675 */             colSelDataBean.setValue("DISPLAY", "1");
/*  683:     */           }
/*  684: 677 */           tempIndex++;
/*  685:     */         }
/*  686:     */       }
/*  687:     */     }
/*  688: 679 */     if ((secondary >= 0) && (
/*  689: 680 */       (primary < 0) || (primary == secondary))) {
/*  690: 681 */       colSelDataBean.getMobileMbo(secondary).setValue("SECONDARYSCAN", "0");
/*  691:     */     }
/*  692: 683 */     colSelDataBean.getDataBeanManager().save();
/*  693: 684 */     colSelDataBean.reset();
/*  694: 685 */     colSelDataBean.getQBE().setQBE("CTRLID", getValue("id"));
/*  695: 686 */     colSelDataBean.getQBE().setQBE("TABLEID", getStringValue("datasrcname"));
/*  696: 687 */     colSelDataBean.reset();
/*  697:     */   }
/*  698:     */   
/*  699:     */   protected boolean showColSelector()
/*  700:     */     throws MobileApplicationException
/*  701:     */   {
/*  702: 692 */     this.tabColSelectBean = null;
/*  703:     */     
/*  704: 694 */     getDataBean().setDefaultOrder();
/*  705: 697 */     if (getDataBean().isToBeSaved()) {
/*  706: 698 */       getDataBean().getDataBeanManager().save();
/*  707:     */     }
/*  708: 700 */     getDataBean().reset();
/*  709: 701 */     AbstractMobileControl tabColSelCtrl = null;
/*  710: 702 */     if (barCodingEnabled())
/*  711:     */     {
/*  712: 703 */       if (UIUtil.getApplication().getMobileUIManager().supportsTableColumnResizer()) {
/*  713: 704 */         tabColSelCtrl = UIUtil.getApplication().getScreen("TABLE_COL_SEL_SCAN_COL_RESIZER");
/*  714:     */       } else {
/*  715: 706 */         tabColSelCtrl = UIUtil.getApplication().getScreen("TABLE_COL_SEL_SCAN");
/*  716:     */       }
/*  717:     */     }
/*  718: 709 */     else if (UIUtil.getApplication().getMobileUIManager().supportsTableColumnResizer()) {
/*  719: 710 */       tabColSelCtrl = UIUtil.getApplication().getScreen("TABLE_COL_SELECTOR_COL_RESIZER");
/*  720:     */     } else {
/*  721: 712 */       tabColSelCtrl = UIUtil.getApplication().getScreen("TABLE_COL_SELECTOR");
/*  722:     */     }
/*  723: 716 */     MobileMboDataBean colSelDataBean = tabColSelCtrl.getDataBean();
/*  724: 717 */     colSelDataBean.getQBE().setQbeExactMatch(true);
/*  725: 718 */     colSelDataBean.getQBE().setQBE("CTRLID", getValue("id"));
/*  726: 719 */     colSelDataBean.getQBE().setQBE("TABLEID", getStringValue("datasrcname"));
/*  727:     */     
/*  728:     */ 
/*  729: 722 */     colSelDataBean.reset();
/*  730: 723 */     if (!colSelDataBean.dataExists(0)) {
/*  731: 724 */       addColumnData(colSelDataBean);
/*  732:     */     }
/*  733: 727 */     int primary = -1;
/*  734: 728 */     int secondary = -1;
/*  735: 729 */     for (int x = 0; x < colSelDataBean.count(); x++)
/*  736:     */     {
/*  737: 730 */       MobileMbo mbo = colSelDataBean.getMobileMbo(x);
/*  738: 731 */       if (mbo.getBooleanValue("FIXED")) {
/*  739: 732 */         mbo.setReadOnly("DISPLAY", true);
/*  740:     */       }
/*  741: 734 */       if (barCodingEnabled())
/*  742:     */       {
/*  743: 735 */         if (mbo.getBooleanValue("PRIMARYSCAN")) {
/*  744: 736 */           primary = x;
/*  745: 737 */         } else if (mbo.getBooleanValue("SECONDARYSCAN")) {
/*  746: 738 */           secondary = x;
/*  747:     */         }
/*  748:     */       }
/*  749:     */       else
/*  750:     */       {
/*  751: 741 */         mbo.setReadOnly("PRIMARYSCAN", true);
/*  752: 742 */         mbo.setReadOnly("SECONDARYSCAN", true);
/*  753:     */       }
/*  754:     */     }
/*  755: 745 */     if (barCodingEnabled()) {
/*  756: 746 */       for (int x = 0; x < colSelDataBean.count(); x++)
/*  757:     */       {
/*  758: 747 */         MobileMbo mbo = colSelDataBean.getMobileMbo(x);
/*  759: 748 */         if ((primary < 0) || (x == primary)) {
/*  760: 749 */           mbo.setReadOnly("SECONDARYSCAN", true);
/*  761:     */         }
/*  762:     */       }
/*  763:     */     }
/*  764: 753 */     UIUtil.getApplication().showScreen(tabColSelCtrl, this, true, true);
/*  765: 754 */     return true;
/*  766:     */   }
/*  767:     */   
/*  768:     */   protected boolean saveColSettings(String inColwidth)
/*  769:     */     throws MobileApplicationException
/*  770:     */   {
/*  771: 758 */     int actualIndex = 0;
/*  772: 759 */     int newWidth = 0;
/*  773: 760 */     ControlData[] childrenData = this.controlAttributes.getChildControlData();
/*  774: 761 */     if (inColwidth != null)
/*  775:     */     {
/*  776: 762 */       int curCol = Integer.parseInt(inColwidth.substring(0, inColwidth.indexOf(":")));
/*  777: 763 */       newWidth = Integer.parseInt(inColwidth.substring(inColwidth.indexOf(":") + 1));
/*  778: 764 */       actualIndex = getTableColumVectorValue(curCol).getColIndex();
/*  779: 771 */       if (((this.multiselect) && (actualIndex == 0)) || ((this.multiselect) && (actualIndex == -1))) {
/*  780: 772 */         return true;
/*  781:     */       }
/*  782:     */     }
/*  783: 777 */     MobileMboDataBeanManager dataBeanManager = new MobileMboDataBeanManager("TABCOLSEL");
/*  784: 778 */     this.tabColSelectBean = dataBeanManager.getDataBean();
/*  785: 779 */     this.tabColSelectBean.getQBE().setQBE("CTRLID", getValue("id"));
/*  786: 780 */     this.tabColSelectBean.getQBE().setQBE("TABLEID", getStringValue("datasrcname"));
/*  787: 781 */     if (inColwidth != null) {
/*  788: 782 */       this.tabColSelectBean.getQBE().setQBE("COLID", childrenData[actualIndex].getValue("id"));
/*  789:     */     }
/*  790: 784 */     this.tabColSelectBean.getQBE().setQbeExactMatch(true);
/*  791: 785 */     this.tabColSelectBean.reset();
/*  792: 787 */     if (this.tabColSelectBean.dataExists(0))
/*  793:     */     {
/*  794: 788 */       if (newWidth > 0)
/*  795:     */       {
/*  796: 789 */         this.tabColSelectBean.setCurrentPosition(0);
/*  797: 790 */         this.tabColSelectBean.setValue("COLWIDTH", Integer.toString(newWidth));
/*  798: 791 */         this.tabColSelectBean.getDataBeanManager().save();
/*  799: 792 */         this.tabColSelectBean.reset();
/*  800:     */       }
/*  801:     */     }
/*  802: 796 */     else if (childrenData[actualIndex].getValue("dataattribute") != null) {
/*  803: 797 */       addColumnData(this.tabColSelectBean);
/*  804:     */     }
/*  805: 799 */     this.tabColSelectBean = null;
/*  806: 800 */     return true;
/*  807:     */   }
/*  808:     */   
/*  809:     */   protected boolean sortTable(int colIndex)
/*  810:     */     throws MobileApplicationException
/*  811:     */   {
/*  812: 804 */     TableColumnData inTabColData = (TableColumnData)this.tcoldataVector.get(colIndex);
/*  813: 805 */     if (inTabColData.isSortable())
/*  814:     */     {
/*  815: 806 */       String column = inTabColData.getDataAttribute();
/*  816: 807 */       if (column != null)
/*  817:     */       {
/*  818: 808 */         MobileMboDataBean dataBean = getDataBean();
/*  819: 809 */         Set selectedColumns = getSelectedColumns();
/*  820: 810 */         dataBean.setDefaultOrder();
/*  821: 811 */         dataBean.getOrder().resetOrder(column);
/*  822: 812 */         switch (inTabColData.getSortState())
/*  823:     */         {
/*  824:     */         case 0: 
/*  825: 814 */           getTableWidget().setSortImage(0);
/*  826: 815 */           resetTableColumnSortState(colIndex);
/*  827: 816 */           dataBean.getOrder().setOrderFirst(column, true);
/*  828: 817 */           inTabColData.setSortState(1);
/*  829: 818 */           break;
/*  830:     */         case 1: 
/*  831: 820 */           getTableWidget().setSortImage(1);
/*  832: 821 */           dataBean.getOrder().setOrderFirst(column, false);
/*  833: 822 */           inTabColData.setSortState(2);
/*  834: 823 */           break;
/*  835:     */         case 2: 
/*  836:     */         default: 
/*  837: 826 */           getTableWidget().setSortImage(2);
/*  838: 827 */           inTabColData.setSortState(0);
/*  839:     */         }
/*  840: 830 */         dataBean.reset();
/*  841: 831 */         restoreSelectedColumns(selectedColumns);
/*  842: 832 */         setTableColumVectorValue(colIndex, inTabColData);
/*  843: 833 */         resetColumnHeaders();
/*  844: 834 */         getTableWidget().updateTableCaption(colIndex, inTabColData.getCaption(), true, true);
/*  845: 835 */         refreshAfterSort(colIndex);
/*  846: 836 */         return true;
/*  847:     */       }
/*  848: 838 */       return false;
/*  849:     */     }
/*  850: 841 */     return false;
/*  851:     */   }
/*  852:     */   
/*  853:     */   private void restoreSelectedColumns(Set selectedColumns)
/*  854:     */     throws MobileApplicationException
/*  855:     */   {
/*  856: 847 */     MobileMboDataBean data = getDataBean();
/*  857: 849 */     if ((data != null) && (isTableCol(data))) {
/*  858: 852 */       for (int i = 0; i < data.count(); i++)
/*  859:     */       {
/*  860: 853 */         MobileMbo current = data.getMobileMbo(i);
/*  861: 854 */         String id = current.getValue(getIdField(data.getName()));
/*  862: 855 */         current.setBooleanValue(getCheckboxField(data.getName()), selectedColumns.contains(id));
/*  863: 857 */         if (current.getBooleanValue("FIXED")) {
/*  864: 858 */           current.setReadOnly(getCheckboxField(data.getName()), true);
/*  865:     */         }
/*  866:     */       }
/*  867:     */     }
/*  868:     */   }
/*  869:     */   
/*  870:     */   private Set getSelectedColumns()
/*  871:     */     throws MobileApplicationException
/*  872:     */   {
/*  873: 866 */     MobileMboDataBean data = getDataBean();
/*  874: 868 */     if ((data == null) || (!isTableCol(data))) {
/*  875: 869 */       return new HashSet();
/*  876:     */     }
/*  877: 871 */     Set selectedColumns = new HashSet();
/*  878: 874 */     for (int i = 0; i < data.count(); i++)
/*  879:     */     {
/*  880: 875 */       MobileMbo current = data.getMobileMbo(i);
/*  881: 876 */       if (current.getBooleanValue(getCheckboxField(data.getName()))) {
/*  882: 877 */         selectedColumns.add(current.getValue(getIdField(data.getName())));
/*  883:     */       }
/*  884:     */     }
/*  885: 880 */     return selectedColumns;
/*  886:     */   }
/*  887:     */   
/*  888:     */   private boolean isTableCol(MobileMboDataBean data)
/*  889:     */   {
/*  890: 886 */     for (int i = 0; i < checkboxColumnObjects.length; i++) {
/*  891: 887 */       if (checkboxColumnObjects[i].equalsIgnoreCase(data.getName())) {
/*  892: 888 */         return true;
/*  893:     */       }
/*  894:     */     }
/*  895: 891 */     return false;
/*  896:     */   }
/*  897:     */   
/*  898:     */   private String getCheckboxField(String dataBeanName)
/*  899:     */   {
/*  900: 896 */     if (dataBeanName.equals("TABCOLSEL")) {
/*  901: 897 */       return "DISPLAY";
/*  902:     */     }
/*  903: 899 */     if ((dataBeanName.equals("WORKQUERY")) || (dataBeanName.equals("RELATEDQUERY"))) {
/*  904: 900 */       return "DOWNLOADDEFAULT";
/*  905:     */     }
/*  906: 903 */     return null;
/*  907:     */   }
/*  908:     */   
/*  909:     */   private String getIdField(String dataBeanName)
/*  910:     */   {
/*  911: 908 */     if (dataBeanName.equals("TABCOLSEL")) {
/*  912: 909 */       return "COLID";
/*  913:     */     }
/*  914: 911 */     if ((dataBeanName.equals("WORKQUERY")) || (dataBeanName.equals("RELATEDQUERY"))) {
/*  915: 912 */       return "QUERYNAME";
/*  916:     */     }
/*  917: 915 */     return null;
/*  918:     */   }
/*  919:     */   
/*  920:     */   private void resetTableColumnSortState(int index)
/*  921:     */   {
/*  922: 919 */     Vector curTableVector = getTableColumVector();
/*  923: 920 */     int size = curTableVector.size();
/*  924: 921 */     for (int i = 0; i < size; i++) {
/*  925: 922 */       if (index != i)
/*  926:     */       {
/*  927: 923 */         TableColumnData tcd = (TableColumnData)curTableVector.get(i);
/*  928: 924 */         tcd.setSortState(0);
/*  929: 925 */         setTableColumVectorValue(i, tcd);
/*  930:     */       }
/*  931:     */     }
/*  932:     */   }
/*  933:     */   
/*  934:     */   private String getBoundLabel(String attribute)
/*  935:     */     throws MobileApplicationException
/*  936:     */   {
/*  937: 932 */     if (attribute != null)
/*  938:     */     {
/*  939: 933 */       MobileMboAttributeInfo info = getDataBean().getMobileMboInfo().getAttributeInfo(attribute);
/*  940: 934 */       if (info != null) {
/*  941: 935 */         return info.getTitle();
/*  942:     */       }
/*  943: 937 */       return "<not-found>";
/*  944:     */     }
/*  945: 939 */     return "";
/*  946:     */   }
/*  947:     */   
/*  948:     */   public int getCurFirstRow()
/*  949:     */   {
/*  950: 943 */     return this.curLastRow == 0 ? 0 : this.curFirstRow + 1;
/*  951:     */   }
/*  952:     */   
/*  953:     */   public int getCurLastRow()
/*  954:     */   {
/*  955: 947 */     return this.curLastRow;
/*  956:     */   }
/*  957:     */   
/*  958:     */   private Vector getTableColumVector()
/*  959:     */   {
/*  960: 954 */     return this.tcoldataVector;
/*  961:     */   }
/*  962:     */   
/*  963:     */   private void setTableColumVectorValue(int colIndex, TableColumnData tcolData)
/*  964:     */   {
/*  965: 962 */     getTableColumVector().remove(colIndex);
/*  966: 963 */     getTableColumVector().add(colIndex, tcolData);
/*  967:     */   }
/*  968:     */   
/*  969:     */   private TableColumnData getTableColumVectorValue(int colIndex)
/*  970:     */   {
/*  971: 967 */     return (TableColumnData)getTableColumVector().get(colIndex);
/*  972:     */   }
/*  973:     */   
/*  974:     */   public int getActiveColumns()
/*  975:     */   {
/*  976: 974 */     return this.numofColumns;
/*  977:     */   }
/*  978:     */   
/*  979:     */   protected boolean resetColumnHeaders()
/*  980:     */     throws MobileApplicationException
/*  981:     */   {
/*  982: 978 */     TableWidget tableWidget = getTableWidget();
/*  983:     */     
/*  984: 980 */     int count = this.tcoldataVector.size();
/*  985: 981 */     tableWidget.cleanHeaders(false);
/*  986: 982 */     for (int i = 0; i < count; i++)
/*  987:     */     {
/*  988: 983 */       TableColumnData tempColData = (TableColumnData)this.tcoldataVector.get(i);
/*  989: 984 */       tableWidget.setTableCaption(i, tempColData.getCaption(), false, tempColData.isSortable());
/*  990:     */     }
/*  991: 986 */     return true;
/*  992:     */   }
/*  993:     */   
/*  994:     */   protected boolean checkDisplayMode(ControlData childData)
/*  995:     */     throws MobileApplicationException
/*  996:     */   {
/*  997: 990 */     if (isUiTestMode()) {
/*  998: 991 */       return true;
/*  999:     */     }
/* 1000: 995 */     if ((childData == null) || ("scanevent".equalsIgnoreCase(childData.getName()))) {
/* 1001: 996 */       return false;
/* 1002:     */     }
/* 1003: 998 */     if (this.tabColSelectBean == null)
/* 1004:     */     {
/* 1005: 999 */       MobileMboDataBeanManager dataBeanManager = new MobileMboDataBeanManager("TABCOLSEL");
/* 1006:1000 */       this.tabColSelectBean = dataBeanManager.getDataBean();
/* 1007:     */       
/* 1008:1002 */       this.tabColSelectBean.getQBE().setQbeExactMatch(true);
/* 1009:1003 */       this.tabColSelectBean.getQBE().setQBE("CTRLID", getValue("id"));
/* 1010:1004 */       this.tabColSelectBean.getQBE().setQBE("TABLEID", getStringValue("datasrcname"));
/* 1011:1005 */       this.tabColSelectBean.reset();
/* 1012:1006 */       this.primaryAttr = null;
/* 1013:1007 */       this.primaryLabel = null;
/* 1014:1008 */       this.secondaryAttr = null;
/* 1015:1009 */       this.secondaryLabel = null;
/* 1016:     */     }
/* 1017:1013 */     if (this.tabColSelectBean.count() == 0)
/* 1018:     */     {
/* 1019:1014 */       String scanType = childData.getValue("scantype");
/* 1020:1015 */       if (scanType != null) {
/* 1021:1016 */         if ((this.primaryAttr == null) && (scanType.equalsIgnoreCase("primary")))
/* 1022:     */         {
/* 1023:1017 */           this.primaryAttr = childData.getValue("dataattribute");
/* 1024:1018 */           this.pInsertAttr = childData.getValue("scaninsertattribute");
/* 1025:1019 */           if (this.pInsertAttr == null) {
/* 1026:1020 */             this.pInsertAttr = this.primaryAttr;
/* 1027:     */           }
/* 1028:1021 */           this.primaryLabel = childData.getValue("label");
/* 1029:1022 */           if ((UIUtil.isNull(this.primaryLabel)) && (this.primaryAttr != null))
/* 1030:     */           {
/* 1031:1023 */             MobileMboAttributeInfo aInfo = getDataBean().getMobileMboInfo().getAttributeInfo(this.primaryAttr);
/* 1032:1024 */             this.primaryLabel = aInfo.getTitle();
/* 1033:     */           }
/* 1034:     */         }
/* 1035:1026 */         else if ((this.secondaryAttr == null) && (scanType.equalsIgnoreCase("secondary")))
/* 1036:     */         {
/* 1037:1027 */           this.secondaryAttr = childData.getValue("dataattribute");
/* 1038:1028 */           this.sInsertAttr = childData.getValue("scaninsertattribute");
/* 1039:1029 */           if (this.sInsertAttr == null) {
/* 1040:1030 */             this.sInsertAttr = this.secondaryAttr;
/* 1041:     */           }
/* 1042:1031 */           this.secondaryLabel = childData.getValue("label");
/* 1043:1032 */           if ((UIUtil.isNull(this.secondaryLabel)) && (this.secondaryAttr != null))
/* 1044:     */           {
/* 1045:1033 */             MobileMboAttributeInfo aInfo = getDataBean().getMobileMboInfo().getAttributeInfo(this.secondaryAttr);
/* 1046:1034 */             this.secondaryLabel = aInfo.getTitle();
/* 1047:     */           }
/* 1048:     */         }
/* 1049:     */       }
/* 1050:     */     }
/* 1051:     */     else
/* 1052:     */     {
/* 1053:1039 */       this.tabColSelectBean.setCurrentPosition(0);
/* 1054:1040 */       int tabIndex = 0;
/* 1055:1041 */       while (this.tabColSelectBean.dataExists(tabIndex))
/* 1056:     */       {
/* 1057:1042 */         if (this.tabColSelectBean.getValue("COLID").equals(childData.getValue("id")))
/* 1058:     */         {
/* 1059:1043 */           if (barCodingEnabled()) {
/* 1060:1044 */             if (this.tabColSelectBean.getMobileMbo().getBooleanValue("PRIMARYSCAN"))
/* 1061:     */             {
/* 1062:1045 */               this.primaryAttr = childData.getValue("dataattribute");
/* 1063:1046 */               this.pInsertAttr = childData.getValue("scaninsertattribute");
/* 1064:1047 */               if (this.pInsertAttr == null) {
/* 1065:1048 */                 this.pInsertAttr = this.primaryAttr;
/* 1066:     */               }
/* 1067:1049 */               this.primaryLabel = childData.getValue("label");
/* 1068:1050 */               this.primaryLabel = childData.getValue("label");
/* 1069:1051 */               if ((UIUtil.isNull(this.primaryLabel)) && (this.primaryAttr != null))
/* 1070:     */               {
/* 1071:1052 */                 MobileMboAttributeInfo aInfo = getDataBean().getMobileMboInfo().getAttributeInfo(this.primaryAttr);
/* 1072:1053 */                 this.primaryLabel = aInfo.getTitle();
/* 1073:     */               }
/* 1074:     */             }
/* 1075:1055 */             else if (this.tabColSelectBean.getMobileMbo().getBooleanValue("SECONDARYSCAN"))
/* 1076:     */             {
/* 1077:1056 */               this.secondaryAttr = childData.getValue("dataattribute");
/* 1078:1057 */               this.sInsertAttr = childData.getValue("scaninsertattribute");
/* 1079:1058 */               if (this.sInsertAttr == null) {
/* 1080:1059 */                 this.sInsertAttr = this.secondaryAttr;
/* 1081:     */               }
/* 1082:1060 */               this.secondaryLabel = childData.getValue("label");
/* 1083:1061 */               if ((UIUtil.isNull(this.secondaryLabel)) && (this.secondaryAttr != null))
/* 1084:     */               {
/* 1085:1062 */                 MobileMboAttributeInfo aInfo = getDataBean().getMobileMboInfo().getAttributeInfo(this.secondaryAttr);
/* 1086:1063 */                 this.secondaryLabel = aInfo.getTitle();
/* 1087:     */               }
/* 1088:     */             }
/* 1089:     */           }
/* 1090:1067 */           if (this.tabColSelectBean.getValue("FIXED").equals("1"))
/* 1091:     */           {
/* 1092:1068 */             setCustomColWidth(Integer.parseInt(this.tabColSelectBean.getValue("COLWIDTH")));
/* 1093:1069 */             return true;
/* 1094:     */           }
/* 1095:1071 */           if (this.tabColSelectBean.getValue("DISPLAY").equals("1"))
/* 1096:     */           {
/* 1097:1072 */             setCustomColWidth(Integer.parseInt(this.tabColSelectBean.getValue("COLWIDTH")));
/* 1098:1073 */             return true;
/* 1099:     */           }
/* 1100:1075 */           return false;
/* 1101:     */         }
/* 1102:1077 */         tabIndex++;
/* 1103:1078 */         this.tabColSelectBean.setCurrentPosition(tabIndex);
/* 1104:     */       }
/* 1105:     */     }
/* 1106:1082 */     if ((childData.getValue("displaymode") == null) || (childData.getValue("displaymode").equals("fixed")) || (childData.getValue("displaymode").equals("visible"))) {
/* 1107:1084 */       return true;
/* 1108:     */     }
/* 1109:1087 */     return false;
/* 1110:     */   }
/* 1111:     */   
/* 1112:     */   public void setActiveColumns(int numofColumns)
/* 1113:     */   {
/* 1114:1095 */     this.numofColumns = numofColumns;
/* 1115:     */   }
/* 1116:     */   
/* 1117:     */   public void computeActiveColumns()
/* 1118:     */     throws MobileApplicationException
/* 1119:     */   {
/* 1120:1099 */     ControlData[] childrenData = this.controlAttributes.getChildControlData();
/* 1121:1100 */     this.totalNumofColumns = childrenData.length;
/* 1122:1101 */     String sMultiSelect = getStringValue("multiselect");
/* 1123:1102 */     if ((sMultiSelect != null) && (sMultiSelect.equalsIgnoreCase("true"))) {
/* 1124:1103 */       setMultiselect(true);
/* 1125:     */     }
/* 1126:1105 */     int activeColCount = 0;
/* 1127:1106 */     for (int i = 0; i < this.totalNumofColumns; i++) {
/* 1128:1107 */       if (checkDisplayMode(childrenData[i]))
/* 1129:     */       {
/* 1130:1108 */         activeColCount++;
/* 1131:     */         
/* 1132:     */ 
/* 1133:1111 */         this.lastActiveColumnIndex = i;
/* 1134:     */       }
/* 1135:     */     }
/* 1136:1116 */     setActiveColumns(activeColCount);
/* 1137:1118 */     if (!isUiTestMode()) {
/* 1138:1119 */       if ((!barCodingEnabled()) || (this.primaryAttr == null)) {
/* 1139:1120 */         ((PageControl)getPage()).setScanTable(null);
/* 1140:     */       } else {
/* 1141:1122 */         ((PageControl)getPage()).setScanTable(this);
/* 1142:     */       }
/* 1143:     */     }
/* 1144:     */   }
/* 1145:     */   
/* 1146:     */   protected boolean setTableColumn(boolean needClean)
/* 1147:     */     throws MobileApplicationException
/* 1148:     */   {
/* 1149:1129 */     String tablerange = MobileUIProperties.getStringValue("table.lowrange");
/* 1150:1130 */     int basewidth = Integer.parseInt(tablerange.substring(tablerange.indexOf(':') + 1));
/* 1151:1131 */     tablerange = MobileUIProperties.getStringValue("table.lowmidrange");
/* 1152:1132 */     int lmidrange = Integer.parseInt(tablerange.substring(0, tablerange.indexOf('+')));
/* 1153:1133 */     int lmidwidth = Integer.parseInt(tablerange.substring(tablerange.indexOf(':') + 1));
/* 1154:1134 */     tablerange = MobileUIProperties.getStringValue("table.midrange");
/* 1155:1135 */     int midrange = Integer.parseInt(tablerange.substring(0, tablerange.indexOf('+')));
/* 1156:1136 */     int midwidth = Integer.parseInt(tablerange.substring(tablerange.indexOf(':') + 1));
/* 1157:1137 */     tablerange = MobileUIProperties.getStringValue("table.lowhighrange");
/* 1158:1138 */     int lhighrange = Integer.parseInt(tablerange.substring(0, tablerange.indexOf('+')));
/* 1159:1139 */     int lhighwidth = Integer.parseInt(tablerange.substring(tablerange.indexOf(':') + 1));
/* 1160:1140 */     tablerange = MobileUIProperties.getStringValue("table.highrange");
/* 1161:1141 */     int highrange = Integer.parseInt(tablerange.substring(0, tablerange.indexOf('+')));
/* 1162:1142 */     int highwidth = Integer.parseInt(tablerange.substring(tablerange.indexOf(':') + 1));
/* 1163:1143 */     ControlData[] childrenData = this.controlAttributes.getChildControlData();
/* 1164:1144 */     int tempIndex = 0;
/* 1165:1145 */     int tableWidth = 0;
/* 1166:     */     
/* 1167:1147 */     TableWidget tableWidget = getTableWidget();
/* 1168:1148 */     if (needClean)
/* 1169:     */     {
/* 1170:1149 */       tableWidget.cleanHeaders(true);
/* 1171:1150 */       this.tcoldataVector = new Vector();
/* 1172:     */     }
/* 1173:1152 */     if (isMultiselect())
/* 1174:     */     {
/* 1175:1153 */       tableWidget.setTableCaption(0, "");
/* 1176:1154 */       tableWidget.setTableColWidth(0, basewidth);
/* 1177:1155 */       this.tcoldataVector.add(tempIndex, new TableColumnData(-1, "", 0, false, null, "", "fixed", "", 20));
/* 1178:1156 */       tempIndex++;
/* 1179:1157 */       tableWidth = 20;
/* 1180:     */     }
/* 1181:1159 */     setCustomColWidth(0);
/* 1182:1160 */     for (int i = 0; i < this.totalNumofColumns; i++) {
/* 1183:1161 */       if (checkDisplayMode(childrenData[i]))
/* 1184:     */       {
/* 1185:1162 */         String colLabel = childrenData[i].getValue("label");
/* 1186:1163 */         String dataAttr = childrenData[i].getValue("dataattribute");
/* 1187:1164 */         if (colLabel == null) {
/* 1188:1165 */           colLabel = getBoundLabel(childrenData[i].getValue("dataattribute"));
/* 1189:     */         }
/* 1190:1167 */         int customWidth = getCustomColWidth();
/* 1191:1168 */         int curColWidth = basewidth;
/* 1192:1169 */         if (customWidth > 0)
/* 1193:     */         {
/* 1194:1171 */           curColWidth = customWidth;
/* 1195:1172 */           setCustomColWidth(0);
/* 1196:     */         }
/* 1197:     */         else
/* 1198:     */         {
/* 1199:1174 */           curColWidth = tableWidget.calculateColWidthForControlData(childrenData[i], curColWidth, colLabel, dataAttr, highrange, highwidth, lhighrange, lhighwidth, midrange, midwidth, lmidrange, lmidwidth, basewidth);
/* 1200:     */           
/* 1201:     */ 
/* 1202:1177 */           int totalOffSet = (getActiveColumns() + 1) * 1 + getActiveColumns() * (tableWidget.getTablePaddingRight() + tableWidget.getTablePaddingLeft());
/* 1203:1178 */           int screenSize = UIUtil.getApplication().getWindowWidth() - totalOffSet;
/* 1204:1179 */           if (screenSize > UIUtil.getApplication().getWindowMaxSizeForTable()) {
/* 1205:1180 */             screenSize = UIUtil.getApplication().getWindowMaxSizeForTable();
/* 1206:     */           }
/* 1207:1184 */           if ((i == this.lastActiveColumnIndex) && (screenSize > tableWidth + 20)) {
/* 1208:1185 */             curColWidth = tableWidget.calculateLastColumnWidth(curColWidth, screenSize, tableWidth);
/* 1209:     */           }
/* 1210:     */         }
/* 1211:1188 */         tableWidth += curColWidth;
/* 1212:1189 */         boolean isSortable = true;
/* 1213:1190 */         String sortflag = childrenData[i].getValue("sortable");
/* 1214:1191 */         MobileMboDataBean bean = getDataBean();
/* 1215:1197 */         if (dataAttr != null) {
/* 1216:1198 */           if (dataAttr.indexOf('.') > 0)
/* 1217:     */           {
/* 1218:1199 */             isSortable = false;
/* 1219:     */           }
/* 1220:1200 */           else if (bean != null)
/* 1221:     */           {
/* 1222:1201 */             MobileMboAttributeInfo attributeInfo = bean.getMobileMboInfo().getAttributeInfo(dataAttr);
/* 1223:1202 */             if (attributeInfo != null)
/* 1224:     */             {
/* 1225:1203 */               if (bean.isOnline()) {
/* 1226:1204 */                 isSortable = !attributeInfo.isRelationshipBased();
/* 1227:     */               }
/* 1228:1207 */               if (isSortable) {
/* 1229:1208 */                 isSortable = attributeInfo.isSortable();
/* 1230:     */               }
/* 1231:     */             }
/* 1232:     */           }
/* 1233:     */         }
/* 1234:1214 */         if ((sortflag != null) && (isSortable)) {
/* 1235:1215 */           isSortable = Boolean.valueOf(sortflag).booleanValue();
/* 1236:     */         }
/* 1237:1222 */         tableWidget.setTableCaption(tempIndex, colLabel, false, isSortable);
/* 1238:1223 */         tableWidget.setTableColWidth(tempIndex, curColWidth);
/* 1239:     */         
/* 1240:1225 */         String dispAttr = childrenData[i].getValue("displaymode");
/* 1241:1226 */         if (dispAttr == null) {
/* 1242:1227 */           dispAttr = "visible";
/* 1243:     */         }
/* 1244:1229 */         this.tcoldataVector.add(tempIndex, new TableColumnData(i, dataAttr, 0, isSortable, null, colLabel, dispAttr, childrenData[i].getValue("showdataattribute"), curColWidth));
/* 1245:     */         
/* 1246:     */ 
/* 1247:     */ 
/* 1248:1233 */         tempIndex++;
/* 1249:     */       }
/* 1250:     */     }
/* 1251:1236 */     return true;
/* 1252:     */   }
/* 1253:     */   
/* 1254:     */   protected void setTableRows()
/* 1255:     */   {
/* 1256:1244 */     String tableHeightStr = MobileUIProperties.getStringValue("table.rowheight");
/* 1257:1245 */     int total = 0;
/* 1258:1246 */     if ((this.curLastRow > 0) && (this.curFirstRow >= 0)) {
/* 1259:1247 */       total = this.curLastRow - this.curFirstRow;
/* 1260:     */     }
/* 1261:1249 */     int displayRows = getDisplayRows();
/* 1262:1250 */     int tableHeight = Integer.parseInt(tableHeightStr);
/* 1263:     */     
/* 1264:1252 */     TableWidget tableWidget = getTableWidget();
/* 1265:1253 */     for (int i = 0; (i < total) && (i < displayRows); i++) {
/* 1266:1254 */       tableWidget.setTableRowHeight(i, tableHeight);
/* 1267:     */     }
/* 1268:     */   }
/* 1269:     */   
/* 1270:     */   public boolean isMultiselect()
/* 1271:     */   {
/* 1272:1262 */     return this.multiselect;
/* 1273:     */   }
/* 1274:     */   
/* 1275:     */   public void setMultiselect(boolean multiselect)
/* 1276:     */   {
/* 1277:1270 */     this.multiselect = multiselect;
/* 1278:     */   }
/* 1279:     */   
/* 1280:     */   public int getDisplayRows()
/* 1281:     */   {
/* 1282:1277 */     return this.displayRows;
/* 1283:     */   }
/* 1284:     */   
/* 1285:     */   public void setDisplayRows()
/* 1286:     */     throws MobileApplicationException
/* 1287:     */   {
/* 1288:1285 */     if (isUiTestMode())
/* 1289:     */     {
/* 1290:1286 */       this.displayRows = 9;
/* 1291:1287 */       return;
/* 1292:     */     }
/* 1293:1290 */     int dataCount = getDataBean() == null ? 0 : getDataBean().count();
/* 1294:1291 */     this.displayRows = (dataCount < this.maxRows ? dataCount : this.maxRows);
/* 1295:1292 */     if (((UIUtil.getCurrentScreen() instanceof LookupControl)) && (dataCount > this.dataFetchSize))
/* 1296:     */     {
/* 1297:1293 */       this.displayRows = 0;
/* 1298:1294 */       Object[] param = { Integer.toString(this.dataFetchSize) };
/* 1299:1295 */       UIUtil.showMessageBox(MobileMessageGenerator.generate("fetchsizex", param));
/* 1300:     */     }
/* 1301:     */   }
/* 1302:     */   
/* 1303:     */   public boolean refreshToolBar(UIEvent event)
/* 1304:     */     throws MobileApplicationException
/* 1305:     */   {
/* 1306:1300 */     if (getToolBar() != null) {
/* 1307:1301 */       getToolBar().refresh(event);
/* 1308:     */     }
/* 1309:1303 */     return true;
/* 1310:     */   }
/* 1311:     */   
/* 1312:     */   public boolean isColorCode()
/* 1313:     */   {
/* 1314:1310 */     return this.colorCode;
/* 1315:     */   }
/* 1316:     */   
/* 1317:     */   public void setColorCode(boolean colorCode)
/* 1318:     */   {
/* 1319:1318 */     this.colorCode = colorCode;
/* 1320:     */   }
/* 1321:     */   
/* 1322:     */   public int getTextWidth(String text)
/* 1323:     */   {
/* 1324:1323 */     if ((text == null) || (text.trim().equals(""))) {
/* 1325:1324 */       return 20;
/* 1326:     */     }
/* 1327:1326 */     return getTextWidth() * text.length();
/* 1328:     */   }
/* 1329:     */   
/* 1330:     */   public int getTextWidth(int fieldLen)
/* 1331:     */   {
/* 1332:1331 */     return getTextWidth() * fieldLen;
/* 1333:     */   }
/* 1334:     */   
/* 1335:     */   private int getTextWidth()
/* 1336:     */   {
/* 1337:1338 */     if (this.textWidth == 0) {
/* 1338:1339 */       this.textWidth = getTableWidget().getTextWidth();
/* 1339:     */     }
/* 1340:1341 */     return this.textWidth;
/* 1341:     */   }
/* 1342:     */   
/* 1343:     */   public ControlStyle getRowStyle()
/* 1344:     */   {
/* 1345:1350 */     if (isColorCode())
/* 1346:     */     {
/* 1347:     */       try
/* 1348:     */       {
/* 1349:1352 */         MobileMboDataBean curDataBean = getDataBean();
/* 1350:1353 */         if (curDataBean != null)
/* 1351:     */         {
/* 1352:1354 */           if (curDataBean.hasError()) {
/* 1353:1355 */             return StyleManager.getStyle("rowerrored.table", null);
/* 1354:     */           }
/* 1355:1356 */           if (!curDataBean.isComplete()) {
/* 1356:1357 */             return StyleManager.getStyle("rowincomplete.table", null);
/* 1357:     */           }
/* 1358:1358 */           if (curDataBean.isMobileMboModified()) {
/* 1359:1359 */             return StyleManager.getStyle("rowmodified.table", null);
/* 1360:     */           }
/* 1361:     */         }
/* 1362:     */       }
/* 1363:     */       catch (Exception ex)
/* 1364:     */       {
/* 1365:1364 */         getDefaultLogger().warn("Failed to get row style", ex);
/* 1366:     */       }
/* 1367:1366 */       return getDefaultStyle();
/* 1368:     */     }
/* 1369:1368 */     return getDefaultStyle();
/* 1370:     */   }
/* 1371:     */   
/* 1372:     */   private ControlStyle getDefaultStyle()
/* 1373:     */   {
/* 1374:1376 */     return StyleManager.getStyle("table", null);
/* 1375:     */   }
/* 1376:     */   
/* 1377:     */   public int getCustomColWidth()
/* 1378:     */   {
/* 1379:1383 */     return this.customColWidth;
/* 1380:     */   }
/* 1381:     */   
/* 1382:     */   public void setCustomColWidth(int customColWidth)
/* 1383:     */   {
/* 1384:1391 */     this.customColWidth = customColWidth;
/* 1385:     */   }
/* 1386:     */   
/* 1387:     */   public boolean primarycheck(UIEvent event)
/* 1388:     */     throws MobileApplicationException
/* 1389:     */   {
/* 1390:1404 */     boolean newValue = Boolean.valueOf((String)event.getValue()).booleanValue();
/* 1391:1405 */     MobileMboDataBean dataBean = getDataBean();
/* 1392:1406 */     int currentRow = dataBean.getCurrentPosition();
/* 1393:1407 */     for (int x = 0; x < dataBean.count(); x++)
/* 1394:     */     {
/* 1395:1408 */       MobileMbo mbo = dataBean.getMobileMbo(x);
/* 1396:1409 */       if (newValue)
/* 1397:     */       {
/* 1398:1410 */         dataBean.setValue("SECONDARYSCAN", "0");
/* 1399:1412 */         if (mbo.getBooleanValue("PRIMARYSCAN")) {
/* 1400:1413 */           mbo.setValue("PRIMARYSCAN", "0");
/* 1401:     */         }
/* 1402:1415 */         mbo.setReadOnly("SECONDARYSCAN", currentRow == x);
/* 1403:     */       }
/* 1404:     */       else
/* 1405:     */       {
/* 1406:1418 */         mbo.setValue("SECONDARYSCAN", "0");
/* 1407:1419 */         mbo.setReadOnly("SECONDARYSCAN", true);
/* 1408:     */       }
/* 1409:     */     }
/* 1410:1422 */     return true;
/* 1411:     */   }
/* 1412:     */   
/* 1413:     */   public boolean secondarycheck(UIEvent event)
/* 1414:     */     throws MobileApplicationException
/* 1415:     */   {
/* 1416:1435 */     boolean newValue = Boolean.valueOf((String)event.getValue()).booleanValue();
/* 1417:1436 */     MobileMboDataBean dataBean = getDataBean();
/* 1418:1437 */     for (int x = 0; x < dataBean.count(); x++)
/* 1419:     */     {
/* 1420:1438 */       MobileMbo mbo = dataBean.getMobileMbo(x);
/* 1421:1439 */       if (newValue) {
/* 1422:1441 */         if (mbo.getBooleanValue("SECONDARYSCAN")) {
/* 1423:1442 */           mbo.setValue("SECONDARYSCAN", "0");
/* 1424:     */         }
/* 1425:     */       }
/* 1426:     */     }
/* 1427:1446 */     return true;
/* 1428:     */   }
/* 1429:     */   
/* 1430:     */   public boolean sendScanEvent(boolean insert)
/* 1431:     */     throws MobileApplicationException
/* 1432:     */   {
/* 1433:1460 */     boolean eventSent = false;
/* 1434:     */     
/* 1435:1462 */     ControlData eventData = null;
/* 1436:1463 */     if (insert)
/* 1437:     */     {
/* 1438:1464 */       if (this.scanInsertEvent == null) {
/* 1439:1465 */         return false;
/* 1440:     */       }
/* 1441:1466 */       eventData = this.scanInsertEvent;
/* 1442:     */     }
/* 1443:     */     else
/* 1444:     */     {
/* 1445:1468 */       if (this.scanViewEvent == null) {
/* 1446:1469 */         return false;
/* 1447:     */       }
/* 1448:1470 */       String option = this.scanViewEvent.getValue("sigoption");
/* 1449:1471 */       if ((option != null) && (!getDataBean().isOptionAuthorized(option))) {
/* 1450:1472 */         return false;
/* 1451:     */       }
/* 1452:1474 */       eventData = this.scanViewEvent;
/* 1453:     */     }
/* 1454:1476 */     UIEvent scanEvent = new UIEvent(this, eventData.getValue("event"), eventData.getValue("targetid"), eventData.getValue("value"));
/* 1455:1478 */     if (scanEvent != null)
/* 1456:     */     {
/* 1457:1479 */       if (scanEvent.getEventName().equalsIgnoreCase("filter")) {
/* 1458:1480 */         return false;
/* 1459:     */       }
/* 1460:1484 */       UIUtil.refreshCurrentScreen();
/* 1461:     */       
/* 1462:1486 */       eventSent = handleEvent(scanEvent) == true;
/* 1463:     */     }
/* 1464:1488 */     if ((eventSent) && (!insert))
/* 1465:     */     {
/* 1466:1492 */       MobileDeviceAppSession session = MobileDeviceAppSession.getSession();
/* 1467:1493 */       if (getScanState() == 1) {
/* 1468:1494 */         session.setAttribute(getId() + REMOVE_SCAN, this.primaryAttr);
/* 1469:     */       } else {
/* 1470:1496 */         session.setAttribute(getId() + REMOVE_SCAN, this.secondaryAttr);
/* 1471:     */       }
/* 1472:     */     }
/* 1473:1498 */     return eventSent;
/* 1474:     */   }
/* 1475:     */   
/* 1476:     */   public void removeLastScan(boolean checkFlag)
/* 1477:     */     throws MobileApplicationException
/* 1478:     */   {
/* 1479:1512 */     MobileDeviceAppSession session = MobileDeviceAppSession.getSession();
/* 1480:1513 */     String scanAttr = null;
/* 1481:1514 */     if (checkFlag)
/* 1482:     */     {
/* 1483:1517 */       scanAttr = (String)session.getAttribute(getId() + REMOVE_SCAN);
/* 1484:1518 */       if (scanAttr == null) {
/* 1485:1520 */         return;
/* 1486:     */       }
/* 1487:     */     }
/* 1488:1524 */     session.removeAttribute(getId() + REMOVE_SCAN);
/* 1489:1525 */     MobileMboDataBean databean = getDataBean();
/* 1490:1526 */     if (!databean.isFiltered())
/* 1491:     */     {
/* 1492:1528 */       setScanState(0);
/* 1493:1529 */       return;
/* 1494:     */     }
/* 1495:1531 */     MobileMboQBE qbe = databean.getQBE();
/* 1496:1532 */     if (getScanState() == 2)
/* 1497:     */     {
/* 1498:1533 */       if (scanAttr == null) {
/* 1499:1534 */         scanAttr = this.secondaryAttr;
/* 1500:     */       }
/* 1501:1535 */       qbe.setQBE(scanAttr, null);
/* 1502:1536 */       setScanState(1);
/* 1503:1537 */       databean.reset();
/* 1504:1538 */       databean.setFiltered(true);
/* 1505:     */     }
/* 1506:     */     else
/* 1507:     */     {
/* 1508:1540 */       qbe.reset();
/* 1509:1541 */       qbe.setQbeExactMatch(false);
/* 1510:1542 */       databean.reset();
/* 1511:1543 */       databean.setFiltered(false);
/* 1512:1544 */       setScanState(0);
/* 1513:     */     }
/* 1514:1546 */     databean.setCurrentPosition(0);
/* 1515:     */   }
/* 1516:     */   
/* 1517:     */   private TextboxControl getBarcodeControl(AbstractMobileControl parent, String attribute)
/* 1518:     */   {
/* 1519:1552 */     TextboxControl retControl = null;
/* 1520:1553 */     Iterator iter = parent.getChildren();
/* 1521:1555 */     while ((iter != null) && (iter.hasNext()))
/* 1522:     */     {
/* 1523:1556 */       AbstractMobileControl tempControl = (AbstractMobileControl)iter.next();
/* 1524:1557 */       if ((tempControl != null) && ((tempControl instanceof TextboxControl)))
/* 1525:     */       {
/* 1526:1558 */         retControl = (TextboxControl)tempControl;
/* 1527:1559 */         if (retControl.dataAttribute.equalsIgnoreCase(attribute)) {
/* 1528:     */           break;
/* 1529:     */         }
/* 1530:     */       }
/* 1531:     */       else
/* 1532:     */       {
/* 1533:1563 */         retControl = getBarcodeControl(tempControl, attribute);
/* 1534:1565 */         if ((retControl != null) && 
/* 1535:     */         
/* 1536:     */ 
/* 1537:     */ 
/* 1538:1569 */           (retControl.dataAttribute.equalsIgnoreCase(attribute))) {
/* 1539:     */           break;
/* 1540:     */         }
/* 1541:     */       }
/* 1542:     */     }
/* 1543:1575 */     return retControl;
/* 1544:     */   }
/* 1545:     */   
/* 1546:     */   public boolean barcoderead(UIEvent event)
/* 1547:     */     throws MobileApplicationException
/* 1548:     */   {
/* 1549:1586 */     if (!barCodingEnabled()) {
/* 1550:1587 */       return true;
/* 1551:     */     }
/* 1552:1589 */     String scanValue = (String)event.getValue();
/* 1553:1590 */     MobileMboDataBean databean = getDataBean();
/* 1554:1591 */     MobileMboQBE qbe = databean.getQBE();
/* 1555:1592 */     if (this.scaninsertflag > 0)
/* 1556:     */     {
/* 1557:1593 */       String option = this.scanInsertEvent.getValue("sigoption");
/* 1558:1594 */       if ((this.scaninsertflag > 1) && (option != null) && (!this.app.isOptionAuthorized(option)))
/* 1559:     */       {
/* 1560:1595 */         String msg = MobileMessageGenerator.generate("scannoaccess", null);
/* 1561:1596 */         UIUtil.showInfoMessageBox(msg);
/* 1562:1597 */         return true;
/* 1563:     */       }
/* 1564:1602 */       if ((event.getMsgResponse().equals("1")) || (this.scaninsertflag == 2))
/* 1565:     */       {
/* 1566:1603 */         if (this.scaninsertflag > 1) {
/* 1567:1604 */           removeLastScan(false);
/* 1568:     */         }
/* 1569:1608 */         AbstractMobileControl onPage = getPage();
/* 1570:1609 */         if (sendScanEvent(true))
/* 1571:     */         {
/* 1572:1610 */           AbstractMobileControl insertPage = UIUtil.getApplication().getCurrentScreen();
/* 1573:1611 */           if ((insertPage != null) && (insertPage != onPage))
/* 1574:     */           {
/* 1575:1612 */             MobileMboDataBean pageBean = insertPage.getDataBean();
/* 1576:1613 */             if (pageBean != databean) {
/* 1577:1614 */               databean = pageBean;
/* 1578:     */             }
/* 1579:1616 */             if ((databean.getMobileMbo() == null) || (!databean.getMobileMbo().isNew())) {
/* 1580:1617 */               databean.insert();
/* 1581:     */             }
/* 1582:1619 */             if ((getScanState() == 1) && (this.scaninsertflag == 1))
/* 1583:     */             {
/* 1584:1620 */               databean.setValue(this.pInsertAttr, qbe.getQBE(this.primaryAttr));
/* 1585:1621 */               databean.setValue(this.sInsertAttr, scanValue);
/* 1586:     */             }
/* 1587:     */             else
/* 1588:     */             {
/* 1589:1623 */               databean.setValue(this.pInsertAttr, scanValue);
/* 1590:     */               
/* 1591:     */ 
/* 1592:     */ 
/* 1593:     */ 
/* 1594:1628 */               TextboxControl textControl = getBarcodeControl(insertPage, this.pInsertAttr);
/* 1595:1629 */               if ((textControl != null) && 
/* 1596:1630 */                 (textControl.hasTextField()))
/* 1597:     */               {
/* 1598:1633 */                 UIEvent bcEvent = new UIEvent(textControl, "setvalue", null, scanValue);
/* 1599:1634 */                 textControl.setvalue(bcEvent);
/* 1600:     */               }
/* 1601:     */             }
/* 1602:     */           }
/* 1603:     */         }
/* 1604:1640 */         UIUtil.refreshCurrentScreen();
/* 1605:1641 */         return true;
/* 1606:     */       }
/* 1607:1642 */       if (event.getMsgResponse().equals("0"))
/* 1608:     */       {
/* 1609:1643 */         if (this.scaninsertflag == 3) {
/* 1610:1646 */           sendScanEvent(false);
/* 1611:     */         }
/* 1612:1648 */         return true;
/* 1613:     */       }
/* 1614:1649 */       if (event.getMsgResponse().equals("2")) {
/* 1615:1650 */         return true;
/* 1616:     */       }
/* 1617:     */     }
/* 1618:1653 */     if (scanValue == null)
/* 1619:     */     {
/* 1620:1654 */       String msg = MobileMessageGenerator.generate("scannotfound", new Object[] { scanValue });
/* 1621:1655 */       UIUtil.showMessageBox(msg);
/* 1622:1656 */       return true;
/* 1623:     */     }
/* 1624:1659 */     if ((getScanState() == 1) && (this.secondaryAttr != null))
/* 1625:     */     {
/* 1626:1661 */       qbe.setQBE(this.secondaryAttr, scanValue);
/* 1627:1662 */       setScanState(2);
/* 1628:     */     }
/* 1629:     */     else
/* 1630:     */     {
/* 1631:1665 */       qbe.reset();
/* 1632:1666 */       qbe.setQbeExactMatch(true);
/* 1633:1667 */       databean.setFiltered(true);
/* 1634:1668 */       qbe.setQBE(this.primaryAttr, scanValue);
/* 1635:1669 */       setScanState(1);
/* 1636:     */     }
/* 1637:1671 */     databean.reset();
/* 1638:1673 */     switch (databean.count())
/* 1639:     */     {
/* 1640:     */     case 0: 
/* 1641:1675 */       String whatScanned = null;
/* 1642:1676 */       if (getScanState() == 1) {
/* 1643:1677 */         whatScanned = this.primaryLabel;
/* 1644:     */       } else {
/* 1645:1679 */         whatScanned = this.secondaryLabel;
/* 1646:     */       }
/* 1647:1680 */       if (this.scaninsertflag > 0)
/* 1648:     */       {
/* 1649:1683 */         String msg = MobileMessageGenerator.generate("scannotfoundinsert", new Object[] { whatScanned, scanValue, whatScanned });
/* 1650:1684 */         UIUtil.showMessageBox(msg, "question", 12, event);
/* 1651:     */       }
/* 1652:     */       else
/* 1653:     */       {
/* 1654:1687 */         String msg = MobileMessageGenerator.generate("scannotfound", new Object[] { whatScanned, scanValue });
/* 1655:1688 */         UIUtil.showMessageBox(msg);
/* 1656:     */       }
/* 1657:1691 */       removeLastScan(false);
/* 1658:1692 */       break;
/* 1659:     */     case 1: 
/* 1660:1694 */       if ((this.scaninsertflag != 3) || (getScanState() == 2))
/* 1661:     */       {
/* 1662:1695 */         databean.setCurrentPosition(0);
/* 1663:1697 */         if (!sendScanEvent(false)) {
/* 1664:     */           break label657;
/* 1665:     */         }
/* 1666:1698 */         return true;
/* 1667:     */       }
/* 1668:     */       break;
/* 1669:     */     }
/* 1670:1703 */     databean.setCurrentPosition(0);
/* 1671:1707 */     if ((this.scaninsertflag == 3) && (getScanState() == 1))
/* 1672:     */     {
/* 1673:1708 */       String msg = MobileMessageGenerator.generate("scaninsertask", new Object[] { scanValue });
/* 1674:1709 */       UIUtil.showMessageBoxControl("scan_insert_ask", msg, event);
/* 1675:     */     }
/* 1676:     */     label657:
/* 1677:1714 */     UIUtil.refreshCurrentScreen();
/* 1678:1715 */     return true;
/* 1679:     */   }
/* 1680:     */   
/* 1681:     */   public boolean togglescanbutton(UIEvent event)
/* 1682:     */     throws MobileApplicationException
/* 1683:     */   {
/* 1684:1726 */     StateControl state = (StateControl)event.getCreatingObject();
/* 1685:1727 */     state.setVisibility((barCodingEnabled()) && (this.primaryAttr != null));
/* 1686:1728 */     if ((getScanState() > 0) && (this.secondaryAttr != null)) {
/* 1687:1729 */       state.setStateViaState("1");
/* 1688:     */     } else {
/* 1689:1731 */       state.setStateViaState("0");
/* 1690:     */     }
/* 1691:1732 */     return true;
/* 1692:     */   }
/* 1693:     */   
/* 1694:     */   public boolean scaninfo(UIEvent event)
/* 1695:     */     throws MobileApplicationException
/* 1696:     */   {
/* 1697:1744 */     String nextLabel = null;
/* 1698:1745 */     if ((getScanState() == 0) || (this.secondaryAttr == null)) {
/* 1699:1746 */       nextLabel = this.primaryLabel;
/* 1700:     */     } else {
/* 1701:1748 */       nextLabel = this.secondaryLabel;
/* 1702:     */     }
/* 1703:1750 */     String msg = null;
/* 1704:1751 */     if (this.secondaryLabel == null) {
/* 1705:1752 */       msg = MobileMessageGenerator.generate("scandetailnosec", new Object[] { nextLabel, this.primaryLabel });
/* 1706:     */     } else {
/* 1707:1754 */       msg = MobileMessageGenerator.generate("scandetail", new Object[] { nextLabel, this.primaryLabel, this.secondaryLabel });
/* 1708:     */     }
/* 1709:1755 */     UIUtil.showMessageBoxControl("scanbox", msg, event);
/* 1710:1756 */     return true;
/* 1711:     */   }
/* 1712:     */   
/* 1713:     */   public boolean hasscanned(UIEvent event)
/* 1714:     */   {
/* 1715:1768 */     ((AbstractMobileControl)event.getCreatingObject()).setVisibility(getScanState() > 0);
/* 1716:1769 */     return true;
/* 1717:     */   }
/* 1718:     */   
/* 1719:     */   public int getScanState()
/* 1720:     */   {
/* 1721:1780 */     if (this.scanstate < 0)
/* 1722:     */     {
/* 1723:1781 */       this.scanstate = 0;
/* 1724:1782 */       MobileDeviceAppSession session = MobileDeviceAppSession.getSession();
/* 1725:1783 */       Hashtable scanData = (Hashtable)session.getAttribute("scanstate");
/* 1726:1784 */       if (scanData != null)
/* 1727:     */       {
/* 1728:1785 */         Integer state = (Integer)scanData.get(getId());
/* 1729:1786 */         if (state != null) {
/* 1730:1787 */           this.scanstate = state.intValue();
/* 1731:     */         }
/* 1732:     */       }
/* 1733:     */     }
/* 1734:1790 */     return this.scanstate;
/* 1735:     */   }
/* 1736:     */   
/* 1737:     */   public void setScanState(int state)
/* 1738:     */   {
/* 1739:1800 */     MobileDeviceAppSession session = MobileDeviceAppSession.getSession();
/* 1740:1801 */     Hashtable scanData = (Hashtable)session.getAttribute("scanstate");
/* 1741:1802 */     if (scanData == null)
/* 1742:     */     {
/* 1743:1803 */       scanData = new Hashtable();
/* 1744:1804 */       session.setAttribute("scanstate", scanData);
/* 1745:     */     }
/* 1746:1806 */     scanData.put(getId(), new Integer(state));
/* 1747:1807 */     this.scanstate = state;
/* 1748:     */   }
/* 1749:     */   
/* 1750:     */   public void cancelRemoveLastScan()
/* 1751:     */   {
/* 1752:1816 */     MobileDeviceAppSession session = MobileDeviceAppSession.getSession();
/* 1753:1817 */     session.removeAttribute(getId() + REMOVE_SCAN);
/* 1754:     */   }
/* 1755:     */   
/* 1756:     */   public boolean clearscan(UIEvent event)
/* 1757:     */     throws MobileApplicationException
/* 1758:     */   {
/* 1759:1821 */     MobileMboDataBean dataBean = getDataBean();
/* 1760:1822 */     if (dataBean != null)
/* 1761:     */     {
/* 1762:1823 */       ((MobileMboDataBeanQBE)dataBean.getQBE()).restoreDefaultQBEValues();
/* 1763:1824 */       dataBean.reset();
/* 1764:1825 */       dataBean.setFiltered(false);
/* 1765:1826 */       dataBean.setSecondaryFilter(false);
/* 1766:1827 */       setScanState(0);
/* 1767:     */     }
/* 1768:1829 */     UIUtil.refreshCurrentScreen();
/* 1769:1830 */     return true;
/* 1770:     */   }
/* 1771:     */   
/* 1772:     */   public boolean scannoaccess(UIEvent event)
/* 1773:     */   {
/* 1774:1834 */     String msg = MobileMessageGenerator.generate("scannoaccess", null);
/* 1775:1835 */     UIUtil.showInfoMessageBox(msg);
/* 1776:1836 */     return true;
/* 1777:     */   }
/* 1778:     */   
/* 1779:     */   public void setBarcodeEnabled(boolean enabled)
/* 1780:     */   {
/* 1781:1840 */     if (UIUtil.getApplication().isBarcodeEnabled()) {
/* 1782:1841 */       this.useBarCode = enabled;
/* 1783:     */     }
/* 1784:     */   }
/* 1785:     */   
/* 1786:     */   protected AbstractWidget createWidget()
/* 1787:     */   {
/* 1788:1845 */     return widgetCreator.createWidget();
/* 1789:     */   }
/* 1790:     */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.controls.TableControl
 * JD-Core Version:    0.7.0.1
 */