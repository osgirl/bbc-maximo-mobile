/*   1:    */ package com.mro.mobile.ui.res.controls;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.ui.event.UIEvent;
/*   5:    */ import com.mro.mobile.ui.res.ControlData;
/*   6:    */ import com.mro.mobile.ui.res.controls.utils.ControlStyle;
/*   7:    */ import com.mro.mobile.ui.res.controls.utils.StyleManager;
/*   8:    */ import com.mro.mobile.ui.res.widgets.def.AbstractWidget;
/*   9:    */ import com.mro.mobile.ui.res.widgets.def.PopUpImageWidget;
/*  10:    */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  11:    */ import com.mro.mobile.ui.res.widgets.def.WidgetCreator;
/*  12:    */ import com.mro.mobile.util.MobileLogger;
/*  13:    */ import java.util.ArrayList;
/*  14:    */ import java.util.Iterator;
/*  15:    */ import java.util.Vector;
/*  16:    */ 
/*  17:    */ public class PopUpImageControl
/*  18:    */   extends AbstractMobileControl
/*  19:    */ {
/*  20: 41 */   private ArrayList menuContents = null;
/*  21: 42 */   private String img = null;
/*  22: 43 */   private String singleActionImg = null;
/*  23:    */   
/*  24:    */   protected PopUpImageWidget getPopUpImageWidget()
/*  25:    */   {
/*  26: 49 */     return (PopUpImageWidget)super.getWidget();
/*  27:    */   }
/*  28:    */   
/*  29:    */   private ArrayList getVisibleContents(ArrayList menuContents)
/*  30:    */   {
/*  31: 54 */     if (menuContents == null) {
/*  32: 55 */       return null;
/*  33:    */     }
/*  34: 56 */     ArrayList newList = new ArrayList();
/*  35:    */     
/*  36: 58 */     newList = getPopUpImageWidget().getVisibleContents(menuContents);
/*  37:    */     
/*  38: 60 */     return newList;
/*  39:    */   }
/*  40:    */   
/*  41:    */   public UIComponent[] composeComponents()
/*  42:    */     throws MobileApplicationException
/*  43:    */   {
/*  44: 66 */     this.img = getStringValue("image");
/*  45: 67 */     this.singleActionImg = getStringValue("singleactionimage");
/*  46:    */     
/*  47:    */ 
/*  48: 70 */     this.singleActionImg = (this.singleActionImg == null ? this.img : this.singleActionImg);
/*  49: 71 */     PopUpImageWidget widget = getPopUpImageWidget();
/*  50: 72 */     String menuTitleAttributes = getStringValue("titleattributes");
/*  51: 73 */     return widget.createPopUp(this.singleActionImg, widget.resolveMenuTitle(menuTitleAttributes), this);
/*  52:    */   }
/*  53:    */   
/*  54:    */   public void renderMenu(UIComponent inPopup)
/*  55:    */     throws MobileApplicationException
/*  56:    */   {
/*  57: 78 */     String menu = getStringValue("menu");
/*  58: 79 */     Object controlObject = includeControl(menu);
/*  59: 80 */     if ((controlObject instanceof MenuControl))
/*  60:    */     {
/*  61: 82 */       MenuControl mc = (MenuControl)controlObject;
/*  62: 83 */       this.menuContents = mc.composeChildren();
/*  63: 84 */       ArrayList visibleContents = getVisibleContents(this.menuContents);
/*  64: 86 */       if ((visibleContents != null) && (!visibleContents.isEmpty())) {
/*  65: 88 */         setUpPopUpMenu(visibleContents, inPopup);
/*  66:    */       } else {
/*  67: 92 */         getPopUpImageWidget().setControlVisibility(inPopup, false);
/*  68:    */       }
/*  69:    */     }
/*  70:    */   }
/*  71:    */   
/*  72:    */   protected boolean performEvent(UIEvent event)
/*  73:    */     throws MobileApplicationException
/*  74:    */   {
/*  75:108 */     return false;
/*  76:    */   }
/*  77:    */   
/*  78:    */   protected boolean handleException(UIEvent event, Exception exception)
/*  79:    */   {
/*  80:118 */     return false;
/*  81:    */   }
/*  82:    */   
/*  83:    */   public void refreshPopUpMenu(UIComponent popup)
/*  84:    */   {
/*  85:123 */     ArrayList visibleContents = getVisibleContents(this.menuContents);
/*  86:125 */     if ((visibleContents != null) && (!visibleContents.isEmpty())) {
/*  87:127 */       setUpPopUpMenu(visibleContents, popup);
/*  88:    */     }
/*  89:    */   }
/*  90:    */   
/*  91:    */   protected boolean refreshControl(UIEvent event)
/*  92:    */     throws MobileApplicationException
/*  93:    */   {
/*  94:137 */     return getPopUpImageWidget().refreshPopUpControl();
/*  95:    */   }
/*  96:    */   
/*  97:    */   public AbstractMobileControl createControl(ControlData controlData)
/*  98:    */     throws MobileApplicationException
/*  99:    */   {
/* 100:146 */     return new PopUpImageControl();
/* 101:    */   }
/* 102:    */   
/* 103:    */   protected boolean init()
/* 104:    */     throws MobileApplicationException
/* 105:    */   {
/* 106:156 */     return false;
/* 107:    */   }
/* 108:    */   
/* 109:    */   public void cleanup()
/* 110:    */   {
/* 111:164 */     UIComponent[] uicomp = getComponents();
/* 112:165 */     if (uicomp != null) {
/* 113:167 */       for (int i = 0; i < uicomp.length; i++)
/* 114:    */       {
/* 115:169 */         getPopUpImageWidget().cleanup(uicomp[i]);
/* 116:    */         
/* 117:171 */         this.menuContents = null;
/* 118:172 */         this.img = null;
/* 119:173 */         this.singleActionImg = null;
/* 120:174 */         super.cleanup();
/* 121:    */       }
/* 122:    */     }
/* 123:    */   }
/* 124:    */   
/* 125:    */   public void setUpPopUpMenu(ArrayList menuContents, UIComponent mPopUp)
/* 126:    */   {
/* 127:180 */     Vector controlNodeData = getPopUpImageWidget().getControlNodeData(mPopUp);
/* 128:182 */     if (controlNodeData == null)
/* 129:    */     {
/* 130:184 */       controlNodeData = new Vector();
/* 131:185 */       getPopUpImageWidget().setControlNodeData(controlNodeData, mPopUp);
/* 132:    */     }
/* 133:    */     else
/* 134:    */     {
/* 135:189 */       getPopUpImageWidget().clearControlNodeData(mPopUp);
/* 136:    */     }
/* 137:192 */     getPopUpImageWidget().removeAllItems();
/* 138:193 */     if (menuContents != null)
/* 139:    */     {
/* 140:195 */       int size = menuContents.size();
/* 141:196 */       if (size > 0)
/* 142:    */       {
/* 143:198 */         ArrayList tempMenuContents = menuContents;
/* 144:199 */         if (tempMenuContents != null) {
/* 145:201 */           for (int i = 0; i < size; i++)
/* 146:    */           {
/* 147:203 */             Object tmpObj = tempMenuContents.get(i);
/* 148:204 */             UIComponent comp = null;
/* 149:205 */             if ((tmpObj instanceof UIComponent[]))
/* 150:    */             {
/* 151:207 */               UIComponent[] comps = (UIComponent[])tmpObj;
/* 152:208 */               comp = comps[0];
/* 153:    */             }
/* 154:    */             else
/* 155:    */             {
/* 156:210 */               comp = (UIComponent)tmpObj;
/* 157:    */             }
/* 158:213 */             if (getPopUpImageWidget().isComponentAPanel(comp))
/* 159:    */             {
/* 160:214 */               if (getPopUpImageWidget().isPanelVisible(comp))
/* 161:    */               {
/* 162:    */                 try
/* 163:    */                 {
/* 164:216 */                   menuContents = getPopUpImageWidget().getMenuContents(comp);
/* 165:    */                 }
/* 166:    */                 catch (MobileApplicationException e)
/* 167:    */                 {
/* 168:218 */                   getDefaultLogger().warn("Failed to get menu for PopUpImage", e);
/* 169:    */                 }
/* 170:220 */                 buildMenu(menuContents, mPopUp);
/* 171:    */               }
/* 172:    */             }
/* 173:    */             else
/* 174:    */             {
/* 175:230 */               buildMenu(menuContents, mPopUp);
/* 176:231 */               break;
/* 177:    */             }
/* 178:    */           }
/* 179:    */         }
/* 180:237 */         getPopUpImageWidget().setControlNodeData(getPopUpImageWidget().getControlNodeData(mPopUp), mPopUp);
/* 181:    */         
/* 182:    */ 
/* 183:240 */         getPopUpImageWidget().removeSelectionListenerFromPopup(mPopUp);
/* 184:242 */         if (getPopUpImageWidget().isPopUpListenerSet()) {
/* 185:243 */           getPopUpImageWidget().removeListenerFromMainMenu(mPopUp);
/* 186:    */         }
/* 187:246 */         getPopUpImageWidget().addNewListenerToMainMenu(mPopUp);
/* 188:    */       }
/* 189:    */     }
/* 190:    */   }
/* 191:    */   
/* 192:    */   public void buildMenu(ArrayList inList, UIComponent inPopUP)
/* 193:    */   {
/* 194:255 */     boolean isTextEmpty = false;
/* 195:256 */     if ((getParentControl() instanceof TextboxControl)) {
/* 196:    */       try
/* 197:    */       {
/* 198:259 */         TextboxControl control = (TextboxControl)getParentControl();
/* 199:261 */         if ((control.getValue().trim().equals("")) || (control.isForcedAccepted())) {
/* 200:262 */           isTextEmpty = true;
/* 201:    */         }
/* 202:    */       }
/* 203:    */       catch (MobileApplicationException e)
/* 204:    */       {
/* 205:265 */         getDefaultLogger().warn("Failed to get value from TextboxControl", e);
/* 206:    */       }
/* 207:    */     }
/* 208:268 */     int xx = 0;
/* 209:269 */     Iterator i = inList.iterator();
/* 210:270 */     ControlStyle style = StyleManager.getStyle("popupmenu", null);
/* 211:271 */     while (i.hasNext())
/* 212:    */     {
/* 213:273 */       Object tmpObj = i.next();
/* 214:274 */       UIComponent comp = null;
/* 215:275 */       if ((tmpObj instanceof UIComponent[]))
/* 216:    */       {
/* 217:277 */         UIComponent[] comps = (UIComponent[])tmpObj;
/* 218:278 */         comp = comps[0];
/* 219:    */       }
/* 220:    */       else
/* 221:    */       {
/* 222:280 */         comp = (UIComponent)tmpObj;
/* 223:    */       }
/* 224:283 */       String hideEmpty = getPopUpImageWidget().getStringValueFromComponentController(comp, "hidewhenempty");
/* 225:284 */       if ((hideEmpty == null) || (!hideEmpty.equalsIgnoreCase("true")) || (!isTextEmpty))
/* 226:    */       {
/* 227:287 */         getPopUpImageWidget().addComponentInfoToPopUpImage(comp, inPopUP, style, xx);
/* 228:288 */         xx++;
/* 229:    */       }
/* 230:    */     }
/* 231:    */   }
/* 232:    */   
/* 233:    */   public void fireClickEvent(int textSize)
/* 234:    */   {
/* 235:295 */     getPopUpImageWidget().fireClickEvent(textSize);
/* 236:    */   }
/* 237:    */   
/* 238:298 */   private static WidgetCreator widgetCreator = null;
/* 239:    */   
/* 240:    */   public static void registerWidgetCreator(WidgetCreator wc)
/* 241:    */   {
/* 242:301 */     widgetCreator = wc;
/* 243:    */   }
/* 244:    */   
/* 245:    */   protected AbstractWidget createWidget()
/* 246:    */   {
/* 247:305 */     return widgetCreator.createWidget();
/* 248:    */   }
/* 249:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.controls.PopUpImageControl
 * JD-Core Version:    0.7.0.1
 */