/*   1:    */ package com.mro.mobile.ui.res.controls;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.ui.event.UIEvent;
/*   5:    */ import com.mro.mobile.ui.res.ControlData;
/*   6:    */ import com.mro.mobile.ui.res.widgets.def.AbstractWidget;
/*   7:    */ import com.mro.mobile.ui.res.widgets.def.TableColWidget;
/*   8:    */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*   9:    */ import com.mro.mobile.ui.res.widgets.def.WidgetCreator;
/*  10:    */ import java.util.Iterator;
/*  11:    */ 
/*  12:    */ public class TableColControl
/*  13:    */   extends AbstractMobileControl
/*  14:    */ {
/*  15:    */   protected TableColWidget getTableColWidget()
/*  16:    */   {
/*  17: 45 */     return (TableColWidget)super.getWidget();
/*  18:    */   }
/*  19:    */   
/*  20: 48 */   private static WidgetCreator widgetCreator = null;
/*  21:    */   
/*  22:    */   public static void registerWidgetCreator(WidgetCreator wc)
/*  23:    */   {
/*  24: 51 */     widgetCreator = wc;
/*  25:    */   }
/*  26:    */   
/*  27:    */   protected boolean init()
/*  28:    */   {
/*  29: 56 */     return true;
/*  30:    */   }
/*  31:    */   
/*  32:    */   public AbstractMobileControl createControl(ControlData controlData)
/*  33:    */     throws MobileApplicationException
/*  34:    */   {
/*  35: 61 */     return new TableColControl();
/*  36:    */   }
/*  37:    */   
/*  38:    */   public UIComponent[] composeComponents()
/*  39:    */     throws MobileApplicationException
/*  40:    */   {
/*  41: 66 */     TableColWidget widget = getTableColWidget();
/*  42: 67 */     widget.createTableCol("TableColPanel_" + getStringValue("id"));
/*  43: 68 */     composeChildren();
/*  44: 69 */     Iterator i = getChildren();
/*  45: 70 */     boolean visible = false;
/*  46: 72 */     while ((i != null) && (i.hasNext()))
/*  47:    */     {
/*  48: 74 */       AbstractMobileControl child = (AbstractMobileControl)i.next();
/*  49: 75 */       UIComponent[] components = child.getComponents();
/*  50: 76 */       for (int j = 0; j < components.length; j++)
/*  51:    */       {
/*  52: 78 */         UIComponent component = components[j];
/*  53: 79 */         if (!visible) {
/*  54: 81 */           visible = widget.isComponentVisible(component);
/*  55:    */         }
/*  56: 84 */         widget.addToCol(component);
/*  57:    */       }
/*  58:    */     }
/*  59: 88 */     widget.setVisible(visible);
/*  60:    */     
/*  61: 90 */     return widget.resolveTableColComponents();
/*  62:    */   }
/*  63:    */   
/*  64:    */   public void setComponents(UIComponent[] comps)
/*  65:    */   {
/*  66: 97 */     this.components = comps;
/*  67: 98 */     if (comps == null) {
/*  68: 99 */       return;
/*  69:    */     }
/*  70:101 */     for (int i = 0; i < this.components.length; i++) {
/*  71:104 */       if (this.components[i].getController() == null) {
/*  72:106 */         setComponentController(this.components[i]);
/*  73:    */       }
/*  74:    */     }
/*  75:    */   }
/*  76:    */   
/*  77:    */   protected boolean performEvent(UIEvent event)
/*  78:    */     throws MobileApplicationException
/*  79:    */   {
/*  80:113 */     return false;
/*  81:    */   }
/*  82:    */   
/*  83:    */   protected boolean refreshControl(UIEvent event)
/*  84:    */   {
/*  85:118 */     return true;
/*  86:    */   }
/*  87:    */   
/*  88:    */   protected boolean handleException(UIEvent event, Exception exception)
/*  89:    */   {
/*  90:123 */     return false;
/*  91:    */   }
/*  92:    */   
/*  93:    */   protected AbstractWidget createWidget()
/*  94:    */   {
/*  95:127 */     return widgetCreator.createWidget();
/*  96:    */   }
/*  97:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.controls.TableColControl
 * JD-Core Version:    0.7.0.1
 */