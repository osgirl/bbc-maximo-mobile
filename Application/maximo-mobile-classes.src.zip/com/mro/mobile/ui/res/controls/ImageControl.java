/*   1:    */ package com.mro.mobile.ui.res.controls;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.ui.event.UIEvent;
/*   5:    */ import com.mro.mobile.ui.res.ControlData;
/*   6:    */ import com.mro.mobile.ui.res.widgets.def.AbstractWidget;
/*   7:    */ import com.mro.mobile.ui.res.widgets.def.ImageWidget;
/*   8:    */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*   9:    */ import com.mro.mobile.ui.res.widgets.def.WidgetCreator;
/*  10:    */ 
/*  11:    */ public class ImageControl
/*  12:    */   extends AbstractMobileControl
/*  13:    */ {
/*  14:    */   protected ImageWidget getImageWidget()
/*  15:    */   {
/*  16: 38 */     return (ImageWidget)super.getWidget();
/*  17:    */   }
/*  18:    */   
/*  19:    */   public UIComponent[] composeComponents()
/*  20:    */     throws MobileApplicationException
/*  21:    */   {
/*  22: 43 */     ImageWidget imageWidget = getImageWidget().createImageWidget(getStringValue("image"));
/*  23: 44 */     imageWidget.setImageId(getStringValue("id"));
/*  24:    */     
/*  25: 46 */     return imageWidget.resolveImageComponents();
/*  26:    */   }
/*  27:    */   
/*  28:    */   protected boolean performEvent(UIEvent event)
/*  29:    */     throws MobileApplicationException
/*  30:    */   {
/*  31: 54 */     return false;
/*  32:    */   }
/*  33:    */   
/*  34:    */   protected boolean handleException(UIEvent event, Exception exception)
/*  35:    */   {
/*  36: 63 */     return false;
/*  37:    */   }
/*  38:    */   
/*  39:    */   protected boolean refreshControl(UIEvent event)
/*  40:    */   {
/*  41: 72 */     return false;
/*  42:    */   }
/*  43:    */   
/*  44:    */   public AbstractMobileControl createControl(ControlData controlData)
/*  45:    */     throws MobileApplicationException
/*  46:    */   {
/*  47: 81 */     return new ImageControl();
/*  48:    */   }
/*  49:    */   
/*  50:    */   protected boolean init()
/*  51:    */   {
/*  52: 90 */     return false;
/*  53:    */   }
/*  54:    */   
/*  55: 93 */   private static WidgetCreator widgetCreator = null;
/*  56:    */   
/*  57:    */   public static void registerWidgetCreator(WidgetCreator wc)
/*  58:    */   {
/*  59: 96 */     widgetCreator = wc;
/*  60:    */   }
/*  61:    */   
/*  62:    */   protected AbstractWidget createWidget()
/*  63:    */   {
/*  64:100 */     return widgetCreator.createWidget();
/*  65:    */   }
/*  66:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.controls.ImageControl
 * JD-Core Version:    0.7.0.1
 */