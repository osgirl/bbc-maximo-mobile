package com.mro.mobile.ui.res.controls.utils;

import java.util.Map;

public abstract interface FontCreator
{
  public abstract Object createFont(Map paramMap);
  
  public abstract boolean isAlreadyColor(Object paramObject);
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.controls.utils.FontCreator
 * JD-Core Version:    0.7.0.1
 */