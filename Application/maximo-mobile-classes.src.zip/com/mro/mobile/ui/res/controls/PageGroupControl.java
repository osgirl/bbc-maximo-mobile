/*   1:    */ package com.mro.mobile.ui.res.controls;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.app.BasicMobileDeviceUIApplication;
/*   5:    */ import com.mro.mobile.ui.event.UIEvent;
/*   6:    */ import com.mro.mobile.ui.res.ControlData;
/*   7:    */ import com.mro.mobile.ui.res.UIUtil;
/*   8:    */ import com.mro.mobile.ui.res.widgets.def.AbstractWidget;
/*   9:    */ import com.mro.mobile.ui.res.widgets.def.PageGroupWidget;
/*  10:    */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  11:    */ import com.mro.mobile.ui.res.widgets.def.WidgetCreator;
/*  12:    */ import com.mro.mobile.util.MobileLogger;
/*  13:    */ import java.util.ArrayList;
/*  14:    */ 
/*  15:    */ public class PageGroupControl
/*  16:    */   extends AbstractMobileControl
/*  17:    */ {
/*  18: 40 */   private int currentIndex = -1;
/*  19:    */   
/*  20:    */   protected PageGroupWidget getPageGroupWidget()
/*  21:    */   {
/*  22: 46 */     return (PageGroupWidget)super.getWidget();
/*  23:    */   }
/*  24:    */   
/*  25: 49 */   private static WidgetCreator widgetCreator = null;
/*  26:    */   
/*  27:    */   public static void registerWidgetCreator(WidgetCreator wc)
/*  28:    */   {
/*  29: 52 */     widgetCreator = wc;
/*  30:    */   }
/*  31:    */   
/*  32:    */   public UIComponent[] composeComponents()
/*  33:    */     throws MobileApplicationException
/*  34:    */   {
/*  35: 60 */     if (this.currentIndex >= 0)
/*  36:    */     {
/*  37: 62 */       AbstractMobileControl page = (AbstractMobileControl)this.childControls.get(this.currentIndex);
/*  38: 63 */       page.setComponents(page.composeComponents());
/*  39: 64 */       return page.getComponents();
/*  40:    */     }
/*  41: 66 */     return null;
/*  42:    */   }
/*  43:    */   
/*  44:    */   public AbstractMobileControl createControl(ControlData controlData)
/*  45:    */     throws MobileApplicationException
/*  46:    */   {
/*  47: 75 */     PageGroupControl pageGroup = new PageGroupControl();
/*  48: 76 */     return pageGroup;
/*  49:    */   }
/*  50:    */   
/*  51:    */   protected boolean performEvent(UIEvent event)
/*  52:    */     throws MobileApplicationException
/*  53:    */   {
/*  54: 85 */     String eventType = event.getEventName();
/*  55: 86 */     if (eventType.equals("nextpage")) {
/*  56: 88 */       return nextpage(event);
/*  57:    */     }
/*  58: 90 */     if (eventType.equals("prevpage")) {
/*  59: 92 */       return prevpage(event);
/*  60:    */     }
/*  61: 94 */     if (eventType.equals("listpage")) {
/*  62: 96 */       return listpage(event);
/*  63:    */     }
/*  64: 99 */     return false;
/*  65:    */   }
/*  66:    */   
/*  67:    */   public AbstractMobileControl getCurrentPage()
/*  68:    */   {
/*  69:104 */     if (this.currentIndex >= 0) {
/*  70:105 */       return (AbstractMobileControl)this.childControls.get(this.currentIndex);
/*  71:    */     }
/*  72:106 */     return null;
/*  73:    */   }
/*  74:    */   
/*  75:    */   public AbstractMobileControl getPage(String pageId)
/*  76:    */     throws MobileApplicationException
/*  77:    */   {
/*  78:111 */     if (hasChildren()) {
/*  79:113 */       for (int i = 0; i < this.childControls.size(); i++)
/*  80:    */       {
/*  81:115 */         AbstractMobileControl page = (AbstractMobileControl)this.childControls.get(i);
/*  82:116 */         if (page.getId().equals(pageId))
/*  83:    */         {
/*  84:118 */           if (!page.hasChildren()) {
/*  85:119 */             page.createChildren();
/*  86:    */           }
/*  87:120 */           return page;
/*  88:    */         }
/*  89:    */       }
/*  90:    */     }
/*  91:124 */     return null;
/*  92:    */   }
/*  93:    */   
/*  94:    */   public AbstractMobileControl setCurrentPage(AbstractMobileControl inPage)
/*  95:    */   {
/*  96:129 */     if (hasChildren()) {
/*  97:131 */       for (int i = 0; i < this.childControls.size(); i++)
/*  98:    */       {
/*  99:133 */         AbstractMobileControl page = (AbstractMobileControl)this.childControls.get(i);
/* 100:134 */         if (page == inPage) {
/* 101:136 */           this.currentIndex = i;
/* 102:    */         }
/* 103:    */       }
/* 104:    */     }
/* 105:140 */     return null;
/* 106:    */   }
/* 107:    */   
/* 108:    */   public void closePage(AbstractMobileControl inPage)
/* 109:    */     throws MobileApplicationException
/* 110:    */   {
/* 111:145 */     for (int i = 0; i < this.childControls.size(); i++)
/* 112:    */     {
/* 113:147 */       AbstractMobileControl page = (AbstractMobileControl)this.childControls.get(i);
/* 114:148 */       if (page == inPage)
/* 115:    */       {
/* 116:150 */         AbstractMobileControl curPage = (AbstractMobileControl)this.childControls.remove(i);
/* 117:151 */         AbstractMobileControl newPage = curPage.createControl(curPage.getControlData());
/* 118:152 */         newPage.setControlData(curPage.getControlData());
/* 119:153 */         getPageGroupWidget().requestFocus();
/* 120:154 */         curPage.cleanup();
/* 121:155 */         newPage.setParentControl(this);
/* 122:    */         
/* 123:157 */         this.childControls.add(i, newPage);
/* 124:    */       }
/* 125:    */     }
/* 126:    */   }
/* 127:    */   
/* 128:    */   protected void showPage(int pageIndex)
/* 129:    */     throws MobileApplicationException
/* 130:    */   {
/* 131:    */     try
/* 132:    */     {
/* 133:166 */       AbstractMobileControl page = (AbstractMobileControl)this.childControls.get(pageIndex);
/* 134:167 */       if (!page.hasChildren()) {
/* 135:168 */         page.createChildren();
/* 136:    */       }
/* 137:169 */       if (this.app.showScreen(page, this, false, true) != null) {
/* 138:171 */         this.currentIndex = pageIndex;
/* 139:    */       }
/* 140:    */     }
/* 141:    */     catch (IndexOutOfBoundsException e)
/* 142:    */     {
/* 143:176 */       getDefaultLogger().warn("Failed to show page for pageIndex: " + pageIndex, e);
/* 144:    */     }
/* 145:    */   }
/* 146:    */   
/* 147:    */   public boolean listpage(UIEvent event)
/* 148:    */     throws MobileApplicationException
/* 149:    */   {
/* 150:182 */     String listpage = getStringValue("listpage");
/* 151:183 */     if (listpage == null) {
/* 152:184 */       listpage = "listpage";
/* 153:    */     }
/* 154:185 */     this.app.showScreen(listpage);
/* 155:187 */     if (this.app.getCurrentScreen().getId().equals(listpage)) {
/* 156:188 */       UIUtil.refreshCurrentScreen();
/* 157:    */     }
/* 158:189 */     return true;
/* 159:    */   }
/* 160:    */   
/* 161:    */   public boolean nextpage(UIEvent event)
/* 162:    */     throws MobileApplicationException
/* 163:    */   {
/* 164:194 */     if (hasChildren()) {
/* 165:196 */       if (this.currentIndex + 1 != this.childControls.size()) {
/* 166:202 */         showPage(this.currentIndex + 1);
/* 167:    */       }
/* 168:    */     }
/* 169:205 */     return true;
/* 170:    */   }
/* 171:    */   
/* 172:    */   public boolean prevpage(UIEvent event)
/* 173:    */     throws MobileApplicationException
/* 174:    */   {
/* 175:210 */     if (hasChildren()) {
/* 176:212 */       if (this.currentIndex != 0) {
/* 177:218 */         showPage(this.currentIndex - 1);
/* 178:    */       }
/* 179:    */     }
/* 180:221 */     return true;
/* 181:    */   }
/* 182:    */   
/* 183:    */   protected boolean handleException(UIEvent event, Exception exception)
/* 184:    */   {
/* 185:230 */     return false;
/* 186:    */   }
/* 187:    */   
/* 188:    */   protected boolean refreshControl(UIEvent event)
/* 189:    */   {
/* 190:238 */     return true;
/* 191:    */   }
/* 192:    */   
/* 193:    */   protected AbstractWidget createWidget()
/* 194:    */   {
/* 195:242 */     return widgetCreator.createWidget();
/* 196:    */   }
/* 197:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.controls.PageGroupControl
 * JD-Core Version:    0.7.0.1
 */