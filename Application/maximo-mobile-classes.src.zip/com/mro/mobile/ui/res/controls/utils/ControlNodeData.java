/*   1:    */ package com.mro.mobile.ui.res.controls.utils;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*   4:    */ 
/*   5:    */ public class ControlNodeData
/*   6:    */ {
/*   7: 31 */   private String id = "";
/*   8: 32 */   private String event = "";
/*   9: 33 */   private Object value = "";
/*  10: 34 */   private String targetid = "";
/*  11: 35 */   private String label = "";
/*  12: 36 */   private String image = "";
/*  13: 37 */   private String displayevent = "";
/*  14: 38 */   private AbstractMobileControl controller = null;
/*  15:    */   
/*  16:    */   public String getImage()
/*  17:    */   {
/*  18: 45 */     return this.image;
/*  19:    */   }
/*  20:    */   
/*  21:    */   public void setImage(String image)
/*  22:    */   {
/*  23: 52 */     this.image = image;
/*  24:    */   }
/*  25:    */   
/*  26:    */   public String getEvent()
/*  27:    */   {
/*  28: 59 */     return this.event;
/*  29:    */   }
/*  30:    */   
/*  31:    */   public void setEvent(String event)
/*  32:    */   {
/*  33: 66 */     this.event = event;
/*  34:    */   }
/*  35:    */   
/*  36:    */   public String getId()
/*  37:    */   {
/*  38: 73 */     return this.id;
/*  39:    */   }
/*  40:    */   
/*  41:    */   public void setId(String id)
/*  42:    */   {
/*  43: 80 */     this.id = id;
/*  44:    */   }
/*  45:    */   
/*  46:    */   public String getLabel()
/*  47:    */   {
/*  48: 87 */     return this.label;
/*  49:    */   }
/*  50:    */   
/*  51:    */   public void setLabel(String label)
/*  52:    */   {
/*  53: 94 */     this.label = label;
/*  54:    */   }
/*  55:    */   
/*  56:    */   public String getTargetid()
/*  57:    */   {
/*  58:101 */     return this.targetid;
/*  59:    */   }
/*  60:    */   
/*  61:    */   public void setTargetid(String targetid)
/*  62:    */   {
/*  63:108 */     this.targetid = targetid;
/*  64:    */   }
/*  65:    */   
/*  66:    */   public Object getValue()
/*  67:    */   {
/*  68:115 */     return this.value;
/*  69:    */   }
/*  70:    */   
/*  71:    */   public void setValue(Object value)
/*  72:    */   {
/*  73:122 */     this.value = value;
/*  74:    */   }
/*  75:    */   
/*  76:    */   public AbstractMobileControl getController()
/*  77:    */   {
/*  78:129 */     return this.controller;
/*  79:    */   }
/*  80:    */   
/*  81:    */   public void setController(AbstractMobileControl controller)
/*  82:    */   {
/*  83:136 */     this.controller = controller;
/*  84:    */   }
/*  85:    */   
/*  86:    */   public String getDisplayevent()
/*  87:    */   {
/*  88:143 */     return this.displayevent;
/*  89:    */   }
/*  90:    */   
/*  91:    */   public void setDisplayevent(String displayevent)
/*  92:    */   {
/*  93:150 */     this.displayevent = displayevent;
/*  94:    */   }
/*  95:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.controls.utils.ControlNodeData
 * JD-Core Version:    0.7.0.1
 */