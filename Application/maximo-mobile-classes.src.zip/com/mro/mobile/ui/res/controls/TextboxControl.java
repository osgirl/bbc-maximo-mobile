/*   1:    */ package com.mro.mobile.ui.res.controls;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.app.BasicMobileDeviceUIApplication;
/*   5:    */ import com.mro.mobile.mbo.MobileMbo;
/*   6:    */ import com.mro.mobile.mbo.MobileMboAttributeInfo;
/*   7:    */ import com.mro.mobile.mbo.MobileMboInfo;
/*   8:    */ import com.mro.mobile.mbo.MobileMboQBE;
/*   9:    */ import com.mro.mobile.ui.ControlComposer;
/*  10:    */ import com.mro.mobile.ui.LookupManager;
/*  11:    */ import com.mro.mobile.ui.MobileMboDataBean;
/*  12:    */ import com.mro.mobile.ui.MobileUIControlData;
/*  13:    */ import com.mro.mobile.ui.UIControlManager;
/*  14:    */ import com.mro.mobile.ui.event.UIEvent;
/*  15:    */ import com.mro.mobile.ui.res.ControlData;
/*  16:    */ import com.mro.mobile.ui.res.MobileUIProperties;
/*  17:    */ import com.mro.mobile.ui.res.UIUtil;
/*  18:    */ import com.mro.mobile.ui.res.widgets.def.AbstractWidget;
/*  19:    */ import com.mro.mobile.ui.res.widgets.def.TextboxWidget;
/*  20:    */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  21:    */ import com.mro.mobile.ui.res.widgets.def.WidgetCreator;
/*  22:    */ 
/*  23:    */ public class TextboxControl
/*  24:    */   extends InputControl
/*  25:    */   implements FocusableControl
/*  26:    */ {
/*  27: 38 */   protected UIComponent[] textBoxComponents = null;
/*  28: 39 */   protected boolean showbox = false;
/*  29: 40 */   protected boolean movenext = false;
/*  30: 42 */   private static WidgetCreator widgetCreator = null;
/*  31: 45 */   private boolean forcedAccepted = false;
/*  32:    */   
/*  33:    */   public TextboxWidget getTextboxWidget()
/*  34:    */   {
/*  35: 51 */     return (TextboxWidget)super.getWidget();
/*  36:    */   }
/*  37:    */   
/*  38:    */   public AbstractMobileControl createControl(ControlData controlData)
/*  39:    */     throws MobileApplicationException
/*  40:    */   {
/*  41: 55 */     return new TextboxControl();
/*  42:    */   }
/*  43:    */   
/*  44:    */   public UIComponent[] composeComponents()
/*  45:    */     throws MobileApplicationException
/*  46:    */   {
/*  47: 66 */     if (!isAttributeSet("enablebarcode")) {
/*  48: 68 */       this.useBarCode = true;
/*  49:    */     }
/*  50: 71 */     if (!isAttributeSet("enablerfid")) {
/*  51: 73 */       this.useRFID = false;
/*  52:    */     }
/*  53: 76 */     String editMode = getStringValue("editmode");
/*  54: 78 */     if (editMode != null) {
/*  55: 79 */       this.showbox = editMode.equals("always");
/*  56:    */     } else {
/*  57: 81 */       this.showbox = isQuery();
/*  58:    */     }
/*  59: 84 */     String text = getValue();
/*  60:    */     
/*  61: 86 */     int maxCol = getIntValue("maxdatalength");
/*  62: 87 */     int size = getIntValue("size");
/*  63: 88 */     MobileMboAttributeInfo info = getAttributeInfo();
/*  64: 89 */     if (!isQuery())
/*  65:    */     {
/*  66: 90 */       int dataLen = 0;
/*  67: 91 */       if (info != null) {
/*  68: 92 */         if (info.getDataType() == 11) {
/*  69: 93 */           dataLen = 20;
/*  70: 95 */         } else if (info.getDataType() == 9) {
/*  71: 96 */           dataLen = 10;
/*  72:    */         } else {
/*  73: 98 */           dataLen = info.getLength();
/*  74:    */         }
/*  75:    */       }
/*  76:100 */       if (dataLen > 0) {
/*  77:101 */         maxCol = (maxCol > 0) && (maxCol <= dataLen) ? maxCol : dataLen;
/*  78:    */       }
/*  79:    */     }
/*  80:104 */     int flags = getTextboxWidget().getFlags(this.showbox);
/*  81:105 */     getTextboxWidget().createTextField(text, maxCol, size, flags);
/*  82:106 */     getTextboxWidget().setTextFieldId(getStringValue("id"));
/*  83:    */     
/*  84:108 */     boolean readonly = isReadOnly();
/*  85:109 */     if (readonly) {
/*  86:110 */       getTextboxWidget().setTextFieldEditable(false);
/*  87:    */     } else {
/*  88:113 */       getTextboxWidget().setTextFieldEditable(true);
/*  89:    */     }
/*  90:116 */     String lookup = getStringValue("lookup");
/*  91:117 */     String menuId = getStringValue("menu");
/*  92:    */     
/*  93:    */ 
/*  94:120 */     String buttonImage = getStringValue("imagebutton");
/*  95:122 */     if (menuId != null)
/*  96:    */     {
/*  97:123 */       MobileUIControlData cData = new MobileUIControlData();
/*  98:124 */       cData.putValue("id", getId() + "_pop");
/*  99:125 */       cData.putValue("menu", menuId);
/* 100:126 */       if (info != null) {
/* 101:127 */         cData.putValue("titleattributes", info.getTitle());
/* 102:    */       }
/* 103:132 */       if (buttonImage == null) {
/* 104:133 */         cData.putValue("image", MobileUIProperties.getStringValue("detailmenuicon"));
/* 105:    */       } else {
/* 106:135 */         cData.putValue("image", buttonImage);
/* 107:    */       }
/* 108:137 */       UIControlManager controlManager = UIControlManager.getInstance();
/* 109:138 */       ControlComposer cc = controlManager.getControlComposer("popupmenu");
/* 110:139 */       if (cc != null)
/* 111:    */       {
/* 112:140 */         AbstractMobileControl pop = ((AbstractMobileControl)cc).buildControl(cData);
/* 113:141 */         addChildControl(pop);
/* 114:142 */         UIComponent[] menu = pop.composeComponents();
/* 115:143 */         pop.setComponents(menu);
/* 116:144 */         getTextboxWidget().appendFirstMenuItemToTextField(menu);
/* 117:    */       }
/* 118:    */     }
/* 119:146 */     else if (lookup != null)
/* 120:    */     {
/* 121:147 */       getTextboxWidget().appendLookupToTextField();
/* 122:    */     }
/* 123:148 */     else if ((isAttributeSet("longdescattribute")) && (!isAttributeSet("descattribute")))
/* 124:    */     {
/* 125:149 */       getTextboxWidget().appendLDToTextField();
/* 126:    */     }
/* 127:153 */     setForcedAccepted(wasForcedAccepted(text));
/* 128:    */     
/* 129:155 */     this.textBoxComponents = getTextboxWidget().resolveTextBoxComponents();
/* 130:    */     
/* 131:157 */     boolean defaultFocus = getBooleanValue("defaultfocus");
/* 132:158 */     MobileMboDataBean dataBean = getDataBean();
/* 133:    */     
/* 134:160 */     boolean noCurFocus = true;
/* 135:161 */     if (!isUiTestMode()) {
/* 136:162 */       noCurFocus = ((PageControl)this.app.getCurrentScreen()).getCurrentInput() == null;
/* 137:    */     }
/* 138:165 */     boolean newrec = false;
/* 139:167 */     if ((this.inputMode != null) && (this.inputMode.equalsIgnoreCase("query"))) {
/* 140:168 */       newrec = false;
/* 141:    */     } else {
/* 142:170 */       newrec = (dataBean != null) && (dataBean.getMobileMbo() != null) && (dataBean.getMobileMbo().isToBeInserted());
/* 143:    */     }
/* 144:176 */     if ((!isUiTestMode()) && 
/* 145:177 */       (!readonly) && ((defaultFocus) || ((noCurFocus) && ((this.showbox) || ((newrec) && (UIUtil.isNull(text))))))) {
/* 146:178 */       ((PageControl)this.app.getCurrentScreen()).setCurrentInput(this);
/* 147:    */     }
/* 148:182 */     return this.textBoxComponents;
/* 149:    */   }
/* 150:    */   
/* 151:    */   public boolean acceptvalue(UIEvent event)
/* 152:    */     throws MobileApplicationException
/* 153:    */   {
/* 154:186 */     if (getTextboxWidget().hasTextField())
/* 155:    */     {
/* 156:187 */       event.setValue(getTextboxWidget().getText());
/* 157:188 */       getTextboxWidget().setTextFieldInvalid(false);
/* 158:    */       
/* 159:190 */       setForcedAccepted(true);
/* 160:191 */       setvalue(event);
/* 161:192 */       cleanUpRelatedData();
/* 162:193 */       ((PageControl)this.app.getCurrentScreen()).setCurrentInput(this);
/* 163:    */     }
/* 164:196 */     return true;
/* 165:    */   }
/* 166:    */   
/* 167:    */   private void cleanUpRelatedData()
/* 168:    */     throws MobileApplicationException
/* 169:    */   {
/* 170:208 */     String descMobileMbo = getValue("descmobilembo");
/* 171:209 */     String currentDataBean = getDataBean().getName();
/* 172:211 */     if (descMobileMbo == null) {
/* 173:212 */       descMobileMbo = getValue("domain");
/* 174:    */     }
/* 175:214 */     if ((descMobileMbo == null) || (descMobileMbo.equalsIgnoreCase(currentDataBean)))
/* 176:    */     {
/* 177:215 */       String descAttribute = getValue("descattribute");
/* 178:216 */       String longDescAttribute = getValue("longdescattribute");
/* 179:218 */       if ((descAttribute != null) && (descAttribute.trim().length() != 0)) {
/* 180:219 */         getDataBean().setValue(descAttribute, "");
/* 181:    */       }
/* 182:221 */       if ((longDescAttribute != null) && (longDescAttribute.trim().length() != 0)) {
/* 183:222 */         getDataBean().setValue(longDescAttribute, "");
/* 184:    */       }
/* 185:    */     }
/* 186:    */   }
/* 187:    */   
/* 188:    */   public boolean clearfield(UIEvent event)
/* 189:    */     throws MobileApplicationException
/* 190:    */   {
/* 191:228 */     if (getTextboxWidget().hasTextField())
/* 192:    */     {
/* 193:229 */       this.movenext = false;
/* 194:230 */       getTextboxWidget().setTextFieldInvalid(false);
/* 195:231 */       UIEvent newevent = new UIEvent(this, "setvalue", null, null);
/* 196:232 */       setvalue(newevent);
/* 197:233 */       if (newevent.errorOccured()) {
/* 198:234 */         event.setEventErrored();
/* 199:    */       }
/* 200:    */     }
/* 201:237 */     return true;
/* 202:    */   }
/* 203:    */   
/* 204:    */   public boolean hasTextField()
/* 205:    */   {
/* 206:241 */     return getTextboxWidget().hasTextField();
/* 207:    */   }
/* 208:    */   
/* 209:    */   protected boolean performEvent(UIEvent event)
/* 210:    */     throws MobileApplicationException
/* 211:    */   {
/* 212:252 */     if (super.performEvent(event) == true) {
/* 213:253 */       return true;
/* 214:    */     }
/* 215:255 */     String eventType = event.getEventName();
/* 216:256 */     if (eventType.equals("lookup")) {
/* 217:257 */       return lookup(event);
/* 218:    */     }
/* 219:258 */     if (eventType.equals("details")) {
/* 220:259 */       return details(event);
/* 221:    */     }
/* 222:260 */     if (eventType.equalsIgnoreCase("acceptvalue")) {
/* 223:261 */       return acceptvalue(event);
/* 224:    */     }
/* 225:262 */     if (eventType.equalsIgnoreCase("clearfield")) {
/* 226:263 */       return clearfield(event);
/* 227:    */     }
/* 228:264 */     if (eventType.equalsIgnoreCase("barcoderead")) {
/* 229:265 */       return barcoderead(event);
/* 230:    */     }
/* 231:266 */     if (eventType.equalsIgnoreCase("rfidread")) {
/* 232:267 */       return rfidread(event);
/* 233:    */     }
/* 234:270 */     return false;
/* 235:    */   }
/* 236:    */   
/* 237:    */   public boolean lookup(UIEvent event)
/* 238:    */     throws MobileApplicationException
/* 239:    */   {
/* 240:274 */     this.movenext = false;
/* 241:275 */     String value = getStringValue("lookup");
/* 242:276 */     UIUtil.gotoPageNoSave(value, this);
/* 243:277 */     return true;
/* 244:    */   }
/* 245:    */   
/* 246:    */   public boolean details(UIEvent event)
/* 247:    */     throws MobileApplicationException
/* 248:    */   {
/* 249:281 */     String value = getStringValue("detailpage");
/* 250:282 */     UIUtil.gotoPageNoSave(value, this);
/* 251:283 */     return true;
/* 252:    */   }
/* 253:    */   
/* 254:    */   public boolean barcoderead(UIEvent event)
/* 255:    */     throws MobileApplicationException
/* 256:    */   {
/* 257:287 */     boolean ret = true;
/* 258:288 */     String val = (String)event.getValue();
/* 259:289 */     if (val != null) {
/* 260:290 */       getTextboxWidget().setText(val);
/* 261:    */     }
/* 262:292 */     String scanEvent = getStringValue("scanevent");
/* 263:293 */     if (scanEvent != null)
/* 264:    */     {
/* 265:294 */       UIEvent initEvent = new UIEvent(this, scanEvent, null, getDataBean());
/* 266:295 */       handleEvent(initEvent);
/* 267:    */     }
/* 268:297 */     this.movenext = true;
/* 269:299 */     if (this.dataAttribute != null) {
/* 270:300 */       ret = setvalue(event);
/* 271:    */     }
/* 272:301 */     if (!event.errorOccured()) {
/* 273:303 */       this.movenext = false;
/* 274:    */     }
/* 275:305 */     return ret;
/* 276:    */   }
/* 277:    */   
/* 278:    */   public boolean rfidread(UIEvent event)
/* 279:    */     throws MobileApplicationException
/* 280:    */   {
/* 281:309 */     boolean ret = true;
/* 282:310 */     String val = (String)event.getValue();
/* 283:311 */     if (val != null) {
/* 284:312 */       getTextboxWidget().setText(val);
/* 285:    */     }
/* 286:313 */     this.movenext = true;
/* 287:314 */     if (this.dataAttribute != null) {
/* 288:315 */       ret = setvalue(event);
/* 289:    */     }
/* 290:316 */     if (!event.errorOccured())
/* 291:    */     {
/* 292:317 */       getTextboxWidget().processTextFieldKeyEvent();
/* 293:318 */       this.movenext = false;
/* 294:    */     }
/* 295:320 */     return ret;
/* 296:    */   }
/* 297:    */   
/* 298:    */   public boolean setvalue(UIEvent event)
/* 299:    */     throws MobileApplicationException
/* 300:    */   {
/* 301:324 */     String domain = getStringValue("domain");
/* 302:325 */     if ((domain != null) && 
/* 303:326 */       (this.dataAttribute != null))
/* 304:    */     {
/* 305:327 */       MobileMboDataBean dataBean = getDataBean();
/* 306:328 */       String value = (String)event.getValue();
/* 307:329 */       if ((!event.getEventName().equals("acceptvalue")) && (!UIUtil.isNull(value)))
/* 308:    */       {
/* 309:330 */         String domainAttr = getStringValue("domainattribute");
/* 310:331 */         if (domainAttr == null) {
/* 311:332 */           domainAttr = this.dataAttribute;
/* 312:    */         }
/* 313:334 */         if (domainAttr != null)
/* 314:    */         {
/* 315:335 */           LookupManager luMan = UIUtil.getLookupManager();
/* 316:336 */           MobileMboDataBean domainBean = luMan.createLookupDomainBean(domain);
/* 317:337 */           luMan.applyMultisiteFilter(domainBean, dataBean);
/* 318:338 */           domainBean.getQBE().setQbeExactMatch(true);
/* 319:339 */           domainBean.getQBE().setQBE(domainAttr, value);
/* 320:340 */           domainBean.reset();
/* 321:341 */           String initEventStr = getStringValue("domaininitevent");
/* 322:342 */           if (initEventStr != null)
/* 323:    */           {
/* 324:343 */             UIEvent initEvent = new UIEvent(this, initEventStr, null, domainBean);
/* 325:344 */             handleEvent(initEvent);
/* 326:345 */             if (initEvent.errorOccured())
/* 327:    */             {
/* 328:346 */               event.setEventErrored();
/* 329:347 */               getTextboxWidget().setTextFieldInvalid(event.errorOccured());
/* 330:348 */               getTextboxWidget().setForceCleanUpOnInvalid(false);
/* 331:349 */               this.movenext = false;
/* 332:350 */               return true;
/* 333:    */             }
/* 334:    */           }
/* 335:354 */           if (domainBean.getMobileMbo(0) == null)
/* 336:    */           {
/* 337:355 */             getTextboxWidget().setFocusBack();
/* 338:357 */             if (getBooleanValue("domainvaluerequired"))
/* 339:    */             {
/* 340:358 */               UIUtil.popupPage("requiredvalue", event);
/* 341:359 */               getTextboxWidget().setForceCleanUpOnInvalid(false);
/* 342:    */             }
/* 343:    */             else
/* 344:    */             {
/* 345:362 */               getTextboxWidget().setForceCleanUpOnInvalid(false);
/* 346:363 */               UIUtil.popupPage("invalidvalue", event);
/* 347:    */             }
/* 348:365 */             event.setEventErrored();
/* 349:366 */             getTextboxWidget().setTextFieldInvalid(event.errorOccured());
/* 350:367 */             return true;
/* 351:    */           }
/* 352:    */         }
/* 353:    */       }
/* 354:    */     }
/* 355:374 */     boolean ret = super.setvalue(event);
/* 356:375 */     getTextboxWidget().setTextFieldInvalid(event.errorOccured());
/* 357:376 */     if ((!event.errorOccured()) && (this.movenext)) {
/* 358:377 */       getTextboxWidget().processTextFieldKeyEvent();
/* 359:    */     }
/* 360:379 */     this.movenext = false;
/* 361:    */     
/* 362:381 */     return ret;
/* 363:    */   }
/* 364:    */   
/* 365:    */   protected boolean handleException(UIEvent event, Exception exception)
/* 366:    */   {
/* 367:392 */     return false;
/* 368:    */   }
/* 369:    */   
/* 370:    */   protected boolean refreshControl(UIEvent event)
/* 371:    */     throws MobileApplicationException
/* 372:    */   {
/* 373:403 */     MobileMboDataBean dataBean = getDataBean();
/* 374:404 */     if (dataBean == null) {
/* 375:405 */       return true;
/* 376:    */     }
/* 377:408 */     PageControl page = (PageControl)this.app.getCurrentScreen();
/* 378:409 */     boolean readonly = isReadOnly();
/* 379:410 */     getTextboxWidget().setTextFieldEditable(!readonly);
/* 380:411 */     String value = getValue();
/* 381:412 */     getTextboxWidget().refreshText(value);
/* 382:414 */     if ((page.getCurrentInput() == this) && (readonly))
/* 383:    */     {
/* 384:415 */       page.setCurrentInput(null);
/* 385:    */     }
/* 386:    */     else
/* 387:    */     {
/* 388:417 */       boolean noCurFocus = page.getCurrentInput() == null;
/* 389:418 */       if ((noCurFocus) && (!readonly))
/* 390:    */       {
/* 391:419 */         boolean defaultFocus = getBooleanValue("defaultfocus");
/* 392:420 */         if ((defaultFocus) || (this.showbox) || ((UIUtil.isNull(value)) && (dataBean.getMobileMbo() != null) && (dataBean.getMobileMbo().isToBeInserted()))) {
/* 393:421 */           page.setCurrentInput(this);
/* 394:    */         }
/* 395:    */       }
/* 396:    */     }
/* 397:426 */     return true;
/* 398:    */   }
/* 399:    */   
/* 400:    */   protected boolean init()
/* 401:    */   {
/* 402:435 */     return false;
/* 403:    */   }
/* 404:    */   
/* 405:    */   public String getControlValue()
/* 406:    */   {
/* 407:444 */     return getTextboxWidget().getText();
/* 408:    */   }
/* 409:    */   
/* 410:    */   public String getImage()
/* 411:    */     throws MobileApplicationException
/* 412:    */   {
/* 413:448 */     int launchControlDataType = getDataBean().getMobileMboInfo().getAttributeInfo(getStringValue("dataattribute")).getDataType();
/* 414:450 */     if ((launchControlDataType == 11) || (launchControlDataType == 9)) {
/* 415:451 */       return MobileUIProperties.getStringValue("datelookupicon");
/* 416:    */     }
/* 417:453 */     return MobileUIProperties.getStringValue("lookupicon");
/* 418:    */   }
/* 419:    */   
/* 420:    */   public void setFocus()
/* 421:    */   {
/* 422:458 */     getTextboxWidget().setTextFieldFocus(getTextboxWidget().getTextField());
/* 423:    */   }
/* 424:    */   
/* 425:    */   public int getFieldWidth()
/* 426:    */   {
/* 427:465 */     return 0;
/* 428:    */   }
/* 429:    */   
/* 430:    */   private boolean wasForcedAccepted(String value)
/* 431:    */     throws MobileApplicationException
/* 432:    */   {
/* 433:484 */     if ((value == null) || (value.trim().length() == 0)) {
/* 434:485 */       return false;
/* 435:    */     }
/* 436:487 */     String domain = getStringValue("domain");
/* 437:488 */     String domainAttr = getStringValue("domainattribute");
/* 438:489 */     if (domain == null) {
/* 439:490 */       return false;
/* 440:    */     }
/* 441:492 */     domainAttr = domainAttr != null ? domainAttr : this.dataAttribute;
/* 442:    */     
/* 443:    */ 
/* 444:495 */     LookupManager luMan = UIUtil.getLookupManager();
/* 445:496 */     MobileMboDataBean domainBean = luMan.createLookupDomainBean(domain);
/* 446:497 */     luMan.applyMultisiteFilter(domainBean, getDataBean());
/* 447:498 */     domainBean.getQBE().setQbeExactMatch(true);
/* 448:499 */     domainBean.getQBE().setQBE(domainAttr, value);
/* 449:500 */     domainBean.reset();
/* 450:    */     
/* 451:502 */     return domainBean.getMobileMbo(0) == null;
/* 452:    */   }
/* 453:    */   
/* 454:    */   public boolean isForcedAccepted()
/* 455:    */   {
/* 456:506 */     return this.forcedAccepted;
/* 457:    */   }
/* 458:    */   
/* 459:    */   public void setForcedAccepted(boolean forcedAccepted)
/* 460:    */   {
/* 461:510 */     this.forcedAccepted = forcedAccepted;
/* 462:    */   }
/* 463:    */   
/* 464:    */   public void updateForcedAccepted(String value)
/* 465:    */     throws MobileApplicationException
/* 466:    */   {
/* 467:514 */     setForcedAccepted(wasForcedAccepted(value));
/* 468:    */   }
/* 469:    */   
/* 470:    */   public static void registerWidgetCreator(WidgetCreator wc)
/* 471:    */   {
/* 472:518 */     widgetCreator = wc;
/* 473:    */   }
/* 474:    */   
/* 475:    */   public void setTextOnWidget(String value)
/* 476:    */   {
/* 477:529 */     getTextboxWidget().setText(value);
/* 478:    */   }
/* 479:    */   
/* 480:    */   public void setTextWidgetInvalid(boolean errorOccured)
/* 481:    */   {
/* 482:540 */     getTextboxWidget().setTextFieldInvalid(errorOccured);
/* 483:    */   }
/* 484:    */   
/* 485:    */   public void setTextFontColor(Object color)
/* 486:    */   {
/* 487:544 */     getTextboxWidget().setTextFontColor(color);
/* 488:    */   }
/* 489:    */   
/* 490:    */   protected AbstractWidget createWidget()
/* 491:    */   {
/* 492:548 */     return widgetCreator.createWidget();
/* 493:    */   }
/* 494:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.controls.TextboxControl
 * JD-Core Version:    0.7.0.1
 */