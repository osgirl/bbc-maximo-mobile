/*   1:    */ package com.mro.mobile.ui.res.controls;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.ui.event.UIEvent;
/*   5:    */ import com.mro.mobile.ui.res.ControlData;
/*   6:    */ import com.mro.mobile.ui.res.widgets.def.AbstractWidget;
/*   7:    */ import com.mro.mobile.ui.res.widgets.def.MenuBarWidget;
/*   8:    */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*   9:    */ import com.mro.mobile.ui.res.widgets.def.WidgetCreator;
/*  10:    */ import java.util.ArrayList;
/*  11:    */ 
/*  12:    */ public class MenuBarControl
/*  13:    */   extends AbstractMobileControl
/*  14:    */ {
/*  15: 38 */   private String label = "";
/*  16: 39 */   private ArrayList menuContents = null;
/*  17:    */   
/*  18:    */   protected MenuBarWidget getMenuBarWidget()
/*  19:    */   {
/*  20: 46 */     return (MenuBarWidget)super.getWidget();
/*  21:    */   }
/*  22:    */   
/*  23:    */   public boolean init()
/*  24:    */     throws MobileApplicationException
/*  25:    */   {
/*  26: 54 */     this.id = getStringValue("id");
/*  27: 55 */     this.label = getStringValue("label");
/*  28: 56 */     return true;
/*  29:    */   }
/*  30:    */   
/*  31:    */   public UIComponent[] composeComponents()
/*  32:    */     throws MobileApplicationException
/*  33:    */   {
/*  34: 64 */     init();
/*  35: 65 */     this.menuContents = composeChildren();
/*  36: 66 */     addMenusToBar();
/*  37: 67 */     return null;
/*  38:    */   }
/*  39:    */   
/*  40:    */   protected boolean performEvent(UIEvent event)
/*  41:    */     throws MobileApplicationException
/*  42:    */   {
/*  43: 76 */     return false;
/*  44:    */   }
/*  45:    */   
/*  46:    */   protected boolean handleException(UIEvent event, Exception exception)
/*  47:    */   {
/*  48: 81 */     return false;
/*  49:    */   }
/*  50:    */   
/*  51:    */   private void addMenusToBar()
/*  52:    */   {
/*  53: 87 */     if ((this.menuContents != null) && (this.menuContents.size() > 0)) {
/*  54: 89 */       getMenuBarWidget().addMenusToBar(this.menuContents);
/*  55:    */     }
/*  56:    */   }
/*  57:    */   
/*  58:    */   public void showMenuBar()
/*  59:    */   {
/*  60: 95 */     getMenuBarWidget().showMenuBar();
/*  61:    */   }
/*  62:    */   
/*  63:    */   protected boolean refreshControl(UIEvent event)
/*  64:    */   {
/*  65:100 */     return true;
/*  66:    */   }
/*  67:    */   
/*  68:    */   public AbstractMobileControl createControl(ControlData controlData)
/*  69:    */     throws MobileApplicationException
/*  70:    */   {
/*  71:106 */     return new MenuBarControl();
/*  72:    */   }
/*  73:    */   
/*  74:    */   public void refresh(UIEvent clientEvent)
/*  75:    */     throws MobileApplicationException
/*  76:    */   {
/*  77:111 */     super.refresh(clientEvent);
/*  78:112 */     addMenusToBar();
/*  79:113 */     showMenuBar();
/*  80:    */   }
/*  81:    */   
/*  82:116 */   private static WidgetCreator widgetCreator = null;
/*  83:    */   
/*  84:    */   public static void registerWidgetCreator(WidgetCreator wc)
/*  85:    */   {
/*  86:119 */     widgetCreator = wc;
/*  87:    */   }
/*  88:    */   
/*  89:    */   protected AbstractWidget createWidget()
/*  90:    */   {
/*  91:123 */     return widgetCreator.createWidget();
/*  92:    */   }
/*  93:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.controls.MenuBarControl
 * JD-Core Version:    0.7.0.1
 */