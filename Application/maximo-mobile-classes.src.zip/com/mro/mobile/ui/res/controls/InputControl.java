/*   1:    */ package com.mro.mobile.ui.res.controls;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.MobileMessageGenerator;
/*   5:    */ import com.mro.mobile.app.BasicMobileDeviceUIApplication;
/*   6:    */ import com.mro.mobile.app.DefaultMobileMboDataFormatter;
/*   7:    */ import com.mro.mobile.mbo.MobileMbo;
/*   8:    */ import com.mro.mobile.mbo.MobileMboAttributeInfo;
/*   9:    */ import com.mro.mobile.mbo.MobileMboInfo;
/*  10:    */ import com.mro.mobile.mbo.MobileMboQBE;
/*  11:    */ import com.mro.mobile.ui.LookupManager;
/*  12:    */ import com.mro.mobile.ui.MobileMboDataBean;
/*  13:    */ import com.mro.mobile.ui.event.UIEvent;
/*  14:    */ import com.mro.mobile.ui.res.ControlData;
/*  15:    */ import com.mro.mobile.ui.res.UIUtil;
/*  16:    */ import com.mro.mobile.ui.res.widgets.def.InputWidget;
/*  17:    */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  18:    */ import com.mro.mobile.util.MobileLogger;
/*  19:    */ import java.util.Date;
/*  20:    */ 
/*  21:    */ public abstract class InputControl
/*  22:    */   extends AbstractMobileControl
/*  23:    */ {
/*  24: 59 */   public String inputMode = null;
/*  25: 60 */   protected String dataAttribute = null;
/*  26: 61 */   protected MobileMboAttributeInfo attributeInfo = null;
/*  27:    */   
/*  28:    */   public abstract String getControlValue();
/*  29:    */   
/*  30:    */   protected InputWidget getInputWidget()
/*  31:    */   {
/*  32: 64 */     return (InputWidget)getWidget();
/*  33:    */   }
/*  34:    */   
/*  35:    */   public String getDataAttribute()
/*  36:    */   {
/*  37: 68 */     return this.dataAttribute;
/*  38:    */   }
/*  39:    */   
/*  40:    */   public String getDomainDataAttribute()
/*  41:    */   {
/*  42: 72 */     return getControlData().getValue("domainattribute");
/*  43:    */   }
/*  44:    */   
/*  45:    */   public void setControlData(ControlData controlAttributes)
/*  46:    */   {
/*  47: 82 */     this.dataAttribute = controlAttributes.getValue("dataattribute");
/*  48: 83 */     super.setControlData(controlAttributes);
/*  49:    */   }
/*  50:    */   
/*  51:    */   protected MobileMboAttributeInfo getAttributeInfo()
/*  52:    */     throws MobileApplicationException
/*  53:    */   {
/*  54: 88 */     if (this.attributeInfo == null) {
/*  55: 90 */       if (this.dataAttribute != null)
/*  56:    */       {
/*  57: 92 */         MobileMboDataBean dataBean = getDataBean();
/*  58: 94 */         if ((this instanceof LongDescription)) {
/*  59: 96 */           dataBean = ((PageControl)getPage()).getLaunchingControl().getDataBean();
/*  60:    */         }
/*  61: 98 */         if (dataBean != null) {
/*  62:100 */           this.attributeInfo = dataBean.getMobileMboInfo().getAttributeInfo(this.dataAttribute);
/*  63:    */         }
/*  64:    */       }
/*  65:    */     }
/*  66:104 */     return this.attributeInfo;
/*  67:    */   }
/*  68:    */   
/*  69:    */   public String getBoundLabel()
/*  70:    */     throws MobileApplicationException
/*  71:    */   {
/*  72:116 */     String label = getStringValue("label");
/*  73:121 */     if (label == null)
/*  74:    */     {
/*  75:123 */       MobileMboAttributeInfo info = getAttributeInfo();
/*  76:124 */       if (info != null) {
/*  77:125 */         label = info.getTitle();
/*  78:    */       }
/*  79:127 */       if ((label != null) && (!label.equals("")))
/*  80:    */       {
/*  81:129 */         Object[] param = { label };
/*  82:130 */         if ((this instanceof CheckboxControl))
/*  83:    */         {
/*  84:131 */           if (!MobileMessageGenerator.getMessageGenerator().isStringPattern(label, "checkboxlabelformat")) {
/*  85:132 */             label = MobileMessageGenerator.generate("checkboxlabelformat", param);
/*  86:    */           }
/*  87:    */         }
/*  88:    */         else {
/*  89:135 */           label = MobileMessageGenerator.generate("defaultlabelformat", param);
/*  90:    */         }
/*  91:    */       }
/*  92:    */     }
/*  93:138 */     return label;
/*  94:    */   }
/*  95:    */   
/*  96:    */   public UIComponent getLabelPanelUIComponent(boolean linkEnabled)
/*  97:    */     throws MobileApplicationException
/*  98:    */   {
/*  99:143 */     return getInputWidget().getLabelPanelUIComponent(linkEnabled);
/* 100:    */   }
/* 101:    */   
/* 102:    */   public String getValue()
/* 103:    */     throws MobileApplicationException
/* 104:    */   {
/* 105:148 */     MobileMboDataBean dataBean = getDataBean();
/* 106:149 */     if ((dataBean == null) || (this.dataAttribute == null)) {
/* 107:151 */       return "";
/* 108:    */     }
/* 109:154 */     if (isQuery()) {
/* 110:156 */       return dataBean.getQBE().getQBE(this.dataAttribute);
/* 111:    */     }
/* 112:159 */     return dataBean.getValue(this.dataAttribute);
/* 113:    */   }
/* 114:    */   
/* 115:    */   public boolean isReadOnly()
/* 116:    */   {
/* 117:178 */     if (this.readonly > -1) {
/* 118:179 */       return this.readonly == 1;
/* 119:    */     }
/* 120:182 */     if ((this.inputMode != null) && (this.inputMode.equals("readonly"))) {
/* 121:183 */       return true;
/* 122:    */     }
/* 123:185 */     if (isQuery()) {
/* 124:186 */       return false;
/* 125:    */     }
/* 126:188 */     if (UIUtil.isNull(this.dataAttribute)) {
/* 127:189 */       return false;
/* 128:    */     }
/* 129:    */     try
/* 130:    */     {
/* 131:193 */       MobileMboDataBean dataBean = getDataBean();
/* 132:194 */       if (dataBean != null)
/* 133:    */       {
/* 134:196 */         MobileMbo mbo = dataBean.getMobileMbo();
/* 135:197 */         if (mbo != null)
/* 136:    */         {
/* 137:199 */           if (mbo.isReadOnly()) {
/* 138:200 */             return true;
/* 139:    */           }
/* 140:201 */           return mbo.isReadOnly(this.dataAttribute);
/* 141:    */         }
/* 142:    */       }
/* 143:    */     }
/* 144:    */     catch (MobileApplicationException e)
/* 145:    */     {
/* 146:207 */       getDefaultLogger().warn("Failed to determine if is read only", e);
/* 147:    */     }
/* 148:211 */     return true;
/* 149:    */   }
/* 150:    */   
/* 151:    */   public boolean isRequired()
/* 152:    */   {
/* 153:230 */     if (this.required > -1) {
/* 154:231 */       return this.required == 1;
/* 155:    */     }
/* 156:234 */     if ((this.inputMode != null) && ((this.inputMode.equals("required")) || (this.inputMode.equals("passwordrequired")))) {
/* 157:235 */       return true;
/* 158:    */     }
/* 159:237 */     if ((this.inputMode != null) && (this.inputMode.equalsIgnoreCase("query"))) {
/* 160:239 */       return false;
/* 161:    */     }
/* 162:    */     try
/* 163:    */     {
/* 164:244 */       MobileMboDataBean dataBean = getDataBean();
/* 165:245 */       if (dataBean != null)
/* 166:    */       {
/* 167:247 */         MobileMbo mbo = dataBean.getMobileMbo();
/* 168:248 */         if (mbo != null) {
/* 169:250 */           return mbo.isRequired(this.dataAttribute);
/* 170:    */         }
/* 171:    */       }
/* 172:    */     }
/* 173:    */     catch (MobileApplicationException e)
/* 174:    */     {
/* 175:256 */       getDefaultLogger().warn("Failed to determine if is required", e);
/* 176:    */     }
/* 177:259 */     return false;
/* 178:    */   }
/* 179:    */   
/* 180:    */   public boolean isPassword()
/* 181:    */   {
/* 182:270 */     return (this.inputMode != null) && ((this.inputMode.equals("password")) || (this.inputMode.equals("passwordrequired")));
/* 183:    */   }
/* 184:    */   
/* 185:    */   public boolean isQuery()
/* 186:    */   {
/* 187:281 */     return (this.inputMode != null) && (this.inputMode.equals("query"));
/* 188:    */   }
/* 189:    */   
/* 190:    */   public boolean requiredcheck(UIEvent event)
/* 191:    */     throws MobileApplicationException
/* 192:    */   {
/* 193:286 */     if (isRequired())
/* 194:    */     {
/* 195:288 */       MobileMboDataBean dataBean = getDataBean();
/* 196:289 */       String value = null;
/* 197:290 */       if (this.dataAttribute == null)
/* 198:    */       {
/* 199:292 */         value = getControlValue();
/* 200:    */       }
/* 201:    */       else
/* 202:    */       {
/* 203:294 */         if ((dataBean == null) || (dataBean.getCurrentPosition() == -1)) {
/* 204:296 */           return false;
/* 205:    */         }
/* 206:300 */         value = getValue();
/* 207:    */       }
/* 208:302 */       if (UIUtil.isNull(value))
/* 209:    */       {
/* 210:304 */         Object[] param = { getBoundLabel() };
/* 211:305 */         if ((this instanceof FocusableControl)) {
/* 212:306 */           ((PageControl)this.app.getCurrentScreen()).setCurrentInput(this);
/* 213:    */         }
/* 214:307 */         throw new MobileApplicationException("requiredblank", param);
/* 215:    */       }
/* 216:    */     }
/* 217:310 */     return false;
/* 218:    */   }
/* 219:    */   
/* 220:    */   public boolean viewld(UIEvent event)
/* 221:    */     throws MobileApplicationException
/* 222:    */   {
/* 223:315 */     UIUtil.gotoPage("longdesc", this);
/* 224:316 */     return true;
/* 225:    */   }
/* 226:    */   
/* 227:    */   public boolean canhaveld(UIEvent event)
/* 228:    */     throws MobileApplicationException
/* 229:    */   {
/* 230:321 */     ((AbstractMobileControl)event.getCreatingObject()).setVisibility(isAttributeSet("longdescattribute"));
/* 231:322 */     return true;
/* 232:    */   }
/* 233:    */   
/* 234:    */   public boolean showdesc(UIEvent event)
/* 235:    */     throws MobileApplicationException
/* 236:    */   {
/* 237:327 */     String descAttr = getStringValue("descattribute");
/* 238:328 */     if (descAttr != null)
/* 239:    */     {
/* 240:330 */       String descMbo = getStringValue("descmobilembo");
/* 241:331 */       if (descMbo == null) {
/* 242:332 */         descMbo = getStringValue("domain");
/* 243:    */       }
/* 244:333 */       String domainAttr = getStringValue("descmobilembokeyattr");
/* 245:334 */       if (domainAttr == null)
/* 246:    */       {
/* 247:336 */         domainAttr = getStringValue("domainattribute");
/* 248:337 */         if (domainAttr == null) {
/* 249:339 */           domainAttr = this.dataAttribute;
/* 250:    */         }
/* 251:    */       }
/* 252:342 */       if ((descMbo != null) && (domainAttr != null))
/* 253:    */       {
/* 254:344 */         LookupManager luMan = UIUtil.getLookupManager();
/* 255:345 */         MobileMboDataBean dataBean = getDataBean();
/* 256:346 */         String value = dataBean.getValue(this.dataAttribute);
/* 257:347 */         MobileMboDataBean domainBean = luMan.createLookupDomainBean(descMbo);
/* 258:348 */         luMan.applyMultisiteFilter(domainBean, dataBean);
/* 259:349 */         domainBean.getQBE().setQbeExactMatch(true);
/* 260:350 */         domainBean.getQBE().setQBE(domainAttr, value);
/* 261:351 */         domainBean.reset();
/* 262:352 */         String desc = null;
/* 263:355 */         if ((domainBean.getMobileMbo(0) != null) && (value != null) && (!value.equals(""))) {
/* 264:357 */           desc = domainBean.getValue(0, descAttr);
/* 265:    */         }
/* 266:359 */         UIUtil.showMessageBoxControl("descbox", desc == null ? "" : desc, event);
/* 267:    */       }
/* 268:361 */       else if (descMbo == null)
/* 269:    */       {
/* 270:363 */         MobileMboDataBean dataBean = getDataBean();
/* 271:364 */         String desc = dataBean.getValue(descAttr);
/* 272:365 */         UIUtil.showMessageBoxControl("descbox", desc == null ? "" : desc, event);
/* 273:    */       }
/* 274:    */     }
/* 275:368 */     return true;
/* 276:    */   }
/* 277:    */   
/* 278:    */   public void refresh(UIEvent event)
/* 279:    */     throws MobileApplicationException
/* 280:    */   {
/* 281:377 */     this.attributeInfo = null;
/* 282:378 */     super.refresh(event);
/* 283:379 */     refreshLabel();
/* 284:    */   }
/* 285:    */   
/* 286:    */   protected void setLeftConstraints(UIComponent component)
/* 287:    */   {
/* 288:384 */     getInputWidget().setLeftConstraints(component);
/* 289:    */   }
/* 290:    */   
/* 291:    */   protected void setRightConstraints(UIComponent component)
/* 292:    */   {
/* 293:389 */     getInputWidget().setRightConstraints(component);
/* 294:    */   }
/* 295:    */   
/* 296:    */   public void refreshLabel()
/* 297:    */     throws MobileApplicationException
/* 298:    */   {
/* 299:394 */     getInputWidget().refreshLabel();
/* 300:    */   }
/* 301:    */   
/* 302:    */   protected boolean performEvent(UIEvent event)
/* 303:    */     throws MobileApplicationException
/* 304:    */   {
/* 305:402 */     String eventType = event.getEventName();
/* 306:403 */     if (eventType.equals("setvalue")) {
/* 307:405 */       return setvalue(event);
/* 308:    */     }
/* 309:407 */     if (eventType.equals("requiredcheck")) {
/* 310:409 */       return requiredcheck(event);
/* 311:    */     }
/* 312:411 */     if (eventType.equals("showdesc")) {
/* 313:413 */       return showdesc(event);
/* 314:    */     }
/* 315:415 */     if (eventType.equals("viewld")) {
/* 316:417 */       return viewld(event);
/* 317:    */     }
/* 318:419 */     if (eventType.equals("canhaveld")) {
/* 319:421 */       return canhaveld(event);
/* 320:    */     }
/* 321:423 */     return false;
/* 322:    */   }
/* 323:    */   
/* 324:    */   public boolean setvalue(UIEvent event)
/* 325:    */     throws MobileApplicationException
/* 326:    */   {
/* 327:435 */     if (this.dataAttribute != null)
/* 328:    */     {
/* 329:437 */       MobileMboDataBean dataBean = getDataBean();
/* 330:439 */       if ((this instanceof LongDescription)) {
/* 331:441 */         dataBean = ((PageControl)getPage()).getLaunchingControl().getDataBean();
/* 332:    */       }
/* 333:443 */       if (dataBean != null)
/* 334:    */       {
/* 335:445 */         String value = (String)event.getValue();
/* 336:446 */         String validate = getStringValue("validateevent");
/* 337:447 */         Object validateValue = value;
/* 338:448 */         if (validate != null)
/* 339:    */         {
/* 340:450 */           if (!UIUtil.isNull(value)) {
/* 341:452 */             switch (getAttributeInfo().getDataType())
/* 342:    */             {
/* 343:    */             case 11: 
/* 344:455 */               validateValue = DefaultMobileMboDataFormatter.stringToDateTime(value);
/* 345:456 */               break;
/* 346:    */             case 9: 
/* 347:459 */               validateValue = DefaultMobileMboDataFormatter.stringToDate(value);
/* 348:460 */               break;
/* 349:    */             case 10: 
/* 350:463 */               validateValue = DefaultMobileMboDataFormatter.stringToTime(value);
/* 351:    */             }
/* 352:    */           }
/* 353:467 */           if (!validateControl(event, validateValue))
/* 354:    */           {
/* 355:469 */             event.setEventErrored();
/* 356:470 */             return true;
/* 357:    */           }
/* 358:474 */           event.setEventErrored(false);
/* 359:    */         }
/* 360:477 */         if (getAttributeInfo().getDataType() == 8)
/* 361:    */         {
/* 362:479 */           if (!isQuery())
/* 363:    */           {
/* 364:482 */             MobileMbo mbo = dataBean.getMobileMbo();
/* 365:483 */             if (mbo != null)
/* 366:    */             {
/* 367:485 */               mbo.setBooleanValue(this.dataAttribute, Boolean.valueOf(value).booleanValue());
/* 368:486 */               UIUtil.refreshCurrentScreen();
/* 369:    */             }
/* 370:    */           }
/* 371:    */           else
/* 372:    */           {
/* 373:491 */             dataBean.getQBE().setQBE(this.dataAttribute, value);
/* 374:    */           }
/* 375:    */         }
/* 376:    */         else
/* 377:    */         {
/* 378:496 */           if (isQuery())
/* 379:    */           {
/* 380:498 */             dataBean.getQBE().setQBE(this.dataAttribute, value);
/* 381:    */           }
/* 382:502 */           else if ((validateValue instanceof Date))
/* 383:    */           {
/* 384:504 */             MobileMbo mbo = dataBean.getMobileMbo();
/* 385:505 */             if (mbo != null) {
/* 386:506 */               mbo.setDateValue(this.dataAttribute, (Date)validateValue);
/* 387:    */             }
/* 388:    */           }
/* 389:    */           else
/* 390:    */           {
/* 391:509 */             dataBean.setValue(this.dataAttribute, value);
/* 392:    */           }
/* 393:511 */           UIUtil.refreshCurrentScreen();
/* 394:    */         }
/* 395:    */       }
/* 396:    */     }
/* 397:515 */     return true;
/* 398:    */   }
/* 399:    */   
/* 400:    */   public void setParentControl(AbstractMobileControl parentControl)
/* 401:    */   {
/* 402:523 */     super.setParentControl(parentControl);
/* 403:524 */     this.inputMode = inheritControlAttribute("inputmode");
/* 404:    */   }
/* 405:    */   
/* 406:    */   public MobileMboDataBean getLongDescDataBean()
/* 407:    */     throws MobileApplicationException
/* 408:    */   {
/* 409:529 */     MobileMboDataBean ldBean = null;
/* 410:530 */     String ldMbo = getStringValue("ldmobilembo");
/* 411:531 */     if (ldMbo == null) {
/* 412:532 */       ldMbo = getStringValue("descmobilembo");
/* 413:    */     }
/* 414:534 */     if (ldMbo == null) {
/* 415:535 */       ldMbo = getStringValue("domain");
/* 416:    */     }
/* 417:536 */     String ldMboAttr = getStringValue("ldmobilembokeyattr");
/* 418:537 */     if (ldMboAttr == null)
/* 419:    */     {
/* 420:539 */       ldMboAttr = getStringValue("descmobilembokeyattr");
/* 421:540 */       if (ldMboAttr == null)
/* 422:    */       {
/* 423:542 */         ldMboAttr = getStringValue("domainattribute");
/* 424:543 */         if (ldMboAttr == null) {
/* 425:545 */           ldMboAttr = this.dataAttribute;
/* 426:    */         }
/* 427:    */       }
/* 428:    */     }
/* 429:550 */     if ((ldMbo != null) && (ldMboAttr != null))
/* 430:    */     {
/* 431:552 */       LookupManager luMan = UIUtil.getLookupManager();
/* 432:553 */       MobileMboDataBean dataBean = getDataBean();
/* 433:554 */       String value = dataBean.getValue(this.dataAttribute);
/* 434:555 */       ldBean = luMan.createLookupDomainBean(ldMbo);
/* 435:556 */       luMan.applyMultisiteFilter(ldBean, dataBean);
/* 436:557 */       ldBean.getQBE().setQbeExactMatch(true);
/* 437:562 */       if ((value != null) && (value.length() > 0)) {
/* 438:564 */         ldBean.getQBE().setQBE(ldMboAttr, value);
/* 439:    */       } else {
/* 440:568 */         ldBean.getQBE().setQBE(ldMboAttr, "~NULL~");
/* 441:    */       }
/* 442:572 */       ldBean.reset();
/* 443:573 */       ldBean.setCurrentPosition(0);
/* 444:    */     }
/* 445:576 */     else if (ldMbo == null)
/* 446:    */     {
/* 447:578 */       ldBean = getDataBean();
/* 448:    */     }
/* 449:580 */     return ldBean;
/* 450:    */   }
/* 451:    */   
/* 452:    */   public String getLongDesc()
/* 453:    */     throws MobileApplicationException
/* 454:    */   {
/* 455:585 */     String desc = null;
/* 456:    */     
/* 457:587 */     String ldAttr = getStringValue("longdescattribute");
/* 458:588 */     if (!UIUtil.isNull(ldAttr))
/* 459:    */     {
/* 460:590 */       MobileMboDataBean ldDataBean = getLongDescDataBean();
/* 461:593 */       if ((ldDataBean != null) && (ldDataBean.count() > 0)) {
/* 462:595 */         desc = ldDataBean.getValue(ldAttr);
/* 463:    */       } else {
/* 464:600 */         desc = "";
/* 465:    */       }
/* 466:    */     }
/* 467:604 */     return desc;
/* 468:    */   }
/* 469:    */   
/* 470:    */   public boolean isLongDescReadOnly()
/* 471:    */   {
/* 472:610 */     return (isAttributeSet("ldmobilembo")) || (isAttributeSet("descmobilembo")) || (isAttributeSet("domain")) || (isReadOnly());
/* 473:    */   }
/* 474:    */   
/* 475:    */   public void setTextFieldFocus(UIComponent textField)
/* 476:    */   {
/* 477:615 */     getInputWidget().setTextFieldFocus(textField);
/* 478:    */   }
/* 479:    */   
/* 480:    */   public void setReadonly(boolean readonly)
/* 481:    */   {
/* 482:623 */     super.setReadonly(readonly);
/* 483:    */     try
/* 484:    */     {
/* 485:626 */       refreshControl(null);
/* 486:    */     }
/* 487:    */     catch (MobileApplicationException e) {}
/* 488:    */   }
/* 489:    */   
/* 490:    */   public void setRequired(boolean required)
/* 491:    */   {
/* 492:639 */     super.setRequired(required);
/* 493:    */     try
/* 494:    */     {
/* 495:642 */       if ((this instanceof InputControl))
/* 496:    */       {
/* 497:645 */         refreshControl(null);
/* 498:646 */         refreshLabel();
/* 499:    */       }
/* 500:    */     }
/* 501:    */     catch (MobileApplicationException e) {}
/* 502:    */   }
/* 503:    */   
/* 504:    */   public boolean handleEvent(UIEvent event)
/* 505:    */   {
/* 506:660 */     if ((!AbstractMobileControl.isUiTestMode()) && 
/* 507:661 */       (this.app.getUserEvent() == null)) {
/* 508:662 */       ((PageControl)this.app.getCurrentScreen()).setCurrentInput(this);
/* 509:    */     }
/* 510:664 */     return super.handleEvent(event);
/* 511:    */   }
/* 512:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.controls.InputControl
 * JD-Core Version:    0.7.0.1
 */