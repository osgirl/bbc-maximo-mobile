/*   1:    */ package com.mro.mobile.ui.res.controls;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.mbo.MobileMboQBE;
/*   5:    */ import com.mro.mobile.ui.DataBeanCache;
/*   6:    */ import com.mro.mobile.ui.LookupManager;
/*   7:    */ import com.mro.mobile.ui.MobileMboDataBean;
/*   8:    */ import com.mro.mobile.ui.event.UIEvent;
/*   9:    */ import com.mro.mobile.ui.res.ControlData;
/*  10:    */ import com.mro.mobile.ui.res.UIUtil;
/*  11:    */ import com.mro.mobile.ui.res.controls.utils.ControlStyle;
/*  12:    */ import com.mro.mobile.ui.res.widgets.def.AbstractWidget;
/*  13:    */ import com.mro.mobile.ui.res.widgets.def.DropDownWidget;
/*  14:    */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  15:    */ import com.mro.mobile.ui.res.widgets.def.WidgetCreator;
/*  16:    */ import java.util.Vector;
/*  17:    */ 
/*  18:    */ public class DropDownControl
/*  19:    */   extends InputControl
/*  20:    */   implements FocusableControl
/*  21:    */ {
/*  22: 43 */   protected String displayDataAttribute = null;
/*  23: 44 */   protected String valueDataAttribute = null;
/*  24: 45 */   protected DropDownWidget comboboxWidget = null;
/*  25: 46 */   protected Vector comboVector = new Vector();
/*  26: 47 */   protected boolean addItem = false;
/*  27: 48 */   private static String STYLEKEY = "dropdown";
/*  28: 49 */   protected ControlStyle style = null;
/*  29: 50 */   private boolean setDefaultValue = false;
/*  30:    */   
/*  31:    */   protected DropDownWidget getDropDownWidget()
/*  32:    */   {
/*  33: 56 */     return (DropDownWidget)super.getWidget();
/*  34:    */   }
/*  35:    */   
/*  36:    */   public AbstractMobileControl createControl(ControlData controlData)
/*  37:    */     throws MobileApplicationException
/*  38:    */   {
/*  39: 60 */     return new DropDownControl();
/*  40:    */   }
/*  41:    */   
/*  42:    */   public UIComponent[] composeComponents()
/*  43:    */     throws MobileApplicationException
/*  44:    */   {
/*  45: 68 */     performInitEvent();
/*  46: 69 */     this.comboboxWidget = getDropDownWidget().createDropDownField();
/*  47: 70 */     this.style = getStyle(STYLEKEY);
/*  48: 71 */     this.comboboxWidget.setDropDownId(getStringValue("id"));
/*  49: 72 */     this.comboboxWidget.setEvent(getStringValue("event"));
/*  50: 73 */     this.comboboxWidget.setController(this);
/*  51: 74 */     this.comboboxWidget.setDataBeanName(inheritControlAttribute("datasrcname", ""));
/*  52: 75 */     this.comboboxWidget.setMobileMboAttributeName(getStringValue("mobilembo"));
/*  53:    */     
/*  54: 77 */     this.setDefaultValue = getBooleanValue("setdefaultvalue");
/*  55:    */     
/*  56: 79 */     this.valueDataAttribute = getStringValue("valuedataattribute");
/*  57: 80 */     if (this.valueDataAttribute == null) {
/*  58: 81 */       this.valueDataAttribute = this.dataAttribute;
/*  59:    */     }
/*  60: 82 */     this.displayDataAttribute = getStringValue("displaydataattribute");
/*  61: 83 */     if (this.displayDataAttribute == null) {
/*  62: 84 */       this.displayDataAttribute = this.valueDataAttribute;
/*  63:    */     }
/*  64: 86 */     String strAddBlank = getStringValue("addblankitem");
/*  65: 87 */     if (((strAddBlank != null) && (strAddBlank.equalsIgnoreCase("true"))) || (this.comboboxWidget.needsBlankItem())) {
/*  66: 88 */       this.addItem = true;
/*  67:    */     }
/*  68: 90 */     setAllLookupValues();
/*  69: 91 */     if (isReadOnly()) {
/*  70: 93 */       this.comboboxWidget.setEnabled(false);
/*  71:    */     }
/*  72: 96 */     UIComponent[] components = getDropDownWidget().resolveDropDownComponents();
/*  73:    */     
/*  74:    */ 
/*  75: 99 */     setDefaultValueSelected();
/*  76:    */     
/*  77:101 */     return components;
/*  78:    */   }
/*  79:    */   
/*  80:    */   public String getSelectedItemText()
/*  81:    */   {
/*  82:105 */     return this.comboboxWidget.getSelectedItemAsText();
/*  83:    */   }
/*  84:    */   
/*  85:    */   private void setDefaultValueSelected()
/*  86:    */     throws MobileApplicationException
/*  87:    */   {
/*  88:112 */     String fieldValue = null;
/*  89:113 */     String fieldName = null;
/*  90:114 */     int selected = -1;
/*  91:116 */     if ((this.setDefaultValue) && (!isReadOnly()))
/*  92:    */     {
/*  93:118 */       fieldValue = getStringValue("defaultselectedvalue");
/*  94:119 */       fieldName = getStringValue("defaultfieldname");
/*  95:120 */       if (fieldName != null) {
/*  96:121 */         fieldValue = getDataBean().getValue(fieldName);
/*  97:    */       }
/*  98:123 */       if ((fieldValue != null) && 
/*  99:124 */         (performValidation(fieldValue))) {
/* 100:125 */         for (int i = 0; i < this.comboVector.size(); i++)
/* 101:    */         {
/* 102:126 */           String value = this.comboVector.get(i).toString();
/* 103:127 */           if (value.equals(fieldValue))
/* 104:    */           {
/* 105:128 */             selected = i;
/* 106:129 */             break;
/* 107:    */           }
/* 108:    */         }
/* 109:    */       }
/* 110:    */     }
/* 111:135 */     if (selected != -1)
/* 112:    */     {
/* 113:136 */       this.comboboxWidget.setSelectedItem(selected);
/* 114:137 */       getDataBean().setValue(this.dataAttribute, fieldValue);
/* 115:    */     }
/* 116:    */   }
/* 117:    */   
/* 118:    */   private boolean performValidation(String fieldValue)
/* 119:    */   {
/* 120:145 */     String validationEvent = getStringValue("defaultvalidationevent");
/* 121:146 */     if (validationEvent != null)
/* 122:    */     {
/* 123:147 */       UIEvent event = new UIEvent(this, validationEvent, null, fieldValue);
/* 124:148 */       handleEvent(event);
/* 125:149 */       return !event.errorOccured();
/* 126:    */     }
/* 127:151 */     return true;
/* 128:    */   }
/* 129:    */   
/* 130:    */   private boolean setAllLookupValues()
/* 131:    */     throws MobileApplicationException
/* 132:    */   {
/* 133:160 */     int curValueIndex = -1;
/* 134:163 */     if (this.comboVector != null) {
/* 135:164 */       this.comboVector.clear();
/* 136:    */     }
/* 137:167 */     String parentDatasrc = getStringValue("listparentdatasrcname");
/* 138:168 */     MobileMboDataBean listDataBean = null;
/* 139:169 */     if (parentDatasrc == null)
/* 140:    */     {
/* 141:171 */       listDataBean = UIUtil.getLookupManager().createLookupDomainBean(getStringValue("listdatasrcname"));
/* 142:    */     }
/* 143:    */     else
/* 144:    */     {
/* 145:175 */       MobileMboDataBean parentDataBean = DataBeanCache.findDataBean(parentDatasrc);
/* 146:176 */       listDataBean = parentDataBean.getDataBean(getStringValue("listmobilembo"));
/* 147:    */     }
/* 148:179 */     if ((listDataBean == null) || (getDataBean().getMobileMbo() == null)) {
/* 149:181 */       return false;
/* 150:    */     }
/* 151:185 */     UIUtil.getLookupManager().applyMultisiteFilter(listDataBean, getDataBean());
/* 152:187 */     if (this.dataAttribute == null) {
/* 153:189 */       return false;
/* 154:    */     }
/* 155:192 */     String filterEvent = getStringValue("filterevent");
/* 156:193 */     if (filterEvent != null)
/* 157:    */     {
/* 158:195 */       UIEvent event = new UIEvent(this, filterEvent, null, listDataBean);
/* 159:196 */       handleEvent(event);
/* 160:    */     }
/* 161:198 */     String curDataValue = getValue();
/* 162:199 */     this.comboboxWidget.setEnabled(true);
/* 163:    */     
/* 164:201 */     int count = listDataBean.count();
/* 165:202 */     if (isAddItem())
/* 166:    */     {
/* 167:206 */       this.comboboxWidget.addBlankItem(this.style);
/* 168:207 */       this.comboVector.add(0, null);
/* 169:    */     }
/* 170:209 */     for (int i = 0; i < count; i++)
/* 171:    */     {
/* 172:210 */       listDataBean.setCurrentPosition(i);
/* 173:211 */       this.comboboxWidget.addItem(listDataBean.getValue(this.displayDataAttribute), this.style);
/* 174:212 */       String internalValue = listDataBean.getValue(this.valueDataAttribute);
/* 175:213 */       if ((curDataValue != null) && (internalValue.equalsIgnoreCase(curDataValue))) {
/* 176:215 */         curValueIndex = isAddItem() ? i + 1 : i;
/* 177:    */       }
/* 178:217 */       this.comboVector.add(isAddItem() ? i + 1 : i, listDataBean.getValue(this.valueDataAttribute));
/* 179:    */     }
/* 180:221 */     this.comboboxWidget.applyDataAdapter();
/* 181:222 */     this.comboboxWidget.setSelectedItem(curValueIndex);
/* 182:    */     
/* 183:    */ 
/* 184:225 */     listDataBean.reset();
/* 185:226 */     if (curValueIndex != -1) {
/* 186:227 */       this.comboboxWidget.setSelectedItem(curValueIndex);
/* 187:    */     }
/* 188:229 */     this.comboboxWidget.bindListeners();
/* 189:230 */     return true;
/* 190:    */   }
/* 191:    */   
/* 192:    */   protected boolean handleException(UIEvent event, Exception exception)
/* 193:    */   {
/* 194:238 */     return false;
/* 195:    */   }
/* 196:    */   
/* 197:    */   protected boolean refreshControl(UIEvent event)
/* 198:    */     throws MobileApplicationException
/* 199:    */   {
/* 200:247 */     this.comboboxWidget.clear();
/* 201:248 */     setAllLookupValues();
/* 202:251 */     if (isReadOnly()) {
/* 203:253 */       this.comboboxWidget.setEnabled(false);
/* 204:    */     }
/* 205:255 */     return true;
/* 206:    */   }
/* 207:    */   
/* 208:    */   protected boolean init()
/* 209:    */   {
/* 210:263 */     return true;
/* 211:    */   }
/* 212:    */   
/* 213:    */   public boolean setvalue(UIEvent event)
/* 214:    */     throws MobileApplicationException
/* 215:    */   {
/* 216:275 */     if (this.dataAttribute != null)
/* 217:    */     {
/* 218:277 */       MobileMboDataBean dataBean = getDataBean();
/* 219:278 */       String value = null;
/* 220:279 */       if (dataBean != null)
/* 221:    */       {
/* 222:281 */         if (this.comboboxWidget.getSelectedIndex() > -1) {
/* 223:283 */           if ((isAddItem()) && (this.comboboxWidget.getSelectedIndex() == 0)) {
/* 224:285 */             value = "";
/* 225:    */           } else {
/* 226:287 */             value = (String)this.comboVector.get(this.comboboxWidget.getSelectedIndex());
/* 227:    */           }
/* 228:    */         }
/* 229:290 */         if (value != null)
/* 230:    */         {
/* 231:292 */           if (validateControl(event, value))
/* 232:    */           {
/* 233:294 */             if ((this.inputMode != null) && (this.inputMode.equals("query"))) {
/* 234:296 */               dataBean.getQBE().setQBE(this.dataAttribute, value);
/* 235:    */             } else {
/* 236:300 */               dataBean.setValue(this.dataAttribute, value);
/* 237:    */             }
/* 238:302 */             UIUtil.refreshCurrentScreen();
/* 239:    */           }
/* 240:    */           else
/* 241:    */           {
/* 242:308 */             String oldValue = dataBean.getValue(this.dataAttribute);
/* 243:309 */             int index = this.comboVector.indexOf(oldValue);
/* 244:310 */             if ((oldValue == null) || (oldValue.trim().length() == 0)) {
/* 245:311 */               index = 0;
/* 246:    */             }
/* 247:313 */             if (index > -1) {
/* 248:314 */               this.comboboxWidget.setSelectedItem(index);
/* 249:    */             }
/* 250:    */           }
/* 251:    */         }
/* 252:    */         else {
/* 253:319 */           event.setEventErrored();
/* 254:    */         }
/* 255:    */       }
/* 256:    */     }
/* 257:323 */     return true;
/* 258:    */   }
/* 259:    */   
/* 260:    */   protected boolean performInitEvent()
/* 261:    */   {
/* 262:331 */     String initEvent = getStringValue("initevent");
/* 263:332 */     if (initEvent != null)
/* 264:    */     {
/* 265:334 */       UIEvent event = new UIEvent(this, initEvent, null, null);
/* 266:335 */       handleEvent(event);
/* 267:336 */       return !event.errorOccured();
/* 268:    */     }
/* 269:338 */     return true;
/* 270:    */   }
/* 271:    */   
/* 272:    */   public String getControlValue()
/* 273:    */   {
/* 274:345 */     return this.comboboxWidget.getSelectedItem().toString();
/* 275:    */   }
/* 276:    */   
/* 277:    */   public boolean isAddItem()
/* 278:    */   {
/* 279:351 */     return this.addItem;
/* 280:    */   }
/* 281:    */   
/* 282:    */   public void setFocus()
/* 283:    */   {
/* 284:356 */     if (this.comboboxWidget != null) {
/* 285:357 */       this.comboboxWidget.requestFocus();
/* 286:    */     }
/* 287:    */   }
/* 288:    */   
/* 289:361 */   private static WidgetCreator widgetCreator = null;
/* 290:    */   
/* 291:    */   public static void registerWidgetCreator(WidgetCreator wc)
/* 292:    */   {
/* 293:364 */     widgetCreator = wc;
/* 294:    */   }
/* 295:    */   
/* 296:    */   protected AbstractWidget createWidget()
/* 297:    */   {
/* 298:368 */     return widgetCreator.createWidget();
/* 299:    */   }
/* 300:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.controls.DropDownControl
 * JD-Core Version:    0.7.0.1
 */