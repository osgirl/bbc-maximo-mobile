/*    1:     */ package com.mro.mobile.ui.res.controls;
/*    2:     */ 
/*    3:     */ import com.mro.mobile.MobileApplicationException;
/*    4:     */ import com.mro.mobile.MobileMessageGenerator;
/*    5:     */ import com.mro.mobile.app.BasicMobileDeviceUIApplication;
/*    6:     */ import com.mro.mobile.app.DefaultMobileMboDataFormatter;
/*    7:     */ import com.mro.mobile.app.MobileDeviceAppSession;
/*    8:     */ import com.mro.mobile.ui.ControlComposer;
/*    9:     */ import com.mro.mobile.ui.DataBeanCache;
/*   10:     */ import com.mro.mobile.ui.DataBeanCacheItem;
/*   11:     */ import com.mro.mobile.ui.MobileMboDataBean;
/*   12:     */ import com.mro.mobile.ui.MobileMboDataBeanManager;
/*   13:     */ import com.mro.mobile.ui.MobileUIControlData;
/*   14:     */ import com.mro.mobile.ui.UIControlManager;
/*   15:     */ import com.mro.mobile.ui.UIHandlerManager;
/*   16:     */ import com.mro.mobile.ui.event.UIEvent;
/*   17:     */ import com.mro.mobile.ui.event.UIEventHandler;
/*   18:     */ import com.mro.mobile.ui.res.ControlData;
/*   19:     */ import com.mro.mobile.ui.res.MobileUIProperties;
/*   20:     */ import com.mro.mobile.ui.res.MobileUIResources;
/*   21:     */ import com.mro.mobile.ui.res.UIUtil;
/*   22:     */ import com.mro.mobile.ui.res.controls.utils.ControlStyle;
/*   23:     */ import com.mro.mobile.ui.res.controls.utils.StyleManager;
/*   24:     */ import com.mro.mobile.ui.res.controls.utils.TreeNodeData;
/*   25:     */ import com.mro.mobile.ui.res.widgets.def.AbstractWidget;
/*   26:     */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*   27:     */ import com.mro.mobile.util.MobileLogger;
/*   28:     */ import com.mro.mobile.util.MobileLoggerFactory;
/*   29:     */ import java.util.ArrayList;
/*   30:     */ import java.util.Date;
/*   31:     */ import java.util.Enumeration;
/*   32:     */ import java.util.HashMap;
/*   33:     */ import java.util.HashSet;
/*   34:     */ import java.util.Iterator;
/*   35:     */ import java.util.StringTokenizer;
/*   36:     */ 
/*   37:     */ public abstract class AbstractMobileControl
/*   38:     */   implements ControlComposer, AttributeNameConstants
/*   39:     */ {
/*   40:  52 */   protected MobileLogger log = MobileLoggerFactory.getLogger("maximo.mobile.communication");
/*   41:  55 */   protected ControlData controlAttributes = null;
/*   42:  56 */   protected ArrayList childControls = null;
/*   43:  57 */   protected AbstractMobileControl parentControl = null;
/*   44:  58 */   protected UIComponent[] components = null;
/*   45:  59 */   protected String id = null;
/*   46:  60 */   protected HashMap inheritedValues = null;
/*   47:  61 */   protected BasicMobileDeviceUIApplication app = UIUtil.getApplication();
/*   48:  62 */   protected boolean initalized = false;
/*   49:  63 */   protected boolean visible = true;
/*   50:  64 */   protected int readonly = -1;
/*   51:  65 */   protected int required = -1;
/*   52:  66 */   protected String displayEvent = null;
/*   53:  67 */   protected AbstractMobileControl myToolBar = null;
/*   54:  68 */   protected boolean useBarCode = false;
/*   55:  69 */   protected boolean useRFID = false;
/*   56:  71 */   protected HashSet imageAttributes = null;
/*   57:  73 */   protected AbstractMobileControl menuBar = null;
/*   58:  89 */   protected AbstractWidget widget = null;
/*   59:     */   
/*   60:     */   public abstract UIComponent[] composeComponents()
/*   61:     */     throws MobileApplicationException;
/*   62:     */   
/*   63:     */   protected abstract boolean performEvent(UIEvent paramUIEvent)
/*   64:     */     throws MobileApplicationException;
/*   65:     */   
/*   66:     */   protected abstract boolean handleException(UIEvent paramUIEvent, Exception paramException);
/*   67:     */   
/*   68:     */   protected abstract boolean refreshControl(UIEvent paramUIEvent)
/*   69:     */     throws MobileApplicationException;
/*   70:     */   
/*   71:     */   public abstract AbstractMobileControl createControl(ControlData paramControlData)
/*   72:     */     throws MobileApplicationException;
/*   73:     */   
/*   74:     */   protected AbstractWidget getWidget()
/*   75:     */   {
/*   76:  92 */     return this.widget;
/*   77:     */   }
/*   78:     */   
/*   79:     */   public AbstractMobileControl()
/*   80:     */   {
/*   81:  96 */     this.imageAttributes = new HashSet();
/*   82:  97 */     this.imageAttributes.add("tabimage");
/*   83:  98 */     this.imageAttributes.add("image");
/*   84:  99 */     this.imageAttributes.add("backgroundimage");
/*   85:     */     
/*   86: 101 */     setupWidget();
/*   87:     */   }
/*   88:     */   
/*   89:     */   public MobileLogger getDefaultLogger()
/*   90:     */   {
/*   91: 105 */     return MobileLoggerFactory.getDefaultLogger();
/*   92:     */   }
/*   93:     */   
/*   94:     */   protected void setupWidget()
/*   95:     */   {
/*   96: 109 */     this.widget = createWidget();
/*   97: 110 */     this.widget.setController(this);
/*   98:     */   }
/*   99:     */   
/*  100:     */   protected abstract AbstractWidget createWidget();
/*  101:     */   
/*  102:     */   public Object compose(ControlData controlData)
/*  103:     */   {
/*  104:     */     try
/*  105:     */     {
/*  106: 119 */       AbstractMobileControl control = buildControl(controlData);
/*  107: 120 */       if (control != null) {
/*  108: 122 */         control.setComponents(control.composeComponents());
/*  109:     */       }
/*  110: 124 */       return control;
/*  111:     */     }
/*  112:     */     catch (MobileApplicationException e)
/*  113:     */     {
/*  114: 128 */       getDefaultLogger().warn("Failed to compose ControlData", e);
/*  115:     */     }
/*  116: 130 */     return null;
/*  117:     */   }
/*  118:     */   
/*  119:     */   public AbstractMobileControl buildControl(ControlData controlData)
/*  120:     */   {
/*  121:     */     try
/*  122:     */     {
/*  123: 138 */       AbstractMobileControl control = createControl(controlData);
/*  124: 139 */       if (control != null)
/*  125:     */       {
/*  126: 141 */         control.setControlData(controlData);
/*  127: 142 */         control.createChildren();
/*  128:     */       }
/*  129: 144 */       return control;
/*  130:     */     }
/*  131:     */     catch (MobileApplicationException e)
/*  132:     */     {
/*  133: 148 */       getDefaultLogger().warn("Failed to build control", e);
/*  134:     */     }
/*  135: 150 */     return null;
/*  136:     */   }
/*  137:     */   
/*  138:     */   private void createChildren(ControlData[] childrenData)
/*  139:     */     throws MobileApplicationException
/*  140:     */   {
/*  141: 155 */     if (childrenData != null)
/*  142:     */     {
/*  143: 157 */       int noOfChildren = childrenData.length;
/*  144: 158 */       UIControlManager controlManager = UIControlManager.getInstance();
/*  145: 159 */       for (int i = 0; i < noOfChildren; i++)
/*  146:     */       {
/*  147: 161 */         String controlType = childrenData[i].getName();
/*  148: 163 */         if ((controlType.equals("includecontrol")) || (controlType.equals("includemenu")))
/*  149:     */         {
/*  150: 165 */           String ctrlid = childrenData[i].getValue("controlid");
/*  151:     */           
/*  152: 167 */           String datasrc = childrenData[i].getValue("datasrcname");
/*  153: 168 */           String mobilembo = childrenData[i].getValue("mobilembo");
/*  154: 169 */           String handler = childrenData[i].getValue("handler");
/*  155: 171 */           if (ctrlid != null)
/*  156:     */           {
/*  157: 173 */             MobileUIControlData includeData = (MobileUIControlData)controlManager.getControlData(ctrlid);
/*  158: 175 */             if (includeData == null) {
/*  159:     */               continue;
/*  160:     */             }
/*  161: 179 */             MobileUIControlData childData = includeData.cloneThis();
/*  162: 180 */             String id = childrenData[i].getValue("id");
/*  163: 181 */             if (id != null) {
/*  164: 182 */               childData.putValue("id", id);
/*  165:     */             }
/*  166: 183 */             if (datasrc != null) {
/*  167: 184 */               childData.putValue("datasrcname", datasrc);
/*  168:     */             }
/*  169: 185 */             if (mobilembo != null) {
/*  170: 186 */               childData.putValue("mobilembo", mobilembo);
/*  171:     */             }
/*  172: 187 */             if (handler != null) {
/*  173: 188 */               childData.putValue("handler", handler);
/*  174:     */             }
/*  175: 189 */             childrenData[i] = childData;
/*  176: 190 */             controlType = childData.getName();
/*  177:     */           }
/*  178:     */         }
/*  179: 195 */         ControlComposer cc = controlManager.getControlComposer(controlType);
/*  180: 196 */         if (cc != null) {
/*  181: 198 */           if ((cc instanceof AbstractMobileControl))
/*  182:     */           {
/*  183: 200 */             AbstractMobileControl control = ((AbstractMobileControl)cc).createControl(childrenData[i]);
/*  184: 201 */             if (control != null)
/*  185:     */             {
/*  186: 203 */               control.setControlData(childrenData[i]);
/*  187: 204 */               addChildControl(control);
/*  188: 205 */               control.createChildren();
/*  189:     */             }
/*  190:     */           }
/*  191:     */           else
/*  192:     */           {
/*  193: 212 */             Object ctrl = cc.compose(childrenData[i]);
/*  194: 213 */             if ((ctrl instanceof AbstractMobileControl))
/*  195:     */             {
/*  196: 215 */               addChildControl((AbstractMobileControl)ctrl);
/*  197: 216 */               ((AbstractMobileControl)ctrl).createChildren();
/*  198:     */             }
/*  199:     */           }
/*  200:     */         }
/*  201:     */       }
/*  202:     */     }
/*  203:     */   }
/*  204:     */   
/*  205:     */   protected ArrayList createChildren()
/*  206:     */     throws MobileApplicationException
/*  207:     */   {
/*  208: 231 */     UIControlManager controlManager = UIControlManager.getInstance();
/*  209:     */     
/*  210: 233 */     String linkcontrol = getStringValue("linkcontrol");
/*  211: 234 */     if (!UIUtil.isNull(linkcontrol))
/*  212:     */     {
/*  213: 236 */       ControlData otherData = controlManager.getControlData(linkcontrol);
/*  214: 237 */       if (otherData != null)
/*  215:     */       {
/*  216: 239 */         otherData = ((MobileUIControlData)otherData).cloneThis();
/*  217: 240 */         ControlData[] cData = this.controlAttributes.getChildControlData();
/*  218: 241 */         ControlData[] ocData = otherData.getChildControlData();
/*  219: 242 */         if ((cData == null) || (cData.length == 0))
/*  220:     */         {
/*  221: 244 */           ((MobileUIControlData)this.controlAttributes).setChildComponentData(ocData);
/*  222:     */         }
/*  223: 246 */         else if ((ocData != null) && (ocData.length > 0))
/*  224:     */         {
/*  225: 248 */           int length = (cData == null ? 0 : cData.length) + (ocData == null ? 0 : ocData.length);
/*  226: 249 */           ControlData[] newCData = new ControlData[length];
/*  227: 250 */           System.arraycopy(cData, 0, newCData, 0, cData.length);
/*  228: 251 */           System.arraycopy(ocData, 0, newCData, cData.length, ocData.length);
/*  229: 252 */           ((MobileUIControlData)this.controlAttributes).setChildComponentData(newCData);
/*  230:     */         }
/*  231: 256 */         ((MobileUIControlData)getControlData()).rebuildControlDataTree(getControlData(), new String[] { "datasrcname" });
/*  232:     */       }
/*  233: 258 */       ((MobileUIControlData)this.controlAttributes).putValue("linkcontrol", "");
/*  234:     */     }
/*  235: 260 */     createChildren(this.controlAttributes.getChildControlData());
/*  236: 261 */     return this.childControls;
/*  237:     */   }
/*  238:     */   
/*  239:     */   public void setControlData(ControlData controlAttributes)
/*  240:     */   {
/*  241: 266 */     this.id = controlAttributes.getValue("id");
/*  242: 267 */     this.displayEvent = controlAttributes.getValue("displayevent");
/*  243: 268 */     registerBean(controlAttributes.getValue("datasrcname"), false);
/*  244: 269 */     registerBean(controlAttributes.getValue("parentdatasrc"), false);
/*  245: 270 */     this.controlAttributes = controlAttributes;
/*  246: 271 */     if (!isUiTestMode())
/*  247:     */     {
/*  248: 272 */       this.useBarCode = ((UIUtil.getApplication().isBarcodeEnabled()) && (getBooleanValue("enablebarcode")));
/*  249: 273 */       this.useRFID = ((UIUtil.getApplication().isRFIDEnabled()) && (getBooleanValue("enablerfid")));
/*  250:     */     }
/*  251:     */   }
/*  252:     */   
/*  253:     */   public ControlData getControlData()
/*  254:     */   {
/*  255: 279 */     return this.controlAttributes;
/*  256:     */   }
/*  257:     */   
/*  258:     */   public int getIntValue(String attribute)
/*  259:     */   {
/*  260:     */     try
/*  261:     */     {
/*  262: 286 */       return Integer.valueOf(this.controlAttributes.getValue(attribute)).intValue();
/*  263:     */     }
/*  264:     */     catch (Exception ex) {}
/*  265: 289 */     return 0;
/*  266:     */   }
/*  267:     */   
/*  268:     */   public boolean isAttributeSet(String attribute)
/*  269:     */   {
/*  270: 294 */     String value = this.controlAttributes.getValue(attribute);
/*  271: 295 */     if (value == null) {
/*  272: 297 */       return false;
/*  273:     */     }
/*  274: 300 */     return true;
/*  275:     */   }
/*  276:     */   
/*  277:     */   public String getValue(String attribute)
/*  278:     */   {
/*  279: 305 */     return this.controlAttributes.getValue(attribute);
/*  280:     */   }
/*  281:     */   
/*  282:     */   public boolean getBooleanValue(String attribute)
/*  283:     */   {
/*  284: 310 */     String value = this.controlAttributes.getValue(attribute);
/*  285: 312 */     if (value == null) {
/*  286: 314 */       return false;
/*  287:     */     }
/*  288: 317 */     if (value.equalsIgnoreCase("true")) {
/*  289: 319 */       return true;
/*  290:     */     }
/*  291: 322 */     return false;
/*  292:     */   }
/*  293:     */   
/*  294:     */   public String getStringValue(String attribute)
/*  295:     */   {
/*  296: 327 */     String v = this.controlAttributes.getValue(attribute);
/*  297: 329 */     if ((this.imageAttributes.contains(attribute)) && (v != null)) {
/*  298: 330 */       v = MobileUIResources.getInstance().getImagePath(v);
/*  299:     */     }
/*  300: 333 */     return v;
/*  301:     */   }
/*  302:     */   
/*  303:     */   public Object getColorValue(String attribute)
/*  304:     */   {
/*  305: 340 */     String attributeValue = this.controlAttributes.getValue(attribute);
/*  306: 341 */     if (attributeValue == null) {
/*  307: 343 */       return null;
/*  308:     */     }
/*  309: 346 */     int red = Integer.parseInt(attributeValue.substring(1, 3), 16);
/*  310: 347 */     int green = Integer.parseInt(attributeValue.substring(3, 5), 16);
/*  311: 348 */     int blue = Integer.parseInt(attributeValue.substring(5, 7), 16);
/*  312:     */     
/*  313: 350 */     return getWidget().createColor(red, green, blue);
/*  314:     */   }
/*  315:     */   
/*  316:     */   protected void registerControl(AbstractMobileControl control)
/*  317:     */   {
/*  318: 355 */     if (getParentControl() != null) {
/*  319: 357 */       getParentControl().registerControl(control);
/*  320:     */     }
/*  321:     */   }
/*  322:     */   
/*  323:     */   public void addChildControl(AbstractMobileControl control)
/*  324:     */   {
/*  325: 363 */     if ((this.childControls == null) && (control != null)) {
/*  326: 364 */       this.childControls = new ArrayList();
/*  327:     */     }
/*  328: 366 */     if (this.childControls != null) {
/*  329: 367 */       this.childControls.add(control);
/*  330:     */     }
/*  331: 368 */     if (control != null) {
/*  332: 369 */       control.setParentControl(this);
/*  333:     */     }
/*  334: 370 */     registerControl(control);
/*  335:     */   }
/*  336:     */   
/*  337:     */   public Iterator getChildren()
/*  338:     */   {
/*  339: 375 */     if ((this.childControls != null) && (!this.childControls.isEmpty())) {
/*  340: 376 */       return this.childControls.iterator();
/*  341:     */     }
/*  342: 377 */     return null;
/*  343:     */   }
/*  344:     */   
/*  345:     */   public ArrayList composeChildren()
/*  346:     */     throws MobileApplicationException
/*  347:     */   {
/*  348: 391 */     if (hasChildren())
/*  349:     */     {
/*  350: 393 */       ArrayList childrenComps = new ArrayList();
/*  351: 394 */       Iterator i = getChildren();
/*  352: 396 */       while (i.hasNext())
/*  353:     */       {
/*  354: 399 */         AbstractMobileControl child = (AbstractMobileControl)i.next();
/*  355:     */         
/*  356:     */ 
/*  357: 402 */         UIComponent[] comps = child.composeComponents();
/*  358: 404 */         if (comps != null)
/*  359:     */         {
/*  360: 406 */           child.setComponents(comps);
/*  361: 407 */           childrenComps.add(comps);
/*  362:     */         }
/*  363:     */       }
/*  364: 412 */       return childrenComps;
/*  365:     */     }
/*  366: 414 */     return null;
/*  367:     */   }
/*  368:     */   
/*  369:     */   public AbstractMobileControl getParentControl()
/*  370:     */   {
/*  371: 422 */     return this.parentControl;
/*  372:     */   }
/*  373:     */   
/*  374:     */   public void setParentControl(AbstractMobileControl parentControl)
/*  375:     */   {
/*  376: 429 */     this.parentControl = parentControl;
/*  377:     */   }
/*  378:     */   
/*  379:     */   public boolean hasChildren()
/*  380:     */   {
/*  381: 434 */     return (this.childControls != null) && (!this.childControls.isEmpty());
/*  382:     */   }
/*  383:     */   
/*  384:     */   public UIComponent[] getComponents()
/*  385:     */   {
/*  386: 439 */     return this.components;
/*  387:     */   }
/*  388:     */   
/*  389:     */   protected void setComponentController(UIComponent component)
/*  390:     */   {
/*  391: 444 */     if ((component != null) && (component.getController() == null))
/*  392:     */     {
/*  393: 446 */       component.setController(this);
/*  394: 447 */       Enumeration e = component.getChildren();
/*  395: 448 */       if (e != null) {
/*  396: 450 */         while (e.hasMoreElements()) {
/*  397: 452 */           setComponentController((UIComponent)e.nextElement());
/*  398:     */         }
/*  399:     */       }
/*  400:     */     }
/*  401:     */   }
/*  402:     */   
/*  403:     */   public void sendDisplayEvent()
/*  404:     */   {
/*  405:     */     try
/*  406:     */     {
/*  407: 464 */       if (isAuthorizedToCompose())
/*  408:     */       {
/*  409: 466 */         setVisibility(true);
/*  410:     */       }
/*  411:     */       else
/*  412:     */       {
/*  413: 468 */         setVisibility(false);
/*  414: 469 */         return;
/*  415:     */       }
/*  416:     */     }
/*  417:     */     catch (MobileApplicationException e) {}
/*  418: 477 */     if (this.displayEvent != null) {
/*  419: 480 */       handleEvent(this.displayEvent, null, null);
/*  420:     */     }
/*  421:     */   }
/*  422:     */   
/*  423:     */   public void setComponents(UIComponent[] comps)
/*  424:     */   {
/*  425: 486 */     this.components = comps;
/*  426: 487 */     if (comps == null) {
/*  427: 488 */       return;
/*  428:     */     }
/*  429: 490 */     sendDisplayEvent();
/*  430: 491 */     for (int i = 0; i < this.components.length; i++) {
/*  431: 493 */       if (this.components[i].getController() == null)
/*  432:     */       {
/*  433: 495 */         getWidget().setUIComponentVisible(this.components[i], isVisible());
/*  434: 496 */         setComponentController(this.components[i]);
/*  435:     */       }
/*  436:     */     }
/*  437:     */   }
/*  438:     */   
/*  439:     */   public String getId()
/*  440:     */   {
/*  441: 506 */     if (this.id == null) {
/*  442: 507 */       this.id = getStringValue("id");
/*  443:     */     }
/*  444: 508 */     return this.id;
/*  445:     */   }
/*  446:     */   
/*  447:     */   public boolean validateControl(UIEvent origEvent, Object value)
/*  448:     */   {
/*  449: 524 */     String validate = getStringValue("validateevent");
/*  450: 525 */     if (validate != null)
/*  451:     */     {
/*  452: 527 */       UIEvent event = null;
/*  453: 528 */       if ((origEvent != null) && (origEvent.getInitialEvent() != null)) {
/*  454: 532 */         event = origEvent.getInitialEvent();
/*  455:     */       } else {
/*  456: 535 */         event = new UIEvent(this, validate, null, value);
/*  457:     */       }
/*  458: 536 */       event.setInitialEvent(origEvent);
/*  459: 537 */       handleEvent(event);
/*  460: 538 */       return !event.errorOccured();
/*  461:     */     }
/*  462: 540 */     return true;
/*  463:     */   }
/*  464:     */   
/*  465:     */   public boolean validateControl()
/*  466:     */   {
/*  467: 552 */     return validateControl(UIUtil.getApplication().getUserEvent(), null);
/*  468:     */   }
/*  469:     */   
/*  470:     */   public boolean callControlHandler(UIEvent event)
/*  471:     */     throws MobileApplicationException
/*  472:     */   {
/*  473: 557 */     String handlerName = getValue("handler");
/*  474: 559 */     if (handlerName != null)
/*  475:     */     {
/*  476: 561 */       UIHandlerManager hMan = UIHandlerManager.getInstance();
/*  477: 562 */       UIEventHandler handler = hMan.getUIHandler(handlerName);
/*  478: 563 */       if (handler != null) {
/*  479: 565 */         return handler.performEvent(event);
/*  480:     */       }
/*  481:     */     }
/*  482: 568 */     return false;
/*  483:     */   }
/*  484:     */   
/*  485:     */   public boolean sendEventUp(UIEvent event)
/*  486:     */     throws MobileApplicationException
/*  487:     */   {
/*  488: 574 */     boolean ret = false;
/*  489: 575 */     AbstractMobileControl parent = getParentControl();
/*  490: 577 */     if (parent == null)
/*  491:     */     {
/*  492: 579 */       MobileDeviceAppSession session = MobileDeviceAppSession.getSession();
/*  493: 580 */       UIEventHandler appHandler = session.getUIEventHandler();
/*  494: 582 */       if (appHandler != null) {
/*  495: 583 */         ret = appHandler.performEvent(event);
/*  496:     */       }
/*  497:     */     }
/*  498:     */     else
/*  499:     */     {
/*  500: 587 */       if ((parent instanceof InputControl)) {
/*  501: 589 */         ((PageControl)this.app.getCurrentScreen()).setCurrentInput(parent);
/*  502:     */       }
/*  503: 592 */       ret = parent.processEvent(event);
/*  504: 594 */       if (!ret) {
/*  505: 596 */         ret = parent.sendEventUp(event);
/*  506:     */       }
/*  507:     */     }
/*  508: 599 */     return ret;
/*  509:     */   }
/*  510:     */   
/*  511:     */   public boolean sendEventDown(UIEvent event)
/*  512:     */     throws MobileApplicationException
/*  513:     */   {
/*  514: 604 */     boolean ret = false;
/*  515: 605 */     if (hasChildren())
/*  516:     */     {
/*  517: 607 */       Iterator i = getChildren();
/*  518: 608 */       while ((i.hasNext()) && (!ret))
/*  519:     */       {
/*  520: 610 */         AbstractMobileControl child = (AbstractMobileControl)i.next();
/*  521: 611 */         ret = child.processEvent(event);
/*  522: 612 */         if (!ret) {
/*  523: 614 */           ret = child.sendEventDown(event);
/*  524:     */         }
/*  525:     */       }
/*  526:     */     }
/*  527: 618 */     return ret;
/*  528:     */   }
/*  529:     */   
/*  530:     */   public boolean processEvent(UIEvent event)
/*  531:     */     throws MobileApplicationException
/*  532:     */   {
/*  533: 623 */     boolean ret = callControlHandler(event);
/*  534: 624 */     if (!ret) {
/*  535: 626 */       ret = performEvent(event);
/*  536:     */     }
/*  537: 628 */     return ret;
/*  538:     */   }
/*  539:     */   
/*  540:     */   public boolean handleEvent(String eventType, String targetID, Object value)
/*  541:     */   {
/*  542: 633 */     return handleEvent(new UIEvent(this, eventType, targetID, value));
/*  543:     */   }
/*  544:     */   
/*  545:     */   public boolean handleEvent(UIEvent event)
/*  546:     */   {
/*  547: 640 */     if (event == null) {
/*  548: 641 */       return true;
/*  549:     */     }
/*  550: 643 */     if ((!isUiTestMode()) && 
/*  551: 644 */       (this.app.getUserEvent() == null))
/*  552:     */     {
/*  553: 646 */       this.app.showWait();
/*  554: 647 */       this.app.setUserEvent(event);
/*  555: 649 */       if ((event.getCreatingObject() == this) && (isAttributeSet("event")))
/*  556:     */       {
/*  557: 653 */         String eventAttrValue = getStringValue("event");
/*  558: 655 */         if (eventAttrValue.equals(event.getEventName()))
/*  559:     */         {
/*  560: 659 */           String eSigOption = getStringValue("sigoption");
/*  561: 660 */           boolean ignoreEsig = getBooleanValue("noesig");
/*  562: 662 */           if ((eSigOption != null) && (!ignoreEsig)) {
/*  563:     */             try
/*  564:     */             {
/*  565: 666 */               MobileMboDataBean dataBean = getDataBean();
/*  566: 667 */               if (!UIUtil.checkESignature(event, dataBean, eSigOption))
/*  567:     */               {
/*  568: 669 */                 UIUtil.getApplication().removeUserEvent(event);
/*  569: 670 */                 event.setEventErrored();
/*  570: 671 */                 return true;
/*  571:     */               }
/*  572:     */             }
/*  573:     */             catch (MobileApplicationException e) {}
/*  574:     */           }
/*  575:     */         }
/*  576:     */       }
/*  577:     */     }
/*  578: 684 */     boolean ret = false;
/*  579:     */     try
/*  580:     */     {
/*  581: 689 */       if ((event.getTargetID() != null) && (!event.getTargetID().equals(getId()))) {
/*  582: 691 */         return UIUtil.sendEvent(event);
/*  583:     */       }
/*  584: 694 */       ret = processEvent(event);
/*  585: 696 */       if (!ret)
/*  586:     */       {
/*  587: 698 */         ret = sendEventUp(event);
/*  588: 700 */         if (!ret) {
/*  589: 701 */           ret = sendEventDown(event);
/*  590:     */         }
/*  591:     */       }
/*  592: 705 */       if (!isUiTestMode()) {
/*  593: 707 */         UIUtil.getApplication().removeUserEvent(event);
/*  594:     */       }
/*  595: 709 */       return ret;
/*  596:     */     }
/*  597:     */     catch (MobileApplicationException e)
/*  598:     */     {
/*  599: 713 */       ret = true;
/*  600: 714 */       event.setEventErrored();
/*  601: 715 */       if (!handleException(event, e))
/*  602:     */       {
/*  603: 717 */         AbstractMobileControl callingCtrl = (AbstractMobileControl)event.getCreatingObject();
/*  604: 718 */         if ((callingCtrl != null) && (callingCtrl != this)) {
/*  605: 720 */           if (callingCtrl.handleException(event, e))
/*  606:     */           {
/*  607: 722 */             UIUtil.getApplication().removeUserEvent(event);
/*  608: 723 */             return ret;
/*  609:     */           }
/*  610:     */         }
/*  611: 726 */         UIUtil.showExceptionMessage(e, event, 0);
/*  612:     */       }
/*  613: 729 */       UIUtil.getApplication().removeUserEvent(event);
/*  614:     */     }
/*  615: 730 */     return ret;
/*  616:     */   }
/*  617:     */   
/*  618:     */   public String inheritControlAttribute(String attribute, String defaultValue)
/*  619:     */   {
/*  620: 786 */     String val = inheritControlAttribute(attribute);
/*  621: 787 */     if (val == null) {
/*  622: 788 */       val = defaultValue;
/*  623:     */     }
/*  624: 789 */     return val;
/*  625:     */   }
/*  626:     */   
/*  627:     */   public String inheritControlAttribute(String attribute)
/*  628:     */   {
/*  629: 803 */     String val = getStringValue(attribute);
/*  630: 804 */     if ((val == null) && (this.parentControl != null))
/*  631:     */     {
/*  632: 806 */       val = this.parentControl.inheritControlAttribute(attribute);
/*  633: 807 */       if (val != null) {
/*  634: 808 */         this.controlAttributes.putValue(attribute, val);
/*  635:     */       }
/*  636:     */     }
/*  637: 810 */     return val;
/*  638:     */   }
/*  639:     */   
/*  640:     */   public AbstractMobileControl includeControl(String controlId)
/*  641:     */     throws MobileApplicationException
/*  642:     */   {
/*  643: 815 */     UIControlManager controlManager = UIControlManager.getInstance();
/*  644: 816 */     ControlData controlData = controlManager.getControlData(controlId);
/*  645: 817 */     if (controlData != null)
/*  646:     */     {
/*  647: 819 */       controlData = ((MobileUIControlData)controlData).cloneThis();
/*  648: 820 */       controlData.putValue("id", getId() + controlId);
/*  649: 821 */       String controlType = controlData.getName();
/*  650: 822 */       ControlComposer cc = controlManager.getControlComposer(controlType);
/*  651: 823 */       if (cc != null) {
/*  652: 825 */         if ((cc instanceof AbstractMobileControl))
/*  653:     */         {
/*  654: 827 */           AbstractMobileControl control = ((AbstractMobileControl)cc).createControl(controlData);
/*  655: 828 */           if (control != null)
/*  656:     */           {
/*  657: 830 */             control.setControlData(controlData);
/*  658: 831 */             addChildControl(control);
/*  659: 832 */             control.createChildren();
/*  660:     */           }
/*  661: 834 */           return control;
/*  662:     */         }
/*  663:     */       }
/*  664:     */     }
/*  665: 838 */     return null;
/*  666:     */   }
/*  667:     */   
/*  668:     */   public void setToolBar(AbstractMobileControl toolBar)
/*  669:     */   {
/*  670: 856 */     if (this.parentControl != null) {
/*  671: 857 */       this.parentControl.setToolBar(toolBar == null ? this.myToolBar : toolBar);
/*  672:     */     }
/*  673:     */   }
/*  674:     */   
/*  675:     */   public void addToolbar()
/*  676:     */     throws MobileApplicationException
/*  677:     */   {
/*  678: 862 */     addToolbar(getStringValue("toolbar"));
/*  679:     */   }
/*  680:     */   
/*  681:     */   public void addToolbar(String toolBarId)
/*  682:     */     throws MobileApplicationException
/*  683:     */   {
/*  684: 867 */     if (toolBarId == null) {
/*  685: 868 */       return;
/*  686:     */     }
/*  687: 874 */     UIControlManager controlManager = UIControlManager.getInstance();
/*  688: 875 */     MobileUIControlData controlData = (MobileUIControlData)controlManager.getControlData(toolBarId);
/*  689: 876 */     if (controlData != null)
/*  690:     */     {
/*  691: 878 */       controlData = controlData.cloneThis();
/*  692: 879 */       controlData.putValue("id", getId() + toolBarId);
/*  693: 880 */       String controlType = controlData.getName();
/*  694: 881 */       ControlComposer cc = controlManager.getControlComposer(controlType);
/*  695: 882 */       if (cc != null) {
/*  696: 884 */         if ((cc instanceof AbstractMobileControl))
/*  697:     */         {
/*  698: 886 */           this.myToolBar = ((AbstractMobileControl)cc).createControl(controlData);
/*  699: 887 */           if (this.myToolBar != null)
/*  700:     */           {
/*  701: 889 */             this.myToolBar.setControlData(controlData);
/*  702: 890 */             this.myToolBar.createChildren();
/*  703:     */           }
/*  704:     */         }
/*  705:     */       }
/*  706:     */     }
/*  707: 896 */     if (this.myToolBar != null)
/*  708:     */     {
/*  709: 897 */       this.myToolBar.setParentControl(this);
/*  710: 898 */       this.myToolBar.setComponents(this.myToolBar.composeComponents());
/*  711: 899 */       setToolBar(this.myToolBar);
/*  712:     */     }
/*  713:     */   }
/*  714:     */   
/*  715:     */   public void addMenubar()
/*  716:     */     throws MobileApplicationException
/*  717:     */   {
/*  718: 905 */     addMenubar(getStringValue("menubar"));
/*  719:     */   }
/*  720:     */   
/*  721:     */   public void addMenubar(String menuBarId)
/*  722:     */     throws MobileApplicationException
/*  723:     */   {
/*  724: 910 */     if (menuBarId != null)
/*  725:     */     {
/*  726: 912 */       UIControlManager controlManager = UIControlManager.getInstance();
/*  727: 913 */       MobileUIControlData controlData = (MobileUIControlData)controlManager.getControlData(menuBarId);
/*  728: 914 */       if (controlData != null)
/*  729:     */       {
/*  730: 916 */         controlData = controlData.cloneThis();
/*  731: 917 */         controlData.putValue("id", getId() + menuBarId);
/*  732: 918 */         String controlType = controlData.getName();
/*  733: 919 */         ControlComposer cc = controlManager.getControlComposer(controlType);
/*  734: 920 */         if (cc != null) {
/*  735: 922 */           if ((cc instanceof AbstractMobileControl))
/*  736:     */           {
/*  737: 924 */             this.menuBar = ((AbstractMobileControl)cc).createControl(controlData);
/*  738: 925 */             if (this.menuBar != null)
/*  739:     */             {
/*  740: 927 */               this.menuBar.setControlData(controlData);
/*  741: 928 */               this.menuBar.createChildren();
/*  742:     */             }
/*  743:     */           }
/*  744:     */         }
/*  745:     */       }
/*  746: 933 */       if (this.menuBar != null)
/*  747:     */       {
/*  748: 934 */         this.menuBar.setParentControl(this);
/*  749: 935 */         this.menuBar.setComponents(this.menuBar.composeComponents());
/*  750:     */       }
/*  751:     */     }
/*  752:     */   }
/*  753:     */   
/*  754:     */   public MobileMboDataBean getDataBean()
/*  755:     */     throws MobileApplicationException
/*  756:     */   {
/*  757: 942 */     MobileMboDataBean dataBean = null;
/*  758: 943 */     String dataSrc = inheritControlAttribute("datasrcname");
/*  759: 944 */     dataBean = DataBeanCache.findDataBean(dataSrc);
/*  760: 945 */     if (dataBean == null)
/*  761:     */     {
/*  762: 947 */       String mobileMboName = getValue("mobilembo");
/*  763: 948 */       if (mobileMboName != null)
/*  764:     */       {
/*  765: 950 */         String parentDataSrc = getValue("parentdatasrc");
/*  766: 951 */         if (parentDataSrc != null)
/*  767:     */         {
/*  768: 953 */           MobileMboDataBean parentDataBean = DataBeanCache.findDataBean(parentDataSrc);
/*  769: 954 */           if (parentDataBean != null)
/*  770:     */           {
/*  771: 956 */             MobileMboDataBean dependentDataBean = parentDataBean.getDataBean(mobileMboName);
/*  772: 957 */             if (dependentDataBean != null)
/*  773:     */             {
/*  774: 959 */               DataBeanCacheItem item = new DataBeanCacheItem(dataSrc, parentDataSrc, mobileMboName, dependentDataBean);
/*  775: 960 */               DataBeanCache.cacheDataBean(dataSrc, item);
/*  776:     */             }
/*  777: 963 */             dataBean = dependentDataBean;
/*  778:     */           }
/*  779:     */           else
/*  780:     */           {
/*  781: 967 */             return null;
/*  782:     */           }
/*  783:     */         }
/*  784:     */         else
/*  785:     */         {
/*  786: 972 */           MobileMboDataBeanManager mgr = new MobileMboDataBeanManager(mobileMboName);
/*  787: 973 */           MobileMboDataBean bean = mgr.getDataBean();
/*  788:     */           
/*  789: 975 */           DataBeanCacheItem item = new DataBeanCacheItem(dataSrc, mobileMboName, bean);
/*  790: 976 */           DataBeanCache.cacheDataBean(dataSrc, item);
/*  791:     */           
/*  792: 978 */           dataBean = bean;
/*  793:     */         }
/*  794:     */       }
/*  795: 981 */       else if (getParentControl() != null)
/*  796:     */       {
/*  797: 983 */         dataBean = getParentControl().getDataBean();
/*  798:     */       }
/*  799: 985 */       registerBean(dataSrc, true);
/*  800:     */     }
/*  801:     */     else
/*  802:     */     {
/*  803: 988 */       registerBean(dataSrc, false);
/*  804:     */     }
/*  805: 989 */     return dataBean;
/*  806:     */   }
/*  807:     */   
/*  808:     */   public void refresh(UIEvent clientEvent)
/*  809:     */     throws MobileApplicationException
/*  810:     */   {
/*  811:1003 */     sendDisplayEvent();
/*  812:1006 */     if (isValidThreadToRefresh())
/*  813:     */     {
/*  814:1012 */       boolean refreshControlFlag = false;
/*  815:1013 */       if (((this instanceof PageControl)) && (!UIUtil.getCurrentScreen().equals(this))) {
/*  816:1015 */         refreshControlFlag = ((PageControl)this).forceRefreshControl(clientEvent);
/*  817:     */       } else {
/*  818:1019 */         refreshControlFlag = refreshControl(clientEvent);
/*  819:     */       }
/*  820:1022 */       if ((refreshControlFlag) && (hasChildren()))
/*  821:     */       {
/*  822:1025 */         Iterator i = getChildren();
/*  823:1028 */         while (i.hasNext())
/*  824:     */         {
/*  825:1030 */           AbstractMobileControl child = (AbstractMobileControl)i.next();
/*  826:1031 */           child.refresh(clientEvent);
/*  827:     */         }
/*  828:     */       }
/*  829:     */     }
/*  830:     */   }
/*  831:     */   
/*  832:     */   private boolean isValidThreadToRefresh()
/*  833:     */   {
/*  834:1040 */     return UIUtil.getApplication().isValidThreadToRefresh(Thread.currentThread());
/*  835:     */   }
/*  836:     */   
/*  837:     */   public String getLabel()
/*  838:     */     throws MobileApplicationException
/*  839:     */   {
/*  840:1047 */     return generateLabel(getStringValue("label"), getStringValue("labelattribute"), getStringValue("labeldatasrc"));
/*  841:     */   }
/*  842:     */   
/*  843:     */   public String generateLabel(String label, String labelAttributes, String labelDataSrc)
/*  844:     */     throws MobileApplicationException
/*  845:     */   {
/*  846:1058 */     MobileMboDataBean mmb = null;
/*  847:1059 */     if (labelDataSrc != null) {
/*  848:1060 */       mmb = DataBeanCache.findDataBean(labelDataSrc);
/*  849:     */     }
/*  850:1061 */     if (mmb == null) {
/*  851:1062 */       mmb = getDataBean();
/*  852:     */     }
/*  853:1063 */     boolean isLabelPresent = false;
/*  854:1064 */     if (label == null)
/*  855:     */     {
/*  856:1066 */       label = getStringValue("messagekey");
/*  857:1067 */       if (label == null) {
/*  858:1069 */         return label;
/*  859:     */       }
/*  860:     */     }
/*  861:     */     else
/*  862:     */     {
/*  863:1072 */       isLabelPresent = true;
/*  864:     */     }
/*  865:1074 */     if (labelAttributes == null) {
/*  866:1075 */       return label;
/*  867:     */     }
/*  868:1077 */     StringTokenizer stok = new StringTokenizer(labelAttributes, ",");
/*  869:1078 */     ArrayList arrList = new ArrayList();
/*  870:1079 */     while (stok.hasMoreElements())
/*  871:     */     {
/*  872:1080 */       String lblEle = stok.nextElement().toString();
/*  873:1081 */       if (lblEle.equals("recordcount"))
/*  874:     */       {
/*  875:1083 */         if (!getTableDataCount(arrList)) {
/*  876:1085 */           if (mmb != null) {
/*  877:1087 */             arrList.add(new Integer(getDataBean().count()));
/*  878:     */           }
/*  879:     */         }
/*  880:     */       }
/*  881:1091 */       else if (lblEle.equals("recordset"))
/*  882:     */       {
/*  883:1093 */         getTableDetails(arrList);
/*  884:     */       }
/*  885:1095 */       else if (lblEle.equals("pagelabel"))
/*  886:     */       {
/*  887:1097 */         String lbl = getPage().getLabel();
/*  888:1098 */         arrList.add(lbl == null ? "" : lbl);
/*  889:     */       }
/*  890:1100 */       else if (lblEle.equals("pagetitle"))
/*  891:     */       {
/*  892:1102 */         String ttl = getPage().getTitle();
/*  893:1103 */         arrList.add(ttl == null ? "" : ttl);
/*  894:     */       }
/*  895:1105 */       else if (lblEle.equals("lastrefreshall"))
/*  896:     */       {
/*  897:1107 */         Date date = this.app.getRelatedListDownloadTime();
/*  898:1109 */         if (date != null) {
/*  899:1111 */           arrList.add(DefaultMobileMboDataFormatter.dateTimeToString(date));
/*  900:     */         } else {
/*  901:1114 */           arrList.add("");
/*  902:     */         }
/*  903:     */       }
/*  904:1116 */       else if (lblEle.equals("lastrefresh"))
/*  905:     */       {
/*  906:1118 */         Date date = this.app.getWorkListDownloadTime();
/*  907:1120 */         if (date != null) {
/*  908:1122 */           arrList.add(DefaultMobileMboDataFormatter.dateTimeToString(date));
/*  909:     */         } else {
/*  910:1125 */           arrList.add("");
/*  911:     */         }
/*  912:     */       }
/*  913:1127 */       else if (lblEle.equals("lastupload"))
/*  914:     */       {
/*  915:1129 */         Date date = this.app.getLastCommunicationTime();
/*  916:1131 */         if (date != null) {
/*  917:1133 */           arrList.add(DefaultMobileMboDataFormatter.dateTimeToString(date));
/*  918:     */         } else {
/*  919:1136 */           arrList.add("");
/*  920:     */         }
/*  921:     */       }
/*  922:1138 */       else if (lblEle.equals("lastrelatedrefresh"))
/*  923:     */       {
/*  924:1140 */         Date date = this.app.getRelatedListDownloadTime();
/*  925:1142 */         if (date != null) {
/*  926:1144 */           arrList.add(DefaultMobileMboDataFormatter.dateTimeToString(date));
/*  927:     */         } else {
/*  928:1147 */           arrList.add("");
/*  929:     */         }
/*  930:     */       }
/*  931:1149 */       else if (lblEle.equals("pendingcount"))
/*  932:     */       {
/*  933:1151 */         arrList.add(this.app.getQueuedMessageCount() + "");
/*  934:     */       }
/*  935:1153 */       else if (lblEle.equals("errorcount"))
/*  936:     */       {
/*  937:1155 */         if (mmb != null) {
/*  938:1157 */           arrList.add(new Integer(getDataBean().getErrorCount()));
/*  939:     */         } else {
/*  940:1160 */           arrList.add("0");
/*  941:     */         }
/*  942:     */       }
/*  943:1162 */       else if (lblEle.equals("modifiedcount"))
/*  944:     */       {
/*  945:1164 */         if (mmb != null)
/*  946:     */         {
/*  947:1166 */           int count = mmb.getModifiedCount();
/*  948:1167 */           arrList.add(count + "");
/*  949:     */         }
/*  950:     */         else
/*  951:     */         {
/*  952:1170 */           arrList.add("0");
/*  953:     */         }
/*  954:     */       }
/*  955:     */       else
/*  956:     */       {
/*  957:1175 */         arrList.add(mmb.getValue(lblEle));
/*  958:     */       }
/*  959:     */     }
/*  960:1178 */     StringBuffer buf = new StringBuffer();
/*  961:1179 */     if (isLabelPresent) {
/*  962:1181 */       buf.append(MobileMessageGenerator.generateDirectMessage(label, arrList.toArray()));
/*  963:     */     } else {
/*  964:1184 */       buf.append(MobileMessageGenerator.generate(label, arrList.toArray()));
/*  965:     */     }
/*  966:1187 */     return (buf.length() == 0) && (!label.trim().equals("{0}")) ? label : buf.toString();
/*  967:     */   }
/*  968:     */   
/*  969:     */   public AbstractMobileControl getPageGroup()
/*  970:     */   {
/*  971:1198 */     AbstractMobileControl pageGroup = getParentControl();
/*  972:1199 */     while ((!(pageGroup instanceof PageGroupControl)) && (pageGroup != null)) {
/*  973:1201 */       pageGroup = pageGroup.getParentControl();
/*  974:     */     }
/*  975:1203 */     if ((pageGroup instanceof PageGroupControl)) {
/*  976:1205 */       return pageGroup;
/*  977:     */     }
/*  978:1207 */     return null;
/*  979:     */   }
/*  980:     */   
/*  981:     */   public boolean isSigOptionAuth(String event)
/*  982:     */     throws MobileApplicationException
/*  983:     */   {
/*  984:1220 */     MobileMboDataBean mdb = getDataBean();
/*  985:1221 */     if (mdb != null) {
/*  986:1223 */       return mdb.isOptionAuthorized(event);
/*  987:     */     }
/*  988:1225 */     BasicMobileDeviceUIApplication app = UIUtil.getApplication();
/*  989:1226 */     return app.isOptionAuthorized(event);
/*  990:     */   }
/*  991:     */   
/*  992:     */   public boolean isAuthorizedToCompose()
/*  993:     */     throws MobileApplicationException
/*  994:     */   {
/*  995:1238 */     String event = getStringValue("sigoption");
/*  996:1240 */     if ((event == null) || (event.equals(""))) {
/*  997:1242 */       return true;
/*  998:     */     }
/*  999:1244 */     return isSigOptionAuth(getStringValue("sigoption"));
/* 1000:     */   }
/* 1001:     */   
/* 1002:     */   public boolean isInitalized()
/* 1003:     */   {
/* 1004:1254 */     return this.initalized;
/* 1005:     */   }
/* 1006:     */   
/* 1007:     */   public String getTitle()
/* 1008:     */     throws MobileApplicationException
/* 1009:     */   {
/* 1010:1265 */     String title = getStringValue("title");
/* 1011:1266 */     if (title == null) {
/* 1012:1268 */       title = getLabel();
/* 1013:     */     } else {
/* 1014:1272 */       title = generateLabel(title, getStringValue("titleattribute"), getStringValue("titledatasrc"));
/* 1015:     */     }
/* 1016:1275 */     return title;
/* 1017:     */   }
/* 1018:     */   
/* 1019:     */   public boolean getTableDataCount(ArrayList arrObj)
/* 1020:     */     throws MobileApplicationException
/* 1021:     */   {
/* 1022:1281 */     AbstractMobileControl subControl = getParentControl();
/* 1023:1282 */     while ((!(subControl instanceof TableControl)) && (subControl != null)) {
/* 1024:1284 */       subControl = subControl.getParentControl();
/* 1025:     */     }
/* 1026:1286 */     if ((subControl instanceof TableControl))
/* 1027:     */     {
/* 1028:1288 */       arrObj.add(new Integer(((TableControl)subControl).getDataBean().count()));
/* 1029:1289 */       return true;
/* 1030:     */     }
/* 1031:1291 */     return false;
/* 1032:     */   }
/* 1033:     */   
/* 1034:     */   public Object[] getTableDetails(ArrayList arrObj)
/* 1035:     */   {
/* 1036:1296 */     AbstractMobileControl tableControl = getParentControl();
/* 1037:1297 */     while ((!(tableControl instanceof TableControl)) && (tableControl != null)) {
/* 1038:1299 */       tableControl = tableControl.getParentControl();
/* 1039:     */     }
/* 1040:1301 */     if ((tableControl instanceof TableControl)) {
/* 1041:1303 */       arrObj.add(((TableControl)tableControl).getCurFirstRow() + "-" + ((TableControl)tableControl).getCurLastRow());
/* 1042:     */     }
/* 1043:1305 */     return null;
/* 1044:     */   }
/* 1045:     */   
/* 1046:     */   public void setReadonly(boolean readonly)
/* 1047:     */   {
/* 1048:1314 */     this.readonly = (readonly ? 1 : 0);
/* 1049:     */   }
/* 1050:     */   
/* 1051:     */   public void setRequired(boolean required)
/* 1052:     */   {
/* 1053:1322 */     this.required = (required ? 1 : 0);
/* 1054:     */   }
/* 1055:     */   
/* 1056:     */   public boolean isVisible()
/* 1057:     */   {
/* 1058:1332 */     return this.visible;
/* 1059:     */   }
/* 1060:     */   
/* 1061:     */   public void setVisibility(boolean visibility)
/* 1062:     */   {
/* 1063:1342 */     this.visible = visibility;
/* 1064:1343 */     UIComponent[] components = getComponents();
/* 1065:1344 */     if (components != null) {
/* 1066:1346 */       for (int i = 0; i < components.length; i++) {
/* 1067:1348 */         getWidget().setUIComponentVisible(components[i], visibility);
/* 1068:     */       }
/* 1069:     */     }
/* 1070:     */   }
/* 1071:     */   
/* 1072:     */   public AbstractMobileControl getToolBar()
/* 1073:     */   {
/* 1074:1359 */     return this.myToolBar;
/* 1075:     */   }
/* 1076:     */   
/* 1077:     */   public boolean rfidEnabled()
/* 1078:     */   {
/* 1079:1365 */     return this.useRFID;
/* 1080:     */   }
/* 1081:     */   
/* 1082:     */   public boolean barCodingEnabled()
/* 1083:     */   {
/* 1084:1370 */     return this.useBarCode;
/* 1085:     */   }
/* 1086:     */   
/* 1087:     */   public boolean checkRequiredFields()
/* 1088:     */   {
/* 1089:1380 */     UIEvent event = new UIEvent(this, "requiredcheck", null, null);
/* 1090:     */     try
/* 1091:     */     {
/* 1092:1383 */       sendEventDown(event);
/* 1093:     */     }
/* 1094:     */     catch (MobileApplicationException e)
/* 1095:     */     {
/* 1096:1387 */       UIUtil.showExceptionMessage(e, event, 0);
/* 1097:1388 */       return false;
/* 1098:     */     }
/* 1099:1390 */     return true;
/* 1100:     */   }
/* 1101:     */   
/* 1102:     */   public void registerBean(String bean, boolean created)
/* 1103:     */   {
/* 1104:1395 */     if ((bean != null) && (this.parentControl != null)) {
/* 1105:1396 */       this.parentControl.registerBean(bean, created);
/* 1106:     */     }
/* 1107:     */   }
/* 1108:     */   
/* 1109:     */   public boolean sendInitEvent()
/* 1110:     */     throws MobileApplicationException
/* 1111:     */   {
/* 1112:1401 */     String initEvent = getStringValue("initevent");
/* 1113:1402 */     if (initEvent != null)
/* 1114:     */     {
/* 1115:1404 */       UIEvent event = new UIEvent(this, initEvent, null, null);
/* 1116:1405 */       handleEvent(event);
/* 1117:1406 */       return !event.errorOccured();
/* 1118:     */     }
/* 1119:1408 */     return true;
/* 1120:     */   }
/* 1121:     */   
/* 1122:     */   public boolean sendRefreshEvent()
/* 1123:     */     throws MobileApplicationException
/* 1124:     */   {
/* 1125:1413 */     String refreshEvent = getStringValue("refreshevent");
/* 1126:1414 */     if (refreshEvent != null)
/* 1127:     */     {
/* 1128:1416 */       UIEvent event = new UIEvent(this, refreshEvent, null, null);
/* 1129:1417 */       handleEvent(event);
/* 1130:1418 */       return !event.errorOccured();
/* 1131:     */     }
/* 1132:1420 */     return true;
/* 1133:     */   }
/* 1134:     */   
/* 1135:     */   public AbstractMobileControl getMenuBar()
/* 1136:     */   {
/* 1137:1428 */     return this.menuBar;
/* 1138:     */   }
/* 1139:     */   
/* 1140:     */   public AbstractMobileControl getPage()
/* 1141:     */   {
/* 1142:1433 */     if (this.parentControl != null) {
/* 1143:1435 */       return this.parentControl.getPage();
/* 1144:     */     }
/* 1145:1437 */     return null;
/* 1146:     */   }
/* 1147:     */   
/* 1148:     */   public void setScrollableSection(boolean scrollableSection)
/* 1149:     */   {
/* 1150:1445 */     if (getParentControl() != null) {
/* 1151:1446 */       getParentControl().setScrollableSection(scrollableSection);
/* 1152:     */     }
/* 1153:     */   }
/* 1154:     */   
/* 1155:     */   public ControlStyle getStyle(String key, String componentKey)
/* 1156:     */   {
/* 1157:1451 */     if ((key != null) || (componentKey != null))
/* 1158:     */     {
/* 1159:1453 */       String realKey = (key == null ? "" : new StringBuilder().append(key).append(".").toString()) + this.controlAttributes.getName() + (componentKey == null ? "" : new StringBuilder().append(".").append(componentKey).toString());
/* 1160:1454 */       String prop = null;
/* 1161:1455 */       if (key != null) {
/* 1162:1456 */         prop = key.substring(key.lastIndexOf('.') + 1) + "style";
/* 1163:     */       } else {
/* 1164:1458 */         prop = componentKey.substring(componentKey.lastIndexOf('.') + 1) + "style";
/* 1165:     */       }
/* 1166:1459 */       String override = getStringValue(prop);
/* 1167:1460 */       if (override == null) {
/* 1168:1461 */         override = inheritControlAttribute("styleoverride");
/* 1169:     */       }
/* 1170:1462 */       return StyleManager.getStyle(realKey, override);
/* 1171:     */     }
/* 1172:1464 */     return StyleManager.getDefaultStyle();
/* 1173:     */   }
/* 1174:     */   
/* 1175:     */   public ControlStyle getStyle(String componentKey)
/* 1176:     */   {
/* 1177:1469 */     return getStyle(null, componentKey);
/* 1178:     */   }
/* 1179:     */   
/* 1180:     */   public int getCharBasedSized(int dataSize)
/* 1181:     */   {
/* 1182:1474 */     String rangeVals = null;
/* 1183:1475 */     if (!isUiTestMode()) {
/* 1184:1476 */       rangeVals = (String)MobileUIProperties.getValue(this.controlAttributes.getName() + ".sizerange", false);
/* 1185:     */     }
/* 1186:1478 */     if (rangeVals != null)
/* 1187:     */     {
/* 1188:1480 */       StringTokenizer ranges = new StringTokenizer(rangeVals, ";");
/* 1189:1481 */       int lower = 0;
/* 1190:1482 */       int upper = 0;
/* 1191:1483 */       while (ranges.hasMoreTokens())
/* 1192:     */       {
/* 1193:1485 */         String setting = ranges.nextToken();
/* 1194:1486 */         int index = setting.indexOf(":");
/* 1195:1487 */         if (index > 0)
/* 1196:     */         {
/* 1197:1489 */           String range = setting.substring(0, index);
/* 1198:1490 */           String size = setting.substring(index + 1);
/* 1199:1491 */           int sizeToUse = dataSize;
/* 1200:1492 */           if (!size.equals("*")) {
/* 1201:1493 */             sizeToUse = Integer.parseInt(size);
/* 1202:     */           }
/* 1203:1495 */           if (range.endsWith("+"))
/* 1204:     */           {
/* 1205:1497 */             lower = Integer.parseInt(range.substring(0, range.length() - 1));
/* 1206:1498 */             upper = Math.max(lower, dataSize);
/* 1207:     */           }
/* 1208:     */           else
/* 1209:     */           {
/* 1210:1502 */             index = range.indexOf("-");
/* 1211:1503 */             if (index > 0)
/* 1212:     */             {
/* 1213:1505 */               lower = Integer.parseInt(range.substring(0, index));
/* 1214:1506 */               upper = Integer.parseInt(range.substring(index + 1));
/* 1215:     */             }
/* 1216:     */           }
/* 1217:1510 */           if ((dataSize >= lower) && (dataSize <= upper)) {
/* 1218:1512 */             return sizeToUse;
/* 1219:     */           }
/* 1220:     */         }
/* 1221:     */       }
/* 1222:     */     }
/* 1223:1517 */     return dataSize;
/* 1224:     */   }
/* 1225:     */   
/* 1226:     */   public String getUIPropertyKey(String key)
/* 1227:     */   {
/* 1228:1522 */     return this.controlAttributes.getName() + (key == null ? "" : new StringBuilder().append(".").append(key).toString());
/* 1229:     */   }
/* 1230:     */   
/* 1231:     */   public UIComponent createDataPanel(AbstractMobileControl calledControl, String label, String image, String popKey, MobileMboDataBean activeDataBean, TreeNodeData data)
/* 1232:     */     throws MobileApplicationException
/* 1233:     */   {
/* 1234:1528 */     return getWidget().createDataPanel(calledControl, label, image, popKey, activeDataBean, data);
/* 1235:     */   }
/* 1236:     */   
/* 1237:     */   public void cleanup()
/* 1238:     */   {
/* 1239:1533 */     Iterator iterator = getChildren();
/* 1240:1534 */     if (iterator != null) {
/* 1241:1536 */       while (iterator.hasNext())
/* 1242:     */       {
/* 1243:1538 */         AbstractMobileControl child = (AbstractMobileControl)iterator.next();
/* 1244:1539 */         child.cleanup();
/* 1245:     */       }
/* 1246:     */     }
/* 1247:1542 */     if (this.components != null) {
/* 1248:1544 */       for (int i = 0; i < this.components.length; i++)
/* 1249:     */       {
/* 1250:1546 */         UIComponent component = this.components[i];
/* 1251:1547 */         if (component != null) {
/* 1252:1548 */           component.setController(null);
/* 1253:     */         }
/* 1254:     */       }
/* 1255:     */     }
/* 1256:1552 */     this.parentControl = null;
/* 1257:1553 */     this.childControls = null;
/* 1258:     */     
/* 1259:1555 */     this.components = null;
/* 1260:1556 */     this.inheritedValues = null;
/* 1261:1557 */     this.app = null;
/* 1262:1558 */     this.menuBar = null;
/* 1263:1559 */     this.myToolBar = null;
/* 1264:     */   }
/* 1265:     */   
/* 1266:     */   public boolean isCancelEvent()
/* 1267:     */   {
/* 1268:1564 */     String event = getStringValue("event");
/* 1269:1565 */     if ((event != null) && ((event.equalsIgnoreCase("cancelpage")) || (event.equalsIgnoreCase("closepage")))) {
/* 1270:1567 */       return true;
/* 1271:     */     }
/* 1272:1570 */     return getBooleanValue("cancelsetvalue");
/* 1273:     */   }
/* 1274:     */   
/* 1275:     */   public String getDisplayEvent()
/* 1276:     */   {
/* 1277:1575 */     return this.displayEvent;
/* 1278:     */   }
/* 1279:     */   
/* 1280:     */   public void setDisplayEvent(String displayEvent)
/* 1281:     */   {
/* 1282:1579 */     this.displayEvent = displayEvent;
/* 1283:     */   }
/* 1284:     */   
/* 1285:     */   public BasicMobileDeviceUIApplication getApp()
/* 1286:     */   {
/* 1287:1583 */     return this.app;
/* 1288:     */   }
/* 1289:     */   
/* 1290:1604 */   private static boolean uiTestMode = false;
/* 1291:     */   
/* 1292:     */   public static boolean isUiTestMode()
/* 1293:     */   {
/* 1294:1607 */     return uiTestMode;
/* 1295:     */   }
/* 1296:     */   
/* 1297:     */   public static void setUiTestMode(boolean uiTestMode)
/* 1298:     */   {
/* 1299:1611 */     uiTestMode = uiTestMode;
/* 1300:     */   }
/* 1301:     */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.controls.AbstractMobileControl
 * JD-Core Version:    0.7.0.1
 */