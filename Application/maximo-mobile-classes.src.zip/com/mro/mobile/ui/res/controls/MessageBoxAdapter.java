package com.mro.mobile.ui.res.controls;

import com.mro.mobile.ui.res.widgets.def.UIComponent;
import java.util.Vector;

public abstract interface MessageBoxAdapter
{
  public abstract void show();
  
  public abstract UIComponent createIconImage(String paramString);
  
  public abstract UIComponent createLinkImageAndAddListener(String paramString1, boolean paramBoolean, String paramString2);
  
  public abstract void addListenerToLinkImageAndAppendComponent(LinkControl paramLinkControl, UIComponent paramUIComponent, Vector paramVector);
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.controls.MessageBoxAdapter
 * JD-Core Version:    0.7.0.1
 */