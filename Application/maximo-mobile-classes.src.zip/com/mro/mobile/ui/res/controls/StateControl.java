/*   1:    */ package com.mro.mobile.ui.res.controls;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.ui.event.UIEvent;
/*   5:    */ import com.mro.mobile.ui.res.ControlData;
/*   6:    */ import com.mro.mobile.ui.res.widgets.def.AbstractWidget;
/*   7:    */ import com.mro.mobile.ui.res.widgets.def.StateWidget;
/*   8:    */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*   9:    */ import com.mro.mobile.ui.res.widgets.def.WidgetCreator;
/*  10:    */ import java.util.ArrayList;
/*  11:    */ import java.util.Iterator;
/*  12:    */ import java.util.Vector;
/*  13:    */ 
/*  14:    */ public class StateControl
/*  15:    */   extends AbstractMobileControl
/*  16:    */ {
/*  17: 39 */   private AbstractMobileControl currentstate = null;
/*  18: 40 */   private int currentstateseq = 0;
/*  19: 41 */   private Vector stateCompRegistry = new Vector();
/*  20: 42 */   public ArrayList child = null;
/*  21: 43 */   public Iterator cControls = null;
/*  22:    */   
/*  23:    */   protected StateWidget getStateWidget()
/*  24:    */   {
/*  25: 49 */     return (StateWidget)super.getWidget();
/*  26:    */   }
/*  27:    */   
/*  28: 52 */   private static WidgetCreator widgetCreator = null;
/*  29:    */   
/*  30:    */   public static void registerWidgetCreator(WidgetCreator wc)
/*  31:    */   {
/*  32: 55 */     widgetCreator = wc;
/*  33:    */   }
/*  34:    */   
/*  35:    */   public UIComponent[] composeComponents()
/*  36:    */     throws MobileApplicationException
/*  37:    */   {
/*  38: 60 */     StateWidget widget = getStateWidget();
/*  39:    */     
/*  40: 62 */     this.child = composeChildren();
/*  41: 63 */     this.cControls = this.child.iterator();
/*  42:    */     
/*  43:    */ 
/*  44:    */ 
/*  45: 67 */     widget.createStatePanel();
/*  46: 68 */     UIComponent[] st = getCurrentState();
/*  47: 69 */     if (getStringValue("initevent") != null)
/*  48:    */     {
/*  49: 71 */       sendInitEvent();
/*  50:    */       
/*  51:    */ 
/*  52: 74 */       return widget.resolveStateComponents();
/*  53:    */     }
/*  54: 78 */     Iterator it = this.child.iterator();
/*  55: 79 */     if (it != null)
/*  56:    */     {
/*  57: 82 */       UIComponent[] comp = (UIComponent[])it.next();
/*  58: 83 */       UIComponent uic = comp[0];
/*  59: 84 */       widget.addToStatePanel(uic);
/*  60:    */       
/*  61:    */ 
/*  62: 87 */       return widget.resolveStateComponents();
/*  63:    */     }
/*  64: 90 */     return null;
/*  65:    */   }
/*  66:    */   
/*  67:    */   public Iterator getStateControls()
/*  68:    */     throws MobileApplicationException
/*  69:    */   {
/*  70: 95 */     return this.cControls;
/*  71:    */   }
/*  72:    */   
/*  73:    */   public void setStateViaState(String state)
/*  74:    */     throws MobileApplicationException
/*  75:    */   {
/*  76:100 */     if (state != null)
/*  77:    */     {
/*  78:102 */       Iterator controls = getChildren();
/*  79:103 */       while (controls.hasNext())
/*  80:    */       {
/*  81:105 */         AbstractMobileControl ctrl = (AbstractMobileControl)controls.next();
/*  82:106 */         String ctrlEvent = ctrl.getStringValue("state");
/*  83:107 */         if (state.equalsIgnoreCase(ctrlEvent)) {
/*  84:109 */           if (ctrl.getComponents() != null)
/*  85:    */           {
/*  86:111 */             setCurrentstate(ctrl);
/*  87:    */             
/*  88:    */ 
/*  89:114 */             StateWidget widget = getStateWidget();
/*  90:115 */             widget.removeAllFromStatePanel();
/*  91:116 */             widget.addToStatePanel(ctrl.getComponents()[0]);
/*  92:117 */             break;
/*  93:    */           }
/*  94:    */         }
/*  95:    */       }
/*  96:    */     }
/*  97:    */   }
/*  98:    */   
/*  99:    */   public void setStateViaEvent(String event)
/* 100:    */     throws MobileApplicationException
/* 101:    */   {
/* 102:126 */     if (event != null)
/* 103:    */     {
/* 104:128 */       Iterator controls = getChildren();
/* 105:129 */       while (controls.hasNext())
/* 106:    */       {
/* 107:131 */         AbstractMobileControl ctrl = (AbstractMobileControl)controls.next();
/* 108:132 */         String ctrlEvent = ctrl.getStringValue("event");
/* 109:133 */         if (event.equalsIgnoreCase(ctrlEvent)) {
/* 110:135 */           if (ctrl.getComponents() != null)
/* 111:    */           {
/* 112:137 */             setCurrentstate(ctrl);
/* 113:    */             
/* 114:    */ 
/* 115:140 */             StateWidget widget = getStateWidget();
/* 116:141 */             widget.removeAllFromStatePanel();
/* 117:142 */             widget.addToStatePanel(ctrl.getComponents()[0]);
/* 118:143 */             break;
/* 119:    */           }
/* 120:    */         }
/* 121:    */       }
/* 122:    */     }
/* 123:    */   }
/* 124:    */   
/* 125:    */   public void setNewState(String id)
/* 126:    */     throws MobileApplicationException
/* 127:    */   {
/* 128:152 */     Iterator controls = this.child.iterator();
/* 129:153 */     while (controls.hasNext())
/* 130:    */     {
/* 131:155 */       UIComponent[] comp = (UIComponent[])controls.next();
/* 132:156 */       UIComponent uic = comp[0];
/* 133:157 */       AbstractMobileControl newControl = uic.getController();
/* 134:158 */       if (newControl.getId().equalsIgnoreCase(id))
/* 135:    */       {
/* 136:162 */         StateWidget widget = getStateWidget();
/* 137:163 */         widget.removeAllFromStatePanel();
/* 138:164 */         widget.addToStatePanel(uic);
/* 139:    */       }
/* 140:    */     }
/* 141:    */   }
/* 142:    */   
/* 143:    */   private UIComponent[] getCurrentState()
/* 144:    */     throws MobileApplicationException
/* 145:    */   {
/* 146:172 */     Iterator i = this.child.iterator();
/* 147:173 */     int x = 0;
/* 148:174 */     if (i != null)
/* 149:    */     {
/* 150:176 */       StateWidget widget = getStateWidget();
/* 151:177 */       while (i.hasNext())
/* 152:    */       {
/* 153:179 */         UIComponent[] comp = (UIComponent[])i.next();
/* 154:180 */         UIComponent uic = comp[0];
/* 155:182 */         if (widget.isStateListener(uic))
/* 156:    */         {
/* 157:184 */           UIComponent[] retcomponent = { uic };
/* 158:185 */           AbstractMobileControl control = uic.getController();
/* 159:186 */           StateControl statecontrol = (StateControl)control.getParentControl();
/* 160:187 */           AbstractMobileControl cont = statecontrol.getCurrentstate();
/* 161:188 */           if ((cont != null) && (cont.equals(control)))
/* 162:    */           {
/* 163:190 */             String event = control.getStringValue("event");
/* 164:191 */             if ((event == null) || (isSigOptionAuth(event)))
/* 165:    */             {
/* 166:193 */               widget.removeAllFromStatePanel();
/* 167:194 */               widget.addToStatePanel(uic);
/* 168:    */               
/* 169:    */ 
/* 170:197 */               return retcomponent;
/* 171:    */             }
/* 172:    */           }
/* 173:    */         }
/* 174:201 */         x++;
/* 175:    */       }
/* 176:    */     }
/* 177:204 */     return null;
/* 178:    */   }
/* 179:    */   
/* 180:    */   protected boolean performEvent(UIEvent event)
/* 181:    */     throws MobileApplicationException
/* 182:    */   {
/* 183:217 */     return false;
/* 184:    */   }
/* 185:    */   
/* 186:    */   protected boolean handleException(UIEvent event, Exception exception)
/* 187:    */   {
/* 188:226 */     return false;
/* 189:    */   }
/* 190:    */   
/* 191:    */   protected boolean refreshControl(UIEvent event)
/* 192:    */     throws MobileApplicationException
/* 193:    */   {
/* 194:235 */     getCurrentState();
/* 195:    */     
/* 196:237 */     return true;
/* 197:    */   }
/* 198:    */   
/* 199:    */   public AbstractMobileControl createControl(ControlData controlData)
/* 200:    */     throws MobileApplicationException
/* 201:    */   {
/* 202:247 */     return new StateControl();
/* 203:    */   }
/* 204:    */   
/* 205:    */   protected boolean init()
/* 206:    */     throws MobileApplicationException
/* 207:    */   {
/* 208:256 */     return false;
/* 209:    */   }
/* 210:    */   
/* 211:    */   public AbstractMobileControl getCurrentstate()
/* 212:    */   {
/* 213:264 */     return this.currentstate;
/* 214:    */   }
/* 215:    */   
/* 216:    */   public void setCurrentstate(AbstractMobileControl currentstate)
/* 217:    */   {
/* 218:272 */     this.currentstate = currentstate;
/* 219:    */   }
/* 220:    */   
/* 221:    */   protected AbstractWidget createWidget()
/* 222:    */   {
/* 223:276 */     return widgetCreator.createWidget();
/* 224:    */   }
/* 225:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.controls.StateControl
 * JD-Core Version:    0.7.0.1
 */