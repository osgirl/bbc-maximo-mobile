/*   1:    */ package com.mro.mobile.ui.res.controls;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.mbo.MobileMbo;
/*   5:    */ import com.mro.mobile.ui.MobileMboDataBean;
/*   6:    */ import com.mro.mobile.ui.MobileMboDataBeanManager;
/*   7:    */ import com.mro.mobile.ui.event.UIEvent;
/*   8:    */ import com.mro.mobile.ui.res.ControlData;
/*   9:    */ import com.mro.mobile.ui.res.UIUtil;
/*  10:    */ import com.mro.mobile.ui.res.widgets.def.AbstractWidget;
/*  11:    */ import com.mro.mobile.ui.res.widgets.def.FileDialogueWidget;
/*  12:    */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  13:    */ import com.mro.mobile.ui.res.widgets.def.WidgetCreator;
/*  14:    */ import com.mro.mobile.util.MobileLogger;
/*  15:    */ import java.io.File;
/*  16:    */ import java.io.FileInputStream;
/*  17:    */ import java.io.InputStream;
/*  18:    */ 
/*  19:    */ public class FileDialogueControl
/*  20:    */   extends AbstractMobileControl
/*  21:    */ {
/*  22: 43 */   private static String STYLEKEY_COMBO = "dropdown";
/*  23:    */   
/*  24:    */   protected FileDialogueWidget getFileDialogueWidget()
/*  25:    */   {
/*  26: 49 */     return (FileDialogueWidget)super.getWidget();
/*  27:    */   }
/*  28:    */   
/*  29:    */   public UIComponent[] composeComponents()
/*  30:    */     throws MobileApplicationException
/*  31:    */   {
/*  32: 54 */     return getFileDialogueWidget().composePanel(getStringValue("directory"));
/*  33:    */   }
/*  34:    */   
/*  35:    */   protected boolean performEvent(UIEvent event)
/*  36:    */     throws MobileApplicationException
/*  37:    */   {
/*  38: 63 */     String eventType = event.getEventName();
/*  39: 64 */     byte[] dataBytes = null;
/*  40: 65 */     if (eventType.equalsIgnoreCase("savedoc"))
/*  41:    */     {
/*  42: 67 */       AbstractMobileControl tempCtrl = ((PageControl)UIUtil.getCurrentScreen()).getLaunchingControl();
/*  43: 68 */       if ((tempCtrl instanceof LinkControl))
/*  44:    */       {
/*  45: 70 */         String setAttr = tempCtrl.getStringValue("dataattribute");
/*  46: 71 */         if (setAttr != null)
/*  47:    */         {
/*  48: 73 */           File curFile = getSelectedFile();
/*  49: 74 */           if (curFile != null)
/*  50:    */           {
/*  51:    */             try
/*  52:    */             {
/*  53: 78 */               dataBytes = new byte[(int)curFile.length()];
/*  54: 79 */               InputStream fis = new FileInputStream(getSelectedFile());
/*  55: 80 */               fis.read(dataBytes);
/*  56: 81 */               tempCtrl.getDataBean().getMobileMbo().setValue("FILENAME", getSelectedFile().getName());
/*  57:    */             }
/*  58:    */             catch (Exception ioe)
/*  59:    */             {
/*  60: 85 */               getDefaultLogger().warn("Failed to get FileInputStream", ioe);
/*  61: 86 */               return true;
/*  62:    */             }
/*  63: 88 */             tempCtrl.getDataBean().getMobileMbo().setBinaryValue(setAttr, dataBytes);
/*  64: 89 */             tempCtrl.getDataBean().getDataBeanManager().save();
/*  65:    */           }
/*  66:    */           else
/*  67:    */           {
/*  68: 94 */             MobileMbo newAttachMbo = tempCtrl.getDataBean().getMobileMbo();
/*  69: 95 */             if (newAttachMbo != null)
/*  70:    */             {
/*  71: 97 */               newAttachMbo.delete();
/*  72: 98 */               newAttachMbo.deleteLocal();
/*  73: 99 */               tempCtrl.getDataBean().reset();
/*  74:    */             }
/*  75:    */           }
/*  76:    */         }
/*  77:    */       }
/*  78:104 */       UIUtil.closePage();
/*  79:    */     }
/*  80:106 */     else if (eventType.equalsIgnoreCase("treeselect"))
/*  81:    */     {
/*  82:108 */       Object selItem = event.getValue();
/*  83:109 */       getFileDialogueWidget().handleTreeSelect(selItem);
/*  84:    */     }
/*  85:111 */     else if (eventType.equalsIgnoreCase("scan4Children"))
/*  86:    */     {
/*  87:113 */       Object selItem = event.getValue();
/*  88:114 */       getFileDialogueWidget().handleScan4Children(selItem);
/*  89:    */     }
/*  90:116 */     return false;
/*  91:    */   }
/*  92:    */   
/*  93:    */   protected boolean handleException(UIEvent event, Exception exception)
/*  94:    */   {
/*  95:125 */     return false;
/*  96:    */   }
/*  97:    */   
/*  98:    */   protected boolean refreshControl(UIEvent event)
/*  99:    */     throws MobileApplicationException
/* 100:    */   {
/* 101:135 */     return false;
/* 102:    */   }
/* 103:    */   
/* 104:    */   public AbstractMobileControl createControl(ControlData controlData)
/* 105:    */     throws MobileApplicationException
/* 106:    */   {
/* 107:144 */     return new FileDialogueControl();
/* 108:    */   }
/* 109:    */   
/* 110:    */   public File getSelectedFile()
/* 111:    */   {
/* 112:152 */     return getFileDialogueWidget().getSelectedFile();
/* 113:    */   }
/* 114:    */   
/* 115:    */   public void setSelectedFile(File selectedFile)
/* 116:    */   {
/* 117:161 */     getFileDialogueWidget().setSelectedFile(selectedFile);
/* 118:    */   }
/* 119:    */   
/* 120:164 */   private static WidgetCreator widgetCreator = null;
/* 121:    */   
/* 122:    */   public static void registerWidgetCreator(WidgetCreator wc)
/* 123:    */   {
/* 124:167 */     widgetCreator = wc;
/* 125:    */   }
/* 126:    */   
/* 127:    */   protected AbstractWidget createWidget()
/* 128:    */   {
/* 129:171 */     return widgetCreator.createWidget();
/* 130:    */   }
/* 131:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.controls.FileDialogueControl
 * JD-Core Version:    0.7.0.1
 */