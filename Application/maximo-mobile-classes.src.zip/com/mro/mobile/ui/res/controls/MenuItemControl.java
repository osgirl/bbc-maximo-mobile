/*   1:    */ package com.mro.mobile.ui.res.controls;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.ui.event.UIEvent;
/*   5:    */ import com.mro.mobile.ui.res.ControlData;
/*   6:    */ import com.mro.mobile.ui.res.widgets.def.AbstractWidget;
/*   7:    */ import com.mro.mobile.ui.res.widgets.def.MenuItemWidget;
/*   8:    */ import com.mro.mobile.ui.res.widgets.def.MenuWidget;
/*   9:    */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  10:    */ import com.mro.mobile.ui.res.widgets.def.WidgetCreator;
/*  11:    */ 
/*  12:    */ public class MenuItemControl
/*  13:    */   extends MenuControl
/*  14:    */ {
/*  15: 35 */   private String id = "";
/*  16: 36 */   private String label = "";
/*  17: 37 */   private String event = "";
/*  18: 38 */   private String value = "";
/*  19: 39 */   private boolean separator = false;
/*  20: 40 */   private String image = "";
/*  21: 41 */   private String targetid = "";
/*  22:    */   
/*  23:    */   public MenuItemWidget getMenuItemWidget()
/*  24:    */   {
/*  25: 47 */     return (MenuItemWidget)super.getWidget();
/*  26:    */   }
/*  27:    */   
/*  28:    */   public boolean init()
/*  29:    */     throws MobileApplicationException
/*  30:    */   {
/*  31: 52 */     getMenuWidget().setMenuId(getStringValue("id"));
/*  32: 53 */     this.label = getLabel();
/*  33: 54 */     this.event = getStringValue("event");
/*  34: 55 */     this.value = getStringValue("value");
/*  35: 56 */     this.targetid = getStringValue("targetid");
/*  36: 57 */     this.image = getStringValue("image");
/*  37: 58 */     this.separator = getBooleanValue("seperator");
/*  38: 59 */     return true;
/*  39:    */   }
/*  40:    */   
/*  41:    */   public AbstractMobileControl createControl(ControlData controlData)
/*  42:    */     throws MobileApplicationException
/*  43:    */   {
/*  44: 65 */     return new MenuItemControl();
/*  45:    */   }
/*  46:    */   
/*  47:    */   public UIComponent[] composeComponents()
/*  48:    */     throws MobileApplicationException
/*  49:    */   {
/*  50: 71 */     init();
/*  51: 72 */     return getMenuItems(this.image, this.label);
/*  52:    */   }
/*  53:    */   
/*  54:    */   public boolean handleEvent(UIEvent event)
/*  55:    */   {
/*  56: 80 */     event.setValue(this.value);
/*  57: 81 */     return super.handleEvent(event);
/*  58:    */   }
/*  59:    */   
/*  60:    */   protected boolean performEvent(UIEvent event)
/*  61:    */     throws MobileApplicationException
/*  62:    */   {
/*  63: 89 */     return false;
/*  64:    */   }
/*  65:    */   
/*  66:    */   private UIComponent[] getMenuItems(String image, String label)
/*  67:    */     throws MobileApplicationException
/*  68:    */   {
/*  69: 95 */     MenuItemWidget widget = getMenuItemWidget();
/*  70: 96 */     widget.createMenuItem(this.id, label, this.value, image, this.separator, this.event, this.targetid);
/*  71: 97 */     return widget.resolveMMenuItemComponents();
/*  72:    */   }
/*  73:    */   
/*  74:    */   public void refresh(UIEvent clientEvent)
/*  75:    */     throws MobileApplicationException
/*  76:    */   {
/*  77:105 */     sendDisplayEvent();
/*  78:    */   }
/*  79:    */   
/*  80:108 */   private static WidgetCreator widgetCreator = null;
/*  81:    */   
/*  82:    */   public static void registerWidgetCreator(WidgetCreator wc)
/*  83:    */   {
/*  84:111 */     widgetCreator = wc;
/*  85:    */   }
/*  86:    */   
/*  87:    */   protected AbstractWidget createWidget()
/*  88:    */   {
/*  89:115 */     return widgetCreator.createWidget();
/*  90:    */   }
/*  91:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.controls.MenuItemControl
 * JD-Core Version:    0.7.0.1
 */