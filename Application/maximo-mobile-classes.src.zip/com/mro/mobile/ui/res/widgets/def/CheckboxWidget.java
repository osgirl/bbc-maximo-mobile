package com.mro.mobile.ui.res.widgets.def;

import com.mro.mobile.MobileApplicationException;
import com.mro.mobile.ui.res.controls.AbstractMobileControl;

public abstract interface CheckboxWidget
  extends InputWidget
{
  public abstract CheckboxWidget createCheckBoxField(String paramString, boolean paramBoolean);
  
  public abstract void setCheckBoxId(String paramString);
  
  public abstract void setEvent(String paramString);
  
  public abstract void setController(AbstractMobileControl paramAbstractMobileControl);
  
  public abstract void setDataBeanName(String paramString);
  
  public abstract void setMobileMboAttributeName(String paramString);
  
  public abstract void setState(boolean paramBoolean);
  
  public abstract boolean getState();
  
  public abstract void setInputMode(String paramString);
  
  public abstract void setEnabled(boolean paramBoolean);
  
  public abstract void requestFocus();
  
  public abstract UIComponent[] resolveCheckBoxComponents()
    throws MobileApplicationException;
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.def.CheckboxWidget
 * JD-Core Version:    0.7.0.1
 */