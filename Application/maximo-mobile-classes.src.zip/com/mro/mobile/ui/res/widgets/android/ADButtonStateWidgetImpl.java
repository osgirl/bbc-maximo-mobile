/*  1:   */ package com.mro.mobile.ui.res.widgets.android;
/*  2:   */ 
/*  3:   */ import com.mro.mobile.MobileApplicationException;
/*  4:   */ import com.mro.mobile.ui.res.controls.ButtonStateControl;
/*  5:   */ import com.mro.mobile.ui.res.widgets.android.components.NButtonStateful;
/*  6:   */ import com.mro.mobile.ui.res.widgets.def.ButtonStateWidget;
/*  7:   */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  8:   */ 
/*  9:   */ public class ADButtonStateWidgetImpl
/* 10:   */   extends ADAbstractWidgetImpl
/* 11:   */   implements ButtonStateWidget
/* 12:   */ {
/* 13:13 */   private NButtonStateful button = null;
/* 14:   */   
/* 15:   */   public ButtonStateWidget createButtonState(String imageOnPath, String imageOffPath)
/* 16:   */   {
/* 17:17 */     this.button = NButtonStateful.createByInflate(getButtonStateControl(), AndroidEnv.getCurrentActivity(), imageOnPath, imageOffPath);
/* 18:18 */     return null;
/* 19:   */   }
/* 20:   */   
/* 21:   */   protected ButtonStateControl getButtonStateControl()
/* 22:   */   {
/* 23:22 */     return (ButtonStateControl)getController();
/* 24:   */   }
/* 25:   */   
/* 26:   */   public void setVisible(boolean vis)
/* 27:   */   {
/* 28:27 */     this.button.setVisibility(vis ? 0 : 4);
/* 29:   */   }
/* 30:   */   
/* 31:   */   public void setValue(String value)
/* 32:   */   {
/* 33:32 */     this.button.setValue(value);
/* 34:   */   }
/* 35:   */   
/* 36:   */   public void setTargetId(String targetId)
/* 37:   */   {
/* 38:37 */     this.button.setTargetId(targetId);
/* 39:   */   }
/* 40:   */   
/* 41:   */   public UIComponent[] resolveButtonStateComponents()
/* 42:   */     throws MobileApplicationException
/* 43:   */   {
/* 44:44 */     return null;
/* 45:   */   }
/* 46:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.ADButtonStateWidgetImpl
 * JD-Core Version:    0.7.0.1
 */