package com.mro.mobile.ui.res.widgets.def;

import com.mro.mobile.MobileApplicationException;
import com.mro.mobile.ui.res.controls.AbstractMobileControl;
import com.mro.mobile.ui.res.controls.utils.ControlStyle;

public abstract interface DropDownWidget
  extends InputWidget
{
  public abstract DropDownWidget createDropDownField();
  
  public abstract void setDropDownId(String paramString);
  
  public abstract void setEvent(String paramString);
  
  public abstract void setController(AbstractMobileControl paramAbstractMobileControl);
  
  public abstract void setDataBeanName(String paramString);
  
  public abstract void setMobileMboAttributeName(String paramString);
  
  public abstract void setEnabled(boolean paramBoolean);
  
  public abstract void requestFocus();
  
  public abstract void setSelectedItem(int paramInt);
  
  public abstract void addBlankItem(ControlStyle paramControlStyle);
  
  public abstract void addItem(String paramString, ControlStyle paramControlStyle);
  
  public abstract void clear();
  
  public abstract int getSelectedIndex();
  
  public abstract Object getSelectedItem();
  
  public abstract UIComponent[] resolveDropDownComponents()
    throws MobileApplicationException;
  
  public abstract String getSelectedItemAsText();
  
  public abstract void applyDataAdapter();
  
  public abstract void bindListeners();
  
  public abstract boolean needsBlankItem();
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.def.DropDownWidget
 * JD-Core Version:    0.7.0.1
 */