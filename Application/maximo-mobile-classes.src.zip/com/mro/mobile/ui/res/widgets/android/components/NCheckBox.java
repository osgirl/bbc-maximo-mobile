/*   1:    */ package com.mro.mobile.ui.res.widgets.android.components;
/*   2:    */ 
/*   3:    */ import android.app.Activity;
/*   4:    */ import android.content.Context;
/*   5:    */ import android.content.res.Resources;
/*   6:    */ import android.graphics.drawable.Drawable;
/*   7:    */ import android.util.AttributeSet;
/*   8:    */ import android.view.View;
/*   9:    */ import android.view.View.OnClickListener;
/*  10:    */ import android.widget.CheckBox;
/*  11:    */ import android.widget.LinearLayout.LayoutParams;
/*  12:    */ import com.ibm.tivoli.maximo.mobile.android.util.UIUtil;
/*  13:    */ import com.ibm.tivoli.maximo.mobile.resources.R.drawable;
/*  14:    */ import com.ibm.tivoli.maximo.mobile.resources.R.layout;
/*  15:    */ import com.mro.mobile.ui.event.UIEvent;
/*  16:    */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*  17:    */ import com.mro.mobile.ui.res.controls.InputControl;
/*  18:    */ import com.mro.mobile.ui.res.widgets.android.AndroidEnv;
/*  19:    */ import com.mro.mobile.ui.res.widgets.android.components.table.NTableListenerManager.TableClickable;
/*  20:    */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  21:    */ import java.util.Enumeration;
/*  22:    */ 
/*  23:    */ public class NCheckBox
/*  24:    */   extends CheckBox
/*  25:    */   implements UIComponent
/*  26:    */ {
/*  27: 36 */   private static final int DEFAULT_XML_LAYOUT = UIUtil.getResourceId(R.layout.class, "ncheckbox");
/*  28: 38 */   private String mobileMboAttributeName = null;
/*  29: 39 */   private String dataBeanName = null;
/*  30: 40 */   private String event = null;
/*  31: 41 */   private String cid = null;
/*  32: 42 */   private AbstractMobileControl controller = null;
/*  33: 43 */   private LinearLayout.LayoutParams constraints = null;
/*  34: 44 */   private String inputMode = null;
/*  35:    */   
/*  36:    */   public NCheckBox(Context context)
/*  37:    */   {
/*  38: 47 */     super(context);
/*  39:    */   }
/*  40:    */   
/*  41:    */   public NCheckBox(Context context, AttributeSet attrs)
/*  42:    */   {
/*  43: 51 */     super(context, attrs);
/*  44:    */   }
/*  45:    */   
/*  46:    */   public NCheckBox(Context context, AttributeSet attrs, int defStyle)
/*  47:    */   {
/*  48: 55 */     super(context, attrs, defStyle);
/*  49:    */   }
/*  50:    */   
/*  51:    */   public static NCheckBox createByInflate(AbstractMobileControl control, Context context, String text)
/*  52:    */   {
/*  53: 59 */     return createByInflate(control, context, text, false);
/*  54:    */   }
/*  55:    */   
/*  56:    */   public static NCheckBox createByInflate(AbstractMobileControl control, Context context, String text, boolean readOnly)
/*  57:    */   {
/*  58: 63 */     return createByInflate(DEFAULT_XML_LAYOUT, control, context, text, readOnly);
/*  59:    */   }
/*  60:    */   
/*  61:    */   public static NCheckBox createByInflate(int layoutId, AbstractMobileControl control, Context context, String text, boolean readOnly)
/*  62:    */   {
/*  63: 67 */     NCheckBox checkbox = (NCheckBox)View.inflate(context, layoutId, null);
/*  64: 68 */     checkbox.postInstance(control, text, readOnly);
/*  65: 69 */     return checkbox;
/*  66:    */   }
/*  67:    */   
/*  68:    */   private void postInstance(AbstractMobileControl control, String text, boolean readOnly)
/*  69:    */   {
/*  70: 73 */     setController(control);
/*  71: 75 */     if (control != null) {
/*  72: 76 */       setId(NIDMapper.getAndroidIdFor(control.getId()));
/*  73:    */     } else {
/*  74: 78 */       setId(NIDMapper.getNextId());
/*  75:    */     }
/*  76: 81 */     setEnabled(!readOnly);
/*  77: 82 */     setText(text);
/*  78:    */     
/*  79: 84 */     Drawable drawable = AndroidEnv.getCurrentActivity().getResources().getDrawable(UIUtil.getResourceId(R.drawable.class, "checkbox_image_state"));
/*  80: 85 */     if (drawable != null) {
/*  81: 86 */       setButtonDrawable(drawable);
/*  82:    */     }
/*  83: 88 */     init();
/*  84:    */   }
/*  85:    */   
/*  86:    */   public String getCId()
/*  87:    */   {
/*  88: 96 */     return this.cid;
/*  89:    */   }
/*  90:    */   
/*  91:    */   public void setCId(String cid)
/*  92:    */   {
/*  93:102 */     this.cid = cid;
/*  94:    */   }
/*  95:    */   
/*  96:    */   public void init()
/*  97:    */   {
/*  98:108 */     setOnClickListener(new View.OnClickListener()
/*  99:    */     {
/* 100:    */       public void onClick(View v)
/* 101:    */       {
/* 102:112 */         NCheckBox.this.firePreListeners();
/* 103:113 */         if (!AbstractMobileControl.isUiTestMode()) {
/* 104:115 */           if (NCheckBox.this.getController().isAttributeSet("dataattribute")) {
/* 105:118 */             if ((!((InputControl)NCheckBox.this.getController()).isReadOnly()) && (NCheckBox.this.mTableClickable == null))
/* 106:    */             {
/* 107:120 */               UIEvent uievent = new UIEvent(NCheckBox.this.getController(), NCheckBox.this.event == null ? "setvalue" : NCheckBox.this.event, null, NCheckBox.this.getState() + "");
/* 108:121 */               NCheckBox.this.getController().handleEvent(uievent);
/* 109:    */             }
/* 110:    */           }
/* 111:    */         }
/* 112:125 */         NCheckBox.this.firePostListeners();
/* 113:    */       }
/* 114:    */     });
/* 115:    */   }
/* 116:    */   
/* 117:130 */   private NTableListenerManager.TableClickable mTableClickable = null;
/* 118:    */   
/* 119:    */   private void firePreListeners()
/* 120:    */   {
/* 121:133 */     if (this.mTableClickable != null) {
/* 122:134 */       this.mTableClickable.tableClicked(this);
/* 123:    */     }
/* 124:    */   }
/* 125:    */   
/* 126:    */   private void firePostListeners() {}
/* 127:    */   
/* 128:    */   public void setTableClickable(NTableListenerManager.TableClickable tc)
/* 129:    */   {
/* 130:142 */     this.mTableClickable = tc;
/* 131:    */   }
/* 132:    */   
/* 133:    */   public void setState(boolean b)
/* 134:    */   {
/* 135:147 */     setChecked(b);
/* 136:    */   }
/* 137:    */   
/* 138:    */   public boolean getState()
/* 139:    */   {
/* 140:152 */     return isChecked();
/* 141:    */   }
/* 142:    */   
/* 143:    */   public void addChildUIComponent(UIComponent child) {}
/* 144:    */   
/* 145:    */   public boolean canContainChildren()
/* 146:    */   {
/* 147:165 */     return false;
/* 148:    */   }
/* 149:    */   
/* 150:    */   public Enumeration getChildren()
/* 151:    */   {
/* 152:171 */     return null;
/* 153:    */   }
/* 154:    */   
/* 155:    */   public AbstractMobileControl getController()
/* 156:    */   {
/* 157:177 */     return this.controller;
/* 158:    */   }
/* 159:    */   
/* 160:    */   public void setController(AbstractMobileControl controller)
/* 161:    */   {
/* 162:183 */     this.controller = controller;
/* 163:    */   }
/* 164:    */   
/* 165:    */   public Object getConstraints()
/* 166:    */   {
/* 167:189 */     return this.constraints;
/* 168:    */   }
/* 169:    */   
/* 170:    */   public void setConstraints(Object conts)
/* 171:    */   {
/* 172:195 */     this.constraints = ((LinearLayout.LayoutParams)conts);
/* 173:196 */     setLayoutParams(this.constraints);
/* 174:197 */     requestLayout();
/* 175:    */   }
/* 176:    */   
/* 177:    */   public String getEvent()
/* 178:    */   {
/* 179:204 */     return this.event;
/* 180:    */   }
/* 181:    */   
/* 182:    */   public void setEvent(String event)
/* 183:    */   {
/* 184:211 */     this.event = event;
/* 185:    */   }
/* 186:    */   
/* 187:    */   public String getDataBeanName()
/* 188:    */   {
/* 189:218 */     return this.dataBeanName;
/* 190:    */   }
/* 191:    */   
/* 192:    */   public void setDataBeanName(String dataBeanName)
/* 193:    */   {
/* 194:225 */     this.dataBeanName = dataBeanName;
/* 195:    */   }
/* 196:    */   
/* 197:    */   public String getMobileMboAttributeName()
/* 198:    */   {
/* 199:232 */     return this.mobileMboAttributeName;
/* 200:    */   }
/* 201:    */   
/* 202:    */   public void setMobileMboAttributeName(String mobileMboAttributeName)
/* 203:    */   {
/* 204:239 */     this.mobileMboAttributeName = mobileMboAttributeName;
/* 205:    */   }
/* 206:    */   
/* 207:    */   public void setInputMode(String inputMode)
/* 208:    */   {
/* 209:246 */     this.inputMode = inputMode;
/* 210:    */   }
/* 211:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.components.NCheckBox
 * JD-Core Version:    0.7.0.1
 */