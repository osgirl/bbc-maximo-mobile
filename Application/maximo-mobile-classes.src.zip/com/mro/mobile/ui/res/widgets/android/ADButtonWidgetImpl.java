/*  1:   */ package com.mro.mobile.ui.res.widgets.android;
/*  2:   */ 
/*  3:   */ import com.mro.mobile.MobileApplicationException;
/*  4:   */ import com.mro.mobile.ui.res.widgets.android.components.NDrawerListenerManager;
/*  5:   */ import com.mro.mobile.ui.res.widgets.android.components.NImageButton;
/*  6:   */ import com.mro.mobile.ui.res.widgets.android.components.table.NTableListenerManager;
/*  7:   */ import com.mro.mobile.ui.res.widgets.def.ButtonWidget;
/*  8:   */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  9:   */ 
/* 10:   */ public class ADButtonWidgetImpl
/* 11:   */   extends ADAbstractWidgetImpl
/* 12:   */   implements ButtonWidget
/* 13:   */ {
/* 14:12 */   private NImageButton button = null;
/* 15:14 */   private Object value = null;
/* 16:15 */   private String attributeid = "";
/* 17:16 */   private String targetid = "";
/* 18:17 */   private String event = "";
/* 19:18 */   private boolean defaultbutton = false;
/* 20:   */   
/* 21:   */   public ButtonWidget createButtonField(String img, String label)
/* 22:   */   {
/* 23:25 */     this.button = NImageButton.createByInflate(getController(), AndroidEnv.getCurrentActivity(), img, label);
/* 24:27 */     if (NTableListenerManager.instance().isWidgetControlInTable(getController())) {
/* 25:28 */       this.button.setTableClickable(NTableListenerManager.instance().getTableClickable());
/* 26:   */     }
/* 27:32 */     this.button.setButtonDrawerClickable(NDrawerListenerManager.instance().getDrawerLinkClickable());
/* 28:   */     
/* 29:34 */     return this;
/* 30:   */   }
/* 31:   */   
/* 32:   */   public UIComponent[] resolveButtonComponents()
/* 33:   */     throws MobileApplicationException
/* 34:   */   {
/* 35:39 */     this.button.setCId(this.attributeid);
/* 36:40 */     this.button.setValue(this.value);
/* 37:41 */     this.button.setTargetId(this.targetid);
/* 38:42 */     this.button.setEvent(this.event);
/* 39:43 */     if ((!this.defaultbutton) || 
/* 40:   */     
/* 41:   */ 
/* 42:46 */       (isBarcodeInfoButton())) {
/* 43:47 */       this.button.notifyBarcodeInfoButton();
/* 44:   */     }
/* 45:50 */     return new UIComponent[] { this.button };
/* 46:   */   }
/* 47:   */   
/* 48:   */   private boolean isBarcodeInfoButton()
/* 49:   */   {
/* 50:54 */     return (this.event != null) && ("scaninfo".equalsIgnoreCase(this.event));
/* 51:   */   }
/* 52:   */   
/* 53:   */   public Object getLinkValue()
/* 54:   */   {
/* 55:59 */     return this.value;
/* 56:   */   }
/* 57:   */   
/* 58:   */   public void setAttributeID(String attrib)
/* 59:   */   {
/* 60:64 */     this.attributeid = attrib;
/* 61:   */   }
/* 62:   */   
/* 63:   */   public void setAttributeValue(Object val)
/* 64:   */   {
/* 65:69 */     this.value = val;
/* 66:   */   }
/* 67:   */   
/* 68:   */   public void setAttributeTargetId(String targetId)
/* 69:   */   {
/* 70:74 */     this.targetid = targetId;
/* 71:   */   }
/* 72:   */   
/* 73:   */   public void setAtrributeEvent(String nEvent)
/* 74:   */   {
/* 75:79 */     this.event = nEvent;
/* 76:   */   }
/* 77:   */   
/* 78:   */   public void setDefaultButton(boolean defButton)
/* 79:   */   {
/* 80:84 */     this.defaultbutton = defButton;
/* 81:   */   }
/* 82:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.ADButtonWidgetImpl
 * JD-Core Version:    0.7.0.1
 */