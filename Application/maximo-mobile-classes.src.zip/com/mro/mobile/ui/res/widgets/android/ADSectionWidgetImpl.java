/*   1:    */ package com.mro.mobile.ui.res.widgets.android;
/*   2:    */ 
/*   3:    */ import android.view.View;
/*   4:    */ import android.view.ViewGroup;
/*   5:    */ import android.widget.LinearLayout.LayoutParams;
/*   6:    */ import com.mro.mobile.ui.res.ControlData;
/*   7:    */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*   8:    */ import com.mro.mobile.ui.res.controls.SectionControl;
/*   9:    */ import com.mro.mobile.ui.res.widgets.android.components.NLabel;
/*  10:    */ import com.mro.mobile.ui.res.widgets.android.components.NPanel;
/*  11:    */ import com.mro.mobile.ui.res.widgets.android.components.NRelativePanel;
/*  12:    */ import com.mro.mobile.ui.res.widgets.def.SectionWidget;
/*  13:    */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  14:    */ 
/*  15:    */ public class ADSectionWidgetImpl
/*  16:    */   extends ADAbstractWidgetImpl
/*  17:    */   implements SectionWidget
/*  18:    */ {
/*  19: 34 */   private NPanel mainPanel = null;
/*  20: 36 */   private LinearLayout.LayoutParams defaultConstraints = new LinearLayout.LayoutParams(-1, -2);
/*  21:    */   
/*  22:    */   public void createMainPanel()
/*  23:    */   {
/*  24: 40 */     this.mainPanel = NPanel.createByInflate(getSectionControl(), AndroidEnv.getCurrentActivity(), 1);
/*  25: 41 */     this.mainPanel.setGravity(48);
/*  26:    */   }
/*  27:    */   
/*  28:    */   protected SectionControl getSectionControl()
/*  29:    */   {
/*  30: 45 */     return (SectionControl)getController();
/*  31:    */   }
/*  32:    */   
/*  33:    */   public UIComponent getMainPanel()
/*  34:    */   {
/*  35: 50 */     return this.mainPanel;
/*  36:    */   }
/*  37:    */   
/*  38:    */   public void setMainPanelSectionId(String id)
/*  39:    */   {
/*  40: 55 */     this.mainPanel.setCId(id);
/*  41:    */   }
/*  42:    */   
/*  43:    */   public void setBgImage(String backgroundImageName) {}
/*  44:    */   
/*  45:    */   public void setBgColor(Object backgroundColor)
/*  46:    */   {
/*  47: 64 */     this.mainPanel.setBackgroundColor(-1);
/*  48:    */   }
/*  49:    */   
/*  50:    */   public UIComponent createLabel(String label)
/*  51:    */   {
/*  52: 69 */     NLabel nLabel = NLabel.createByInflate(getSectionControl(), AndroidEnv.getCurrentActivity(), label);
/*  53: 70 */     LinearLayout.LayoutParams nLabelConstraints = new LinearLayout.LayoutParams(-2, -2);
/*  54: 71 */     nLabelConstraints.setMargins(0, 0, 0, 4);
/*  55: 72 */     nLabel.setConstraints(nLabelConstraints);
/*  56: 73 */     nLabel.applyStyle(getController());
/*  57: 74 */     return nLabel;
/*  58:    */   }
/*  59:    */   
/*  60:    */   public void configDefaultConstraints(int top, int left, int bottom, int right)
/*  61:    */   {
/*  62: 79 */     this.defaultConstraints = new LinearLayout.LayoutParams(-1, -1);
/*  63: 80 */     this.defaultConstraints.setMargins(left, top, right, bottom);
/*  64:    */   }
/*  65:    */   
/*  66:    */   public UIComponent createOnePanel()
/*  67:    */   {
/*  68: 85 */     return createOnePanel(1);
/*  69:    */   }
/*  70:    */   
/*  71:    */   public UIComponent createOnePanel(int orentation)
/*  72:    */   {
/*  73: 90 */     boolean useRelativeLayout = getController().getBooleanValue("userelativelayout");
/*  74: 91 */     int childrenCount = getChildrenCount();
/*  75: 92 */     if ((useRelativeLayout) && (childrenCount > 1))
/*  76:    */     {
/*  77: 93 */       NRelativePanel p = NRelativePanel.createByInflate(getSectionControl(), AndroidEnv.getCurrentActivity(), childrenCount);
/*  78: 94 */       return p;
/*  79:    */     }
/*  80: 97 */     NPanel p = NPanel.createByInflate(getSectionControl(), AndroidEnv.getCurrentActivity(), orentation);
/*  81: 98 */     p.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
/*  82: 99 */     return p;
/*  83:    */   }
/*  84:    */   
/*  85:    */   protected int getChildrenCount()
/*  86:    */   {
/*  87:103 */     ControlData[] children = getController().getControlData().getChildControlData();
/*  88:104 */     return children != null ? children.length : 0;
/*  89:    */   }
/*  90:    */   
/*  91:    */   public void setPanelLayout(UIComponent panel, int rows, int cols)
/*  92:    */   {
/*  93:109 */     panel.setConstraints(this.defaultConstraints);
/*  94:    */   }
/*  95:    */   
/*  96:    */   public Object createRowLevelConstraints(int top, int left, int bottom, int right)
/*  97:    */   {
/*  98:114 */     LinearLayout.LayoutParams c = new LinearLayout.LayoutParams(-1, -2);
/*  99:115 */     c.setMargins(left, top, right, bottom);
/* 100:116 */     return c;
/* 101:    */   }
/* 102:    */   
/* 103:    */   public void addOneComponentToPanel(UIComponent panel, UIComponent component)
/* 104:    */   {
/* 105:121 */     Object constraints = component.getConstraints();
/* 106:122 */     if (constraints == null) {
/* 107:123 */       constraints = this.defaultConstraints;
/* 108:    */     }
/* 109:125 */     ((ViewGroup)panel).addView((View)component);
/* 110:    */   }
/* 111:    */   
/* 112:    */   public void addOneComponentToPanel(UIComponent panel, UIComponent component, Object constraints)
/* 113:    */   {
/* 114:130 */     if (constraints == null)
/* 115:    */     {
/* 116:131 */       addOneComponentToPanel(panel, component);
/* 117:    */     }
/* 118:    */     else
/* 119:    */     {
/* 120:133 */       component.setConstraints(constraints);
/* 121:134 */       this.mainPanel.addView((View)component);
/* 122:    */     }
/* 123:    */   }
/* 124:    */   
/* 125:    */   public Object createPageLevelConstraints(int top, int left, int bottom, int right)
/* 126:    */   {
/* 127:140 */     return new LinearLayout.LayoutParams(-1, -1);
/* 128:    */   }
/* 129:    */   
/* 130:    */   public void setPanelConstraints(UIComponent mainP, Object constraints)
/* 131:    */   {
/* 132:145 */     mainP.setConstraints(constraints);
/* 133:    */   }
/* 134:    */   
/* 135:    */   public Object getDefaultConstraints()
/* 136:    */   {
/* 137:150 */     return this.defaultConstraints;
/* 138:    */   }
/* 139:    */   
/* 140:    */   public void addComponentsAsOneRow(UIComponent[] comps, UIComponent panel, int cols)
/* 141:    */   {
/* 142:155 */     if (comps.length == 1)
/* 143:    */     {
/* 144:156 */       addOneComponentToPanel(panel, comps[0]);
/* 145:157 */       return;
/* 146:    */     }
/* 147:160 */     NPanel subpanel = (NPanel)createOnePanel(0);
/* 148:161 */     for (int col = 0; col < cols; col++)
/* 149:    */     {
/* 150:162 */       UIComponent component = comps[col];
/* 151:163 */       addOneComponentToPanel(subpanel, component);
/* 152:    */     }
/* 153:165 */     addOneComponentToPanel(panel, subpanel);
/* 154:    */   }
/* 155:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.ADSectionWidgetImpl
 * JD-Core Version:    0.7.0.1
 */