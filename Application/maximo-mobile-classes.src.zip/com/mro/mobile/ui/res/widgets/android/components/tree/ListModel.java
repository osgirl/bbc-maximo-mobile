package com.mro.mobile.ui.res.widgets.android.components.tree;

import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;

public abstract interface ListModel
{
  public abstract int getCount();
  
  public abstract Object getItem(int paramInt);
  
  public abstract long getItemId(int paramInt);
  
  public abstract View getView(int paramInt, View paramView, ViewGroup paramViewGroup);
  
  public abstract TreeModel getTreeModel();
  
  public abstract void onItemClick(AdapterView<?> paramAdapterView, View paramView, int paramInt, long paramLong);
  
  public abstract boolean onItemLongClick(AdapterView<?> paramAdapterView, View paramView, int paramInt, long paramLong);
  
  public abstract void itemSelection(Item paramItem);
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.components.tree.ListModel
 * JD-Core Version:    0.7.0.1
 */