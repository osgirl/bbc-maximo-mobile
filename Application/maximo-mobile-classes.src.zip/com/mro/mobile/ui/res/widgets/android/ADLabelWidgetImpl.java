/*  1:   */ package com.mro.mobile.ui.res.widgets.android;
/*  2:   */ 
/*  3:   */ import android.widget.LinearLayout.LayoutParams;
/*  4:   */ import com.mro.mobile.MobileApplicationException;
/*  5:   */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*  6:   */ import com.mro.mobile.ui.res.controls.LabelControl;
/*  7:   */ import com.mro.mobile.ui.res.widgets.android.components.NLabel;
/*  8:   */ import com.mro.mobile.ui.res.widgets.def.LabelWidget;
/*  9:   */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/* 10:   */ 
/* 11:   */ public class ADLabelWidgetImpl
/* 12:   */   extends ADAbstractWidgetImpl
/* 13:   */   implements LabelWidget
/* 14:   */ {
/* 15:28 */   private NLabel label = null;
/* 16:   */   
/* 17:   */   public void createLabelField(String labelText, Object styler, int width, boolean wrap)
/* 18:   */     throws MobileApplicationException
/* 19:   */   {
/* 20:31 */     this.label = NLabel.createByInflate(getLabelControl(), AndroidEnv.getCurrentActivity(), labelText, styler);
/* 21:32 */     this.label.setLayoutParams(new LinearLayout.LayoutParams(-2, -2));
/* 22:   */   }
/* 23:   */   
/* 24:   */   public LabelControl getLabelControl()
/* 25:   */   {
/* 26:36 */     return (LabelControl)getController();
/* 27:   */   }
/* 28:   */   
/* 29:   */   public UIComponent[] setLabelAttributes(AbstractMobileControl controller)
/* 30:   */     throws MobileApplicationException
/* 31:   */   {
/* 32:41 */     this.label.setCId(controller.getStringValue("id"));
/* 33:   */     
/* 34:43 */     UIComponent[] components = null;
/* 35:45 */     if (controller.isAttributeSet("backgroundcolor")) {
/* 36:47 */       this.label.setBackground((Integer)controller.getColorValue("backgroundcolor"));
/* 37:   */     }
/* 38:50 */     if (controller.isAttributeSet("foregroundcolor")) {
/* 39:52 */       this.label.setForeground((Integer)controller.getColorValue("foregroundcolor"));
/* 40:   */     }
/* 41:55 */     UIComponent[] tmpComp = { this.label };
/* 42:56 */     components = tmpComp;
/* 43:   */     
/* 44:58 */     return components;
/* 45:   */   }
/* 46:   */   
/* 47:   */   public void setText(String text)
/* 48:   */   {
/* 49:63 */     this.label.setText(text);
/* 50:   */   }
/* 51:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.ADLabelWidgetImpl
 * JD-Core Version:    0.7.0.1
 */