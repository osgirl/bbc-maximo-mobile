/*   1:    */ package com.mro.mobile.ui.res.widgets.android.components;
/*   2:    */ 
/*   3:    */ import android.content.Context;
/*   4:    */ import android.util.AttributeSet;
/*   5:    */ import android.view.View;
/*   6:    */ import android.widget.LinearLayout.LayoutParams;
/*   7:    */ import android.widget.TextView;
/*   8:    */ import com.ibm.tivoli.maximo.mobile.android.util.UIUtil;
/*   9:    */ import com.ibm.tivoli.maximo.mobile.resources.R.layout;
/*  10:    */ import com.ibm.tivoli.maximo.mobile.resources.R.style;
/*  11:    */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*  12:    */ import com.mro.mobile.ui.res.controls.LabelControl;
/*  13:    */ import com.mro.mobile.ui.res.controls.utils.ControlStyle;
/*  14:    */ import com.mro.mobile.ui.res.controls.utils.StyleManager;
/*  15:    */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  16:    */ import java.util.Enumeration;
/*  17:    */ 
/*  18:    */ public class NLabel
/*  19:    */   extends TextView
/*  20:    */   implements UIComponent
/*  21:    */ {
/*  22: 34 */   private EmsResolver emsResolver = null;
/*  23: 36 */   private static final int DEFAULT_XML_LAYOUT = UIUtil.getResourceId(R.layout.class, "nlabel");
/*  24:    */   public static final String STYLEKEY = "label";
/*  25:    */   
/*  26:    */   public static NLabel createByInflate(AbstractMobileControl control, Context context, Object text)
/*  27:    */   {
/*  28: 39 */     return createByInflate(DEFAULT_XML_LAYOUT, control, context, text, null);
/*  29:    */   }
/*  30:    */   
/*  31:    */   public static NLabel createByInflate(AbstractMobileControl control, Context context, Object text, Object styler)
/*  32:    */   {
/*  33: 43 */     return createByInflate(DEFAULT_XML_LAYOUT, control, context, text, styler);
/*  34:    */   }
/*  35:    */   
/*  36:    */   public static NLabel createByInflate(int layoutId, AbstractMobileControl control, Context context, Object text)
/*  37:    */   {
/*  38: 47 */     return createByInflate(layoutId, control, context, text, null);
/*  39:    */   }
/*  40:    */   
/*  41:    */   public static NLabel createByInflate(int layoutId, AbstractMobileControl control, Context context, Object text, Object styler)
/*  42:    */   {
/*  43: 51 */     NLabel label = (NLabel)View.inflate(context, layoutId, null);
/*  44: 52 */     label.postInstance(context, control, text, styler);
/*  45: 53 */     return label;
/*  46:    */   }
/*  47:    */   
/*  48: 57 */   private String cid = null;
/*  49: 59 */   private AbstractMobileControl controller = null;
/*  50:    */   
/*  51:    */   public NLabel(Context context)
/*  52:    */   {
/*  53: 62 */     super(context);
/*  54:    */   }
/*  55:    */   
/*  56:    */   public NLabel(Context context, AttributeSet attrs)
/*  57:    */   {
/*  58: 66 */     super(context, attrs);
/*  59:    */   }
/*  60:    */   
/*  61:    */   public NLabel(Context context, AttributeSet attrs, int defStyle)
/*  62:    */   {
/*  63: 70 */     super(context, attrs, defStyle);
/*  64:    */   }
/*  65:    */   
/*  66:    */   public void postInstance(Context context, AbstractMobileControl control, Object text, Object styler)
/*  67:    */   {
/*  68: 74 */     setController(control);
/*  69: 75 */     if (control != null)
/*  70:    */     {
/*  71: 76 */       if ((control instanceof LabelControl)) {
/*  72: 77 */         setId(NIDMapper.getAndroidIdFor(control.getId()));
/*  73:    */       } else {
/*  74: 79 */         setId(NIDMapper.getAndroidIdFor(control.getId() + "_label"));
/*  75:    */       }
/*  76:    */     }
/*  77:    */     else {
/*  78: 82 */       setId(NIDMapper.getNextId());
/*  79:    */     }
/*  80: 84 */     init();
/*  81: 85 */     setupLabel(context, text, control != null ? control.getStyle("label") : styler != null ? styler : null);
/*  82:    */   }
/*  83:    */   
/*  84:    */   private void setupLabel(Context context, Object text, Object styler)
/*  85:    */   {
/*  86: 89 */     if ((text instanceof String)) {
/*  87: 90 */       setText(calculateFinalTextValue((String)text));
/*  88:    */     }
/*  89: 92 */     applyStyle(styler);
/*  90:    */   }
/*  91:    */   
/*  92:    */   private String calculateFinalTextValue(String s)
/*  93:    */   {
/*  94: 96 */     String text = s;
/*  95: 97 */     if (s == null) {
/*  96: 98 */       text = "";
/*  97:    */     } else {
/*  98:101 */       text = text + " ";
/*  99:    */     }
/* 100:103 */     return text;
/* 101:    */   }
/* 102:    */   
/* 103:    */   public void applyStyle(Object styler)
/* 104:    */   {
/* 105:107 */     if (styler != null)
/* 106:    */     {
/* 107:108 */       ControlStyle style = null;
/* 108:109 */       if ((styler instanceof ControlStyle))
/* 109:    */       {
/* 110:110 */         style = (ControlStyle)styler;
/* 111:    */       }
/* 112:111 */       else if ((styler instanceof AbstractMobileControl))
/* 113:    */       {
/* 114:112 */         this.controller = ((AbstractMobileControl)styler);
/* 115:113 */         style = this.controller.getStyle("label");
/* 116:    */       }
/* 117:    */       else
/* 118:    */       {
/* 119:115 */         style = StyleManager.getStyle("label", null);
/* 120:    */       }
/* 121:118 */       String styleName = style.getStyleName();
/* 122:    */       
/* 123:120 */       int styleToApply = UIUtil.getResourceId(R.style.class, styleName);
/* 124:121 */       if (styleToApply != 0) {
/* 125:122 */         setTextAppearance(getContext(), styleToApply);
/* 126:    */       }
/* 127:    */     }
/* 128:    */   }
/* 129:    */   
/* 130:    */   public String getCId()
/* 131:    */   {
/* 132:128 */     return this.cid;
/* 133:    */   }
/* 134:    */   
/* 135:    */   public void setCId(String cid)
/* 136:    */   {
/* 137:132 */     this.cid = cid;
/* 138:    */   }
/* 139:    */   
/* 140:    */   public void init() {}
/* 141:    */   
/* 142:    */   public void addChildUIComponent(UIComponent child) {}
/* 143:    */   
/* 144:    */   public boolean canContainChildren()
/* 145:    */   {
/* 146:142 */     return false;
/* 147:    */   }
/* 148:    */   
/* 149:    */   public Enumeration getChildren()
/* 150:    */   {
/* 151:146 */     return null;
/* 152:    */   }
/* 153:    */   
/* 154:    */   public AbstractMobileControl getController()
/* 155:    */   {
/* 156:153 */     return this.controller;
/* 157:    */   }
/* 158:    */   
/* 159:    */   public void setController(AbstractMobileControl controller)
/* 160:    */   {
/* 161:161 */     this.controller = controller;
/* 162:    */   }
/* 163:    */   
/* 164:164 */   private LinearLayout.LayoutParams constraints = null;
/* 165:    */   
/* 166:    */   public Object getConstraints()
/* 167:    */   {
/* 168:172 */     return this.constraints;
/* 169:    */   }
/* 170:    */   
/* 171:    */   public void setConstraints(Object consts)
/* 172:    */   {
/* 173:183 */     this.constraints = ((LinearLayout.LayoutParams)consts);
/* 174:184 */     setLayoutParams(this.constraints);
/* 175:185 */     requestLayout();
/* 176:    */   }
/* 177:    */   
/* 178:    */   public void setBackground(Integer colorValue)
/* 179:    */   {
/* 180:189 */     if (colorValue != null)
/* 181:    */     {
/* 182:190 */       setBackgroundColor(colorValue.intValue());
/* 183:191 */       requestLayout();
/* 184:    */     }
/* 185:    */   }
/* 186:    */   
/* 187:    */   public void setForeground(Integer colorValue)
/* 188:    */   {
/* 189:196 */     if (colorValue != null)
/* 190:    */     {
/* 191:197 */       setTextColor(colorValue.intValue());
/* 192:198 */       requestLayout();
/* 193:    */     }
/* 194:    */   }
/* 195:    */   
/* 196:    */   public void setEmsResolver(EmsResolver resolver)
/* 197:    */   {
/* 198:203 */     this.emsResolver = resolver;
/* 199:    */   }
/* 200:    */   
/* 201:    */   protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec)
/* 202:    */   {
/* 203:209 */     if (this.emsResolver != null) {
/* 204:210 */       setEms(this.emsResolver.getEms());
/* 205:    */     }
/* 206:212 */     super.onMeasure(widthMeasureSpec, heightMeasureSpec);
/* 207:    */   }
/* 208:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.components.NLabel
 * JD-Core Version:    0.7.0.1
 */