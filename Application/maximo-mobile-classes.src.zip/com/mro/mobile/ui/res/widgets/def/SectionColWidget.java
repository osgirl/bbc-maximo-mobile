package com.mro.mobile.ui.res.widgets.def;

public abstract interface SectionColWidget
{
  public abstract void createSectionCol(String paramString1, String paramString2);
  
  public abstract void addComponent(UIComponent paramUIComponent);
  
  public abstract void setPadding(int paramInt1, int paramInt2);
  
  public abstract UIComponent[] resolveSectionColComponents();
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.def.SectionColWidget
 * JD-Core Version:    0.7.0.1
 */