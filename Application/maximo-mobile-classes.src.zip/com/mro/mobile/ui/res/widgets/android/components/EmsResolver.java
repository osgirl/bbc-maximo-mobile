package com.mro.mobile.ui.res.widgets.android.components;

public abstract interface EmsResolver
{
  public abstract int getEms();
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.components.EmsResolver
 * JD-Core Version:    0.7.0.1
 */