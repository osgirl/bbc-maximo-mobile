/*  1:   */ package com.mro.mobile.ui.res.widgets.android.components.table;
/*  2:   */ 
/*  3:   */ import android.content.Context;
/*  4:   */ import android.util.AttributeSet;
/*  5:   */ import android.widget.TableLayout;
/*  6:   */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*  7:   */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  8:   */ import java.util.Enumeration;
/*  9:   */ 
/* 10:   */ public class NTableBody
/* 11:   */   extends TableLayout
/* 12:   */   implements UIComponent
/* 13:   */ {
/* 14:   */   private AbstractMobileControl controller;
/* 15:   */   
/* 16:   */   public NTableBody(Context context)
/* 17:   */   {
/* 18:17 */     super(context);
/* 19:   */   }
/* 20:   */   
/* 21:   */   public NTableBody(Context context, AttributeSet attrs)
/* 22:   */   {
/* 23:21 */     super(context, attrs);
/* 24:   */   }
/* 25:   */   
/* 26:   */   public void setCId(String cid) {}
/* 27:   */   
/* 28:   */   public String getCId()
/* 29:   */   {
/* 30:30 */     return null;
/* 31:   */   }
/* 32:   */   
/* 33:   */   public void init() {}
/* 34:   */   
/* 35:   */   public void addChildUIComponent(UIComponent child) {}
/* 36:   */   
/* 37:   */   public boolean canContainChildren()
/* 38:   */   {
/* 39:43 */     return false;
/* 40:   */   }
/* 41:   */   
/* 42:   */   public Enumeration getChildren()
/* 43:   */   {
/* 44:48 */     return null;
/* 45:   */   }
/* 46:   */   
/* 47:   */   public AbstractMobileControl getController()
/* 48:   */   {
/* 49:53 */     return this.controller;
/* 50:   */   }
/* 51:   */   
/* 52:   */   public void setController(AbstractMobileControl controller)
/* 53:   */   {
/* 54:58 */     this.controller = controller;
/* 55:   */   }
/* 56:   */   
/* 57:   */   public Object getConstraints()
/* 58:   */   {
/* 59:63 */     return null;
/* 60:   */   }
/* 61:   */   
/* 62:   */   public void setConstraints(Object contstraints) {}
/* 63:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.components.table.NTableBody
 * JD-Core Version:    0.7.0.1
 */