package com.mro.mobile.ui.res.widgets.def;

import com.mro.mobile.MobileApplicationException;
import com.mro.mobile.ui.res.controls.AbstractMobileControl;

public abstract interface LabelWidget
  extends AbstractWidget
{
  public abstract void createLabelField(String paramString, Object paramObject, int paramInt, boolean paramBoolean)
    throws MobileApplicationException;
  
  public abstract UIComponent[] setLabelAttributes(AbstractMobileControl paramAbstractMobileControl)
    throws MobileApplicationException;
  
  public abstract void setText(String paramString);
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.def.LabelWidget
 * JD-Core Version:    0.7.0.1
 */