/*  1:   */ package com.mro.mobile.ui.res.widgets.android.components.tree;
/*  2:   */ 
/*  3:   */ import android.content.Context;
/*  4:   */ import android.util.AttributeSet;
/*  5:   */ import android.view.View;
/*  6:   */ import android.view.View.OnClickListener;
/*  7:   */ import android.widget.ImageView;
/*  8:   */ 
/*  9:   */ public class TreeIconView
/* 10:   */   extends ImageView
/* 11:   */ {
/* 12:   */   public int position;
/* 13:   */   
/* 14:   */   public TreeIconView(Context context)
/* 15:   */   {
/* 16:28 */     super(context);
/* 17:   */   }
/* 18:   */   
/* 19:   */   public TreeIconView(Context context, AttributeSet attrs)
/* 20:   */   {
/* 21:32 */     super(context, attrs);
/* 22:33 */     init();
/* 23:   */   }
/* 24:   */   
/* 25:   */   public TreeIconView(Context context, AttributeSet attrs, int defStyle)
/* 26:   */   {
/* 27:37 */     super(context, attrs, defStyle);
/* 28:   */   }
/* 29:   */   
/* 30:   */   private void init()
/* 31:   */   {
/* 32:41 */     setOnClickListener(new View.OnClickListener()
/* 33:   */     {
/* 34:   */       public void onClick(View v)
/* 35:   */       {
/* 36:44 */         if (TreeIconView.this.mTreeIconViewListener == null) {
/* 37:45 */           return;
/* 38:   */         }
/* 39:47 */         TreeIconView.this.mTreeIconViewListener.iconClicked(TreeIconView.this.position, v);
/* 40:   */       }
/* 41:   */     });
/* 42:   */   }
/* 43:   */   
/* 44:52 */   private IconClickable mTreeIconViewListener = null;
/* 45:   */   
/* 46:   */   public void setLineIconViewListener(IconClickable mTreeIconViewListener)
/* 47:   */   {
/* 48:59 */     this.mTreeIconViewListener = mTreeIconViewListener;
/* 49:   */   }
/* 50:   */   
/* 51:   */   public static abstract interface IconClickable
/* 52:   */   {
/* 53:   */     public abstract void iconClicked(int paramInt, View paramView);
/* 54:   */   }
/* 55:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.components.tree.TreeIconView
 * JD-Core Version:    0.7.0.1
 */