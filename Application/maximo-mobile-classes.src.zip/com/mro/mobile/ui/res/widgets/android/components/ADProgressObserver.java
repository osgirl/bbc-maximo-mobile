/*  1:   */ package com.mro.mobile.ui.res.widgets.android.components;
/*  2:   */ 
/*  3:   */ import com.ibm.tivoli.maximo.mobile.entrypoint.android.AndroidMobileAppEntryPoint;
/*  4:   */ import com.mro.mobile.ProgressObserver;
/*  5:   */ import com.mro.mobile.ProgressWindow;
/*  6:   */ 
/*  7:   */ public class ADProgressObserver
/*  8:   */   implements ProgressObserver
/*  9:   */ {
/* 10:22 */   private boolean stopped = false;
/* 11:24 */   private AndroidMobileAppEntryPoint<?> androidApplication = null;
/* 12:26 */   NPopUpDialog progressDailog = null;
/* 13:28 */   private Thread workerThread = null;
/* 14:   */   
/* 15:   */   public ADProgressObserver(NPopUpDialog progressDailog, AndroidMobileAppEntryPoint<?> androidApplication)
/* 16:   */   {
/* 17:31 */     this(progressDailog, null, androidApplication);
/* 18:   */   }
/* 19:   */   
/* 20:   */   public ADProgressObserver(NPopUpDialog progressDailog, String message, AndroidMobileAppEntryPoint<?> androidApplication)
/* 21:   */   {
/* 22:35 */     this.progressDailog = progressDailog;
/* 23:36 */     this.androidApplication = androidApplication;
/* 24:   */   }
/* 25:   */   
/* 26:   */   public boolean isWorkStopped()
/* 27:   */   {
/* 28:40 */     return this.stopped;
/* 29:   */   }
/* 30:   */   
/* 31:   */   public void updateWorkProgress() {}
/* 32:   */   
/* 33:   */   public void setWorkProgressMessage(final String note)
/* 34:   */   {
/* 35:48 */     this.androidApplication.runOnUiThread(new Runnable()
/* 36:   */     {
/* 37:   */       public void run()
/* 38:   */       {
/* 39:51 */         ADProgressObserver.this.progressDailog.setMessage(note);
/* 40:   */       }
/* 41:   */     });
/* 42:   */   }
/* 43:   */   
/* 44:   */   public void actionPerformed(Object src, Object data) {}
/* 45:   */   
/* 46:   */   public ProgressWindow getProgressWindow()
/* 47:   */   {
/* 48:67 */     return this.progressDailog;
/* 49:   */   }
/* 50:   */   
/* 51:   */   public void setBackgroundThread(Thread workerThread)
/* 52:   */   {
/* 53:71 */     this.workerThread = workerThread;
/* 54:72 */     if (this.progressDailog != null) {
/* 55:73 */       this.progressDailog.setBackgroundThread(workerThread);
/* 56:   */     }
/* 57:   */   }
/* 58:   */   
/* 59:   */   public Thread getBackgroundThread()
/* 60:   */   {
/* 61:78 */     return this.workerThread;
/* 62:   */   }
/* 63:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.components.ADProgressObserver
 * JD-Core Version:    0.7.0.1
 */