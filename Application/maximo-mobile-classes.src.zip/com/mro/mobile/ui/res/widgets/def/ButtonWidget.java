package com.mro.mobile.ui.res.widgets.def;

import com.mro.mobile.MobileApplicationException;

public abstract interface ButtonWidget
  extends AbstractWidget
{
  public abstract ButtonWidget createButtonField(String paramString1, String paramString2);
  
  public abstract UIComponent[] resolveButtonComponents()
    throws MobileApplicationException;
  
  public abstract Object getLinkValue();
  
  public abstract void setAttributeID(String paramString);
  
  public abstract void setAttributeValue(Object paramObject);
  
  public abstract void setAttributeTargetId(String paramString);
  
  public abstract void setAtrributeEvent(String paramString);
  
  public abstract void setDefaultButton(boolean paramBoolean);
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.def.ButtonWidget
 * JD-Core Version:    0.7.0.1
 */