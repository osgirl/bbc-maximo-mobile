package com.mro.mobile.ui.res.widgets.android;

import com.mro.mobile.ui.res.widgets.def.LookupWidget;

public class ADLookupWidgetImpl
  extends ADPageWidgetImpl
  implements LookupWidget
{}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.ADLookupWidgetImpl
 * JD-Core Version:    0.7.0.1
 */