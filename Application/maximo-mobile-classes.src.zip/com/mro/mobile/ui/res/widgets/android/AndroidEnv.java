/*  1:   */ package com.mro.mobile.ui.res.widgets.android;
/*  2:   */ 
/*  3:   */ import android.app.Activity;
/*  4:   */ import android.app.Dialog;
/*  5:   */ import com.ibm.tivoli.maximo.mobile.android.DefaultMaximoMobileActivity;
/*  6:   */ import com.mro.mobile.ui.res.widgets.android.components.NPopUpWindow;
/*  7:   */ import java.util.concurrent.atomic.AtomicReference;
/*  8:   */ 
/*  9:   */ public class AndroidEnv
/* 10:   */ {
/* 11:37 */   private AtomicReference<Activity> currentActivity = new AtomicReference();
/* 12:39 */   private AtomicReference<NPopUpWindow> popUpPage = new AtomicReference();
/* 13:41 */   private AtomicReference<Dialog> messageBox = new AtomicReference();
/* 14:46 */   private static AndroidEnv instance = new AndroidEnv();
/* 15:   */   
/* 16:   */   public static void removeActivity(Activity context)
/* 17:   */   {
/* 18:50 */     instance.currentActivity.set(null);
/* 19:   */   }
/* 20:   */   
/* 21:   */   public static void setCurrentActivity(Activity context)
/* 22:   */   {
/* 23:54 */     instance.currentActivity.set(context);
/* 24:   */   }
/* 25:   */   
/* 26:   */   public static Activity getCurrentActivity()
/* 27:   */   {
/* 28:58 */     return (Activity)instance.currentActivity.get();
/* 29:   */   }
/* 30:   */   
/* 31:   */   public static DefaultMaximoMobileActivity getCurrentActivityAsMobileActivity()
/* 32:   */   {
/* 33:62 */     return (DefaultMaximoMobileActivity)instance.currentActivity.get();
/* 34:   */   }
/* 35:   */   
/* 36:   */   public static void setPopUpPage(NPopUpWindow popUp)
/* 37:   */   {
/* 38:67 */     closeCurrentPopUpPage();
/* 39:68 */     instance.popUpPage.set(popUp);
/* 40:   */   }
/* 41:   */   
/* 42:   */   public static void closeCurrentPopUpPage()
/* 43:   */   {
/* 44:72 */     NPopUpWindow page = (NPopUpWindow)instance.popUpPage.getAndSet(null);
/* 45:73 */     if (page != null) {
/* 46:74 */       page.dismiss();
/* 47:   */     }
/* 48:   */   }
/* 49:   */   
/* 50:   */   public static void setMessageBox(Dialog dialog)
/* 51:   */   {
/* 52:79 */     closeCurrentMessageBox();
/* 53:80 */     instance.messageBox.set(dialog);
/* 54:   */   }
/* 55:   */   
/* 56:   */   public static void closeCurrentMessageBox()
/* 57:   */   {
/* 58:84 */     Dialog box = (Dialog)instance.messageBox.getAndSet(null);
/* 59:85 */     if (box != null) {
/* 60:86 */       box.dismiss();
/* 61:   */     }
/* 62:   */   }
/* 63:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.AndroidEnv
 * JD-Core Version:    0.7.0.1
 */