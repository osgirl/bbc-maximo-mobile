package com.mro.mobile.ui.res.widgets.def;

public abstract interface ToolBarContainerWidget
  extends AbstractWidget
{
  public abstract void setId(String paramString);
  
  public abstract void setBgImage(String paramString);
  
  public abstract void setLayout(int paramInt);
  
  public abstract void addComponent(UIComponent paramUIComponent);
  
  public abstract void addComponent(UIComponent paramUIComponent, String paramString);
  
  public abstract UIComponent[] resolveToolBarContainerComponents();
  
  public abstract void createToolBarContainer();
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.def.ToolBarContainerWidget
 * JD-Core Version:    0.7.0.1
 */