/*  1:   */ package com.mro.mobile.ui.res.widgets.android;
/*  2:   */ 
/*  3:   */ import com.mro.mobile.ui.res.widgets.android.components.NSignature;
/*  4:   */ import com.mro.mobile.ui.res.widgets.def.SignatureCaptureWidget;
/*  5:   */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  6:   */ 
/*  7:   */ public class ADSignatureWidgetImpl
/*  8:   */   extends ADAbstractWidgetImpl
/*  9:   */   implements SignatureCaptureWidget
/* 10:   */ {
/* 11:24 */   private NSignature signature = null;
/* 12:   */   
/* 13:   */   public UIComponent[] createSignatureCaptureWidget()
/* 14:   */   {
/* 15:28 */     this.signature = NSignature.createByInflate(getController(), AndroidEnv.getCurrentActivity());
/* 16:29 */     UIComponent[] retcomponent = { this.signature };
/* 17:30 */     return retcomponent;
/* 18:   */   }
/* 19:   */   
/* 20:   */   public byte[] getImageData()
/* 21:   */   {
/* 22:35 */     return this.signature.getImageData();
/* 23:   */   }
/* 24:   */   
/* 25:   */   public void erase()
/* 26:   */   {
/* 27:40 */     this.signature.clear();
/* 28:   */   }
/* 29:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.ADSignatureWidgetImpl
 * JD-Core Version:    0.7.0.1
 */