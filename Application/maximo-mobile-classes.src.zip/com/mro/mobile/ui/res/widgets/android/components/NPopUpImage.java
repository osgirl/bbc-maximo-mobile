/*   1:    */ package com.mro.mobile.ui.res.widgets.android.components;
/*   2:    */ 
/*   3:    */ import android.app.AlertDialog;
/*   4:    */ import android.app.AlertDialog.Builder;
/*   5:    */ import android.content.Context;
/*   6:    */ import android.content.DialogInterface;
/*   7:    */ import android.content.DialogInterface.OnClickListener;
/*   8:    */ import android.util.AttributeSet;
/*   9:    */ import android.view.View;
/*  10:    */ import android.view.View.OnClickListener;
/*  11:    */ import android.widget.ListAdapter;
/*  12:    */ import android.widget.ListView;
/*  13:    */ import com.ibm.tivoli.maximo.mobile.android.util.UIUtil;
/*  14:    */ import com.ibm.tivoli.maximo.mobile.android.widget.NMenuAdapter;
/*  15:    */ import com.ibm.tivoli.maximo.mobile.resources.R.layout;
/*  16:    */ import com.mro.mobile.MobileApplicationException;
/*  17:    */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*  18:    */ import com.mro.mobile.ui.res.controls.PopUpImageControl;
/*  19:    */ import com.mro.mobile.ui.res.controls.utils.ControlNodeData;
/*  20:    */ import com.mro.mobile.util.MobileLogger;
/*  21:    */ import com.mro.mobile.util.MobileLoggerFactory;
/*  22:    */ import java.util.Vector;
/*  23:    */ 
/*  24:    */ public class NPopUpImage
/*  25:    */   extends NImageButton
/*  26:    */ {
/*  27: 36 */   private NMenu mainMenu = null;
/*  28: 37 */   private boolean menuRendered = false;
/*  29: 38 */   private Vector controlNodeData = null;
/*  30: 39 */   private boolean refreshMenu = false;
/*  31:    */   private String title;
/*  32: 42 */   private static final int DEFAULT_XML_LAYOUT = UIUtil.getResourceId(R.layout.class, "npopupimage");
/*  33:    */   
/*  34:    */   public NPopUpImage(Context context)
/*  35:    */   {
/*  36: 48 */     super(context);
/*  37: 49 */     this.mainMenu = new NMenu(null, context);
/*  38:    */   }
/*  39:    */   
/*  40:    */   public NPopUpImage(Context context, AttributeSet attrs)
/*  41:    */   {
/*  42: 57 */     super(context, attrs);
/*  43: 58 */     this.mainMenu = new NMenu(null, context);
/*  44:    */   }
/*  45:    */   
/*  46:    */   public NPopUpImage(Context context, AttributeSet attrs, int defStyle)
/*  47:    */   {
/*  48: 67 */     super(context, attrs, defStyle);
/*  49: 68 */     this.mainMenu = new NMenu(null, context);
/*  50:    */   }
/*  51:    */   
/*  52:    */   public static NPopUpImage createByInflate(AbstractMobileControl control, Context context, String image)
/*  53:    */   {
/*  54: 73 */     return createByInflate(DEFAULT_XML_LAYOUT, control, context, image);
/*  55:    */   }
/*  56:    */   
/*  57:    */   public static NPopUpImage createByInflate(int layoutId, AbstractMobileControl control, Context context, String image)
/*  58:    */   {
/*  59: 77 */     NPopUpImage popUpImage = (NPopUpImage)View.inflate(context, layoutId, null);
/*  60: 78 */     popUpImage.postInstance(control, image);
/*  61: 79 */     return popUpImage;
/*  62:    */   }
/*  63:    */   
/*  64:    */   protected void postInstance(AbstractMobileControl control, String image)
/*  65:    */   {
/*  66: 83 */     super.postInstance(control, image, "");
/*  67:    */   }
/*  68:    */   
/*  69:    */   public void init()
/*  70:    */   {
/*  71: 88 */     setOnClickListener(new View.OnClickListener()
/*  72:    */     {
/*  73:    */       public void onClick(View v)
/*  74:    */       {
/*  75: 90 */         NPopUpImage.this.firePreListeners();
/*  76: 91 */         NPopUpImage.this.onClickCallback();
/*  77: 92 */         NPopUpImage.this.firePostListeners();
/*  78:    */       }
/*  79:    */     });
/*  80:    */   }
/*  81:    */   
/*  82:    */   public void setVisible(boolean visible)
/*  83:    */   {
/*  84: 98 */     setVisibility(visible ? 0 : 8);
/*  85:    */   }
/*  86:    */   
/*  87:    */   public NMenu getMainMenu()
/*  88:    */   {
/*  89:103 */     return this.mainMenu;
/*  90:    */   }
/*  91:    */   
/*  92:    */   public Vector getControlNodeData()
/*  93:    */   {
/*  94:107 */     return this.controlNodeData;
/*  95:    */   }
/*  96:    */   
/*  97:    */   public void setControlNodeData(Vector controlNodeData)
/*  98:    */   {
/*  99:111 */     this.controlNodeData = controlNodeData;
/* 100:112 */     if (this.mainMenu != null) {
/* 101:113 */       this.mainMenu.setControlNodeData(controlNodeData);
/* 102:    */     }
/* 103:    */   }
/* 104:    */   
/* 105:    */   public void refreshMenu()
/* 106:    */   {
/* 107:117 */     this.refreshMenu = true;
/* 108:    */   }
/* 109:    */   
/* 110:    */   public void cleanup()
/* 111:    */   {
/* 112:121 */     setController(null);
/* 113:122 */     this.mainMenu = null;
/* 114:    */   }
/* 115:    */   
/* 116:    */   private void showMenu()
/* 117:    */   {
/* 118:126 */     AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
/* 119:127 */     builder.setCancelable(true);
/* 120:128 */     if (this.title != null) {
/* 121:129 */       builder.setTitle(this.title);
/* 122:    */     }
/* 123:131 */     builder.setAdapter(new NMenuAdapter(getContext(), this.mainMenu), new DialogInterface.OnClickListener()
/* 124:    */     {
/* 125:    */       public void onClick(DialogInterface dialog, int clicked)
/* 126:    */       {
/* 127:134 */         AlertDialog myDialog = (AlertDialog)dialog;
/* 128:135 */         NMenu selectedMenu = (NMenu)myDialog.getListView().getAdapter().getItem(clicked);
/* 129:136 */         if ((selectedMenu instanceof NMenuItem))
/* 130:    */         {
/* 131:137 */           NMenuItem item = (NMenuItem)selectedMenu;
/* 132:138 */           item.handleMenuSelect();
/* 133:    */         }
/* 134:140 */         myDialog.dismiss();
/* 135:    */       }
/* 136:142 */     });
/* 137:143 */     AlertDialog alert = builder.create();
/* 138:144 */     alert.show();
/* 139:    */   }
/* 140:    */   
/* 141:    */   public void onClickCallback()
/* 142:    */   {
/* 143:148 */     if (!this.menuRendered)
/* 144:    */     {
/* 145:    */       try
/* 146:    */       {
/* 147:150 */         ((PopUpImageControl)getController()).renderMenu(this);
/* 148:151 */         this.menuRendered = true;
/* 149:    */       }
/* 150:    */       catch (MobileApplicationException e1)
/* 151:    */       {
/* 152:153 */         MobileLoggerFactory.getDefaultLogger().warn("Failed to render menu", e1);
/* 153:    */       }
/* 154:    */     }
/* 155:155 */     else if (this.refreshMenu)
/* 156:    */     {
/* 157:156 */       ((PopUpImageControl)getController()).refreshPopUpMenu(this);
/* 158:157 */       this.refreshMenu = false;
/* 159:    */     }
/* 160:160 */     if ((this.menuRendered) && (this.mainMenu != null)) {
/* 161:161 */       showMenuOrOpenFirstIfSingleItem();
/* 162:    */     }
/* 163:    */   }
/* 164:    */   
/* 165:    */   protected void showMenuOrOpenFirstIfSingleItem()
/* 166:    */   {
/* 167:166 */     Vector nodeData = getControlNodeData();
/* 168:167 */     if (nodeData != null) {
/* 169:168 */       if (nodeData.size() == 1)
/* 170:    */       {
/* 171:169 */         ControlNodeData data = (ControlNodeData)nodeData.get(0);
/* 172:170 */         AbstractMobileControl controller = data.getController();
/* 173:171 */         String event = data.getEvent();
/* 174:172 */         controller.handleEvent(event, null, null);
/* 175:    */       }
/* 176:    */       else
/* 177:    */       {
/* 178:175 */         showMenu();
/* 179:    */       }
/* 180:    */     }
/* 181:    */   }
/* 182:    */   
/* 183:    */   public void setTitle(String title)
/* 184:    */   {
/* 185:181 */     this.title = title;
/* 186:    */   }
/* 187:    */   
/* 188:    */   public String getTitle()
/* 189:    */   {
/* 190:185 */     return this.title;
/* 191:    */   }
/* 192:    */   
/* 193:192 */   private PopupImageClickable mPopupImageClickable = null;
/* 194:    */   
/* 195:    */   public void setPopupImageClickable(PopupImageClickable mPopupImageClickable)
/* 196:    */   {
/* 197:195 */     this.mPopupImageClickable = mPopupImageClickable;
/* 198:    */   }
/* 199:    */   
/* 200:    */   protected void firePreListeners()
/* 201:    */   {
/* 202:200 */     if (this.mPopupImageClickable != null) {
/* 203:201 */       this.mPopupImageClickable.popupImageClicked(this);
/* 204:    */     } else {
/* 205:204 */       super.firePreListeners();
/* 206:    */     }
/* 207:    */   }
/* 208:    */   
/* 209:    */   public static abstract interface PopupImageClickable
/* 210:    */   {
/* 211:    */     public abstract void popupImageClicked(View paramView);
/* 212:    */   }
/* 213:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.components.NPopUpImage
 * JD-Core Version:    0.7.0.1
 */