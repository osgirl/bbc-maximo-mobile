/*   1:    */ package com.mro.mobile.ui.res.widgets.android;
/*   2:    */ 
/*   3:    */ import android.graphics.Color;
/*   4:    */ import android.view.View;
/*   5:    */ import android.view.ViewGroup;
/*   6:    */ import android.widget.Button;
/*   7:    */ import android.widget.HorizontalScrollView;
/*   8:    */ import android.widget.LinearLayout.LayoutParams;
/*   9:    */ import android.widget.SlidingDrawer.OnDrawerCloseListener;
/*  10:    */ import android.widget.SlidingDrawer.OnDrawerOpenListener;
/*  11:    */ import com.ibm.tivoli.maximo.mobile.resources.R.drawable;
/*  12:    */ import com.ibm.tivoli.maximo.mobile.resources.R.id;
/*  13:    */ import com.mro.mobile.MobileApplicationException;
/*  14:    */ import com.mro.mobile.app.BasicMobileDeviceUIApplication;
/*  15:    */ import com.mro.mobile.ui.event.UIEvent;
/*  16:    */ import com.mro.mobile.ui.res.MobileUIManager;
/*  17:    */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*  18:    */ import com.mro.mobile.ui.res.controls.PageControl;
/*  19:    */ import com.mro.mobile.ui.res.widgets.android.components.NDrawer;
/*  20:    */ import com.mro.mobile.ui.res.widgets.android.components.NPanel;
/*  21:    */ import com.mro.mobile.ui.res.widgets.android.components.NRelativePanel;
/*  22:    */ import com.mro.mobile.ui.res.widgets.android.components.NScrollPan;
/*  23:    */ import com.mro.mobile.ui.res.widgets.def.PageWidget;
/*  24:    */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  25:    */ import java.util.ArrayList;
/*  26:    */ import java.util.Iterator;
/*  27:    */ 
/*  28:    */ public class ADPageWidgetImpl
/*  29:    */   extends ADAbstractWidgetImpl
/*  30:    */   implements PageWidget
/*  31:    */ {
/*  32: 46 */   private NPanel pagePanel = null;
/*  33: 47 */   private UIComponent centerPanel = null;
/*  34: 48 */   private NDrawer buttonDrawer = null;
/*  35: 49 */   private NScrollPan southPanel = null;
/*  36: 51 */   private NScrollPan centerScroll = null;
/*  37: 52 */   private Button slideButton = null;
/*  38:    */   private NPanel toolbar;
/*  39: 55 */   private View contentContainer = null;
/*  40: 57 */   private boolean usePanelLayout = false;
/*  41:    */   
/*  42:    */   protected void setController(PageControl controller)
/*  43:    */   {
/*  44: 60 */     super.setController(controller);
/*  45:    */   }
/*  46:    */   
/*  47:    */   protected PageControl getPageControl()
/*  48:    */   {
/*  49: 64 */     return (PageControl)getController();
/*  50:    */   }
/*  51:    */   
/*  52:    */   public UIComponent createPagePanel()
/*  53:    */   {
/*  54: 68 */     this.pagePanel = NPanel.createByInflate(getPageControl(), AndroidEnv.getCurrentActivity(), 1);
/*  55:    */     
/*  56: 70 */     this.pagePanel.setFocusableInTouchMode(true);
/*  57:    */     
/*  58:    */ 
/*  59: 73 */     this.usePanelLayout = getController().getBooleanValue("usepanellayout");
/*  60:    */     
/*  61: 75 */     return this.pagePanel;
/*  62:    */   }
/*  63:    */   
/*  64:    */   public void setOpaque(boolean opaque)
/*  65:    */   {
/*  66: 79 */     this.pagePanel.setOpaque(opaque);
/*  67:    */   }
/*  68:    */   
/*  69:    */   public void setId(String id)
/*  70:    */   {
/*  71: 83 */     this.pagePanel.setCId(id);
/*  72:    */   }
/*  73:    */   
/*  74:    */   public void setBackgroundColor(String img)
/*  75:    */   {
/*  76: 87 */     if (img != null) {
/*  77: 88 */       this.pagePanel.setBackgroundImage(img);
/*  78:    */     } else {
/*  79: 90 */       this.pagePanel.setBackground(-1);
/*  80:    */     }
/*  81:    */   }
/*  82:    */   
/*  83:    */   public void setDefaultPageLayout()
/*  84:    */   {
/*  85: 95 */     this.pagePanel.setConstraints(new LinearLayout.LayoutParams(-1, -1));
/*  86:    */   }
/*  87:    */   
/*  88:    */   public void addToolbarComponents(UIComponent[] comp)
/*  89:    */   {
/*  90: 99 */     this.toolbar = NPanel.createByInflate(getPageControl(), AndroidEnv.getCurrentActivity(), 0);
/*  91:    */     
/*  92:    */ 
/*  93:102 */     LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-2, -2);
/*  94:103 */     this.toolbar.setLayoutParams(params);
/*  95:104 */     this.toolbar.setMinimumHeight(com.ibm.tivoli.maximo.mobile.android.util.UIUtil.convertDIPtoPixels(55));
/*  96:    */     
/*  97:106 */     this.toolbar.setPadding(0, 0, 0, 0);
/*  98:107 */     addToolBarToContainer(comp[0]);
/*  99:    */     
/* 100:109 */     HorizontalScrollView hsv = new HorizontalScrollView(AndroidEnv.getCurrentActivity());
/* 101:110 */     hsv.setFillViewport(true);
/* 102:111 */     hsv.setHorizontalScrollBarEnabled(true);
/* 103:112 */     hsv.addView(this.toolbar);
/* 104:    */     
/* 105:    */ 
/* 106:    */ 
/* 107:116 */     hsv.setBackgroundResource(com.ibm.tivoli.maximo.mobile.android.util.UIUtil.getResourceId(R.drawable.class, "ntoolbar_background"));
/* 108:    */     
/* 109:118 */     this.pagePanel.addView(hsv);
/* 110:    */   }
/* 111:    */   
/* 112:    */   public void createCenterPanel()
/* 113:    */   {
/* 114:122 */     if (this.usePanelLayout)
/* 115:    */     {
/* 116:123 */       this.centerPanel = NPanel.createByInflate(getPageControl(), AndroidEnv.getCurrentActivity(), 1);
/* 117:124 */       ((NPanel)this.centerPanel).setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
/* 118:    */     }
/* 119:    */     else
/* 120:    */     {
/* 121:126 */       this.centerPanel = NRelativePanel.createByInflate(getPageControl(), AndroidEnv.getCurrentActivity(), -1);
/* 122:    */     }
/* 123:    */   }
/* 124:    */   
/* 125:    */   public void setDefaultCenterLayout()
/* 126:    */   {
/* 127:131 */     LinearLayout.LayoutParams conts = new LinearLayout.LayoutParams(-1, -1);
/* 128:132 */     String valign = getPageControl().getStringValue("valign");
/* 129:133 */     String align = getPageControl().getStringValue("align");
/* 130:134 */     boolean centerVertical = (valign != null) && (valign.equalsIgnoreCase("center"));
/* 131:135 */     boolean center = (align != null) && (align.equalsIgnoreCase("center"));
/* 132:136 */     if (centerVertical) {
/* 133:137 */       conts.gravity = 16;
/* 134:    */     }
/* 135:139 */     if (center) {
/* 136:140 */       conts.gravity = 17;
/* 137:    */     }
/* 138:142 */     if ((!center) && (!centerVertical)) {
/* 139:143 */       conts.gravity = 48;
/* 140:    */     }
/* 141:145 */     this.centerPanel.setConstraints(conts);
/* 142:146 */     if (this.usePanelLayout) {
/* 143:147 */       ((NPanel)this.centerPanel).setGravity(conts.gravity);
/* 144:    */     } else {
/* 145:149 */       ((NRelativePanel)this.centerPanel).setGravity(conts.gravity);
/* 146:    */     }
/* 147:    */   }
/* 148:    */   
/* 149:    */   public void addChildComponentsToCenterPanel(UIComponent[] components)
/* 150:    */   {
/* 151:155 */     addChildComponentsToCenterPanel(components[0]);
/* 152:    */   }
/* 153:    */   
/* 154:    */   private void addChildComponentsToCenterPanel(UIComponent component)
/* 155:    */   {
/* 156:159 */     this.centerScroll = NScrollPan.createByInflate(getPageControl(), AndroidEnv.getCurrentActivity(), (View)component);
/* 157:160 */     LinearLayout.LayoutParams conts = new LinearLayout.LayoutParams(-1, -1);
/* 158:161 */     String valign = getPageControl().getStringValue("valign");
/* 159:162 */     String align = getPageControl().getStringValue("align");
/* 160:163 */     boolean centerVertical = (valign != null) && (valign.equalsIgnoreCase("center"));
/* 161:164 */     boolean center = (align != null) && (align.equalsIgnoreCase("center"));
/* 162:166 */     if (centerVertical) {
/* 163:167 */       conts.gravity = 16;
/* 164:    */     }
/* 165:169 */     if (center) {
/* 166:170 */       conts.gravity = 17;
/* 167:    */     }
/* 168:172 */     if ((!center) && (!centerVertical)) {
/* 169:173 */       conts.gravity = 48;
/* 170:    */     }
/* 171:175 */     this.centerScroll.setConstraints(conts);
/* 172:176 */     this.centerScroll.setBackgroundColor(Color.alpha(0));
/* 173:    */   }
/* 174:    */   
/* 175:    */   public UIComponent addControlsToPanel(ArrayList controls)
/* 176:    */   {
/* 177:180 */     NRelativePanel panel = NRelativePanel.createByInflate(getPageControl(), AndroidEnv.getCurrentActivity(), -1);
/* 178:181 */     LinearLayout.LayoutParams conts = new LinearLayout.LayoutParams(-1, -1);
/* 179:182 */     panel.setLayoutParams(conts);
/* 180:    */     
/* 181:184 */     boolean centerSet = false;
/* 182:185 */     ArrayList drawerControls = null;
/* 183:    */     
/* 184:187 */     Iterator nItr = controls.iterator();
/* 185:188 */     if (nItr != null)
/* 186:    */     {
/* 187:190 */       NPanel container = createContainerPanel();
/* 188:192 */       while (nItr.hasNext())
/* 189:    */       {
/* 190:194 */         AbstractMobileControl control = (AbstractMobileControl)nItr.next();
/* 191:197 */         if ((centerSet) && ((control instanceof PageControl))) {
/* 192:198 */           centerSet = false;
/* 193:    */         }
/* 194:201 */         if (!centerSet)
/* 195:    */         {
/* 196:203 */           UIComponent[] components = control.getComponents();
/* 197:204 */           for (int x = 0; x < components.length; x++) {
/* 198:206 */             container.addView((View)components[x]);
/* 199:    */           }
/* 200:208 */           centerSet = true;
/* 201:    */         }
/* 202:    */         else
/* 203:    */         {
/* 204:210 */           if (drawerControls == null) {
/* 205:211 */             drawerControls = new ArrayList();
/* 206:    */           }
/* 207:212 */           drawerControls.add(control);
/* 208:    */         }
/* 209:    */       }
/* 210:216 */       panel.addView(container);
/* 211:    */       
/* 212:218 */       setContentContainer(container);
/* 213:220 */       if (drawerControls != null)
/* 214:    */       {
/* 215:222 */         addControlsToSouthPanel(drawerControls);
/* 216:    */         
/* 217:    */ 
/* 218:225 */         updateContentContainerSize();
/* 219:226 */         panel.addView(this.buttonDrawer);
/* 220:    */       }
/* 221:    */     }
/* 222:229 */     return panel;
/* 223:    */   }
/* 224:    */   
/* 225:    */   private NPanel createContainerPanel()
/* 226:    */   {
/* 227:233 */     NPanel container = NPanel.createByInflate(getPageControl(), AndroidEnv.getCurrentActivity(), 1);
/* 228:234 */     LinearLayout.LayoutParams containerConts = new LinearLayout.LayoutParams(-1, -1);
/* 229:235 */     containerConts.setMargins(0, 0, 0, 0);
/* 230:236 */     container.setConstraints(containerConts);
/* 231:    */     
/* 232:238 */     return container;
/* 233:    */   }
/* 234:    */   
/* 235:    */   public void addControlsToSouthPanel(ArrayList controls)
/* 236:    */   {
/* 237:243 */     Iterator nItr = controls.iterator();
/* 238:244 */     if (nItr != null)
/* 239:    */     {
/* 240:246 */       createDrawerPanel();
/* 241:248 */       while (nItr.hasNext())
/* 242:    */       {
/* 243:250 */         AbstractMobileControl control = (AbstractMobileControl)nItr.next();
/* 244:251 */         UIComponent[] components = control.getComponents();
/* 245:252 */         for (int x = 0; x < components.length; x++) {
/* 246:254 */           this.southPanel.addView((View)components[x]);
/* 247:    */         }
/* 248:    */       }
/* 249:    */     }
/* 250:    */   }
/* 251:    */   
/* 252:    */   private void createDrawerPanel()
/* 253:    */   {
/* 254:262 */     this.buttonDrawer = NDrawer.createByInflate(getPageControl(), AndroidEnv.getCurrentActivity());
/* 255:263 */     this.buttonDrawer.setBackgroundColor(-1);
/* 256:    */     
/* 257:265 */     this.slideButton = ((Button)this.buttonDrawer.findViewById(com.ibm.tivoli.maximo.mobile.android.util.UIUtil.getResourceId(R.id.class, "slideButton")));
/* 258:    */     
/* 259:267 */     this.buttonDrawer.setOnDrawerOpenListener(new SlidingDrawer.OnDrawerOpenListener()
/* 260:    */     {
/* 261:    */       public void onDrawerOpened()
/* 262:    */       {
/* 263:270 */         ADPageWidgetImpl.this.getContentContainer().setVisibility(4);
/* 264:    */       }
/* 265:273 */     });
/* 266:274 */     this.buttonDrawer.setOnDrawerCloseListener(new SlidingDrawer.OnDrawerCloseListener()
/* 267:    */     {
/* 268:    */       public void onDrawerClosed()
/* 269:    */       {
/* 270:277 */         ADPageWidgetImpl.this.getContentContainer().setVisibility(0);
/* 271:    */       }
/* 272:280 */     });
/* 273:281 */     this.southPanel = ((NScrollPan)this.buttonDrawer.findViewById(com.ibm.tivoli.maximo.mobile.android.util.UIUtil.getResourceId(R.id.class, "scrollViewPanel")));
/* 274:    */   }
/* 275:    */   
/* 276:    */   public void setSouthPanelTopBorders() {}
/* 277:    */   
/* 278:    */   public void addSouthPanelToCenterPanel()
/* 279:    */   {
/* 280:289 */     ((ViewGroup)this.centerPanel).addView(this.buttonDrawer);
/* 281:    */     
/* 282:    */ 
/* 283:292 */     updateContentContainerSize();
/* 284:    */   }
/* 285:    */   
/* 286:    */   private void updateContentContainerSize()
/* 287:    */   {
/* 288:296 */     this.slideButton.measure(0, 0);
/* 289:297 */     getContentContainer().setPadding(0, 0, 0, this.slideButton.getMeasuredHeight() + 5);
/* 290:    */   }
/* 291:    */   
/* 292:    */   public void addCenterPanelToPagePanel()
/* 293:    */   {
/* 294:301 */     ((ViewGroup)this.centerPanel).addView(this.centerScroll);
/* 295:    */     
/* 296:    */ 
/* 297:304 */     setContentContainer(this.centerScroll);
/* 298:    */     
/* 299:306 */     this.pagePanel.addView((View)this.centerPanel);
/* 300:    */   }
/* 301:    */   
/* 302:    */   public void addPanelToPagePanel(UIComponent panel)
/* 303:    */   {
/* 304:310 */     this.pagePanel.addView((View)panel);
/* 305:    */   }
/* 306:    */   
/* 307:    */   private View getContentContainer()
/* 308:    */   {
/* 309:314 */     return this.contentContainer;
/* 310:    */   }
/* 311:    */   
/* 312:    */   private void setContentContainer(View c)
/* 313:    */   {
/* 314:318 */     this.contentContainer = c;
/* 315:    */   }
/* 316:    */   
/* 317:    */   public boolean move(String eventType)
/* 318:    */   {
/* 319:322 */     return true;
/* 320:    */   }
/* 321:    */   
/* 322:    */   public void removeFromToolBarContainer(UIComponent comp)
/* 323:    */   {
/* 324:326 */     this.toolbar.removeAllViews();
/* 325:    */   }
/* 326:    */   
/* 327:    */   public void addToolBarToContainer(UIComponent comp)
/* 328:    */   {
/* 329:330 */     this.toolbar.addView((View)comp);
/* 330:    */   }
/* 331:    */   
/* 332:    */   public void setPageFocus(PageControl page) {}
/* 333:    */   
/* 334:    */   public boolean barcoderead(UIEvent event)
/* 335:    */     throws MobileApplicationException
/* 336:    */   {
/* 337:383 */     UIComponent component = com.mro.mobile.ui.res.UIUtil.getApplication().getMobileUIManager().getFocusOwner();
/* 338:384 */     if (component != null)
/* 339:    */     {
/* 340:385 */       AbstractMobileControl tCtrl = component.getController();
/* 341:386 */       if ((tCtrl != null) && (tCtrl.barCodingEnabled())) {
/* 342:387 */         return tCtrl.handleEvent(event);
/* 343:    */       }
/* 344:    */     }
/* 345:391 */     return false;
/* 346:    */   }
/* 347:    */   
/* 348:    */   public void setEnabled(boolean b)
/* 349:    */   {
/* 350:395 */     this.pagePanel.setEnabled(b);
/* 351:    */   }
/* 352:    */   
/* 353:    */   public UIComponent getPagePanel()
/* 354:    */   {
/* 355:399 */     return this.pagePanel;
/* 356:    */   }
/* 357:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.ADPageWidgetImpl
 * JD-Core Version:    0.7.0.1
 */