/*  1:   */ package com.mro.mobile.ui.res.widgets.android.components.table;
/*  2:   */ 
/*  3:   */ import android.view.View;
/*  4:   */ import com.mro.mobile.ui.event.UIEvent;
/*  5:   */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*  6:   */ import com.mro.mobile.ui.res.controls.TableControl;
/*  7:   */ import com.mro.mobile.ui.res.widgets.android.components.NCheckBox;
/*  8:   */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  9:   */ 
/* 10:   */ public class NTableListenerManager
/* 11:   */ {
/* 12:33 */   private static NTableListenerManager instance = null;
/* 13:   */   
/* 14:   */   public static synchronized NTableListenerManager instance()
/* 15:   */   {
/* 16:36 */     if (instance == null) {
/* 17:37 */       instance = new NTableListenerManager();
/* 18:   */     }
/* 19:39 */     return instance;
/* 20:   */   }
/* 21:   */   
/* 22:   */   public boolean isWidgetControlInTable(AbstractMobileControl control)
/* 23:   */   {
/* 24:48 */     if (control == null) {
/* 25:49 */       return false;
/* 26:   */     }
/* 27:51 */     if ((control instanceof TableControl)) {
/* 28:52 */       return true;
/* 29:   */     }
/* 30:54 */     return isWidgetControlInTable(control.getParentControl());
/* 31:   */   }
/* 32:   */   
/* 33:   */   public TableClickable getTableClickable()
/* 34:   */   {
/* 35:62 */     new TableClickable()
/* 36:   */     {
/* 37:64 */       private View originalView = null;
/* 38:66 */       private TableControl tableControl = null;
/* 39:   */       
/* 40:   */       public void tableClicked(View view)
/* 41:   */       {
/* 42:70 */         this.originalView = view;
/* 43:   */         
/* 44:72 */         runHierarchyBackToTableRow(view);
/* 45:74 */         if ((this.originalView instanceof NCheckBox))
/* 46:   */         {
/* 47:75 */           NCheckBox nCheckBox = (NCheckBox)this.originalView;
/* 48:76 */           nCheckBox.requestFocus();
/* 49:   */           
/* 50:78 */           UIEvent uiEvent = new UIEvent(nCheckBox.getController(), nCheckBox.getEvent() == null ? "setvalue" : nCheckBox.getEvent(), null, nCheckBox.getState() + "");
/* 51:79 */           nCheckBox.getController().handleEvent(uiEvent);
/* 52:   */         }
/* 53:   */       }
/* 54:   */       
/* 55:   */       public void runHierarchyBackToTableRow(View view)
/* 56:   */       {
/* 57:85 */         if ((view == null) || (!(view instanceof UIComponent))) {
/* 58:86 */           return;
/* 59:   */         }
/* 60:88 */         if ((view instanceof NTableRow)) {
/* 61:   */           try
/* 62:   */           {
/* 63:90 */             ((NTableRow)view).publishRowInfoToTable(); return;
/* 64:   */           }
/* 65:   */           finally
/* 66:   */           {
/* 67:94 */             this.tableControl = ((TableControl)((NTableBody)view.getParent()).getController());
/* 68:   */           }
/* 69:   */         }
/* 70:98 */         View parent = (View)view.getParent();
/* 71:99 */         if (parent != null) {
/* 72::0 */           runHierarchyBackToTableRow(parent);
/* 73:   */         }
/* 74:   */       }
/* 75:   */     };
/* 76:   */   }
/* 77:   */   
/* 78:   */   public static abstract interface TableClickable
/* 79:   */   {
/* 80:   */     public abstract void tableClicked(View paramView);
/* 81:   */   }
/* 82:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.components.table.NTableListenerManager
 * JD-Core Version:    0.7.0.1
 */