package com.mro.mobile.ui.res.widgets.def;

import com.mro.mobile.MobileApplicationException;
import com.mro.mobile.ui.MobileMboDataBean;
import com.mro.mobile.ui.res.controls.AbstractMobileControl;

public abstract interface AbstractWidget
{
  public abstract void setUIComponentVisible(UIComponent paramUIComponent, boolean paramBoolean);
  
  public abstract void setController(AbstractMobileControl paramAbstractMobileControl);
  
  public abstract UIComponent createDataPanel(AbstractMobileControl paramAbstractMobileControl, String paramString1, String paramString2, String paramString3, MobileMboDataBean paramMobileMboDataBean, Object paramObject)
    throws MobileApplicationException;
  
  public abstract Object createColor(int paramInt1, int paramInt2, int paramInt3);
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.def.AbstractWidget
 * JD-Core Version:    0.7.0.1
 */