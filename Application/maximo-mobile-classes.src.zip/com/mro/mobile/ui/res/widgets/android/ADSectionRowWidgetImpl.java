/*  1:   */ package com.mro.mobile.ui.res.widgets.android;
/*  2:   */ 
/*  3:   */ import android.view.View;
/*  4:   */ import android.widget.LinearLayout.LayoutParams;
/*  5:   */ import com.mro.mobile.ui.res.controls.SectionRowControl;
/*  6:   */ import com.mro.mobile.ui.res.widgets.android.components.NPanel;
/*  7:   */ import com.mro.mobile.ui.res.widgets.def.SectionRowWidget;
/*  8:   */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  9:   */ 
/* 10:   */ public class ADSectionRowWidgetImpl
/* 11:   */   extends ADAbstractWidgetImpl
/* 12:   */   implements SectionRowWidget
/* 13:   */ {
/* 14:28 */   private NPanel rowPanel = null;
/* 15:   */   
/* 16:   */   protected SectionRowControl getSectionRowControl()
/* 17:   */   {
/* 18:31 */     return (SectionRowControl)getController();
/* 19:   */   }
/* 20:   */   
/* 21:   */   public void createSectionRow(String id)
/* 22:   */   {
/* 23:36 */     this.rowPanel = NPanel.createByInflate(getSectionRowControl(), AndroidEnv.getCurrentActivity(), 0);
/* 24:37 */     this.rowPanel.setCId(id);
/* 25:   */   }
/* 26:   */   
/* 27:   */   public void initializeLayout(int numCols)
/* 28:   */   {
/* 29:42 */     LinearLayout.LayoutParams sectionConstraints = new LinearLayout.LayoutParams(-2, -2);
/* 30:43 */     sectionConstraints.setMargins(0, 0, 0, 0);
/* 31:44 */     this.rowPanel.setConstraints(sectionConstraints);
/* 32:   */   }
/* 33:   */   
/* 34:   */   public void setLayoutConstraints(int paddingTop, int indent)
/* 35:   */   {
/* 36:49 */     LinearLayout.LayoutParams sectionConstraints = new LinearLayout.LayoutParams(-2, -2);
/* 37:50 */     sectionConstraints.setMargins(indent, paddingTop, 0, 0);
/* 38:51 */     this.rowPanel.setConstraints(sectionConstraints);
/* 39:   */   }
/* 40:   */   
/* 41:   */   public void addComponent(UIComponent component)
/* 42:   */   {
/* 43:57 */     this.rowPanel.addView((View)component);
/* 44:   */   }
/* 45:   */   
/* 46:   */   public void addComponentWithDefaultLayoutConstraints(UIComponent component)
/* 47:   */   {
/* 48:62 */     LinearLayout.LayoutParams defaultConstraints = new LinearLayout.LayoutParams(-2, -2);
/* 49:63 */     defaultConstraints.setMargins(0, 0, 0, 0);
/* 50:65 */     if (component.getConstraints() == null) {
/* 51:66 */       component.setConstraints(defaultConstraints);
/* 52:   */     }
/* 53:69 */     this.rowPanel.addView((View)component);
/* 54:   */   }
/* 55:   */   
/* 56:   */   public UIComponent[] resolveSectionRowComponents()
/* 57:   */   {
/* 58:74 */     return new UIComponent[] { this.rowPanel };
/* 59:   */   }
/* 60:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.ADSectionRowWidgetImpl
 * JD-Core Version:    0.7.0.1
 */