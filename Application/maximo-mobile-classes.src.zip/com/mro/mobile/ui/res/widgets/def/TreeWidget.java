package com.mro.mobile.ui.res.widgets.def;

import com.mro.mobile.MobileApplicationException;
import com.mro.mobile.ui.res.controls.AbstractMobileControl;
import com.mro.mobile.ui.res.controls.utils.TreeNodeData;
import java.util.Hashtable;

public abstract interface TreeWidget
  extends AbstractWidget
{
  public abstract UIComponent[] createBaseTree(String paramString, AbstractMobileControl paramAbstractMobileControl)
    throws MobileApplicationException;
  
  public abstract void selectTreeRoot();
  
  public abstract TreeNodeData getSelectedTreeNodeData(Object paramObject);
  
  public abstract void addElementToBranchTree(Object paramObject1, Object paramObject2, int paramInt);
  
  public abstract void buildBaseTreeModel()
    throws MobileApplicationException;
  
  public abstract Hashtable getActualIndex();
  
  public abstract void removeChildren();
  
  public abstract boolean isTreeValid();
  
  public abstract Object getSelectedItem();
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.def.TreeWidget
 * JD-Core Version:    0.7.0.1
 */