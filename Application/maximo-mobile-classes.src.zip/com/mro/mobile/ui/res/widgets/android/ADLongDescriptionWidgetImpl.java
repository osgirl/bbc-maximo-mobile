/*  1:   */ package com.mro.mobile.ui.res.widgets.android;
/*  2:   */ 
/*  3:   */ import android.widget.LinearLayout.LayoutParams;
/*  4:   */ import com.mro.mobile.MobileApplicationException;
/*  5:   */ import com.mro.mobile.ui.res.controls.LongDescription;
/*  6:   */ import com.mro.mobile.ui.res.widgets.android.components.NTextField;
/*  7:   */ import com.mro.mobile.ui.res.widgets.android.components.NTextFieldMLL;
/*  8:   */ import com.mro.mobile.ui.res.widgets.def.LongDescriptionWidget;
/*  9:   */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/* 10:   */ 
/* 11:   */ public class ADLongDescriptionWidgetImpl
/* 12:   */   extends ADMultiLineTextboxWidgetImpl
/* 13:   */   implements LongDescriptionWidget
/* 14:   */ {
/* 15:   */   protected void setController(LongDescription controller)
/* 16:   */   {
/* 17:32 */     super.setController(controller);
/* 18:   */   }
/* 19:   */   
/* 20:   */   protected LongDescription getLongDescriptionControl()
/* 21:   */   {
/* 22:36 */     return (LongDescription)getController();
/* 23:   */   }
/* 24:   */   
/* 25:   */   public ADLongDescriptionWidgetImpl() {}
/* 26:   */   
/* 27:   */   public ADLongDescriptionWidgetImpl(LongDescription control)
/* 28:   */   {
/* 29:43 */     setController(control);
/* 30:   */   }
/* 31:   */   
/* 32:   */   public UIComponent[] resolveLongDescriptionComponents(String textToSet, int width, boolean readonly)
/* 33:   */     throws MobileApplicationException
/* 34:   */   {
/* 35:48 */     this.textField = new NTextFieldMLL(getTextboxControl(), AndroidEnv.getCurrentActivity(), textToSet, 0, width, 2);
/* 36:49 */     this.textField.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
/* 37:   */     
/* 38:51 */     this.textField.setText(textToSet);
/* 39:52 */     this.textField.setCId(getLongDescriptionControl().getStringValue("id"));
/* 40:   */     
/* 41:   */ 
/* 42:   */ 
/* 43:56 */     this.textField.setLines(40);
/* 44:57 */     this.textField.setGravity(51);
/* 45:59 */     if (readonly) {
/* 46:61 */       this.textField.setKeyListener(null);
/* 47:   */     }
/* 48:64 */     UIComponent[] ret = { this.textField };
/* 49:65 */     return ret;
/* 50:   */   }
/* 51:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.ADLongDescriptionWidgetImpl
 * JD-Core Version:    0.7.0.1
 */