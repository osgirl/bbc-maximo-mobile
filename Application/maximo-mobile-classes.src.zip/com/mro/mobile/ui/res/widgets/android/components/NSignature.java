/*   1:    */ package com.mro.mobile.ui.res.widgets.android.components;
/*   2:    */ 
/*   3:    */ import android.content.Context;
/*   4:    */ import android.graphics.Bitmap;
/*   5:    */ import android.graphics.Bitmap.CompressFormat;
/*   6:    */ import android.graphics.Bitmap.Config;
/*   7:    */ import android.graphics.Canvas;
/*   8:    */ import android.graphics.Paint;
/*   9:    */ import android.graphics.Paint.Join;
/*  10:    */ import android.graphics.Paint.Style;
/*  11:    */ import android.graphics.Path;
/*  12:    */ import android.graphics.RectF;
/*  13:    */ import android.util.AttributeSet;
/*  14:    */ import android.view.MotionEvent;
/*  15:    */ import android.view.View;
/*  16:    */ import android.view.ViewGroup.LayoutParams;
/*  17:    */ import com.ibm.tivoli.maximo.mobile.android.util.UIUtil;
/*  18:    */ import com.ibm.tivoli.maximo.mobile.resources.R.layout;
/*  19:    */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*  20:    */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  21:    */ import com.mro.mobile.util.MobileLogger;
/*  22:    */ import com.mro.mobile.util.MobileLoggerFactory;
/*  23:    */ import java.io.BufferedOutputStream;
/*  24:    */ import java.io.ByteArrayOutputStream;
/*  25:    */ import java.util.Enumeration;
/*  26:    */ 
/*  27:    */ public class NSignature
/*  28:    */   extends View
/*  29:    */   implements UIComponent
/*  30:    */ {
/*  31: 40 */   private static final int DEFAULT_XML_LAYOUT = UIUtil.getResourceId(R.layout.class, "nsignature");
/*  32:    */   private static final float STROKE_WIDTH = 5.0F;
/*  33:    */   private static final float HALF_STROKE_WIDTH = 2.5F;
/*  34:    */   
/*  35:    */   public static NSignature createByInflate(AbstractMobileControl control, Context context)
/*  36:    */   {
/*  37: 43 */     return createByInflate(DEFAULT_XML_LAYOUT, control, context);
/*  38:    */   }
/*  39:    */   
/*  40:    */   public static NSignature createByInflate(int layoutId, AbstractMobileControl control, Context context)
/*  41:    */   {
/*  42: 47 */     NSignature signature = (NSignature)View.inflate(context, layoutId, null);
/*  43: 48 */     signature.postInstance(control);
/*  44: 49 */     return signature;
/*  45:    */   }
/*  46:    */   
/*  47: 56 */   private Paint paint = new Paint();
/*  48: 57 */   private Path path = new Path();
/*  49: 59 */   private Bitmap mBitmap = null;
/*  50: 61 */   private AbstractMobileControl controller = null;
/*  51:    */   private float lastTouchX;
/*  52:    */   private float lastTouchY;
/*  53: 65 */   private final RectF dirtyRect = new RectF();
/*  54:    */   
/*  55:    */   public NSignature(Context context)
/*  56:    */   {
/*  57: 68 */     super(context);
/*  58:    */   }
/*  59:    */   
/*  60:    */   public NSignature(Context context, AttributeSet attrs, int defStyle)
/*  61:    */   {
/*  62: 72 */     super(context, attrs, defStyle);
/*  63:    */   }
/*  64:    */   
/*  65:    */   public NSignature(Context context, AttributeSet attrs)
/*  66:    */   {
/*  67: 76 */     super(context, attrs);
/*  68:    */   }
/*  69:    */   
/*  70:    */   public void postInstance(AbstractMobileControl control)
/*  71:    */   {
/*  72: 80 */     this.paint.setAntiAlias(true);
/*  73: 81 */     this.paint.setColor(-16777216);
/*  74: 82 */     this.paint.setStyle(Paint.Style.STROKE);
/*  75: 83 */     this.paint.setStrokeJoin(Paint.Join.ROUND);
/*  76: 84 */     this.paint.setStrokeWidth(5.0F);
/*  77:    */     
/*  78: 86 */     setController(control);
/*  79: 87 */     if (control != null) {
/*  80: 88 */       setId(NIDMapper.getAndroidIdFor(control.getId()));
/*  81:    */     } else {
/*  82: 90 */       setId(NIDMapper.getNextId());
/*  83:    */     }
/*  84: 92 */     init();
/*  85:    */   }
/*  86:    */   
/*  87:    */   public void clear()
/*  88:    */   {
/*  89: 96 */     this.path.reset();
/*  90: 97 */     invalidate();
/*  91: 98 */     this.mBitmap = null;
/*  92:    */   }
/*  93:    */   
/*  94:    */   protected void onDraw(Canvas canvas)
/*  95:    */   {
/*  96:103 */     canvas.drawPath(this.path, this.paint);
/*  97:    */   }
/*  98:    */   
/*  99:    */   public boolean onTouchEvent(MotionEvent event)
/* 100:    */   {
/* 101:108 */     float eventX = event.getX();
/* 102:109 */     float eventY = event.getY();
/* 103:111 */     switch (event.getAction())
/* 104:    */     {
/* 105:    */     case 0: 
/* 106:114 */       this.path.moveTo(eventX, eventY);
/* 107:115 */       this.lastTouchX = eventX;
/* 108:116 */       this.lastTouchY = eventY;
/* 109:117 */       return true;
/* 110:    */     case 1: 
/* 111:    */     case 2: 
/* 112:122 */       resetDirtyRect(eventX, eventY);
/* 113:    */       
/* 114:124 */       int historySize = event.getHistorySize();
/* 115:125 */       for (int i = 0; i < historySize; i++)
/* 116:    */       {
/* 117:126 */         float historicalX = event.getHistoricalX(i);
/* 118:127 */         float historicalY = event.getHistoricalY(i);
/* 119:128 */         expandDirtyRect(historicalX, historicalY);
/* 120:129 */         this.path.lineTo(historicalX, historicalY);
/* 121:    */       }
/* 122:132 */       this.path.lineTo(eventX, eventY);
/* 123:133 */       break;
/* 124:    */     default: 
/* 125:136 */       return false;
/* 126:    */     }
/* 127:139 */     invalidate((int)(this.dirtyRect.left - 2.5F), (int)(this.dirtyRect.top - 2.5F), (int)(this.dirtyRect.right + 2.5F), (int)(this.dirtyRect.bottom + 2.5F));
/* 128:    */     
/* 129:    */ 
/* 130:    */ 
/* 131:    */ 
/* 132:    */ 
/* 133:145 */     this.lastTouchX = eventX;
/* 134:146 */     this.lastTouchY = eventY;
/* 135:    */     
/* 136:148 */     return true;
/* 137:    */   }
/* 138:    */   
/* 139:    */   private void expandDirtyRect(float historicalX, float historicalY)
/* 140:    */   {
/* 141:152 */     if (historicalX < this.dirtyRect.left) {
/* 142:153 */       this.dirtyRect.left = historicalX;
/* 143:154 */     } else if (historicalX > this.dirtyRect.right) {
/* 144:155 */       this.dirtyRect.right = historicalX;
/* 145:    */     }
/* 146:157 */     if (historicalY < this.dirtyRect.top) {
/* 147:158 */       this.dirtyRect.top = historicalY;
/* 148:159 */     } else if (historicalY > this.dirtyRect.bottom) {
/* 149:160 */       this.dirtyRect.bottom = historicalY;
/* 150:    */     }
/* 151:    */   }
/* 152:    */   
/* 153:    */   private void resetDirtyRect(float eventX, float eventY)
/* 154:    */   {
/* 155:165 */     this.dirtyRect.left = Math.min(this.lastTouchX, eventX);
/* 156:166 */     this.dirtyRect.right = Math.max(this.lastTouchX, eventX);
/* 157:167 */     this.dirtyRect.top = Math.min(this.lastTouchY, eventY);
/* 158:168 */     this.dirtyRect.bottom = Math.max(this.lastTouchY, eventY);
/* 159:    */   }
/* 160:    */   
/* 161:    */   public byte[] getImageData()
/* 162:    */   {
/* 163:172 */     if (this.mBitmap == null) {
/* 164:173 */       this.mBitmap = Bitmap.createBitmap(getWidth(), getHeight(), Bitmap.Config.RGB_565);
/* 165:    */     }
/* 166:176 */     Canvas canvas = new Canvas(this.mBitmap);
/* 167:    */     
/* 168:178 */     BufferedOutputStream bos = null;
/* 169:    */     try
/* 170:    */     {
/* 171:180 */       ByteArrayOutputStream baos = new ByteArrayOutputStream();
/* 172:181 */       bos = new BufferedOutputStream(baos);
/* 173:182 */       draw(canvas);
/* 174:183 */       this.mBitmap.compress(Bitmap.CompressFormat.PNG, 90, bos);
/* 175:184 */       bos.flush();
/* 176:185 */       return baos.toByteArray();
/* 177:    */     }
/* 178:    */     catch (Exception e)
/* 179:    */     {
/* 180:188 */       MobileLoggerFactory.getDefaultLogger().warn("Error encountered getting image data", e);
/* 181:    */     }
/* 182:    */     finally
/* 183:    */     {
/* 184:191 */       if (bos != null) {
/* 185:    */         try
/* 186:    */         {
/* 187:193 */           bos.close();
/* 188:    */         }
/* 189:    */         catch (Throwable t) {}
/* 190:    */       }
/* 191:    */     }
/* 192:200 */     return null;
/* 193:    */   }
/* 194:    */   
/* 195:    */   public void setCId(String cid) {}
/* 196:    */   
/* 197:    */   public String getCId()
/* 198:    */   {
/* 199:211 */     return null;
/* 200:    */   }
/* 201:    */   
/* 202:    */   public void init()
/* 203:    */   {
/* 204:216 */     setLayoutParams(new ViewGroup.LayoutParams(-1, -1));
/* 205:    */   }
/* 206:    */   
/* 207:    */   public void addChildUIComponent(UIComponent child) {}
/* 208:    */   
/* 209:    */   public boolean canContainChildren()
/* 210:    */   {
/* 211:228 */     return false;
/* 212:    */   }
/* 213:    */   
/* 214:    */   public Enumeration getChildren()
/* 215:    */   {
/* 216:234 */     return null;
/* 217:    */   }
/* 218:    */   
/* 219:    */   public AbstractMobileControl getController()
/* 220:    */   {
/* 221:239 */     return this.controller;
/* 222:    */   }
/* 223:    */   
/* 224:    */   public void setController(AbstractMobileControl controller)
/* 225:    */   {
/* 226:244 */     this.controller = controller;
/* 227:    */   }
/* 228:    */   
/* 229:    */   public Object getConstraints()
/* 230:    */   {
/* 231:250 */     return null;
/* 232:    */   }
/* 233:    */   
/* 234:    */   public void setConstraints(Object contstraints) {}
/* 235:    */   
/* 236:    */   protected void onAttachedToWindow()
/* 237:    */   {
/* 238:260 */     super.onAttachedToWindow();
/* 239:    */     
/* 240:262 */     disableParentPageScroll();
/* 241:    */   }
/* 242:    */   
/* 243:    */   private void disableParentPageScroll()
/* 244:    */   {
/* 245:266 */     NScrollPan pageScrollView = UIUtil.findHolderScrollPan(this);
/* 246:267 */     if (pageScrollView != null) {
/* 247:268 */       UIUtil.moveChildrenToParent(pageScrollView);
/* 248:    */     }
/* 249:    */   }
/* 250:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.components.NSignature
 * JD-Core Version:    0.7.0.1
 */