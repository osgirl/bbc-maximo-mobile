package com.mro.mobile.ui.res.widgets.def;

public abstract interface LookupWidget
  extends PageWidget
{}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.def.LookupWidget
 * JD-Core Version:    0.7.0.1
 */