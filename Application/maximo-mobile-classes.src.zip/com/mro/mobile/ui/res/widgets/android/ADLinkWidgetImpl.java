/*   1:    */ package com.mro.mobile.ui.res.widgets.android;
/*   2:    */ 
/*   3:    */ import android.widget.LinearLayout.LayoutParams;
/*   4:    */ import com.mro.mobile.MobileApplicationException;
/*   5:    */ import com.mro.mobile.ui.MobileMboDataBean;
/*   6:    */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*   7:    */ import com.mro.mobile.ui.res.controls.LinkControl;
/*   8:    */ import com.mro.mobile.ui.res.widgets.android.components.NDrawerListenerManager;
/*   9:    */ import com.mro.mobile.ui.res.widgets.android.components.NImageButton;
/*  10:    */ import com.mro.mobile.ui.res.widgets.android.components.NImageLink;
/*  11:    */ import com.mro.mobile.ui.res.widgets.android.components.NLabel;
/*  12:    */ import com.mro.mobile.ui.res.widgets.android.components.table.NTableListenerManager;
/*  13:    */ import com.mro.mobile.ui.res.widgets.def.LinkWidget;
/*  14:    */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  15:    */ import java.util.ArrayList;
/*  16:    */ import java.util.List;
/*  17:    */ 
/*  18:    */ public class ADLinkWidgetImpl
/*  19:    */   extends ADAbstractWidgetImpl
/*  20:    */   implements LinkWidget
/*  21:    */ {
/*  22: 37 */   protected NImageLink imglink = null;
/*  23: 38 */   private LinkControl linkControl = null;
/*  24: 40 */   protected NImageButton buttonImg = null;
/*  25: 41 */   protected NLabel nlabel = null;
/*  26: 42 */   private Object value = null;
/*  27: 43 */   private String targetid = null;
/*  28: 45 */   private String controlID = null;
/*  29: 46 */   private String displayattribute = null;
/*  30: 47 */   private String displayevent = null;
/*  31: 48 */   private String dataattribute = null;
/*  32: 49 */   private boolean displaycount = false;
/*  33:    */   
/*  34:    */   public void createLinkField(String s, AbstractMobileControl control)
/*  35:    */   {
/*  36: 53 */     this.imglink = NImageLink.createByInflate(control, AndroidEnv.getCurrentActivity(), s);
/*  37: 54 */     this.imglink.setLayoutParams(new LinearLayout.LayoutParams(-2, -2));
/*  38: 57 */     if (NTableListenerManager.instance().isWidgetControlInTable(getController())) {
/*  39: 58 */       this.imglink.setTableClickable(NTableListenerManager.instance().getTableClickable());
/*  40:    */     }
/*  41: 61 */     this.imglink.setButtonDrawerClickable(NDrawerListenerManager.instance().getDrawerLinkClickable());
/*  42:    */   }
/*  43:    */   
/*  44:    */   public UIComponent addLinkLine(UIComponent link)
/*  45:    */   {
/*  46: 66 */     return link;
/*  47:    */   }
/*  48:    */   
/*  49:    */   protected LinkControl getLinkControl()
/*  50:    */   {
/*  51: 70 */     return (LinkControl)getController();
/*  52:    */   }
/*  53:    */   
/*  54:    */   public UIComponent[] resolveLinkComponents()
/*  55:    */     throws MobileApplicationException
/*  56:    */   {
/*  57: 76 */     UIComponent[] components = null;
/*  58:    */     
/*  59: 78 */     String label = this.linkControl.getLabel();
/*  60: 79 */     if ((label == null) || (label.equals("")))
/*  61:    */     {
/*  62: 81 */       MobileMboDataBean mdbean = this.linkControl.getDataBean();
/*  63: 82 */       if (mdbean != null) {
/*  64: 83 */         label = mdbean.getValue(this.dataattribute == null ? "" : this.dataattribute);
/*  65:    */       }
/*  66: 84 */       if ((label == null) || (label.trim().equals(""))) {
/*  67: 85 */         label = ".....";
/*  68:    */       }
/*  69:    */     }
/*  70: 88 */     this.value = this.linkControl.getStringValue("value");
/*  71: 89 */     this.targetid = this.linkControl.getStringValue("targetid");
/*  72: 90 */     String image = this.linkControl.getStringValue("image");
/*  73:    */     
/*  74:    */ 
/*  75: 93 */     this.imglink.refreshLink(label);
/*  76: 94 */     this.imglink.setCId(this.linkControl.getStringValue("id"));
/*  77: 95 */     this.imglink.setEvent(this.linkControl.getStringValue("event"));
/*  78: 96 */     this.imglink.setValue(this.value);
/*  79: 97 */     this.imglink.setTargetId(this.targetid);
/*  80:    */     
/*  81: 99 */     List<UIComponent> compsToRender = new ArrayList();
/*  82:101 */     if (image != null)
/*  83:    */     {
/*  84:104 */       this.buttonImg = NImageButton.createByInflate(getLinkControl(), AndroidEnv.getCurrentActivity(), image, label);
/*  85:105 */       this.buttonImg.setLayoutParams(new LinearLayout.LayoutParams(-2, -2));
/*  86:106 */       this.buttonImg.setEvent(this.linkControl.getStringValue("event"));
/*  87:107 */       this.buttonImg.setTargetId(this.targetid);
/*  88:108 */       this.buttonImg.setValue(this.value);
/*  89:109 */       this.nlabel = NLabel.createByInflate(getLinkControl(), AndroidEnv.getCurrentActivity(), "");
/*  90:110 */       this.nlabel.setLayoutParams(new LinearLayout.LayoutParams(-2, -2));
/*  91:111 */       compsToRender.add(this.buttonImg);
/*  92:112 */       compsToRender.add(this.nlabel);
/*  93:    */     }
/*  94:115 */     if (label.length() > 0) {
/*  95:117 */       compsToRender.add(this.linkControl.addLine(this.imglink));
/*  96:    */     } else {
/*  97:119 */       compsToRender.add(this.imglink);
/*  98:    */     }
/*  99:122 */     return (UIComponent[])compsToRender.toArray(new UIComponent[compsToRender.size()]);
/* 100:    */   }
/* 101:    */   
/* 102:    */   public void setController(AbstractMobileControl controller)
/* 103:    */   {
/* 104:127 */     this.linkControl = ((LinkControl)controller);
/* 105:128 */     super.setController(controller);
/* 106:    */   }
/* 107:    */   
/* 108:    */   public void setControlID(String controlID)
/* 109:    */   {
/* 110:133 */     this.controlID = controlID;
/* 111:    */   }
/* 112:    */   
/* 113:    */   public void setDisplayAttribute(String attr)
/* 114:    */   {
/* 115:138 */     this.displayattribute = attr;
/* 116:    */   }
/* 117:    */   
/* 118:    */   public void setDisplayEvent(String displayEvent)
/* 119:    */   {
/* 120:143 */     this.displayevent = displayEvent;
/* 121:    */   }
/* 122:    */   
/* 123:    */   public void setDataAttribute(String attribute)
/* 124:    */   {
/* 125:148 */     this.dataattribute = attribute;
/* 126:    */   }
/* 127:    */   
/* 128:    */   public void setDisplayCount(boolean count)
/* 129:    */   {
/* 130:153 */     this.displaycount = count;
/* 131:    */   }
/* 132:    */   
/* 133:    */   public Object getLinkField()
/* 134:    */   {
/* 135:157 */     return this.imglink;
/* 136:    */   }
/* 137:    */   
/* 138:    */   public Object getLinkValue()
/* 139:    */   {
/* 140:161 */     return this.value;
/* 141:    */   }
/* 142:    */   
/* 143:    */   public void refreshLink(String label)
/* 144:    */   {
/* 145:166 */     this.imglink.refreshLink(label);
/* 146:    */   }
/* 147:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.ADLinkWidgetImpl
 * JD-Core Version:    0.7.0.1
 */