/*   1:    */ package com.mro.mobile.ui.res.widgets.android;
/*   2:    */ 
/*   3:    */ import android.view.ViewGroup;
/*   4:    */ import com.ibm.tivoli.maximo.mobile.android.util.UIUtil;
/*   5:    */ import com.ibm.tivoli.maximo.mobile.resources.R.layout;
/*   6:    */ import com.mro.mobile.MobileApplicationException;
/*   7:    */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*   8:    */ import com.mro.mobile.ui.res.controls.CheckboxControl;
/*   9:    */ import com.mro.mobile.ui.res.widgets.android.components.NCheckBox;
/*  10:    */ import com.mro.mobile.ui.res.widgets.android.components.table.NTableListenerManager;
/*  11:    */ import com.mro.mobile.ui.res.widgets.def.CheckboxWidget;
/*  12:    */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  13:    */ 
/*  14:    */ public class ADCheckboxWidgetImpl
/*  15:    */   extends ADInputWidgetImpl
/*  16:    */   implements CheckboxWidget
/*  17:    */ {
/*  18: 30 */   private NCheckBox checkbox = null;
/*  19:    */   
/*  20:    */   protected CheckboxControl getCheckboxControl()
/*  21:    */   {
/*  22: 33 */     return (CheckboxControl)getController();
/*  23:    */   }
/*  24:    */   
/*  25:    */   public CheckboxWidget createCheckBoxField(String text, boolean readOnly)
/*  26:    */   {
/*  27: 38 */     this.checkbox = NCheckBox.createByInflate(getCheckboxControl(), AndroidEnv.getCurrentActivity(), text, readOnly);
/*  28: 40 */     if (NTableListenerManager.instance().isWidgetControlInTable(getController())) {
/*  29: 41 */       this.checkbox.setTableClickable(NTableListenerManager.instance().getTableClickable());
/*  30:    */     }
/*  31: 44 */     return this;
/*  32:    */   }
/*  33:    */   
/*  34:    */   public void setCheckBoxId(String id)
/*  35:    */   {
/*  36: 50 */     this.checkbox.setCId(id);
/*  37:    */   }
/*  38:    */   
/*  39:    */   public void setEvent(String event)
/*  40:    */   {
/*  41: 56 */     this.checkbox.setEvent(event);
/*  42:    */   }
/*  43:    */   
/*  44:    */   public void setController(AbstractMobileControl controller)
/*  45:    */   {
/*  46: 62 */     super.setController(controller);
/*  47:    */   }
/*  48:    */   
/*  49:    */   public void setDataBeanName(String dataBeanName)
/*  50:    */   {
/*  51: 68 */     this.checkbox.setDataBeanName(dataBeanName);
/*  52:    */   }
/*  53:    */   
/*  54:    */   public void setMobileMboAttributeName(String mobileMboAttributeName)
/*  55:    */   {
/*  56: 74 */     this.checkbox.setMobileMboAttributeName(mobileMboAttributeName);
/*  57:    */   }
/*  58:    */   
/*  59:    */   public void setState(boolean b)
/*  60:    */   {
/*  61: 80 */     this.checkbox.setState(b);
/*  62:    */   }
/*  63:    */   
/*  64:    */   public boolean getState()
/*  65:    */   {
/*  66: 86 */     return this.checkbox.getState();
/*  67:    */   }
/*  68:    */   
/*  69:    */   public void setInputMode(String inputMode)
/*  70:    */   {
/*  71: 92 */     this.checkbox.setInputMode(inputMode);
/*  72:    */   }
/*  73:    */   
/*  74:    */   public void setEnabled(boolean readOnly)
/*  75:    */   {
/*  76: 98 */     this.checkbox.setEnabled(readOnly);
/*  77:    */   }
/*  78:    */   
/*  79:    */   public void requestFocus()
/*  80:    */   {
/*  81:104 */     this.checkbox.requestFocus();
/*  82:    */   }
/*  83:    */   
/*  84:    */   public UIComponent[] resolveCheckBoxComponents()
/*  85:    */     throws MobileApplicationException
/*  86:    */   {
/*  87:109 */     UIComponent[] components = null;
/*  88:    */     
/*  89:111 */     UIComponent labelPanel = getLabelPanelUIComponent(true);
/*  90:113 */     if (labelPanel != null)
/*  91:    */     {
/*  92:114 */       ViewGroup viewGroup = getViewGroupForSubclassContent(UIUtil.getResourceId(R.layout.class, "adtextboxwidgetimpl"));
/*  93:    */       
/*  94:116 */       viewGroup.addView(this.checkbox);
/*  95:    */       
/*  96:118 */       components = new UIComponent[] { labelPanel };
/*  97:    */     }
/*  98:    */     else
/*  99:    */     {
/* 100:121 */       UIComponent[] tmpComp = { this.checkbox };
/* 101:122 */       components = tmpComp;
/* 102:    */     }
/* 103:124 */     return components;
/* 104:    */   }
/* 105:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.ADCheckboxWidgetImpl
 * JD-Core Version:    0.7.0.1
 */