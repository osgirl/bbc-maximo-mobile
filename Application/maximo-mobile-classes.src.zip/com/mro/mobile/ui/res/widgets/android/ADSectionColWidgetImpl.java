/*  1:   */ package com.mro.mobile.ui.res.widgets.android;
/*  2:   */ 
/*  3:   */ import android.view.View;
/*  4:   */ import android.view.ViewGroup.LayoutParams;
/*  5:   */ import android.widget.LinearLayout.LayoutParams;
/*  6:   */ import com.mro.mobile.ui.res.controls.SectionColControl;
/*  7:   */ import com.mro.mobile.ui.res.widgets.android.components.NPanel;
/*  8:   */ import com.mro.mobile.ui.res.widgets.def.SectionColWidget;
/*  9:   */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/* 10:   */ 
/* 11:   */ public class ADSectionColWidgetImpl
/* 12:   */   extends ADAbstractWidgetImpl
/* 13:   */   implements SectionColWidget
/* 14:   */ {
/* 15:30 */   private NPanel colPanel = null;
/* 16:   */   
/* 17:   */   public void createSectionCol(String id, String align)
/* 18:   */   {
/* 19:34 */     this.colPanel = NPanel.createByInflate(getSectionColControl(), AndroidEnv.getCurrentActivity(), 0);
/* 20:35 */     this.colPanel.setCId(id);
/* 21:36 */     this.colPanel.setGravity(16);
/* 22:   */     
/* 23:38 */     LinearLayout.LayoutParams defaultConstraints = new LinearLayout.LayoutParams(-2, -2);
/* 24:39 */     defaultConstraints.setMargins(2, 2, 2, 2);
/* 25:40 */     this.colPanel.setConstraints(defaultConstraints);
/* 26:   */   }
/* 27:   */   
/* 28:   */   protected SectionColControl getSectionColControl()
/* 29:   */   {
/* 30:44 */     return (SectionColControl)getController();
/* 31:   */   }
/* 32:   */   
/* 33:   */   public void addComponent(UIComponent component)
/* 34:   */   {
/* 35:48 */     View view = (View)component;
/* 36:49 */     ViewGroup.LayoutParams params = view.getLayoutParams();
/* 37:50 */     if (params == null) {
/* 38:51 */       params = new LinearLayout.LayoutParams(-2, -2);
/* 39:   */     }
/* 40:56 */     if ((params instanceof LinearLayout.LayoutParams)) {
/* 41:57 */       ((LinearLayout.LayoutParams)params).weight = 1.0F;
/* 42:   */     }
/* 43:59 */     view.setLayoutParams(params);
/* 44:   */     
/* 45:61 */     this.colPanel.addView((View)component);
/* 46:   */   }
/* 47:   */   
/* 48:   */   public void setPadding(int rowPadding, int columnPadding)
/* 49:   */   {
/* 50:66 */     LinearLayout.LayoutParams defaultConstraints = new LinearLayout.LayoutParams(-2, -2);
/* 51:67 */     defaultConstraints.setMargins(0, 0, columnPadding, rowPadding);
/* 52:   */     
/* 53:69 */     this.colPanel.setConstraints(defaultConstraints);
/* 54:   */   }
/* 55:   */   
/* 56:   */   public UIComponent[] resolveSectionColComponents()
/* 57:   */   {
/* 58:74 */     return new UIComponent[] { this.colPanel };
/* 59:   */   }
/* 60:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.ADSectionColWidgetImpl
 * JD-Core Version:    0.7.0.1
 */