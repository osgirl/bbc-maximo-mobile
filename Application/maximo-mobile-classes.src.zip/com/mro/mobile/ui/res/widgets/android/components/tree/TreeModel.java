package com.mro.mobile.ui.res.widgets.android.components.tree;

public abstract interface TreeModel
{
  public abstract Item getRoot();
  
  public abstract int getItemsCount();
  
  public abstract Item getParent(Item paramItem);
  
  public abstract Item getChildAt(Item paramItem, int paramInt);
  
  public abstract int getChildIndex(Item paramItem);
  
  public abstract int getChildrenCount(Item paramItem);
  
  public abstract boolean hasChildren(Item paramItem);
  
  public abstract void add(Item paramItem1, Item paramItem2);
  
  public abstract void insert(Item paramItem1, Item paramItem2, int paramInt);
  
  public abstract void set(Item paramItem, Object paramObject);
  
  public abstract void remove(Item paramItem);
  
  public abstract void addTreeListener(TreeListener paramTreeListener);
  
  public abstract void removeTreeListener(TreeListener paramTreeListener);
  
  public abstract int getHierarchyChildrenCount(Item paramItem);
  
  public abstract ItemDesc getItemDesc(Item paramItem);
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.components.tree.TreeModel
 * JD-Core Version:    0.7.0.1
 */