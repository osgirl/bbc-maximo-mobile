/*  1:   */ package com.mro.mobile.ui.res.widgets.android.components.table;
/*  2:   */ 
/*  3:   */ import android.view.View;
/*  4:   */ import android.widget.TableRow;
/*  5:   */ import com.ibm.tivoli.maximo.mobile.android.util.UIUtil;
/*  6:   */ import com.ibm.tivoli.maximo.mobile.resources.R.drawable;
/*  7:   */ import java.util.List;
/*  8:   */ 
/*  9:   */ public class NTableLayoutUpdater
/* 10:   */   implements Runnable
/* 11:   */ {
/* 12:   */   private NTable table;
/* 13:   */   
/* 14:   */   public NTableLayoutUpdater(NTable table)
/* 15:   */   {
/* 16:36 */     this.table = table;
/* 17:   */   }
/* 18:   */   
/* 19:   */   public void run()
/* 20:   */   {
/* 21:41 */     forceChangesOnHeader(this.table.getHeader());
/* 22:42 */     forceChangesOnTable(this.table.getBody());
/* 23:   */   }
/* 24:   */   
/* 25:   */   private void forceChangesOnTable(List<TableRow> body)
/* 26:   */   {
/* 27:46 */     int currentRow = 0;
/* 28:47 */     for (TableRow row : body)
/* 29:   */     {
/* 30:49 */       String bgColor = currentRow % 2 == 0 ? "table_cell_even" : "table_cell_odd";
/* 31:   */       
/* 32:51 */       int c = row.getChildCount();
/* 33:52 */       for (int i = 0; i < c; i++)
/* 34:   */       {
/* 35:53 */         View v = row.getChildAt(i);
/* 36:54 */         v.setBackgroundResource(UIUtil.getResourceId(R.drawable.class, bgColor));
/* 37:55 */         v.invalidate();
/* 38:   */       }
/* 39:58 */       currentRow++;
/* 40:   */     }
/* 41:   */   }
/* 42:   */   
/* 43:   */   private void forceChangesOnHeader(TableRow row)
/* 44:   */   {
/* 45:63 */     int c = row.getChildCount();
/* 46:64 */     for (int i = 0; i < c; i++)
/* 47:   */     {
/* 48:65 */       View v = row.getChildAt(i);
/* 49:66 */       v.setBackgroundResource(UIUtil.getResourceId(R.drawable.class, "table_header"));
/* 50:67 */       v.invalidate();
/* 51:   */     }
/* 52:   */   }
/* 53:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.components.table.NTableLayoutUpdater
 * JD-Core Version:    0.7.0.1
 */