package com.mro.mobile.ui.res.widgets.def;

import com.mro.mobile.MobileApplicationException;

public abstract interface InputWidget
  extends AbstractWidget
{
  public abstract void setTextFieldFocus(UIComponent paramUIComponent);
  
  public abstract UIComponent getLabelPanelUIComponent(boolean paramBoolean)
    throws MobileApplicationException;
  
  public abstract void setLeftConstraints(UIComponent paramUIComponent);
  
  public abstract void setRightConstraints(UIComponent paramUIComponent);
  
  public abstract void refreshLabel()
    throws MobileApplicationException;
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.def.InputWidget
 * JD-Core Version:    0.7.0.1
 */