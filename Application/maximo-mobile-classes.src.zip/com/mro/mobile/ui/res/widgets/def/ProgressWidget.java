package com.mro.mobile.ui.res.widgets.def;

import com.mro.mobile.MobileApplicationException;
import com.mro.mobile.ui.res.controls.AbstractMobileControl;

public abstract interface ProgressWidget
  extends AbstractWidget
{
  public abstract ProgressWidget createProgressWidget();
  
  public abstract void setProgressId(String paramString);
  
  public abstract void setController(AbstractMobileControl paramAbstractMobileControl);
  
  public abstract UIComponent[] resolveProgressComponents()
    throws MobileApplicationException;
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.def.ProgressWidget
 * JD-Core Version:    0.7.0.1
 */