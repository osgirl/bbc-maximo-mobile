package com.mro.mobile.ui.res.widgets.def;

import com.mro.mobile.MobileApplicationException;

public abstract interface ButtonStateWidget
  extends AbstractWidget
{
  public abstract ButtonStateWidget createButtonState(String paramString1, String paramString2);
  
  public abstract void setVisible(boolean paramBoolean);
  
  public abstract void setValue(String paramString);
  
  public abstract void setTargetId(String paramString);
  
  public abstract UIComponent[] resolveButtonStateComponents()
    throws MobileApplicationException;
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.def.ButtonStateWidget
 * JD-Core Version:    0.7.0.1
 */