/*   1:    */ package com.mro.mobile.ui.res.widgets.android;
/*   2:    */ 
/*   3:    */ import android.app.Activity;
/*   4:    */ import android.content.DialogInterface;
/*   5:    */ import android.content.DialogInterface.OnKeyListener;
/*   6:    */ import android.graphics.Color;
/*   7:    */ import android.view.Display;
/*   8:    */ import android.view.KeyEvent;
/*   9:    */ import android.view.View;
/*  10:    */ import android.view.View.OnClickListener;
/*  11:    */ import android.view.WindowManager;
/*  12:    */ import android.widget.LinearLayout.LayoutParams;
/*  13:    */ import android.widget.ScrollView;
/*  14:    */ import com.ibm.tivoli.maximo.mobile.android.util.UIUtil;
/*  15:    */ import com.ibm.tivoli.maximo.mobile.entrypoint.android.AndroidMobileAppEntryPoint;
/*  16:    */ import com.ibm.tivoli.maximo.mobile.resources.R.drawable;
/*  17:    */ import com.mro.mobile.ui.event.UIEvent;
/*  18:    */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*  19:    */ import com.mro.mobile.ui.res.controls.LinkControl;
/*  20:    */ import com.mro.mobile.ui.res.controls.MessageBox;
/*  21:    */ import com.mro.mobile.ui.res.controls.MessageBoxAdapter;
/*  22:    */ import com.mro.mobile.ui.res.widgets.android.components.NImage;
/*  23:    */ import com.mro.mobile.ui.res.widgets.android.components.NImageLink;
/*  24:    */ import com.mro.mobile.ui.res.widgets.android.components.NLabel;
/*  25:    */ import com.mro.mobile.ui.res.widgets.android.components.NPanel;
/*  26:    */ import com.mro.mobile.ui.res.widgets.android.components.NPopUpWindow;
/*  27:    */ import com.mro.mobile.ui.res.widgets.android.components.NScrollPan;
/*  28:    */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  29:    */ import java.util.Enumeration;
/*  30:    */ import java.util.Vector;
/*  31:    */ 
/*  32:    */ public class AndroidMessageBoxAdapterImpl
/*  33:    */   implements MessageBoxAdapter, View.OnClickListener, DialogInterface.OnKeyListener
/*  34:    */ {
/*  35: 34 */   private MessageBox messageBox = null;
/*  36:    */   private NPopUpWindow dialog;
/*  37:    */   private View dialogButton;
/*  38:    */   
/*  39:    */   public AndroidMessageBoxAdapterImpl(MessageBox messageBox)
/*  40:    */   {
/*  41: 41 */     this.messageBox = messageBox;
/*  42:    */   }
/*  43:    */   
/*  44:    */   public UIComponent createIconImage(String icon)
/*  45:    */   {
/*  46: 45 */     return NImage.createByInflate(null, AndroidEnv.getCurrentActivity(), icon);
/*  47:    */   }
/*  48:    */   
/*  49:    */   public void show()
/*  50:    */   {
/*  51: 49 */     ((AndroidMobileAppEntryPoint)AndroidEnv.getCurrentActivity().getApplication()).runOnUiThread(new Runnable()
/*  52:    */     {
/*  53:    */       public void run()
/*  54:    */       {
/*  55: 52 */         AndroidMessageBoxAdapterImpl.this.realshow();
/*  56:    */       }
/*  57:    */     });
/*  58:    */   }
/*  59:    */   
/*  60:    */   private void realshow()
/*  61:    */   {
/*  62: 58 */     NImage image = (NImage)this.messageBox.getIcon();
/*  63: 59 */     NPanel main = NPanel.createByInflate(null, AndroidEnv.getCurrentActivity(), 1);
/*  64:    */     
/*  65:    */ 
/*  66:    */ 
/*  67: 63 */     main.setBackgroundResource(UIUtil.getResourceId(R.drawable.class, "custom_dialog_background"));
/*  68:    */     
/*  69: 65 */     NPanel middle = NPanel.createByInflate(null, AndroidEnv.getCurrentActivity(), 0);
/*  70: 66 */     LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -1);
/*  71: 67 */     NPanel south = NPanel.createByInflate(null, AndroidEnv.getCurrentActivity(), 1);
/*  72: 68 */     middle.setLayoutParams(layoutParams);
/*  73: 69 */     south.setLayoutParams(layoutParams);
/*  74: 70 */     south.setGravity(5);
/*  75: 71 */     main.setLayoutParams(layoutParams);
/*  76:    */     
/*  77:    */ 
/*  78: 74 */     ScrollView centerScroll = NScrollPan.createByInflate(null, AndroidEnv.getCurrentActivity(), main);
/*  79: 75 */     centerScroll.computeScroll();
/*  80: 76 */     centerScroll.setBackgroundColor(Color.alpha(0));
/*  81:    */     
/*  82: 78 */     main.addView(middle);
/*  83: 79 */     main.addView(south);
/*  84: 80 */     if (image != null)
/*  85:    */     {
/*  86: 81 */       image.setPadding(20, 20, 20, 0);
/*  87: 82 */       middle.addView(image);
/*  88:    */     }
/*  89: 86 */     String msg = this.messageBox.getMessage().replace("\\n", "\n");
/*  90: 87 */     NLabel label = NLabel.createByInflate(null, AndroidEnv.getCurrentActivity(), msg);
/*  91: 88 */     label.setPadding(5, 40, 45, 20);
/*  92: 89 */     middle.addView(label);
/*  93: 90 */     Vector<?> buttons = this.messageBox.createButtons();
/*  94: 91 */     Enumeration<?> e = buttons.elements();
/*  95: 92 */     NPanel buttonPanel = NPanel.createByInflate(null, AndroidEnv.getCurrentActivity(), 0);
/*  96: 93 */     LinearLayout.LayoutParams btnPanelParams = new LinearLayout.LayoutParams(-2, -2);
/*  97: 94 */     buttonPanel.setLayoutParams(btnPanelParams);
/*  98: 95 */     buttonPanel.setGravity(16);
/*  99: 96 */     int maxWidth = AndroidEnv.getCurrentActivity().getWindowManager().getDefaultDisplay().getWidth() - 10;
/* 100: 97 */     int initialContainerWidth = buttonPanel.getMeasuredWidth();
/* 101: 98 */     int widthSoFar = initialContainerWidth;
/* 102: 99 */     while (e.hasMoreElements())
/* 103:    */     {
/* 104:100 */       View button = (View)e.nextElement();
/* 105:101 */       button.setPadding(10, 0, 10, 0);
/* 106:102 */       button.measure(0, 0);
/* 107:    */       
/* 108:104 */       widthSoFar += button.getMeasuredWidth();
/* 109:105 */       if (widthSoFar >= maxWidth)
/* 110:    */       {
/* 111:106 */         south.addView(buttonPanel);
/* 112:    */         
/* 113:108 */         buttonPanel = NPanel.createByInflate(null, AndroidEnv.getCurrentActivity(), 0);
/* 114:109 */         buttonPanel.setLayoutParams(btnPanelParams);
/* 115:    */         
/* 116:111 */         buttonPanel.addView(button);
/* 117:112 */         widthSoFar = button.getMeasuredWidth() + initialContainerWidth;
/* 118:    */       }
/* 119:    */       else
/* 120:    */       {
/* 121:114 */         buttonPanel.addView(button);
/* 122:    */       }
/* 123:117 */       if (e.hasMoreElements())
/* 124:    */       {
/* 125:118 */         NImage img = NImage.createByInflate(null, AndroidEnv.getCurrentActivity(), "/img/btntb_divider.gif");
/* 126:119 */         buttonPanel.addView(img);
/* 127:120 */         img.measure(0, 0);
/* 128:121 */         widthSoFar += img.getMeasuredWidth();
/* 129:    */       }
/* 130:    */     }
/* 131:124 */     south.addView(buttonPanel);
/* 132:125 */     this.dialog = new NPopUpWindow(AndroidEnv.getCurrentActivity(), true);
/* 133:126 */     this.dialog.setContentView(centerScroll);
/* 134:127 */     enableBackButtonIfSingleButton(buttonPanel);
/* 135:128 */     AndroidEnv.setMessageBox(this.dialog);
/* 136:129 */     this.dialog.show();
/* 137:    */   }
/* 138:    */   
/* 139:    */   protected void enableBackButtonIfSingleButton(NPanel buttonPanel)
/* 140:    */   {
/* 141:133 */     if (buttonPanel.getChildCount() == 1)
/* 142:    */     {
/* 143:134 */       this.dialog.setOnKeyListener(this);
/* 144:135 */       this.dialogButton = buttonPanel.getChildAt(0);
/* 145:    */     }
/* 146:    */   }
/* 147:    */   
/* 148:    */   private void dispatchEvent(NImageLink link)
/* 149:    */   {
/* 150:141 */     if (this.messageBox.getEvent() != null) {
/* 151:144 */       if (link.getEvent() != null)
/* 152:    */       {
/* 153:145 */         if (link.getEvent().equals("setresponse"))
/* 154:    */         {
/* 155:146 */           this.messageBox.getEvent().setMsgResponse((String)link.getValue());
/* 156:147 */           UIEvent sendEvent = this.messageBox.getEvent().getInitialEvent();
/* 157:148 */           if (sendEvent != null)
/* 158:    */           {
/* 159:149 */             sendEvent.setInitialEvent(this.messageBox.getEvent());
/* 160:150 */             this.messageBox.getEvent().setEventErrored(false);
/* 161:151 */             this.messageBox.setEvent(sendEvent);
/* 162:    */           }
/* 163:    */         }
/* 164:    */         else
/* 165:    */         {
/* 166:154 */           this.messageBox.setEvent(new UIEvent((AbstractMobileControl)this.messageBox.getEvent().getCreatingObject(), link.getEvent(), link.getTargetId(), link.getValue()));
/* 167:    */         }
/* 168:158 */         ((AbstractMobileControl)this.messageBox.getEvent().getCreatingObject()).handleEvent(this.messageBox.getEvent());
/* 169:    */       }
/* 170:    */     }
/* 171:163 */     if (this.dialog != null)
/* 172:    */     {
/* 173:164 */       this.dialog.dismiss();
/* 174:165 */       this.dialog = null;
/* 175:    */     }
/* 176:    */   }
/* 177:    */   
/* 178:    */   public UIComponent createLinkImageAndAddListener(String label, boolean setmsgresponse, String value)
/* 179:    */   {
/* 180:170 */     NImageLink link = NImageLink.createByInflate(null, AndroidEnv.getCurrentActivity(), label);
/* 181:171 */     link.setEvent(setmsgresponse ? "setresponse" : null);
/* 182:172 */     link.setValue(value);
/* 183:173 */     link.setOnClickListener(this);
/* 184:174 */     return link;
/* 185:    */   }
/* 186:    */   
/* 187:    */   public void addListenerToLinkImageAndAppendComponent(LinkControl linkCtrl, UIComponent firstComponent, Vector btns)
/* 188:    */   {
/* 189:178 */     NImageLink link = (NImageLink)linkCtrl.getLink();
/* 190:179 */     View comp = (View)firstComponent;
/* 191:180 */     if (comp.getVisibility() == 0)
/* 192:    */     {
/* 193:181 */       link.setOnClickListener(this);
/* 194:182 */       btns.add(comp);
/* 195:    */     }
/* 196:    */   }
/* 197:    */   
/* 198:    */   public void onClick(View v)
/* 199:    */   {
/* 200:188 */     dispatchEvent((NImageLink)v);
/* 201:    */   }
/* 202:    */   
/* 203:    */   public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event)
/* 204:    */   {
/* 205:193 */     if ((event.getKeyCode() == 4) && 
/* 206:194 */       (this.dialogButton != null)) {
/* 207:195 */       onClick(this.dialogButton);
/* 208:    */     }
/* 209:198 */     return false;
/* 210:    */   }
/* 211:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.AndroidMessageBoxAdapterImpl
 * JD-Core Version:    0.7.0.1
 */