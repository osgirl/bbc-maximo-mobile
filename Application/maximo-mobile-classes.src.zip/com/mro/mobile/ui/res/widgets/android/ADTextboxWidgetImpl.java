/*   1:    */ package com.mro.mobile.ui.res.widgets.android;
/*   2:    */ 
/*   3:    */ import android.view.KeyEvent;
/*   4:    */ import android.view.View;
/*   5:    */ import android.view.ViewGroup;
/*   6:    */ import android.widget.LinearLayout.LayoutParams;
/*   7:    */ import com.ibm.tivoli.maximo.mobile.resources.R.layout;
/*   8:    */ import com.mro.mobile.MobileApplicationException;
/*   9:    */ import com.mro.mobile.ui.res.MobileUIProperties;
/*  10:    */ import com.mro.mobile.ui.res.controls.TextboxControl;
/*  11:    */ import com.mro.mobile.ui.res.widgets.android.components.NImageButton;
/*  12:    */ import com.mro.mobile.ui.res.widgets.android.components.NPanel;
/*  13:    */ import com.mro.mobile.ui.res.widgets.android.components.NTextField;
/*  14:    */ import com.mro.mobile.ui.res.widgets.def.TextboxWidget;
/*  15:    */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  16:    */ 
/*  17:    */ public class ADTextboxWidgetImpl
/*  18:    */   extends ADInputWidgetImpl
/*  19:    */   implements TextboxWidget
/*  20:    */ {
/*  21: 35 */   protected NTextField textField = null;
/*  22: 37 */   protected NPanel tbPanel = null;
/*  23:    */   
/*  24:    */   protected void setController(TextboxControl controller)
/*  25:    */   {
/*  26: 41 */     super.setController(controller);
/*  27:    */   }
/*  28:    */   
/*  29:    */   protected TextboxControl getTextboxControl()
/*  30:    */   {
/*  31: 45 */     return (TextboxControl)getController();
/*  32:    */   }
/*  33:    */   
/*  34:    */   public ADTextboxWidgetImpl() {}
/*  35:    */   
/*  36:    */   public ADTextboxWidgetImpl(TextboxControl control)
/*  37:    */   {
/*  38: 52 */     setController(control);
/*  39:    */   }
/*  40:    */   
/*  41:    */   public void createTextField(String text, int maxCol, int size, int flags)
/*  42:    */   {
/*  43: 56 */     this.textField = new NTextField(getTextboxControl(), AndroidEnv.getCurrentActivity(), text, maxCol, size, flags);
/*  44:    */   }
/*  45:    */   
/*  46:    */   public void setTextFieldId(String textFieldId)
/*  47:    */   {
/*  48: 60 */     this.textField.setCId(textFieldId);
/*  49:    */   }
/*  50:    */   
/*  51:    */   public void setTextFieldEditable(boolean editable)
/*  52:    */   {
/*  53: 64 */     this.textField.setEditable(editable);
/*  54:    */   }
/*  55:    */   
/*  56:    */   public void appendFirstMenuItemToTextField(UIComponent[] menu)
/*  57:    */   {
/*  58: 68 */     this.tbPanel = NPanel.createByInflate(getTextboxControl(), AndroidEnv.getCurrentActivity(), 0);
/*  59: 69 */     this.tbPanel.setGravity(16);
/*  60: 70 */     this.tbPanel.addView(this.textField);
/*  61: 72 */     if (menu != null)
/*  62:    */     {
/*  63: 74 */       View v = (View)menu[0];
/*  64: 75 */       LinearLayout.LayoutParams params = (LinearLayout.LayoutParams)v.getLayoutParams();
/*  65: 76 */       if (params == null) {
/*  66: 77 */         params = new LinearLayout.LayoutParams(-2, -2);
/*  67:    */       }
/*  68: 79 */       params.leftMargin = 15;
/*  69: 80 */       v.setLayoutParams(params);
/*  70:    */       
/*  71: 82 */       this.tbPanel.addView(v);
/*  72:    */     }
/*  73:    */   }
/*  74:    */   
/*  75:    */   public void appendLookupToTextField()
/*  76:    */     throws MobileApplicationException
/*  77:    */   {
/*  78: 87 */     String lookup = getTextboxControl().getStringValue("lookup");
/*  79: 88 */     String buttonImage = getTextboxControl().getStringValue("imagebutton");
/*  80: 89 */     NImageButton luButton = null;
/*  81: 90 */     if (buttonImage == null) {
/*  82: 91 */       luButton = NImageButton.createByInflate(getTextboxControl(), AndroidEnv.getCurrentActivity(), getTextboxControl().getImage(), null);
/*  83:    */     } else {
/*  84: 93 */       luButton = NImageButton.createByInflate(getTextboxControl(), AndroidEnv.getCurrentActivity(), buttonImage, null);
/*  85:    */     }
/*  86: 96 */     luButton.setEvent("lookup");
/*  87: 97 */     luButton.setValue(lookup);
/*  88: 98 */     luButton.setController(getTextboxControl());
/*  89:    */     
/*  90:    */ 
/*  91:    */ 
/*  92:102 */     LinearLayout.LayoutParams params = (LinearLayout.LayoutParams)this.textField.getLayoutParams();
/*  93:103 */     if (params == null) {
/*  94:104 */       params = new LinearLayout.LayoutParams(-2, -2);
/*  95:    */     }
/*  96:106 */     params.weight = 1.0F;
/*  97:107 */     this.textField.setLayoutParams(params);
/*  98:    */     
/*  99:109 */     this.tbPanel = NPanel.createByInflate(getTextboxControl(), AndroidEnv.getCurrentActivity(), 0);
/* 100:110 */     this.tbPanel.setGravity(16);
/* 101:111 */     this.tbPanel.addView(this.textField);
/* 102:112 */     this.tbPanel.addView(luButton);
/* 103:    */     
/* 104:114 */     params = (LinearLayout.LayoutParams)luButton.getLayoutParams();
/* 105:115 */     params.leftMargin = 15;
/* 106:116 */     luButton.setLayoutParams(params);
/* 107:    */   }
/* 108:    */   
/* 109:    */   public void appendLDToTextField()
/* 110:    */     throws MobileApplicationException
/* 111:    */   {
/* 112:120 */     String buttonImage = getTextboxControl().getStringValue("imagebutton");
/* 113:121 */     NImageButton ldButton = null;
/* 114:122 */     if (buttonImage == null)
/* 115:    */     {
/* 116:123 */       String buttonLngDescriptionImage = "";
/* 117:124 */       if (com.mro.mobile.ui.res.UIUtil.isNull(getTextboxControl().getLongDesc())) {
/* 118:125 */         buttonLngDescriptionImage = MobileUIProperties.getStringValue("button.long_description.off");
/* 119:    */       } else {
/* 120:127 */         buttonLngDescriptionImage = MobileUIProperties.getStringValue("button.long_description.on");
/* 121:    */       }
/* 122:129 */       ldButton = NImageButton.createByInflate(getTextboxControl(), AndroidEnv.getCurrentActivity(), buttonLngDescriptionImage, null);
/* 123:    */     }
/* 124:    */     else
/* 125:    */     {
/* 126:131 */       ldButton = NImageButton.createByInflate(getTextboxControl(), AndroidEnv.getCurrentActivity(), buttonImage, null);
/* 127:    */     }
/* 128:134 */     ldButton.setEvent("viewld");
/* 129:135 */     ldButton.setController(getTextboxControl());
/* 130:136 */     this.tbPanel = NPanel.createByInflate(getTextboxControl(), AndroidEnv.getCurrentActivity(), 0);
/* 131:137 */     this.tbPanel.setGravity(16);
/* 132:    */     
/* 133:139 */     this.tbPanel.addView(this.textField);
/* 134:140 */     this.tbPanel.addView(ldButton);
/* 135:    */     
/* 136:142 */     LinearLayout.LayoutParams params = (LinearLayout.LayoutParams)ldButton.getLayoutParams();
/* 137:143 */     params.leftMargin = 15;
/* 138:144 */     ldButton.setLayoutParams(params);
/* 139:    */   }
/* 140:    */   
/* 141:    */   public UIComponent[] resolveTextBoxComponents()
/* 142:    */     throws MobileApplicationException
/* 143:    */   {
/* 144:148 */     UIComponent[] textBoxComponents = null;
/* 145:149 */     UIComponent labelPanel = getLabelPanelUIComponent(true);
/* 146:151 */     if (labelPanel != null)
/* 147:    */     {
/* 148:153 */       ViewGroup viewGroup = getViewGroupForSubclassContent(com.ibm.tivoli.maximo.mobile.android.util.UIUtil.getResourceId(R.layout.class, "adtextboxwidgetimpl"));
/* 149:155 */       if (this.tbPanel != null) {
/* 150:156 */         viewGroup.addView(this.tbPanel);
/* 151:    */       } else {
/* 152:158 */         viewGroup.addView(this.textField);
/* 153:    */       }
/* 154:160 */       textBoxComponents = new UIComponent[] { labelPanel };
/* 155:    */     }
/* 156:163 */     else if (this.tbPanel != null)
/* 157:    */     {
/* 158:164 */       textBoxComponents = new UIComponent[] { this.tbPanel };
/* 159:    */     }
/* 160:    */     else
/* 161:    */     {
/* 162:166 */       textBoxComponents = new UIComponent[] { this.textField };
/* 163:    */     }
/* 164:170 */     return textBoxComponents;
/* 165:    */   }
/* 166:    */   
/* 167:    */   public UIComponent getTextField()
/* 168:    */   {
/* 169:174 */     return this.textField;
/* 170:    */   }
/* 171:    */   
/* 172:    */   public String getText()
/* 173:    */   {
/* 174:178 */     return this.textField.getText().toString().trim();
/* 175:    */   }
/* 176:    */   
/* 177:    */   public void setText(String s)
/* 178:    */   {
/* 179:182 */     this.textField.setTheText(s);
/* 180:    */   }
/* 181:    */   
/* 182:    */   public void setTextFieldInvalid(boolean b)
/* 183:    */   {
/* 184:186 */     this.textField.setInvalid(b);
/* 185:    */   }
/* 186:    */   
/* 187:    */   public void processTextFieldKeyEvent()
/* 188:    */   {
/* 189:190 */     this.textField.dispatchKeyEvent(new KeyEvent(0, 66));
/* 190:    */   }
/* 191:    */   
/* 192:    */   public String getTextFieldId()
/* 193:    */   {
/* 194:194 */     return this.textField.getCId();
/* 195:    */   }
/* 196:    */   
/* 197:    */   public void refreshText(String value)
/* 198:    */   {
/* 199:198 */     this.textField.refreshText(value);
/* 200:    */   }
/* 201:    */   
/* 202:    */   public void setFocusBack()
/* 203:    */   {
/* 204:202 */     this.textField.requestFocus();
/* 205:    */   }
/* 206:    */   
/* 207:    */   public int getFlags(boolean showbox)
/* 208:    */   {
/* 209:206 */     return 4 + (showbox ? 1 : 0);
/* 210:    */   }
/* 211:    */   
/* 212:    */   public boolean hasTextField()
/* 213:    */   {
/* 214:210 */     return this.textField != null;
/* 215:    */   }
/* 216:    */   
/* 217:    */   public void setTextFontColor(Object color) {}
/* 218:    */   
/* 219:    */   public void setForceCleanUpOnInvalid(boolean cleanup)
/* 220:    */   {
/* 221:219 */     this.textField.forceCleanUpOnInvalid(cleanup);
/* 222:    */   }
/* 223:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.ADTextboxWidgetImpl
 * JD-Core Version:    0.7.0.1
 */