package com.mro.mobile.ui.res.widgets.def;

import com.mro.mobile.MobileApplicationException;

public abstract interface TextboxWidget
  extends InputWidget
{
  public abstract int getFlags(boolean paramBoolean);
  
  public abstract void createTextField(String paramString, int paramInt1, int paramInt2, int paramInt3);
  
  public abstract void setTextFieldId(String paramString);
  
  public abstract void setTextFieldEditable(boolean paramBoolean);
  
  public abstract void appendFirstMenuItemToTextField(UIComponent[] paramArrayOfUIComponent);
  
  public abstract void appendLookupToTextField()
    throws MobileApplicationException;
  
  public abstract void appendLDToTextField()
    throws MobileApplicationException;
  
  public abstract UIComponent[] resolveTextBoxComponents()
    throws MobileApplicationException;
  
  public abstract String getTextFieldId();
  
  public abstract String getText();
  
  public abstract void setText(String paramString);
  
  public abstract void setTextFieldInvalid(boolean paramBoolean);
  
  public abstract void processTextFieldKeyEvent();
  
  public abstract void refreshText(String paramString);
  
  public abstract void setFocusBack();
  
  public abstract boolean hasTextField();
  
  public abstract UIComponent getTextField();
  
  public abstract void setTextFontColor(Object paramObject);
  
  public abstract void setForceCleanUpOnInvalid(boolean paramBoolean);
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.def.TextboxWidget
 * JD-Core Version:    0.7.0.1
 */