/*   1:    */ package com.mro.mobile.ui.res.widgets.android;
/*   2:    */ 
/*   3:    */ import android.content.Context;
/*   4:    */ import android.view.View;
/*   5:    */ import android.view.ViewGroup;
/*   6:    */ import android.view.ViewStub;
/*   7:    */ import android.widget.TextView;
/*   8:    */ import com.ibm.tivoli.maximo.mobile.android.util.UIUtil;
/*   9:    */ import com.ibm.tivoli.maximo.mobile.resources.R.id;
/*  10:    */ import com.ibm.tivoli.maximo.mobile.resources.R.layout;
/*  11:    */ import com.mro.mobile.MobileApplicationException;
/*  12:    */ import com.mro.mobile.ui.res.controls.InputControl;
/*  13:    */ import com.mro.mobile.ui.res.widgets.android.components.NImageLink;
/*  14:    */ import com.mro.mobile.ui.res.widgets.android.components.NLabel;
/*  15:    */ import com.mro.mobile.ui.res.widgets.android.components.NPanel;
/*  16:    */ import com.mro.mobile.ui.res.widgets.def.InputWidget;
/*  17:    */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  18:    */ 
/*  19:    */ public class ADInputWidgetImpl
/*  20:    */   extends ADAbstractWidgetImpl
/*  21:    */   implements InputWidget
/*  22:    */ {
/*  23:    */   protected void setController(InputControl controller)
/*  24:    */   {
/*  25: 41 */     super.setController(controller);
/*  26:    */   }
/*  27:    */   
/*  28:    */   protected InputControl getInputControl()
/*  29:    */   {
/*  30: 45 */     return (InputControl)getController();
/*  31:    */   }
/*  32:    */   
/*  33: 48 */   private NPanel labelPanel = null;
/*  34: 49 */   private NLabel label = null;
/*  35: 50 */   private NImageLink labelLink = null;
/*  36: 51 */   private TextView requiredLabel = null;
/*  37:    */   
/*  38:    */   public void setTextFieldFocus(UIComponent targetTextField) {}
/*  39:    */   
/*  40:    */   public UIComponent getLabelPanelUIComponent(boolean linkEnabled)
/*  41:    */     throws MobileApplicationException
/*  42:    */   {
/*  43: 67 */     String labelText = getInputControl().getBoundLabel();
/*  44: 68 */     if ((labelText != null) && (!labelText.equals("")))
/*  45:    */     {
/*  46: 70 */       Context context = AndroidEnv.getCurrentActivity();
/*  47: 72 */       if (this.labelPanel == null)
/*  48:    */       {
/*  49: 73 */         this.labelPanel = NPanel.createByInflate(getInputControl(), context, 0);
/*  50: 74 */         View.inflate(context, UIUtil.getResourceId(R.layout.class, "adinputwidgetimpl"), this.labelPanel);
/*  51:    */       }
/*  52: 77 */       ViewStub labelStub = (ViewStub)this.labelPanel.findViewById(UIUtil.getResourceId(R.id.class, "viewstub_labellinkrequired"));
/*  53: 78 */       ViewGroup viewGroup = (ViewGroup)labelStub.inflate();
/*  54:    */       
/*  55: 80 */       this.label = ((NLabel)viewGroup.findViewById(UIUtil.getResourceId(R.id.class, "label")));
/*  56: 81 */       this.label.postInstance(context, getInputControl(), labelText, null);
/*  57:    */       
/*  58: 83 */       this.labelLink = ((NImageLink)viewGroup.findViewById(UIUtil.getResourceId(R.id.class, "labelLink")));
/*  59: 84 */       this.labelLink.postInstance(getInputControl(), labelText);
/*  60: 85 */       this.labelLink.setEvent("showdesc");
/*  61: 87 */       if (getInputControl().isAttributeSet("descattribute"))
/*  62:    */       {
/*  63: 88 */         this.labelLink.setVisibility(linkEnabled ? 0 : 8);
/*  64: 89 */         this.label.setVisibility(linkEnabled ? 8 : 0);
/*  65:    */       }
/*  66:    */       else
/*  67:    */       {
/*  68: 91 */         this.labelLink.setVisibility(8);
/*  69: 92 */         this.label.setVisibility(0);
/*  70:    */       }
/*  71: 95 */       this.requiredLabel = ((TextView)this.labelPanel.findViewById(UIUtil.getResourceId(R.id.class, "requiredlabel")));
/*  72: 96 */       if (isRequired()) {
/*  73: 97 */         this.requiredLabel.setVisibility(0);
/*  74:    */       }
/*  75:    */     }
/*  76:101 */     return this.labelPanel;
/*  77:    */   }
/*  78:    */   
/*  79:    */   protected ViewGroup getViewGroupForSubclassContent(int layoutIdToLoadIntoViewStub)
/*  80:    */   {
/*  81:105 */     ViewStub viewStub = (ViewStub)this.labelPanel.findViewById(UIUtil.getResourceId(R.id.class, "viewstub_inputwidget_content"));
/*  82:106 */     viewStub.setLayoutResource(layoutIdToLoadIntoViewStub);
/*  83:107 */     return (ViewGroup)viewStub.inflate();
/*  84:    */   }
/*  85:    */   
/*  86:    */   private boolean isRequired()
/*  87:    */   {
/*  88:111 */     return (getInputControl().isRequired()) || ((getInputControl().inputMode != null) && (getInputControl().inputMode.equals("showrequired")));
/*  89:    */   }
/*  90:    */   
/*  91:    */   public void setRightConstraints(UIComponent component) {}
/*  92:    */   
/*  93:    */   public void setLeftConstraints(UIComponent component) {}
/*  94:    */   
/*  95:    */   public void refreshLabel()
/*  96:    */     throws MobileApplicationException
/*  97:    */   {
/*  98:121 */     if (this.labelPanel != null)
/*  99:    */     {
/* 100:122 */       boolean isRequired = isRequired();
/* 101:123 */       this.requiredLabel.setVisibility(isRequired ? 0 : 8);
/* 102:    */     }
/* 103:    */   }
/* 104:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.ADInputWidgetImpl
 * JD-Core Version:    0.7.0.1
 */