package com.mro.mobile.ui.res.widgets.def;

public abstract interface StateWidget
  extends AbstractWidget
{
  public abstract void createStatePanel();
  
  public abstract void addToStatePanel(UIComponent paramUIComponent);
  
  public abstract void removeAllFromStatePanel();
  
  public abstract boolean isStateListener(UIComponent paramUIComponent);
  
  public abstract UIComponent[] resolveStateComponents();
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.def.StateWidget
 * JD-Core Version:    0.7.0.1
 */