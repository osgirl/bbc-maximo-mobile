package com.mro.mobile.ui.res.widgets.android;

import com.mro.mobile.ui.res.widgets.def.MenuViewWidget;

public class ADMenuViewWidgetImpl
  extends ADMenuWidgetImpl
  implements MenuViewWidget
{}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.ADMenuViewWidgetImpl
 * JD-Core Version:    0.7.0.1
 */