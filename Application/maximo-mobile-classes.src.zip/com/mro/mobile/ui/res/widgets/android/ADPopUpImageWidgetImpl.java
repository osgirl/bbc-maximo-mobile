/*   1:    */ package com.mro.mobile.ui.res.widgets.android;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.mbo.MobileMboInfo;
/*   5:    */ import com.mro.mobile.ui.MobileMboDataBean;
/*   6:    */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*   7:    */ import com.mro.mobile.ui.res.controls.utils.ControlNodeData;
/*   8:    */ import com.mro.mobile.ui.res.controls.utils.ControlStyle;
/*   9:    */ import com.mro.mobile.ui.res.widgets.android.components.NMenu;
/*  10:    */ import com.mro.mobile.ui.res.widgets.android.components.NMenuItem;
/*  11:    */ import com.mro.mobile.ui.res.widgets.android.components.NPanel;
/*  12:    */ import com.mro.mobile.ui.res.widgets.android.components.NPopUpImage;
/*  13:    */ import com.mro.mobile.ui.res.widgets.android.components.table.NTableListenerManager;
/*  14:    */ import com.mro.mobile.ui.res.widgets.def.PopUpImageWidget;
/*  15:    */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  16:    */ import com.mro.mobile.util.MobileLogger;
/*  17:    */ import java.util.ArrayList;
/*  18:    */ import java.util.Vector;
/*  19:    */ 
/*  20:    */ public class ADPopUpImageWidgetImpl
/*  21:    */   extends ADAbstractWidgetImpl
/*  22:    */   implements PopUpImageWidget
/*  23:    */ {
/*  24:    */   private NPopUpImage popUpImage;
/*  25:    */   
/*  26:    */   public ArrayList<?> getVisibleContents(ArrayList menuContents)
/*  27:    */   {
/*  28: 47 */     ArrayList<UIComponent> newList = new ArrayList();
/*  29: 48 */     for (Object comps : menuContents)
/*  30:    */     {
/*  31: 49 */       UIComponent comp = ((UIComponent[])(UIComponent[])comps)[0];
/*  32: 50 */       if (!processIfMenuItem(comp, newList)) {
/*  33: 51 */         processIfPanel(comp, newList);
/*  34:    */       }
/*  35:    */     }
/*  36: 54 */     return newList;
/*  37:    */   }
/*  38:    */   
/*  39:    */   private void processIfPanel(UIComponent comp, ArrayList<UIComponent> newList)
/*  40:    */   {
/*  41: 58 */     if ((comp instanceof NPanel))
/*  42:    */     {
/*  43: 59 */       NPanel panel = (NPanel)comp;
/*  44: 60 */       if (panel.isVisible()) {
/*  45:    */         try
/*  46:    */         {
/*  47: 62 */           ArrayList<?> menuItems = panel.getController().composeChildren();
/*  48: 63 */           for (Object menuComps : menuItems)
/*  49:    */           {
/*  50: 64 */             UIComponent menuComp = ((UIComponent[])(UIComponent[])menuComps)[0];
/*  51: 65 */             processIfMenuItem(menuComp, newList);
/*  52:    */           }
/*  53:    */         }
/*  54:    */         catch (MobileApplicationException e)
/*  55:    */         {
/*  56: 68 */           getDefaultLogger().warn("Error encountered processing menuitems", e);
/*  57:    */         }
/*  58:    */       }
/*  59:    */     }
/*  60:    */   }
/*  61:    */   
/*  62:    */   private boolean processIfMenuItem(UIComponent comp, ArrayList<UIComponent> newList)
/*  63:    */   {
/*  64: 75 */     if ((comp instanceof NMenuItem))
/*  65:    */     {
/*  66: 76 */       NMenuItem item = (NMenuItem)comp;
/*  67: 77 */       if (item.isVisible()) {
/*  68: 78 */         newList.add(item);
/*  69:    */       }
/*  70: 80 */       return true;
/*  71:    */     }
/*  72: 82 */     return false;
/*  73:    */   }
/*  74:    */   
/*  75:    */   public UIComponent[] createPopUp(String singleActionImg, String menuTitle, AbstractMobileControl controller)
/*  76:    */   {
/*  77: 95 */     this.popUpImage = NPopUpImage.createByInflate(controller, AndroidEnv.getCurrentActivity(), singleActionImg);
/*  78: 96 */     if (NTableListenerManager.instance().isWidgetControlInTable(getController())) {
/*  79: 97 */       this.popUpImage.setTableClickable(NTableListenerManager.instance().getTableClickable());
/*  80:    */     }
/*  81: 99 */     this.popUpImage.setTitle(menuTitle);
/*  82:100 */     UIComponent[] retcomponent = { this.popUpImage };
/*  83:101 */     return retcomponent;
/*  84:    */   }
/*  85:    */   
/*  86:    */   public void setControlVisibility(UIComponent popup, boolean visible)
/*  87:    */   {
/*  88:113 */     ((NPopUpImage)popup).setVisible(visible);
/*  89:    */   }
/*  90:    */   
/*  91:    */   public void cleanup(UIComponent uicomp)
/*  92:    */   {
/*  93:126 */     NPopUpImage popup = (NPopUpImage)uicomp;
/*  94:127 */     if (popup != null) {
/*  95:128 */       popup.cleanup();
/*  96:    */     }
/*  97:    */   }
/*  98:    */   
/*  99:    */   public boolean refreshPopUpControl()
/* 100:    */     throws MobileApplicationException
/* 101:    */   {
/* 102:140 */     this.popUpImage.refreshMenu();
/* 103:141 */     return true;
/* 104:    */   }
/* 105:    */   
/* 106:    */   public String getStringValueFromComponentController(UIComponent comp, String attrib)
/* 107:    */   {
/* 108:153 */     return ((NMenuItem)comp).getController().getStringValue(attrib);
/* 109:    */   }
/* 110:    */   
/* 111:    */   public String getComponentEvent(UIComponent comp)
/* 112:    */   {
/* 113:165 */     return ((NMenuItem)comp).getEvent();
/* 114:    */   }
/* 115:    */   
/* 116:    */   public String getComponentCId(UIComponent comp)
/* 117:    */   {
/* 118:177 */     return comp.getCId();
/* 119:    */   }
/* 120:    */   
/* 121:    */   public String getComponentTargetId(UIComponent comp)
/* 122:    */   {
/* 123:189 */     return ((NMenuItem)comp).getTargetId();
/* 124:    */   }
/* 125:    */   
/* 126:    */   public String getComponentLabel(UIComponent comp)
/* 127:    */   {
/* 128:201 */     return ((NMenuItem)comp).getLabel();
/* 129:    */   }
/* 130:    */   
/* 131:    */   public AbstractMobileControl getController(UIComponent comp)
/* 132:    */   {
/* 133:213 */     return comp.getController();
/* 134:    */   }
/* 135:    */   
/* 136:    */   public boolean addSeperator(UIComponent comp)
/* 137:    */   {
/* 138:226 */     return true;
/* 139:    */   }
/* 140:    */   
/* 141:    */   public void addComponentInfoToPopUpImage(UIComponent comp, UIComponent mPopUp, ControlStyle style, int xx)
/* 142:    */   {
/* 143:240 */     NPopUpImage inPopUP = (NPopUpImage)mPopUp;
/* 144:241 */     NMenuItem item = (NMenuItem)comp;
/* 145:242 */     ControlNodeData cnd = new ControlNodeData();
/* 146:243 */     cnd.setEvent(item.getEvent());
/* 147:244 */     cnd.setId(item.getCId());
/* 148:245 */     cnd.setTargetid(item.getTargetId());
/* 149:246 */     cnd.setLabel(item.getLabel());
/* 150:247 */     cnd.setController(item.getController());
/* 151:248 */     inPopUP.getControlNodeData().add(cnd);
/* 152:249 */     inPopUP.getMainMenu().addChildUIComponent(comp);
/* 153:    */   }
/* 154:    */   
/* 155:    */   public Vector getControlNodeData(UIComponent mPopUp)
/* 156:    */   {
/* 157:261 */     return ((NPopUpImage)mPopUp).getControlNodeData();
/* 158:    */   }
/* 159:    */   
/* 160:    */   public void setControlNodeData(Vector controlNodeData, UIComponent mPopUp)
/* 161:    */   {
/* 162:273 */     ((NPopUpImage)mPopUp).setControlNodeData(controlNodeData);
/* 163:    */   }
/* 164:    */   
/* 165:    */   public void clearControlNodeData(UIComponent mPopUp)
/* 166:    */   {
/* 167:286 */     ((NPopUpImage)mPopUp).getControlNodeData().clear();
/* 168:    */   }
/* 169:    */   
/* 170:    */   public void removeAllItems()
/* 171:    */   {
/* 172:297 */     this.popUpImage.getMainMenu().removeAllItems();
/* 173:    */   }
/* 174:    */   
/* 175:    */   public ArrayList getMenuContents(UIComponent comp)
/* 176:    */     throws MobileApplicationException
/* 177:    */   {
/* 178:309 */     return ((NPanel)comp).getController().composeChildren();
/* 179:    */   }
/* 180:    */   
/* 181:    */   public boolean isComponentAPanel(UIComponent comp)
/* 182:    */   {
/* 183:321 */     return comp instanceof NPanel;
/* 184:    */   }
/* 185:    */   
/* 186:    */   public boolean isPanelVisible(UIComponent comp)
/* 187:    */   {
/* 188:333 */     return ((NPanel)comp).isVisible();
/* 189:    */   }
/* 190:    */   
/* 191:    */   public void removeSelectionListenerFromPopup(UIComponent mPopUp) {}
/* 192:    */   
/* 193:    */   public boolean isPopUpListenerSet()
/* 194:    */   {
/* 195:357 */     return false;
/* 196:    */   }
/* 197:    */   
/* 198:    */   public void removeListenerFromMainMenu(UIComponent mPopUp) {}
/* 199:    */   
/* 200:    */   public void addNewListenerToMainMenu(UIComponent mPopUp) {}
/* 201:    */   
/* 202:    */   public void fireClickEvent(int textSize) {}
/* 203:    */   
/* 204:    */   public String resolveMenuTitle(String menuPattern)
/* 205:    */   {
/* 206:397 */     if (menuPattern != null) {
/* 207:    */       try
/* 208:    */       {
/* 209:399 */         MobileMboDataBean dataSource = getController().getDataBean();
/* 210:400 */         StringBuilder result = new StringBuilder();
/* 211:401 */         if (dataSource != null)
/* 212:    */         {
/* 213:402 */           String[] attributes = menuPattern.split(",");
/* 214:403 */           for (String attribute : attributes)
/* 215:    */           {
/* 216:404 */             attribute = attribute.trim();
/* 217:405 */             String value = attribute;
/* 218:406 */             if (dataSource.getMobileMboInfo().getAttributeInfo(attribute) != null) {
/* 219:407 */               value = dataSource.getValue(attribute);
/* 220:    */             }
/* 221:409 */             if (value != null) {
/* 222:410 */               result.append(value);
/* 223:    */             } else {
/* 224:412 */               result.append(attribute);
/* 225:    */             }
/* 226:414 */             result.append(" - ");
/* 227:    */           }
/* 228:416 */           int index = result.lastIndexOf(" - ");
/* 229:417 */           return index > 0 ? result.delete(index, result.length()).toString() : result.toString();
/* 230:    */         }
/* 231:    */       }
/* 232:    */       catch (MobileApplicationException e)
/* 233:    */       {
/* 234:420 */         getDefaultLogger().warn("Error encountered resolving menu title using menu pattern: " + menuPattern, e);
/* 235:    */       }
/* 236:    */     }
/* 237:423 */     return null;
/* 238:    */   }
/* 239:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.ADPopUpImageWidgetImpl
 * JD-Core Version:    0.7.0.1
 */