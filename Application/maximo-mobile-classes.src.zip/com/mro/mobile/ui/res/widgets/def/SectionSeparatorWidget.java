package com.mro.mobile.ui.res.widgets.def;

import com.mro.mobile.ui.res.controls.SectionSeparatorControl;

public abstract interface SectionSeparatorWidget
  extends AbstractWidget
{
  public abstract void createSectionSeparator(SectionSeparatorControl paramSectionSeparatorControl);
  
  public abstract void setOpaque(boolean paramBoolean);
  
  public abstract void setInsets(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  public abstract void setPreferredSize(int paramInt1, int paramInt2);
  
  public abstract UIComponent[] resolveSectionSeparatorWidgetComponents();
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.def.SectionSeparatorWidget
 * JD-Core Version:    0.7.0.1
 */