package com.mro.mobile.ui.res.widgets.def;

public abstract interface ToolBarRightWidget
  extends ToolBarContainerWidget
{}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.def.ToolBarRightWidget
 * JD-Core Version:    0.7.0.1
 */