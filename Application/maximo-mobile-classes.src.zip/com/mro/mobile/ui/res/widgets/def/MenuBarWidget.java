package com.mro.mobile.ui.res.widgets.def;

import java.util.ArrayList;

public abstract interface MenuBarWidget
  extends AbstractWidget
{
  public abstract void addMenusToBar(ArrayList paramArrayList);
  
  public abstract void showMenuBar();
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.def.MenuBarWidget
 * JD-Core Version:    0.7.0.1
 */