package com.mro.mobile.ui.res.widgets.def;

import com.mro.mobile.ui.res.controls.AbstractMobileControl;
import java.util.Enumeration;

public abstract interface UIComponent
{
  public abstract void setCId(String paramString);
  
  public abstract String getCId();
  
  public abstract void init();
  
  public abstract void addChildUIComponent(UIComponent paramUIComponent);
  
  public abstract boolean canContainChildren();
  
  public abstract Enumeration getChildren();
  
  public abstract AbstractMobileControl getController();
  
  public abstract void setController(AbstractMobileControl paramAbstractMobileControl);
  
  public abstract Object getConstraints();
  
  public abstract void setConstraints(Object paramObject);
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.def.UIComponent
 * JD-Core Version:    0.7.0.1
 */