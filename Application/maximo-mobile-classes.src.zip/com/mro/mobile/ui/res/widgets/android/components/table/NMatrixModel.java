package com.mro.mobile.ui.res.widgets.android.components.table;

public abstract interface NMatrixModel
{
  public abstract int getRows();
  
  public abstract int getCols();
  
  public abstract Object get(int paramInt1, int paramInt2);
  
  public abstract void put(int paramInt1, int paramInt2, Object paramObject);
  
  public abstract void removeRows(int paramInt1, int paramInt2);
  
  public abstract void removeCols(int paramInt1, int paramInt2);
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.components.table.NMatrixModel
 * JD-Core Version:    0.7.0.1
 */