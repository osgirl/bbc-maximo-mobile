/*   1:    */ package com.mro.mobile.ui.res.widgets.android.components;
/*   2:    */ 
/*   3:    */ import android.content.Context;
/*   4:    */ import android.text.TextUtils.TruncateAt;
/*   5:    */ import android.util.AttributeSet;
/*   6:    */ import android.view.View;
/*   7:    */ import android.view.View.OnClickListener;
/*   8:    */ import android.widget.LinearLayout.LayoutParams;
/*   9:    */ import android.widget.TextView;
/*  10:    */ import com.ibm.tivoli.maximo.mobile.android.camera.AttachmentIntentCameraCallback;
/*  11:    */ import com.ibm.tivoli.maximo.mobile.resources.R.layout;
/*  12:    */ import com.ibm.tivoli.maximo.mobile.resources.R.style;
/*  13:    */ import com.mro.mobile.MobileApplicationException;
/*  14:    */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*  15:    */ import com.mro.mobile.ui.res.controls.AttributeNameConstants;
/*  16:    */ import com.mro.mobile.ui.res.controls.InputControl;
/*  17:    */ import com.mro.mobile.ui.res.controls.LinkControl;
/*  18:    */ import com.mro.mobile.ui.res.controls.utils.ControlStyle;
/*  19:    */ import com.mro.mobile.ui.res.controls.utils.StyleManager;
/*  20:    */ import com.mro.mobile.ui.res.widgets.android.AndroidEnv;
/*  21:    */ import com.mro.mobile.ui.res.widgets.android.components.table.NTableListenerManager.TableClickable;
/*  22:    */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  23:    */ import com.mro.mobile.util.MobileLogger;
/*  24:    */ import com.mro.mobile.util.MobileLoggerFactory;
/*  25:    */ import java.util.Enumeration;
/*  26:    */ 
/*  27:    */ public class NImageLink
/*  28:    */   extends TextView
/*  29:    */   implements UIComponent, AttributeNameConstants
/*  30:    */ {
/*  31: 48 */   private static final int DEFAULT_XML_LAYOUT = com.ibm.tivoli.maximo.mobile.android.util.UIUtil.getResourceId(R.layout.class, "nimagelink");
/*  32:    */   public static final String STYLEKEY = "link";
/*  33: 52 */   private AbstractMobileControl controller = null;
/*  34: 53 */   private String event = null;
/*  35: 54 */   private String cid = null;
/*  36: 55 */   private String targetid = null;
/*  37: 56 */   private Object value = null;
/*  38: 57 */   private ControlStyle style = null;
/*  39: 58 */   private NTableListenerManager.TableClickable mTableClickable = null;
/*  40: 59 */   private NDrawerListenerManager.DrawerLinkClickable mDrawerClickable = null;
/*  41:    */   
/*  42:    */   public NImageLink(Context context)
/*  43:    */   {
/*  44: 63 */     super(context);
/*  45:    */   }
/*  46:    */   
/*  47:    */   public NImageLink(Context context, AttributeSet attrs)
/*  48:    */   {
/*  49: 67 */     super(context, attrs);
/*  50:    */   }
/*  51:    */   
/*  52:    */   public NImageLink(Context context, AttributeSet attrs, int defStyle)
/*  53:    */   {
/*  54: 71 */     super(context, attrs, defStyle);
/*  55:    */   }
/*  56:    */   
/*  57:    */   public static NImageLink createByInflate(AbstractMobileControl control, Context context)
/*  58:    */   {
/*  59: 75 */     return createByInflate(control, context, null);
/*  60:    */   }
/*  61:    */   
/*  62:    */   public static NImageLink createByInflate(AbstractMobileControl control, Context context, String label)
/*  63:    */   {
/*  64: 79 */     return createByInflate(DEFAULT_XML_LAYOUT, control, context, label);
/*  65:    */   }
/*  66:    */   
/*  67:    */   public static NImageLink createByInflate(int layoutId, AbstractMobileControl control, Context context, String label)
/*  68:    */   {
/*  69: 83 */     NImageLink imagelink = (NImageLink)View.inflate(context, layoutId, null);
/*  70: 84 */     imagelink.setLayoutParams(new LinearLayout.LayoutParams(-2, -2));
/*  71: 85 */     imagelink.postInstance(control, label);
/*  72: 86 */     return imagelink;
/*  73:    */   }
/*  74:    */   
/*  75:    */   public void postInstance(AbstractMobileControl control, String label)
/*  76:    */   {
/*  77: 90 */     setController(control);
/*  78: 91 */     if (control != null)
/*  79:    */     {
/*  80: 92 */       if ((control instanceof InputControl)) {
/*  81: 93 */         setId(NIDMapper.getAndroidIdFor(control.getId() + "_labellink"));
/*  82:    */       } else {
/*  83: 95 */         setId(NIDMapper.getAndroidIdFor(control.getId()));
/*  84:    */       }
/*  85:    */     }
/*  86:    */     else {
/*  87: 98 */       setId(NIDMapper.getNextId());
/*  88:    */     }
/*  89:100 */     setupLink(label, control != null ? control.getStyle("link") : null);
/*  90:101 */     init();
/*  91:    */   }
/*  92:    */   
/*  93:    */   private void setupLink(String s, ControlStyle style)
/*  94:    */   {
/*  95:105 */     String linkText = calculateFinalTextValue(s);
/*  96:106 */     this.style = style;
/*  97:107 */     setText(linkText);
/*  98:    */     
/*  99:    */ 
/* 100:110 */     setSingleLine(true);
/* 101:111 */     setEllipsize(TextUtils.TruncateAt.MIDDLE);
/* 102:113 */     if (style != null)
/* 103:    */     {
/* 104:114 */       String styleName = style.getStyleName();
/* 105:115 */       int styleToApply = com.ibm.tivoli.maximo.mobile.android.util.UIUtil.getResourceId(R.style.class, styleName);
/* 106:116 */       if (styleToApply != 0) {
/* 107:117 */         setTextAppearance(getContext(), styleToApply);
/* 108:    */       }
/* 109:    */     }
/* 110:    */   }
/* 111:    */   
/* 112:    */   private String calculateFinalTextValue(String s)
/* 113:    */   {
/* 114:123 */     String text = s;
/* 115:124 */     if (s == null) {
/* 116:125 */       text = "";
/* 117:    */     } else {
/* 118:128 */       text = text + " ";
/* 119:    */     }
/* 120:130 */     return text;
/* 121:    */   }
/* 122:    */   
/* 123:    */   public String getCId()
/* 124:    */   {
/* 125:134 */     return this.cid;
/* 126:    */   }
/* 127:    */   
/* 128:    */   public Object getValue()
/* 129:    */   {
/* 130:138 */     return this.value;
/* 131:    */   }
/* 132:    */   
/* 133:    */   public void setValue(Object value)
/* 134:    */   {
/* 135:142 */     this.value = value;
/* 136:    */   }
/* 137:    */   
/* 138:    */   public String getTargetId()
/* 139:    */   {
/* 140:146 */     return this.targetid;
/* 141:    */   }
/* 142:    */   
/* 143:    */   public void setTargetId(String targetid)
/* 144:    */   {
/* 145:150 */     this.targetid = targetid;
/* 146:    */   }
/* 147:    */   
/* 148:    */   public void refreshLink(String label)
/* 149:    */   {
/* 150:154 */     setupLink(label, this.style);
/* 151:    */   }
/* 152:    */   
/* 153:    */   public void init()
/* 154:    */   {
/* 155:158 */     setOnClickListener(new View.OnClickListener()
/* 156:    */     {
/* 157:    */       public void onClick(View v)
/* 158:    */       {
/* 159:160 */         NImageLink.this.firePreListeners();
/* 160:161 */         AndroidEnv.closeCurrentPopUpPage();
/* 161:162 */         if (NImageLink.this.isCameraEvent())
/* 162:    */         {
/* 163:163 */           NImageLink.this.firePostListeners();
/* 164:164 */           LinkControl myControl = (LinkControl)NImageLink.this.getController();
/* 165:    */           try
/* 166:    */           {
/* 167:166 */             new AttachmentIntentCameraCallback(myControl).launchIntentForResult();
/* 168:    */           }
/* 169:    */           catch (MobileApplicationException e)
/* 170:    */           {
/* 171:168 */             com.mro.mobile.ui.res.UIUtil.showFailureMessageBox(e.getCompleteMessage());
/* 172:169 */             MobileLoggerFactory.getDefaultLogger().error("Error lauching camera activity", e);
/* 173:    */           }
/* 174:171 */           return;
/* 175:    */         }
/* 176:173 */         NImageLink.this.getController().handleEvent(NImageLink.this.event, NImageLink.this.targetid, NImageLink.this.value);
/* 177:    */         
/* 178:175 */         NImageLink.this.firePostListeners();
/* 179:    */       }
/* 180:    */     });
/* 181:    */   }
/* 182:    */   
/* 183:    */   private boolean isCameraEvent()
/* 184:    */   {
/* 185:181 */     return (this.event != null) && (this.event.equalsIgnoreCase("CAMERA"));
/* 186:    */   }
/* 187:    */   
/* 188:    */   private void firePreListeners()
/* 189:    */   {
/* 190:185 */     if (this.mTableClickable != null) {
/* 191:186 */       this.mTableClickable.tableClicked(this);
/* 192:    */     }
/* 193:    */   }
/* 194:    */   
/* 195:    */   private void firePostListeners()
/* 196:    */   {
/* 197:191 */     if (this.mDrawerClickable != null) {
/* 198:192 */       this.mDrawerClickable.drawerLinkClicked(this);
/* 199:    */     }
/* 200:    */   }
/* 201:    */   
/* 202:    */   public void setTableClickable(NTableListenerManager.TableClickable tc)
/* 203:    */   {
/* 204:197 */     this.mTableClickable = tc;
/* 205:    */   }
/* 206:    */   
/* 207:    */   public void setButtonDrawerClickable(NDrawerListenerManager.DrawerLinkClickable dc)
/* 208:    */   {
/* 209:201 */     this.mDrawerClickable = dc;
/* 210:    */   }
/* 211:    */   
/* 212:    */   public void addChildUIComponent(UIComponent child) {}
/* 213:    */   
/* 214:    */   public boolean canContainChildren()
/* 215:    */   {
/* 216:208 */     return false;
/* 217:    */   }
/* 218:    */   
/* 219:    */   public Enumeration getChildren()
/* 220:    */   {
/* 221:212 */     return null;
/* 222:    */   }
/* 223:    */   
/* 224:    */   public AbstractMobileControl getController()
/* 225:    */   {
/* 226:216 */     return this.controller;
/* 227:    */   }
/* 228:    */   
/* 229:    */   public void setController(AbstractMobileControl controller)
/* 230:    */   {
/* 231:220 */     this.controller = controller;
/* 232:    */   }
/* 233:    */   
/* 234:224 */   private LinearLayout.LayoutParams constraints = null;
/* 235:    */   
/* 236:    */   public Object getConstraints()
/* 237:    */   {
/* 238:232 */     return this.constraints;
/* 239:    */   }
/* 240:    */   
/* 241:    */   public void setConstraints(Object consts)
/* 242:    */   {
/* 243:243 */     this.constraints = ((LinearLayout.LayoutParams)consts);
/* 244:244 */     setLayoutParams(this.constraints);
/* 245:245 */     requestLayout();
/* 246:    */   }
/* 247:    */   
/* 248:    */   public String getEvent()
/* 249:    */   {
/* 250:249 */     return this.event;
/* 251:    */   }
/* 252:    */   
/* 253:    */   public void setEvent(String event)
/* 254:    */   {
/* 255:253 */     this.event = event;
/* 256:    */   }
/* 257:    */   
/* 258:    */   public void setCId(String cid)
/* 259:    */   {
/* 260:257 */     this.cid = cid;
/* 261:    */   }
/* 262:    */   
/* 263:    */   public void applyStyle(Object styler)
/* 264:    */   {
/* 265:261 */     if (styler != null)
/* 266:    */     {
/* 267:262 */       ControlStyle style = null;
/* 268:263 */       if ((styler instanceof ControlStyle))
/* 269:    */       {
/* 270:264 */         style = (ControlStyle)styler;
/* 271:    */       }
/* 272:265 */       else if ((styler instanceof AbstractMobileControl))
/* 273:    */       {
/* 274:266 */         this.controller = ((AbstractMobileControl)styler);
/* 275:267 */         style = this.controller.getStyle("link");
/* 276:    */       }
/* 277:    */       else
/* 278:    */       {
/* 279:269 */         style = StyleManager.getStyle("link", null);
/* 280:    */       }
/* 281:271 */       String styleName = style.getStyleName() + "_link";
/* 282:272 */       int styleToApply = com.ibm.tivoli.maximo.mobile.android.util.UIUtil.getResourceId(R.style.class, styleName);
/* 283:273 */       if (styleToApply != 0) {
/* 284:274 */         setTextAppearance(getContext(), styleToApply);
/* 285:    */       }
/* 286:    */     }
/* 287:    */   }
/* 288:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.components.NImageLink
 * JD-Core Version:    0.7.0.1
 */