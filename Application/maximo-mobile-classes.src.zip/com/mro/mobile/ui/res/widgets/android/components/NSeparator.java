/*   1:    */ package com.mro.mobile.ui.res.widgets.android.components;
/*   2:    */ 
/*   3:    */ import android.content.Context;
/*   4:    */ import android.util.AttributeSet;
/*   5:    */ import android.view.View;
/*   6:    */ import android.view.ViewGroup.LayoutParams;
/*   7:    */ import android.widget.LinearLayout;
/*   8:    */ import com.ibm.tivoli.maximo.mobile.android.util.UIUtil;
/*   9:    */ import com.ibm.tivoli.maximo.mobile.resources.R.color;
/*  10:    */ import com.ibm.tivoli.maximo.mobile.resources.R.layout;
/*  11:    */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*  12:    */ import com.mro.mobile.ui.res.controls.utils.ControlStyle;
/*  13:    */ import com.mro.mobile.ui.res.controls.utils.StyleManager;
/*  14:    */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  15:    */ import java.util.Enumeration;
/*  16:    */ 
/*  17:    */ public class NSeparator
/*  18:    */   extends LinearLayout
/*  19:    */   implements UIComponent
/*  20:    */ {
/*  21: 20 */   private String cid = null;
/*  22:    */   protected int top;
/*  23:    */   protected int left;
/*  24:    */   protected int bottom;
/*  25:    */   protected int right;
/*  26: 23 */   private AbstractMobileControl controller = null;
/*  27: 24 */   private static final int DEFAULT_XML_LAYOUT = UIUtil.getResourceId(R.layout.class, "nsectionseparator");
/*  28:    */   public static final String STYLEKEY = "line";
/*  29:    */   
/*  30:    */   public NSeparator(Context context)
/*  31:    */   {
/*  32: 28 */     super(context);
/*  33:    */   }
/*  34:    */   
/*  35:    */   public void setInsets(int top, int left, int bottom, int right)
/*  36:    */   {
/*  37: 32 */     if ((top != this.top) || (left != this.left) || (bottom != this.bottom) || (right != this.right))
/*  38:    */     {
/*  39: 33 */       this.top = top;
/*  40: 34 */       this.left = left;
/*  41: 35 */       this.bottom = bottom;
/*  42: 36 */       this.right = right;
/*  43: 37 */       setPadding(left, top, right, bottom);
/*  44:    */     }
/*  45:    */   }
/*  46:    */   
/*  47:    */   private void setupLine(Object styler, Context context)
/*  48:    */   {
/*  49: 42 */     ControlStyle style = null;
/*  50: 43 */     if ((styler instanceof ControlStyle))
/*  51:    */     {
/*  52: 44 */       style = (ControlStyle)styler;
/*  53:    */     }
/*  54: 45 */     else if ((styler instanceof AbstractMobileControl))
/*  55:    */     {
/*  56: 46 */       this.controller = ((AbstractMobileControl)styler);
/*  57: 47 */       style = this.controller.getStyle("line");
/*  58:    */     }
/*  59:    */     else
/*  60:    */     {
/*  61: 49 */       style = StyleManager.getStyle("line", null);
/*  62:    */     }
/*  63: 52 */     String styleName = style.getStyleName();
/*  64:    */     
/*  65: 54 */     int styleToApply = UIUtil.getResourceId(R.color.class, styleName);
/*  66: 55 */     if (styleToApply != 0) {
/*  67: 56 */       setBackgroundResource(styleToApply);
/*  68:    */     }
/*  69:    */   }
/*  70:    */   
/*  71:    */   public NSeparator(Context context, AttributeSet attrs)
/*  72:    */   {
/*  73: 62 */     super(context, attrs);
/*  74:    */   }
/*  75:    */   
/*  76:    */   public static NSeparator createByInflate(AbstractMobileControl control, Context context)
/*  77:    */   {
/*  78: 66 */     return createByInflate(DEFAULT_XML_LAYOUT, control, context);
/*  79:    */   }
/*  80:    */   
/*  81:    */   public static NSeparator createByInflate(int layoutId, AbstractMobileControl control, Context context)
/*  82:    */   {
/*  83: 70 */     NSeparator sep = (NSeparator)View.inflate(context, layoutId, null);
/*  84: 71 */     sep.postInstance(control, context);
/*  85: 72 */     return sep;
/*  86:    */   }
/*  87:    */   
/*  88:    */   public void setOpaque(boolean op)
/*  89:    */   {
/*  90: 76 */     setVisibility(op ? 0 : 4);
/*  91:    */   }
/*  92:    */   
/*  93:    */   private void postInstance(AbstractMobileControl control, Context context)
/*  94:    */   {
/*  95: 80 */     setController(control);
/*  96: 81 */     if (this.controller != null) {
/*  97: 82 */       setId(NIDMapper.getAndroidIdFor(this.controller.getId()));
/*  98:    */     } else {
/*  99: 84 */       setId(NIDMapper.getNextId());
/* 100:    */     }
/* 101: 86 */     init();
/* 102: 87 */     setupLine(control, context);
/* 103:    */   }
/* 104:    */   
/* 105:    */   public void setCId(String cid)
/* 106:    */   {
/* 107: 92 */     this.cid = cid;
/* 108:    */   }
/* 109:    */   
/* 110:    */   public String getCId()
/* 111:    */   {
/* 112: 97 */     return this.cid;
/* 113:    */   }
/* 114:    */   
/* 115:    */   public void init() {}
/* 116:    */   
/* 117:    */   public void addChildUIComponent(UIComponent child) {}
/* 118:    */   
/* 119:    */   public boolean canContainChildren()
/* 120:    */   {
/* 121:110 */     return false;
/* 122:    */   }
/* 123:    */   
/* 124:    */   public Enumeration getChildren()
/* 125:    */   {
/* 126:115 */     return null;
/* 127:    */   }
/* 128:    */   
/* 129:    */   public AbstractMobileControl getController()
/* 130:    */   {
/* 131:120 */     return this.controller;
/* 132:    */   }
/* 133:    */   
/* 134:    */   public void setController(AbstractMobileControl controller)
/* 135:    */   {
/* 136:125 */     this.controller = controller;
/* 137:    */   }
/* 138:    */   
/* 139:    */   public Object getConstraints()
/* 140:    */   {
/* 141:130 */     return null;
/* 142:    */   }
/* 143:    */   
/* 144:    */   public void setConstraints(Object constraints)
/* 145:    */   {
/* 146:135 */     ViewGroup.LayoutParams larms = (ViewGroup.LayoutParams)constraints;
/* 147:136 */     setLayoutParams(larms);
/* 148:137 */     setPadding(this.left, 0, this.right, larms.height);
/* 149:    */   }
/* 150:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.components.NSeparator
 * JD-Core Version:    0.7.0.1
 */