/*  1:   */ package com.mro.mobile.ui.res.widgets.android;
/*  2:   */ 
/*  3:   */ import android.view.ViewGroup;
/*  4:   */ import com.ibm.tivoli.maximo.mobile.android.util.UIUtil;
/*  5:   */ import com.ibm.tivoli.maximo.mobile.resources.R.layout;
/*  6:   */ import com.mro.mobile.MobileApplicationException;
/*  7:   */ import com.mro.mobile.ui.res.controls.ReasonForChangeControl;
/*  8:   */ import com.mro.mobile.ui.res.controls.utils.ControlStyle;
/*  9:   */ import com.mro.mobile.ui.res.widgets.android.components.NComboBox;
/* 10:   */ import com.mro.mobile.ui.res.widgets.android.components.NLabel;
/* 11:   */ import com.mro.mobile.ui.res.widgets.android.components.NPanel;
/* 12:   */ import com.mro.mobile.ui.res.widgets.android.components.NTextField;
/* 13:   */ import com.mro.mobile.ui.res.widgets.def.ReasonForChangeWidget;
/* 14:   */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/* 15:   */ 
/* 16:   */ public class ADReasonForChangeWidgetImpl
/* 17:   */   extends ADInputWidgetImpl
/* 18:   */   implements ReasonForChangeWidget
/* 19:   */ {
/* 20:19 */   private NComboBox chgReasonDropDown = null;
/* 21:20 */   private NTextField chgReasonTextBox = null;
/* 22:   */   
/* 23:   */   private ReasonForChangeControl getReasonForChangeControl()
/* 24:   */   {
/* 25:23 */     return (ReasonForChangeControl)getController();
/* 26:   */   }
/* 27:   */   
/* 28:   */   public void createReasonForChange(String id)
/* 29:   */   {
/* 30:28 */     this.chgReasonDropDown = NComboBox.createByInflate(getReasonForChangeControl(), AndroidEnv.getCurrentActivity());
/* 31:29 */     this.chgReasonDropDown.setCId(id);
/* 32:   */   }
/* 33:   */   
/* 34:   */   public void createChangeReasonTextBox(int size)
/* 35:   */   {
/* 36:34 */     this.chgReasonTextBox = new NTextField(getReasonForChangeControl(), AndroidEnv.getCurrentActivity(), "", 0, size, 5);
/* 37:35 */     setLeftConstraints(this.chgReasonTextBox);
/* 38:   */   }
/* 39:   */   
/* 40:   */   public void setChangeReasonTextBoxFocus()
/* 41:   */   {
/* 42:40 */     getReasonForChangeControl().setTextFieldFocus(this.chgReasonTextBox);
/* 43:   */   }
/* 44:   */   
/* 45:   */   public void addItemToReasonDropdown(String label, ControlStyle style)
/* 46:   */   {
/* 47:45 */     this.chgReasonDropDown.addItem(NLabel.createByInflate(getReasonForChangeControl(), AndroidEnv.getCurrentActivity(), label, style));
/* 48:   */   }
/* 49:   */   
/* 50:   */   public String getControlValue()
/* 51:   */   {
/* 52:50 */     if (this.chgReasonDropDown != null)
/* 53:   */     {
/* 54:51 */       Object item = this.chgReasonDropDown.getSelectedItem();
/* 55:52 */       if (item != null)
/* 56:   */       {
/* 57:53 */         if ((item instanceof NLabel)) {
/* 58:54 */           return ((NLabel)item).getText().toString();
/* 59:   */         }
/* 60:56 */         return item.toString();
/* 61:   */       }
/* 62:   */     }
/* 63:59 */     else if (this.chgReasonTextBox != null)
/* 64:   */     {
/* 65:60 */       return this.chgReasonTextBox.getText().toString();
/* 66:   */     }
/* 67:62 */     return null;
/* 68:   */   }
/* 69:   */   
/* 70:   */   public UIComponent[] resolveChangeReasonDropDownComponents(String label)
/* 71:   */     throws MobileApplicationException
/* 72:   */   {
/* 73:67 */     UIComponent[] reasonComponents = null;
/* 74:68 */     if ((label != null) && (!label.equals("")))
/* 75:   */     {
/* 76:69 */       NPanel labelPanel = (NPanel)getReasonForChangeControl().getLabelPanelUIComponent(false);
/* 77:71 */       if (labelPanel != null)
/* 78:   */       {
/* 79:73 */         ViewGroup viewGroup = getViewGroupForSubclassContent(UIUtil.getResourceId(R.layout.class, "adreasonforchangewidgetimpl"));
/* 80:74 */         viewGroup.addView(this.chgReasonDropDown);
/* 81:75 */         reasonComponents = new UIComponent[] { labelPanel };
/* 82:   */       }
/* 83:   */       else
/* 84:   */       {
/* 85:77 */         reasonComponents = new UIComponent[] { this.chgReasonDropDown };
/* 86:   */       }
/* 87:   */     }
/* 88:80 */     return reasonComponents;
/* 89:   */   }
/* 90:   */   
/* 91:   */   public UIComponent[] resolveReasonForChangeComponents()
/* 92:   */     throws MobileApplicationException
/* 93:   */   {
/* 94:85 */     UIComponent[] reasonComponents = null;
/* 95:86 */     NPanel labelPanel = (NPanel)getReasonForChangeControl().getLabelPanelUIComponent(false);
/* 96:88 */     if (labelPanel != null)
/* 97:   */     {
/* 98:90 */       ViewGroup viewGroup = getViewGroupForSubclassContent(UIUtil.getResourceId(R.layout.class, "adreasonforchangewidgetimpl"));
/* 99:91 */       viewGroup.addView(this.chgReasonTextBox);
/* :0:92 */       reasonComponents = new UIComponent[] { labelPanel };
/* :1:   */     }
/* :2:   */     else
/* :3:   */     {
/* :4:94 */       reasonComponents = new UIComponent[] { this.chgReasonTextBox };
/* :5:   */     }
/* :6:96 */     return reasonComponents;
/* :7:   */   }
/* :8:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.ADReasonForChangeWidgetImpl
 * JD-Core Version:    0.7.0.1
 */