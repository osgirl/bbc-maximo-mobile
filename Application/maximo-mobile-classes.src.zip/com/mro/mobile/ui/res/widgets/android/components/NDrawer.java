/*   1:    */ package com.mro.mobile.ui.res.widgets.android.components;
/*   2:    */ 
/*   3:    */ import android.content.Context;
/*   4:    */ import android.graphics.Color;
/*   5:    */ import android.graphics.drawable.Drawable;
/*   6:    */ import android.util.AttributeSet;
/*   7:    */ import android.view.View;
/*   8:    */ import android.view.ViewGroup.LayoutParams;
/*   9:    */ import android.view.ViewParent;
/*  10:    */ import android.widget.SlidingDrawer;
/*  11:    */ import com.ibm.tivoli.maximo.mobile.android.util.ImageUtil;
/*  12:    */ import com.ibm.tivoli.maximo.mobile.android.util.UIUtil;
/*  13:    */ import com.ibm.tivoli.maximo.mobile.resources.R.id;
/*  14:    */ import com.ibm.tivoli.maximo.mobile.resources.R.layout;
/*  15:    */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*  16:    */ import com.mro.mobile.ui.res.controls.PageControl;
/*  17:    */ import com.mro.mobile.ui.res.controls.SectionControl;
/*  18:    */ import com.mro.mobile.ui.res.controls.utils.ControlStyle;
/*  19:    */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  20:    */ import java.util.Enumeration;
/*  21:    */ import java.util.Vector;
/*  22:    */ 
/*  23:    */ public class NDrawer
/*  24:    */   extends SlidingDrawer
/*  25:    */   implements UIComponent
/*  26:    */ {
/*  27: 25 */   protected AbstractMobileControl controller = null;
/*  28: 27 */   private static final int DEFAULT_XML_LAYOUT = UIUtil.getResourceId(R.layout.class, "ndrawer");
/*  29: 29 */   private String cid = null;
/*  30: 30 */   private Vector children = new Vector();
/*  31: 31 */   private ControlStyle style = null;
/*  32:    */   
/*  33:    */   public NDrawer(Context context, AttributeSet attrs)
/*  34:    */   {
/*  35: 34 */     super(context, attrs);
/*  36:    */   }
/*  37:    */   
/*  38:    */   public static NDrawer createByInflate(AbstractMobileControl control, Context context)
/*  39:    */   {
/*  40: 38 */     return createByInflate(DEFAULT_XML_LAYOUT, control, context);
/*  41:    */   }
/*  42:    */   
/*  43:    */   public static NDrawer createByInflate(int layoutId, AbstractMobileControl control, Context context)
/*  44:    */   {
/*  45: 43 */     NDrawer panel = (NDrawer)View.inflate(context, layoutId, null);
/*  46: 44 */     panel.postInstance(control);
/*  47: 45 */     return panel;
/*  48:    */   }
/*  49:    */   
/*  50:    */   protected void postInstance(AbstractMobileControl control)
/*  51:    */   {
/*  52: 49 */     setController(control);
/*  53: 50 */     if (control != null)
/*  54:    */     {
/*  55: 51 */       if (((control instanceof PageControl)) || ((control instanceof SectionControl))) {
/*  56: 52 */         setId(NIDMapper.getAndroidIdFor(control.getId()));
/*  57:    */       } else {
/*  58: 54 */         setId(NIDMapper.getNextId());
/*  59:    */       }
/*  60:    */     }
/*  61:    */     else {
/*  62: 58 */       setId(NIDMapper.getNextId());
/*  63:    */     }
/*  64: 61 */     init();
/*  65:    */   }
/*  66:    */   
/*  67:    */   public void setCId(String cid)
/*  68:    */   {
/*  69: 66 */     this.cid = cid;
/*  70:    */   }
/*  71:    */   
/*  72:    */   public String getCId()
/*  73:    */   {
/*  74: 71 */     return this.cid;
/*  75:    */   }
/*  76:    */   
/*  77:    */   public void init() {}
/*  78:    */   
/*  79:    */   public void setOpaque(boolean opaque)
/*  80:    */   {
/*  81: 79 */     if (opaque) {
/*  82: 80 */       setBackgroundColor(Color.alpha(0));
/*  83:    */     }
/*  84:    */   }
/*  85:    */   
/*  86:    */   public void setBackgroundColor(int c)
/*  87:    */   {
/*  88: 85 */     NPanel p = (NPanel)findViewById(UIUtil.getResourceId(R.id.class, "southPanel"));
/*  89: 86 */     if (p != null) {
/*  90: 87 */       p.setBackgroundColor(c);
/*  91:    */     }
/*  92: 90 */     NScrollPan sv = (NScrollPan)findViewById(UIUtil.getResourceId(R.id.class, "scrollViewPanel"));
/*  93: 91 */     if (sv != null) {
/*  94: 92 */       sv.setBackgroundColor(c);
/*  95:    */     }
/*  96:    */   }
/*  97:    */   
/*  98:    */   public void setBackgroundImage(String img)
/*  99:    */   {
/* 100: 97 */     Drawable image = ImageUtil.findImageFromResources(img);
/* 101: 98 */     if (image != null) {
/* 102: 99 */       setBackgroundDrawable(image);
/* 103:    */     }
/* 104:    */   }
/* 105:    */   
/* 106:    */   public void addChildUIComponent(UIComponent child)
/* 107:    */   {
/* 108:104 */     this.children.addElement(child);
/* 109:    */   }
/* 110:    */   
/* 111:    */   public boolean canContainChildren()
/* 112:    */   {
/* 113:108 */     return true;
/* 114:    */   }
/* 115:    */   
/* 116:    */   public Enumeration getChildren()
/* 117:    */   {
/* 118:112 */     return this.children.elements();
/* 119:    */   }
/* 120:    */   
/* 121:    */   public AbstractMobileControl getController()
/* 122:    */   {
/* 123:116 */     return this.controller;
/* 124:    */   }
/* 125:    */   
/* 126:    */   public void setController(AbstractMobileControl controller)
/* 127:    */   {
/* 128:120 */     this.controller = controller;
/* 129:    */   }
/* 130:    */   
/* 131:123 */   private ViewGroup.LayoutParams constraints = null;
/* 132:    */   
/* 133:    */   public Object getConstraints()
/* 134:    */   {
/* 135:126 */     return this.constraints;
/* 136:    */   }
/* 137:    */   
/* 138:    */   public void setConstraints(Object consts)
/* 139:    */   {
/* 140:130 */     this.constraints = ((ViewGroup.LayoutParams)consts);
/* 141:131 */     setLayoutParams(this.constraints);
/* 142:132 */     requestLayout();
/* 143:    */   }
/* 144:    */   
/* 145:    */   public void addView(View v)
/* 146:    */   {
/* 147:136 */     ViewParent viewParent = v.getParent();
/* 148:137 */     if (viewParent == null)
/* 149:    */     {
/* 150:138 */       super.addView(v);
/* 151:139 */       if ((v instanceof UIComponent)) {
/* 152:140 */         addChildUIComponent((UIComponent)v);
/* 153:    */       }
/* 154:    */     }
/* 155:    */   }
/* 156:    */   
/* 157:    */   public void remove(UIComponent comp)
/* 158:    */   {
/* 159:146 */     this.children.remove(comp);
/* 160:    */   }
/* 161:    */   
/* 162:    */   public ControlStyle getStyle()
/* 163:    */   {
/* 164:150 */     return this.style;
/* 165:    */   }
/* 166:    */   
/* 167:    */   public void setStyle(ControlStyle style)
/* 168:    */   {
/* 169:154 */     this.style = style;
/* 170:    */   }
/* 171:    */   
/* 172:    */   public void setVisible(boolean show)
/* 173:    */   {
/* 174:158 */     setVisibility(show ? 0 : 8);
/* 175:    */   }
/* 176:    */   
/* 177:    */   public boolean isVisible()
/* 178:    */   {
/* 179:162 */     return getVisibility() == 0;
/* 180:    */   }
/* 181:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.components.NDrawer
 * JD-Core Version:    0.7.0.1
 */