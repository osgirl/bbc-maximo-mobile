/*   1:    */ package com.mro.mobile.ui.res.widgets.android.components.table;
/*   2:    */ 
/*   3:    */ import android.content.Context;
/*   4:    */ import android.util.Log;
/*   5:    */ import android.widget.TableRow;
/*   6:    */ import com.mro.mobile.MobileApplicationException;
/*   7:    */ import com.mro.mobile.ui.MobileMboDataBean;
/*   8:    */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*   9:    */ import com.mro.mobile.ui.res.widgets.android.components.NIDMapper;
/*  10:    */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  11:    */ import java.util.Enumeration;
/*  12:    */ 
/*  13:    */ public class NTableRow
/*  14:    */   extends TableRow
/*  15:    */   implements UIComponent
/*  16:    */ {
/*  17: 31 */   private String cid = null;
/*  18: 33 */   protected AbstractMobileControl controller = null;
/*  19:    */   
/*  20:    */   public NTable getNtableRef()
/*  21:    */   {
/*  22: 36 */     return this.ntableRef;
/*  23:    */   }
/*  24:    */   
/*  25: 39 */   protected NTable ntableRef = null;
/*  26:    */   
/*  27:    */   protected void setNtableRef(NTable ntableRef)
/*  28:    */   {
/*  29: 42 */     this.ntableRef = ntableRef;
/*  30:    */   }
/*  31:    */   
/*  32:    */   public int getRowNumber()
/*  33:    */   {
/*  34: 46 */     return this.rowNumber;
/*  35:    */   }
/*  36:    */   
/*  37:    */   public void setRowNumber(int rowNumber)
/*  38:    */   {
/*  39: 50 */     this.rowNumber = rowNumber;
/*  40:    */   }
/*  41:    */   
/*  42: 53 */   private int rowNumber = -1;
/*  43:    */   
/*  44:    */   public NTableRow(AbstractMobileControl controller, Context context, int rowNumber, NTable ntable)
/*  45:    */   {
/*  46: 56 */     super(context);
/*  47: 57 */     setController(controller);
/*  48: 58 */     if (controller != null) {
/*  49: 59 */       setId(NIDMapper.getAndroidIdFor(controller.getId()));
/*  50:    */     } else {
/*  51: 61 */       setId(NIDMapper.getNextId());
/*  52:    */     }
/*  53: 63 */     setRowNumber(rowNumber);
/*  54: 64 */     setNtableRef(ntable);
/*  55:    */   }
/*  56:    */   
/*  57:    */   public void setId(String id) {}
/*  58:    */   
/*  59:    */   public AbstractMobileControl getController()
/*  60:    */   {
/*  61: 74 */     return this.controller;
/*  62:    */   }
/*  63:    */   
/*  64:    */   public void setController(AbstractMobileControl controller)
/*  65:    */   {
/*  66: 82 */     this.controller = controller;
/*  67:    */   }
/*  68:    */   
/*  69:    */   public void remove(UIComponent comp) {}
/*  70:    */   
/*  71:    */   public void init() {}
/*  72:    */   
/*  73:    */   public void addChildUIComponent(UIComponent child) {}
/*  74:    */   
/*  75:    */   public boolean canContainChildren()
/*  76:    */   {
/*  77:103 */     return false;
/*  78:    */   }
/*  79:    */   
/*  80:    */   public Enumeration getChildren()
/*  81:    */   {
/*  82:108 */     return null;
/*  83:    */   }
/*  84:    */   
/*  85:    */   public Object getConstraints()
/*  86:    */   {
/*  87:113 */     return null;
/*  88:    */   }
/*  89:    */   
/*  90:    */   public void setConstraints(Object contstraints) {}
/*  91:    */   
/*  92:    */   public void publishRowInfoToTable()
/*  93:    */   {
/*  94:    */     try
/*  95:    */     {
/*  96:125 */       MobileMboDataBean dataBean = getController().getDataBean();
/*  97:126 */       if (dataBean != null) {
/*  98:127 */         dataBean.setCurrentPosition(getRowNumber() + getNtableRef().getCurModelBeanFirstRow());
/*  99:    */       }
/* 100:    */     }
/* 101:    */     catch (MobileApplicationException mae)
/* 102:    */     {
/* 103:131 */       Log.d(getClass().getName(), "No DataBean Found", mae);
/* 104:    */     }
/* 105:    */   }
/* 106:    */   
/* 107:    */   public String getCId()
/* 108:    */   {
/* 109:136 */     return this.cid;
/* 110:    */   }
/* 111:    */   
/* 112:    */   public void setCId(String cid)
/* 113:    */   {
/* 114:140 */     this.cid = cid;
/* 115:    */   }
/* 116:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.components.table.NTableRow
 * JD-Core Version:    0.7.0.1
 */