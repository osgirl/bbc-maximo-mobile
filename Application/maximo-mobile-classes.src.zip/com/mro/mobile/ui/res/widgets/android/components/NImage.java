/*   1:    */ package com.mro.mobile.ui.res.widgets.android.components;
/*   2:    */ 
/*   3:    */ import android.content.Context;
/*   4:    */ import android.graphics.drawable.Drawable;
/*   5:    */ import android.util.AttributeSet;
/*   6:    */ import android.view.View;
/*   7:    */ import android.widget.ImageView;
/*   8:    */ import android.widget.LinearLayout.LayoutParams;
/*   9:    */ import com.ibm.tivoli.maximo.mobile.android.util.ImageUtil;
/*  10:    */ import com.ibm.tivoli.maximo.mobile.android.util.UIUtil;
/*  11:    */ import com.ibm.tivoli.maximo.mobile.resources.R.layout;
/*  12:    */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*  13:    */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  14:    */ import java.util.Enumeration;
/*  15:    */ 
/*  16:    */ public class NImage
/*  17:    */   extends ImageView
/*  18:    */   implements UIComponent
/*  19:    */ {
/*  20: 33 */   private static final int DEFAULT_XML_LAYOUT = UIUtil.getResourceId(R.layout.class, "nimage");
/*  21: 35 */   private String cid = null;
/*  22: 37 */   private AbstractMobileControl controller = null;
/*  23: 39 */   private LinearLayout.LayoutParams constraints = null;
/*  24:    */   
/*  25:    */   public NImage(Context context)
/*  26:    */   {
/*  27: 42 */     super(context);
/*  28:    */   }
/*  29:    */   
/*  30:    */   public NImage(Context context, AttributeSet attrs)
/*  31:    */   {
/*  32: 46 */     super(context, attrs);
/*  33:    */   }
/*  34:    */   
/*  35:    */   public NImage(Context context, AttributeSet attrs, int defStyle)
/*  36:    */   {
/*  37: 50 */     super(context, attrs, defStyle);
/*  38:    */   }
/*  39:    */   
/*  40:    */   public static NImage createByInflate(AbstractMobileControl control, Context context, String imagePath)
/*  41:    */   {
/*  42: 54 */     return createByInflate(DEFAULT_XML_LAYOUT, control, context, imagePath);
/*  43:    */   }
/*  44:    */   
/*  45:    */   public static NImage createByInflate(int layoutId, AbstractMobileControl control, Context context, String imagePath)
/*  46:    */   {
/*  47: 58 */     NImage image = (NImage)View.inflate(context, layoutId, null);
/*  48: 59 */     image.postInstance(control, imagePath);
/*  49: 60 */     return image;
/*  50:    */   }
/*  51:    */   
/*  52:    */   private void postInstance(AbstractMobileControl control, String imagePath)
/*  53:    */   {
/*  54: 64 */     setController(control);
/*  55: 65 */     if (control != null) {
/*  56: 66 */       setId(NIDMapper.getAndroidIdFor(control.getId()));
/*  57:    */     } else {
/*  58: 68 */       setId(NIDMapper.getNextId());
/*  59:    */     }
/*  60: 70 */     Drawable image = ImageUtil.findImageFromResources(imagePath);
/*  61: 71 */     if (image != null) {
/*  62: 72 */       setImageDrawable(image);
/*  63:    */     }
/*  64:    */   }
/*  65:    */   
/*  66:    */   public String getCId()
/*  67:    */   {
/*  68: 77 */     return this.cid;
/*  69:    */   }
/*  70:    */   
/*  71:    */   public void init() {}
/*  72:    */   
/*  73:    */   public void addChildUIComponent(UIComponent child) {}
/*  74:    */   
/*  75:    */   public boolean canContainChildren()
/*  76:    */   {
/*  77: 87 */     return false;
/*  78:    */   }
/*  79:    */   
/*  80:    */   public Enumeration getChildren()
/*  81:    */   {
/*  82: 91 */     return null;
/*  83:    */   }
/*  84:    */   
/*  85:    */   public AbstractMobileControl getController()
/*  86:    */   {
/*  87: 95 */     return this.controller;
/*  88:    */   }
/*  89:    */   
/*  90:    */   public void setController(AbstractMobileControl controller)
/*  91:    */   {
/*  92: 99 */     this.controller = controller;
/*  93:    */   }
/*  94:    */   
/*  95:    */   public Object getConstraints()
/*  96:    */   {
/*  97:103 */     return this.constraints;
/*  98:    */   }
/*  99:    */   
/* 100:    */   public void setConstraints(Object conts)
/* 101:    */   {
/* 102:107 */     this.constraints = ((LinearLayout.LayoutParams)conts);
/* 103:108 */     setLayoutParams(this.constraints);
/* 104:109 */     requestLayout();
/* 105:    */   }
/* 106:    */   
/* 107:    */   public void setCId(String cid)
/* 108:    */   {
/* 109:113 */     this.cid = cid;
/* 110:    */   }
/* 111:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.components.NImage
 * JD-Core Version:    0.7.0.1
 */