/*   1:    */ package com.mro.mobile.ui.res.widgets.android.components;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.app.AbstractMobileDeviceApplication;
/*   4:    */ import com.mro.mobile.app.MobileDeviceAppSession;
/*   5:    */ import java.security.MessageDigest;
/*   6:    */ import java.security.NoSuchAlgorithmException;
/*   7:    */ import java.util.concurrent.ConcurrentHashMap;
/*   8:    */ 
/*   9:    */ public class NIDMapper
/*  10:    */ {
/*  11: 25 */   private ConcurrentHashMap<String, Integer> map = new ConcurrentHashMap();
/*  12:    */   private boolean automationMode;
/*  13:    */   private static NIDMapper instance;
/*  14: 31 */   private MessageDigest algorithm = null;
/*  15: 33 */   private static boolean inTestMode = false;
/*  16:    */   
/*  17:    */   public static boolean isInTestMode()
/*  18:    */   {
/*  19: 36 */     return inTestMode;
/*  20:    */   }
/*  21:    */   
/*  22:    */   public static void setInTestMode(boolean inTestMode)
/*  23:    */   {
/*  24: 40 */     inTestMode = inTestMode;
/*  25:    */   }
/*  26:    */   
/*  27: 48 */   private int last = 570425344;
/*  28:    */   
/*  29:    */   private NIDMapper()
/*  30:    */   {
/*  31: 51 */     this.automationMode = defineIfAutomationModeIsOn();
/*  32: 52 */     init();
/*  33:    */   }
/*  34:    */   
/*  35:    */   private boolean defineIfAutomationModeIsOn()
/*  36:    */   {
/*  37: 56 */     AbstractMobileDeviceApplication app = MobileDeviceAppSession.getSession().getApplication();
/*  38: 57 */     return app != null ? app.isAutomationModeOn() : inTestMode;
/*  39:    */   }
/*  40:    */   
/*  41:    */   private void init()
/*  42:    */   {
/*  43: 61 */     if (this.automationMode) {
/*  44:    */       try
/*  45:    */       {
/*  46: 63 */         this.algorithm = MessageDigest.getInstance("MD5");
/*  47:    */       }
/*  48:    */       catch (NoSuchAlgorithmException e)
/*  49:    */       {
/*  50: 65 */         throw new RuntimeException("Cannot start IDMapper in automation mode because MD5 is not supported in the current JVM.");
/*  51:    */       }
/*  52:    */     }
/*  53:    */   }
/*  54:    */   
/*  55:    */   public static synchronized int getAndroidIdFor(String mobileIdInXML)
/*  56:    */   {
/*  57: 72 */     Integer value = (Integer)instance().map.get(mobileIdInXML);
/*  58: 73 */     if (value == null)
/*  59:    */     {
/*  60: 74 */       if (instance().automationMode) {
/*  61: 75 */         value = Integer.valueOf(getAndroidIdInAutomationModeFor(mobileIdInXML));
/*  62:    */       } else {
/*  63: 77 */         value = Integer.valueOf(getNextId());
/*  64:    */       }
/*  65: 79 */       instance().map.put(mobileIdInXML, value);
/*  66:    */     }
/*  67: 81 */     return value.intValue();
/*  68:    */   }
/*  69:    */   
/*  70:    */   private static int getAndroidIdInAutomationModeFor(String mobileIdInXML)
/*  71:    */   {
/*  72: 85 */     instance().algorithm.reset();
/*  73: 86 */     instance().algorithm.update(mobileIdInXML.getBytes());
/*  74: 87 */     byte[] messageDigest = instance().algorithm.digest();
/*  75: 88 */     StringBuilder hexString = new StringBuilder();
/*  76: 89 */     for (byte b : messageDigest) {
/*  77: 90 */       hexString.append(Integer.toHexString(0xFF & b));
/*  78:    */     }
/*  79: 97 */     return Integer.parseInt(hexString.substring(0, 7).toString(), 16);
/*  80:    */   }
/*  81:    */   
/*  82:    */   public static synchronized int getNextId()
/*  83:    */   {
/*  84:101 */     return instance().last++;
/*  85:    */   }
/*  86:    */   
/*  87:    */   private static NIDMapper instance()
/*  88:    */   {
/*  89:105 */     if (instance == null) {
/*  90:106 */       instance = new NIDMapper();
/*  91:    */     }
/*  92:108 */     return instance;
/*  93:    */   }
/*  94:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.components.NIDMapper
 * JD-Core Version:    0.7.0.1
 */