package com.mro.mobile.ui.res.widgets.def;

public abstract interface TableColWidget
  extends AbstractWidget
{
  public abstract void createTableCol(String paramString);
  
  public abstract void setVisible(boolean paramBoolean);
  
  public abstract boolean isComponentVisible(UIComponent paramUIComponent);
  
  public abstract void addToCol(UIComponent paramUIComponent);
  
  public abstract UIComponent[] resolveTableColComponents();
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.def.TableColWidget
 * JD-Core Version:    0.7.0.1
 */