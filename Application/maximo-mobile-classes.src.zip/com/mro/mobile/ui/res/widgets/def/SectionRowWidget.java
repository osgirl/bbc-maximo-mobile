package com.mro.mobile.ui.res.widgets.def;

public abstract interface SectionRowWidget
  extends AbstractWidget
{
  public abstract void createSectionRow(String paramString);
  
  public abstract void initializeLayout(int paramInt);
  
  public abstract void setLayoutConstraints(int paramInt1, int paramInt2);
  
  public abstract void addComponent(UIComponent paramUIComponent);
  
  public abstract void addComponentWithDefaultLayoutConstraints(UIComponent paramUIComponent);
  
  public abstract UIComponent[] resolveSectionRowComponents();
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.def.SectionRowWidget
 * JD-Core Version:    0.7.0.1
 */