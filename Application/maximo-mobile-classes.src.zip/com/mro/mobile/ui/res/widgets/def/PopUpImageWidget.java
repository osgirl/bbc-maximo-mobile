package com.mro.mobile.ui.res.widgets.def;

import com.mro.mobile.MobileApplicationException;
import com.mro.mobile.ui.res.controls.AbstractMobileControl;
import com.mro.mobile.ui.res.controls.utils.ControlStyle;
import java.util.ArrayList;
import java.util.Vector;

public abstract interface PopUpImageWidget
  extends AbstractWidget
{
  public abstract ArrayList getVisibleContents(ArrayList paramArrayList);
  
  public abstract UIComponent[] createPopUp(String paramString1, String paramString2, AbstractMobileControl paramAbstractMobileControl);
  
  public abstract void setControlVisibility(UIComponent paramUIComponent, boolean paramBoolean);
  
  public abstract void cleanup(UIComponent paramUIComponent);
  
  public abstract boolean refreshPopUpControl()
    throws MobileApplicationException;
  
  public abstract String getStringValueFromComponentController(UIComponent paramUIComponent, String paramString);
  
  public abstract String getComponentEvent(UIComponent paramUIComponent);
  
  public abstract String getComponentCId(UIComponent paramUIComponent);
  
  public abstract String getComponentTargetId(UIComponent paramUIComponent);
  
  public abstract String getComponentLabel(UIComponent paramUIComponent);
  
  public abstract AbstractMobileControl getController(UIComponent paramUIComponent);
  
  public abstract boolean addSeperator(UIComponent paramUIComponent);
  
  public abstract void addComponentInfoToPopUpImage(UIComponent paramUIComponent1, UIComponent paramUIComponent2, ControlStyle paramControlStyle, int paramInt);
  
  public abstract Vector getControlNodeData(UIComponent paramUIComponent);
  
  public abstract void setControlNodeData(Vector paramVector, UIComponent paramUIComponent);
  
  public abstract void clearControlNodeData(UIComponent paramUIComponent);
  
  public abstract void removeAllItems();
  
  public abstract ArrayList getMenuContents(UIComponent paramUIComponent)
    throws MobileApplicationException;
  
  public abstract boolean isComponentAPanel(UIComponent paramUIComponent);
  
  public abstract boolean isPanelVisible(UIComponent paramUIComponent);
  
  public abstract void removeSelectionListenerFromPopup(UIComponent paramUIComponent);
  
  public abstract boolean isPopUpListenerSet();
  
  public abstract void removeListenerFromMainMenu(UIComponent paramUIComponent);
  
  public abstract void addNewListenerToMainMenu(UIComponent paramUIComponent);
  
  public abstract void fireClickEvent(int paramInt);
  
  public abstract String resolveMenuTitle(String paramString);
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.def.PopUpImageWidget
 * JD-Core Version:    0.7.0.1
 */