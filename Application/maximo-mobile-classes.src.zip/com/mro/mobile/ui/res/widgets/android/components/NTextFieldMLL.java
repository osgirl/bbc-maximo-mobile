/*  1:   */ package com.mro.mobile.ui.res.widgets.android.components;
/*  2:   */ 
/*  3:   */ import android.content.Context;
/*  4:   */ import android.text.method.KeyListener;
/*  5:   */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*  6:   */ 
/*  7:   */ public class NTextFieldMLL
/*  8:   */   extends NTextField
/*  9:   */ {
/* 10:   */   private KeyListener listener;
/* 11:   */   
/* 12:   */   public NTextFieldMLL(AbstractMobileControl control, Context context, String text, int maxCol, int size, int flags)
/* 13:   */   {
/* 14:27 */     super(control, context, text, maxCol, size, flags);
/* 15:   */   }
/* 16:   */   
/* 17:   */   protected boolean needValidationWithKeyStroke(int keyCode)
/* 18:   */   {
/* 19:32 */     return false;
/* 20:   */   }
/* 21:   */   
/* 22:   */   public void setEditable(boolean editable)
/* 23:   */   {
/* 24:37 */     super.setEditable(editable);
/* 25:39 */     if (editable)
/* 26:   */     {
/* 27:40 */       if (this.listener != null) {
/* 28:40 */         setKeyListener(this.listener);
/* 29:   */       }
/* 30:   */     }
/* 31:   */     else
/* 32:   */     {
/* 33:43 */       this.listener = getKeyListener();
/* 34:44 */       setKeyListener(null);
/* 35:   */     }
/* 36:   */   }
/* 37:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.components.NTextFieldMLL
 * JD-Core Version:    0.7.0.1
 */