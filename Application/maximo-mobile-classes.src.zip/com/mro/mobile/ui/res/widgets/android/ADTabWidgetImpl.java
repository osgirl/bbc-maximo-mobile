/*   1:    */ package com.mro.mobile.ui.res.widgets.android;
/*   2:    */ 
/*   3:    */ import android.view.View;
/*   4:    */ import android.widget.Button;
/*   5:    */ import android.widget.LinearLayout.LayoutParams;
/*   6:    */ import android.widget.SlidingDrawer.OnDrawerCloseListener;
/*   7:    */ import android.widget.SlidingDrawer.OnDrawerOpenListener;
/*   8:    */ import com.ibm.tivoli.maximo.mobile.android.util.UIUtil;
/*   9:    */ import com.ibm.tivoli.maximo.mobile.resources.R.id;
/*  10:    */ import com.mro.mobile.MobileApplicationException;
/*  11:    */ import com.mro.mobile.ui.event.UIEvent;
/*  12:    */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*  13:    */ import com.mro.mobile.ui.res.controls.TabControl;
/*  14:    */ import com.mro.mobile.ui.res.widgets.android.components.NDrawer;
/*  15:    */ import com.mro.mobile.ui.res.widgets.android.components.NPanel;
/*  16:    */ import com.mro.mobile.ui.res.widgets.android.components.NRelativePanel;
/*  17:    */ import com.mro.mobile.ui.res.widgets.android.components.NScrollPan;
/*  18:    */ import com.mro.mobile.ui.res.widgets.android.components.tree.NTree;
/*  19:    */ import com.mro.mobile.ui.res.widgets.def.TabWidget;
/*  20:    */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  21:    */ import java.util.ArrayList;
/*  22:    */ import java.util.Iterator;
/*  23:    */ 
/*  24:    */ public class ADTabWidgetImpl
/*  25:    */   extends ADAbstractWidgetImpl
/*  26:    */   implements TabWidget
/*  27:    */ {
/*  28: 45 */   private NRelativePanel panel = null;
/*  29: 46 */   private NPanel controlContainer = null;
/*  30: 48 */   private NDrawer buttonDrawer = null;
/*  31: 49 */   private Button slideButton = null;
/*  32: 50 */   private NScrollPan southPanel = null;
/*  33: 51 */   private NScrollPan centerScroll = null;
/*  34: 53 */   private View contentContainer = null;
/*  35:    */   
/*  36:    */   public void createTabPanel(String id)
/*  37:    */   {
/*  38: 56 */     this.panel = NRelativePanel.createByInflate(getTabControl(), AndroidEnv.getCurrentActivity(), -1);
/*  39: 57 */     this.panel.setCId("panel_" + id);
/*  40:    */     
/*  41:    */ 
/*  42: 60 */     this.controlContainer = NPanel.createByInflate(getTabControl(), AndroidEnv.getCurrentActivity(), 1);
/*  43: 61 */     this.controlContainer.setCId("controlContainer_" + id);
/*  44:    */   }
/*  45:    */   
/*  46:    */   public boolean isTabPanelVisible()
/*  47:    */   {
/*  48: 65 */     return this.panel.getVisibility() == 0;
/*  49:    */   }
/*  50:    */   
/*  51:    */   public void setPanelLayoutForCurrentTab()
/*  52:    */   {
/*  53: 69 */     LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -1);
/*  54: 70 */     params.setMargins(0, 0, 0, 0);
/*  55: 71 */     this.panel.setLayoutParams(params);
/*  56:    */     
/*  57: 73 */     LinearLayout.LayoutParams containerParams = new LinearLayout.LayoutParams(-1, -1);
/*  58: 74 */     containerParams.setMargins(0, 0, 0, 0);
/*  59: 75 */     this.controlContainer.setLayoutParams(containerParams);
/*  60:    */   }
/*  61:    */   
/*  62:    */   public void addComponentToCurrentTab(UIComponent component)
/*  63:    */   {
/*  64: 79 */     if ((component instanceof NTree))
/*  65:    */     {
/*  66: 80 */       this.controlContainer.addView((View)component);
/*  67: 81 */       return;
/*  68:    */     }
/*  69: 86 */     this.centerScroll = NScrollPan.createByInflate(getTabControl(), AndroidEnv.getCurrentActivity(), (View)component);
/*  70:    */     
/*  71: 88 */     LinearLayout.LayoutParams conts = new LinearLayout.LayoutParams(-1, -1);
/*  72: 89 */     conts.setMargins(0, 0, 0, 0);
/*  73: 90 */     conts.gravity = 48;
/*  74: 91 */     this.centerScroll.setConstraints(conts);
/*  75:    */     
/*  76: 93 */     this.controlContainer.addView(this.centerScroll);
/*  77:    */     
/*  78:    */ 
/*  79: 96 */     setContentContainer(this.controlContainer);
/*  80:    */   }
/*  81:    */   
/*  82:    */   public void addControlsToTabPanel(ArrayList controls)
/*  83:    */   {
/*  84:100 */     boolean centerSet = false;
/*  85:101 */     ArrayList drawerControls = null;
/*  86:    */     
/*  87:103 */     Iterator nItr = controls.iterator();
/*  88:104 */     if (nItr != null)
/*  89:    */     {
/*  90:106 */       NPanel container = createContainerPanel();
/*  91:107 */       container.setBackgroundColor(-1);
/*  92:109 */       while (nItr.hasNext())
/*  93:    */       {
/*  94:111 */         AbstractMobileControl control = (AbstractMobileControl)nItr.next();
/*  95:112 */         if (!centerSet)
/*  96:    */         {
/*  97:114 */           UIComponent[] components = control.getComponents();
/*  98:115 */           for (int x = 0; x < components.length; x++) {
/*  99:117 */             container.addView((View)components[x]);
/* 100:    */           }
/* 101:119 */           centerSet = true;
/* 102:    */         }
/* 103:    */         else
/* 104:    */         {
/* 105:121 */           if (drawerControls == null) {
/* 106:122 */             drawerControls = new ArrayList();
/* 107:    */           }
/* 108:123 */           drawerControls.add(control);
/* 109:    */         }
/* 110:    */       }
/* 111:127 */       this.panel.addView(container);
/* 112:    */       
/* 113:    */ 
/* 114:130 */       setContentContainer(container);
/* 115:132 */       if (drawerControls != null)
/* 116:    */       {
/* 117:134 */         addControlsToSouthPanel(drawerControls);
/* 118:    */         
/* 119:    */ 
/* 120:137 */         updateContentContainerSize();
/* 121:138 */         this.panel.addView(this.buttonDrawer);
/* 122:    */       }
/* 123:    */     }
/* 124:    */   }
/* 125:    */   
/* 126:    */   private NPanel createContainerPanel()
/* 127:    */   {
/* 128:144 */     NPanel container = NPanel.createByInflate(getTabControl(), AndroidEnv.getCurrentActivity(), 1);
/* 129:145 */     LinearLayout.LayoutParams containerConts = new LinearLayout.LayoutParams(-1, -1);
/* 130:146 */     containerConts.setMargins(0, 0, 0, 0);
/* 131:147 */     container.setConstraints(containerConts);
/* 132:    */     
/* 133:149 */     return container;
/* 134:    */   }
/* 135:    */   
/* 136:    */   public void addControlsToSouthPanel(ArrayList controls)
/* 137:    */   {
/* 138:154 */     Iterator<?> nItr = controls.iterator();
/* 139:155 */     if (nItr != null)
/* 140:    */     {
/* 141:157 */       createDrawerPanel();
/* 142:159 */       while (nItr.hasNext())
/* 143:    */       {
/* 144:161 */         AbstractMobileControl control = (AbstractMobileControl)nItr.next();
/* 145:162 */         UIComponent[] components = control.getComponents();
/* 146:163 */         for (int x = 0; x < components.length; x++) {
/* 147:165 */           this.southPanel.addView((View)components[x]);
/* 148:    */         }
/* 149:    */       }
/* 150:    */     }
/* 151:170 */     this.panel.addView(this.buttonDrawer);
/* 152:    */   }
/* 153:    */   
/* 154:    */   private void createDrawerPanel()
/* 155:    */   {
/* 156:176 */     this.buttonDrawer = NDrawer.createByInflate(getTabControl(), AndroidEnv.getCurrentActivity());
/* 157:    */     
/* 158:    */ 
/* 159:179 */     this.buttonDrawer.setId(this.controlContainer.getId());
/* 160:180 */     this.buttonDrawer.setBackgroundColor(-1);
/* 161:    */     
/* 162:182 */     this.slideButton = ((Button)this.buttonDrawer.findViewById(UIUtil.getResourceId(R.id.class, "slideButton")));
/* 163:    */     
/* 164:184 */     this.buttonDrawer.setOnDrawerOpenListener(new SlidingDrawer.OnDrawerOpenListener()
/* 165:    */     {
/* 166:    */       public void onDrawerOpened()
/* 167:    */       {
/* 168:187 */         ADTabWidgetImpl.this.getContentContainer().setVisibility(4);
/* 169:    */       }
/* 170:190 */     });
/* 171:191 */     this.buttonDrawer.setOnDrawerCloseListener(new SlidingDrawer.OnDrawerCloseListener()
/* 172:    */     {
/* 173:    */       public void onDrawerClosed()
/* 174:    */       {
/* 175:194 */         ADTabWidgetImpl.this.getContentContainer().setVisibility(0);
/* 176:    */       }
/* 177:198 */     });
/* 178:199 */     this.southPanel = ((NScrollPan)this.buttonDrawer.findViewById(UIUtil.getResourceId(R.id.class, "scrollViewPanel")));
/* 179:    */     
/* 180:    */ 
/* 181:202 */     updateContentContainerSize();
/* 182:    */   }
/* 183:    */   
/* 184:    */   private void updateContentContainerSize()
/* 185:    */   {
/* 186:206 */     this.slideButton.measure(0, 0);
/* 187:207 */     getContentContainer().setPadding(0, 0, 0, this.slideButton.getMeasuredHeight() + 5);
/* 188:    */   }
/* 189:    */   
/* 190:    */   public void addControlsToTab()
/* 191:    */   {
/* 192:212 */     this.panel.addView(this.controlContainer);
/* 193:    */   }
/* 194:    */   
/* 195:    */   private View getContentContainer()
/* 196:    */   {
/* 197:216 */     return this.contentContainer;
/* 198:    */   }
/* 199:    */   
/* 200:    */   private void setContentContainer(View c)
/* 201:    */   {
/* 202:220 */     this.contentContainer = c;
/* 203:    */   }
/* 204:    */   
/* 205:    */   public boolean performEvent(UIEvent event)
/* 206:    */     throws MobileApplicationException
/* 207:    */   {
/* 208:224 */     return false;
/* 209:    */   }
/* 210:    */   
/* 211:    */   public UIComponent[] resolveTabComponents()
/* 212:    */   {
/* 213:228 */     return new UIComponent[] { this.panel };
/* 214:    */   }
/* 215:    */   
/* 216:    */   protected TabControl getTabControl()
/* 217:    */   {
/* 218:232 */     return (TabControl)getController();
/* 219:    */   }
/* 220:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.ADTabWidgetImpl
 * JD-Core Version:    0.7.0.1
 */