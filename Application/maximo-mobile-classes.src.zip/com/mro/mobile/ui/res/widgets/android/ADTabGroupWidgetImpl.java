/*  1:   */ package com.mro.mobile.ui.res.widgets.android;
/*  2:   */ 
/*  3:   */ import com.mro.mobile.ui.res.controls.TabGroupControl;
/*  4:   */ import com.mro.mobile.ui.res.controls.utils.ControlStyle;
/*  5:   */ import com.mro.mobile.ui.res.widgets.android.components.NTabGroup;
/*  6:   */ import com.mro.mobile.ui.res.widgets.def.TabGroupWidget;
/*  7:   */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  8:   */ 
/*  9:   */ public class ADTabGroupWidgetImpl
/* 10:   */   extends ADAbstractWidgetImpl
/* 11:   */   implements TabGroupWidget
/* 12:   */ {
/* 13:24 */   private NTabGroup ntabgroup = null;
/* 14:26 */   private ControlStyle style = null;
/* 15:   */   
/* 16:   */   public TabGroupControl getTabGroupControl()
/* 17:   */   {
/* 18:29 */     return (TabGroupControl)super.getController();
/* 19:   */   }
/* 20:   */   
/* 21:   */   public void createTabGroup(ControlStyle style)
/* 22:   */   {
/* 23:33 */     this.style = style;
/* 24:34 */     this.ntabgroup = new NTabGroup(getTabGroupControl(), AndroidEnv.getCurrentActivity());
/* 25:   */   }
/* 26:   */   
/* 27:   */   public void applyLayoutConstraints() {}
/* 28:   */   
/* 29:   */   public int getSelectedTab()
/* 30:   */   {
/* 31:41 */     return this.ntabgroup == null ? -1 : this.ntabgroup.getSelectedIndex();
/* 32:   */   }
/* 33:   */   
/* 34:   */   public void removeAllTabs()
/* 35:   */   {
/* 36:45 */     this.ntabgroup.removeAllTabs();
/* 37:   */   }
/* 38:   */   
/* 39:   */   public void addImageTab(UIComponent component, String tabId, String attributeTabImage)
/* 40:   */   {
/* 41:49 */     this.ntabgroup.addImageTab(component, tabId, attributeTabImage);
/* 42:   */   }
/* 43:   */   
/* 44:   */   public void addTextTab(UIComponent component, String tabId, String label)
/* 45:   */   {
/* 46:53 */     this.ntabgroup.addTextTab(component, tabId, label);
/* 47:   */   }
/* 48:   */   
/* 49:   */   public int getTabCount()
/* 50:   */   {
/* 51:57 */     return this.ntabgroup.getTabCount();
/* 52:   */   }
/* 53:   */   
/* 54:   */   public void selectTab(int tabIndex)
/* 55:   */   {
/* 56:61 */     this.ntabgroup.selectTab(tabIndex);
/* 57:   */   }
/* 58:   */   
/* 59:   */   public UIComponent[] resolveTabGroupComponents()
/* 60:   */   {
/* 61:65 */     return new UIComponent[] { this.ntabgroup };
/* 62:   */   }
/* 63:   */   
/* 64:   */   public boolean needFullCleanUpDuringRefresh()
/* 65:   */   {
/* 66:70 */     return false;
/* 67:   */   }
/* 68:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.ADTabGroupWidgetImpl
 * JD-Core Version:    0.7.0.1
 */