/*  1:   */ package com.mro.mobile.ui.res.widgets.android.components;
/*  2:   */ 
/*  3:   */ import android.content.Context;
/*  4:   */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*  5:   */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  6:   */ 
/*  7:   */ public class NMenuItem
/*  8:   */   extends NMenu
/*  9:   */   implements UIComponent
/* 10:   */ {
/* 11:25 */   private String cid = null;
/* 12:27 */   private String image = "";
/* 13:28 */   private String label = "";
/* 14:29 */   private boolean seperator = false;
/* 15:30 */   private String event = "";
/* 16:   */   
/* 17:   */   public NMenuItem(AbstractMobileControl controller, Context context)
/* 18:   */   {
/* 19:33 */     super(controller, context);
/* 20:34 */     if (controller != null) {
/* 21:35 */       setId(NIDMapper.getAndroidIdFor(controller.getId()));
/* 22:   */     } else {
/* 23:37 */       setId(NIDMapper.getNextId());
/* 24:   */     }
/* 25:   */   }
/* 26:   */   
/* 27:   */   public String getImage()
/* 28:   */   {
/* 29:42 */     return this.image;
/* 30:   */   }
/* 31:   */   
/* 32:   */   public void setImage(String image)
/* 33:   */   {
/* 34:46 */     this.image = image;
/* 35:   */   }
/* 36:   */   
/* 37:   */   public String getLabel()
/* 38:   */   {
/* 39:50 */     return this.label;
/* 40:   */   }
/* 41:   */   
/* 42:   */   public void setLabel(String label)
/* 43:   */   {
/* 44:54 */     this.label = label;
/* 45:   */   }
/* 46:   */   
/* 47:   */   public boolean hasSeperator()
/* 48:   */   {
/* 49:58 */     return this.seperator;
/* 50:   */   }
/* 51:   */   
/* 52:   */   public void setAddSeperator(boolean seperator)
/* 53:   */   {
/* 54:62 */     this.seperator = seperator;
/* 55:   */   }
/* 56:   */   
/* 57:   */   public String getEvent()
/* 58:   */   {
/* 59:66 */     return this.event;
/* 60:   */   }
/* 61:   */   
/* 62:   */   public void setEvent(String event)
/* 63:   */   {
/* 64:70 */     this.event = event;
/* 65:   */   }
/* 66:   */   
/* 67:   */   public void handleMenuSelect()
/* 68:   */   {
/* 69:74 */     if (getController() != null) {
/* 70:75 */       getController().handleEvent(getEvent(), "".equals(getTargetId()) ? null : getTargetId(), getValue());
/* 71:   */     }
/* 72:   */   }
/* 73:   */   
/* 74:   */   public String getCId()
/* 75:   */   {
/* 76:80 */     return this.cid;
/* 77:   */   }
/* 78:   */   
/* 79:   */   public void setCId(String cid)
/* 80:   */   {
/* 81:84 */     this.cid = cid;
/* 82:   */   }
/* 83:   */   
/* 84:   */   public boolean isVisible()
/* 85:   */   {
/* 86:88 */     return getVisibility() == 0;
/* 87:   */   }
/* 88:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.components.NMenuItem
 * JD-Core Version:    0.7.0.1
 */