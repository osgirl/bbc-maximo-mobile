package com.mro.mobile.ui.res.widgets.android.components.tree;

public abstract interface TreeListener
{
  public abstract void itemInserted(Item paramItem);
  
  public abstract void itemRemoved(Item paramItem, int paramInt);
  
  public abstract void itemModified(Item paramItem);
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.components.tree.TreeListener
 * JD-Core Version:    0.7.0.1
 */