/*   1:    */ package com.mro.mobile.ui.res.widgets.android.components;
/*   2:    */ 
/*   3:    */ import android.content.Context;
/*   4:    */ import android.os.Bundle;
/*   5:    */ import android.view.LayoutInflater;
/*   6:    */ import android.view.View;
/*   7:    */ import android.widget.FrameLayout;
/*   8:    */ import android.widget.FrameLayout.LayoutParams;
/*   9:    */ import android.widget.HorizontalScrollView;
/*  10:    */ import android.widget.ImageView;
/*  11:    */ import android.widget.LinearLayout;
/*  12:    */ import android.widget.LinearLayout.LayoutParams;
/*  13:    */ import android.widget.TabHost;
/*  14:    */ import android.widget.TabHost.TabSpec;
/*  15:    */ import android.widget.TabWidget;
/*  16:    */ import android.widget.TextView;
/*  17:    */ import com.ibm.tivoli.maximo.mobile.android.util.UIUtil;
/*  18:    */ import com.ibm.tivoli.maximo.mobile.resources.R.id;
/*  19:    */ import com.ibm.tivoli.maximo.mobile.resources.R.layout;
/*  20:    */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*  21:    */ import com.mro.mobile.ui.res.controls.TabControl;
/*  22:    */ import com.mro.mobile.ui.res.controls.TabGroupControl;
/*  23:    */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  24:    */ import java.util.Enumeration;
/*  25:    */ import java.util.HashMap;
/*  26:    */ import java.util.Map;
/*  27:    */ 
/*  28:    */ public class NTabGroup
/*  29:    */   extends TabHost
/*  30:    */   implements UIComponent
/*  31:    */ {
/*  32: 43 */   private static final int DEFAULT_TABS_XML_LAYOUT = UIUtil.getResourceId(R.layout.class, "tabs_bg");
/*  33: 45 */   private String cid = null;
/*  34: 51 */   protected int tabCounts = 0;
/*  35: 53 */   protected AbstractMobileControl controller = null;
/*  36: 55 */   private NTabGroupManager mTabManager = null;
/*  37: 57 */   private Map<String, TabControl> tagtotab = new HashMap();
/*  38: 59 */   private volatile boolean addingTab = false;
/*  39:    */   
/*  40:    */   public NTabGroupManager getmTabManager()
/*  41:    */   {
/*  42: 62 */     return this.mTabManager;
/*  43:    */   }
/*  44:    */   
/*  45:    */   public NTabGroup(AbstractMobileControl control, Context context)
/*  46:    */   {
/*  47: 66 */     super(context, null);
/*  48: 67 */     setController(control);
/*  49: 68 */     if (control != null) {
/*  50: 69 */       setId(NIDMapper.getAndroidIdFor(control.getId()));
/*  51:    */     } else {
/*  52: 71 */       setId(NIDMapper.getNextId());
/*  53:    */     }
/*  54: 73 */     initView();
/*  55: 74 */     super.setup();
/*  56: 75 */     initTabManager();
/*  57:    */   }
/*  58:    */   
/*  59:    */   private void initView()
/*  60:    */   {
/*  61: 79 */     LinearLayout layout = new LinearLayout(getContext());
/*  62: 80 */     layout.setOrientation(1);
/*  63: 81 */     layout.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
/*  64: 82 */     super.addView(layout);
/*  65:    */     
/*  66: 84 */     TabWidget tabWidget = new TabWidget(getContext());
/*  67: 85 */     tabWidget.setOrientation(0);
/*  68: 86 */     tabWidget.setId(16908307);
/*  69: 87 */     tabWidget.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
/*  70:    */     
/*  71: 89 */     HorizontalScrollView hscroll = new HorizontalScrollView(getContext());
/*  72: 90 */     hscroll.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
/*  73: 91 */     hscroll.addView(tabWidget);
/*  74: 92 */     layout.addView(hscroll);
/*  75:    */     
/*  76: 94 */     FrameLayout frm1 = new FrameLayout(getContext());
/*  77: 95 */     frm1.setId(16908305);
/*  78: 96 */     frm1.setLayoutParams(new FrameLayout.LayoutParams(-1, -1));
/*  79: 97 */     layout.addView(frm1);
/*  80:    */   }
/*  81:    */   
/*  82:    */   public boolean isAddingTab()
/*  83:    */   {
/*  84:101 */     return this.addingTab;
/*  85:    */   }
/*  86:    */   
/*  87:    */   public void addTab(TabHost.TabSpec tabSpec)
/*  88:    */   {
/*  89:106 */     this.addingTab = true;
/*  90:107 */     super.addTab(tabSpec);
/*  91:108 */     View tabview = getTabWidget().getChildTabViewAt(this.tabCounts);
/*  92:109 */     alignTabIndicator(tabview);
/*  93:110 */     this.tabCounts += 1;
/*  94:111 */     this.addingTab = false;
/*  95:    */   }
/*  96:    */   
/*  97:    */   protected void alignTabIndicator(View tabView)
/*  98:    */   {
/*  99:115 */     View tabTitle = tabView.findViewById(16908310);
/* 100:116 */     if ((tabTitle instanceof TextView))
/* 101:    */     {
/* 102:117 */       TextView titleText = (TextView)tabTitle;
/* 103:118 */       titleText.setGravity(17);
/* 104:119 */       titleText.setSingleLine(false);
/* 105:120 */       titleText.getLayoutParams().height = -1;
/* 106:121 */       titleText.getLayoutParams().width = -2;
/* 107:    */     }
/* 108:    */   }
/* 109:    */   
/* 110:    */   public void recordMappingFromTagToTab(String tag, TabControl tab)
/* 111:    */   {
/* 112:126 */     this.tagtotab.put(tag, tab);
/* 113:    */   }
/* 114:    */   
/* 115:    */   public TabControl getTabFromTag(String tag)
/* 116:    */   {
/* 117:130 */     return (TabControl)this.tagtotab.get(tag);
/* 118:    */   }
/* 119:    */   
/* 120:    */   public void clearAllTabs()
/* 121:    */   {
/* 122:135 */     super.clearAllTabs();
/* 123:136 */     this.tabCounts = 0;
/* 124:137 */     this.tagtotab.clear();
/* 125:    */   }
/* 126:    */   
/* 127:    */   private void initTabManager()
/* 128:    */   {
/* 129:141 */     this.mTabManager = new NTabGroupManager(this);
/* 130:    */   }
/* 131:    */   
/* 132:    */   public void addTab(String tag, String indicator, View v)
/* 133:    */   {
/* 134:145 */     this.addingTab = true;
/* 135:146 */     View tabContents = LayoutInflater.from(getContext()).inflate(DEFAULT_TABS_XML_LAYOUT, null);
/* 136:147 */     TextView tv = (TextView)tabContents.findViewById(UIUtil.getResourceId(R.id.class, "tabsText"));
/* 137:148 */     tv.setVisibility(0);
/* 138:149 */     tv.setText(indicator);
/* 139:    */     
/* 140:151 */     this.mTabManager.addTab(newTabSpec(tag).setIndicator(tabContents), v, new Bundle());
/* 141:152 */     this.addingTab = false;
/* 142:    */   }
/* 143:    */   
/* 144:    */   public void addTab(String tag, NImage indicator, View v)
/* 145:    */   {
/* 146:156 */     this.addingTab = true;
/* 147:    */     
/* 148:158 */     View tabContents = LayoutInflater.from(getContext()).inflate(DEFAULT_TABS_XML_LAYOUT, null);
/* 149:159 */     ImageView image = (ImageView)tabContents.findViewById(UIUtil.getResourceId(R.id.class, "icon"));
/* 150:160 */     image.setVisibility(0);
/* 151:161 */     image.setBackgroundDrawable(indicator.getDrawable());
/* 152:    */     
/* 153:163 */     this.mTabManager.addTab(newTabSpec(tag).setIndicator(tabContents), v, new Bundle());
/* 154:164 */     this.addingTab = false;
/* 155:    */   }
/* 156:    */   
/* 157:    */   public void swicthToAnotherTab(Bundle b)
/* 158:    */   {
/* 159:168 */     this.mTabManager.swicthToAnotherTab(b);
/* 160:    */   }
/* 161:    */   
/* 162:    */   public void init() {}
/* 163:    */   
/* 164:    */   public void addChildUIComponent(UIComponent child) {}
/* 165:    */   
/* 166:    */   public boolean canContainChildren()
/* 167:    */   {
/* 168:181 */     return false;
/* 169:    */   }
/* 170:    */   
/* 171:    */   public Enumeration getChildren()
/* 172:    */   {
/* 173:186 */     return null;
/* 174:    */   }
/* 175:    */   
/* 176:    */   public AbstractMobileControl getController()
/* 177:    */   {
/* 178:191 */     return this.controller;
/* 179:    */   }
/* 180:    */   
/* 181:    */   public TabGroupControl getTabGroupController()
/* 182:    */   {
/* 183:195 */     return (TabGroupControl)getController();
/* 184:    */   }
/* 185:    */   
/* 186:    */   public void setController(AbstractMobileControl controller)
/* 187:    */   {
/* 188:200 */     this.controller = controller;
/* 189:    */   }
/* 190:    */   
/* 191:203 */   private FrameLayout.LayoutParams constraints = null;
/* 192:    */   
/* 193:    */   public Object getConstraints()
/* 194:    */   {
/* 195:207 */     return this.constraints;
/* 196:    */   }
/* 197:    */   
/* 198:    */   public void setConstraints(Object consts)
/* 199:    */   {
/* 200:212 */     this.constraints = ((FrameLayout.LayoutParams)consts);
/* 201:213 */     setLayoutParams(this.constraints);
/* 202:214 */     requestLayout();
/* 203:    */   }
/* 204:    */   
/* 205:    */   public int getSelectedIndex()
/* 206:    */   {
/* 207:218 */     return getCurrentTab();
/* 208:    */   }
/* 209:    */   
/* 210:    */   public void removeAllTabs()
/* 211:    */   {
/* 212:222 */     this.mTabManager.removeAllTabs();
/* 213:    */   }
/* 214:    */   
/* 215:    */   public void addImageTab(UIComponent component, String tabId, String attributeTabImage)
/* 216:    */   {
/* 217:226 */     NImage image = NImage.createByInflate(null, getContext(), attributeTabImage);
/* 218:227 */     addTab(tabId, image, (View)component);
/* 219:    */   }
/* 220:    */   
/* 221:    */   public void addTextTab(UIComponent component, String tabId, String label)
/* 222:    */   {
/* 223:231 */     addTab(tabId, label, (View)component);
/* 224:    */   }
/* 225:    */   
/* 226:    */   public int getTabCount()
/* 227:    */   {
/* 228:235 */     return this.mTabManager.getTabCount();
/* 229:    */   }
/* 230:    */   
/* 231:    */   public void selectTab(String tag)
/* 232:    */   {
/* 233:239 */     this.mTabManager.swicthToAnotherTab(tag);
/* 234:    */   }
/* 235:    */   
/* 236:    */   public void selectTab(int tabIndex)
/* 237:    */   {
/* 238:243 */     this.mTabManager.swicthToAnotherTab(tabIndex);
/* 239:    */   }
/* 240:    */   
/* 241:    */   public String getCId()
/* 242:    */   {
/* 243:247 */     return this.cid;
/* 244:    */   }
/* 245:    */   
/* 246:    */   public void setCId(String cid)
/* 247:    */   {
/* 248:251 */     this.cid = cid;
/* 249:    */   }
/* 250:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.components.NTabGroup
 * JD-Core Version:    0.7.0.1
 */