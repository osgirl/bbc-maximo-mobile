/*   1:    */ package com.mro.mobile.ui.res.widgets.android.components.table;
/*   2:    */ 
/*   3:    */ import android.content.Context;
/*   4:    */ import android.util.AttributeSet;
/*   5:    */ import android.view.View;
/*   6:    */ import android.widget.HorizontalScrollView;
/*   7:    */ import android.widget.TableLayout;
/*   8:    */ import android.widget.TableRow;
/*   9:    */ import com.ibm.tivoli.maximo.mobile.android.util.UIUtil;
/*  10:    */ import com.ibm.tivoli.maximo.mobile.resources.R.id;
/*  11:    */ import com.ibm.tivoli.maximo.mobile.resources.R.layout;
/*  12:    */ import com.mro.mobile.MobileApplicationException;
/*  13:    */ import com.mro.mobile.ui.MobileMboDataBean;
/*  14:    */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*  15:    */ import com.mro.mobile.ui.res.widgets.android.components.NIDMapper;
/*  16:    */ import com.mro.mobile.ui.res.widgets.android.components.NScrollPan;
/*  17:    */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  18:    */ import java.util.ArrayList;
/*  19:    */ import java.util.Enumeration;
/*  20:    */ import java.util.HashMap;
/*  21:    */ import java.util.List;
/*  22:    */ import java.util.Map;
/*  23:    */ import java.util.Vector;
/*  24:    */ 
/*  25:    */ public class NTable
/*  26:    */   extends HorizontalScrollView
/*  27:    */   implements UIComponent
/*  28:    */ {
/*  29: 47 */   private static final int DEFAULT_XML_LAYOUT = UIUtil.getResourceId(R.layout.class, "nscrollabletablefixheader");
/*  30: 48 */   protected AbstractMobileControl controller = null;
/*  31: 49 */   private String cid = null;
/*  32: 50 */   private String event = null;
/*  33: 51 */   private String value = null;
/*  34: 52 */   private String dataBeanName = null;
/*  35: 53 */   private String mobileMboName = null;
/*  36: 54 */   private String parentDataBeanName = null;
/*  37: 55 */   private Vector attributeNames = new Vector();
/*  38: 56 */   private int curModelBeanFirstRow = 0;
/*  39: 57 */   private int curColumn = 0;
/*  40: 58 */   private boolean trackColSizing = false;
/*  41:    */   private TableRow header;
/*  42: 60 */   private ArrayList<TableRow> rows = new ArrayList();
/*  43:    */   public static final String STYLEKEY = "table";
/*  44: 63 */   private Map<Integer, Integer> columnSizes = new HashMap();
/*  45:    */   
/*  46:    */   public NTable(Context context, AttributeSet attrs, int defStyle)
/*  47:    */   {
/*  48: 66 */     super(context, attrs, defStyle);
/*  49:    */   }
/*  50:    */   
/*  51:    */   public NTable(Context context, AttributeSet attrs)
/*  52:    */   {
/*  53: 70 */     super(context, attrs);
/*  54:    */   }
/*  55:    */   
/*  56:    */   public NTable(Context context)
/*  57:    */   {
/*  58: 74 */     super(context);
/*  59:    */   }
/*  60:    */   
/*  61:    */   public static NTable createByInflate(AbstractMobileControl control, Context context)
/*  62:    */   {
/*  63: 78 */     return createByInflate(DEFAULT_XML_LAYOUT, control, context);
/*  64:    */   }
/*  65:    */   
/*  66:    */   public static NTable createByInflate(int layoutId, AbstractMobileControl control, Context context)
/*  67:    */   {
/*  68: 82 */     NTable table = (NTable)View.inflate(context, layoutId, null);
/*  69: 83 */     table.postInstance(control);
/*  70: 84 */     return table;
/*  71:    */   }
/*  72:    */   
/*  73:    */   protected void postInstance(AbstractMobileControl control)
/*  74:    */   {
/*  75: 88 */     setController(control);
/*  76: 89 */     if (control != null) {
/*  77: 90 */       setId(NIDMapper.getAndroidIdFor(control.getId()));
/*  78:    */     } else {
/*  79: 92 */       setId(NIDMapper.getNextId());
/*  80:    */     }
/*  81: 94 */     setClickable(true);
/*  82: 95 */     setFocusable(true);
/*  83: 96 */     setFocusableInTouchMode(true);
/*  84:    */   }
/*  85:    */   
/*  86:    */   public TableRow getHeader()
/*  87:    */   {
/*  88:100 */     return this.header;
/*  89:    */   }
/*  90:    */   
/*  91:    */   public List<TableRow> getBody()
/*  92:    */   {
/*  93:104 */     return this.rows;
/*  94:    */   }
/*  95:    */   
/*  96:    */   protected TableLayout getHeaderHolder()
/*  97:    */   {
/*  98:108 */     return (TableLayout)findViewById(UIUtil.getResourceId(R.id.class, "tableHeaderLayout"));
/*  99:    */   }
/* 100:    */   
/* 101:    */   protected NTableBody getBodyHolder()
/* 102:    */   {
/* 103:112 */     return (NTableBody)findViewById(UIUtil.getResourceId(R.id.class, "tableBody"));
/* 104:    */   }
/* 105:    */   
/* 106:    */   private void updateHeader(TableRow header)
/* 107:    */   {
/* 108:116 */     if (header == null) {
/* 109:117 */       return;
/* 110:    */     }
/* 111:119 */     if (getHeader() != null) {
/* 112:120 */       cleanExistingHeader(true);
/* 113:    */     }
/* 114:122 */     this.header = header;
/* 115:123 */     getHeaderHolder().addView(this.header, 0);
/* 116:    */   }
/* 117:    */   
/* 118:    */   private void updateRows(ArrayList<TableRow> rows)
/* 119:    */   {
/* 120:127 */     cleanExistingRows();
/* 121:128 */     if ((rows != null) && (rows.size() > 0))
/* 122:    */     {
/* 123:129 */       this.rows = rows;
/* 124:130 */       for (int i = 0; i < this.rows.size(); i++) {
/* 125:131 */         updateOneRow((TableRow)this.rows.get(i), i);
/* 126:    */       }
/* 127:    */     }
/* 128:    */   }
/* 129:    */   
/* 130:    */   private void cleanExistingHeader(boolean alsoRemoveHeaderView)
/* 131:    */   {
/* 132:138 */     if (this.header != null)
/* 133:    */     {
/* 134:139 */       this.header.removeAllViews();
/* 135:140 */       if (alsoRemoveHeaderView) {
/* 136:141 */         getHeaderHolder().removeView(this.header);
/* 137:    */       }
/* 138:143 */       invalidate();
/* 139:    */     }
/* 140:    */   }
/* 141:    */   
/* 142:    */   private void cleanExistingRows()
/* 143:    */   {
/* 144:148 */     if (this.rows != null)
/* 145:    */     {
/* 146:149 */       for (TableRow row : this.rows) {
/* 147:150 */         getBodyHolder().removeView(row);
/* 148:    */       }
/* 149:152 */       invalidate();
/* 150:    */     }
/* 151:    */   }
/* 152:    */   
/* 153:    */   public void init() {}
/* 154:    */   
/* 155:    */   public void addChildUIComponent(UIComponent child) {}
/* 156:    */   
/* 157:    */   public boolean canContainChildren()
/* 158:    */   {
/* 159:166 */     return false;
/* 160:    */   }
/* 161:    */   
/* 162:    */   public Enumeration getChildren()
/* 163:    */   {
/* 164:171 */     return null;
/* 165:    */   }
/* 166:    */   
/* 167:    */   public AbstractMobileControl getController()
/* 168:    */   {
/* 169:176 */     return this.controller;
/* 170:    */   }
/* 171:    */   
/* 172:    */   public void setController(AbstractMobileControl controller)
/* 173:    */   {
/* 174:181 */     this.controller = controller;
/* 175:182 */     getBodyHolder().setController(controller);
/* 176:    */   }
/* 177:    */   
/* 178:    */   public Object getConstraints()
/* 179:    */   {
/* 180:188 */     return null;
/* 181:    */   }
/* 182:    */   
/* 183:    */   public void setConstraints(Object contstraints) {}
/* 184:    */   
/* 185:    */   public void setDataBeanName(String dataBeanName)
/* 186:    */   {
/* 187:196 */     this.dataBeanName = dataBeanName;
/* 188:    */   }
/* 189:    */   
/* 190:    */   public String getMobileMboName()
/* 191:    */   {
/* 192:200 */     return this.mobileMboName;
/* 193:    */   }
/* 194:    */   
/* 195:    */   public void setMobileMboName(String dataBeanTypeName)
/* 196:    */   {
/* 197:204 */     this.mobileMboName = dataBeanTypeName;
/* 198:    */   }
/* 199:    */   
/* 200:    */   public String getParentDataBeanName()
/* 201:    */   {
/* 202:208 */     return this.parentDataBeanName;
/* 203:    */   }
/* 204:    */   
/* 205:    */   public void setParentDataBeanName(String name)
/* 206:    */   {
/* 207:212 */     this.parentDataBeanName = name;
/* 208:    */   }
/* 209:    */   
/* 210:    */   public String getDataBeanName()
/* 211:    */   {
/* 212:216 */     return this.dataBeanName;
/* 213:    */   }
/* 214:    */   
/* 215:    */   public String getValue()
/* 216:    */   {
/* 217:220 */     return this.value;
/* 218:    */   }
/* 219:    */   
/* 220:    */   public void setValue(String value)
/* 221:    */   {
/* 222:224 */     this.value = value;
/* 223:    */   }
/* 224:    */   
/* 225:    */   public boolean canBindIndependently()
/* 226:    */   {
/* 227:228 */     return true;
/* 228:    */   }
/* 229:    */   
/* 230:    */   public void addAttributeName(String attributeName)
/* 231:    */   {
/* 232:232 */     this.attributeNames.addElement(attributeName);
/* 233:    */   }
/* 234:    */   
/* 235:    */   public String getAttributeName(int index)
/* 236:    */   {
/* 237:236 */     return (String)this.attributeNames.elementAt(index);
/* 238:    */   }
/* 239:    */   
/* 240:    */   public MobileMboDataBean getDataBean()
/* 241:    */     throws MobileApplicationException
/* 242:    */   {
/* 243:240 */     return getController().getDataBean();
/* 244:    */   }
/* 245:    */   
/* 246:    */   public void refresh(Object uiEvent)
/* 247:    */     throws MobileApplicationException
/* 248:    */   {
/* 249:244 */     getDataBean();
/* 250:    */   }
/* 251:    */   
/* 252:    */   public void setHeader()
/* 253:    */   {
/* 254:248 */     updateHeader(new TableRow(getContext()));
/* 255:    */   }
/* 256:    */   
/* 257:    */   public void setEvent(String event)
/* 258:    */   {
/* 259:252 */     this.event = event;
/* 260:    */   }
/* 261:    */   
/* 262:    */   public boolean isTrackColSizing()
/* 263:    */   {
/* 264:259 */     return this.trackColSizing;
/* 265:    */   }
/* 266:    */   
/* 267:    */   public void setTrackColSizing(boolean trackColSizing)
/* 268:    */   {
/* 269:267 */     this.trackColSizing = trackColSizing;
/* 270:    */   }
/* 271:    */   
/* 272:    */   public int getCurModelBeanFirstRow()
/* 273:    */   {
/* 274:274 */     return this.curModelBeanFirstRow;
/* 275:    */   }
/* 276:    */   
/* 277:    */   public void setCurModelBeanFirstRow(int curModelBeanFirstRow)
/* 278:    */   {
/* 279:282 */     this.curModelBeanFirstRow = curModelBeanFirstRow;
/* 280:    */   }
/* 281:    */   
/* 282:    */   public void setCaption(int column, View title)
/* 283:    */   {
/* 284:286 */     getHeader().addView(title, column);
/* 285:    */   }
/* 286:    */   
/* 287:    */   public void updateCaption(int column, View title)
/* 288:    */   {
/* 289:290 */     getHeader().removeViewAt(column);
/* 290:291 */     setCaption(column, title);
/* 291:    */   }
/* 292:    */   
/* 293:    */   public void populateModel(NMatrixModel inMatrix)
/* 294:    */   {
/* 295:295 */     ArrayList<TableRow> allrows = new ArrayList();
/* 296:296 */     for (int i = 0; i < inMatrix.getRows(); i++)
/* 297:    */     {
/* 298:297 */       NTableRow lineRow = new NTableRow(getController(), getContext(), i, this);
/* 299:298 */       for (int j = 0; j < inMatrix.getCols(); j++) {
/* 300:299 */         addOneCellToTableRow(lineRow, (View)inMatrix.get(i, j));
/* 301:    */       }
/* 302:301 */       allrows.add(lineRow);
/* 303:    */     }
/* 304:303 */     updateRows(allrows);
/* 305:    */   }
/* 306:    */   
/* 307:    */   private void updateOneRow(TableRow lineRow, int rowNum)
/* 308:    */   {
/* 309:307 */     getBodyHolder().addView(lineRow, rowNum);
/* 310:    */   }
/* 311:    */   
/* 312:    */   private void addOneCellToTableRow(TableRow lineRow, View cell)
/* 313:    */   {
/* 314:311 */     if ((cell instanceof UIComponent))
/* 315:    */     {
/* 316:312 */       NTableCell tableCell = NTableCell.createByInflate(((UIComponent)cell).getController(), cell.getContext(), 0);
/* 317:313 */       tableCell.addView(cell);
/* 318:314 */       lineRow.addView(tableCell);
/* 319:    */     }
/* 320:    */     else
/* 321:    */     {
/* 322:316 */       lineRow.addView(cell);
/* 323:    */     }
/* 324:    */   }
/* 325:    */   
/* 326:    */   public int getCurColumn()
/* 327:    */   {
/* 328:324 */     return this.curColumn;
/* 329:    */   }
/* 330:    */   
/* 331:    */   public void setCurColumn(int curColumn)
/* 332:    */   {
/* 333:332 */     this.curColumn = curColumn;
/* 334:    */   }
/* 335:    */   
/* 336:    */   public void setTableColWidth(int columnIndex, int width)
/* 337:    */   {
/* 338:336 */     this.columnSizes.put(Integer.valueOf(columnIndex), Integer.valueOf(width));
/* 339:    */   }
/* 340:    */   
/* 341:    */   public void setTableRowHeight(int rowIndex, int height) {}
/* 342:    */   
/* 343:    */   public int getTableColumnWidth(int columnIndex)
/* 344:    */   {
/* 345:344 */     if ((this.columnSizes != null) && (this.columnSizes.containsKey(Integer.valueOf(columnIndex)))) {
/* 346:345 */       return ((Integer)this.columnSizes.get(Integer.valueOf(columnIndex))).intValue();
/* 347:    */     }
/* 348:347 */     return -1;
/* 349:    */   }
/* 350:    */   
/* 351:    */   public String getEvent()
/* 352:    */   {
/* 353:351 */     return this.event;
/* 354:    */   }
/* 355:    */   
/* 356:    */   public void cleanHeaderCaptions(boolean recalculate)
/* 357:    */   {
/* 358:355 */     cleanExistingHeader(false);
/* 359:356 */     if (recalculate) {
/* 360:357 */       this.columnSizes = new HashMap();
/* 361:    */     }
/* 362:    */   }
/* 363:    */   
/* 364:    */   public void setCId(String cid)
/* 365:    */   {
/* 366:363 */     this.cid = cid;
/* 367:    */   }
/* 368:    */   
/* 369:    */   public String getCId()
/* 370:    */   {
/* 371:368 */     return this.cid;
/* 372:    */   }
/* 373:    */   
/* 374:    */   protected void onAttachedToWindow()
/* 375:    */   {
/* 376:373 */     super.onAttachedToWindow();
/* 377:    */     
/* 378:    */ 
/* 379:    */ 
/* 380:    */ 
/* 381:378 */     disableParentPageScroll();
/* 382:    */   }
/* 383:    */   
/* 384:    */   private void disableParentPageScroll()
/* 385:    */   {
/* 386:382 */     NScrollPan pageScrollView = UIUtil.findHolderScrollPan(this);
/* 387:383 */     if (pageScrollView != null) {
/* 388:384 */       UIUtil.moveChildrenToParent(pageScrollView);
/* 389:    */     }
/* 390:    */   }
/* 391:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.components.table.NTable
 * JD-Core Version:    0.7.0.1
 */