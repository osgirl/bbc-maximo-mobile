/*   1:    */ package com.mro.mobile.ui.res.widgets.android;
/*   2:    */ 
/*   3:    */ import android.os.Build.VERSION;
/*   4:    */ import android.view.View;
/*   5:    */ import android.widget.DatePicker;
/*   6:    */ import android.widget.DatePicker.OnDateChangedListener;
/*   7:    */ import android.widget.LinearLayout.LayoutParams;
/*   8:    */ import android.widget.TextView;
/*   9:    */ import android.widget.TimePicker;
/*  10:    */ import com.ibm.tivoli.maximo.mobile.resources.R.id;
/*  11:    */ import com.ibm.tivoli.maximo.mobile.resources.R.layout;
/*  12:    */ import com.mro.mobile.MobileApplicationException;
/*  13:    */ import com.mro.mobile.app.AbstractMobileDeviceApplication;
/*  14:    */ import com.mro.mobile.app.CurrentTimeProvider;
/*  15:    */ import com.mro.mobile.app.DefaultMobileMboDataFormatter;
/*  16:    */ import com.mro.mobile.app.MobileDeviceAppSession;
/*  17:    */ import com.mro.mobile.mbo.MobileMbo;
/*  18:    */ import com.mro.mobile.mbo.MobileMboAttributeInfo;
/*  19:    */ import com.mro.mobile.mbo.MobileMboInfo;
/*  20:    */ import com.mro.mobile.mbo.MobileMboQBE;
/*  21:    */ import com.mro.mobile.ui.MobileMboDataBean;
/*  22:    */ import com.mro.mobile.ui.event.UIEvent;
/*  23:    */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*  24:    */ import com.mro.mobile.ui.res.controls.InputControl;
/*  25:    */ import com.mro.mobile.ui.res.controls.PageControl;
/*  26:    */ import com.mro.mobile.ui.res.controls.TextboxControl;
/*  27:    */ import com.mro.mobile.ui.res.widgets.android.components.NPanel;
/*  28:    */ import com.mro.mobile.ui.res.widgets.def.CalendarWidget;
/*  29:    */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  30:    */ import java.lang.reflect.Method;
/*  31:    */ import java.util.Calendar;
/*  32:    */ import java.util.Date;
/*  33:    */ 
/*  34:    */ public class ADCalendarWidgetImpl
/*  35:    */   extends ADAbstractWidgetImpl
/*  36:    */   implements CalendarWidget, DatePicker.OnDateChangedListener
/*  37:    */ {
/*  38: 37 */   private static final int DEFAULT_XML_LAYOUT = com.ibm.tivoli.maximo.mobile.android.util.UIUtil.getResourceId(R.layout.class, "ndatetime");
/*  39: 38 */   private boolean isTimeEnabled = true;
/*  40: 40 */   private AbstractMobileControl retInput = null;
/*  41: 41 */   private Calendar curCalendar = null;
/*  42: 42 */   private NPanel calendarHolder = null;
/*  43: 43 */   private DatePicker dp = null;
/*  44: 44 */   private TimePicker tp = null;
/*  45: 45 */   private TextView dateToString = null;
/*  46:    */   
/*  47:    */   public void createCalendar(int startOfWeek)
/*  48:    */     throws MobileApplicationException
/*  49:    */   {
/*  50: 49 */     this.calendarHolder = NPanel.createByInflate(getController(), AndroidEnv.getCurrentActivity(), 0);
/*  51: 50 */     this.calendarHolder.setCId("panel_calendar");
/*  52: 51 */     this.calendarHolder.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
/*  53: 52 */     View v = View.inflate(AndroidEnv.getCurrentActivity(), DEFAULT_XML_LAYOUT, null);
/*  54:    */     
/*  55:    */ 
/*  56: 55 */     this.dateToString = ((TextView)v.findViewById(com.ibm.tivoli.maximo.mobile.android.util.UIUtil.getResourceId(R.id.class, "dateToString")));
/*  57:    */     
/*  58: 57 */     this.dp = ((DatePicker)v.findViewById(com.ibm.tivoli.maximo.mobile.android.util.UIUtil.getResourceId(R.id.class, "datePicker")));
/*  59:    */     
/*  60:    */ 
/*  61:    */ 
/*  62: 61 */     this.dp.init(1978, 1, 19, this);
/*  63: 64 */     if (Build.VERSION.SDK_INT >= 11) {
/*  64:    */       try
/*  65:    */       {
/*  66: 66 */         Method m = this.dp.getClass().getMethod("setCalendarViewShown", new Class[] { Boolean.TYPE });
/*  67: 67 */         m.invoke(this.dp, new Object[] { Boolean.valueOf(false) });
/*  68:    */       }
/*  69:    */       catch (Exception e) {}
/*  70:    */     }
/*  71: 72 */     this.tp = ((TimePicker)v.findViewById(com.ibm.tivoli.maximo.mobile.android.util.UIUtil.getResourceId(R.id.class, "timePicker")));
/*  72: 73 */     if (this.tp != null) {
/*  73: 74 */       this.tp.setIs24HourView(Boolean.valueOf(isAmPmMarkerVisible()));
/*  74:    */     }
/*  75: 77 */     this.calendarHolder.addView(v);
/*  76:    */     
/*  77: 79 */     refreshCalendar();
/*  78:    */   }
/*  79:    */   
/*  80:    */   public boolean performEvent(UIEvent event)
/*  81:    */     throws MobileApplicationException
/*  82:    */   {
/*  83: 84 */     String eventType = event.getEventName();
/*  84: 86 */     if (eventType.equals("setdatevalue"))
/*  85:    */     {
/*  86: 94 */       setDateTimeFromPickers();
/*  87: 95 */       AbstractMobileControl tempCtrl = ((PageControl)com.mro.mobile.ui.res.UIUtil.getCurrentScreen()).getLaunchingControl();
/*  88: 96 */       if ((tempCtrl instanceof TextboxControl))
/*  89:    */       {
/*  90: 97 */         Date date = getCurrentSetDate();
/*  91: 98 */         if (!tempCtrl.validateControl(event, date))
/*  92:    */         {
/*  93: 99 */           event.setEventErrored();
/*  94:100 */           return true;
/*  95:    */         }
/*  96:102 */         String setAttr = tempCtrl.getStringValue("dataattribute");
/*  97:103 */         if (setAttr != null) {
/*  98:105 */           if (((InputControl)tempCtrl).isQuery())
/*  99:    */           {
/* 100:106 */             tempCtrl.getDataBean().getQBE().setQBE(setAttr, DefaultMobileMboDataFormatter.dateTimeToString(date));
/* 101:    */           }
/* 102:    */           else
/* 103:    */           {
/* 104:109 */             MobileMbo mbo = tempCtrl.getDataBean().getMobileMbo();
/* 105:110 */             if (mbo.isReadOnly()) {
/* 106:111 */               throw new MobileApplicationException("readonly", new Object[] { mbo.getDescription() });
/* 107:    */             }
/* 108:114 */             if (mbo.isReadOnly(setAttr)) {
/* 109:115 */               throw new MobileApplicationException("readonlyattr", new Object[] { mbo.getAttributeDescription(setAttr), mbo.getDescription() });
/* 110:    */             }
/* 111:118 */             mbo.setDateValue(setAttr, date);
/* 112:    */           }
/* 113:    */         }
/* 114:    */       }
/* 115:122 */       com.mro.mobile.ui.res.UIUtil.closePage();
/* 116:    */     }
/* 117:124 */     return false;
/* 118:    */   }
/* 119:    */   
/* 120:    */   private AbstractMobileControl getLaunchingControl()
/* 121:    */   {
/* 122:128 */     return this.retInput;
/* 123:    */   }
/* 124:    */   
/* 125:    */   private void setLaunchingControl()
/* 126:    */     throws MobileApplicationException
/* 127:    */   {
/* 128:132 */     this.retInput = ((PageControl)com.mro.mobile.ui.res.UIUtil.getCurrentScreen()).getLaunchingControl();
/* 129:    */   }
/* 130:    */   
/* 131:    */   public void refreshCalendar()
/* 132:    */     throws MobileApplicationException
/* 133:    */   {
/* 134:137 */     setLaunchingControl();
/* 135:138 */     String dataAttribute = getLaunchingControl().getStringValue("dataattribute");
/* 136:139 */     MobileMbo mobMbo = getLaunchingControl().getDataBean().getMobileMbo();
/* 137:    */     
/* 138:141 */     Date curDate = null;
/* 139:142 */     if (mobMbo != null)
/* 140:    */     {
/* 141:143 */       AbstractMobileControl tempCtrl = getLaunchingControl();
/* 142:144 */       if ((tempCtrl instanceof TextboxControl))
/* 143:    */       {
/* 144:145 */         if (!((TextboxControl)tempCtrl).getControlValue().trim().equals("")) {
/* 145:148 */           curDate = DefaultMobileMboDataFormatter.stringToDateTime(((TextboxControl)tempCtrl).getControlValue());
/* 146:    */         }
/* 147:    */       }
/* 148:    */       else {
/* 149:151 */         curDate = mobMbo.getDateValue(dataAttribute);
/* 150:    */       }
/* 151:    */     }
/* 152:155 */     Calendar cal = Calendar.getInstance();
/* 153:156 */     if (curDate == null) {
/* 154:157 */       cal.setTime(CurrentTimeProvider.getInstance().getCurrentTime());
/* 155:    */     } else {
/* 156:159 */       cal.setTime(curDate);
/* 157:    */     }
/* 158:161 */     this.dp.updateDate(cal.get(1), cal.get(2), cal.get(5));
/* 159:    */     
/* 160:    */ 
/* 161:164 */     int launchControlDataType = getLaunchingControl().getDataBean().getMobileMboInfo().getAttributeInfo(dataAttribute).getDataType();
/* 162:165 */     if (launchControlDataType == 11)
/* 163:    */     {
/* 164:166 */       if (!this.isTimeEnabled) {
/* 165:167 */         this.tp.setVisibility(0);
/* 166:    */       }
/* 167:169 */       this.isTimeEnabled = true;
/* 168:    */     }
/* 169:    */     else
/* 170:    */     {
/* 171:171 */       if (this.isTimeEnabled) {
/* 172:172 */         this.tp.setVisibility(4);
/* 173:    */       }
/* 174:174 */       this.isTimeEnabled = false;
/* 175:    */     }
/* 176:177 */     if (this.isTimeEnabled)
/* 177:    */     {
/* 178:178 */       this.tp.setCurrentHour(Integer.valueOf(cal.get(11)));
/* 179:179 */       this.tp.setCurrentMinute(Integer.valueOf(cal.get(12)));
/* 180:    */     }
/* 181:183 */     setCurCalendar(cal);
/* 182:    */   }
/* 183:    */   
/* 184:    */   private void setDateTimeFromPickers()
/* 185:    */   {
/* 186:188 */     Calendar cal = Calendar.getInstance();
/* 187:189 */     cal.set(this.dp.getYear(), this.dp.getMonth(), this.dp.getDayOfMonth());
/* 188:    */     
/* 189:191 */     cal.set(11, this.tp.getCurrentHour().intValue());
/* 190:192 */     cal.set(12, this.tp.getCurrentMinute().intValue());
/* 191:193 */     setCurCalendar(cal);
/* 192:    */   }
/* 193:    */   
/* 194:    */   private Calendar getCurCalendar()
/* 195:    */   {
/* 196:197 */     this.curCalendar.set(13, 0);
/* 197:198 */     this.curCalendar.set(14, 0);
/* 198:199 */     return this.curCalendar;
/* 199:    */   }
/* 200:    */   
/* 201:    */   private Date getCurrentSetDate()
/* 202:    */     throws MobileApplicationException
/* 203:    */   {
/* 204:203 */     return getCurCalendar().getTime();
/* 205:    */   }
/* 206:    */   
/* 207:    */   private void setCurCalendar(Calendar inCal)
/* 208:    */   {
/* 209:207 */     this.curCalendar = inCal;
/* 210:    */   }
/* 211:    */   
/* 212:    */   public boolean isAmPmMarkerVisible()
/* 213:    */   {
/* 214:211 */     MobileDeviceAppSession deviceAppSession = MobileDeviceAppSession.getSession();
/* 215:212 */     AbstractMobileDeviceApplication app = null;
/* 216:    */     
/* 217:214 */     app = deviceAppSession.getApplication();
/* 218:215 */     String language = app.getPackageLanguage();
/* 219:216 */     if ((language != null) && (language.equalsIgnoreCase("da"))) {
/* 220:217 */       return true;
/* 221:    */     }
/* 222:219 */     return false;
/* 223:    */   }
/* 224:    */   
/* 225:    */   public UIComponent[] resolveCalendarComponents()
/* 226:    */   {
/* 227:224 */     return new UIComponent[] { this.calendarHolder };
/* 228:    */   }
/* 229:    */   
/* 230:    */   public void onDateChanged(DatePicker view, int year, int monthOfYear, int dayOfMonth)
/* 231:    */   {
/* 232:229 */     Calendar c = Calendar.getInstance();
/* 233:230 */     c.set(year, monthOfYear, dayOfMonth);
/* 234:    */     try
/* 235:    */     {
/* 236:234 */       this.dateToString.setText(DefaultMobileMboDataFormatter.dateToStringFull(c.getTime()));
/* 237:    */     }
/* 238:    */     catch (MobileApplicationException e)
/* 239:    */     {
/* 240:236 */       this.dateToString.setText("");
/* 241:    */     }
/* 242:    */   }
/* 243:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.ADCalendarWidgetImpl
 * JD-Core Version:    0.7.0.1
 */