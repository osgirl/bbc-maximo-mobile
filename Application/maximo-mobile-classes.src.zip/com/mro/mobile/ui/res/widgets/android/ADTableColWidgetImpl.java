/*  1:   */ package com.mro.mobile.ui.res.widgets.android;
/*  2:   */ 
/*  3:   */ import android.view.View;
/*  4:   */ import android.widget.LinearLayout.LayoutParams;
/*  5:   */ import com.mro.mobile.ui.res.widgets.android.components.NPanel;
/*  6:   */ import com.mro.mobile.ui.res.widgets.def.TableColWidget;
/*  7:   */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  8:   */ 
/*  9:   */ public class ADTableColWidgetImpl
/* 10:   */   extends ADAbstractWidgetImpl
/* 11:   */   implements TableColWidget
/* 12:   */ {
/* 13:28 */   private NPanel npanel = null;
/* 14:   */   
/* 15:   */   public void createTableCol(String id)
/* 16:   */   {
/* 17:32 */     this.npanel = NPanel.createByInflate(getController(), AndroidEnv.getCurrentActivity(), 0);
/* 18:33 */     this.npanel.setLayoutParams(new LinearLayout.LayoutParams(-2, -2));
/* 19:34 */     this.npanel.setCId(id);
/* 20:35 */     this.npanel.setPadding(0, 0, 0, 0);
/* 21:36 */     this.npanel.setBackgroundColor(0);
/* 22:37 */     this.npanel.setGravity(16);
/* 23:   */   }
/* 24:   */   
/* 25:   */   public void setVisible(boolean visibility)
/* 26:   */   {
/* 27:42 */     this.npanel.setVisible(visibility);
/* 28:   */   }
/* 29:   */   
/* 30:   */   public boolean isComponentVisible(UIComponent c)
/* 31:   */   {
/* 32:47 */     return (!(c instanceof View)) || (((View)c).getVisibility() == 0);
/* 33:   */   }
/* 34:   */   
/* 35:   */   public void addToCol(UIComponent c)
/* 36:   */   {
/* 37:52 */     this.npanel.addView((View)c);
/* 38:   */   }
/* 39:   */   
/* 40:   */   public UIComponent[] resolveTableColComponents()
/* 41:   */   {
/* 42:57 */     return new UIComponent[] { this.npanel };
/* 43:   */   }
/* 44:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.ADTableColWidgetImpl
 * JD-Core Version:    0.7.0.1
 */