/*   1:    */ package com.mro.mobile.ui.res.widgets.android;
/*   2:    */ 
/*   3:    */ import android.text.TextUtils.TruncateAt;
/*   4:    */ import android.view.View;
/*   5:    */ import android.view.View.OnClickListener;
/*   6:    */ import com.mro.mobile.MobileApplicationException;
/*   7:    */ import com.mro.mobile.mbo.MobileMboAttributeInfo;
/*   8:    */ import com.mro.mobile.mbo.MobileMboInfo;
/*   9:    */ import com.mro.mobile.ui.MobileMboDataBean;
/*  10:    */ import com.mro.mobile.ui.res.ControlData;
/*  11:    */ import com.mro.mobile.ui.res.MobileUIProperties;
/*  12:    */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*  13:    */ import com.mro.mobile.ui.res.controls.TableControl;
/*  14:    */ import com.mro.mobile.ui.res.controls.utils.ControlStyle;
/*  15:    */ import com.mro.mobile.ui.res.widgets.android.components.NCheckBox;
/*  16:    */ import com.mro.mobile.ui.res.widgets.android.components.NImage;
/*  17:    */ import com.mro.mobile.ui.res.widgets.android.components.NLabel;
/*  18:    */ import com.mro.mobile.ui.res.widgets.android.components.NPanel;
/*  19:    */ import com.mro.mobile.ui.res.widgets.android.components.NToolBar;
/*  20:    */ import com.mro.mobile.ui.res.widgets.android.components.table.NMatrix;
/*  21:    */ import com.mro.mobile.ui.res.widgets.android.components.table.NTable;
/*  22:    */ import com.mro.mobile.ui.res.widgets.android.components.table.NTableCellEmsResolver;
/*  23:    */ import com.mro.mobile.ui.res.widgets.android.components.table.NTableCellHeader;
/*  24:    */ import com.mro.mobile.ui.res.widgets.android.components.table.NTableListenerManager;
/*  25:    */ import com.mro.mobile.ui.res.widgets.def.TableWidget;
/*  26:    */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  27:    */ 
/*  28:    */ public class ADTableWidgetImpl
/*  29:    */   extends ADAbstractWidgetImpl
/*  30:    */   implements TableWidget
/*  31:    */ {
/*  32: 41 */   private NMatrix inMatrix = null;
/*  33: 43 */   private NTable nTable = null;
/*  34: 45 */   private NImage sortImage = null;
/*  35:    */   
/*  36:    */   public void createTable(String id, int displayRows)
/*  37:    */     throws MobileApplicationException
/*  38:    */   {
/*  39: 49 */     this.nTable = NTable.createByInflate(getTableControl(), AndroidEnv.getCurrentActivity());
/*  40: 50 */     setupTableModelAndPopulateIntoTable(displayRows);
/*  41: 51 */     this.nTable.setController(getTableControl());
/*  42: 52 */     this.nTable.setDataBeanName(getTableControl().getDataBean().getName());
/*  43: 53 */     this.nTable.setHeader();
/*  44:    */   }
/*  45:    */   
/*  46:    */   public void setEvent(String event)
/*  47:    */   {
/*  48: 58 */     this.nTable.setEvent(event);
/*  49:    */   }
/*  50:    */   
/*  51:    */   public void setValue(String value)
/*  52:    */   {
/*  53: 63 */     this.nTable.setValue(value);
/*  54:    */   }
/*  55:    */   
/*  56:    */   public void setDataBeanName(String dataBeanName)
/*  57:    */   {
/*  58: 68 */     this.nTable.setDataBeanName(dataBeanName);
/*  59:    */   }
/*  60:    */   
/*  61:    */   public void setMobileMboName(String mobileMboName)
/*  62:    */   {
/*  63: 73 */     this.nTable.setMobileMboName(mobileMboName);
/*  64:    */   }
/*  65:    */   
/*  66:    */   public void setCurrrentModelBeanFirstRow(int firstRow)
/*  67:    */   {
/*  68: 78 */     this.nTable.setCurModelBeanFirstRow(firstRow);
/*  69:    */   }
/*  70:    */   
/*  71:    */   public void setTableCaption(int column, Object title)
/*  72:    */   {
/*  73: 83 */     if ((title instanceof View)) {
/*  74: 84 */       this.nTable.setCaption(column, (View)title);
/*  75: 86 */     } else if ((title instanceof String)) {
/*  76: 87 */       setTableCaption(column, (String)title, false, false);
/*  77:    */     }
/*  78:    */   }
/*  79:    */   
/*  80:    */   public void setTableCaption(int column, String title, boolean useSortImage, boolean isUnderline)
/*  81:    */   {
/*  82: 93 */     setTableCaption(column, newTableCaption(column, title, useSortImage, isUnderline));
/*  83:    */   }
/*  84:    */   
/*  85:    */   protected View newTableCaption(int column, String title, boolean useSortImage, boolean isUnderline)
/*  86:    */   {
/*  87: 97 */     NTableCellHeader header = NTableCellHeader.createByInflate(getController(), AndroidEnv.getCurrentActivity(), column, title, useSortImage ? this.sortImage : null, isUnderline);
/*  88:    */     
/*  89:    */ 
/*  90:    */ 
/*  91:101 */     header.setEmsResolver(new NTableCellEmsResolver(this.nTable, column));
/*  92:    */     
/*  93:103 */     return header;
/*  94:    */   }
/*  95:    */   
/*  96:    */   public void setTableColWidth(int column, int width)
/*  97:    */   {
/*  98:108 */     this.nTable.setTableColWidth(column, width);
/*  99:    */   }
/* 100:    */   
/* 101:    */   public void setTableRowHeight(int row, int height)
/* 102:    */   {
/* 103:113 */     this.nTable.setTableRowHeight(row, height);
/* 104:    */   }
/* 105:    */   
/* 106:    */   public int getTablePaddingLeft()
/* 107:    */   {
/* 108:118 */     return 0;
/* 109:    */   }
/* 110:    */   
/* 111:    */   public int getTablePaddingRight()
/* 112:    */   {
/* 113:123 */     return 0;
/* 114:    */   }
/* 115:    */   
/* 116:    */   public int getTextWidth()
/* 117:    */   {
/* 118:128 */     return 1;
/* 119:    */   }
/* 120:    */   
/* 121:    */   public void setTrackColSizing(boolean trackColSizing)
/* 122:    */   {
/* 123:133 */     this.nTable.setTrackColSizing(trackColSizing);
/* 124:    */   }
/* 125:    */   
/* 126:    */   public int getCurrentColumn()
/* 127:    */   {
/* 128:138 */     return this.nTable.getCurColumn();
/* 129:    */   }
/* 130:    */   
/* 131:    */   public int getTableColumnWidth(int column)
/* 132:    */   {
/* 133:143 */     return this.nTable.getTableColumnWidth(column);
/* 134:    */   }
/* 135:    */   
/* 136:    */   public boolean performHorizontalMove(int direction)
/* 137:    */   {
/* 138:148 */     return false;
/* 139:    */   }
/* 140:    */   
/* 141:    */   public boolean performVerticalMove(int direction)
/* 142:    */   {
/* 143:153 */     return false;
/* 144:    */   }
/* 145:    */   
/* 146:    */   public boolean isToolbarComponent(UIComponent component)
/* 147:    */   {
/* 148:158 */     return component instanceof NToolBar;
/* 149:    */   }
/* 150:    */   
/* 151:    */   public boolean isPanelComponent(UIComponent component)
/* 152:    */   {
/* 153:163 */     return component instanceof NPanel;
/* 154:    */   }
/* 155:    */   
/* 156:    */   public void setStyleIntoPanel(UIComponent component, ControlStyle style)
/* 157:    */   {
/* 158:168 */     ((NPanel)component).setStyle(style);
/* 159:    */   }
/* 160:    */   
/* 161:    */   public void setSortImage(int state)
/* 162:    */   {
/* 163:173 */     switch (state)
/* 164:    */     {
/* 165:    */     case 0: 
/* 166:175 */       this.sortImage = NImage.createByInflate(null, AndroidEnv.getCurrentActivity(), MobileUIProperties.getStringValue("table.sortasc"));
/* 167:176 */       break;
/* 168:    */     case 1: 
/* 169:178 */       this.sortImage = NImage.createByInflate(null, AndroidEnv.getCurrentActivity(), MobileUIProperties.getStringValue("table.sortdesc"));
/* 170:179 */       break;
/* 171:    */     case 2: 
/* 172:    */     default: 
/* 173:182 */       this.sortImage = null;
/* 174:    */     }
/* 175:    */   }
/* 176:    */   
/* 177:    */   public boolean isComponentNotVisible(UIComponent c)
/* 178:    */   {
/* 179:189 */     return ((c instanceof View)) && (((View)c).getVisibility() != 0);
/* 180:    */   }
/* 181:    */   
/* 182:    */   public void setupTableModelAndPopulateIntoTable(int displayRows)
/* 183:    */     throws MobileApplicationException
/* 184:    */   {
/* 185:194 */     getTableControl().setupTableModel(displayRows);
/* 186:195 */     this.nTable.populateModel(this.inMatrix);
/* 187:    */   }
/* 188:    */   
/* 189:    */   private TableControl getTableControl()
/* 190:    */   {
/* 191:199 */     return (TableControl)super.getController();
/* 192:    */   }
/* 193:    */   
/* 194:    */   public void createTableModel(int rows, int cols)
/* 195:    */   {
/* 196:204 */     this.inMatrix = new NMatrix(rows, cols);
/* 197:    */   }
/* 198:    */   
/* 199:    */   public void removeNotNeededTableModelRows()
/* 200:    */   {
/* 201:209 */     this.inMatrix.setRows(this.inMatrix.getRows() - 1);
/* 202:    */   }
/* 203:    */   
/* 204:    */   public void putComponentToTableModel(int row, int column, UIComponent component)
/* 205:    */   {
/* 206:214 */     View v = (View)component;
/* 207:215 */     v.setPadding(0, 0, 0, 0);
/* 208:216 */     this.inMatrix.put(row, column, component);
/* 209:    */   }
/* 210:    */   
/* 211:    */   public void putLabelToTableModel(int row, int column, final String text, ControlStyle rowStyle)
/* 212:    */   {
/* 213:221 */     String textToDisplay = text;
/* 214:    */     
/* 215:223 */     NLabel curTextLabel = NLabel.createByInflate(getTableControl(), AndroidEnv.getCurrentActivity(), textToDisplay, rowStyle);
/* 216:    */     
/* 217:    */ 
/* 218:226 */     curTextLabel.setEmsResolver(new NTableCellEmsResolver(this.nTable, column));
/* 219:227 */     curTextLabel.setSingleLine(true);
/* 220:228 */     curTextLabel.setEllipsize(TextUtils.TruncateAt.END);
/* 221:    */     
/* 222:230 */     curTextLabel.setClickable(true);
/* 223:231 */     curTextLabel.setOnClickListener(new View.OnClickListener()
/* 224:    */     {
/* 225:    */       public void onClick(View v)
/* 226:    */       {
/* 227:233 */         ADTableWidgetImpl.this.getController().handleEvent("showInfo", null, text);
/* 228:    */       }
/* 229:236 */     });
/* 230:237 */     this.inMatrix.put(row, column, curTextLabel);
/* 231:    */   }
/* 232:    */   
/* 233:    */   public void putCheckboxToTableModel(int row, int column, boolean selected, String event)
/* 234:    */   {
/* 235:242 */     NCheckBox nSelectCKBox = NCheckBox.createByInflate(getTableControl(), AndroidEnv.getCurrentActivity(), "", selected);
/* 236:243 */     nSelectCKBox.setState(selected);
/* 237:244 */     nSelectCKBox.setEvent(event);
/* 238:245 */     if (NTableListenerManager.instance().isWidgetControlInTable(getController())) {
/* 239:246 */       nSelectCKBox.setTableClickable(NTableListenerManager.instance().getTableClickable());
/* 240:    */     }
/* 241:248 */     this.inMatrix.put(row, column, nSelectCKBox);
/* 242:    */   }
/* 243:    */   
/* 244:    */   public UIComponent[] resolveTableComponents()
/* 245:    */   {
/* 246:253 */     return new UIComponent[] { this.nTable };
/* 247:    */   }
/* 248:    */   
/* 249:    */   public Object getModel()
/* 250:    */   {
/* 251:258 */     return this.inMatrix;
/* 252:    */   }
/* 253:    */   
/* 254:    */   public void cleanHeaders(boolean recalculate)
/* 255:    */   {
/* 256:263 */     this.nTable.cleanHeaderCaptions(recalculate);
/* 257:    */   }
/* 258:    */   
/* 259:    */   public void updateTableCaption(int column, String title, boolean useSortImage, boolean isUnderline)
/* 260:    */   {
/* 261:268 */     this.nTable.updateCaption(column, newTableCaption(column, title, useSortImage, isUnderline));
/* 262:    */   }
/* 263:    */   
/* 264:    */   public int calculateColWidthForControlData(ControlData childData, int curColWidth, String colLabel, String dataAttr, int highrange, int highwidth, int lhighrange, int lhighwidth, int midrange, int midwidth, int lmidrange, int lmidwidth, int basewidth)
/* 265:    */     throws MobileApplicationException
/* 266:    */   {
/* 267:274 */     if (dataAttr == null)
/* 268:    */     {
/* 269:275 */       if ((colLabel == null) || (colLabel.trim().length() == 0)) {
/* 270:276 */         curColWidth = basewidth / 2;
/* 271:    */       }
/* 272:    */     }
/* 273:    */     else
/* 274:    */     {
/* 275:280 */       MobileMboAttributeInfo info = getTableControl().getDataBean().getMobileMboInfo().getAttributeInfo(dataAttr);
/* 276:281 */       int dataLen = info != null ? info.getLength() : curColWidth;
/* 277:282 */       if (info.getDataType() == 8)
/* 278:    */       {
/* 279:283 */         if ((colLabel == null) || (colLabel.trim().length() == 0))
/* 280:    */         {
/* 281:284 */           curColWidth = basewidth;
/* 282:    */         }
/* 283:    */         else
/* 284:    */         {
/* 285:286 */           int size = colLabel.length();
/* 286:287 */           if (size > highrange) {
/* 287:288 */             curColWidth = highwidth;
/* 288:289 */           } else if (size > lhighrange) {
/* 289:290 */             curColWidth = lhighwidth;
/* 290:291 */           } else if (size > midrange) {
/* 291:292 */             curColWidth = midwidth;
/* 292:293 */           } else if (size > lmidrange) {
/* 293:294 */             curColWidth = lmidwidth;
/* 294:    */           } else {
/* 295:296 */             curColWidth = basewidth;
/* 296:    */           }
/* 297:    */         }
/* 298:    */       }
/* 299:300 */       else if (info.getDataType() == 11) {
/* 300:301 */         curColWidth = midwidth;
/* 301:303 */       } else if (getTableControl().getTextWidth(dataLen) > curColWidth) {
/* 302:304 */         if (dataLen > highrange) {
/* 303:305 */           curColWidth = highwidth;
/* 304:306 */         } else if (dataLen > lhighrange) {
/* 305:307 */           curColWidth = lhighwidth;
/* 306:308 */         } else if (dataLen > midrange) {
/* 307:309 */           curColWidth = midwidth;
/* 308:310 */         } else if (dataLen > lmidrange) {
/* 309:311 */           curColWidth = lmidwidth;
/* 310:    */         } else {
/* 311:313 */           curColWidth = basewidth;
/* 312:    */         }
/* 313:    */       }
/* 314:    */     }
/* 315:318 */     return curColWidth;
/* 316:    */   }
/* 317:    */   
/* 318:    */   public int calculateLastColumnWidth(int curColWidth, int screenSize, int tableWidth)
/* 319:    */   {
/* 320:322 */     return curColWidth;
/* 321:    */   }
/* 322:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.ADTableWidgetImpl
 * JD-Core Version:    0.7.0.1
 */