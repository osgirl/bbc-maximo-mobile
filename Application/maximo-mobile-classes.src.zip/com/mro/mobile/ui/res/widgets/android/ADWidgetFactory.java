/*   1:    */ package com.mro.mobile.ui.res.widgets.android;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.ui.res.widgets.def.AbstractWidget;
/*   4:    */ import com.mro.mobile.ui.res.widgets.def.WidgetCreator;
/*   5:    */ 
/*   6:    */ public class ADWidgetFactory
/*   7:    */ {
/*   8:    */   public static WidgetCreator initStubWidgetCreator()
/*   9:    */   {
/*  10: 23 */     new WidgetCreator()
/*  11:    */     {
/*  12:    */       public AbstractWidget createWidget()
/*  13:    */       {
/*  14: 25 */         return new ADStubWidgetImpl();
/*  15:    */       }
/*  16:    */     };
/*  17:    */   }
/*  18:    */   
/*  19:    */   public static WidgetCreator initTextboxWidgetCreator()
/*  20:    */   {
/*  21: 31 */     new WidgetCreator()
/*  22:    */     {
/*  23:    */       public AbstractWidget createWidget()
/*  24:    */       {
/*  25: 33 */         return new ADTextboxWidgetImpl();
/*  26:    */       }
/*  27:    */     };
/*  28:    */   }
/*  29:    */   
/*  30:    */   public static WidgetCreator initMultiLineTextboxWidgetCreator()
/*  31:    */   {
/*  32: 39 */     new WidgetCreator()
/*  33:    */     {
/*  34:    */       public AbstractWidget createWidget()
/*  35:    */       {
/*  36: 41 */         return new ADMultiLineTextboxWidgetImpl();
/*  37:    */       }
/*  38:    */     };
/*  39:    */   }
/*  40:    */   
/*  41:    */   public static WidgetCreator initLongDescriptionWidgetCreator()
/*  42:    */   {
/*  43: 47 */     new WidgetCreator()
/*  44:    */     {
/*  45:    */       public AbstractWidget createWidget()
/*  46:    */       {
/*  47: 49 */         return new ADLongDescriptionWidgetImpl();
/*  48:    */       }
/*  49:    */     };
/*  50:    */   }
/*  51:    */   
/*  52:    */   public static WidgetCreator initLabelWidgetCreator()
/*  53:    */   {
/*  54: 55 */     new WidgetCreator()
/*  55:    */     {
/*  56:    */       public AbstractWidget createWidget()
/*  57:    */       {
/*  58: 57 */         return new ADLabelWidgetImpl();
/*  59:    */       }
/*  60:    */     };
/*  61:    */   }
/*  62:    */   
/*  63:    */   public static WidgetCreator initLinkWidgetCreator()
/*  64:    */   {
/*  65: 63 */     new WidgetCreator()
/*  66:    */     {
/*  67:    */       public AbstractWidget createWidget()
/*  68:    */       {
/*  69: 65 */         return new ADLinkWidgetImpl();
/*  70:    */       }
/*  71:    */     };
/*  72:    */   }
/*  73:    */   
/*  74:    */   public static WidgetCreator initCheckboxWidgetCreator()
/*  75:    */   {
/*  76: 71 */     new WidgetCreator()
/*  77:    */     {
/*  78:    */       public AbstractWidget createWidget()
/*  79:    */       {
/*  80: 73 */         return new ADCheckboxWidgetImpl();
/*  81:    */       }
/*  82:    */     };
/*  83:    */   }
/*  84:    */   
/*  85:    */   public static WidgetCreator initSectionWidgetCreator()
/*  86:    */   {
/*  87: 79 */     new WidgetCreator()
/*  88:    */     {
/*  89:    */       public AbstractWidget createWidget()
/*  90:    */       {
/*  91: 81 */         return new ADSectionWidgetImpl();
/*  92:    */       }
/*  93:    */     };
/*  94:    */   }
/*  95:    */   
/*  96:    */   public static WidgetCreator initSectionRowWidgetCreator()
/*  97:    */   {
/*  98: 87 */     new WidgetCreator()
/*  99:    */     {
/* 100:    */       public AbstractWidget createWidget()
/* 101:    */       {
/* 102: 89 */         return new ADSectionRowWidgetImpl();
/* 103:    */       }
/* 104:    */     };
/* 105:    */   }
/* 106:    */   
/* 107:    */   public static WidgetCreator initSectionColWidgetCreator()
/* 108:    */   {
/* 109: 95 */     new WidgetCreator()
/* 110:    */     {
/* 111:    */       public AbstractWidget createWidget()
/* 112:    */       {
/* 113: 97 */         return new ADSectionColWidgetImpl();
/* 114:    */       }
/* 115:    */     };
/* 116:    */   }
/* 117:    */   
/* 118:    */   public static WidgetCreator initTabWidgetCreator()
/* 119:    */   {
/* 120:103 */     new WidgetCreator()
/* 121:    */     {
/* 122:    */       public AbstractWidget createWidget()
/* 123:    */       {
/* 124:105 */         return new ADTabWidgetImpl();
/* 125:    */       }
/* 126:    */     };
/* 127:    */   }
/* 128:    */   
/* 129:    */   public static WidgetCreator initTabGroupWidgetCreator()
/* 130:    */   {
/* 131:111 */     new WidgetCreator()
/* 132:    */     {
/* 133:    */       public AbstractWidget createWidget()
/* 134:    */       {
/* 135:113 */         return new ADTabGroupWidgetImpl();
/* 136:    */       }
/* 137:    */     };
/* 138:    */   }
/* 139:    */   
/* 140:    */   public static WidgetCreator initPageWidgetCreator()
/* 141:    */   {
/* 142:119 */     new WidgetCreator()
/* 143:    */     {
/* 144:    */       public AbstractWidget createWidget()
/* 145:    */       {
/* 146:121 */         return new ADPageWidgetImpl();
/* 147:    */       }
/* 148:    */     };
/* 149:    */   }
/* 150:    */   
/* 151:    */   public static WidgetCreator initToolBarContainerCreator()
/* 152:    */   {
/* 153:127 */     new WidgetCreator()
/* 154:    */     {
/* 155:    */       public AbstractWidget createWidget()
/* 156:    */       {
/* 157:129 */         return new ADToolBarContainerWidgetImpl();
/* 158:    */       }
/* 159:    */     };
/* 160:    */   }
/* 161:    */   
/* 162:    */   public static WidgetCreator initToolBarLeftWidgetCreator()
/* 163:    */   {
/* 164:135 */     new WidgetCreator()
/* 165:    */     {
/* 166:    */       public AbstractWidget createWidget()
/* 167:    */       {
/* 168:137 */         return new ADToolBarLeftWidgetImpl();
/* 169:    */       }
/* 170:    */     };
/* 171:    */   }
/* 172:    */   
/* 173:    */   public static WidgetCreator initToolBarRightWidgetCreator()
/* 174:    */   {
/* 175:143 */     new WidgetCreator()
/* 176:    */     {
/* 177:    */       public AbstractWidget createWidget()
/* 178:    */       {
/* 179:145 */         return new ADToolBarRightWidgetImpl();
/* 180:    */       }
/* 181:    */     };
/* 182:    */   }
/* 183:    */   
/* 184:    */   public static WidgetCreator initMenuBarWidgetCreator()
/* 185:    */   {
/* 186:151 */     new WidgetCreator()
/* 187:    */     {
/* 188:    */       public AbstractWidget createWidget()
/* 189:    */       {
/* 190:153 */         return new ADMenuBarWidgetImpl();
/* 191:    */       }
/* 192:    */     };
/* 193:    */   }
/* 194:    */   
/* 195:    */   public static WidgetCreator initMenuWidgetCreator()
/* 196:    */   {
/* 197:159 */     new WidgetCreator()
/* 198:    */     {
/* 199:    */       public AbstractWidget createWidget()
/* 200:    */       {
/* 201:161 */         return new ADMenuWidgetImpl();
/* 202:    */       }
/* 203:    */     };
/* 204:    */   }
/* 205:    */   
/* 206:    */   public static WidgetCreator initMenuItemWidgetCreator()
/* 207:    */   {
/* 208:167 */     new WidgetCreator()
/* 209:    */     {
/* 210:    */       public AbstractWidget createWidget()
/* 211:    */       {
/* 212:169 */         return new ADMenuItemWidgetImpl();
/* 213:    */       }
/* 214:    */     };
/* 215:    */   }
/* 216:    */   
/* 217:    */   public static WidgetCreator initMenuViewWidgetCreator()
/* 218:    */   {
/* 219:175 */     new WidgetCreator()
/* 220:    */     {
/* 221:    */       public AbstractWidget createWidget()
/* 222:    */       {
/* 223:177 */         return new ADMenuViewWidgetImpl();
/* 224:    */       }
/* 225:    */     };
/* 226:    */   }
/* 227:    */   
/* 228:    */   public static WidgetCreator initPageGroupWidgetCreator()
/* 229:    */   {
/* 230:183 */     new WidgetCreator()
/* 231:    */     {
/* 232:    */       public AbstractWidget createWidget()
/* 233:    */       {
/* 234:185 */         return new ADPageGroupWidgetImpl();
/* 235:    */       }
/* 236:    */     };
/* 237:    */   }
/* 238:    */   
/* 239:    */   public static WidgetCreator initTableColWidgetCreator()
/* 240:    */   {
/* 241:191 */     new WidgetCreator()
/* 242:    */     {
/* 243:    */       public AbstractWidget createWidget()
/* 244:    */       {
/* 245:193 */         return new ADTableColWidgetImpl();
/* 246:    */       }
/* 247:    */     };
/* 248:    */   }
/* 249:    */   
/* 250:    */   public static WidgetCreator initTableWidgetCreator()
/* 251:    */   {
/* 252:199 */     new WidgetCreator()
/* 253:    */     {
/* 254:    */       public AbstractWidget createWidget()
/* 255:    */       {
/* 256:201 */         return new ADTableWidgetImpl();
/* 257:    */       }
/* 258:    */     };
/* 259:    */   }
/* 260:    */   
/* 261:    */   public static WidgetCreator initImageWidgetCreator()
/* 262:    */   {
/* 263:207 */     new WidgetCreator()
/* 264:    */     {
/* 265:    */       public AbstractWidget createWidget()
/* 266:    */       {
/* 267:209 */         return new ADImageWidgeImpl();
/* 268:    */       }
/* 269:    */     };
/* 270:    */   }
/* 271:    */   
/* 272:    */   public static WidgetCreator initDropDownWidgetCreator()
/* 273:    */   {
/* 274:215 */     new WidgetCreator()
/* 275:    */     {
/* 276:    */       public AbstractWidget createWidget()
/* 277:    */       {
/* 278:217 */         return new ADDropDownWidgetImpl();
/* 279:    */       }
/* 280:    */     };
/* 281:    */   }
/* 282:    */   
/* 283:    */   public static WidgetCreator initButtonWidgetCreator()
/* 284:    */   {
/* 285:223 */     new WidgetCreator()
/* 286:    */     {
/* 287:    */       public AbstractWidget createWidget()
/* 288:    */       {
/* 289:225 */         return new ADButtonWidgetImpl();
/* 290:    */       }
/* 291:    */     };
/* 292:    */   }
/* 293:    */   
/* 294:    */   public static WidgetCreator initStateWidgetCreator()
/* 295:    */   {
/* 296:231 */     new WidgetCreator()
/* 297:    */     {
/* 298:    */       public AbstractWidget createWidget()
/* 299:    */       {
/* 300:233 */         return new ADStateWidgetImpl();
/* 301:    */       }
/* 302:    */     };
/* 303:    */   }
/* 304:    */   
/* 305:    */   public static WidgetCreator initLookupWidgetCreator()
/* 306:    */   {
/* 307:239 */     new WidgetCreator()
/* 308:    */     {
/* 309:    */       public AbstractWidget createWidget()
/* 310:    */       {
/* 311:241 */         return new ADLookupWidgetImpl();
/* 312:    */       }
/* 313:    */     };
/* 314:    */   }
/* 315:    */   
/* 316:    */   public static WidgetCreator initButtonStateWidgetCreator()
/* 317:    */   {
/* 318:247 */     new WidgetCreator()
/* 319:    */     {
/* 320:    */       public AbstractWidget createWidget()
/* 321:    */       {
/* 322:249 */         return new ADButtonStateWidgetImpl();
/* 323:    */       }
/* 324:    */     };
/* 325:    */   }
/* 326:    */   
/* 327:    */   public static WidgetCreator initSectionSeparatorWidgetCreator()
/* 328:    */   {
/* 329:255 */     new WidgetCreator()
/* 330:    */     {
/* 331:    */       public AbstractWidget createWidget()
/* 332:    */       {
/* 333:257 */         return new ADSectionSeparatorWidgetImpl();
/* 334:    */       }
/* 335:    */     };
/* 336:    */   }
/* 337:    */   
/* 338:    */   public static WidgetCreator initPopUpImageWidgetCreator()
/* 339:    */   {
/* 340:263 */     new WidgetCreator()
/* 341:    */     {
/* 342:    */       public AbstractWidget createWidget()
/* 343:    */       {
/* 344:265 */         return new ADPopUpImageWidgetImpl();
/* 345:    */       }
/* 346:    */     };
/* 347:    */   }
/* 348:    */   
/* 349:    */   public static WidgetCreator initTreeWidgetCreator()
/* 350:    */   {
/* 351:271 */     new WidgetCreator()
/* 352:    */     {
/* 353:    */       public AbstractWidget createWidget()
/* 354:    */       {
/* 355:273 */         return new ADTreeWidgetImpl();
/* 356:    */       }
/* 357:    */     };
/* 358:    */   }
/* 359:    */   
/* 360:    */   public static WidgetCreator initSignatureCaptureWidgetCreator()
/* 361:    */   {
/* 362:279 */     new WidgetCreator()
/* 363:    */     {
/* 364:    */       public AbstractWidget createWidget()
/* 365:    */       {
/* 366:281 */         return new ADSignatureWidgetImpl();
/* 367:    */       }
/* 368:    */     };
/* 369:    */   }
/* 370:    */   
/* 371:    */   public static WidgetCreator initCalendarWidgetCreator()
/* 372:    */   {
/* 373:287 */     new WidgetCreator()
/* 374:    */     {
/* 375:    */       public AbstractWidget createWidget()
/* 376:    */       {
/* 377:289 */         return new ADCalendarWidgetImpl();
/* 378:    */       }
/* 379:    */     };
/* 380:    */   }
/* 381:    */   
/* 382:    */   public static WidgetCreator initReasonForChangeWidgetCreator()
/* 383:    */   {
/* 384:295 */     new WidgetCreator()
/* 385:    */     {
/* 386:    */       public AbstractWidget createWidget()
/* 387:    */       {
/* 388:297 */         return new ADReasonForChangeWidgetImpl();
/* 389:    */       }
/* 390:    */     };
/* 391:    */   }
/* 392:    */   
/* 393:    */   public static WidgetCreator initFileDialogueWidgetCreator()
/* 394:    */   {
/* 395:305 */     new WidgetCreator()
/* 396:    */     {
/* 397:    */       public AbstractWidget createWidget()
/* 398:    */       {
/* 399:307 */         return new ADFileDialogueWidgetImpl();
/* 400:    */       }
/* 401:    */     };
/* 402:    */   }
/* 403:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.ADWidgetFactory
 * JD-Core Version:    0.7.0.1
 */