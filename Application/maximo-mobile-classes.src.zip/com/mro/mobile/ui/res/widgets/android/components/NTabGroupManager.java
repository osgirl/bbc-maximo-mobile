/*   1:    */ package com.mro.mobile.ui.res.widgets.android.components;
/*   2:    */ 
/*   3:    */ import android.os.Bundle;
/*   4:    */ import android.util.Log;
/*   5:    */ import android.view.View;
/*   6:    */ import android.view.ViewGroup;
/*   7:    */ import android.view.ViewParent;
/*   8:    */ import android.widget.TabHost.OnTabChangeListener;
/*   9:    */ import android.widget.TabHost.TabContentFactory;
/*  10:    */ import android.widget.TabHost.TabSpec;
/*  11:    */ import android.widget.TabWidget;
/*  12:    */ import com.mro.mobile.ui.res.controls.TabControl;
/*  13:    */ import com.mro.mobile.ui.res.controls.TabGroupControl;
/*  14:    */ import com.mro.mobile.ui.res.widgets.android.AndroidEnv;
/*  15:    */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  16:    */ import com.mro.mobile.util.android.ADStreamerImpl;
/*  17:    */ import java.util.HashMap;
/*  18:    */ 
/*  19:    */ public class NTabGroupManager
/*  20:    */   implements TabHost.OnTabChangeListener
/*  21:    */ {
/*  22:    */   private final NTabGroup ntabgroup;
/*  23: 36 */   private final HashMap<String, TabInfo> mTabsInfo = new HashMap();
/*  24:    */   private TabInfo mLastTabInfo;
/*  25:    */   
/*  26:    */   public NTabGroupManager(NTabGroup ntabgroup)
/*  27:    */   {
/*  28: 41 */     this.ntabgroup = ntabgroup;
/*  29: 42 */     ntabgroup.setOnTabChangedListener(this);
/*  30:    */   }
/*  31:    */   
/*  32:    */   public TabInfo getTab(String tabId)
/*  33:    */   {
/*  34: 46 */     return (TabInfo)this.mTabsInfo.get(tabId);
/*  35:    */   }
/*  36:    */   
/*  37:    */   public void addTab(TabHost.TabSpec tabSpec, View view, Bundle args)
/*  38:    */   {
/*  39: 50 */     ensureViewHasNoParent(view);
/*  40: 51 */     NPanel fixwrap = NPanel.createByInflate(this.ntabgroup.getController(), AndroidEnv.getCurrentActivity(), 0);
/*  41: 52 */     fixwrap.addView(view);
/*  42: 53 */     tabSpec.setContent(new ViewTabFactory(fixwrap));
/*  43: 54 */     String tag = tabSpec.getTag();
/*  44: 55 */     TabInfo tabInfo = new TabInfo(tag, args);
/*  45: 56 */     this.mTabsInfo.put(tag, tabInfo);
/*  46: 57 */     this.ntabgroup.recordMappingFromTagToTab(tabSpec.getTag(), (TabControl)((UIComponent)view).getController());
/*  47: 58 */     this.ntabgroup.addTab(tabSpec);
/*  48:    */   }
/*  49:    */   
/*  50:    */   private void ensureViewHasNoParent(View view)
/*  51:    */   {
/*  52: 63 */     ViewParent parent = view.getParent();
/*  53: 64 */     if ((parent != null) && ((parent instanceof ViewGroup))) {
/*  54: 65 */       ((ViewGroup)parent).removeView(view);
/*  55:    */     }
/*  56:    */   }
/*  57:    */   
/*  58:    */   public void onTabChanged(String tabId)
/*  59:    */   {
/*  60: 71 */     TabInfo newTabInfo = (TabInfo)this.mTabsInfo.get(tabId);
/*  61: 72 */     if (newTabInfo == null) {
/*  62: 73 */       throw new RuntimeException(" Your target tabinfo is not defined");
/*  63:    */     }
/*  64: 75 */     if (newTabInfo == this.mLastTabInfo) {
/*  65: 76 */       return;
/*  66:    */     }
/*  67:    */     try
/*  68:    */     {
/*  69: 80 */       if (!this.ntabgroup.isAddingTab())
/*  70:    */       {
/*  71: 81 */         this.ntabgroup.getTabGroupController().setCurrentTab(this.ntabgroup.getTabFromTag(tabId));
/*  72: 82 */         this.ntabgroup.getTabGroupController().handleEvent("refreshTab", null, null);
/*  73:    */       }
/*  74:    */     }
/*  75:    */     catch (Throwable t)
/*  76:    */     {
/*  77: 85 */       Log.d(ADStreamerImpl.TAG, "as setCurrentTab [" + this.ntabgroup.getTabFromTag(tabId) + "]", t);
/*  78:    */     }
/*  79: 87 */     this.mLastTabInfo = newTabInfo;
/*  80:    */   }
/*  81:    */   
/*  82:    */   public void swicthToAnotherTab(Bundle bundle)
/*  83:    */   {
/*  84: 91 */     swicthToAnotherTab(bundle.getString("targettabtag"));
/*  85:    */   }
/*  86:    */   
/*  87:    */   public void swicthToAnotherTab(String tag)
/*  88:    */   {
/*  89: 95 */     TabWidget widget = this.ntabgroup.getTabWidget();
/*  90: 96 */     int oldFocusability = widget.getDescendantFocusability();
/*  91: 97 */     widget.setDescendantFocusability(393216);
/*  92: 98 */     this.ntabgroup.setCurrentTabByTag(tag);
/*  93: 99 */     widget.setDescendantFocusability(oldFocusability);
/*  94:    */   }
/*  95:    */   
/*  96:    */   public void swicthToAnotherTab(int index)
/*  97:    */   {
/*  98:103 */     TabWidget widget = this.ntabgroup.getTabWidget();
/*  99:104 */     int oldFocusability = widget.getDescendantFocusability();
/* 100:105 */     widget.setDescendantFocusability(393216);
/* 101:106 */     this.ntabgroup.setCurrentTab(index);
/* 102:107 */     widget.setDescendantFocusability(oldFocusability);
/* 103:    */   }
/* 104:    */   
/* 105:    */   public static final class TabInfo
/* 106:    */   {
/* 107:    */     public String tag;
/* 108:    */     public Bundle args;
/* 109:    */     
/* 110:    */     TabInfo(String _tag, Bundle _args)
/* 111:    */     {
/* 112:115 */       this.tag = _tag;
/* 113:116 */       this.args = _args;
/* 114:    */     }
/* 115:    */   }
/* 116:    */   
/* 117:    */   static class ViewTabFactory
/* 118:    */     implements TabHost.TabContentFactory
/* 119:    */   {
/* 120:121 */     private View v = null;
/* 121:    */     
/* 122:    */     public ViewTabFactory(View v)
/* 123:    */     {
/* 124:124 */       this.v = v;
/* 125:    */     }
/* 126:    */     
/* 127:    */     public View createTabContent(String tag)
/* 128:    */     {
/* 129:129 */       return this.v;
/* 130:    */     }
/* 131:    */   }
/* 132:    */   
/* 133:    */   public int getTabCount()
/* 134:    */   {
/* 135:134 */     return this.ntabgroup.tabCounts;
/* 136:    */   }
/* 137:    */   
/* 138:    */   public void removeAllTabs()
/* 139:    */   {
/* 140:138 */     this.ntabgroup.clearAllTabs();
/* 141:    */   }
/* 142:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.components.NTabGroupManager
 * JD-Core Version:    0.7.0.1
 */