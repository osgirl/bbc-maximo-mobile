/*   1:    */ package com.mro.mobile.ui.res.widgets.android.components;
/*   2:    */ 
/*   3:    */ import android.content.Context;
/*   4:    */ import android.util.AttributeSet;
/*   5:    */ import android.view.View;
/*   6:    */ import android.widget.LinearLayout.LayoutParams;
/*   7:    */ import com.ibm.tivoli.maximo.mobile.android.util.UIUtil;
/*   8:    */ import com.ibm.tivoli.maximo.mobile.resources.R.layout;
/*   9:    */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*  10:    */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  11:    */ 
/*  12:    */ public class NToolBar
/*  13:    */   extends NPanel
/*  14:    */   implements UIComponent
/*  15:    */ {
/*  16: 29 */   private String cid = null;
/*  17: 31 */   private static final int DEFAULT_XML_LAYOUT = UIUtil.getResourceId(R.layout.class, "ntoolbar");
/*  18: 33 */   public LinearLayout.LayoutParams constraints = new LinearLayout.LayoutParams(-2, -2);
/*  19:    */   
/*  20:    */   public NToolBar(Context context)
/*  21:    */   {
/*  22: 38 */     super(context);
/*  23:    */   }
/*  24:    */   
/*  25:    */   public NToolBar(Context context, AttributeSet attrs)
/*  26:    */   {
/*  27: 42 */     super(context, attrs);
/*  28:    */   }
/*  29:    */   
/*  30:    */   public static NToolBar createByInflate(AbstractMobileControl control, Context context, int orientation)
/*  31:    */   {
/*  32: 47 */     return createByInflate(DEFAULT_XML_LAYOUT, control, context, orientation);
/*  33:    */   }
/*  34:    */   
/*  35:    */   public static NToolBar createByInflate(int layoutId, AbstractMobileControl control, Context context, int orientation)
/*  36:    */   {
/*  37: 51 */     NToolBar toolbar = (NToolBar)View.inflate(context, layoutId, null);
/*  38: 52 */     toolbar.postInstance(control, orientation);
/*  39: 53 */     return toolbar;
/*  40:    */   }
/*  41:    */   
/*  42:    */   protected void postInstance(AbstractMobileControl control, int orientation)
/*  43:    */   {
/*  44: 57 */     if (control != null) {
/*  45: 58 */       setId(NIDMapper.getAndroidIdFor(control.getId()));
/*  46:    */     } else {
/*  47: 60 */       setId(NIDMapper.getNextId());
/*  48:    */     }
/*  49: 62 */     setController(control);
/*  50: 63 */     setOrientation(orientation);
/*  51: 64 */     setOpaque(false);
/*  52:    */   }
/*  53:    */   
/*  54:    */   public LinearLayout.LayoutParams getLeftToolBarConstraints()
/*  55:    */   {
/*  56: 68 */     LinearLayout.LayoutParams cons = new LinearLayout.LayoutParams(-2, -2);
/*  57: 69 */     cons.setMargins(2, 1, 0, 0);
/*  58:    */     
/*  59: 71 */     cons.gravity = 19;
/*  60: 72 */     this.constraints = cons;
/*  61: 73 */     return cons;
/*  62:    */   }
/*  63:    */   
/*  64:    */   public LinearLayout.LayoutParams getRightToolBarConstraints()
/*  65:    */   {
/*  66: 78 */     LinearLayout.LayoutParams cons = new LinearLayout.LayoutParams(-2, -2);
/*  67: 79 */     cons.setMargins(0, 1, 2, 0);
/*  68:    */     
/*  69: 81 */     cons.gravity = 21;
/*  70: 82 */     this.constraints = cons;
/*  71: 83 */     return cons;
/*  72:    */   }
/*  73:    */   
/*  74:    */   public LinearLayout.LayoutParams getToolBarConstraints()
/*  75:    */   {
/*  76: 88 */     this.constraints.weight = 1.0F;
/*  77: 89 */     return this.constraints;
/*  78:    */   }
/*  79:    */   
/*  80: 92 */   private LinearLayout.LayoutParams componentConstraints = null;
/*  81:    */   
/*  82:    */   public Object getConstraints()
/*  83:    */   {
/*  84: 96 */     return this.componentConstraints;
/*  85:    */   }
/*  86:    */   
/*  87:    */   public void setConstraints(LinearLayout.LayoutParams consts)
/*  88:    */   {
/*  89:101 */     this.componentConstraints = consts;
/*  90:102 */     setLayoutParams(this.componentConstraints);
/*  91:    */   }
/*  92:    */   
/*  93:    */   public int getHorizontalAlignment()
/*  94:    */   {
/*  95:107 */     return getHorizontalAlignment();
/*  96:    */   }
/*  97:    */   
/*  98:    */   public void setBgImage(String image)
/*  99:    */   {
/* 100:111 */     setBackgroundImage(image);
/* 101:    */   }
/* 102:    */   
/* 103:    */   public String getCId()
/* 104:    */   {
/* 105:115 */     return this.cid;
/* 106:    */   }
/* 107:    */   
/* 108:    */   public void setCId(String cid)
/* 109:    */   {
/* 110:119 */     this.cid = cid;
/* 111:    */   }
/* 112:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.components.NToolBar
 * JD-Core Version:    0.7.0.1
 */