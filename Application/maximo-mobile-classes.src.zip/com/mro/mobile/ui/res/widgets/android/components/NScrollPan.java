/*   1:    */ package com.mro.mobile.ui.res.widgets.android.components;
/*   2:    */ 
/*   3:    */ import android.content.Context;
/*   4:    */ import android.graphics.Rect;
/*   5:    */ import android.util.AttributeSet;
/*   6:    */ import android.view.View;
/*   7:    */ import android.widget.LinearLayout.LayoutParams;
/*   8:    */ import android.widget.ScrollView;
/*   9:    */ import com.ibm.tivoli.maximo.mobile.android.util.UIUtil;
/*  10:    */ import com.ibm.tivoli.maximo.mobile.resources.R.layout;
/*  11:    */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*  12:    */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  13:    */ import java.util.Enumeration;
/*  14:    */ import java.util.Vector;
/*  15:    */ 
/*  16:    */ public class NScrollPan
/*  17:    */   extends ScrollView
/*  18:    */   implements UIComponent
/*  19:    */ {
/*  20: 33 */   protected AbstractMobileControl controller = null;
/*  21: 35 */   private static final int DEFAULT_XML_LAYOUT = UIUtil.getResourceId(R.layout.class, "nscrollpan");
/*  22: 37 */   private String cid = null;
/*  23: 39 */   private Vector<Object> children = new Vector();
/*  24:    */   
/*  25:    */   public NScrollPan(Context context)
/*  26:    */   {
/*  27: 42 */     super(context);
/*  28:    */   }
/*  29:    */   
/*  30:    */   public NScrollPan(Context context, AttributeSet attrs)
/*  31:    */   {
/*  32: 46 */     super(context, attrs);
/*  33:    */   }
/*  34:    */   
/*  35:    */   public NScrollPan(Context context, AttributeSet attrs, int defStyle)
/*  36:    */   {
/*  37: 50 */     super(context, attrs, defStyle);
/*  38:    */   }
/*  39:    */   
/*  40:    */   public static NScrollPan createByInflate(AbstractMobileControl control, Context context, View v)
/*  41:    */   {
/*  42: 54 */     return createByInflate(DEFAULT_XML_LAYOUT, control, context, v);
/*  43:    */   }
/*  44:    */   
/*  45:    */   public static NScrollPan createByInflate(int layoutId, AbstractMobileControl control, Context context, View v)
/*  46:    */   {
/*  47: 58 */     NScrollPan scrollpan = (NScrollPan)View.inflate(context, layoutId, null);
/*  48: 59 */     scrollpan.postInstance(control, v);
/*  49: 60 */     return scrollpan;
/*  50:    */   }
/*  51:    */   
/*  52:    */   private void postInstance(AbstractMobileControl control, View v)
/*  53:    */   {
/*  54: 64 */     setController(control);
/*  55: 65 */     if (control != null) {
/*  56: 67 */       setId(NIDMapper.getAndroidIdFor(control.getId()));
/*  57:    */     } else {
/*  58: 69 */       setId(NIDMapper.getNextId());
/*  59:    */     }
/*  60: 73 */     setFillViewport(true);
/*  61: 75 */     if (v != null) {
/*  62: 76 */       addView(v);
/*  63:    */     }
/*  64: 79 */     init();
/*  65:    */   }
/*  66:    */   
/*  67:    */   public String getCId()
/*  68:    */   {
/*  69: 84 */     return this.cid;
/*  70:    */   }
/*  71:    */   
/*  72:    */   public void setCId(String cid)
/*  73:    */   {
/*  74: 89 */     this.cid = cid;
/*  75:    */   }
/*  76:    */   
/*  77:    */   public void init() {}
/*  78:    */   
/*  79:    */   public void addChildUIComponent(UIComponent child)
/*  80:    */   {
/*  81: 98 */     this.children.addElement(child);
/*  82:    */   }
/*  83:    */   
/*  84:    */   public boolean canContainChildren()
/*  85:    */   {
/*  86:103 */     return true;
/*  87:    */   }
/*  88:    */   
/*  89:    */   public Enumeration getChildren()
/*  90:    */   {
/*  91:108 */     return this.children.elements();
/*  92:    */   }
/*  93:    */   
/*  94:    */   public AbstractMobileControl getController()
/*  95:    */   {
/*  96:116 */     return this.controller;
/*  97:    */   }
/*  98:    */   
/*  99:    */   public void setController(AbstractMobileControl controller)
/* 100:    */   {
/* 101:123 */     this.controller = controller;
/* 102:    */   }
/* 103:    */   
/* 104:126 */   private LinearLayout.LayoutParams constraints = null;
/* 105:    */   
/* 106:    */   public Object getConstraints()
/* 107:    */   {
/* 108:132 */     return this.constraints;
/* 109:    */   }
/* 110:    */   
/* 111:    */   public void setConstraints(Object consts)
/* 112:    */   {
/* 113:139 */     this.constraints = ((LinearLayout.LayoutParams)consts);
/* 114:140 */     setLayoutParams(this.constraints);
/* 115:141 */     requestLayout();
/* 116:    */   }
/* 117:    */   
/* 118:    */   protected boolean onRequestFocusInDescendants(int direction, Rect previouslyFocusedRect)
/* 119:    */   {
/* 120:147 */     return true;
/* 121:    */   }
/* 122:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.components.NScrollPan
 * JD-Core Version:    0.7.0.1
 */