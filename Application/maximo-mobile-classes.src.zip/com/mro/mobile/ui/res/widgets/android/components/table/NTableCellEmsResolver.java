/*  1:   */ package com.mro.mobile.ui.res.widgets.android.components.table;
/*  2:   */ 
/*  3:   */ import com.mro.mobile.ui.res.widgets.android.components.EmsResolver;
/*  4:   */ 
/*  5:   */ public class NTableCellEmsResolver
/*  6:   */   implements EmsResolver
/*  7:   */ {
/*  8: 7 */   private NTable table = null;
/*  9: 8 */   private int column = 0;
/* 10:   */   
/* 11:   */   public NTableCellEmsResolver(NTable table, int column)
/* 12:   */   {
/* 13:10 */     this.table = table;
/* 14:11 */     this.column = column;
/* 15:   */   }
/* 16:   */   
/* 17:   */   public int getEms()
/* 18:   */   {
/* 19:15 */     return this.table.getTableColumnWidth(this.column);
/* 20:   */   }
/* 21:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.components.table.NTableCellEmsResolver
 * JD-Core Version:    0.7.0.1
 */