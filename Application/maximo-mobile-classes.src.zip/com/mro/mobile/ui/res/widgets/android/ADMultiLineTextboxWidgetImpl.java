/*  1:   */ package com.mro.mobile.ui.res.widgets.android;
/*  2:   */ 
/*  3:   */ import android.view.ViewGroup;
/*  4:   */ import com.ibm.tivoli.maximo.mobile.android.util.UIUtil;
/*  5:   */ import com.ibm.tivoli.maximo.mobile.resources.R.layout;
/*  6:   */ import com.mro.mobile.MobileApplicationException;
/*  7:   */ import com.mro.mobile.ui.res.controls.MultiLineTextboxControl;
/*  8:   */ import com.mro.mobile.ui.res.widgets.android.components.NTextField;
/*  9:   */ import com.mro.mobile.ui.res.widgets.android.components.NTextFieldMLL;
/* 10:   */ import com.mro.mobile.ui.res.widgets.def.MultiLineTextboxWidget;
/* 11:   */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/* 12:   */ 
/* 13:   */ public class ADMultiLineTextboxWidgetImpl
/* 14:   */   extends ADTextboxWidgetImpl
/* 15:   */   implements MultiLineTextboxWidget
/* 16:   */ {
/* 17:   */   protected MultiLineTextboxControl getMultiLineTextboxControl()
/* 18:   */   {
/* 19:33 */     return (MultiLineTextboxControl)getController();
/* 20:   */   }
/* 21:   */   
/* 22:   */   public ADMultiLineTextboxWidgetImpl() {}
/* 23:   */   
/* 24:   */   public ADMultiLineTextboxWidgetImpl(MultiLineTextboxControl control)
/* 25:   */   {
/* 26:40 */     setController(control);
/* 27:   */   }
/* 28:   */   
/* 29:   */   public UIComponent[] resolveMultiLineTextboxComponents()
/* 30:   */     throws MobileApplicationException
/* 31:   */   {
/* 32:45 */     String text = getMultiLineTextboxControl().getValue();
/* 33:46 */     int cols = getMultiLineTextboxControl().getIntValue("cols");
/* 34:47 */     this.textField = new NTextFieldMLL(getMultiLineTextboxControl(), AndroidEnv.getCurrentActivity(), text, 0, cols > 0 ? cols : 30, 6);
/* 35:48 */     int rows = getMultiLineTextboxControl().getIntValue("rows");
/* 36:49 */     this.textField.setCId(getMultiLineTextboxControl().getStringValue("id"));
/* 37:50 */     this.textField.setSingleLine(false);
/* 38:51 */     this.textField.setLines(rows);
/* 39:52 */     this.textField.setGravity(51);
/* 40:   */     
/* 41:   */ 
/* 42:   */ 
/* 43:   */ 
/* 44:   */ 
/* 45:   */ 
/* 46:   */ 
/* 47:   */ 
/* 48:   */ 
/* 49:62 */     UIComponent labelPanel = getMultiLineTextboxControl().getLabelPanelUIComponent(false);
/* 50:63 */     if (labelPanel != null)
/* 51:   */     {
/* 52:65 */       ViewGroup viewGroup = getViewGroupForSubclassContent(UIUtil.getResourceId(R.layout.class, "admultilinetextboxwidgetimpl"));
/* 53:66 */       viewGroup.addView(this.textField);
/* 54:   */       
/* 55:68 */       UIComponent[] ret = { labelPanel };
/* 56:69 */       return ret;
/* 57:   */     }
/* 58:71 */     UIComponent[] ret = { this.textField };
/* 59:72 */     return ret;
/* 60:   */   }
/* 61:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.ADMultiLineTextboxWidgetImpl
 * JD-Core Version:    0.7.0.1
 */