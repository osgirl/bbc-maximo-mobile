/*  1:   */ package com.mro.mobile.ui.res.widgets.android.components.tree;
/*  2:   */ 
/*  3:   */ import android.content.Context;
/*  4:   */ import android.view.View;
/*  5:   */ import android.view.ViewGroup;
/*  6:   */ import android.widget.BaseAdapter;
/*  7:   */ 
/*  8:   */ public class NTreeListViewAdapter
/*  9:   */   extends BaseAdapter
/* 10:   */ {
/* 11:26 */   private NTree nTree = null;
/* 12:28 */   private ListModel listModel = null;
/* 13:   */   
/* 14:   */   public NTreeListViewAdapter(Context context, TreeModel treeModel, NTree ntree)
/* 15:   */   {
/* 16:31 */     this.nTree = ntree;
/* 17:32 */     this.listModel = new ListModelImpl(context, treeModel, this);
/* 18:33 */     treeModel.addTreeListener((TreeListener)this.listModel);
/* 19:   */   }
/* 20:   */   
/* 21:   */   public int getCount()
/* 22:   */   {
/* 23:38 */     return getListModel().getCount();
/* 24:   */   }
/* 25:   */   
/* 26:   */   public Object getItem(int position)
/* 27:   */   {
/* 28:43 */     return getListModel().getItem(position);
/* 29:   */   }
/* 30:   */   
/* 31:   */   public long getItemId(int position)
/* 32:   */   {
/* 33:48 */     return getListModel().getItemId(position);
/* 34:   */   }
/* 35:   */   
/* 36:   */   public View getView(int position, View convertView, ViewGroup parent)
/* 37:   */   {
/* 38:53 */     return getListModel().getView(position, convertView, parent);
/* 39:   */   }
/* 40:   */   
/* 41:   */   public ListModel getListModel()
/* 42:   */   {
/* 43:57 */     return this.listModel;
/* 44:   */   }
/* 45:   */   
/* 46:   */   public NTree getnTree()
/* 47:   */   {
/* 48:61 */     return this.nTree;
/* 49:   */   }
/* 50:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.components.tree.NTreeListViewAdapter
 * JD-Core Version:    0.7.0.1
 */