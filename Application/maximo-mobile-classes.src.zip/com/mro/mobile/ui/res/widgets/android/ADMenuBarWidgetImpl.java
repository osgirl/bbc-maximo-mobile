package com.mro.mobile.ui.res.widgets.android;

import com.mro.mobile.ui.res.widgets.def.MenuBarWidget;
import java.util.ArrayList;

public class ADMenuBarWidgetImpl
  extends ADAbstractWidgetImpl
  implements MenuBarWidget
{
  public void addMenusToBar(ArrayList uiMenuComponents) {}
  
  public void showMenuBar() {}
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.ADMenuBarWidgetImpl
 * JD-Core Version:    0.7.0.1
 */