package com.mro.mobile.ui.res.widgets.def;

import com.mro.mobile.MobileApplicationException;

public abstract interface LongDescriptionWidget
  extends MultiLineTextboxWidget
{
  public abstract UIComponent[] resolveLongDescriptionComponents(String paramString, int paramInt, boolean paramBoolean)
    throws MobileApplicationException;
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.def.LongDescriptionWidget
 * JD-Core Version:    0.7.0.1
 */