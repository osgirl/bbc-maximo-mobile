package com.mro.mobile.ui.res.widgets.def;

import com.mro.mobile.ui.res.controls.utils.ControlStyle;

public abstract interface TabGroupWidget
{
  public abstract void createTabGroup(ControlStyle paramControlStyle);
  
  public abstract void applyLayoutConstraints();
  
  public abstract int getSelectedTab();
  
  public abstract int getTabCount();
  
  public abstract void selectTab(int paramInt);
  
  public abstract void removeAllTabs();
  
  public abstract void addImageTab(UIComponent paramUIComponent, String paramString1, String paramString2);
  
  public abstract void addTextTab(UIComponent paramUIComponent, String paramString1, String paramString2);
  
  public abstract UIComponent[] resolveTabGroupComponents();
  
  public abstract boolean needFullCleanUpDuringRefresh();
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.def.TabGroupWidget
 * JD-Core Version:    0.7.0.1
 */