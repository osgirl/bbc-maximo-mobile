package com.mro.mobile.ui.res.widgets.def;

import com.mro.mobile.MobileApplicationException;
import com.mro.mobile.ui.event.UIEvent;

public abstract interface CalendarWidget
{
  public abstract void createCalendar(int paramInt)
    throws MobileApplicationException;
  
  public abstract boolean performEvent(UIEvent paramUIEvent)
    throws MobileApplicationException;
  
  public abstract void refreshCalendar()
    throws MobileApplicationException;
  
  public abstract boolean isAmPmMarkerVisible();
  
  public abstract UIComponent[] resolveCalendarComponents();
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.def.CalendarWidget
 * JD-Core Version:    0.7.0.1
 */