package com.mro.mobile.ui.res.widgets.def;

public abstract interface SignatureCaptureWidget
  extends AbstractWidget
{
  public abstract UIComponent[] createSignatureCaptureWidget();
  
  public abstract byte[] getImageData();
  
  public abstract void erase();
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.def.SignatureCaptureWidget
 * JD-Core Version:    0.7.0.1
 */