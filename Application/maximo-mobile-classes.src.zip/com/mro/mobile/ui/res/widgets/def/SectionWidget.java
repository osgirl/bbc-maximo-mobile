package com.mro.mobile.ui.res.widgets.def;

public abstract interface SectionWidget
  extends AbstractWidget
{
  public abstract void createMainPanel();
  
  public abstract UIComponent getMainPanel();
  
  public abstract void setMainPanelSectionId(String paramString);
  
  public abstract void setBgImage(String paramString);
  
  public abstract void setBgColor(Object paramObject);
  
  public abstract UIComponent createLabel(String paramString);
  
  public abstract void configDefaultConstraints(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  public abstract UIComponent createOnePanel();
  
  public abstract void setPanelLayout(UIComponent paramUIComponent, int paramInt1, int paramInt2);
  
  public abstract void addOneComponentToPanel(UIComponent paramUIComponent1, UIComponent paramUIComponent2);
  
  public abstract Object createRowLevelConstraints(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  public abstract void addOneComponentToPanel(UIComponent paramUIComponent1, UIComponent paramUIComponent2, Object paramObject);
  
  public abstract Object createPageLevelConstraints(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  public abstract void setPanelConstraints(UIComponent paramUIComponent, Object paramObject);
  
  public abstract Object getDefaultConstraints();
  
  public abstract void addComponentsAsOneRow(UIComponent[] paramArrayOfUIComponent, UIComponent paramUIComponent, int paramInt);
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.def.SectionWidget
 * JD-Core Version:    0.7.0.1
 */