package com.mro.mobile.ui.res.widgets.def;

import com.mro.mobile.MobileApplicationException;
import com.mro.mobile.ui.res.controls.AbstractMobileControl;

public abstract interface SpinWidget
  extends AbstractWidget
{
  public abstract SpinWidget createSpinWidget(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean);
  
  public abstract void setSpinId(String paramString);
  
  public abstract void setEvent(String paramString);
  
  public abstract void setController(AbstractMobileControl paramAbstractMobileControl);
  
  public abstract void setDataBeanName(String paramString);
  
  public abstract void setMobileMboAttributeName(String paramString);
  
  public abstract int getInitValue();
  
  public abstract void setValue(int paramInt);
  
  public abstract int getValue();
  
  public abstract UIComponent[] resolveCheckBoxComponents(String paramString)
    throws MobileApplicationException;
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.def.SpinWidget
 * JD-Core Version:    0.7.0.1
 */