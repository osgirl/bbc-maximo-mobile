/*  1:   */ package com.mro.mobile.ui.res.widgets.android;
/*  2:   */ 
/*  3:   */ import com.mro.mobile.MobileApplicationException;
/*  4:   */ import com.mro.mobile.ui.res.widgets.android.components.NImage;
/*  5:   */ import com.mro.mobile.ui.res.widgets.def.ImageWidget;
/*  6:   */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  7:   */ 
/*  8:   */ public class ADImageWidgeImpl
/*  9:   */   extends ADAbstractWidgetImpl
/* 10:   */   implements ImageWidget
/* 11:   */ {
/* 12:23 */   private NImage image = null;
/* 13:   */   
/* 14:   */   public ImageWidget createImageWidget(String imagePath)
/* 15:   */   {
/* 16:26 */     this.image = NImage.createByInflate(getController(), AndroidEnv.getCurrentActivity(), imagePath);
/* 17:   */     
/* 18:28 */     return this;
/* 19:   */   }
/* 20:   */   
/* 21:   */   public void setImageId(String id) {}
/* 22:   */   
/* 23:   */   public UIComponent[] resolveImageComponents()
/* 24:   */     throws MobileApplicationException
/* 25:   */   {
/* 26:35 */     return new UIComponent[] { this.image };
/* 27:   */   }
/* 28:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.ADImageWidgeImpl
 * JD-Core Version:    0.7.0.1
 */