/*   1:    */ package com.mro.mobile.ui.res.widgets.android.components.table;
/*   2:    */ 
/*   3:    */ import android.content.Context;
/*   4:    */ import android.util.AttributeSet;
/*   5:    */ import android.view.View;
/*   6:    */ import android.widget.LinearLayout;
/*   7:    */ import android.widget.TableRow;
/*   8:    */ import android.widget.TableRow.LayoutParams;
/*   9:    */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*  10:    */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  11:    */ import java.util.ArrayList;
/*  12:    */ import java.util.Enumeration;
/*  13:    */ import java.util.List;
/*  14:    */ 
/*  15:    */ public class NScrollTable
/*  16:    */   extends LinearLayout
/*  17:    */   implements UIComponent
/*  18:    */ {
/*  19: 31 */   private String cid = null;
/*  20: 32 */   private NTable ntable = null;
/*  21: 33 */   private AbstractMobileControl controller = null;
/*  22: 35 */   private ArrayList<Integer> colWidths = new ArrayList();
/*  23: 36 */   private int maxHeight = 0;
/*  24: 37 */   private int maxHeaderHeight = 0;
/*  25:    */   private NTableLayoutUpdater updater;
/*  26:    */   
/*  27:    */   public void init() {}
/*  28:    */   
/*  29:    */   public NScrollTable(Context context, AttributeSet attrs)
/*  30:    */   {
/*  31: 46 */     super(context, attrs);
/*  32:    */   }
/*  33:    */   
/*  34:    */   public NScrollTable(Context context)
/*  35:    */   {
/*  36: 50 */     super(context);
/*  37:    */   }
/*  38:    */   
/*  39:    */   public void addChildUIComponent(UIComponent child) {}
/*  40:    */   
/*  41:    */   public boolean canContainChildren()
/*  42:    */   {
/*  43: 59 */     return false;
/*  44:    */   }
/*  45:    */   
/*  46:    */   public Enumeration getChildren()
/*  47:    */   {
/*  48: 64 */     return null;
/*  49:    */   }
/*  50:    */   
/*  51:    */   public AbstractMobileControl getController()
/*  52:    */   {
/*  53: 69 */     return this.controller;
/*  54:    */   }
/*  55:    */   
/*  56:    */   public void setController(AbstractMobileControl controller)
/*  57:    */   {
/*  58: 74 */     this.controller = controller;
/*  59:    */   }
/*  60:    */   
/*  61:    */   public Object getConstraints()
/*  62:    */   {
/*  63: 79 */     return null;
/*  64:    */   }
/*  65:    */   
/*  66:    */   public void setConstraints(Object contstraints) {}
/*  67:    */   
/*  68:    */   public String getCId()
/*  69:    */   {
/*  70: 87 */     return this.cid;
/*  71:    */   }
/*  72:    */   
/*  73:    */   public void setCId(String cid)
/*  74:    */   {
/*  75: 91 */     this.cid = cid;
/*  76:    */   }
/*  77:    */   
/*  78:    */   void setHolderTable(NTable table)
/*  79:    */   {
/*  80: 95 */     this.ntable = table;
/*  81:    */   }
/*  82:    */   
/*  83:    */   public NTable getHolderTable()
/*  84:    */   {
/*  85: 99 */     if (this.ntable == null) {
/*  86:100 */       this.ntable = ((NTable)getParent());
/*  87:    */     }
/*  88:102 */     if (this.updater == null) {
/*  89:103 */       this.updater = new NTableLayoutUpdater(this.ntable);
/*  90:    */     }
/*  91:105 */     return this.ntable;
/*  92:    */   }
/*  93:    */   
/*  94:    */   protected void onLayout(boolean changed, int l, int t, int r, int b)
/*  95:    */   {
/*  96:110 */     super.onLayout(changed, l, t, r, b);
/*  97:111 */     TableRow header = getHolderTable().getHeader();
/*  98:112 */     List<TableRow> body = getHolderTable().getBody();
/*  99:113 */     computeCellDimensions(header, body);
/* 100:114 */     fixRowCellsDimensions(this.colWidths, header, this.maxHeaderHeight);
/* 101:115 */     fixRowsCellsDimensions(this.colWidths, body, this.maxHeight);
/* 102:116 */     if (this.updater != null) {
/* 103:118 */       post(this.updater);
/* 104:    */     }
/* 105:    */   }
/* 106:    */   
/* 107:    */   private void fixRowsCellsDimensions(ArrayList<Integer> newColumnsWidth, List<TableRow> layout, int newHeight)
/* 108:    */   {
/* 109:123 */     for (TableRow row : layout) {
/* 110:124 */       fixRowCellsDimensions(newColumnsWidth, row, newHeight);
/* 111:    */     }
/* 112:    */   }
/* 113:    */   
/* 114:    */   private void fixRowCellsDimensions(ArrayList<Integer> newColumnsWidth, TableRow aRow, int newHeight)
/* 115:    */   {
/* 116:129 */     for (int cellnum = 0; cellnum < aRow.getChildCount(); cellnum++) {
/* 117:130 */       fixDimension((Integer)newColumnsWidth.get(cellnum), aRow.getChildAt(cellnum), newHeight);
/* 118:    */     }
/* 119:    */   }
/* 120:    */   
/* 121:    */   protected void fixDimension(Integer newColumnWidth, View cell, int newHeight)
/* 122:    */   {
/* 123:135 */     TableRow.LayoutParams params = (TableRow.LayoutParams)cell.getLayoutParams();
/* 124:136 */     params.width = newColumnWidth.intValue();
/* 125:137 */     if (newHeight > 0) {
/* 126:138 */       params.height = newHeight;
/* 127:    */     }
/* 128:    */   }
/* 129:    */   
/* 130:    */   protected ArrayList<Integer> computeCellDimensions(TableRow header, List<TableRow> body)
/* 131:    */   {
/* 132:143 */     this.colWidths.clear();
/* 133:144 */     this.maxHeaderHeight = analyzeTableRow(header);
/* 134:145 */     this.maxHeight = 0;
/* 135:146 */     for (TableRow row : body) {
/* 136:147 */       this.maxHeight = Math.max(this.maxHeight, analyzeTableRow(row));
/* 137:    */     }
/* 138:149 */     return this.colWidths;
/* 139:    */   }
/* 140:    */   
/* 141:    */   private int analyzeTableRow(TableRow row)
/* 142:    */   {
/* 143:153 */     int height = 0;
/* 144:154 */     for (int cellnum = 0; cellnum < row.getChildCount(); cellnum++)
/* 145:    */     {
/* 146:155 */       View cell = row.getChildAt(cellnum);
/* 147:156 */       Integer cellWidth = Integer.valueOf(cell.getWidth());
/* 148:157 */       if (this.colWidths.size() <= cellnum)
/* 149:    */       {
/* 150:158 */         this.colWidths.add(cellWidth);
/* 151:    */       }
/* 152:    */       else
/* 153:    */       {
/* 154:160 */         Integer current = (Integer)this.colWidths.get(cellnum);
/* 155:161 */         if (cellWidth.intValue() > current.intValue())
/* 156:    */         {
/* 157:162 */           this.colWidths.remove(cellnum);
/* 158:163 */           this.colWidths.add(cellnum, cellWidth);
/* 159:    */         }
/* 160:    */       }
/* 161:166 */       int cellHeight = cell.getHeight();
/* 162:167 */       if (height < cellHeight) {
/* 163:168 */         height = cellHeight;
/* 164:    */       }
/* 165:    */     }
/* 166:172 */     return height;
/* 167:    */   }
/* 168:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.components.table.NScrollTable
 * JD-Core Version:    0.7.0.1
 */