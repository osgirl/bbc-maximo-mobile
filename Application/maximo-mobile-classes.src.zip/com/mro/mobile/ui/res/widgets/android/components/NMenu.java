/*   1:    */ package com.mro.mobile.ui.res.widgets.android.components;
/*   2:    */ 
/*   3:    */ import android.content.Context;
/*   4:    */ import android.view.View;
/*   5:    */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*   6:    */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*   7:    */ import java.util.Enumeration;
/*   8:    */ import java.util.Vector;
/*   9:    */ 
/*  10:    */ public class NMenu
/*  11:    */   extends View
/*  12:    */   implements UIComponent
/*  13:    */ {
/*  14: 28 */   private String cid = null;
/*  15: 29 */   private String menuLabel = "";
/*  16: 30 */   private String targetid = null;
/*  17: 31 */   private Object value = null;
/*  18: 33 */   private AbstractMobileControl controller = null;
/*  19: 34 */   private Vector children = new Vector();
/*  20:    */   private Vector controlNodeData;
/*  21:    */   
/*  22:    */   public NMenu(AbstractMobileControl controller, Context context)
/*  23:    */   {
/*  24: 38 */     super(context);
/*  25: 39 */     setController(controller);
/*  26: 40 */     if (controller != null) {
/*  27: 41 */       setId(NIDMapper.getAndroidIdFor(controller.getId()));
/*  28:    */     } else {
/*  29: 43 */       setId(NIDMapper.getNextId());
/*  30:    */     }
/*  31:    */   }
/*  32:    */   
/*  33:    */   public String getCId()
/*  34:    */   {
/*  35: 48 */     return this.cid;
/*  36:    */   }
/*  37:    */   
/*  38:    */   public void setCId(String cid)
/*  39:    */   {
/*  40: 52 */     this.cid = cid;
/*  41:    */   }
/*  42:    */   
/*  43:    */   public String getMenuLabel()
/*  44:    */   {
/*  45: 56 */     return this.menuLabel;
/*  46:    */   }
/*  47:    */   
/*  48:    */   public void setMenuLabel(String menuLabel)
/*  49:    */   {
/*  50: 60 */     this.menuLabel = menuLabel;
/*  51:    */   }
/*  52:    */   
/*  53:    */   public String getTargetId()
/*  54:    */   {
/*  55: 64 */     return this.targetid;
/*  56:    */   }
/*  57:    */   
/*  58:    */   public void setTargetId(String targetid)
/*  59:    */   {
/*  60: 68 */     this.targetid = targetid;
/*  61:    */   }
/*  62:    */   
/*  63:    */   public Object getValue()
/*  64:    */   {
/*  65: 72 */     return this.value;
/*  66:    */   }
/*  67:    */   
/*  68:    */   public void setValue(Object value)
/*  69:    */   {
/*  70: 76 */     this.value = value;
/*  71:    */   }
/*  72:    */   
/*  73:    */   public void init() {}
/*  74:    */   
/*  75:    */   public void addChildUIComponent(UIComponent child)
/*  76:    */   {
/*  77: 84 */     this.children.add(child);
/*  78:    */   }
/*  79:    */   
/*  80:    */   public boolean canContainChildren()
/*  81:    */   {
/*  82: 88 */     return true;
/*  83:    */   }
/*  84:    */   
/*  85:    */   public Enumeration getChildren()
/*  86:    */   {
/*  87: 92 */     return this.children.elements();
/*  88:    */   }
/*  89:    */   
/*  90:    */   public Vector getChildrenAsVector()
/*  91:    */   {
/*  92: 96 */     return this.children;
/*  93:    */   }
/*  94:    */   
/*  95:    */   public AbstractMobileControl getController()
/*  96:    */   {
/*  97:100 */     return this.controller;
/*  98:    */   }
/*  99:    */   
/* 100:    */   public void setController(AbstractMobileControl controller)
/* 101:    */   {
/* 102:104 */     this.controller = controller;
/* 103:    */   }
/* 104:    */   
/* 105:    */   public Object getConstraints()
/* 106:    */   {
/* 107:108 */     return null;
/* 108:    */   }
/* 109:    */   
/* 110:    */   public void setConstraints(Object contstraints) {}
/* 111:    */   
/* 112:    */   public void removeAllItems()
/* 113:    */   {
/* 114:116 */     this.children.clear();
/* 115:    */   }
/* 116:    */   
/* 117:    */   public void setControlNodeData(Vector controlNodeData)
/* 118:    */   {
/* 119:120 */     this.controlNodeData = controlNodeData;
/* 120:    */   }
/* 121:    */   
/* 122:    */   public Vector getControlNodeData()
/* 123:    */   {
/* 124:124 */     return this.controlNodeData;
/* 125:    */   }
/* 126:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.components.NMenu
 * JD-Core Version:    0.7.0.1
 */