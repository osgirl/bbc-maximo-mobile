/*  1:   */ package com.mro.mobile.ui.res.widgets.android;
/*  2:   */ 
/*  3:   */ import android.view.View;
/*  4:   */ import android.widget.LinearLayout.LayoutParams;
/*  5:   */ import com.mro.mobile.ui.res.controls.ToolBarContainerControl;
/*  6:   */ import com.mro.mobile.ui.res.widgets.android.components.NToolBar;
/*  7:   */ import com.mro.mobile.ui.res.widgets.def.ToolBarContainerWidget;
/*  8:   */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  9:   */ 
/* 10:   */ public class ADToolBarContainerWidgetImpl
/* 11:   */   extends ADAbstractWidgetImpl
/* 12:   */   implements ToolBarContainerWidget
/* 13:   */ {
/* 14:28 */   protected NToolBar tb = null;
/* 15:   */   
/* 16:   */   public void createToolBarContainer()
/* 17:   */   {
/* 18:35 */     this.tb = NToolBar.createByInflate(getToolbarContainerControl(), AndroidEnv.getCurrentActivity(), 0);
/* 19:   */     
/* 20:37 */     LinearLayout.LayoutParams comp = new LinearLayout.LayoutParams(-1, -1);
/* 21:38 */     comp.setMargins(0, 0, 0, 0);
/* 22:39 */     comp.gravity = 119;
/* 23:40 */     this.tb.setConstraints(comp);
/* 24:   */   }
/* 25:   */   
/* 26:   */   protected void setController(ToolBarContainerControl controller)
/* 27:   */   {
/* 28:44 */     super.setController(controller);
/* 29:   */   }
/* 30:   */   
/* 31:   */   protected ToolBarContainerControl getToolbarContainerControl()
/* 32:   */   {
/* 33:48 */     return (ToolBarContainerControl)getController();
/* 34:   */   }
/* 35:   */   
/* 36:   */   protected void setGravity(int gravity)
/* 37:   */   {
/* 38:52 */     this.tb.setGravity(gravity);
/* 39:   */   }
/* 40:   */   
/* 41:   */   public void setId(String id)
/* 42:   */   {
/* 43:58 */     this.tb.setCId(id);
/* 44:   */   }
/* 45:   */   
/* 46:   */   public void setBgImage(String bgImage)
/* 47:   */   {
/* 48:64 */     this.tb.setBgImage(bgImage);
/* 49:   */   }
/* 50:   */   
/* 51:   */   protected void setBackColor(int col)
/* 52:   */   {
/* 53:69 */     this.tb.setBackgroundColor(col);
/* 54:   */   }
/* 55:   */   
/* 56:   */   public void setLayout(int toolBarContentsSize)
/* 57:   */   {
/* 58:75 */     this.tb.setOrientation(0);
/* 59:   */   }
/* 60:   */   
/* 61:   */   public void addComponent(UIComponent comp)
/* 62:   */   {
/* 63:81 */     comp.setConstraints(this.tb.getToolBarConstraints());
/* 64:82 */     this.tb.addView((View)comp);
/* 65:   */   }
/* 66:   */   
/* 67:   */   public void addComponent(UIComponent comp, String direction)
/* 68:   */   {
/* 69:88 */     comp.setConstraints("right".equals(direction) ? this.tb.getRightToolBarConstraints() : this.tb.getLeftToolBarConstraints());
/* 70:89 */     this.tb.addView((View)comp);
/* 71:   */   }
/* 72:   */   
/* 73:   */   public UIComponent[] resolveToolBarContainerComponents()
/* 74:   */   {
/* 75:95 */     return new UIComponent[] { this.tb };
/* 76:   */   }
/* 77:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.ADToolBarContainerWidgetImpl
 * JD-Core Version:    0.7.0.1
 */