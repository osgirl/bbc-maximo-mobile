package com.mro.mobile.ui.res.widgets.def;

import com.mro.mobile.MobileApplicationException;
import com.mro.mobile.ui.res.controls.AbstractMobileControl;

public abstract interface LinkWidget
  extends AbstractWidget
{
  public abstract void createLinkField(String paramString, AbstractMobileControl paramAbstractMobileControl);
  
  public abstract UIComponent addLinkLine(UIComponent paramUIComponent);
  
  public abstract UIComponent[] resolveLinkComponents()
    throws MobileApplicationException;
  
  public abstract void setController(AbstractMobileControl paramAbstractMobileControl);
  
  public abstract void setControlID(String paramString);
  
  public abstract void setDisplayAttribute(String paramString);
  
  public abstract void setDisplayEvent(String paramString);
  
  public abstract void setDataAttribute(String paramString);
  
  public abstract void setDisplayCount(boolean paramBoolean);
  
  public abstract Object getLinkField();
  
  public abstract Object getLinkValue();
  
  public abstract void refreshLink(String paramString);
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.def.LinkWidget
 * JD-Core Version:    0.7.0.1
 */