/*   1:    */ package com.mro.mobile.ui.res.widgets.android.components.table;
/*   2:    */ 
/*   3:    */ import android.content.Context;
/*   4:    */ import android.text.TextUtils.TruncateAt;
/*   5:    */ import android.util.AttributeSet;
/*   6:    */ import android.view.View;
/*   7:    */ import android.view.View.OnClickListener;
/*   8:    */ import android.widget.LinearLayout;
/*   9:    */ import android.widget.TextView;
/*  10:    */ import com.ibm.tivoli.maximo.mobile.android.util.UIUtil;
/*  11:    */ import com.ibm.tivoli.maximo.mobile.resources.R.id;
/*  12:    */ import com.ibm.tivoli.maximo.mobile.resources.R.layout;
/*  13:    */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*  14:    */ import com.mro.mobile.ui.res.widgets.android.components.EmsResolver;
/*  15:    */ import com.mro.mobile.ui.res.widgets.android.components.NImage;
/*  16:    */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  17:    */ import java.util.Enumeration;
/*  18:    */ 
/*  19:    */ public class NTableCellHeader
/*  20:    */   extends LinearLayout
/*  21:    */   implements UIComponent
/*  22:    */ {
/*  23: 34 */   private static final int DEFAULT_XML_LAYOUT = UIUtil.getResourceId(R.layout.class, "ntablecellheader");
/*  24:    */   private AbstractMobileControl controller;
/*  25:    */   private Object constraints;
/*  26:    */   private String cid;
/*  27:    */   private TextView headerText;
/*  28: 39 */   private EmsResolver emsResolver = null;
/*  29:    */   
/*  30:    */   public NTableCellHeader(Context context)
/*  31:    */   {
/*  32: 42 */     this(context, null);
/*  33:    */   }
/*  34:    */   
/*  35:    */   public NTableCellHeader(Context context, AttributeSet attrs)
/*  36:    */   {
/*  37: 46 */     super(context, attrs);
/*  38:    */   }
/*  39:    */   
/*  40:    */   public static NTableCellHeader createByInflate(AbstractMobileControl control, Context context, int column, String text, NImage sortImage, boolean sortable)
/*  41:    */   {
/*  42: 50 */     return createByInflate(DEFAULT_XML_LAYOUT, control, context, column, text, sortImage, sortable);
/*  43:    */   }
/*  44:    */   
/*  45:    */   public static NTableCellHeader createByInflate(int layoutId, AbstractMobileControl control, Context context, int column, String text, NImage sortImage, boolean sortable)
/*  46:    */   {
/*  47: 55 */     NTableCellHeader cell = (NTableCellHeader)View.inflate(context, layoutId, null);
/*  48: 56 */     cell.postInstance(control, column, text, sortImage, sortable);
/*  49: 57 */     return cell;
/*  50:    */   }
/*  51:    */   
/*  52:    */   protected void postInstance(AbstractMobileControl control, final int column, String text, NImage sortImage, boolean sortable)
/*  53:    */   {
/*  54: 61 */     this.controller = control;
/*  55: 62 */     if ((text != null) && (text.length() == 0))
/*  56:    */     {
/*  57: 63 */       text = "   ";
/*  58: 64 */       sortable = false;
/*  59:    */     }
/*  60: 66 */     this.headerText = ((TextView)findViewById(UIUtil.getResourceId(R.id.class, "cellHeaderText")));
/*  61:    */     
/*  62:    */ 
/*  63: 69 */     this.headerText.setSingleLine(true);
/*  64: 70 */     this.headerText.setEllipsize(TextUtils.TruncateAt.END);
/*  65:    */     
/*  66: 72 */     this.headerText.setText(text);
/*  67: 73 */     if (sortable)
/*  68:    */     {
/*  69: 74 */       UIUtil.bold(this.headerText);
/*  70: 75 */       setOnClickListener(new View.OnClickListener()
/*  71:    */       {
/*  72:    */         public void onClick(View v)
/*  73:    */         {
/*  74: 78 */           NTableCellHeader.this.getController().handleEvent("sort", null, Integer.valueOf(column));
/*  75:    */         }
/*  76:    */       });
/*  77:    */     }
/*  78: 82 */     if (sortImage != null) {
/*  79: 83 */       addView(sortImage);
/*  80:    */     }
/*  81:    */   }
/*  82:    */   
/*  83:    */   public void setCId(String cid)
/*  84:    */   {
/*  85: 89 */     this.cid = cid;
/*  86:    */   }
/*  87:    */   
/*  88:    */   public String getCId()
/*  89:    */   {
/*  90: 94 */     return this.cid;
/*  91:    */   }
/*  92:    */   
/*  93:    */   public void init() {}
/*  94:    */   
/*  95:    */   public void addChildUIComponent(UIComponent child) {}
/*  96:    */   
/*  97:    */   public boolean canContainChildren()
/*  98:    */   {
/*  99:107 */     return false;
/* 100:    */   }
/* 101:    */   
/* 102:    */   public Enumeration getChildren()
/* 103:    */   {
/* 104:112 */     return null;
/* 105:    */   }
/* 106:    */   
/* 107:    */   public AbstractMobileControl getController()
/* 108:    */   {
/* 109:117 */     return this.controller;
/* 110:    */   }
/* 111:    */   
/* 112:    */   public void setController(AbstractMobileControl controller)
/* 113:    */   {
/* 114:122 */     this.controller = controller;
/* 115:    */   }
/* 116:    */   
/* 117:    */   public Object getConstraints()
/* 118:    */   {
/* 119:127 */     return this.constraints;
/* 120:    */   }
/* 121:    */   
/* 122:    */   public void setConstraints(Object contstraints)
/* 123:    */   {
/* 124:132 */     this.constraints = contstraints;
/* 125:    */   }
/* 126:    */   
/* 127:    */   public void setEmsResolver(EmsResolver resolver)
/* 128:    */   {
/* 129:136 */     this.emsResolver = resolver;
/* 130:    */   }
/* 131:    */   
/* 132:    */   protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec)
/* 133:    */   {
/* 134:141 */     if (this.emsResolver != null)
/* 135:    */     {
/* 136:142 */       int ems = this.emsResolver.getEms();
/* 137:143 */       if (ems >= 0) {
/* 138:144 */         this.headerText.setEms(ems);
/* 139:    */       }
/* 140:    */     }
/* 141:147 */     super.onMeasure(widthMeasureSpec, heightMeasureSpec);
/* 142:    */   }
/* 143:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.components.table.NTableCellHeader
 * JD-Core Version:    0.7.0.1
 */