package com.mro.mobile.ui.res.widgets.def;

import com.mro.mobile.MobileApplicationException;
import com.mro.mobile.ui.res.ControlData;
import com.mro.mobile.ui.res.controls.utils.ControlStyle;

public abstract interface TableWidget
  extends AbstractWidget
{
  public abstract void setupTableModelAndPopulateIntoTable(int paramInt)
    throws MobileApplicationException;
  
  public abstract void createTable(String paramString, int paramInt)
    throws MobileApplicationException;
  
  public abstract void setEvent(String paramString);
  
  public abstract void setValue(String paramString);
  
  public abstract void setDataBeanName(String paramString);
  
  public abstract void setMobileMboName(String paramString);
  
  public abstract void setCurrrentModelBeanFirstRow(int paramInt);
  
  public abstract void setTableCaption(int paramInt, Object paramObject);
  
  public abstract void setTableCaption(int paramInt, String paramString, boolean paramBoolean1, boolean paramBoolean2);
  
  public abstract void updateTableCaption(int paramInt, String paramString, boolean paramBoolean1, boolean paramBoolean2);
  
  public abstract void setTableColWidth(int paramInt1, int paramInt2);
  
  public abstract void setTableRowHeight(int paramInt1, int paramInt2);
  
  public abstract int getTablePaddingLeft();
  
  public abstract int getTablePaddingRight();
  
  public abstract int getTextWidth();
  
  public abstract void setTrackColSizing(boolean paramBoolean);
  
  public abstract int getCurrentColumn();
  
  public abstract int getTableColumnWidth(int paramInt);
  
  public abstract boolean performHorizontalMove(int paramInt);
  
  public abstract boolean performVerticalMove(int paramInt);
  
  public abstract boolean isToolbarComponent(UIComponent paramUIComponent);
  
  public abstract boolean isPanelComponent(UIComponent paramUIComponent);
  
  public abstract void setStyleIntoPanel(UIComponent paramUIComponent, ControlStyle paramControlStyle);
  
  public abstract void setSortImage(int paramInt);
  
  public abstract boolean isComponentNotVisible(UIComponent paramUIComponent);
  
  public abstract void createTableModel(int paramInt1, int paramInt2);
  
  public abstract void removeNotNeededTableModelRows();
  
  public abstract void putComponentToTableModel(int paramInt1, int paramInt2, UIComponent paramUIComponent);
  
  public abstract void putLabelToTableModel(int paramInt1, int paramInt2, String paramString, ControlStyle paramControlStyle);
  
  public abstract void putCheckboxToTableModel(int paramInt1, int paramInt2, boolean paramBoolean, String paramString);
  
  public abstract UIComponent[] resolveTableComponents();
  
  public abstract Object getModel();
  
  public abstract void cleanHeaders(boolean paramBoolean);
  
  public abstract int calculateColWidthForControlData(ControlData paramControlData, int paramInt1, String paramString1, String paramString2, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10)
    throws MobileApplicationException;
  
  public abstract int calculateLastColumnWidth(int paramInt1, int paramInt2, int paramInt3);
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.def.TableWidget
 * JD-Core Version:    0.7.0.1
 */