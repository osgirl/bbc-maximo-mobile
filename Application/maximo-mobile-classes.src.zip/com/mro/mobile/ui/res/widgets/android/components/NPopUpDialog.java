/*  1:   */ package com.mro.mobile.ui.res.widgets.android.components;
/*  2:   */ 
/*  3:   */ import android.app.Dialog;
/*  4:   */ import android.content.Context;
/*  5:   */ import android.graphics.drawable.ColorDrawable;
/*  6:   */ import android.view.LayoutInflater;
/*  7:   */ import android.view.View;
/*  8:   */ import android.view.Window;
/*  9:   */ import android.widget.TextView;
/* 10:   */ import com.ibm.tivoli.maximo.mobile.android.util.UIUtil;
/* 11:   */ import com.ibm.tivoli.maximo.mobile.resources.R.drawable;
/* 12:   */ import com.ibm.tivoli.maximo.mobile.resources.R.id;
/* 13:   */ import com.ibm.tivoli.maximo.mobile.resources.R.layout;
/* 14:   */ import com.mro.mobile.ProgressWindow;
/* 15:   */ import com.mro.mobile.ui.res.android.DefaultBackButtonListener;
/* 16:   */ 
/* 17:   */ public class NPopUpDialog
/* 18:   */   extends Dialog
/* 19:   */   implements ProgressWindow
/* 20:   */ {
/* 21:   */   private Thread background;
/* 22:34 */   private TextView text = null;
/* 23:   */   
/* 24:   */   public NPopUpDialog(Context context)
/* 25:   */   {
/* 26:37 */     this(context, true);
/* 27:   */   }
/* 28:   */   
/* 29:   */   public NPopUpDialog(Context context, boolean hideTitle)
/* 30:   */   {
/* 31:41 */     super(context);
/* 32:43 */     if (hideTitle) {
/* 33:44 */       requestWindowFeature(1);
/* 34:   */     }
/* 35:46 */     getWindow().setBackgroundDrawable(new ColorDrawable(0));
/* 36:   */     
/* 37:48 */     LayoutInflater inflater = (LayoutInflater)context.getSystemService("layout_inflater");
/* 38:49 */     View layout = inflater.inflate(UIUtil.getResourceId(R.layout.class, "npopupdialog"), null);
/* 39:   */     
/* 40:51 */     setContentView(layout);
/* 41:   */     
/* 42:   */ 
/* 43:   */ 
/* 44:55 */     layout.setBackgroundResource(UIUtil.getResourceId(R.drawable.class, "custom_dialog_background"));
/* 45:   */     
/* 46:57 */     this.text = ((TextView)layout.findViewById(UIUtil.getResourceId(R.id.class, "text")));
/* 47:   */     
/* 48:59 */     setCanceledOnTouchOutside(false);
/* 49:60 */     setOnKeyListener(DefaultBackButtonListener.getInstance());
/* 50:   */   }
/* 51:   */   
/* 52:   */   public void closeWindow()
/* 53:   */   {
/* 54:65 */     super.dismiss();
/* 55:   */   }
/* 56:   */   
/* 57:   */   public void setBackgroundThread(Thread thread)
/* 58:   */   {
/* 59:70 */     this.background = thread;
/* 60:   */   }
/* 61:   */   
/* 62:   */   public Thread getBackgroundThread()
/* 63:   */   {
/* 64:75 */     return this.background;
/* 65:   */   }
/* 66:   */   
/* 67:   */   public void setMessage(String msg)
/* 68:   */   {
/* 69:79 */     this.text.setText(msg);
/* 70:   */   }
/* 71:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.components.NPopUpDialog
 * JD-Core Version:    0.7.0.1
 */