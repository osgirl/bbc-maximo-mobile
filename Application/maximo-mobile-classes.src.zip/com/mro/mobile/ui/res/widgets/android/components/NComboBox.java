/*   1:    */ package com.mro.mobile.ui.res.widgets.android.components;
/*   2:    */ 
/*   3:    */ import android.content.Context;
/*   4:    */ import android.util.AttributeSet;
/*   5:    */ import android.view.View;
/*   6:    */ import android.view.ViewGroup.LayoutParams;
/*   7:    */ import android.widget.AdapterView;
/*   8:    */ import android.widget.AdapterView.OnItemSelectedListener;
/*   9:    */ import android.widget.ArrayAdapter;
/*  10:    */ import android.widget.Spinner;
/*  11:    */ import com.ibm.tivoli.maximo.mobile.android.util.UIUtil;
/*  12:    */ import com.ibm.tivoli.maximo.mobile.resources.R.layout;
/*  13:    */ import com.mro.mobile.ui.event.UIEvent;
/*  14:    */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*  15:    */ import com.mro.mobile.ui.res.controls.InputControl;
/*  16:    */ import com.mro.mobile.ui.res.widgets.android.AndroidEnv;
/*  17:    */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  18:    */ import java.util.ArrayList;
/*  19:    */ import java.util.Enumeration;
/*  20:    */ import java.util.List;
/*  21:    */ 
/*  22:    */ public class NComboBox
/*  23:    */   extends Spinner
/*  24:    */   implements UIComponent
/*  25:    */ {
/*  26: 25 */   private String mobileMboAttributeName = null;
/*  27: 26 */   private String dataBeanName = null;
/*  28: 27 */   private String event = null;
/*  29: 28 */   private String cid = null;
/*  30: 29 */   private AbstractMobileControl controller = null;
/*  31: 30 */   private Object constraints = null;
/*  32: 31 */   private boolean cancelSetValue = true;
/*  33: 32 */   private List<CharSequence> comboValueList = new ArrayList();
/*  34: 33 */   private int currentPos = -1;
/*  35: 35 */   private static final int DEFAULT_XML_LAYOUT = UIUtil.getResourceId(R.layout.class, "ncombobox");
/*  36:    */   
/*  37:    */   public NComboBox(Context context)
/*  38:    */   {
/*  39: 38 */     super(context);
/*  40:    */   }
/*  41:    */   
/*  42:    */   public NComboBox(Context context, AttributeSet attrs)
/*  43:    */   {
/*  44: 42 */     super(context, attrs);
/*  45:    */   }
/*  46:    */   
/*  47:    */   public NComboBox(Context context, AttributeSet attrs, int defStyle)
/*  48:    */   {
/*  49: 46 */     super(context, attrs, defStyle);
/*  50:    */   }
/*  51:    */   
/*  52:    */   public static NComboBox createByInflate(AbstractMobileControl control, Context context)
/*  53:    */   {
/*  54: 51 */     return createByInflate(DEFAULT_XML_LAYOUT, control, context);
/*  55:    */   }
/*  56:    */   
/*  57:    */   public static NComboBox createByInflate(int layoutId, AbstractMobileControl control, Context context)
/*  58:    */   {
/*  59: 55 */     NComboBox combobox = (NComboBox)View.inflate(context, layoutId, null);
/*  60: 56 */     combobox.postInstance(control);
/*  61: 57 */     return combobox;
/*  62:    */   }
/*  63:    */   
/*  64:    */   private void postInstance(AbstractMobileControl control)
/*  65:    */   {
/*  66: 62 */     setController(control);
/*  67: 63 */     if (control != null) {
/*  68: 64 */       setId(NIDMapper.getAndroidIdFor(control.getId()));
/*  69:    */     } else {
/*  70: 66 */       setId(NIDMapper.getNextId());
/*  71:    */     }
/*  72: 68 */     init();
/*  73:    */   }
/*  74:    */   
/*  75:    */   public void setMobileMboAttributeName(String dataBeanAttributeName)
/*  76:    */   {
/*  77: 72 */     this.mobileMboAttributeName = dataBeanAttributeName;
/*  78:    */   }
/*  79:    */   
/*  80:    */   public void bindStateChangeListener()
/*  81:    */   {
/*  82: 76 */     setOnItemSelectedListener(new AdapterView.OnItemSelectedListener()
/*  83:    */     {
/*  84:    */       public void onItemSelected(AdapterView<?> parent, View view, int pos, long id)
/*  85:    */       {
/*  86: 78 */         if (pos != NComboBox.this.currentPos)
/*  87:    */         {
/*  88: 79 */           NComboBox.this.currentPos = pos;
/*  89: 80 */           if (!NComboBox.this.cancelSetValue)
/*  90:    */           {
/*  91: 81 */             if ((NComboBox.this.getController().isAttributeSet("dataattribute")) && 
/*  92: 82 */               (!((InputControl)NComboBox.this.getController()).isReadOnly()))
/*  93:    */             {
/*  94: 83 */               String eventName = NComboBox.this.event == null ? "setvalue" : NComboBox.this.event;
/*  95: 84 */               UIEvent uievent = new UIEvent(NComboBox.this.getController(), eventName, null, pos - 1 + "");
/*  96: 85 */               NComboBox.this.getController().handleEvent(uievent);
/*  97:    */             }
/*  98: 88 */             NComboBox.this.cancelSetValue = false;
/*  99:    */           }
/* 100:    */         }
/* 101:    */       }
/* 102:    */       
/* 103:    */       public void onNothingSelected(AdapterView<?> parent) {}
/* 104:    */     });
/* 105:    */   }
/* 106:    */   
/* 107:    */   public void addChildUIComponent(UIComponent child) {}
/* 108:    */   
/* 109:    */   public boolean canContainChildren()
/* 110:    */   {
/* 111:102 */     return false;
/* 112:    */   }
/* 113:    */   
/* 114:    */   public Enumeration getChildren()
/* 115:    */   {
/* 116:106 */     return null;
/* 117:    */   }
/* 118:    */   
/* 119:    */   public Object getConstraints()
/* 120:    */   {
/* 121:115 */     return this.constraints;
/* 122:    */   }
/* 123:    */   
/* 124:    */   public void setConstraints(Object constraints)
/* 125:    */   {
/* 126:126 */     this.constraints = constraints;
/* 127:    */   }
/* 128:    */   
/* 129:    */   public AbstractMobileControl getController()
/* 130:    */   {
/* 131:133 */     return this.controller;
/* 132:    */   }
/* 133:    */   
/* 134:    */   public void setController(AbstractMobileControl controller)
/* 135:    */   {
/* 136:141 */     this.controller = controller;
/* 137:    */   }
/* 138:    */   
/* 139:    */   public String getDataBeanName()
/* 140:    */   {
/* 141:148 */     return this.dataBeanName;
/* 142:    */   }
/* 143:    */   
/* 144:    */   public void setDataBeanName(String dataBeanName)
/* 145:    */   {
/* 146:156 */     this.dataBeanName = dataBeanName;
/* 147:    */   }
/* 148:    */   
/* 149:    */   public String getEvent()
/* 150:    */   {
/* 151:163 */     return this.event;
/* 152:    */   }
/* 153:    */   
/* 154:    */   public void setEvent(String event)
/* 155:    */   {
/* 156:171 */     this.event = event;
/* 157:    */   }
/* 158:    */   
/* 159:    */   public String getCId()
/* 160:    */   {
/* 161:178 */     return this.cid;
/* 162:    */   }
/* 163:    */   
/* 164:    */   public void setCId(String cid)
/* 165:    */   {
/* 166:186 */     this.cid = cid;
/* 167:    */   }
/* 168:    */   
/* 169:    */   public String getMobileMboAttributeName()
/* 170:    */   {
/* 171:193 */     return this.mobileMboAttributeName;
/* 172:    */   }
/* 173:    */   
/* 174:    */   public void addItem(Object data)
/* 175:    */   {
/* 176:197 */     this.comboValueList.add(((NLabel)data).getText());
/* 177:    */   }
/* 178:    */   
/* 179:    */   public void addItemAt(Object data, int index)
/* 180:    */   {
/* 181:201 */     this.comboValueList.add(index, ((NLabel)data).getText());
/* 182:    */   }
/* 183:    */   
/* 184:    */   public void applyDataAdapter()
/* 185:    */   {
/* 186:205 */     ArrayAdapter<CharSequence> aa = new ArrayAdapter(AndroidEnv.getCurrentActivity(), 17367048, this.comboValueList.toArray(new CharSequence[0]));
/* 187:    */     
/* 188:207 */     aa.setDropDownViewResource(UIUtil.getResourceId(R.layout.class, "ncombobox_item"));
/* 189:208 */     setAdapter(aa);
/* 190:    */   }
/* 191:    */   
/* 192:    */   public void clear()
/* 193:    */   {
/* 194:212 */     this.comboValueList.clear();
/* 195:    */   }
/* 196:    */   
/* 197:    */   public int getSelectedIndex()
/* 198:    */   {
/* 199:216 */     return getSelectedItemPosition();
/* 200:    */   }
/* 201:    */   
/* 202:    */   public Object getSelectedItem()
/* 203:    */   {
/* 204:220 */     return getItemAtPosition(getSelectedIndex());
/* 205:    */   }
/* 206:    */   
/* 207:    */   public void setSelectedItem(int index)
/* 208:    */   {
/* 209:224 */     this.cancelSetValue = true;
/* 210:225 */     setSelection(index, false);
/* 211:226 */     this.cancelSetValue = false;
/* 212:    */   }
/* 213:    */   
/* 214:    */   public boolean canHaveFocus()
/* 215:    */   {
/* 216:230 */     return false;
/* 217:    */   }
/* 218:    */   
/* 219:    */   public void init()
/* 220:    */   {
/* 221:235 */     ViewGroup.LayoutParams params = new ViewGroup.LayoutParams(-1, -2);
/* 222:236 */     setLayoutParams(params);
/* 223:    */   }
/* 224:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.components.NComboBox
 * JD-Core Version:    0.7.0.1
 */