package com.mro.mobile.ui.res.widgets.def;

import com.mro.mobile.MobileApplicationException;
import com.mro.mobile.ui.res.controls.utils.ControlStyle;

public abstract interface ReasonForChangeWidget
  extends InputWidget
{
  public abstract void createReasonForChange(String paramString);
  
  public abstract void createChangeReasonTextBox(int paramInt);
  
  public abstract void setChangeReasonTextBoxFocus();
  
  public abstract void addItemToReasonDropdown(String paramString, ControlStyle paramControlStyle);
  
  public abstract String getControlValue();
  
  public abstract UIComponent[] resolveChangeReasonDropDownComponents(String paramString)
    throws MobileApplicationException;
  
  public abstract UIComponent[] resolveReasonForChangeComponents()
    throws MobileApplicationException;
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.def.ReasonForChangeWidget
 * JD-Core Version:    0.7.0.1
 */