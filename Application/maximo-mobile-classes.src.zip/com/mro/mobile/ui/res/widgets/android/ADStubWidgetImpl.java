package com.mro.mobile.ui.res.widgets.android;

public class ADStubWidgetImpl
  extends ADAbstractWidgetImpl
{}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.ADStubWidgetImpl
 * JD-Core Version:    0.7.0.1
 */