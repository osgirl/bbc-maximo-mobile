/*  1:   */ package com.mro.mobile.ui.res.widgets.android;
/*  2:   */ 
/*  3:   */ import android.view.View;
/*  4:   */ import android.widget.LinearLayout.LayoutParams;
/*  5:   */ import com.mro.mobile.ui.res.controls.ToolBarLeftControl;
/*  6:   */ import com.mro.mobile.ui.res.widgets.android.components.NToolBar;
/*  7:   */ import com.mro.mobile.ui.res.widgets.def.ToolBarLeftWidget;
/*  8:   */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  9:   */ 
/* 10:   */ public class ADToolBarLeftWidgetImpl
/* 11:   */   extends ADToolBarContainerWidgetImpl
/* 12:   */   implements ToolBarLeftWidget
/* 13:   */ {
/* 14:28 */   private NToolBar childContainer = null;
/* 15:   */   
/* 16:   */   protected void setController(ToolBarLeftControl controller)
/* 17:   */   {
/* 18:35 */     super.setController(controller);
/* 19:   */   }
/* 20:   */   
/* 21:   */   protected ToolBarLeftControl getToolBarLeftControl()
/* 22:   */   {
/* 23:39 */     return (ToolBarLeftControl)getController();
/* 24:   */   }
/* 25:   */   
/* 26:   */   public void createToolBarContainer()
/* 27:   */   {
/* 28:43 */     super.createToolBarContainer();
/* 29:   */     
/* 30:45 */     createChildContainer();
/* 31:   */     
/* 32:   */ 
/* 33:48 */     this.tb.setGravity(19);
/* 34:49 */     this.tb.addView(this.childContainer);
/* 35:   */   }
/* 36:   */   
/* 37:   */   private void createChildContainer()
/* 38:   */   {
/* 39:53 */     this.childContainer = NToolBar.createByInflate(getToolbarContainerControl(), AndroidEnv.getCurrentActivity(), 0);
/* 40:54 */     this.childContainer.setConstraints(new LinearLayout.LayoutParams(-2, -1));
/* 41:55 */     this.childContainer.setOpaque(false);
/* 42:   */   }
/* 43:   */   
/* 44:   */   public void addComponent(UIComponent comp)
/* 45:   */   {
/* 46:61 */     comp.setConstraints(this.childContainer.getLeftToolBarConstraints());
/* 47:62 */     this.childContainer.addView((View)comp);
/* 48:   */   }
/* 49:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.ADToolBarLeftWidgetImpl
 * JD-Core Version:    0.7.0.1
 */