package com.mro.mobile.ui.res.widgets.def;

import com.mro.mobile.MobileApplicationException;
import java.io.File;

public abstract interface FileDialogueWidget
  extends AbstractWidget
{
  public abstract UIComponent[] composePanel(String paramString)
    throws MobileApplicationException;
  
  public abstract void handleTreeSelect(Object paramObject);
  
  public abstract void handleScan4Children(Object paramObject)
    throws MobileApplicationException;
  
  public abstract void setSelectedFile(File paramFile);
  
  public abstract File getSelectedFile();
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.def.FileDialogueWidget
 * JD-Core Version:    0.7.0.1
 */