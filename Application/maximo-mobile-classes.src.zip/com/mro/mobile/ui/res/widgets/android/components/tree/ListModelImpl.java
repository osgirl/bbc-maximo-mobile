/*   1:    */ package com.mro.mobile.ui.res.widgets.android.components.tree;
/*   2:    */ 
/*   3:    */ import android.content.Context;
/*   4:    */ import android.view.LayoutInflater;
/*   5:    */ import android.view.View;
/*   6:    */ import android.view.ViewGroup;
/*   7:    */ import android.widget.AdapterView;
/*   8:    */ import android.widget.LinearLayout;
/*   9:    */ import android.widget.TextView;
/*  10:    */ import com.ibm.tivoli.maximo.mobile.android.util.UIUtil;
/*  11:    */ import com.ibm.tivoli.maximo.mobile.resources.R.drawable;
/*  12:    */ import com.ibm.tivoli.maximo.mobile.resources.R.id;
/*  13:    */ import com.ibm.tivoli.maximo.mobile.resources.R.layout;
/*  14:    */ import com.mro.mobile.ui.event.UIEvent;
/*  15:    */ import com.mro.mobile.ui.res.controls.TreeControl;
/*  16:    */ import com.mro.mobile.ui.res.controls.utils.TreeNodeData;
/*  17:    */ import com.mro.mobile.ui.res.widgets.android.components.NPanel;
/*  18:    */ import java.util.ArrayList;
/*  19:    */ import java.util.HashMap;
/*  20:    */ import java.util.Map;
/*  21:    */ import java.util.Vector;
/*  22:    */ 
/*  23:    */ public class ListModelImpl
/*  24:    */   implements ListModel, TreeListener, TreeIconView.IconClickable
/*  25:    */ {
/*  26: 40 */   private static int ICON_EXAPNAD_RESID = UIUtil.getResourceId(R.drawable.class, "iconplussign");
/*  27: 41 */   private static int ICON_COLLAPSE_RESID = UIUtil.getResourceId(R.drawable.class, "iconminussign");
/*  28: 42 */   private static int ICON_NONE_RESID = UIUtil.getResourceId(R.drawable.class, "iconsquareblank");
/*  29:    */   private static final int DEFULT_DATALIST_CAPACITY = 390;
/*  30:    */   private Context context;
/*  31: 48 */   private TreeModel treeModel = null;
/*  32: 50 */   private NTreeListViewAdapter ntreeListAdapter = null;
/*  33: 52 */   private ArrayList<Item> datalist = new ArrayList(390);
/*  34: 54 */   private Map<String, Integer> iconmap = new HashMap();
/*  35:    */   
/*  36:    */   public ListModelImpl(Context context, TreeModel treeModel, NTreeListViewAdapter ntreeListAdapter)
/*  37:    */   {
/*  38: 57 */     this.context = context;
/*  39: 58 */     this.treeModel = treeModel;
/*  40: 59 */     this.ntreeListAdapter = ntreeListAdapter;
/*  41:    */     
/*  42: 61 */     init();
/*  43:    */   }
/*  44:    */   
/*  45:    */   private void init()
/*  46:    */   {
/*  47: 65 */     this.iconmap.put("EXPAND", Integer.valueOf(ICON_EXAPNAD_RESID));
/*  48: 66 */     this.iconmap.put("COLLAPSE", Integer.valueOf(ICON_COLLAPSE_RESID));
/*  49: 67 */     this.iconmap.put("NONE", Integer.valueOf(ICON_NONE_RESID));
/*  50:    */   }
/*  51:    */   
/*  52:    */   public int getCount()
/*  53:    */   {
/*  54: 72 */     return getDatalist().size();
/*  55:    */   }
/*  56:    */   
/*  57:    */   public Object getItem(int position)
/*  58:    */   {
/*  59: 77 */     return getDatalist().get(position);
/*  60:    */   }
/*  61:    */   
/*  62:    */   public long getItemId(int position)
/*  63:    */   {
/*  64: 82 */     return position;
/*  65:    */   }
/*  66:    */   
/*  67:    */   public View getView(int position, View convertView, ViewGroup parent)
/*  68:    */   {
/*  69: 87 */     if (convertView == null) {
/*  70: 88 */       convertView = newView(parent, UIUtil.getResourceId(R.layout.class, "ntreeitemlayout"));
/*  71:    */     }
/*  72: 92 */     Item item = (Item)getDatalist().get(position);
/*  73: 93 */     ItemDesc itemdesc = getTreeModel().getItemDesc(item);
/*  74: 94 */     TreeIconView iconView = (TreeIconView)convertView.findViewById(UIUtil.getResourceId(R.id.class, "ImageView01"));
/*  75: 95 */     LinearLayout baseDisplayView = (LinearLayout)convertView.findViewById(UIUtil.getResourceId(R.id.class, "treeChild"));
/*  76:    */     
/*  77:    */ 
/*  78: 98 */     baseDisplayView.removeAllViews();
/*  79:    */     
/*  80:    */ 
/*  81:101 */     updateIconData(iconView, position, ((Integer)this.iconmap.get(itemdesc.getAction())).intValue());
/*  82:    */     int indent;
/*  83:    */     int indent;
/*  84:105 */     if (position == 0)
/*  85:    */     {
/*  86:106 */       updateRootDisplayView(baseDisplayView, (String)item.getValue());
/*  87:107 */       indent = 0;
/*  88:    */     }
/*  89:    */     else
/*  90:    */     {
/*  91:110 */       TreeNodeData treeNodeData = (TreeNodeData)item.getValue();
/*  92:111 */       updateLineDisplayView(baseDisplayView, treeNodeData);
/*  93:112 */       indent = treeNodeData.getDepth();
/*  94:    */     }
/*  95:116 */     convertView.setPadding(indent * 50, 0, 0, 0);
/*  96:    */     
/*  97:118 */     dataChanged();
/*  98:    */     
/*  99:120 */     return convertView;
/* 100:    */   }
/* 101:    */   
/* 102:    */   private void updateIconData(TreeIconView iconView, int position, int imgResId)
/* 103:    */   {
/* 104:124 */     iconView.setLineIconViewListener(this);
/* 105:125 */     iconView.position = position;
/* 106:126 */     iconView.setImageResource(imgResId);
/* 107:    */   }
/* 108:    */   
/* 109:    */   private void updateRootDisplayView(LinearLayout rootDisplayView, String rootText)
/* 110:    */   {
/* 111:130 */     TextView reply = new TextView(this.context);
/* 112:    */     
/* 113:    */ 
/* 114:133 */     StringBuffer sb = new StringBuffer();
/* 115:134 */     for (int i = 0; i < 100; i++) {
/* 116:135 */       sb.append(" ");
/* 117:    */     }
/* 118:138 */     reply.setText(rootText + sb.toString());
/* 119:139 */     rootDisplayView.addView(reply);
/* 120:    */   }
/* 121:    */   
/* 122:    */   private void updateLineDisplayView(LinearLayout baseDisplayView, TreeNodeData treeNodeData)
/* 123:    */   {
/* 124:143 */     View displayPanel = (View)treeNodeData.getDisplayPanel();
/* 125:144 */     if (displayPanel.getParent() != null) {
/* 126:145 */       ((LinearLayout)displayPanel.getParent()).removeAllViews();
/* 127:    */     }
/* 128:152 */     View v1 = (View)((NPanel)displayPanel).getChildrenAsVector().get(0);
/* 129:153 */     if (v1.getParent() != null) {
/* 130:154 */       ((ViewGroup)v1.getParent()).removeAllViews();
/* 131:    */     }
/* 132:156 */     v1.setFocusable(false);
/* 133:157 */     baseDisplayView.addView(v1);
/* 134:    */     
/* 135:159 */     View v2 = (View)((NPanel)displayPanel).getChildrenAsVector().get(1);
/* 136:160 */     if (v2.getParent() != null) {
/* 137:161 */       ((ViewGroup)v2.getParent()).removeAllViews();
/* 138:    */     }
/* 139:163 */     baseDisplayView.addView(v2);
/* 140:    */   }
/* 141:    */   
/* 142:    */   private View newView(ViewGroup parent, int resId)
/* 143:    */   {
/* 144:167 */     LayoutInflater infalInflater = (LayoutInflater)this.context.getSystemService("layout_inflater");
/* 145:168 */     View v = infalInflater.inflate(resId, null, false);
/* 146:169 */     return v;
/* 147:    */   }
/* 148:    */   
/* 149:    */   public TreeModel getTreeModel()
/* 150:    */   {
/* 151:174 */     return this.treeModel;
/* 152:    */   }
/* 153:    */   
/* 154:    */   private ArrayList<Item> getDatalist()
/* 155:    */   {
/* 156:178 */     return this.datalist;
/* 157:    */   }
/* 158:    */   
/* 159:    */   public void dataChanged()
/* 160:    */   {
/* 161:182 */     this.ntreeListAdapter.notifyDataSetChanged();
/* 162:    */   }
/* 163:    */   
/* 164:    */   private void _onItemClick_(AdapterView<?> parent, View view, int position, long id)
/* 165:    */   {
/* 166:189 */     Item item = (Item)getDatalist().get(position);
/* 167:190 */     ItemDesc itemdesc = getTreeModel().getItemDesc(item);
/* 168:191 */     if (item == getTreeModel().getRoot())
/* 169:    */     {
/* 170:192 */       itemdesc.setAction("NONE");
/* 171:193 */       return;
/* 172:    */     }
/* 173:199 */     if (getnTree().hasChildren(item))
/* 174:    */     {
/* 175:200 */       getnTree().removeAllChildren(item);
/* 176:201 */       itemdesc.setAction("EXPAND");
/* 177:202 */       return;
/* 178:    */     }
/* 179:206 */     UIEvent uievent = new UIEvent(getController(), "scan4Children", null, item);
/* 180:207 */     getController().handleEvent(uievent);
/* 181:208 */     if (itemdesc.hasFoundKids()) {
/* 182:209 */       getTreeModel().getItemDesc(item).setAction("COLLAPSE");
/* 183:    */     } else {
/* 184:212 */       getTreeModel().getItemDesc(item).setAction("NONE");
/* 185:    */     }
/* 186:    */   }
/* 187:    */   
/* 188:    */   private NTree getnTree()
/* 189:    */   {
/* 190:217 */     return this.ntreeListAdapter.getnTree();
/* 191:    */   }
/* 192:    */   
/* 193:    */   private TreeControl getController()
/* 194:    */   {
/* 195:221 */     return (TreeControl)getnTree().getController();
/* 196:    */   }
/* 197:    */   
/* 198:    */   public void itemInserted(Item item)
/* 199:    */   {
/* 200:226 */     _itemInserted_(item);
/* 201:227 */     dataChanged();
/* 202:    */   }
/* 203:    */   
/* 204:    */   private void _itemInserted_(Item item)
/* 205:    */   {
/* 206:232 */     Item parentItem = getTreeModel().getParent(item);
/* 207:233 */     if (parentItem == null)
/* 208:    */     {
/* 209:234 */       getDatalist().clear();
/* 210:235 */       getDatalist().add(item);
/* 211:236 */       return;
/* 212:    */     }
/* 213:240 */     getTreeModel().getItemDesc(parentItem).setFoundKids(true);
/* 214:    */     
/* 215:    */ 
/* 216:243 */     int parentPos = getDatalist().indexOf(parentItem);
/* 217:244 */     if (parentPos == -1) {
/* 218:245 */       throw new RuntimeException("Parent Not Exisitng In DataList");
/* 219:    */     }
/* 220:248 */     int numOfHierarchyKids = getTreeModel().getHierarchyChildrenCount(parentItem);
/* 221:249 */     getDatalist().add(parentPos + numOfHierarchyKids, item);
/* 222:    */   }
/* 223:    */   
/* 224:    */   public void itemRemoved(Item item, int hierarchyKIds)
/* 225:    */   {
/* 226:254 */     _itemRemoved_(item, hierarchyKIds);
/* 227:255 */     dataChanged();
/* 228:    */   }
/* 229:    */   
/* 230:    */   private void _itemRemoved_(Item item, int hierarchyKIds)
/* 231:    */   {
/* 232:259 */     int itemPos = getDatalist().indexOf(item);
/* 233:260 */     if (itemPos == -1) {
/* 234:261 */       return;
/* 235:    */     }
/* 236:264 */     int numToRemove = hierarchyKIds + 1;
/* 237:265 */     for (int i = 0; i < numToRemove; i++) {
/* 238:266 */       getDatalist().remove(itemPos);
/* 239:    */     }
/* 240:    */   }
/* 241:    */   
/* 242:    */   public void itemModified(Item item) {}
/* 243:    */   
/* 244:    */   public void onItemClick(AdapterView<?> parent, View view, int position, long id)
/* 245:    */   {
/* 246:277 */     iconClicked(position, view);
/* 247:    */   }
/* 248:    */   
/* 249:    */   public void iconClicked(int position, View v)
/* 250:    */   {
/* 251:282 */     _onItemClick_(null, v, position, 0L);
/* 252:283 */     dataChanged();
/* 253:    */   }
/* 254:    */   
/* 255:    */   public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id)
/* 256:    */   {
/* 257:288 */     longClicked(parent, view, position, id);
/* 258:289 */     return true;
/* 259:    */   }
/* 260:    */   
/* 261:    */   private void longClicked(AdapterView<?> parent, View view, int position, long id)
/* 262:    */   {
/* 263:293 */     Item item = (Item)getDatalist().get(position);
/* 264:296 */     if (position == 0) {
/* 265:297 */       return;
/* 266:    */     }
/* 267:301 */     View displayPanel = (View)((TreeNodeData)item.getValue()).getDisplayPanel();
/* 268:302 */     View vImage = (View)((NPanel)displayPanel).getChildrenAsVector().get(0);
/* 269:303 */     vImage.performClick();
/* 270:    */   }
/* 271:    */   
/* 272:    */   public void itemSelection(Item item)
/* 273:    */   {
/* 274:307 */     if (getTreeModel().getRoot() == item) {
/* 275:308 */       return;
/* 276:    */     }
/* 277:310 */     UIEvent uievent = new UIEvent(getController(), "treeselect", null, item);
/* 278:311 */     getController().handleEvent(uievent);
/* 279:    */   }
/* 280:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.components.tree.ListModelImpl
 * JD-Core Version:    0.7.0.1
 */