/*  1:   */ package com.mro.mobile.ui.res.widgets.android;
/*  2:   */ 
/*  3:   */ import android.app.Activity;
/*  4:   */ import android.view.View;
/*  5:   */ import android.view.Window;
/*  6:   */ import com.mro.mobile.ui.res.widgets.def.PageGroupWidget;
/*  7:   */ 
/*  8:   */ public class ADPageGroupWidgetImpl
/*  9:   */   extends ADAbstractWidgetImpl
/* 10:   */   implements PageGroupWidget
/* 11:   */ {
/* 12:   */   public void requestFocus()
/* 13:   */   {
/* 14:25 */     AndroidEnv.getCurrentActivity().getWindow().getDecorView().requestFocus();
/* 15:   */   }
/* 16:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.ADPageGroupWidgetImpl
 * JD-Core Version:    0.7.0.1
 */