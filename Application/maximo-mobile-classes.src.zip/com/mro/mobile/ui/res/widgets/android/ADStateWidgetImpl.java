/*  1:   */ package com.mro.mobile.ui.res.widgets.android;
/*  2:   */ 
/*  3:   */ import android.view.View;
/*  4:   */ import android.widget.LinearLayout.LayoutParams;
/*  5:   */ import com.mro.mobile.ui.res.widgets.android.components.NPanel;
/*  6:   */ import com.mro.mobile.ui.res.widgets.def.StateWidget;
/*  7:   */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  8:   */ 
/*  9:   */ public class ADStateWidgetImpl
/* 10:   */   extends ADAbstractWidgetImpl
/* 11:   */   implements StateWidget
/* 12:   */ {
/* 13:12 */   private NPanel panel = null;
/* 14:   */   
/* 15:   */   public void createStatePanel()
/* 16:   */   {
/* 17:15 */     this.panel = NPanel.createByInflate(getController(), AndroidEnv.getCurrentActivity(), 0);
/* 18:16 */     this.panel.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
/* 19:17 */     this.panel.setOpaque(false);
/* 20:   */   }
/* 21:   */   
/* 22:   */   public void addToStatePanel(UIComponent component)
/* 23:   */   {
/* 24:21 */     if ((component instanceof View)) {
/* 25:22 */       this.panel.addView((View)component);
/* 26:   */     }
/* 27:   */   }
/* 28:   */   
/* 29:   */   public void removeAllFromStatePanel()
/* 30:   */   {
/* 31:27 */     this.panel.removeAllViews();
/* 32:   */   }
/* 33:   */   
/* 34:   */   public boolean isStateListener(UIComponent component)
/* 35:   */   {
/* 36:32 */     return false;
/* 37:   */   }
/* 38:   */   
/* 39:   */   public UIComponent[] resolveStateComponents()
/* 40:   */   {
/* 41:36 */     return new UIComponent[] { this.panel };
/* 42:   */   }
/* 43:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.ADStateWidgetImpl
 * JD-Core Version:    0.7.0.1
 */