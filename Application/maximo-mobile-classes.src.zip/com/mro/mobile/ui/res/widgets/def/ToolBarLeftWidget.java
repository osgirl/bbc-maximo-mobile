package com.mro.mobile.ui.res.widgets.def;

public abstract interface ToolBarLeftWidget
  extends ToolBarContainerWidget
{}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.def.ToolBarLeftWidget
 * JD-Core Version:    0.7.0.1
 */