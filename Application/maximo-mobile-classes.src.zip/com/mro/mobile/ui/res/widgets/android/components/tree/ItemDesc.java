/*  1:   */ package com.mro.mobile.ui.res.widgets.android.components.tree;
/*  2:   */ 
/*  3:   */ import java.util.Vector;
/*  4:   */ 
/*  5:   */ public class ItemDesc
/*  6:   */ {
/*  7:   */   public static final String EXPAND = "EXPAND";
/*  8:   */   public static final String COLLAPSE = "COLLAPSE";
/*  9:   */   public static final String NONE = "NONE";
/* 10:26 */   private String action = "EXPAND";
/* 11:28 */   private boolean foundKids = false;
/* 12:   */   protected Item self;
/* 13:   */   protected Item parent;
/* 14:   */   protected Vector children;
/* 15:   */   protected Tree tree;
/* 16:   */   
/* 17:   */   public ItemDesc(Item self, Item p, Tree tree)
/* 18:   */   {
/* 19:37 */     this.parent = p;
/* 20:38 */     this.tree = tree;
/* 21:39 */     this.self = self;
/* 22:   */   }
/* 23:   */   
/* 24:   */   public int getChildrenCount()
/* 25:   */   {
/* 26:43 */     return this.children == null ? 0 : this.children.size();
/* 27:   */   }
/* 28:   */   
/* 29:   */   public int getHierarchyChildrenCount()
/* 30:   */   {
/* 31:47 */     return calculateHierarchyChildren(this.self);
/* 32:   */   }
/* 33:   */   
/* 34:   */   private int calculateHierarchyChildren(Item item)
/* 35:   */   {
/* 36:51 */     int sum = 0;
/* 37:52 */     Vector kids = this.tree.getItemDesc(item).children;
/* 38:53 */     if (kids == null) {
/* 39:54 */       return 0;
/* 40:   */     }
/* 41:57 */     for (int i = 0; i < kids.size(); i++)
/* 42:   */     {
/* 43:58 */       sum++;
/* 44:59 */       sum += calculateHierarchyChildren((Item)kids.get(i));
/* 45:   */     }
/* 46:62 */     return sum;
/* 47:   */   }
/* 48:   */   
/* 49:   */   public String getAction()
/* 50:   */   {
/* 51:66 */     return this.action;
/* 52:   */   }
/* 53:   */   
/* 54:   */   public void setAction(String action)
/* 55:   */   {
/* 56:70 */     this.action = action;
/* 57:   */   }
/* 58:   */   
/* 59:   */   public boolean hasFoundKids()
/* 60:   */   {
/* 61:74 */     return this.foundKids;
/* 62:   */   }
/* 63:   */   
/* 64:   */   public void setFoundKids(boolean foundKids)
/* 65:   */   {
/* 66:78 */     this.foundKids = foundKids;
/* 67:   */   }
/* 68:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.components.tree.ItemDesc
 * JD-Core Version:    0.7.0.1
 */