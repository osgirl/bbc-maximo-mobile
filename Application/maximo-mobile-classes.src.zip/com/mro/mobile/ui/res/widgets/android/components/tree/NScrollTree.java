/*   1:    */ package com.mro.mobile.ui.res.widgets.android.components.tree;
/*   2:    */ 
/*   3:    */ import android.content.Context;
/*   4:    */ import android.util.AttributeSet;
/*   5:    */ import android.view.View;
/*   6:    */ import android.widget.FrameLayout.LayoutParams;
/*   7:    */ import android.widget.HorizontalScrollView;
/*   8:    */ import com.ibm.tivoli.maximo.mobile.android.util.UIUtil;
/*   9:    */ import com.ibm.tivoli.maximo.mobile.resources.R.layout;
/*  10:    */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*  11:    */ import com.mro.mobile.ui.res.widgets.android.components.NIDMapper;
/*  12:    */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  13:    */ import java.util.Enumeration;
/*  14:    */ 
/*  15:    */ public class NScrollTree
/*  16:    */   extends HorizontalScrollView
/*  17:    */   implements UIComponent
/*  18:    */ {
/*  19: 35 */   private static final int DEFAULT_XML_LAYOUT = UIUtil.getResourceId(R.layout.class, "nscrolltree");
/*  20: 37 */   private String cid = null;
/*  21: 39 */   private NTree nTree = null;
/*  22: 41 */   private AbstractMobileControl controller = null;
/*  23:    */   
/*  24:    */   public NTree getTree()
/*  25:    */   {
/*  26: 44 */     return this.nTree;
/*  27:    */   }
/*  28:    */   
/*  29:    */   public NScrollTree(Context context)
/*  30:    */   {
/*  31: 48 */     super(context);
/*  32:    */   }
/*  33:    */   
/*  34:    */   public NScrollTree(Context context, AttributeSet attrs)
/*  35:    */   {
/*  36: 52 */     super(context, attrs);
/*  37:    */   }
/*  38:    */   
/*  39:    */   public NScrollTree(Context context, AttributeSet attrs, int defStyle)
/*  40:    */   {
/*  41: 56 */     super(context, attrs, defStyle);
/*  42:    */   }
/*  43:    */   
/*  44:    */   public static NScrollTree createByInflate(AbstractMobileControl control, Context context, NTree ntree)
/*  45:    */   {
/*  46: 60 */     return createByInflate(DEFAULT_XML_LAYOUT, control, context, ntree);
/*  47:    */   }
/*  48:    */   
/*  49:    */   public static NScrollTree createByInflate(int layoutId, AbstractMobileControl control, Context context, NTree ntree)
/*  50:    */   {
/*  51: 64 */     NScrollTree nstree = (NScrollTree)View.inflate(context, layoutId, null);
/*  52: 65 */     nstree.setLayoutParams(new FrameLayout.LayoutParams(-1, -1));
/*  53: 66 */     nstree.setFillViewport(true);
/*  54: 67 */     nstree.postInstance(control, ntree);
/*  55: 68 */     return nstree;
/*  56:    */   }
/*  57:    */   
/*  58:    */   private void postInstance(AbstractMobileControl control, NTree ntree)
/*  59:    */   {
/*  60: 72 */     this.nTree = ntree;
/*  61: 73 */     setController(control);
/*  62: 74 */     setCId("nstree" + getId());
/*  63: 75 */     if (control != null) {
/*  64: 76 */       setId(NIDMapper.getAndroidIdFor(control.getId()));
/*  65:    */     } else {
/*  66: 78 */       setId(NIDMapper.getNextId());
/*  67:    */     }
/*  68: 80 */     initView();
/*  69:    */   }
/*  70:    */   
/*  71:    */   private void initView()
/*  72:    */   {
/*  73: 84 */     super.addView(this.nTree);
/*  74:    */   }
/*  75:    */   
/*  76:    */   public void init() {}
/*  77:    */   
/*  78:    */   public void addChildUIComponent(UIComponent child) {}
/*  79:    */   
/*  80:    */   public boolean canContainChildren()
/*  81:    */   {
/*  82:102 */     return false;
/*  83:    */   }
/*  84:    */   
/*  85:    */   public Enumeration getChildren()
/*  86:    */   {
/*  87:108 */     return null;
/*  88:    */   }
/*  89:    */   
/*  90:    */   public AbstractMobileControl getController()
/*  91:    */   {
/*  92:113 */     return this.controller;
/*  93:    */   }
/*  94:    */   
/*  95:    */   public void setController(AbstractMobileControl controller)
/*  96:    */   {
/*  97:118 */     this.controller = controller;
/*  98:    */   }
/*  99:    */   
/* 100:    */   public Object getConstraints()
/* 101:    */   {
/* 102:124 */     return null;
/* 103:    */   }
/* 104:    */   
/* 105:    */   public void setConstraints(Object contstraints) {}
/* 106:    */   
/* 107:    */   public String getCId()
/* 108:    */   {
/* 109:134 */     return this.cid;
/* 110:    */   }
/* 111:    */   
/* 112:    */   public void setCId(String cid)
/* 113:    */   {
/* 114:138 */     this.cid = cid;
/* 115:    */   }
/* 116:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.components.tree.NScrollTree
 * JD-Core Version:    0.7.0.1
 */