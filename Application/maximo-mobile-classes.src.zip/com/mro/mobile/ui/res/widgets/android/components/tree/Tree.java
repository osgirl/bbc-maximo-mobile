/*   1:    */ package com.mro.mobile.ui.res.widgets.android.components.tree;
/*   2:    */ 
/*   3:    */ import java.util.HashMap;
/*   4:    */ import java.util.Vector;
/*   5:    */ 
/*   6:    */ public class Tree
/*   7:    */   implements TreeModel
/*   8:    */ {
/*   9:    */   private Item root;
/*  10: 14 */   private HashMap<Item, ItemDesc> elements = new HashMap();
/*  11:    */   private Vector support;
/*  12:    */   private static final int INSERTED = 1;
/*  13:    */   private static final int REMOVED = 2;
/*  14:    */   private static final int MODIFIED = 3;
/*  15:    */   
/*  16:    */   public Tree() {}
/*  17:    */   
/*  18:    */   private Tree(Item rootItem)
/*  19:    */   {
/*  20: 31 */     setRoot(rootItem);
/*  21:    */   }
/*  22:    */   
/*  23:    */   public void setRoot(Item rootItem)
/*  24:    */   {
/*  25: 40 */     if ((this.root != null) || (rootItem == null)) {
/*  26: 40 */       throw new IllegalArgumentException();
/*  27:    */     }
/*  28: 41 */     this.root = rootItem;
/*  29: 42 */     regItem(rootItem, null);
/*  30:    */   }
/*  31:    */   
/*  32:    */   public Item getRoot()
/*  33:    */   {
/*  34: 46 */     return this.root;
/*  35:    */   }
/*  36:    */   
/*  37:    */   public int getItemsCount()
/*  38:    */   {
/*  39: 50 */     return this.elements.size();
/*  40:    */   }
/*  41:    */   
/*  42:    */   public Item[] getChildren()
/*  43:    */   {
/*  44: 58 */     return getChildren(getRoot());
/*  45:    */   }
/*  46:    */   
/*  47:    */   public Item[] getChildren(Item item)
/*  48:    */   {
/*  49: 68 */     ItemDesc desc = getItemDesc(item);
/*  50: 69 */     if (desc.children == null) {
/*  51: 69 */       return new Item[0];
/*  52:    */     }
/*  53: 71 */     Item[] items = new Item[desc.children.size()];
/*  54: 72 */     for (int i = 0; i < items.length; i++) {
/*  55: 72 */       items[i] = ((Item)desc.children.elementAt(i));
/*  56:    */     }
/*  57: 73 */     return items;
/*  58:    */   }
/*  59:    */   
/*  60:    */   public Item getChildAt(Item item, int index)
/*  61:    */   {
/*  62: 77 */     return (Item)getItemDesc(item).children.elementAt(index);
/*  63:    */   }
/*  64:    */   
/*  65:    */   public int getChildIndex(Item item)
/*  66:    */   {
/*  67: 82 */     if (contains(item))
/*  68:    */     {
/*  69: 84 */       Item parent = getParent(item);
/*  70: 85 */       return parent != null ? getItemDesc(parent).children.indexOf(item) : 0;
/*  71:    */     }
/*  72: 87 */     return -1;
/*  73:    */   }
/*  74:    */   
/*  75:    */   public Item getParent(Item item)
/*  76:    */   {
/*  77: 91 */     return getItemDesc(item).parent;
/*  78:    */   }
/*  79:    */   
/*  80:    */   public int getChildrenCount(Item item)
/*  81:    */   {
/*  82: 95 */     return getItemDesc(item).getChildrenCount();
/*  83:    */   }
/*  84:    */   
/*  85:    */   public int getHierarchyChildrenCount(Item item)
/*  86:    */   {
/*  87: 99 */     return getItemDesc(item).getHierarchyChildrenCount();
/*  88:    */   }
/*  89:    */   
/*  90:    */   public boolean hasChildren(Item item)
/*  91:    */   {
/*  92:103 */     return getChildrenCount(item) > 0;
/*  93:    */   }
/*  94:    */   
/*  95:    */   public boolean contains(Item item)
/*  96:    */   {
/*  97:113 */     return this.elements.get(item) != null;
/*  98:    */   }
/*  99:    */   
/* 100:    */   public void add(Item to, Item item)
/* 101:    */   {
/* 102:117 */     insert(to, item, getChildrenCount(to));
/* 103:    */   }
/* 104:    */   
/* 105:    */   public void insert(Item to, Item item, int index)
/* 106:    */   {
/* 107:122 */     if (index < 0) {
/* 108:122 */       throw new IllegalArgumentException();
/* 109:    */     }
/* 110:123 */     ItemDesc desc = getItemDesc(to);
/* 111:124 */     if (desc.children == null) {
/* 112:124 */       desc.children = new Vector(5);
/* 113:    */     }
/* 114:125 */     desc.children.insertElementAt(item, index);
/* 115:126 */     regItem(item, to);
/* 116:    */   }
/* 117:    */   
/* 118:    */   public void remove(Item item)
/* 119:    */   {
/* 120:131 */     ItemDesc desc = getItemDesc(item);
/* 121:133 */     if (desc.children != null) {
/* 122:134 */       while (desc.children.size() != 0) {
/* 123:135 */         remove((Item)desc.children.elementAt(0));
/* 124:    */       }
/* 125:    */     }
/* 126:137 */     unregItem(item);
/* 127:    */   }
/* 128:    */   
/* 129:    */   public void removeChild(Item parent, int index)
/* 130:    */   {
/* 131:146 */     remove((Item)getItemDesc(parent).children.elementAt(index));
/* 132:    */   }
/* 133:    */   
/* 134:    */   public void removeKids(Item item)
/* 135:    */   {
/* 136:154 */     Item[] items = getChildren(item);
/* 137:155 */     for (int i = 0; i < items.length; i++) {
/* 138:155 */       remove(items[i]);
/* 139:    */     }
/* 140:    */   }
/* 141:    */   
/* 142:    */   public TreeModel clone(Item item)
/* 143:    */   {
/* 144:166 */     Tree res = new Tree(this.root);
/* 145:167 */     clone(res, new Item(item), getItemDesc(item));
/* 146:168 */     return res;
/* 147:    */   }
/* 148:    */   
/* 149:    */   public void addTreeListener(TreeListener l)
/* 150:    */   {
/* 151:172 */     if (this.support == null) {
/* 152:172 */       this.support = new Vector(1);
/* 153:    */     }
/* 154:173 */     if (!this.support.contains(l)) {
/* 155:173 */       this.support.addElement(l);
/* 156:    */     }
/* 157:    */   }
/* 158:    */   
/* 159:    */   public void removeTreeListener(TreeListener l)
/* 160:    */   {
/* 161:177 */     if (this.support != null) {
/* 162:177 */       this.support.removeElement(l);
/* 163:    */     }
/* 164:    */   }
/* 165:    */   
/* 166:    */   public void set(Item item, Object o)
/* 167:    */   {
/* 168:186 */     item.setValue(o);
/* 169:187 */     perform(3, item, getHierarchyChildrenCount(item));
/* 170:    */   }
/* 171:    */   
/* 172:    */   protected void regItem(Item item, Item parent)
/* 173:    */   {
/* 174:197 */     this.elements.put(item, new ItemDesc(item, parent, this));
/* 175:198 */     perform(1, item, getHierarchyChildrenCount(item));
/* 176:    */   }
/* 177:    */   
/* 178:    */   protected void unregItem(Item item)
/* 179:    */   {
/* 180:207 */     ItemDesc desc = getItemDesc(item);
/* 181:208 */     if (desc.parent != null) {
/* 182:208 */       getItemDesc(desc.parent).children.removeElement(item);
/* 183:    */     }
/* 184:210 */     int hierarchyKids = getHierarchyChildrenCount(item);
/* 185:    */     
/* 186:212 */     this.elements.remove(item);
/* 187:213 */     if (item == this.root) {
/* 188:213 */       this.root = null;
/* 189:    */     }
/* 190:214 */     perform(2, item, hierarchyKids);
/* 191:    */   }
/* 192:    */   
/* 193:    */   protected void perform(int id, Item item, int hierarchyKIds)
/* 194:    */   {
/* 195:224 */     if (this.support != null) {
/* 196:226 */       for (int i = 0; i < this.support.size(); i++)
/* 197:    */       {
/* 198:228 */         TreeListener l = (TreeListener)this.support.elementAt(i);
/* 199:229 */         switch (id)
/* 200:    */         {
/* 201:    */         case 1: 
/* 202:231 */           l.itemInserted(item); break;
/* 203:    */         case 2: 
/* 204:232 */           l.itemRemoved(item, hierarchyKIds); break;
/* 205:    */         case 3: 
/* 206:233 */           l.itemModified(item);
/* 207:    */         }
/* 208:    */       }
/* 209:    */     }
/* 210:    */   }
/* 211:    */   
/* 212:    */   public ItemDesc getItemDesc(Item item)
/* 213:    */   {
/* 214:245 */     return (ItemDesc)this.elements.get(item);
/* 215:    */   }
/* 216:    */   
/* 217:    */   private static void clone(Tree res, Item root, ItemDesc desc)
/* 218:    */   {
/* 219:250 */     if (desc.children != null) {
/* 220:252 */       for (int i = 0; i < desc.children.size(); i++)
/* 221:    */       {
/* 222:254 */         Item originalItem = (Item)desc.children.elementAt(i);
/* 223:255 */         Item item = new Item(originalItem);
/* 224:256 */         res.add(root, item);
/* 225:257 */         clone(res, item, res.getItemDesc(originalItem));
/* 226:    */       }
/* 227:    */     }
/* 228:    */   }
/* 229:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.components.tree.Tree
 * JD-Core Version:    0.7.0.1
 */