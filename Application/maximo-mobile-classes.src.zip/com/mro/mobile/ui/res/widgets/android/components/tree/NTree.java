/*   1:    */ package com.mro.mobile.ui.res.widgets.android.components.tree;
/*   2:    */ 
/*   3:    */ import android.content.Context;
/*   4:    */ import android.util.AttributeSet;
/*   5:    */ import android.view.View;
/*   6:    */ import android.widget.AbsListView.LayoutParams;
/*   7:    */ import android.widget.AdapterView;
/*   8:    */ import android.widget.AdapterView.OnItemClickListener;
/*   9:    */ import android.widget.AdapterView.OnItemLongClickListener;
/*  10:    */ import android.widget.ListView;
/*  11:    */ import com.ibm.tivoli.maximo.mobile.android.util.UIUtil;
/*  12:    */ import com.ibm.tivoli.maximo.mobile.resources.R.layout;
/*  13:    */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*  14:    */ import com.mro.mobile.ui.res.controls.utils.TreeNodeData;
/*  15:    */ import com.mro.mobile.ui.res.widgets.android.components.NIDMapper;
/*  16:    */ import com.mro.mobile.ui.res.widgets.android.components.NImageButton;
/*  17:    */ import com.mro.mobile.ui.res.widgets.android.components.NScrollPan;
/*  18:    */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  19:    */ import java.util.Enumeration;
/*  20:    */ 
/*  21:    */ public class NTree
/*  22:    */   extends ListView
/*  23:    */   implements UIComponent
/*  24:    */ {
/*  25: 38 */   private static final int DEFAULT_XML_LAYOUT = UIUtil.getResourceId(R.layout.class, "ntree");
/*  26: 40 */   private AbstractMobileControl controller = null;
/*  27: 41 */   private String cid = null;
/*  28:    */   
/*  29:    */   public NTree(Context context)
/*  30:    */   {
/*  31: 44 */     super(context);
/*  32:    */   }
/*  33:    */   
/*  34:    */   public NTree(Context context, AttributeSet attrs)
/*  35:    */   {
/*  36: 48 */     super(context, attrs);
/*  37:    */   }
/*  38:    */   
/*  39:    */   public NTree(Context context, AttributeSet attrs, int defStyle)
/*  40:    */   {
/*  41: 52 */     super(context, attrs, defStyle);
/*  42:    */   }
/*  43:    */   
/*  44:    */   public static NTree createByInflate(AbstractMobileControl control, Context context)
/*  45:    */   {
/*  46: 56 */     return createByInflate(DEFAULT_XML_LAYOUT, control, context);
/*  47:    */   }
/*  48:    */   
/*  49:    */   public static NTree createByInflate(int layoutId, AbstractMobileControl control, Context context)
/*  50:    */   {
/*  51: 60 */     NTree tree = (NTree)View.inflate(context, layoutId, null);
/*  52: 61 */     tree.setLayoutParams(new AbsListView.LayoutParams(-1, -1));
/*  53: 62 */     tree.setDivider(null);
/*  54: 63 */     tree.postInstance(control);
/*  55: 64 */     return tree;
/*  56:    */   }
/*  57:    */   
/*  58:    */   private void postInstance(AbstractMobileControl control)
/*  59:    */   {
/*  60: 68 */     setController(control);
/*  61: 69 */     if (control != null) {
/*  62: 70 */       setId(NIDMapper.getAndroidIdFor(control.getId()));
/*  63:    */     } else {
/*  64: 72 */       setId(NIDMapper.getNextId());
/*  65:    */     }
/*  66: 75 */     init();
/*  67:    */   }
/*  68:    */   
/*  69:    */   public void init()
/*  70:    */   {
/*  71: 79 */     super.setOnItemClickListener(new AdapterView.OnItemClickListener()
/*  72:    */     {
/*  73:    */       public void onItemClick(AdapterView<?> parent, View view, int position, long id)
/*  74:    */       {
/*  75: 82 */         NTree.this.getListModel().onItemClick(parent, view, position, id);
/*  76:    */       }
/*  77: 84 */     });
/*  78: 85 */     super.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener()
/*  79:    */     {
/*  80:    */       public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id)
/*  81:    */       {
/*  82: 88 */         return NTree.this.getListModel().onItemLongClick(parent, view, position, id);
/*  83:    */       }
/*  84:    */     });
/*  85:    */   }
/*  86:    */   
/*  87:    */   public String getCId()
/*  88:    */   {
/*  89: 94 */     return this.cid;
/*  90:    */   }
/*  91:    */   
/*  92:    */   public void addChildUIComponent(UIComponent child) {}
/*  93:    */   
/*  94:    */   public boolean canContainChildren()
/*  95:    */   {
/*  96:101 */     return false;
/*  97:    */   }
/*  98:    */   
/*  99:    */   public Enumeration getChildren()
/* 100:    */   {
/* 101:105 */     return null;
/* 102:    */   }
/* 103:    */   
/* 104:    */   public AbstractMobileControl getController()
/* 105:    */   {
/* 106:109 */     return this.controller;
/* 107:    */   }
/* 108:    */   
/* 109:    */   public void setController(AbstractMobileControl controller)
/* 110:    */   {
/* 111:113 */     this.controller = controller;
/* 112:    */   }
/* 113:    */   
/* 114:    */   public Object getConstraints()
/* 115:    */   {
/* 116:123 */     return null;
/* 117:    */   }
/* 118:    */   
/* 119:    */   public void setConstraints(Object consts) {}
/* 120:    */   
/* 121:    */   public void setCId(String cid)
/* 122:    */   {
/* 123:137 */     this.cid = cid;
/* 124:    */   }
/* 125:    */   
/* 126:    */   public void select(Item item) {}
/* 127:    */   
/* 128:    */   public void removeAllChildren(Item targetItem)
/* 129:    */   {
/* 130:144 */     int childCount = getTreeModel().getChildrenCount(targetItem);
/* 131:145 */     for (int i = 0; i < childCount; i++) {
/* 132:146 */       getTreeModel().remove(getTreeModel().getChildAt(targetItem, 0));
/* 133:    */     }
/* 134:    */   }
/* 135:    */   
/* 136:    */   public boolean hasChildren(Item targetItem)
/* 137:    */   {
/* 138:151 */     int childCount = getTreeModel().getChildrenCount(targetItem);
/* 139:152 */     return childCount > 0;
/* 140:    */   }
/* 141:    */   
/* 142:    */   public boolean isValid()
/* 143:    */   {
/* 144:156 */     return true;
/* 145:    */   }
/* 146:    */   
/* 147:    */   public void setupAdapter(TreeModel treeModel)
/* 148:    */   {
/* 149:160 */     setAdapter(new NTreeListViewAdapter(getContext(), treeModel, this));
/* 150:    */   }
/* 151:    */   
/* 152:    */   public TreeModel getTreeModel()
/* 153:    */   {
/* 154:164 */     return getListModel().getTreeModel();
/* 155:    */   }
/* 156:    */   
/* 157:    */   private ListModel getListModel()
/* 158:    */   {
/* 159:168 */     return ((NTreeListViewAdapter)getAdapter()).getListModel();
/* 160:    */   }
/* 161:    */   
/* 162:    */   public void imageClicked(NImageButton nButtonImage)
/* 163:    */   {
/* 164:172 */     getListModel().itemSelection((Item)nButtonImage.getTreeNodeData().getReferenceItem());
/* 165:    */   }
/* 166:    */   
/* 167:    */   protected void onAttachedToWindow()
/* 168:    */   {
/* 169:177 */     super.onAttachedToWindow();
/* 170:    */     
/* 171:179 */     disableParentPageScroll();
/* 172:180 */     ((ListModelImpl)getListModel()).dataChanged();
/* 173:    */   }
/* 174:    */   
/* 175:    */   private void disableParentPageScroll()
/* 176:    */   {
/* 177:184 */     NScrollPan pageScrollView = UIUtil.findHolderScrollPan(this);
/* 178:185 */     if (pageScrollView != null) {
/* 179:186 */       UIUtil.moveChildrenToParent(pageScrollView);
/* 180:    */     }
/* 181:    */   }
/* 182:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.components.tree.NTree
 * JD-Core Version:    0.7.0.1
 */