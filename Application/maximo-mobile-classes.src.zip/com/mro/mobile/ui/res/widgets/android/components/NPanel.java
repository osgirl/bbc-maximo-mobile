/*   1:    */ package com.mro.mobile.ui.res.widgets.android.components;
/*   2:    */ 
/*   3:    */ import android.content.Context;
/*   4:    */ import android.graphics.Color;
/*   5:    */ import android.graphics.drawable.Drawable;
/*   6:    */ import android.util.AttributeSet;
/*   7:    */ import android.view.View;
/*   8:    */ import android.view.ViewParent;
/*   9:    */ import android.widget.LinearLayout;
/*  10:    */ import android.widget.LinearLayout.LayoutParams;
/*  11:    */ import com.ibm.tivoli.maximo.mobile.android.util.ImageUtil;
/*  12:    */ import com.ibm.tivoli.maximo.mobile.android.util.UIUtil;
/*  13:    */ import com.ibm.tivoli.maximo.mobile.resources.R.layout;
/*  14:    */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*  15:    */ import com.mro.mobile.ui.res.controls.PageControl;
/*  16:    */ import com.mro.mobile.ui.res.controls.SectionControl;
/*  17:    */ import com.mro.mobile.ui.res.controls.utils.ControlStyle;
/*  18:    */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  19:    */ import java.util.Enumeration;
/*  20:    */ import java.util.Vector;
/*  21:    */ 
/*  22:    */ public class NPanel
/*  23:    */   extends LinearLayout
/*  24:    */   implements UIComponent
/*  25:    */ {
/*  26: 46 */   protected AbstractMobileControl controller = null;
/*  27: 48 */   private static final int DEFAULT_XML_LAYOUT = UIUtil.getResourceId(R.layout.class, "npanel");
/*  28: 50 */   private String cid = null;
/*  29: 51 */   private Vector children = new Vector();
/*  30: 52 */   private ControlStyle style = null;
/*  31:    */   
/*  32:    */   public NPanel(Context context)
/*  33:    */   {
/*  34: 55 */     super(context);
/*  35:    */   }
/*  36:    */   
/*  37:    */   public NPanel(Context context, AttributeSet attrs)
/*  38:    */   {
/*  39: 59 */     super(context, attrs);
/*  40:    */   }
/*  41:    */   
/*  42:    */   public static NPanel createByInflate(AbstractMobileControl control, Context context, int orientation)
/*  43:    */   {
/*  44: 64 */     return createByInflate(DEFAULT_XML_LAYOUT, control, context, orientation);
/*  45:    */   }
/*  46:    */   
/*  47:    */   public static NPanel createByInflate(int layoutId, AbstractMobileControl control, Context context)
/*  48:    */   {
/*  49: 68 */     return createByInflate(layoutId, control, context, -1);
/*  50:    */   }
/*  51:    */   
/*  52:    */   public static NPanel createByInflate(int layoutId, AbstractMobileControl control, Context context, int orientation)
/*  53:    */   {
/*  54: 72 */     NPanel panel = (NPanel)View.inflate(context, layoutId, null);
/*  55: 73 */     panel.postInstance(control, orientation);
/*  56: 74 */     return panel;
/*  57:    */   }
/*  58:    */   
/*  59:    */   protected void postInstance(AbstractMobileControl control, int orientation)
/*  60:    */   {
/*  61: 79 */     setController(control);
/*  62: 80 */     if (control != null)
/*  63:    */     {
/*  64: 81 */       if (((control instanceof PageControl)) || ((control instanceof SectionControl))) {
/*  65: 82 */         setId(NIDMapper.getAndroidIdFor(control.getId()));
/*  66:    */       } else {
/*  67: 84 */         setId(NIDMapper.getNextId());
/*  68:    */       }
/*  69:    */     }
/*  70:    */     else {
/*  71: 88 */       setId(NIDMapper.getNextId());
/*  72:    */     }
/*  73: 92 */     if (orientation != -1) {
/*  74: 93 */       setOrientation(orientation);
/*  75:    */     }
/*  76: 96 */     init();
/*  77:    */   }
/*  78:    */   
/*  79:    */   public String getCId()
/*  80:    */   {
/*  81:101 */     return this.cid;
/*  82:    */   }
/*  83:    */   
/*  84:    */   public void setCId(String cid)
/*  85:    */   {
/*  86:105 */     this.cid = cid;
/*  87:    */   }
/*  88:    */   
/*  89:    */   public void init() {}
/*  90:    */   
/*  91:    */   public void setOpaque(boolean opaque)
/*  92:    */   {
/*  93:112 */     if (opaque) {
/*  94:113 */       setBackgroundColor(Color.alpha(0));
/*  95:    */     }
/*  96:    */   }
/*  97:    */   
/*  98:    */   public void setBackground(int c)
/*  99:    */   {
/* 100:118 */     super.setBackgroundColor(c);
/* 101:119 */     if (getChildCount() > 0) {
/* 102:120 */       for (int i = 0; i < getChildCount(); i++) {
/* 103:121 */         getChildAt(i).setBackgroundColor(c);
/* 104:    */       }
/* 105:    */     }
/* 106:    */   }
/* 107:    */   
/* 108:    */   public void setBackgroundImage(String img)
/* 109:    */   {
/* 110:127 */     Drawable image = ImageUtil.findImageFromResources(img);
/* 111:128 */     if (image != null) {
/* 112:129 */       setBackgroundDrawable(image);
/* 113:    */     }
/* 114:    */   }
/* 115:    */   
/* 116:    */   public void addChildUIComponent(UIComponent child)
/* 117:    */   {
/* 118:134 */     this.children.addElement(child);
/* 119:    */   }
/* 120:    */   
/* 121:    */   public boolean canContainChildren()
/* 122:    */   {
/* 123:138 */     return true;
/* 124:    */   }
/* 125:    */   
/* 126:    */   public Enumeration getChildren()
/* 127:    */   {
/* 128:142 */     return this.children.elements();
/* 129:    */   }
/* 130:    */   
/* 131:    */   public Vector getChildrenAsVector()
/* 132:    */   {
/* 133:146 */     return this.children;
/* 134:    */   }
/* 135:    */   
/* 136:    */   public AbstractMobileControl getController()
/* 137:    */   {
/* 138:153 */     return this.controller;
/* 139:    */   }
/* 140:    */   
/* 141:    */   public void setController(AbstractMobileControl controller)
/* 142:    */   {
/* 143:161 */     this.controller = controller;
/* 144:    */   }
/* 145:    */   
/* 146:164 */   private LinearLayout.LayoutParams constraints = null;
/* 147:    */   
/* 148:    */   public Object getConstraints()
/* 149:    */   {
/* 150:167 */     return this.constraints;
/* 151:    */   }
/* 152:    */   
/* 153:    */   public void setConstraints(Object consts)
/* 154:    */   {
/* 155:171 */     this.constraints = ((LinearLayout.LayoutParams)consts);
/* 156:172 */     setLayoutParams(this.constraints);
/* 157:173 */     requestLayout();
/* 158:    */   }
/* 159:    */   
/* 160:    */   public void addView(View v)
/* 161:    */   {
/* 162:177 */     ViewParent viewParent = v.getParent();
/* 163:178 */     if (viewParent == null)
/* 164:    */     {
/* 165:179 */       super.addView(v);
/* 166:180 */       if ((v instanceof UIComponent)) {
/* 167:181 */         addChildUIComponent((UIComponent)v);
/* 168:    */       }
/* 169:    */     }
/* 170:    */   }
/* 171:    */   
/* 172:    */   public void remove(UIComponent comp)
/* 173:    */   {
/* 174:192 */     this.children.remove(comp);
/* 175:    */   }
/* 176:    */   
/* 177:    */   public ControlStyle getStyle()
/* 178:    */   {
/* 179:199 */     return this.style;
/* 180:    */   }
/* 181:    */   
/* 182:    */   public void setStyle(ControlStyle style)
/* 183:    */   {
/* 184:207 */     this.style = style;
/* 185:    */   }
/* 186:    */   
/* 187:    */   public void setVisible(boolean show)
/* 188:    */   {
/* 189:211 */     setVisibility(show ? 0 : 8);
/* 190:    */   }
/* 191:    */   
/* 192:    */   public boolean isVisible()
/* 193:    */   {
/* 194:215 */     return getVisibility() == 0;
/* 195:    */   }
/* 196:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.components.NPanel
 * JD-Core Version:    0.7.0.1
 */