/*   1:    */ package com.mro.mobile.ui.res.widgets.android.components;
/*   2:    */ 
/*   3:    */ import android.content.Context;
/*   4:    */ import android.util.AttributeSet;
/*   5:    */ import android.view.View;
/*   6:    */ import android.view.View.OnClickListener;
/*   7:    */ import android.widget.AdapterView;
/*   8:    */ import android.widget.AdapterView.OnItemClickListener;
/*   9:    */ import android.widget.ImageView;
/*  10:    */ import android.widget.LinearLayout;
/*  11:    */ import android.widget.LinearLayout.LayoutParams;
/*  12:    */ import android.widget.ListView;
/*  13:    */ import android.widget.TextView;
/*  14:    */ import com.ibm.tivoli.maximo.mobile.android.util.UIUtil;
/*  15:    */ import com.ibm.tivoli.maximo.mobile.android.widget.FileChooserAdapter;
/*  16:    */ import com.ibm.tivoli.maximo.mobile.resources.R.id;
/*  17:    */ import com.ibm.tivoli.maximo.mobile.resources.R.layout;
/*  18:    */ import com.mro.mobile.MobileMessageGenerator;
/*  19:    */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*  20:    */ import com.mro.mobile.ui.res.controls.LabelControl;
/*  21:    */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  22:    */ import java.io.File;
/*  23:    */ import java.io.FilenameFilter;
/*  24:    */ import java.util.Enumeration;
/*  25:    */ 
/*  26:    */ public class NFileChooser
/*  27:    */   extends LinearLayout
/*  28:    */   implements UIComponent
/*  29:    */ {
/*  30: 28 */   private static final int DEFAULT_XML_LAYOUT = UIUtil.getResourceId(R.layout.class, "nfilechooser");
/*  31:    */   private FileChooserAdapter adapter;
/*  32: 32 */   private File currentPath = null;
/*  33: 33 */   private File selectedFile = null;
/*  34: 34 */   private TextView drilledPath = null;
/*  35: 35 */   private TextView upBtn = null;
/*  36: 36 */   private ImageView upbtnIcon = null;
/*  37:    */   private ListView listView;
/*  38:    */   
/*  39:    */   public NFileChooser(Context context)
/*  40:    */   {
/*  41: 39 */     super(context);
/*  42:    */   }
/*  43:    */   
/*  44:    */   public NFileChooser(Context context, AttributeSet attrs)
/*  45:    */   {
/*  46: 43 */     super(context, attrs);
/*  47:    */   }
/*  48:    */   
/*  49:    */   public static NFileChooser createByInflate(AbstractMobileControl control, Context context, File startDirectory)
/*  50:    */   {
/*  51: 47 */     NFileChooser chooser = new NFileChooser(context);
/*  52:    */     
/*  53: 49 */     chooser.setOrientation(1);
/*  54: 50 */     chooser.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
/*  55:    */     
/*  56: 52 */     View.inflate(context, DEFAULT_XML_LAYOUT, chooser);
/*  57: 53 */     chooser.postInstance(control, context, startDirectory);
/*  58:    */     
/*  59: 55 */     return chooser;
/*  60:    */   }
/*  61:    */   
/*  62:    */   public void postInstance(AbstractMobileControl control, Context context, File startDirectory)
/*  63:    */   {
/*  64: 59 */     setController(control);
/*  65: 61 */     if (control != null)
/*  66:    */     {
/*  67: 62 */       if ((control instanceof LabelControl)) {
/*  68: 63 */         setId(NIDMapper.getAndroidIdFor(control.getId()));
/*  69:    */       } else {
/*  70: 66 */         setId(NIDMapper.getAndroidIdFor(control.getId() + "_filechooser"));
/*  71:    */       }
/*  72:    */     }
/*  73:    */     else {
/*  74: 69 */       setId(NIDMapper.getNextId());
/*  75:    */     }
/*  76: 72 */     init(startDirectory);
/*  77:    */   }
/*  78:    */   
/*  79:    */   private void init(File startDirectory)
/*  80:    */   {
/*  81: 79 */     this.drilledPath = ((TextView)findViewById(UIUtil.getResourceId(R.id.class, "currentpath")));
/*  82:    */     
/*  83: 81 */     this.upbtnIcon = ((ImageView)findViewById(UIUtil.getResourceId(R.id.class, "upbtn_icon")));
/*  84: 82 */     this.upbtnIcon.setOnClickListener(new View.OnClickListener()
/*  85:    */     {
/*  86:    */       public void onClick(View v)
/*  87:    */       {
/*  88: 84 */         NFileChooser.this.backPressed();
/*  89:    */       }
/*  90: 86 */     });
/*  91: 87 */     this.upbtnIcon.setFocusable(false);
/*  92:    */     
/*  93: 89 */     this.upBtn = ((TextView)findViewById(UIUtil.getResourceId(R.id.class, "upbtn")));
/*  94:    */     
/*  95: 91 */     this.upBtn.setText(MobileMessageGenerator.generate("nfilechooser_parentfolder", null));
/*  96:    */     
/*  97: 93 */     this.upBtn.setOnClickListener(new View.OnClickListener()
/*  98:    */     {
/*  99:    */       public void onClick(View v)
/* 100:    */       {
/* 101: 95 */         NFileChooser.this.backPressed();
/* 102:    */       }
/* 103: 97 */     });
/* 104: 98 */     this.upBtn.setFocusable(false);
/* 105:    */     
/* 106:100 */     this.listView = ((ListView)findViewById(16908298));
/* 107:101 */     this.listView.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
/* 108:    */     
/* 109:103 */     this.listView.setEmptyView(findViewById(16908292));
/* 110:    */     
/* 111:    */ 
/* 112:106 */     this.listView.setCacheColorHint(0);
/* 113:    */     
/* 114:108 */     this.listView.setOnItemClickListener(new AdapterView.OnItemClickListener()
/* 115:    */     {
/* 116:    */       public void onItemClick(AdapterView<?> arg0, View view, int position, long id)
/* 117:    */       {
/* 118:111 */         NFileChooser.this.setCurrentPath((File)NFileChooser.this.adapter.getItem(position));
/* 119:    */       }
/* 120:114 */     });
/* 121:115 */     TextView empty = (TextView)findViewById(16908292);
/* 122:116 */     empty.setText(MobileMessageGenerator.generate("nfilechooser_noresults", null));
/* 123:    */     
/* 124:118 */     setCurrentPath(startDirectory);
/* 125:    */   }
/* 126:    */   
/* 127:    */   protected boolean backPressed()
/* 128:    */   {
/* 129:122 */     if (this.currentPath.getParentFile() != null) {
/* 130:123 */       setCurrentPath(this.currentPath.getParentFile());
/* 131:    */     }
/* 132:125 */     return true;
/* 133:    */   }
/* 134:    */   
/* 135:    */   private void setCurrentPath(File newPath)
/* 136:    */   {
/* 137:129 */     this.currentPath = newPath;
/* 138:130 */     this.drilledPath.setText(this.currentPath.getAbsolutePath());
/* 139:132 */     if (newPath.isDirectory())
/* 140:    */     {
/* 141:133 */       File[] filteredFiles = this.currentPath.listFiles(new ExtFileFilter("*"));
/* 142:134 */       this.adapter = new FileChooserAdapter(getContext(), filteredFiles);
/* 143:135 */       this.listView.setAdapter(this.adapter);
/* 144:    */     }
/* 145:    */     else
/* 146:    */     {
/* 147:137 */       this.selectedFile = this.currentPath;
/* 148:    */     }
/* 149:    */   }
/* 150:    */   
/* 151:    */   public File getSelectedFile()
/* 152:    */   {
/* 153:142 */     return this.selectedFile;
/* 154:    */   }
/* 155:    */   
/* 156:    */   public void setCId(String cid) {}
/* 157:    */   
/* 158:    */   public String getCId()
/* 159:    */   {
/* 160:151 */     return null;
/* 161:    */   }
/* 162:    */   
/* 163:    */   public void init() {}
/* 164:    */   
/* 165:    */   public void addChildUIComponent(UIComponent child) {}
/* 166:    */   
/* 167:    */   public boolean canContainChildren()
/* 168:    */   {
/* 169:165 */     return false;
/* 170:    */   }
/* 171:    */   
/* 172:    */   public Enumeration getChildren()
/* 173:    */   {
/* 174:170 */     return null;
/* 175:    */   }
/* 176:    */   
/* 177:    */   public AbstractMobileControl getController()
/* 178:    */   {
/* 179:175 */     return null;
/* 180:    */   }
/* 181:    */   
/* 182:    */   public void setController(AbstractMobileControl controller) {}
/* 183:    */   
/* 184:    */   public Object getConstraints()
/* 185:    */   {
/* 186:184 */     return null;
/* 187:    */   }
/* 188:    */   
/* 189:    */   public void setConstraints(Object contstraints) {}
/* 190:    */   
/* 191:    */   private static class ExtFileFilter
/* 192:    */     implements FilenameFilter
/* 193:    */   {
/* 194:    */     private String ext;
/* 195:    */     
/* 196:    */     public ExtFileFilter(String ext)
/* 197:    */     {
/* 198:196 */       this.ext = ext;
/* 199:    */     }
/* 200:    */     
/* 201:    */     public boolean accept(File dir, String name)
/* 202:    */     {
/* 203:201 */       File currentFile = new File(dir.getPath() + File.separator + name);
/* 204:204 */       if (!currentFile.canRead()) {
/* 205:205 */         return false;
/* 206:    */       }
/* 207:208 */       if ((this.ext.equals("*")) || (currentFile.isDirectory())) {
/* 208:209 */         return true;
/* 209:    */       }
/* 210:212 */       int index = name.lastIndexOf('.');
/* 211:213 */       return (index > 0) && (this.ext.equalsIgnoreCase(name.substring(index + 1)));
/* 212:    */     }
/* 213:    */   }
/* 214:    */   
/* 215:    */   protected void onAttachedToWindow()
/* 216:    */   {
/* 217:219 */     super.onAttachedToWindow();
/* 218:    */     
/* 219:221 */     disableParentPageScroll();
/* 220:    */   }
/* 221:    */   
/* 222:    */   private void disableParentPageScroll()
/* 223:    */   {
/* 224:225 */     NScrollPan pageScrollView = UIUtil.findHolderScrollPan(this);
/* 225:226 */     if (pageScrollView != null) {
/* 226:227 */       UIUtil.moveChildrenToParent(pageScrollView);
/* 227:    */     }
/* 228:    */   }
/* 229:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.components.NFileChooser
 * JD-Core Version:    0.7.0.1
 */