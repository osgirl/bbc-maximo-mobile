/*   1:    */ package com.mro.mobile.ui.res.widgets.android;
/*   2:    */ 
/*   3:    */ import android.view.View;
/*   4:    */ import com.mro.mobile.MobileApplicationException;
/*   5:    */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*   6:    */ import com.mro.mobile.ui.res.widgets.android.components.NMenu;
/*   7:    */ import com.mro.mobile.ui.res.widgets.android.components.NMenuItem;
/*   8:    */ import com.mro.mobile.ui.res.widgets.def.MenuWidget;
/*   9:    */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  10:    */ import java.util.ArrayList;
/*  11:    */ import java.util.Vector;
/*  12:    */ 
/*  13:    */ public class ADMenuWidgetImpl
/*  14:    */   extends ADAbstractWidgetImpl
/*  15:    */   implements MenuWidget
/*  16:    */ {
/*  17: 16 */   private NMenu menu = null;
/*  18: 17 */   protected ArrayList menuContents = null;
/*  19:    */   
/*  20:    */   public NMenu getMenuComponent()
/*  21:    */   {
/*  22: 20 */     return this.menu;
/*  23:    */   }
/*  24:    */   
/*  25:    */   private void createMenu()
/*  26:    */   {
/*  27: 24 */     if (this.menu == null) {
/*  28: 25 */       this.menu = new NMenu(getController(), AndroidEnv.getCurrentActivity());
/*  29:    */     }
/*  30:    */   }
/*  31:    */   
/*  32:    */   public void createMenu(String id, String label)
/*  33:    */   {
/*  34: 30 */     setMenuId(id);
/*  35: 31 */     setMenuLabel(label);
/*  36:    */   }
/*  37:    */   
/*  38:    */   public void setMenuId(String id)
/*  39:    */   {
/*  40: 35 */     createMenu();
/*  41: 36 */     this.menu.setCId(id);
/*  42:    */   }
/*  43:    */   
/*  44:    */   public void setMenuLabel(String label)
/*  45:    */   {
/*  46: 40 */     createMenu();
/*  47: 41 */     this.menu.setMenuLabel(label);
/*  48:    */   }
/*  49:    */   
/*  50:    */   public String getMenuLabel()
/*  51:    */   {
/*  52: 45 */     createMenu();
/*  53: 46 */     return this.menu.getMenuLabel();
/*  54:    */   }
/*  55:    */   
/*  56:    */   public void buildMenu()
/*  57:    */     throws MobileApplicationException
/*  58:    */   {
/*  59: 50 */     if (this.menuContents == null) {
/*  60: 51 */       return;
/*  61:    */     }
/*  62: 54 */     int SIZE = this.menuContents.size();
/*  63: 55 */     if (SIZE == 0) {
/*  64: 56 */       return;
/*  65:    */     }
/*  66: 59 */     for (int i = 0; i < SIZE; i++)
/*  67:    */     {
/*  68: 60 */       UIComponent[] comps = (UIComponent[])this.menuContents.get(i);
/*  69: 61 */       UIComponent comp = comps[0];
/*  70:    */       
/*  71: 63 */       View view = (View)comp;
/*  72: 64 */       if (view.getVisibility() == 0) {
/*  73: 68 */         if ((comp instanceof NMenuItem))
/*  74:    */         {
/*  75: 69 */           NMenuItem item = (NMenuItem)comp;
/*  76: 70 */           this.menu.addChildUIComponent(item);
/*  77:    */         }
/*  78: 71 */         else if ((comp instanceof NMenu))
/*  79:    */         {
/*  80: 72 */           NMenu currentMenu = (NMenu)comp;
/*  81:    */           
/*  82: 74 */           String menuLabel = currentMenu.getMenuLabel();
/*  83: 75 */           this.menu.addChildUIComponent(buildSubmenu(menuLabel, comp.getController().composeChildren()));
/*  84:    */         }
/*  85:    */       }
/*  86:    */     }
/*  87:    */   }
/*  88:    */   
/*  89:    */   private NMenu buildSubmenu(String menuLabel, ArrayList submenuContents)
/*  90:    */     throws MobileApplicationException
/*  91:    */   {
/*  92: 81 */     NMenu subMenu = new NMenu(getController(), AndroidEnv.getCurrentActivity());
/*  93: 82 */     subMenu.setMenuLabel(menuLabel);
/*  94: 84 */     if (submenuContents == null) {
/*  95: 85 */       return subMenu;
/*  96:    */     }
/*  97: 88 */     int SIZE = submenuContents.size();
/*  98: 89 */     if (SIZE == 0) {
/*  99: 90 */       return subMenu;
/* 100:    */     }
/* 101: 93 */     for (int i = 0; i < SIZE; i++)
/* 102:    */     {
/* 103: 94 */       UIComponent[] comps = (UIComponent[])submenuContents.get(i);
/* 104: 95 */       UIComponent comp = comps[0];
/* 105:    */       
/* 106: 97 */       View view = (View)comp;
/* 107: 98 */       if (view.getVisibility() == 0) {
/* 108:102 */         if ((comp instanceof NMenuItem))
/* 109:    */         {
/* 110:103 */           NMenuItem item = (NMenuItem)comp;
/* 111:104 */           subMenu.addChildUIComponent(item);
/* 112:    */         }
/* 113:105 */         else if ((comp instanceof NMenu))
/* 114:    */         {
/* 115:106 */           NMenu currentMenu = (NMenu)comp;
/* 116:    */           
/* 117:108 */           String label = currentMenu.getMenuLabel();
/* 118:109 */           subMenu.addChildUIComponent(buildSubmenu(menuLabel, comp.getController().composeChildren()));
/* 119:    */         }
/* 120:    */       }
/* 121:    */     }
/* 122:113 */     return subMenu;
/* 123:    */   }
/* 124:    */   
/* 125:    */   public void refreshMenu()
/* 126:    */   {
/* 127:117 */     if (this.menu != null)
/* 128:    */     {
/* 129:118 */       Vector list = this.menu.getChildrenAsVector();
/* 130:119 */       if (list != null) {
/* 131:120 */         list.removeAllElements();
/* 132:    */       }
/* 133:    */     }
/* 134:    */   }
/* 135:    */   
/* 136:    */   public UIComponent[] resolveMenuComponents()
/* 137:    */     throws MobileApplicationException
/* 138:    */   {
/* 139:126 */     ArrayList tempMenuContents = getController().composeChildren();
/* 140:127 */     if (tempMenuContents != null)
/* 141:    */     {
/* 142:128 */       this.menuContents = tempMenuContents;
/* 143:129 */       buildMenu();
/* 144:    */     }
/* 145:131 */     return new UIComponent[] { this.menu };
/* 146:    */   }
/* 147:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.ADMenuWidgetImpl
 * JD-Core Version:    0.7.0.1
 */