package com.mro.mobile.ui.res.widgets.def;

import com.mro.mobile.MobileApplicationException;

public abstract interface ImageWidget
  extends AbstractWidget
{
  public abstract ImageWidget createImageWidget(String paramString);
  
  public abstract void setImageId(String paramString);
  
  public abstract UIComponent[] resolveImageComponents()
    throws MobileApplicationException;
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.def.ImageWidget
 * JD-Core Version:    0.7.0.1
 */