/*  1:   */ package com.mro.mobile.ui.res.widgets.android.components;
/*  2:   */ 
/*  3:   */ import android.view.View;
/*  4:   */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  5:   */ 
/*  6:   */ public class NDrawerListenerManager
/*  7:   */ {
/*  8:   */   private DrawerLinkClickableImpl drawerCloser;
/*  9:15 */   private static NDrawerListenerManager instance = null;
/* 10:   */   
/* 11:   */   private NDrawerListenerManager()
/* 12:   */   {
/* 13:18 */     this.drawerCloser = new DrawerLinkClickableImpl(null);
/* 14:   */   }
/* 15:   */   
/* 16:   */   public static synchronized NDrawerListenerManager instance()
/* 17:   */   {
/* 18:22 */     if (instance == null) {
/* 19:23 */       instance = new NDrawerListenerManager();
/* 20:   */     }
/* 21:25 */     return instance;
/* 22:   */   }
/* 23:   */   
/* 24:   */   public DrawerLinkClickable getDrawerLinkClickable()
/* 25:   */   {
/* 26:29 */     return this.drawerCloser;
/* 27:   */   }
/* 28:   */   
/* 29:   */   private class DrawerLinkClickableImpl
/* 30:   */     implements NDrawerListenerManager.DrawerLinkClickable
/* 31:   */   {
/* 32:   */     private DrawerLinkClickableImpl() {}
/* 33:   */     
/* 34:   */     public void drawerLinkClicked(View view)
/* 35:   */     {
/* 36:38 */       NDrawer drawer = runHierachyBackToSlidingDrawer(view);
/* 37:39 */       if (drawer != null) {
/* 38:40 */         drawer.close();
/* 39:   */       }
/* 40:   */     }
/* 41:   */     
/* 42:   */     public NDrawer runHierachyBackToSlidingDrawer(View view)
/* 43:   */     {
/* 44:45 */       if ((view != null) && ((view instanceof UIComponent)))
/* 45:   */       {
/* 46:46 */         if ((view instanceof NDrawer)) {
/* 47:47 */           return (NDrawer)view;
/* 48:   */         }
/* 49:49 */         View parent = (View)view.getParent();
/* 50:50 */         if (parent != null) {
/* 51:51 */           return runHierachyBackToSlidingDrawer(parent);
/* 52:   */         }
/* 53:   */       }
/* 54:54 */       return null;
/* 55:   */     }
/* 56:   */   }
/* 57:   */   
/* 58:   */   public static abstract interface DrawerLinkClickable
/* 59:   */   {
/* 60:   */     public abstract void drawerLinkClicked(View paramView);
/* 61:   */   }
/* 62:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.components.NDrawerListenerManager
 * JD-Core Version:    0.7.0.1
 */