/*  1:   */ package com.mro.mobile.ui.res.widgets.android;
/*  2:   */ 
/*  3:   */ import com.mro.mobile.ui.res.widgets.android.components.NMenuItem;
/*  4:   */ import com.mro.mobile.ui.res.widgets.def.MenuItemWidget;
/*  5:   */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  6:   */ 
/*  7:   */ public class ADMenuItemWidgetImpl
/*  8:   */   extends ADMenuWidgetImpl
/*  9:   */   implements MenuItemWidget
/* 10:   */ {
/* 11: 9 */   private NMenuItem menuItem = null;
/* 12:   */   
/* 13:   */   public void createMenuItem(String id, String label, String value, String image, boolean hasSeparator, String event, String targetid)
/* 14:   */   {
/* 15:12 */     this.menuItem = new NMenuItem(getController(), AndroidEnv.getCurrentActivity());
/* 16:14 */     if (image != null) {
/* 17:16 */       this.menuItem.setImage(image);
/* 18:   */     }
/* 19:18 */     this.menuItem.setLabel(label);
/* 20:19 */     this.menuItem.setAddSeperator(hasSeparator);
/* 21:20 */     this.menuItem.setEvent(event);
/* 22:21 */     this.menuItem.setValue(value);
/* 23:22 */     this.menuItem.setTargetId(targetid);
/* 24:   */   }
/* 25:   */   
/* 26:   */   public UIComponent[] resolveMMenuItemComponents()
/* 27:   */   {
/* 28:26 */     return new UIComponent[] { this.menuItem };
/* 29:   */   }
/* 30:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.ADMenuItemWidgetImpl
 * JD-Core Version:    0.7.0.1
 */