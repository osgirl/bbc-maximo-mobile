/*  1:   */ package com.mro.mobile.ui.res.widgets.android;
/*  2:   */ 
/*  3:   */ import com.mro.mobile.ui.res.controls.MessageBox;
/*  4:   */ import com.mro.mobile.ui.res.controls.MessageBoxAdapter;
/*  5:   */ import com.mro.mobile.ui.res.controls.MessageBoxAdapterFactory;
/*  6:   */ 
/*  7:   */ public class AndroidMessageBoxAdapterFactory
/*  8:   */   implements MessageBoxAdapterFactory
/*  9:   */ {
/* 10:   */   public MessageBoxAdapter create(MessageBox messageBox)
/* 11:   */   {
/* 12:16 */     return new AndroidMessageBoxAdapterImpl(messageBox);
/* 13:   */   }
/* 14:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.AndroidMessageBoxAdapterFactory
 * JD-Core Version:    0.7.0.1
 */