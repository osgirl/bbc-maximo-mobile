/*   1:    */ package com.mro.mobile.ui.res.widgets.android.components;
/*   2:    */ 
/*   3:    */ import android.content.Context;
/*   4:    */ import android.graphics.drawable.Drawable;
/*   5:    */ import android.util.AttributeSet;
/*   6:    */ import android.view.View;
/*   7:    */ import android.view.View.OnClickListener;
/*   8:    */ import android.view.View.OnLongClickListener;
/*   9:    */ import android.widget.ImageButton;
/*  10:    */ import android.widget.LinearLayout.LayoutParams;
/*  11:    */ import com.ibm.tivoli.maximo.mobile.android.camera.AttachmentIntentCameraCallback;
/*  12:    */ import com.ibm.tivoli.maximo.mobile.android.sensor.AndroidIntentBarcodeReader;
/*  13:    */ import com.ibm.tivoli.maximo.mobile.android.util.ImageUtil;
/*  14:    */ import com.ibm.tivoli.maximo.mobile.resources.R.drawable;
/*  15:    */ import com.ibm.tivoli.maximo.mobile.resources.R.layout;
/*  16:    */ import com.mro.mobile.MobileApplicationException;
/*  17:    */ import com.mro.mobile.app.BasicMobileDeviceUIApplication;
/*  18:    */ import com.mro.mobile.sensor.barcode.MobileBarcodeReaderWrapper;
/*  19:    */ import com.mro.mobile.ui.MobileMboDataBean;
/*  20:    */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*  21:    */ import com.mro.mobile.ui.res.controls.AttributeNameConstants;
/*  22:    */ import com.mro.mobile.ui.res.controls.InputControl;
/*  23:    */ import com.mro.mobile.ui.res.controls.LinkControl;
/*  24:    */ import com.mro.mobile.ui.res.controls.utils.TreeNodeData;
/*  25:    */ import com.mro.mobile.ui.res.widgets.android.AndroidEnv;
/*  26:    */ import com.mro.mobile.ui.res.widgets.android.components.table.NTableListenerManager.TableClickable;
/*  27:    */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  28:    */ import com.mro.mobile.util.MobileLogger;
/*  29:    */ import com.mro.mobile.util.MobileLoggerFactory;
/*  30:    */ import java.util.Enumeration;
/*  31:    */ 
/*  32:    */ public class NImageButton
/*  33:    */   extends ImageButton
/*  34:    */   implements UIComponent, AttributeNameConstants, View.OnLongClickListener
/*  35:    */ {
/*  36: 52 */   private static final int DEFAULT_XML_LAYOUT = com.ibm.tivoli.maximo.mobile.android.util.UIUtil.getResourceId(R.layout.class, "nimagebutton");
/*  37: 54 */   private String mobileMboAttributeName = null;
/*  38: 55 */   private String event = null;
/*  39: 56 */   private String cid = null;
/*  40: 57 */   private String targetid = null;
/*  41: 58 */   private Object value = null;
/*  42: 59 */   private AbstractMobileControl controller = null;
/*  43: 60 */   private MobileMboDataBean databean = null;
/*  44: 61 */   private String curimg = "";
/*  45: 62 */   private String image = "";
/*  46: 63 */   private String label = "";
/*  47: 64 */   private NTableListenerManager.TableClickable mTableClickable = null;
/*  48: 65 */   private TreeNodeData treeNodeData = null;
/*  49:    */   private NDrawerListenerManager.DrawerLinkClickable mDrawerClickable;
/*  50:    */   
/*  51:    */   public NImageButton(AbstractMobileControl control, Context context, String image, String label)
/*  52:    */   {
/*  53: 70 */     super(context);
/*  54: 71 */     setController(control);
/*  55: 72 */     this.image = (image == null ? "" : image);
/*  56: 73 */     this.label = (label == null ? "" : label);
/*  57: 74 */     this.curimg = image;
/*  58:    */     
/*  59: 76 */     Drawable drawable = ImageUtil.findImageFromResources(image);
/*  60: 77 */     if (drawable != null) {
/*  61: 78 */       setBackgroundDrawable(drawable);
/*  62:    */     }
/*  63: 80 */     setController(control);
/*  64: 81 */     init();
/*  65:    */   }
/*  66:    */   
/*  67:    */   public NImageButton(Context context)
/*  68:    */   {
/*  69: 85 */     super(context);
/*  70:    */   }
/*  71:    */   
/*  72:    */   public NImageButton(Context context, AttributeSet attrs)
/*  73:    */   {
/*  74: 89 */     super(context, attrs);
/*  75:    */   }
/*  76:    */   
/*  77:    */   public NImageButton(Context context, AttributeSet attrs, int defStyle)
/*  78:    */   {
/*  79: 93 */     super(context, attrs, defStyle);
/*  80:    */   }
/*  81:    */   
/*  82:    */   public static NImageButton createByInflate(AbstractMobileControl control, Context context, String image, String label)
/*  83:    */   {
/*  84: 97 */     return createByInflate(DEFAULT_XML_LAYOUT, control, context, image, label);
/*  85:    */   }
/*  86:    */   
/*  87:    */   public static NImageButton createByInflate(int layoutId, AbstractMobileControl control, Context context, String image, String label)
/*  88:    */   {
/*  89:101 */     NImageButton imagebutton = (NImageButton)View.inflate(context, layoutId, null);
/*  90:102 */     imagebutton.postInstance(control, image, label);
/*  91:103 */     return imagebutton;
/*  92:    */   }
/*  93:    */   
/*  94:    */   protected void postInstance(AbstractMobileControl control, String image, String label)
/*  95:    */   {
/*  96:107 */     setController(control);
/*  97:108 */     if (control != null)
/*  98:    */     {
/*  99:109 */       if ((control instanceof InputControl)) {
/* 100:110 */         setId(NIDMapper.getAndroidIdFor(control.getId() + "_imagebutton"));
/* 101:    */       } else {
/* 102:112 */         setId(NIDMapper.getAndroidIdFor(control.getId()));
/* 103:    */       }
/* 104:    */     }
/* 105:    */     else {
/* 106:115 */       setId(NIDMapper.getNextId());
/* 107:    */     }
/* 108:117 */     this.image = (image == null ? "" : image);
/* 109:118 */     this.label = (label == null ? "" : label);
/* 110:119 */     this.curimg = image;
/* 111:    */     
/* 112:121 */     Drawable drawable = ImageUtil.findImageFromResources(image);
/* 113:122 */     if (drawable != null) {
/* 114:123 */       setImageDrawable(drawable);
/* 115:    */     }
/* 116:128 */     setBackgroundResource(com.ibm.tivoli.maximo.mobile.android.util.UIUtil.getResourceId(R.drawable.class, "nimagebutton_background"));
/* 117:    */     
/* 118:130 */     init();
/* 119:    */   }
/* 120:    */   
/* 121:    */   public void setButtonDrawerClickable(NDrawerListenerManager.DrawerLinkClickable dc)
/* 122:    */   {
/* 123:134 */     this.mDrawerClickable = dc;
/* 124:    */   }
/* 125:    */   
/* 126:    */   public String getCId()
/* 127:    */   {
/* 128:138 */     return this.cid;
/* 129:    */   }
/* 130:    */   
/* 131:    */   public void init()
/* 132:    */   {
/* 133:142 */     setOnClickListener(new View.OnClickListener()
/* 134:    */     {
/* 135:    */       public void onClick(View v)
/* 136:    */       {
/* 137:144 */         AndroidEnv.closeCurrentPopUpPage();
/* 138:145 */         NImageButton.this.firePreListeners();
/* 139:146 */         if (NImageButton.this.getController() != null)
/* 140:    */         {
/* 141:147 */           if (NImageButton.this.isCameraEvent())
/* 142:    */           {
/* 143:148 */             NImageButton.this.firePostListeners();
/* 144:149 */             LinkControl myControl = (LinkControl)NImageButton.this.getController();
/* 145:    */             try
/* 146:    */             {
/* 147:151 */               new AttachmentIntentCameraCallback(myControl).launchIntentForResult();
/* 148:    */             }
/* 149:    */             catch (MobileApplicationException e)
/* 150:    */             {
/* 151:153 */               com.mro.mobile.ui.res.UIUtil.showFailureMessageBox(e.getCompleteMessage());
/* 152:154 */               MobileLoggerFactory.getDefaultLogger().error("Error lauching camera activity", e);
/* 153:    */             }
/* 154:156 */             return;
/* 155:    */           }
/* 156:158 */           NImageButton.this.getController().handleEvent(NImageButton.this.event, NImageButton.this.targetid, NImageButton.this.value);
/* 157:    */         }
/* 158:161 */         NImageButton.this.firePostListeners();
/* 159:    */       }
/* 160:    */     });
/* 161:    */   }
/* 162:    */   
/* 163:    */   private boolean isCameraEvent()
/* 164:    */   {
/* 165:167 */     return (this.event != null) && (this.event.equalsIgnoreCase("CAMERA"));
/* 166:    */   }
/* 167:    */   
/* 168:    */   public void notifyBarcodeInfoButton()
/* 169:    */   {
/* 170:171 */     if (isIntentedBasedBarcodeReaderEnabled()) {
/* 171:172 */       setOnLongClickListener(this);
/* 172:    */     }
/* 173:    */   }
/* 174:    */   
/* 175:    */   private boolean isIntentedBasedBarcodeReaderEnabled()
/* 176:    */   {
/* 177:177 */     return com.mro.mobile.ui.res.UIUtil.getApplication().isBarcodeReaderBasedOnIntents();
/* 178:    */   }
/* 179:    */   
/* 180:    */   protected void firePreListeners()
/* 181:    */   {
/* 182:181 */     if (this.mTableClickable != null) {
/* 183:182 */       this.mTableClickable.tableClicked(this);
/* 184:    */     }
/* 185:184 */     if (this.mButtonImageClickable != null) {
/* 186:185 */       this.mButtonImageClickable.buttonImageClicked(this);
/* 187:    */     }
/* 188:    */   }
/* 189:    */   
/* 190:    */   protected void firePostListeners()
/* 191:    */   {
/* 192:190 */     if (this.mDrawerClickable != null) {
/* 193:191 */       this.mDrawerClickable.drawerLinkClicked(this);
/* 194:    */     }
/* 195:    */   }
/* 196:    */   
/* 197:    */   public void setTableClickable(NTableListenerManager.TableClickable tc)
/* 198:    */   {
/* 199:196 */     this.mTableClickable = tc;
/* 200:    */   }
/* 201:    */   
/* 202:    */   public String getTargetId()
/* 203:    */   {
/* 204:200 */     return this.targetid;
/* 205:    */   }
/* 206:    */   
/* 207:    */   public void setTargetId(String targetid)
/* 208:    */   {
/* 209:204 */     this.targetid = targetid;
/* 210:    */   }
/* 211:    */   
/* 212:    */   public Object getValue()
/* 213:    */   {
/* 214:208 */     return this.targetid;
/* 215:    */   }
/* 216:    */   
/* 217:    */   public void setValue(Object value)
/* 218:    */   {
/* 219:212 */     this.value = value;
/* 220:    */   }
/* 221:    */   
/* 222:    */   public String getEvent()
/* 223:    */   {
/* 224:216 */     return this.event;
/* 225:    */   }
/* 226:    */   
/* 227:    */   public void setEvent(String event)
/* 228:    */   {
/* 229:220 */     this.event = event;
/* 230:    */   }
/* 231:    */   
/* 232:    */   public void addChildUIComponent(UIComponent child) {}
/* 233:    */   
/* 234:    */   public boolean canContainChildren()
/* 235:    */   {
/* 236:233 */     return false;
/* 237:    */   }
/* 238:    */   
/* 239:    */   public Enumeration getChildren()
/* 240:    */   {
/* 241:243 */     return null;
/* 242:    */   }
/* 243:    */   
/* 244:    */   public AbstractMobileControl getController()
/* 245:    */   {
/* 246:252 */     return this.controller;
/* 247:    */   }
/* 248:    */   
/* 249:    */   public void setController(AbstractMobileControl controller)
/* 250:    */   {
/* 251:263 */     this.controller = controller;
/* 252:    */   }
/* 253:    */   
/* 254:    */   public MobileMboDataBean getDataBean()
/* 255:    */     throws MobileApplicationException
/* 256:    */   {
/* 257:268 */     return this.databean;
/* 258:    */   }
/* 259:    */   
/* 260:    */   public void setCId(String cid)
/* 261:    */   {
/* 262:276 */     this.cid = cid;
/* 263:    */   }
/* 264:    */   
/* 265:279 */   private LinearLayout.LayoutParams constraints = null;
/* 266:    */   
/* 267:    */   public Object getConstraints()
/* 268:    */   {
/* 269:287 */     return this.constraints;
/* 270:    */   }
/* 271:    */   
/* 272:    */   public void setConstraints(Object consts)
/* 273:    */   {
/* 274:298 */     this.constraints = ((LinearLayout.LayoutParams)consts);
/* 275:299 */     setLayoutParams(this.constraints);
/* 276:300 */     requestLayout();
/* 277:    */   }
/* 278:    */   
/* 279:    */   public TreeNodeData getTreeNodeData()
/* 280:    */   {
/* 281:304 */     return this.treeNodeData;
/* 282:    */   }
/* 283:    */   
/* 284:    */   public void setTreeNodeData(TreeNodeData treeNodeData)
/* 285:    */   {
/* 286:308 */     this.treeNodeData = treeNodeData;
/* 287:    */   }
/* 288:    */   
/* 289:315 */   private ButtonImageClickable mButtonImageClickable = null;
/* 290:    */   
/* 291:    */   public void setButtonImageClickable(ButtonImageClickable mButtonImageClickable)
/* 292:    */   {
/* 293:318 */     this.mButtonImageClickable = mButtonImageClickable;
/* 294:    */   }
/* 295:    */   
/* 296:    */   public boolean onLongClick(View v)
/* 297:    */   {
/* 298:323 */     if (isIntentedBasedBarcodeReaderEnabled())
/* 299:    */     {
/* 300:324 */       AndroidIntentBarcodeReader reader = (AndroidIntentBarcodeReader)com.mro.mobile.ui.res.UIUtil.getApplication().getBarcodeReaderSupport().getBarcodeReader();
/* 301:    */       
/* 302:326 */       reader.launchIntentForResult();
/* 303:327 */       return true;
/* 304:    */     }
/* 305:329 */     return false;
/* 306:    */   }
/* 307:    */   
/* 308:    */   public static abstract interface ButtonImageClickable
/* 309:    */   {
/* 310:    */     public abstract void buttonImageClicked(View paramView);
/* 311:    */   }
/* 312:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.components.NImageButton
 * JD-Core Version:    0.7.0.1
 */