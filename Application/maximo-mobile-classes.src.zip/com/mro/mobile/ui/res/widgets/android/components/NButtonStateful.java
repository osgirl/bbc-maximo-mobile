/*   1:    */ package com.mro.mobile.ui.res.widgets.android.components;
/*   2:    */ 
/*   3:    */ import android.content.Context;
/*   4:    */ import android.graphics.drawable.Drawable;
/*   5:    */ import android.util.AttributeSet;
/*   6:    */ import android.view.View;
/*   7:    */ import android.view.View.OnClickListener;
/*   8:    */ import android.view.View.OnFocusChangeListener;
/*   9:    */ import android.widget.ImageButton;
/*  10:    */ import android.widget.LinearLayout.LayoutParams;
/*  11:    */ import com.ibm.tivoli.maximo.mobile.android.util.ImageUtil;
/*  12:    */ import com.ibm.tivoli.maximo.mobile.android.util.UIUtil;
/*  13:    */ import com.ibm.tivoli.maximo.mobile.resources.R.layout;
/*  14:    */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*  15:    */ import com.mro.mobile.ui.res.controls.AttributeNameConstants;
/*  16:    */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  17:    */ import java.util.Enumeration;
/*  18:    */ 
/*  19:    */ public class NButtonStateful
/*  20:    */   extends ImageButton
/*  21:    */   implements UIComponent, AttributeNameConstants
/*  22:    */ {
/*  23: 22 */   private String cid = null;
/*  24: 23 */   private String event = null;
/*  25: 24 */   private String targetid = null;
/*  26: 25 */   private Object value = null;
/*  27: 26 */   private AbstractMobileControl controller = null;
/*  28: 27 */   Drawable imgOn = null;
/*  29: 28 */   Drawable imgOff = null;
/*  30: 29 */   private static final int DEFAULT_XML_LAYOUT = UIUtil.getResourceId(R.layout.class, "nbuttonstateful");
/*  31:    */   
/*  32:    */   public NButtonStateful(Context context)
/*  33:    */   {
/*  34: 32 */     super(context);
/*  35:    */   }
/*  36:    */   
/*  37:    */   public NButtonStateful(Context context, AttributeSet attrs)
/*  38:    */   {
/*  39: 36 */     super(context, attrs);
/*  40:    */   }
/*  41:    */   
/*  42:    */   public NButtonStateful(Context context, AttributeSet attrs, int defStyle)
/*  43:    */   {
/*  44: 40 */     super(context, attrs, defStyle);
/*  45:    */   }
/*  46:    */   
/*  47:    */   public static NButtonStateful createByInflate(AbstractMobileControl control, Context context, String imageOn, String imageOff)
/*  48:    */   {
/*  49: 44 */     return createByInflate(DEFAULT_XML_LAYOUT, control, context, imageOn, imageOff);
/*  50:    */   }
/*  51:    */   
/*  52:    */   public static NButtonStateful createByInflate(int layoutId, AbstractMobileControl control, Context context, String imageOn, String imageOff)
/*  53:    */   {
/*  54: 48 */     NButtonStateful buttonstateful = (NButtonStateful)View.inflate(context, layoutId, null);
/*  55: 49 */     buttonstateful.postInstance(control, imageOn, imageOff);
/*  56: 50 */     return buttonstateful;
/*  57:    */   }
/*  58:    */   
/*  59:    */   private void postInstance(AbstractMobileControl control, String imageOn, String imageOff)
/*  60:    */   {
/*  61: 55 */     if (control != null) {
/*  62: 56 */       setId(NIDMapper.getAndroidIdFor(control.getId()));
/*  63:    */     } else {
/*  64: 58 */       setId(NIDMapper.getNextId());
/*  65:    */     }
/*  66: 61 */     this.imgOn = ImageUtil.findImageFromResources(imageOn);
/*  67: 62 */     this.imgOff = ImageUtil.findImageFromResources(imageOff);
/*  68:    */     
/*  69: 64 */     setController(control);
/*  70:    */     
/*  71: 66 */     init();
/*  72:    */   }
/*  73:    */   
/*  74:    */   public String getCId()
/*  75:    */   {
/*  76: 71 */     return this.cid;
/*  77:    */   }
/*  78:    */   
/*  79:    */   public void setCId(String cid)
/*  80:    */   {
/*  81: 76 */     this.cid = cid;
/*  82:    */   }
/*  83:    */   
/*  84:    */   public void init()
/*  85:    */   {
/*  86: 81 */     setOnClickListener(new View.OnClickListener()
/*  87:    */     {
/*  88:    */       public void onClick(View v)
/*  89:    */       {
/*  90: 83 */         if (NButtonStateful.this.imgOn != null) {
/*  91: 84 */           v.setBackgroundDrawable(NButtonStateful.this.imgOn);
/*  92:    */         }
/*  93: 86 */         NButtonStateful.this.getController().handleEvent(NButtonStateful.this.event, NButtonStateful.this.targetid, NButtonStateful.this.value);
/*  94:    */       }
/*  95: 89 */     });
/*  96: 90 */     setOnFocusChangeListener(new View.OnFocusChangeListener()
/*  97:    */     {
/*  98:    */       public void onFocusChange(View v, boolean hasFocus)
/*  99:    */       {
/* 100: 92 */         if ((!hasFocus) && 
/* 101: 93 */           (NButtonStateful.this.imgOff != null)) {
/* 102: 94 */           v.setBackgroundDrawable(NButtonStateful.this.imgOff);
/* 103:    */         }
/* 104:    */       }
/* 105:    */     });
/* 106:    */   }
/* 107:    */   
/* 108:    */   public void addChildUIComponent(UIComponent child) {}
/* 109:    */   
/* 110:    */   public boolean canContainChildren()
/* 111:    */   {
/* 112:107 */     return false;
/* 113:    */   }
/* 114:    */   
/* 115:    */   public Enumeration getChildren()
/* 116:    */   {
/* 117:112 */     return null;
/* 118:    */   }
/* 119:    */   
/* 120:    */   public AbstractMobileControl getController()
/* 121:    */   {
/* 122:117 */     return this.controller;
/* 123:    */   }
/* 124:    */   
/* 125:    */   public void setController(AbstractMobileControl controller)
/* 126:    */   {
/* 127:122 */     this.controller = controller;
/* 128:    */   }
/* 129:    */   
/* 130:    */   public Object getValue()
/* 131:    */   {
/* 132:126 */     return this.value;
/* 133:    */   }
/* 134:    */   
/* 135:    */   public void setValue(Object value)
/* 136:    */   {
/* 137:130 */     this.value = value;
/* 138:    */   }
/* 139:    */   
/* 140:    */   public String getTargetId()
/* 141:    */   {
/* 142:135 */     return this.targetid;
/* 143:    */   }
/* 144:    */   
/* 145:    */   public void setTargetId(String targetid)
/* 146:    */   {
/* 147:140 */     this.targetid = targetid;
/* 148:    */   }
/* 149:    */   
/* 150:    */   public String getEvent()
/* 151:    */   {
/* 152:144 */     return this.event;
/* 153:    */   }
/* 154:    */   
/* 155:    */   public void setEvent(String event)
/* 156:    */   {
/* 157:148 */     this.event = event;
/* 158:    */   }
/* 159:    */   
/* 160:151 */   private LinearLayout.LayoutParams constraints = null;
/* 161:    */   
/* 162:    */   public Object getConstraints()
/* 163:    */   {
/* 164:159 */     return this.constraints;
/* 165:    */   }
/* 166:    */   
/* 167:    */   public void setConstraints(Object consts)
/* 168:    */   {
/* 169:170 */     this.constraints = ((LinearLayout.LayoutParams)consts);
/* 170:171 */     setLayoutParams(this.constraints);
/* 171:172 */     requestLayout();
/* 172:    */   }
/* 173:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.components.NButtonStateful
 * JD-Core Version:    0.7.0.1
 */