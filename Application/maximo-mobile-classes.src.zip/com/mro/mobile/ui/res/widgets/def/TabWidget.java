package com.mro.mobile.ui.res.widgets.def;

import com.mro.mobile.MobileApplicationException;
import com.mro.mobile.ui.event.UIEvent;
import java.util.ArrayList;

public abstract interface TabWidget
{
  public abstract void createTabPanel(String paramString);
  
  public abstract boolean isTabPanelVisible();
  
  public abstract void setPanelLayoutForCurrentTab();
  
  public abstract void addComponentToCurrentTab(UIComponent paramUIComponent);
  
  public abstract void addControlsToTabPanel(ArrayList paramArrayList);
  
  public abstract void addControlsToSouthPanel(ArrayList paramArrayList);
  
  public abstract boolean performEvent(UIEvent paramUIEvent)
    throws MobileApplicationException;
  
  public abstract UIComponent[] resolveTabComponents();
  
  public abstract void addControlsToTab();
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.def.TabWidget
 * JD-Core Version:    0.7.0.1
 */