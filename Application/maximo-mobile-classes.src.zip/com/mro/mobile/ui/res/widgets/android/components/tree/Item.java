/*  1:   */ package com.mro.mobile.ui.res.widgets.android.components.tree;
/*  2:   */ 
/*  3:   */ public class Item
/*  4:   */ {
/*  5:   */   private Object value;
/*  6:   */   
/*  7:   */   public Item()
/*  8:   */   {
/*  9:15 */     this((Object)null);
/* 10:   */   }
/* 11:   */   
/* 12:   */   public Item(Object value)
/* 13:   */   {
/* 14:23 */     setValue(value);
/* 15:   */   }
/* 16:   */   
/* 17:   */   public Item(Item item)
/* 18:   */   {
/* 19:31 */     this(item.value);
/* 20:   */   }
/* 21:   */   
/* 22:   */   public Object getValue()
/* 23:   */   {
/* 24:39 */     return this.value;
/* 25:   */   }
/* 26:   */   
/* 27:   */   public String toString()
/* 28:   */   {
/* 29:43 */     return super.toString() + "::Value:" + this.value;
/* 30:   */   }
/* 31:   */   
/* 32:   */   protected void setValue(Object v)
/* 33:   */   {
/* 34:51 */     this.value = v;
/* 35:   */   }
/* 36:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.components.tree.Item
 * JD-Core Version:    0.7.0.1
 */