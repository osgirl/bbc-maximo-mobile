package com.mro.mobile.ui.res.widgets.def;

import com.mro.mobile.MobileApplicationException;

public abstract interface MultiLineTextboxWidget
  extends TextboxWidget
{
  public abstract UIComponent[] resolveMultiLineTextboxComponents()
    throws MobileApplicationException;
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.def.MultiLineTextboxWidget
 * JD-Core Version:    0.7.0.1
 */