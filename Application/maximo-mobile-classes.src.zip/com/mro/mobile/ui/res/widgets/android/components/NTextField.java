/*   1:    */ package com.mro.mobile.ui.res.widgets.android.components;
/*   2:    */ 
/*   3:    */ import android.content.Context;
/*   4:    */ import android.text.InputFilter;
/*   5:    */ import android.text.InputFilter.LengthFilter;
/*   6:    */ import android.util.AttributeSet;
/*   7:    */ import android.view.KeyEvent;
/*   8:    */ import android.view.View;
/*   9:    */ import android.view.View.OnClickListener;
/*  10:    */ import android.view.View.OnFocusChangeListener;
/*  11:    */ import android.view.View.OnKeyListener;
/*  12:    */ import android.view.View.OnLongClickListener;
/*  13:    */ import android.widget.EditText;
/*  14:    */ import android.widget.LinearLayout.LayoutParams;
/*  15:    */ import com.ibm.tivoli.maximo.mobile.android.sensor.AndroidIntentBarcodeReader;
/*  16:    */ import com.ibm.tivoli.maximo.mobile.resources.R.drawable;
/*  17:    */ import com.ibm.tivoli.maximo.mobile.resources.R.integer;
/*  18:    */ import com.mro.mobile.app.BasicMobileDeviceUIApplication;
/*  19:    */ import com.mro.mobile.mbo.MobileMboAttributeInfo;
/*  20:    */ import com.mro.mobile.mbo.MobileMboInfo;
/*  21:    */ import com.mro.mobile.sensor.barcode.MobileBarcodeReaderWrapper;
/*  22:    */ import com.mro.mobile.ui.MobileMboDataBean;
/*  23:    */ import com.mro.mobile.ui.event.UIEvent;
/*  24:    */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*  25:    */ import com.mro.mobile.ui.res.controls.FocusableControl;
/*  26:    */ import com.mro.mobile.ui.res.controls.InputControl;
/*  27:    */ import com.mro.mobile.ui.res.controls.PageControl;
/*  28:    */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  29:    */ import com.mro.mobile.util.StringUtils;
/*  30:    */ import java.util.Enumeration;
/*  31:    */ 
/*  32:    */ public class NTextField
/*  33:    */   extends EditText
/*  34:    */   implements UIComponent, View.OnFocusChangeListener, View.OnKeyListener, View.OnLongClickListener
/*  35:    */ {
/*  36:    */   public static final int SHOWBOX = 1;
/*  37:    */   public static final int MULTILINE = 2;
/*  38:    */   public static final int SIZE_COL_BASED = 4;
/*  39: 50 */   private String cid = null;
/*  40: 52 */   protected AbstractMobileControl controller = null;
/*  41: 54 */   protected boolean multiLine = false;
/*  42: 56 */   protected int maxCol = 0;
/*  43: 57 */   protected int size = 0;
/*  44: 58 */   protected int fieldWidth = 0;
/*  45: 60 */   protected String origText = "";
/*  46: 62 */   protected boolean invalid = false;
/*  47:    */   
/*  48:    */   public NTextField(Context context)
/*  49:    */   {
/*  50: 65 */     super(context);
/*  51:    */   }
/*  52:    */   
/*  53:    */   public NTextField(Context context, AttributeSet attrs)
/*  54:    */   {
/*  55: 69 */     super(context, attrs);
/*  56:    */   }
/*  57:    */   
/*  58:    */   public NTextField(Context context, AttributeSet attrs, int defStyle)
/*  59:    */   {
/*  60: 73 */     super(context, attrs, defStyle);
/*  61:    */   }
/*  62:    */   
/*  63:    */   public NTextField(AbstractMobileControl control, Context context, String text, int maxCol, int size, int flags)
/*  64:    */   {
/*  65: 77 */     super(context);
/*  66: 78 */     postInstance(context, control, text, maxCol, size, flags);
/*  67:    */   }
/*  68:    */   
/*  69:    */   public void postInstance(Context context, AbstractMobileControl control, String text, int maxCol, int size, int flags)
/*  70:    */   {
/*  71: 82 */     setController(control);
/*  72: 83 */     if (control != null) {
/*  73: 84 */       setId(NIDMapper.getAndroidIdFor(control.getId()));
/*  74:    */     } else {
/*  75: 87 */       setId(NIDMapper.getNextId());
/*  76:    */     }
/*  77: 89 */     this.maxCol = maxCol;
/*  78: 90 */     if ((0x4 & flags) == 4) {
/*  79: 91 */       this.size = size;
/*  80:    */     } else {
/*  81: 93 */       this.fieldWidth = size;
/*  82:    */     }
/*  83: 94 */     this.multiLine = ((0x2 & flags) == 2);
/*  84:    */     
/*  85: 96 */     init();
/*  86:    */     
/*  87: 98 */     setBackgroundResource(com.ibm.tivoli.maximo.mobile.android.util.UIUtil.getResourceId(R.drawable.class, "ntextfield_selector"));
/*  88:    */     
/*  89:100 */     setUpField(text);
/*  90:    */   }
/*  91:    */   
/*  92:    */   private void setUpField(String text)
/*  93:    */   {
/*  94:105 */     setClickable(true);
/*  95:    */     
/*  96:    */ 
/*  97:108 */     setEnabled(true);
/*  98:110 */     if (((InputControl)getController()).isReadOnly())
/*  99:    */     {
/* 100:112 */       setEditable(false);
/* 101:114 */       if (!StringUtils.isStringEmpty(text)) {
/* 102:115 */         setOnClickListener(new View.OnClickListener()
/* 103:    */         {
/* 104:    */           public void onClick(View v)
/* 105:    */           {
/* 106:117 */             String textToShow = ((EditText)v).getText().toString();
/* 107:118 */             com.mro.mobile.ui.res.UIUtil.showInfoMessageBox(textToShow);
/* 108:    */           }
/* 109:    */         });
/* 110:    */       }
/* 111:    */     }
/* 112:124 */     if (((InputControl)getController()).isPassword())
/* 113:    */     {
/* 114:125 */       setInputType(129);
/* 115:126 */       setTheText(text);
/* 116:    */     }
/* 117:    */     else
/* 118:    */     {
/* 119:128 */       setTheText(text);
/* 120:    */     }
/* 121:132 */     int minEms = com.ibm.tivoli.maximo.mobile.android.util.UIUtil.getIntegerFromResource(R.integer.class, "textfield_minems");
/* 122:133 */     int maxEms = com.ibm.tivoli.maximo.mobile.android.util.UIUtil.getIntegerFromResource(R.integer.class, "textfield_maxems");
/* 123:    */     
/* 124:135 */     setMinEms(minEms);
/* 125:136 */     setMaxEms(maxEms);
/* 126:    */     
/* 127:138 */     setOnFocusChangeListener(this);
/* 128:139 */     setOnKeyListener(this);
/* 129:141 */     if (isIntentedBasedBarcodeReaderEnabled()) {
/* 130:142 */       setOnLongClickListener(this);
/* 131:    */     }
/* 132:    */   }
/* 133:    */   
/* 134:    */   public void setTheText(String text)
/* 135:    */   {
/* 136:147 */     super.setText(text);
/* 137:148 */     this.origText = text;
/* 138:    */   }
/* 139:    */   
/* 140:    */   public String getCId()
/* 141:    */   {
/* 142:152 */     return this.cid;
/* 143:    */   }
/* 144:    */   
/* 145:    */   public void setCId(String id)
/* 146:    */   {
/* 147:156 */     this.cid = id;
/* 148:    */   }
/* 149:    */   
/* 150:    */   public void init()
/* 151:    */   {
/* 152:160 */     setCursorVisible(true);
/* 153:    */     
/* 154:162 */     setSingleLine(!this.multiLine);
/* 155:163 */     if (this.maxCol > 0) {
/* 156:164 */       setFilters(new InputFilter[] { new InputFilter.LengthFilter(this.maxCol) });
/* 157:    */     }
/* 158:167 */     setLayoutParams(new LinearLayout.LayoutParams(-2, -2));
/* 159:    */     
/* 160:169 */     setInputType();
/* 161:    */   }
/* 162:    */   
/* 163:    */   private void setInputType()
/* 164:    */   {
/* 165:    */     try
/* 166:    */     {
/* 167:177 */       if ((getController() != null) && (getController().getDataBean() != null))
/* 168:    */       {
/* 169:178 */         String attrName = getController().getStringValue("dataattribute");
/* 170:    */         
/* 171:180 */         MobileMboAttributeInfo info = getController().getDataBean().getMobileMboInfo().getAttributeInfo(attrName);
/* 172:182 */         if (info == null) {
/* 173:183 */           return;
/* 174:    */         }
/* 175:186 */         switch (info.getDataType())
/* 176:    */         {
/* 177:    */         case 4: 
/* 178:    */         case 5: 
/* 179:191 */           setInputType(4098);
/* 180:192 */           break;
/* 181:    */         case 6: 
/* 182:    */         case 7: 
/* 183:197 */           setInputType(12290);
/* 184:    */         }
/* 185:    */       }
/* 186:    */     }
/* 187:    */     catch (Exception e) {}
/* 188:    */   }
/* 189:    */   
/* 190:    */   public void refreshText(String value)
/* 191:    */   {
/* 192:210 */     if (value == null) {
/* 193:211 */       value = "";
/* 194:    */     }
/* 195:214 */     if ((value.equals("")) || (!value.equals(this.origText))) {
/* 196:215 */       if ((!hasFocus()) && (isEditable()) && ((value == null) || (value.length() == 0))) {
/* 197:216 */         setTheText("");
/* 198:    */       } else {
/* 199:218 */         setTheText(value);
/* 200:    */       }
/* 201:    */     }
/* 202:    */   }
/* 203:    */   
/* 204:    */   public void addChildUIComponent(UIComponent child) {}
/* 205:    */   
/* 206:    */   public boolean canContainChildren()
/* 207:    */   {
/* 208:227 */     return false;
/* 209:    */   }
/* 210:    */   
/* 211:    */   public Enumeration getChildren()
/* 212:    */   {
/* 213:231 */     return null;
/* 214:    */   }
/* 215:    */   
/* 216:    */   public AbstractMobileControl getController()
/* 217:    */   {
/* 218:235 */     return this.controller;
/* 219:    */   }
/* 220:    */   
/* 221:    */   public void setController(AbstractMobileControl controller)
/* 222:    */   {
/* 223:239 */     this.controller = controller;
/* 224:    */   }
/* 225:    */   
/* 226:242 */   private LinearLayout.LayoutParams constraints = null;
/* 227:243 */   private boolean forceCleanUpOnInvalid = true;
/* 228:    */   
/* 229:    */   public Object getConstraints()
/* 230:    */   {
/* 231:246 */     return this.constraints;
/* 232:    */   }
/* 233:    */   
/* 234:    */   public void setConstraints(Object consts)
/* 235:    */   {
/* 236:250 */     this.constraints = ((LinearLayout.LayoutParams)consts);
/* 237:251 */     setLayoutParams(this.constraints);
/* 238:252 */     requestLayout();
/* 239:    */   }
/* 240:    */   
/* 241:    */   public void setEditable(boolean editable)
/* 242:    */   {
/* 243:256 */     setFocusable(editable);
/* 244:257 */     setFocusableInTouchMode(editable);
/* 245:    */     
/* 246:259 */     String bgResourceName = editable ? "ntextfield_selector" : "ntextfield_readonly";
/* 247:260 */     setBackgroundResource(com.ibm.tivoli.maximo.mobile.android.util.UIUtil.getResourceId(R.drawable.class, bgResourceName));
/* 248:    */   }
/* 249:    */   
/* 250:    */   public boolean isEditable()
/* 251:    */   {
/* 252:264 */     return (isFocusable()) && (isFocusableInTouchMode()) && (isClickable());
/* 253:    */   }
/* 254:    */   
/* 255:    */   public void onFocusChange(View v, boolean hasFocus)
/* 256:    */   {
/* 257:269 */     if ((hasFocus) && 
/* 258:270 */       ((this.controller instanceof FocusableControl)) && 
/* 259:271 */       (!AbstractMobileControl.isUiTestMode())) {
/* 260:272 */       ((PageControl)com.mro.mobile.ui.res.UIUtil.getCurrentScreen()).setCurrentInput(this.controller);
/* 261:    */     }
/* 262:    */   }
/* 263:    */   
/* 264:    */   public boolean sendSetValue()
/* 265:    */   {
/* 266:279 */     if ((isEditable()) && (isEnabled()))
/* 267:    */     {
/* 268:280 */       String text = getText().toString().trim();
/* 269:281 */       if ((!areEqual(text, this.origText)) && (getController() != null))
/* 270:    */       {
/* 271:282 */         String value = text;
/* 272:283 */         UIEvent event = new UIEvent(getController(), "setvalue", null, value);
/* 273:284 */         getController().handleEvent(event);
/* 274:285 */         this.invalid = event.errorOccured();
/* 275:    */       }
/* 276:    */       else
/* 277:    */       {
/* 278:287 */         this.invalid = false;
/* 279:    */       }
/* 280:290 */       if ((this.invalid) && 
/* 281:291 */         (this.forceCleanUpOnInvalid)) {
/* 282:292 */         refreshText(null);
/* 283:    */       }
/* 284:296 */       return !this.invalid;
/* 285:    */     }
/* 286:298 */     return true;
/* 287:    */   }
/* 288:    */   
/* 289:    */   private boolean areEqual(String str1, String str2)
/* 290:    */   {
/* 291:302 */     if (str1 != null) {
/* 292:303 */       return str1.equals(str2);
/* 293:    */     }
/* 294:304 */     if (str2 == null) {
/* 295:305 */       return true;
/* 296:    */     }
/* 297:306 */     return false;
/* 298:    */   }
/* 299:    */   
/* 300:    */   public void setInvalid(boolean b)
/* 301:    */   {
/* 302:310 */     this.invalid = b;
/* 303:    */   }
/* 304:    */   
/* 305:    */   public boolean isInvalid()
/* 306:    */   {
/* 307:314 */     return this.invalid;
/* 308:    */   }
/* 309:    */   
/* 310:    */   public boolean onKey(View v, int keyCode, KeyEvent event)
/* 311:    */   {
/* 312:319 */     if (needValidationWithKeyStroke(keyCode)) {
/* 313:320 */       sendSetValue();
/* 314:    */     }
/* 315:322 */     if (keyCode == 67) {
/* 316:323 */       this.invalid = false;
/* 317:    */     }
/* 318:326 */     if (this.invalid) {
/* 319:327 */       if (this.forceCleanUpOnInvalid) {
/* 320:328 */         refreshText(null);
/* 321:    */       } else {
/* 322:331 */         resetCleanUpOnInvalid();
/* 323:    */       }
/* 324:    */     }
/* 325:334 */     return (this.invalid) && (keyCode != 4);
/* 326:    */   }
/* 327:    */   
/* 328:    */   protected boolean needValidationWithKeyStroke(int keyCode)
/* 329:    */   {
/* 330:338 */     boolean reply = false;
/* 331:339 */     switch (keyCode)
/* 332:    */     {
/* 333:    */     case 66: 
/* 334:341 */       reply = true;
/* 335:342 */       break;
/* 336:    */     }
/* 337:348 */     return reply;
/* 338:    */   }
/* 339:    */   
/* 340:    */   public int getHeightByRows(int rows)
/* 341:    */   {
/* 342:352 */     return rows * getHeight() + (rows - 1) * (int)(getHeight() * 0.15D);
/* 343:    */   }
/* 344:    */   
/* 345:    */   private boolean isIntentedBasedBarcodeReaderEnabled()
/* 346:    */   {
/* 347:356 */     return com.mro.mobile.ui.res.UIUtil.getApplication().isBarcodeReaderBasedOnIntents();
/* 348:    */   }
/* 349:    */   
/* 350:    */   public boolean onLongClick(View v)
/* 351:    */   {
/* 352:362 */     if (isIntentedBasedBarcodeReaderEnabled())
/* 353:    */     {
/* 354:363 */       requestFocus();
/* 355:364 */       AndroidIntentBarcodeReader reader = (AndroidIntentBarcodeReader)com.mro.mobile.ui.res.UIUtil.getApplication().getBarcodeReaderSupport().getBarcodeReader();
/* 356:365 */       reader.launchIntentForResult();
/* 357:366 */       return true;
/* 358:    */     }
/* 359:368 */     return false;
/* 360:    */   }
/* 361:    */   
/* 362:    */   public void forceCleanUpOnInvalid(boolean cleanup)
/* 363:    */   {
/* 364:372 */     this.forceCleanUpOnInvalid = cleanup;
/* 365:    */   }
/* 366:    */   
/* 367:    */   protected void resetCleanUpOnInvalid()
/* 368:    */   {
/* 369:376 */     this.forceCleanUpOnInvalid = true;
/* 370:    */   }
/* 371:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.components.NTextField
 * JD-Core Version:    0.7.0.1
 */