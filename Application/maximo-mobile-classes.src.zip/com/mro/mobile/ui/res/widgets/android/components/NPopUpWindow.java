/*  1:   */ package com.mro.mobile.ui.res.widgets.android.components;
/*  2:   */ 
/*  3:   */ import android.app.Dialog;
/*  4:   */ import android.content.Context;
/*  5:   */ import android.graphics.drawable.ColorDrawable;
/*  6:   */ import android.view.Window;
/*  7:   */ import com.mro.mobile.ui.res.android.DefaultBackButtonListener;
/*  8:   */ 
/*  9:   */ public class NPopUpWindow
/* 10:   */   extends Dialog
/* 11:   */ {
/* 12:   */   public NPopUpWindow(Context context)
/* 13:   */   {
/* 14:28 */     this(context, false);
/* 15:   */   }
/* 16:   */   
/* 17:   */   public NPopUpWindow(Context context, boolean hideTitle)
/* 18:   */   {
/* 19:32 */     super(context);
/* 20:33 */     setCanceledOnTouchOutside(false);
/* 21:34 */     setOnKeyListener(DefaultBackButtonListener.getInstance());
/* 22:36 */     if (hideTitle) {
/* 23:37 */       requestWindowFeature(1);
/* 24:   */     }
/* 25:39 */     getWindow().setBackgroundDrawable(new ColorDrawable(0));
/* 26:   */   }
/* 27:   */   
/* 28:   */   public void enableBackButton()
/* 29:   */   {
/* 30:43 */     setOnKeyListener(null);
/* 31:   */   }
/* 32:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.components.NPopUpWindow
 * JD-Core Version:    0.7.0.1
 */