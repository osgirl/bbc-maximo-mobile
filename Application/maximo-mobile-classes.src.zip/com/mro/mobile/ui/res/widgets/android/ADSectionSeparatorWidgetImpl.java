/*  1:   */ package com.mro.mobile.ui.res.widgets.android;
/*  2:   */ 
/*  3:   */ import android.view.ViewGroup.LayoutParams;
/*  4:   */ import com.mro.mobile.ui.res.controls.SectionSeparatorControl;
/*  5:   */ import com.mro.mobile.ui.res.widgets.android.components.NSeparator;
/*  6:   */ import com.mro.mobile.ui.res.widgets.def.SectionSeparatorWidget;
/*  7:   */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  8:   */ 
/*  9:   */ public class ADSectionSeparatorWidgetImpl
/* 10:   */   extends ADAbstractWidgetImpl
/* 11:   */   implements SectionSeparatorWidget
/* 12:   */ {
/* 13:12 */   private NSeparator sepView = null;
/* 14:13 */   private int preferredWidth = 0;
/* 15:14 */   private int preferredHeight = 0;
/* 16:   */   
/* 17:   */   public void createSectionSeparator(SectionSeparatorControl control)
/* 18:   */   {
/* 19:18 */     this.sepView = NSeparator.createByInflate(control, AndroidEnv.getCurrentActivity());
/* 20:   */   }
/* 21:   */   
/* 22:   */   public void setOpaque(boolean state)
/* 23:   */   {
/* 24:23 */     this.sepView.setOpaque(state);
/* 25:   */   }
/* 26:   */   
/* 27:   */   public void setInsets(int top, int left, int bottom, int right)
/* 28:   */   {
/* 29:28 */     this.sepView.setInsets(top, left, bottom, right);
/* 30:   */   }
/* 31:   */   
/* 32:   */   public void setPreferredSize(int width, int height)
/* 33:   */   {
/* 34:33 */     this.preferredWidth = width;
/* 35:   */     
/* 36:35 */     this.preferredHeight = 2;
/* 37:36 */     this.sepView.setConstraints(new ViewGroup.LayoutParams(this.preferredWidth, this.preferredHeight));
/* 38:   */   }
/* 39:   */   
/* 40:   */   public UIComponent[] resolveSectionSeparatorWidgetComponents()
/* 41:   */   {
/* 42:41 */     return new UIComponent[] { this.sepView };
/* 43:   */   }
/* 44:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.ADSectionSeparatorWidgetImpl
 * JD-Core Version:    0.7.0.1
 */