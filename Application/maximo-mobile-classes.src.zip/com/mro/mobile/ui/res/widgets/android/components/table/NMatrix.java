/*   1:    */ package com.mro.mobile.ui.res.widgets.android.components.table;
/*   2:    */ 
/*   3:    */ public class NMatrix
/*   4:    */   implements NMatrixModel
/*   5:    */ {
/*   6:    */   private Object[][] objs;
/*   7:    */   private int rows;
/*   8:    */   private int cols;
/*   9:    */   private int alloc_rows;
/*  10:    */   private int alloc_cols;
/*  11:    */   
/*  12:    */   public NMatrix(int rows, int cols)
/*  13:    */   {
/*  14: 15 */     setSize(rows, cols);
/*  15:    */   }
/*  16:    */   
/*  17:    */   public int getRows()
/*  18:    */   {
/*  19: 23 */     return this.rows;
/*  20:    */   }
/*  21:    */   
/*  22:    */   public int getCols()
/*  23:    */   {
/*  24: 31 */     return this.cols;
/*  25:    */   }
/*  26:    */   
/*  27:    */   public void setRows(int rows)
/*  28:    */   {
/*  29: 39 */     setSize(rows, this.cols);
/*  30:    */   }
/*  31:    */   
/*  32:    */   public void setCols(int cols)
/*  33:    */   {
/*  34: 47 */     setSize(this.rows, cols);
/*  35:    */   }
/*  36:    */   
/*  37:    */   public void setSize(int rows, int cols)
/*  38:    */   {
/*  39: 57 */     if ((rows != this.rows) || (cols != this.cols))
/*  40:    */     {
/*  41: 59 */       if ((this.alloc_cols < cols) || (this.alloc_rows < rows))
/*  42:    */       {
/*  43: 62 */         Object[][] nobjs = new Object[rows][cols];
/*  44:    */         
/*  45: 64 */         this.alloc_cols = cols;
/*  46: 65 */         this.alloc_rows = rows;
/*  47: 66 */         if (this.objs != null) {
/*  48: 66 */           copy(this.objs, nobjs);
/*  49:    */         }
/*  50: 67 */         this.objs = nobjs;
/*  51:    */       }
/*  52:    */       else
/*  53:    */       {
/*  54: 71 */         if (cols < this.cols) {
/*  55: 73 */           for (int i = cols; i < this.cols; i++) {
/*  56: 74 */             for (int j = 0; j < this.rows; j++) {
/*  57: 75 */               this.objs[j][i] = null;
/*  58:    */             }
/*  59:    */           }
/*  60:    */         }
/*  61: 78 */         if (rows < this.rows) {
/*  62: 80 */           for (int i = 0; i < cols; i++) {
/*  63: 81 */             for (int j = rows; j < this.rows; j++) {
/*  64: 82 */               this.objs[j][i] = null;
/*  65:    */             }
/*  66:    */           }
/*  67:    */         }
/*  68:    */       }
/*  69: 86 */       int pc = this.cols;
/*  70: 87 */       int pr = this.rows;
/*  71: 88 */       this.cols = cols;
/*  72: 89 */       this.rows = rows;
/*  73:    */     }
/*  74:    */   }
/*  75:    */   
/*  76:    */   public void put(int row, int col, Object obj)
/*  77:    */   {
/*  78:103 */     int nr = getRows();
/*  79:104 */     int nc = getCols();
/*  80:105 */     if (row >= nr) {
/*  81:105 */       nr += row - nr + 1;
/*  82:    */     }
/*  83:106 */     if (col >= nc) {
/*  84:106 */       nc += col - nc + 1;
/*  85:    */     }
/*  86:107 */     setSize(nr, nc);
/*  87:    */     
/*  88:109 */     Object old = this.objs[row][col];
/*  89:110 */     if (((obj == null) && (obj != old)) || ((obj != null) && (!obj.equals(old)))) {
/*  90:113 */       this.objs[row][col] = obj;
/*  91:    */     }
/*  92:    */   }
/*  93:    */   
/*  94:    */   public Object get(int row, int col)
/*  95:    */   {
/*  96:125 */     return this.objs[row][col];
/*  97:    */   }
/*  98:    */   
/*  99:    */   public void removeRows(int begrow, int count)
/* 100:    */   {
/* 101:130 */     if ((begrow < 0) || (begrow + count > this.rows)) {
/* 102:130 */       throw new IllegalArgumentException();
/* 103:    */     }
/* 104:132 */     for (int i = begrow + count; i < this.rows; begrow++)
/* 105:    */     {
/* 106:134 */       for (int j = 0; j < this.cols; j++)
/* 107:    */       {
/* 108:136 */         this.objs[begrow][j] = this.objs[i][j];
/* 109:137 */         this.objs[i][j] = null;
/* 110:    */       }
/* 111:132 */       i++;
/* 112:    */     }
/* 113:140 */     this.rows -= count;
/* 114:    */   }
/* 115:    */   
/* 116:    */   public void removeCols(int begcol, int count)
/* 117:    */   {
/* 118:145 */     if ((begcol < 0) || (begcol + count > this.cols)) {
/* 119:145 */       throw new IllegalArgumentException();
/* 120:    */     }
/* 121:147 */     for (int i = begcol + count; i < this.cols; begcol++)
/* 122:    */     {
/* 123:149 */       for (int j = 0; j < this.rows; j++)
/* 124:    */       {
/* 125:151 */         this.objs[j][begcol] = this.objs[j][i];
/* 126:152 */         this.objs[j][i] = null;
/* 127:    */       }
/* 128:147 */       i++;
/* 129:    */     }
/* 130:155 */     this.cols -= count;
/* 131:    */   }
/* 132:    */   
/* 133:    */   private void copy(Object[][] s, Object[][] d)
/* 134:    */   {
/* 135:161 */     if ((s != null) && (d != null))
/* 136:    */     {
/* 137:163 */       int rows = Math.min(s.length, d.length);
/* 138:164 */       int cols = Math.min(s.length > 0 ? ((Object[])s[0]).length : 0, d.length > 0 ? ((Object[])d[0]).length : 0);
/* 139:167 */       for (int i = 0; i < rows; i++) {
/* 140:168 */         for (int j = 0; j < cols; j++) {
/* 141:169 */           d[i][j] = s[i][j];
/* 142:    */         }
/* 143:    */       }
/* 144:    */     }
/* 145:    */   }
/* 146:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.components.table.NMatrix
 * JD-Core Version:    0.7.0.1
 */