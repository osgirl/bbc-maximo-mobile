package com.mro.mobile.ui.res.widgets.def;

import com.mro.mobile.MobileApplicationException;

public abstract interface MenuWidget
  extends AbstractWidget
{
  public abstract void createMenu(String paramString1, String paramString2);
  
  public abstract void setMenuId(String paramString);
  
  public abstract void setMenuLabel(String paramString);
  
  public abstract String getMenuLabel();
  
  public abstract void buildMenu()
    throws MobileApplicationException;
  
  public abstract void refreshMenu();
  
  public abstract UIComponent[] resolveMenuComponents()
    throws MobileApplicationException;
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.def.MenuWidget
 * JD-Core Version:    0.7.0.1
 */