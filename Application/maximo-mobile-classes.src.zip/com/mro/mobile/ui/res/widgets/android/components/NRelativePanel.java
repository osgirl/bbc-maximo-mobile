/*   1:    */ package com.mro.mobile.ui.res.widgets.android.components;
/*   2:    */ 
/*   3:    */ import android.content.Context;
/*   4:    */ import android.graphics.Color;
/*   5:    */ import android.graphics.drawable.Drawable;
/*   6:    */ import android.util.AttributeSet;
/*   7:    */ import android.view.View;
/*   8:    */ import android.widget.RelativeLayout;
/*   9:    */ import android.widget.RelativeLayout.LayoutParams;
/*  10:    */ import com.ibm.tivoli.maximo.mobile.android.util.ImageUtil;
/*  11:    */ import com.ibm.tivoli.maximo.mobile.android.util.UIUtil;
/*  12:    */ import com.ibm.tivoli.maximo.mobile.resources.R.layout;
/*  13:    */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*  14:    */ import com.mro.mobile.ui.res.controls.PageControl;
/*  15:    */ import com.mro.mobile.ui.res.controls.SectionControl;
/*  16:    */ import com.mro.mobile.ui.res.controls.utils.ControlStyle;
/*  17:    */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  18:    */ import java.util.Enumeration;
/*  19:    */ import java.util.Stack;
/*  20:    */ import java.util.Vector;
/*  21:    */ 
/*  22:    */ public class NRelativePanel
/*  23:    */   extends RelativeLayout
/*  24:    */   implements UIComponent
/*  25:    */ {
/*  26: 54 */   protected AbstractMobileControl controller = null;
/*  27:    */   public static final int INFINITE = -1;
/*  28: 56 */   private static final int DEFAULT_XML_LAYOUT = UIUtil.getResourceId(R.layout.class, "nrelativepanel");
/*  29: 58 */   private String cid = null;
/*  30: 59 */   private Vector children = new Vector();
/*  31: 60 */   private ControlStyle style = null;
/*  32: 62 */   private int numOfKids = 0;
/*  33: 63 */   private Stack<View> allKidViews = new Stack();
/*  34: 64 */   private int currentId = 0;
/*  35:    */   
/*  36:    */   public NRelativePanel(Context context)
/*  37:    */   {
/*  38: 67 */     super(context);
/*  39:    */   }
/*  40:    */   
/*  41:    */   public NRelativePanel(Context context, AttributeSet attrs)
/*  42:    */   {
/*  43: 71 */     super(context, attrs);
/*  44:    */   }
/*  45:    */   
/*  46:    */   public static NRelativePanel createByInflate(AbstractMobileControl control, Context context, int numOfKids)
/*  47:    */   {
/*  48: 75 */     return createByInflate(DEFAULT_XML_LAYOUT, control, context, numOfKids);
/*  49:    */   }
/*  50:    */   
/*  51:    */   public static NRelativePanel createByInflate(int layoutId, AbstractMobileControl control, Context context, int numOfKids)
/*  52:    */   {
/*  53: 79 */     NRelativePanel panel = (NRelativePanel)View.inflate(context, layoutId, null);
/*  54: 80 */     panel.postInstance(control, numOfKids);
/*  55: 81 */     return panel;
/*  56:    */   }
/*  57:    */   
/*  58:    */   protected void postInstance(AbstractMobileControl control, int numOfKids)
/*  59:    */   {
/*  60: 85 */     setController(control);
/*  61: 86 */     this.numOfKids = numOfKids;
/*  62: 87 */     if (control != null)
/*  63:    */     {
/*  64: 88 */       if (((control instanceof PageControl)) || ((control instanceof SectionControl))) {
/*  65: 89 */         setId(NIDMapper.getAndroidIdFor(control.getId()));
/*  66:    */       } else {
/*  67: 91 */         setId(NIDMapper.getNextId());
/*  68:    */       }
/*  69:    */     }
/*  70:    */     else {
/*  71: 95 */       setId(NIDMapper.getNextId());
/*  72:    */     }
/*  73: 98 */     init();
/*  74:    */   }
/*  75:    */   
/*  76:    */   public String getCId()
/*  77:    */   {
/*  78:103 */     return this.cid;
/*  79:    */   }
/*  80:    */   
/*  81:    */   public void setCId(String cid)
/*  82:    */   {
/*  83:107 */     this.cid = cid;
/*  84:    */   }
/*  85:    */   
/*  86:    */   public void init()
/*  87:    */   {
/*  88:111 */     super.setLayoutParams(new RelativeLayout.LayoutParams(-1, -1));
/*  89:    */   }
/*  90:    */   
/*  91:    */   public void setOpaque(boolean opaque)
/*  92:    */   {
/*  93:115 */     if (opaque) {
/*  94:116 */       setBackgroundColor(Color.alpha(0));
/*  95:    */     }
/*  96:    */   }
/*  97:    */   
/*  98:    */   public void setBackground(int c)
/*  99:    */   {
/* 100:121 */     super.setBackgroundColor(c);
/* 101:122 */     if (getChildCount() > 0) {
/* 102:123 */       for (int i = 0; i < getChildCount(); i++) {
/* 103:124 */         getChildAt(i).setBackgroundColor(c);
/* 104:    */       }
/* 105:    */     }
/* 106:    */   }
/* 107:    */   
/* 108:    */   public void setBackgroundImage(String img)
/* 109:    */   {
/* 110:130 */     Drawable image = ImageUtil.findImageFromResources(img);
/* 111:131 */     if (image != null) {
/* 112:132 */       setBackgroundDrawable(image);
/* 113:    */     }
/* 114:    */   }
/* 115:    */   
/* 116:    */   public void addChildUIComponent(UIComponent child)
/* 117:    */   {
/* 118:137 */     this.children.addElement(child);
/* 119:    */   }
/* 120:    */   
/* 121:    */   public boolean canContainChildren()
/* 122:    */   {
/* 123:141 */     return true;
/* 124:    */   }
/* 125:    */   
/* 126:    */   public Enumeration getChildren()
/* 127:    */   {
/* 128:145 */     return this.children.elements();
/* 129:    */   }
/* 130:    */   
/* 131:    */   public Vector getChildrenAsVector()
/* 132:    */   {
/* 133:149 */     return this.children;
/* 134:    */   }
/* 135:    */   
/* 136:    */   public AbstractMobileControl getController()
/* 137:    */   {
/* 138:156 */     return this.controller;
/* 139:    */   }
/* 140:    */   
/* 141:    */   public void setController(AbstractMobileControl controller)
/* 142:    */   {
/* 143:164 */     this.controller = controller;
/* 144:    */   }
/* 145:    */   
/* 146:    */   public Object getConstraints()
/* 147:    */   {
/* 148:168 */     return null;
/* 149:    */   }
/* 150:    */   
/* 151:    */   public void setConstraints(Object consts) {}
/* 152:    */   
/* 153:    */   public void addView(View v)
/* 154:    */   {
/* 155:176 */     this.allKidViews.push(v);
/* 156:177 */     if ((this.allKidViews.size() == this.numOfKids) || (this.numOfKids == -1)) {
/* 157:178 */       addAllViews();
/* 158:    */     }
/* 159:    */   }
/* 160:    */   
/* 161:    */   private void addAllViews()
/* 162:    */   {
/* 163:183 */     while (this.allKidViews.size() > 0) {
/* 164:184 */       realAddView((View)this.allKidViews.pop());
/* 165:    */     }
/* 166:    */   }
/* 167:    */   
/* 168:    */   private void realAddView(View v)
/* 169:    */   {
/* 170:189 */     updateViewLayoutParams(v);
/* 171:190 */     super.addView(v);
/* 172:191 */     this.currentId = v.getId();
/* 173:192 */     if ((v instanceof UIComponent)) {
/* 174:193 */       addChildUIComponent((UIComponent)v);
/* 175:    */     }
/* 176:    */   }
/* 177:    */   
/* 178:    */   private void updateViewLayoutParams(View v)
/* 179:    */   {
/* 180:199 */     if (getChildrenAsVector().size() == 0)
/* 181:    */     {
/* 182:200 */       RelativeLayout.LayoutParams lp = new RelativeLayout.LayoutParams(-1, -2);
/* 183:202 */       if (this.numOfKids > 1) {
/* 184:203 */         lp.addRule(12);
/* 185:    */       } else {
/* 186:205 */         lp.addRule(10);
/* 187:    */       }
/* 188:207 */       v.setLayoutParams(lp);
/* 189:208 */       return;
/* 190:    */     }
/* 191:223 */     RelativeLayout.LayoutParams lp = new RelativeLayout.LayoutParams(-1, -2);
/* 192:    */     
/* 193:225 */     lp.addRule(2, this.currentId);
/* 194:226 */     v.setLayoutParams(lp);
/* 195:    */   }
/* 196:    */   
/* 197:    */   public void remove(UIComponent comp)
/* 198:    */   {
/* 199:235 */     this.children.remove(comp);
/* 200:    */   }
/* 201:    */   
/* 202:    */   public ControlStyle getStyle()
/* 203:    */   {
/* 204:242 */     return this.style;
/* 205:    */   }
/* 206:    */   
/* 207:    */   public void setStyle(ControlStyle style)
/* 208:    */   {
/* 209:250 */     this.style = style;
/* 210:    */   }
/* 211:    */   
/* 212:    */   public void setVisible(boolean show)
/* 213:    */   {
/* 214:254 */     setVisibility(show ? 0 : 8);
/* 215:    */   }
/* 216:    */   
/* 217:    */   public boolean isVisible()
/* 218:    */   {
/* 219:258 */     return getVisibility() == 0;
/* 220:    */   }
/* 221:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.components.NRelativePanel
 * JD-Core Version:    0.7.0.1
 */