/*   1:    */ package com.mro.mobile.ui.res.widgets.android;
/*   2:    */ 
/*   3:    */ import android.content.Context;
/*   4:    */ import android.graphics.Color;
/*   5:    */ import android.view.View;
/*   6:    */ import android.widget.LinearLayout.LayoutParams;
/*   7:    */ import com.ibm.tivoli.maximo.mobile.android.util.UIUtil;
/*   8:    */ import com.ibm.tivoli.maximo.mobile.resources.R.layout;
/*   9:    */ import com.mro.mobile.MobileApplicationException;
/*  10:    */ import com.mro.mobile.ui.MobileMboDataBean;
/*  11:    */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*  12:    */ import com.mro.mobile.ui.res.controls.AttributeNameConstants;
/*  13:    */ import com.mro.mobile.ui.res.controls.TreeControl;
/*  14:    */ import com.mro.mobile.ui.res.controls.utils.TreeNodeData;
/*  15:    */ import com.mro.mobile.ui.res.widgets.android.components.NImageButton;
/*  16:    */ import com.mro.mobile.ui.res.widgets.android.components.NLabel;
/*  17:    */ import com.mro.mobile.ui.res.widgets.android.components.NPanel;
/*  18:    */ import com.mro.mobile.ui.res.widgets.def.AbstractWidget;
/*  19:    */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  20:    */ import com.mro.mobile.util.MobileLogger;
/*  21:    */ import com.mro.mobile.util.MobileLoggerFactory;
/*  22:    */ 
/*  23:    */ public class ADAbstractWidgetImpl
/*  24:    */   implements AbstractWidget, AttributeNameConstants
/*  25:    */ {
/*  26: 43 */   private AbstractMobileControl abstractControl = null;
/*  27:    */   
/*  28:    */   public void setController(AbstractMobileControl control)
/*  29:    */   {
/*  30: 46 */     this.abstractControl = control;
/*  31:    */   }
/*  32:    */   
/*  33:    */   protected AbstractMobileControl getController()
/*  34:    */   {
/*  35: 50 */     return this.abstractControl;
/*  36:    */   }
/*  37:    */   
/*  38:    */   public MobileLogger getDefaultLogger()
/*  39:    */   {
/*  40: 57 */     return MobileLoggerFactory.getDefaultLogger();
/*  41:    */   }
/*  42:    */   
/*  43:    */   public void setUIComponentVisible(UIComponent c, boolean b)
/*  44:    */   {
/*  45: 61 */     if (c != null) {
/*  46: 62 */       if (b) {
/*  47: 63 */         ((View)c).setVisibility(0);
/*  48:    */       } else {
/*  49: 65 */         ((View)c).setVisibility(8);
/*  50:    */       }
/*  51:    */     }
/*  52:    */   }
/*  53:    */   
/*  54:    */   public UIComponent createDataPanel(AbstractMobileControl calledControl, String label, String image, String popKey, MobileMboDataBean activeDataBean, Object treenNodeData)
/*  55:    */     throws MobileApplicationException
/*  56:    */   {
/*  57: 72 */     Context context = AndroidEnv.getCurrentActivity();
/*  58:    */     
/*  59: 74 */     NPanel panel = NPanel.createByInflate(calledControl, context, 0);
/*  60: 75 */     panel.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
/*  61: 77 */     if (popKey != null)
/*  62:    */     {
/*  63: 78 */       View popupImage = (View)((TreeControl)calledControl).getPopUpContrl(popKey);
/*  64: 79 */       popupImagePostCreate(popupImage, label, (TreeNodeData)treenNodeData);
/*  65: 80 */       if (popupImage != null) {
/*  66: 81 */         panel.addView(popupImage);
/*  67:    */       }
/*  68:    */     }
/*  69: 85 */     if (image != null)
/*  70:    */     {
/*  71: 86 */       NImageButton buttonIamge = NImageButton.createByInflate(null, context, image, "");
/*  72: 87 */       buttonImagePostCreate(buttonIamge, (TreeNodeData)treenNodeData);
/*  73: 88 */       if (buttonIamge != null) {
/*  74: 89 */         panel.addView(buttonIamge);
/*  75:    */       }
/*  76:    */     }
/*  77: 93 */     NLabel displayTitle = NLabel.createByInflate(UIUtil.getResourceId(R.layout.class, "ntreetitle"), calledControl, context, label);
/*  78: 94 */     displayTitle.setSingleLine();
/*  79: 95 */     panel.addView(displayTitle);
/*  80:    */     
/*  81: 97 */     return panel;
/*  82:    */   }
/*  83:    */   
/*  84:    */   public Object createColor(int red, int green, int blue)
/*  85:    */   {
/*  86:101 */     return Integer.valueOf(Color.rgb(red, green, blue));
/*  87:    */   }
/*  88:    */   
/*  89:    */   public void popupImagePostCreate(View view, String label, TreeNodeData treeNodeData) {}
/*  90:    */   
/*  91:    */   public void buttonImagePostCreate(View view, TreeNodeData treeNodeData) {}
/*  92:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.ADAbstractWidgetImpl
 * JD-Core Version:    0.7.0.1
 */