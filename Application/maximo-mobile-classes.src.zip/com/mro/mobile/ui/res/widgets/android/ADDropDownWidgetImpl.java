/*   1:    */ package com.mro.mobile.ui.res.widgets.android;
/*   2:    */ 
/*   3:    */ import android.view.ViewGroup;
/*   4:    */ import com.ibm.tivoli.maximo.mobile.resources.R.layout;
/*   5:    */ import com.mro.mobile.MobileApplicationException;
/*   6:    */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*   7:    */ import com.mro.mobile.ui.res.controls.DropDownControl;
/*   8:    */ import com.mro.mobile.ui.res.controls.utils.ControlStyle;
/*   9:    */ import com.mro.mobile.ui.res.widgets.android.components.NComboBox;
/*  10:    */ import com.mro.mobile.ui.res.widgets.android.components.NLabel;
/*  11:    */ import com.mro.mobile.ui.res.widgets.android.components.NPanel;
/*  12:    */ import com.mro.mobile.ui.res.widgets.def.DropDownWidget;
/*  13:    */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  14:    */ 
/*  15:    */ public class ADDropDownWidgetImpl
/*  16:    */   extends ADInputWidgetImpl
/*  17:    */   implements DropDownWidget
/*  18:    */ {
/*  19: 20 */   private NComboBox combobox = null;
/*  20:    */   
/*  21:    */   public DropDownWidget createDropDownField()
/*  22:    */   {
/*  23: 25 */     this.combobox = NComboBox.createByInflate(getDropDownControl(), AndroidEnv.getCurrentActivity());
/*  24: 26 */     return this;
/*  25:    */   }
/*  26:    */   
/*  27:    */   protected DropDownControl getDropDownControl()
/*  28:    */   {
/*  29: 30 */     return (DropDownControl)getController();
/*  30:    */   }
/*  31:    */   
/*  32:    */   public void setDropDownId(String id)
/*  33:    */   {
/*  34: 36 */     this.combobox.setCId(id);
/*  35:    */   }
/*  36:    */   
/*  37:    */   public void setEvent(String event)
/*  38:    */   {
/*  39: 42 */     this.combobox.setEvent(event);
/*  40:    */   }
/*  41:    */   
/*  42:    */   public void setController(AbstractMobileControl controller)
/*  43:    */   {
/*  44: 48 */     super.setController(controller);
/*  45:    */   }
/*  46:    */   
/*  47:    */   public void setDataBeanName(String dataBeanName)
/*  48:    */   {
/*  49: 54 */     this.combobox.setDataBeanName(dataBeanName);
/*  50:    */   }
/*  51:    */   
/*  52:    */   public void setMobileMboAttributeName(String mobileMboAttributeName)
/*  53:    */   {
/*  54: 60 */     this.combobox.setMobileMboAttributeName(mobileMboAttributeName);
/*  55:    */   }
/*  56:    */   
/*  57:    */   public void setEnabled(boolean readOnly)
/*  58:    */   {
/*  59: 66 */     this.combobox.setEnabled(readOnly);
/*  60:    */   }
/*  61:    */   
/*  62:    */   public void requestFocus()
/*  63:    */   {
/*  64: 72 */     this.combobox.requestFocus();
/*  65:    */   }
/*  66:    */   
/*  67:    */   public void setSelectedItem(int index)
/*  68:    */   {
/*  69: 78 */     this.combobox.setSelectedItem(index);
/*  70:    */   }
/*  71:    */   
/*  72:    */   public void addBlankItem(ControlStyle style)
/*  73:    */   {
/*  74: 84 */     addItem("  ", style);
/*  75:    */   }
/*  76:    */   
/*  77:    */   public void addItem(String text, ControlStyle style)
/*  78:    */   {
/*  79: 90 */     this.combobox.addItem(NLabel.createByInflate(getDropDownControl(), AndroidEnv.getCurrentActivity(), text));
/*  80:    */   }
/*  81:    */   
/*  82:    */   public void clear()
/*  83:    */   {
/*  84: 96 */     this.combobox.clear();
/*  85:    */   }
/*  86:    */   
/*  87:    */   public int getSelectedIndex()
/*  88:    */   {
/*  89:102 */     return this.combobox.getSelectedIndex();
/*  90:    */   }
/*  91:    */   
/*  92:    */   public void applyDataAdapter()
/*  93:    */   {
/*  94:106 */     this.combobox.applyDataAdapter();
/*  95:    */   }
/*  96:    */   
/*  97:    */   public Object getSelectedItem()
/*  98:    */   {
/*  99:112 */     return this.combobox.getSelectedItem();
/* 100:    */   }
/* 101:    */   
/* 102:    */   public UIComponent[] resolveDropDownComponents()
/* 103:    */     throws MobileApplicationException
/* 104:    */   {
/* 105:118 */     UIComponent[] components = null;
/* 106:119 */     NPanel labelPanel = (NPanel)getLabelPanelUIComponent(!com.mro.mobile.ui.res.UIUtil.isNull(getDropDownControl().getValue()));
/* 107:121 */     if (labelPanel != null)
/* 108:    */     {
/* 109:123 */       ViewGroup viewGroup = getViewGroupForSubclassContent(com.ibm.tivoli.maximo.mobile.android.util.UIUtil.getResourceId(R.layout.class, "addropdownwidgetimpl"));
/* 110:124 */       viewGroup.addView(this.combobox);
/* 111:125 */       components = new UIComponent[] { labelPanel };
/* 112:    */     }
/* 113:    */     else
/* 114:    */     {
/* 115:129 */       components = new UIComponent[] { this.combobox };
/* 116:    */     }
/* 117:132 */     return components;
/* 118:    */   }
/* 119:    */   
/* 120:    */   public String getSelectedItemAsText()
/* 121:    */   {
/* 122:138 */     return (String)getSelectedItem();
/* 123:    */   }
/* 124:    */   
/* 125:    */   public void bindListeners()
/* 126:    */   {
/* 127:143 */     this.combobox.bindStateChangeListener();
/* 128:    */   }
/* 129:    */   
/* 130:    */   public boolean needsBlankItem()
/* 131:    */   {
/* 132:148 */     return true;
/* 133:    */   }
/* 134:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.ADDropDownWidgetImpl
 * JD-Core Version:    0.7.0.1
 */