/*  1:   */ package com.mro.mobile.ui.res.widgets.android.components.table;
/*  2:   */ 
/*  3:   */ import android.content.Context;
/*  4:   */ import android.util.AttributeSet;
/*  5:   */ import android.view.View;
/*  6:   */ import android.view.ViewGroup;
/*  7:   */ import android.view.ViewParent;
/*  8:   */ import com.ibm.tivoli.maximo.mobile.android.util.UIUtil;
/*  9:   */ import com.ibm.tivoli.maximo.mobile.resources.R.layout;
/* 10:   */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/* 11:   */ import com.mro.mobile.ui.res.controls.utils.ControlStyle;
/* 12:   */ import com.mro.mobile.ui.res.widgets.android.components.NImageLink;
/* 13:   */ import com.mro.mobile.ui.res.widgets.android.components.NLabel;
/* 14:   */ import com.mro.mobile.ui.res.widgets.android.components.NPanel;
/* 15:   */ 
/* 16:   */ public class NTableCell
/* 17:   */   extends NPanel
/* 18:   */ {
/* 19:32 */   private static final int DEFAULT_XML_LAYOUT = UIUtil.getResourceId(R.layout.class, "ntablecell");
/* 20:   */   
/* 21:   */   public NTableCell(Context context)
/* 22:   */   {
/* 23:35 */     this(context, null);
/* 24:   */   }
/* 25:   */   
/* 26:   */   public NTableCell(Context context, AttributeSet attrs)
/* 27:   */   {
/* 28:39 */     super(context, attrs);
/* 29:   */   }
/* 30:   */   
/* 31:   */   public static NTableCell createByInflate(AbstractMobileControl control, Context context, int orientation)
/* 32:   */   {
/* 33:43 */     return createByInflate(DEFAULT_XML_LAYOUT, control, context, orientation);
/* 34:   */   }
/* 35:   */   
/* 36:   */   public static NTableCell createByInflate(int layoutId, AbstractMobileControl control, Context context)
/* 37:   */   {
/* 38:47 */     return createByInflate(layoutId, control, context, 0);
/* 39:   */   }
/* 40:   */   
/* 41:   */   public static NTableCell createByInflate(int layoutId, AbstractMobileControl control, Context context, int orientation)
/* 42:   */   {
/* 43:51 */     NTableCell cell = (NTableCell)View.inflate(context, layoutId, null);
/* 44:52 */     cell.postInstance(control, orientation);
/* 45:53 */     return cell;
/* 46:   */   }
/* 47:   */   
/* 48:   */   public void addView(View v)
/* 49:   */   {
/* 50:58 */     ControlStyle style = null;
/* 51:59 */     if ((v instanceof NPanel)) {
/* 52:60 */       style = ((NPanel)v).getStyle();
/* 53:   */     }
/* 54:63 */     View toAdd = getLeaf(v);
/* 55:64 */     if ((toAdd instanceof NImageLink)) {
/* 56:65 */       ((NImageLink)toAdd).applyStyle(style);
/* 57:66 */     } else if ((toAdd instanceof NLabel)) {
/* 58:67 */       ((NLabel)toAdd).applyStyle(style);
/* 59:   */     }
/* 60:69 */     super.addView(toAdd);
/* 61:   */   }
/* 62:   */   
/* 63:   */   private View getLeaf(View v)
/* 64:   */   {
/* 65:73 */     if ((v instanceof ViewGroup))
/* 66:   */     {
/* 67:74 */       ViewGroup me = (ViewGroup)v;
/* 68:75 */       return getLeaf(me.getChildAt(0));
/* 69:   */     }
/* 70:77 */     ViewParent parent = v.getParent();
/* 71:78 */     if ((parent != null) && ((parent instanceof ViewGroup))) {
/* 72:79 */       ((ViewGroup)parent).removeView(v);
/* 73:   */     }
/* 74:81 */     return v;
/* 75:   */   }
/* 76:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.components.table.NTableCell
 * JD-Core Version:    0.7.0.1
 */