package com.mro.mobile.ui.res.widgets.def;

import com.mro.mobile.MobileApplicationException;
import com.mro.mobile.ui.event.UIEvent;
import com.mro.mobile.ui.res.controls.PageControl;
import java.util.ArrayList;

public abstract interface PageWidget
  extends AbstractWidget
{
  public abstract UIComponent createPagePanel();
  
  public abstract void setOpaque(boolean paramBoolean);
  
  public abstract void setId(String paramString);
  
  public abstract void setBackgroundColor(String paramString);
  
  public abstract void setDefaultPageLayout();
  
  public abstract void addToolbarComponents(UIComponent[] paramArrayOfUIComponent);
  
  public abstract void createCenterPanel();
  
  public abstract void setDefaultCenterLayout();
  
  public abstract void addChildComponentsToCenterPanel(UIComponent[] paramArrayOfUIComponent);
  
  public abstract UIComponent addControlsToPanel(ArrayList paramArrayList);
  
  public abstract void addControlsToSouthPanel(ArrayList paramArrayList);
  
  public abstract void setSouthPanelTopBorders();
  
  public abstract void addSouthPanelToCenterPanel();
  
  public abstract void addCenterPanelToPagePanel();
  
  public abstract void addPanelToPagePanel(UIComponent paramUIComponent);
  
  public abstract boolean move(String paramString);
  
  public abstract void removeFromToolBarContainer(UIComponent paramUIComponent);
  
  public abstract void addToolBarToContainer(UIComponent paramUIComponent);
  
  public abstract void setPageFocus(PageControl paramPageControl);
  
  public abstract boolean barcoderead(UIEvent paramUIEvent)
    throws MobileApplicationException;
  
  public abstract void setEnabled(boolean paramBoolean);
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.def.PageWidget
 * JD-Core Version:    0.7.0.1
 */