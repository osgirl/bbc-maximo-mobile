/*   1:    */ package com.mro.mobile.ui.res.widgets.android;
/*   2:    */ 
/*   3:    */ import android.view.View;
/*   4:    */ import com.mro.mobile.MobileApplicationException;
/*   5:    */ import com.mro.mobile.ui.event.UIEvent;
/*   6:    */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*   7:    */ import com.mro.mobile.ui.res.controls.utils.TreeNodeData;
/*   8:    */ import com.mro.mobile.ui.res.widgets.android.components.NImageButton;
/*   9:    */ import com.mro.mobile.ui.res.widgets.android.components.NImageButton.ButtonImageClickable;
/*  10:    */ import com.mro.mobile.ui.res.widgets.android.components.NPopUpImage;
/*  11:    */ import com.mro.mobile.ui.res.widgets.android.components.NPopUpImage.PopupImageClickable;
/*  12:    */ import com.mro.mobile.ui.res.widgets.android.components.tree.Item;
/*  13:    */ import com.mro.mobile.ui.res.widgets.android.components.tree.NScrollTree;
/*  14:    */ import com.mro.mobile.ui.res.widgets.android.components.tree.NTree;
/*  15:    */ import com.mro.mobile.ui.res.widgets.android.components.tree.Tree;
/*  16:    */ import com.mro.mobile.ui.res.widgets.android.components.tree.TreeModel;
/*  17:    */ import com.mro.mobile.ui.res.widgets.def.TreeWidget;
/*  18:    */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  19:    */ import java.util.Enumeration;
/*  20:    */ import java.util.Hashtable;
/*  21:    */ import java.util.Vector;
/*  22:    */ 
/*  23:    */ public class ADTreeWidgetImpl
/*  24:    */   extends ADAbstractWidgetImpl
/*  25:    */   implements TreeWidget, NPopUpImage.PopupImageClickable, NImageButton.ButtonImageClickable
/*  26:    */ {
/*  27:    */   private static final int BASE_LEVEL_DEPTH = 1;
/*  28: 29 */   private NTree nTree = null;
/*  29: 31 */   private TreeModel treeModel = null;
/*  30: 33 */   private Hashtable actualIndex = new Hashtable();
/*  31: 35 */   private String rootLabel = "";
/*  32:    */   
/*  33:    */   public UIComponent[] createBaseTree(String label, AbstractMobileControl mController)
/*  34:    */     throws MobileApplicationException
/*  35:    */   {
/*  36: 38 */     setController(mController);
/*  37: 39 */     this.nTree = NTree.createByInflate(getController(), AndroidEnv.getCurrentActivity());
/*  38: 40 */     this.rootLabel = label;
/*  39:    */     
/*  40: 42 */     initTreeModel();
/*  41: 43 */     buildBaseTreeModel();
/*  42:    */     
/*  43: 45 */     this.nTree.setController(mController);
/*  44: 46 */     NScrollTree nsTree = NScrollTree.createByInflate(getController(), AndroidEnv.getCurrentActivity(), this.nTree);
/*  45: 47 */     UIComponent[] ret = { nsTree };
/*  46:    */     
/*  47: 49 */     return ret;
/*  48:    */   }
/*  49:    */   
/*  50:    */   public void initTreeModel()
/*  51:    */   {
/*  52: 53 */     this.treeModel = new Tree();
/*  53: 54 */     this.nTree.setupAdapter(this.treeModel);
/*  54: 55 */     Item root = new Item(this.rootLabel);
/*  55: 56 */     ((Tree)this.treeModel).setRoot(root);
/*  56:    */   }
/*  57:    */   
/*  58:    */   public void selectTreeRoot()
/*  59:    */   {
/*  60: 60 */     this.nTree.select(this.nTree.getTreeModel().getRoot());
/*  61:    */   }
/*  62:    */   
/*  63:    */   public TreeNodeData getSelectedTreeNodeData(Object selItem)
/*  64:    */   {
/*  65: 64 */     Item selectedItem = (Item)selItem;
/*  66: 65 */     return (TreeNodeData)selectedItem.getValue();
/*  67:    */   }
/*  68:    */   
/*  69:    */   public void buildBaseTreeModel()
/*  70:    */     throws MobileApplicationException
/*  71:    */   {
/*  72: 69 */     removeChildren();
/*  73: 70 */     _buildBaseTreeModel_();
/*  74:    */   }
/*  75:    */   
/*  76:    */   private void _buildBaseTreeModel_()
/*  77:    */     throws MobileApplicationException
/*  78:    */   {
/*  79: 74 */     UIEvent uievent = new UIEvent(getController(), getController().getStringValue("treebaseevent"), null, null);
/*  80: 75 */     if (getController().handleEvent(uievent))
/*  81:    */     {
/*  82: 76 */       Enumeration treeNodes = ((Vector)uievent.getValue()).elements();
/*  83: 77 */       while (treeNodes.hasMoreElements())
/*  84:    */       {
/*  85: 79 */         this.actualIndex.clear();
/*  86: 80 */         while (treeNodes.hasMoreElements())
/*  87:    */         {
/*  88: 81 */           TreeNodeData treeNodeData = (TreeNodeData)treeNodes.nextElement();
/*  89: 82 */           treeNodeData.setDepth(1);
/*  90: 84 */           if (treeNodeData.isExtra())
/*  91:    */           {
/*  92: 85 */             this.actualIndex.put(treeNodeData.getDisplayValue(), new Integer(treeNodeData.getIndex()));
/*  93:    */           }
/*  94:    */           else
/*  95:    */           {
/*  96: 87 */             Item newItem = new Item(treeNodeData);
/*  97: 88 */             treeNodeData.setReferenceItem(newItem);
/*  98: 89 */             this.treeModel.add(this.treeModel.getRoot(), newItem);
/*  99:    */             
/* 100: 91 */             this.actualIndex.put(treeNodeData.getDisplayValue(), new Integer(treeNodeData.getIndex()));
/* 101:    */           }
/* 102:    */         }
/* 103:    */       }
/* 104:    */     }
/* 105:    */   }
/* 106:    */   
/* 107:    */   public void addElementToBranchTree(Object parentItem, Object kNode, int count)
/* 108:    */   {
/* 109: 99 */     TreeNodeData kidNode = (TreeNodeData)kNode;
/* 110:100 */     Item kidItem = new Item(kidNode);
/* 111:101 */     kidNode.setReferenceItem(kidItem);
/* 112:    */     
/* 113:103 */     TreeNodeData parentNode = (TreeNodeData)((Item)parentItem).getValue();
/* 114:104 */     this.treeModel.insert((Item)parentItem, kidItem, count);
/* 115:105 */     kidNode.setDepth(parentNode.getDepth() + 1);
/* 116:    */   }
/* 117:    */   
/* 118:    */   public Hashtable getActualIndex()
/* 119:    */   {
/* 120:109 */     return this.actualIndex;
/* 121:    */   }
/* 122:    */   
/* 123:    */   public void removeChildren()
/* 124:    */   {
/* 125:113 */     Item root = this.nTree.getTreeModel().getRoot();
/* 126:114 */     this.nTree.removeAllChildren(root);
/* 127:    */   }
/* 128:    */   
/* 129:    */   public boolean isTreeValid()
/* 130:    */   {
/* 131:118 */     return this.nTree.isValid();
/* 132:    */   }
/* 133:    */   
/* 134:    */   public Object getSelectedItem()
/* 135:    */   {
/* 136:122 */     return this.nTree.getSelectedItem();
/* 137:    */   }
/* 138:    */   
/* 139:    */   public void popupImagePostCreate(View view, String label, TreeNodeData treeNodeData)
/* 140:    */   {
/* 141:127 */     if ((view instanceof NPopUpImage))
/* 142:    */     {
/* 143:128 */       NPopUpImage nPopUpImage = (NPopUpImage)view;
/* 144:129 */       nPopUpImage.setTreeNodeData(treeNodeData);
/* 145:130 */       if (label != null) {
/* 146:131 */         nPopUpImage.setTitle(label);
/* 147:    */       }
/* 148:133 */       nPopUpImage.setPopupImageClickable(this);
/* 149:134 */       return;
/* 150:    */     }
/* 151:    */   }
/* 152:    */   
/* 153:    */   public void popupImageClicked(View view)
/* 154:    */   {
/* 155:140 */     if ((view instanceof NPopUpImage))
/* 156:    */     {
/* 157:141 */       NPopUpImage nPopUpImage = (NPopUpImage)view;
/* 158:142 */       this.nTree.imageClicked(nPopUpImage);
/* 159:143 */       return;
/* 160:    */     }
/* 161:    */   }
/* 162:    */   
/* 163:    */   public void buttonImagePostCreate(View view, TreeNodeData treeNodeData)
/* 164:    */   {
/* 165:149 */     if ((view instanceof NImageButton))
/* 166:    */     {
/* 167:150 */       NImageButton nImageButton = (NImageButton)view;
/* 168:151 */       nImageButton.setTreeNodeData(treeNodeData);
/* 169:152 */       nImageButton.setButtonImageClickable(this);
/* 170:153 */       return;
/* 171:    */     }
/* 172:    */   }
/* 173:    */   
/* 174:    */   public void buttonImageClicked(View view)
/* 175:    */   {
/* 176:159 */     if ((view instanceof NImageButton))
/* 177:    */     {
/* 178:160 */       NImageButton nButtonImage = (NImageButton)view;
/* 179:161 */       this.nTree.imageClicked(nButtonImage);
/* 180:162 */       return;
/* 181:    */     }
/* 182:    */   }
/* 183:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.ADTreeWidgetImpl
 * JD-Core Version:    0.7.0.1
 */