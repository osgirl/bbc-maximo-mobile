package com.mro.mobile.ui.res.widgets.def;

public abstract interface MenuItemWidget
  extends AbstractWidget
{
  public abstract void createMenuItem(String paramString1, String paramString2, String paramString3, String paramString4, boolean paramBoolean, String paramString5, String paramString6);
  
  public abstract UIComponent[] resolveMMenuItemComponents();
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.def.MenuItemWidget
 * JD-Core Version:    0.7.0.1
 */