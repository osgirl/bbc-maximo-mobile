/*  1:   */ package com.mro.mobile.ui.res.widgets.android;
/*  2:   */ 
/*  3:   */ import com.mro.mobile.MobileApplicationException;
/*  4:   */ import com.mro.mobile.ui.res.widgets.android.components.NFileChooser;
/*  5:   */ import com.mro.mobile.ui.res.widgets.def.FileDialogueWidget;
/*  6:   */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  7:   */ import java.io.File;
/*  8:   */ 
/*  9:   */ public class ADFileDialogueWidgetImpl
/* 10:   */   extends ADAbstractWidgetImpl
/* 11:   */   implements FileDialogueWidget
/* 12:   */ {
/* 13:   */   private NFileChooser fileChooser;
/* 14:   */   
/* 15:   */   public UIComponent[] composePanel(String startDirectory)
/* 16:   */     throws MobileApplicationException
/* 17:   */   {
/* 18:16 */     if ("\\".equals(startDirectory)) {
/* 19:17 */       startDirectory = "/";
/* 20:   */     }
/* 21:20 */     this.fileChooser = NFileChooser.createByInflate(getController(), AndroidEnv.getCurrentActivity(), new File(startDirectory));
/* 22:   */     
/* 23:22 */     return new UIComponent[] { this.fileChooser };
/* 24:   */   }
/* 25:   */   
/* 26:   */   public void handleTreeSelect(Object selItem) {}
/* 27:   */   
/* 28:   */   public void handleScan4Children(Object sItem)
/* 29:   */     throws MobileApplicationException
/* 30:   */   {}
/* 31:   */   
/* 32:   */   public void setSelectedFile(File selectedFile) {}
/* 33:   */   
/* 34:   */   public File getSelectedFile()
/* 35:   */   {
/* 36:39 */     return this.fileChooser.getSelectedFile();
/* 37:   */   }
/* 38:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.widgets.android.ADFileDialogueWidgetImpl
 * JD-Core Version:    0.7.0.1
 */