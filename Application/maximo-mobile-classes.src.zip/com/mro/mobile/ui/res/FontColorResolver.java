package com.mro.mobile.ui.res;

public abstract interface FontColorResolver
{
  public abstract Object getColor(String paramString, MobileUIPropertiesSupport paramMobileUIPropertiesSupport);
  
  public abstract Object createColor(String paramString, MobileUIPropertiesSupport paramMobileUIPropertiesSupport);
  
  public abstract Object getFont(String paramString, MobileUIPropertiesSupport paramMobileUIPropertiesSupport);
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.FontColorResolver
 * JD-Core Version:    0.7.0.1
 */