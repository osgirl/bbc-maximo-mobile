/*  1:   */ package com.mro.mobile.ui.res;
/*  2:   */ 
/*  3:   */ public class MobileUIResourcesSmall
/*  4:   */   extends MobileUIResources
/*  5:   */ {
/*  6:   */   private static final String RESOURCES_SMALL_FOLDER = "/small";
/*  7:   */   
/*  8:   */   public String getFolderName()
/*  9:   */   {
/* 10:29 */     return "/small";
/* 11:   */   }
/* 12:   */   
/* 13:   */   public float getFactorMultiplierFont()
/* 14:   */   {
/* 15:33 */     return 1.0F;
/* 16:   */   }
/* 17:   */   
/* 18:   */   public float getFactorMultiplierImageSize()
/* 19:   */   {
/* 20:37 */     return 1.0F;
/* 21:   */   }
/* 22:   */   
/* 23:   */   public float getFactorMultiplierTableWidth()
/* 24:   */   {
/* 25:41 */     return 1.0F;
/* 26:   */   }
/* 27:   */   
/* 28:   */   public String toString()
/* 29:   */   {
/* 30:45 */     return "SMALL";
/* 31:   */   }
/* 32:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.MobileUIResourcesSmall
 * JD-Core Version:    0.7.0.1
 */