/*  1:   */ package com.mro.mobile.ui.res;
/*  2:   */ 
/*  3:   */ public class MobileUIResourcesLarge
/*  4:   */   extends MobileUIResources
/*  5:   */ {
/*  6:   */   private static final String RESOURCES_LARGE_FOLDER = "/large";
/*  7:   */   
/*  8:   */   public String getFolderName()
/*  9:   */   {
/* 10:30 */     return "/large";
/* 11:   */   }
/* 12:   */   
/* 13:   */   public float getFactorMultiplierFont()
/* 14:   */   {
/* 15:34 */     return 1.5F;
/* 16:   */   }
/* 17:   */   
/* 18:   */   public float getFactorMultiplierImageSize()
/* 19:   */   {
/* 20:38 */     return 2.0F;
/* 21:   */   }
/* 22:   */   
/* 23:   */   public float getFactorMultiplierTableWidth()
/* 24:   */   {
/* 25:42 */     return 2.0F;
/* 26:   */   }
/* 27:   */   
/* 28:   */   public String toString()
/* 29:   */   {
/* 30:46 */     return "LARGE";
/* 31:   */   }
/* 32:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.MobileUIResourcesLarge
 * JD-Core Version:    0.7.0.1
 */