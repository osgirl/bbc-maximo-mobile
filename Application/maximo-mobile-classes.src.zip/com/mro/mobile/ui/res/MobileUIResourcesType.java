/*  1:   */ package com.mro.mobile.ui.res;
/*  2:   */ 
/*  3:   */ public class MobileUIResourcesType
/*  4:   */ {
/*  5:   */   private static final byte RESOURCE_SMALL = 0;
/*  6:   */   private static final byte RESOURCE_LARGE = 1;
/*  7:31 */   public static final MobileUIResourcesType SMALL = new MobileUIResourcesType(0, new MobileUIResourcesSmall());
/*  8:33 */   public static final MobileUIResourcesType LARGE = new MobileUIResourcesType(1, new MobileUIResourcesLarge());
/*  9:35 */   private int mode = 0;
/* 10:   */   private MobileUIResources mobileUIResourcesHandler;
/* 11:   */   
/* 12:   */   private MobileUIResourcesType(int mode, MobileUIResources resourceHandler)
/* 13:   */   {
/* 14:39 */     this.mode = mode;
/* 15:40 */     this.mobileUIResourcesHandler = resourceHandler;
/* 16:   */   }
/* 17:   */   
/* 18:   */   public int hashCode()
/* 19:   */   {
/* 20:44 */     int prime = 31;
/* 21:45 */     int result = 1;
/* 22:46 */     result = 31 * result + this.mode;
/* 23:47 */     return result;
/* 24:   */   }
/* 25:   */   
/* 26:   */   public boolean equals(Object obj)
/* 27:   */   {
/* 28:51 */     if (this == obj) {
/* 29:52 */       return true;
/* 30:   */     }
/* 31:53 */     if (obj == null) {
/* 32:54 */       return false;
/* 33:   */     }
/* 34:55 */     if (getClass() != obj.getClass()) {
/* 35:56 */       return false;
/* 36:   */     }
/* 37:57 */     MobileUIResourcesType other = (MobileUIResourcesType)obj;
/* 38:58 */     if (this.mode != other.mode) {
/* 39:59 */       return false;
/* 40:   */     }
/* 41:60 */     return true;
/* 42:   */   }
/* 43:   */   
/* 44:   */   public MobileUIResources getMobileUIResourcesHandler()
/* 45:   */   {
/* 46:64 */     return this.mobileUIResourcesHandler;
/* 47:   */   }
/* 48:   */   
/* 49:   */   public String toString()
/* 50:   */   {
/* 51:68 */     return this.mobileUIResourcesHandler.toString();
/* 52:   */   }
/* 53:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.MobileUIResourcesType
 * JD-Core Version:    0.7.0.1
 */