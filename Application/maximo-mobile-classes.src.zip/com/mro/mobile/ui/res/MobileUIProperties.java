/*  1:   */ package com.mro.mobile.ui.res;
/*  2:   */ 
/*  3:   */ public class MobileUIProperties
/*  4:   */ {
/*  5:   */   private static MobileUIPropertiesSupport propertiesSupport;
/*  6:25 */   private static FontColorResolver fontColorResolver = null;
/*  7:   */   
/*  8:   */   public static void registerMobileUIPropertiesSupport(MobileUIPropertiesSupport support)
/*  9:   */   {
/* 10:28 */     propertiesSupport = support;
/* 11:   */   }
/* 12:   */   
/* 13:   */   public static void registerFontColorResolver(FontColorResolver fcr)
/* 14:   */   {
/* 15:32 */     fontColorResolver = fcr;
/* 16:   */   }
/* 17:   */   
/* 18:   */   public static boolean getBooleanValue(String key)
/* 19:   */   {
/* 20:36 */     return propertiesSupport.getBooleanValue(key);
/* 21:   */   }
/* 22:   */   
/* 23:   */   public static String getStringValue(String key)
/* 24:   */   {
/* 25:40 */     return propertiesSupport.getStringValue(key);
/* 26:   */   }
/* 27:   */   
/* 28:   */   public static int getIntValue(String key, int defaultVal)
/* 29:   */   {
/* 30:44 */     return propertiesSupport.getIntValue(key, defaultVal);
/* 31:   */   }
/* 32:   */   
/* 33:   */   public static Object getValue(String key)
/* 34:   */   {
/* 35:48 */     return propertiesSupport.getValue(key);
/* 36:   */   }
/* 37:   */   
/* 38:   */   public static Object getValue(String key, boolean exactMatch)
/* 39:   */   {
/* 40:52 */     return propertiesSupport.getValue(key, exactMatch);
/* 41:   */   }
/* 42:   */   
/* 43:   */   public static void putValue(String key, Object value)
/* 44:   */   {
/* 45:56 */     propertiesSupport.putValue(key, value);
/* 46:   */   }
/* 47:   */   
/* 48:   */   public static Object getColor(String key)
/* 49:   */   {
/* 50:60 */     return fontColorResolver.getColor(key, propertiesSupport);
/* 51:   */   }
/* 52:   */   
/* 53:   */   public static Object createColor(String color)
/* 54:   */   {
/* 55:64 */     return fontColorResolver.createColor(color, propertiesSupport);
/* 56:   */   }
/* 57:   */   
/* 58:   */   public static Object getFont(String key)
/* 59:   */   {
/* 60:68 */     return fontColorResolver.getFont(key, propertiesSupport);
/* 61:   */   }
/* 62:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.MobileUIProperties
 * JD-Core Version:    0.7.0.1
 */