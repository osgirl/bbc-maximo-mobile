/*   1:    */ package com.mro.mobile.ui.res.android;
/*   2:    */ 
/*   3:    */ import android.app.Activity;
/*   4:    */ import android.content.Context;
/*   5:    */ import android.content.Intent;
/*   6:    */ import android.content.pm.PackageManager;
/*   7:    */ import android.content.pm.ResolveInfo;
/*   8:    */ import android.view.Display;
/*   9:    */ import android.view.View;
/*  10:    */ import android.view.ViewGroup;
/*  11:    */ import android.view.Window;
/*  12:    */ import android.view.WindowManager;
/*  13:    */ import com.ibm.tivoli.maximo.mobile.android.util.ViewGroupAnalyzer;
/*  14:    */ import com.ibm.tivoli.maximo.mobile.entrypoint.android.AndroidMobileAppEntryPoint;
/*  15:    */ import com.ibm.tivoli.maximo.mobile.resources.R.drawable;
/*  16:    */ import com.mro.mobile.MobileApplicationException;
/*  17:    */ import com.mro.mobile.ProgressObserver;
/*  18:    */ import com.mro.mobile.app.BasicMobileDeviceUIApplication;
/*  19:    */ import com.mro.mobile.app.DefaultMobileMboDataFormatter;
/*  20:    */ import com.mro.mobile.app.MobileDeviceAppSession;
/*  21:    */ import com.mro.mobile.ui.MobileMboDataFormatter;
/*  22:    */ import com.mro.mobile.ui.event.UIEvent;
/*  23:    */ import com.mro.mobile.ui.res.MobileUIManager;
/*  24:    */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*  25:    */ import com.mro.mobile.ui.res.controls.ButtonControl;
/*  26:    */ import com.mro.mobile.ui.res.controls.ButtonStateControl;
/*  27:    */ import com.mro.mobile.ui.res.controls.CalendarControl;
/*  28:    */ import com.mro.mobile.ui.res.controls.CheckboxControl;
/*  29:    */ import com.mro.mobile.ui.res.controls.DropDownControl;
/*  30:    */ import com.mro.mobile.ui.res.controls.FileDialogueControl;
/*  31:    */ import com.mro.mobile.ui.res.controls.ImageControl;
/*  32:    */ import com.mro.mobile.ui.res.controls.LabelControl;
/*  33:    */ import com.mro.mobile.ui.res.controls.LinkControl;
/*  34:    */ import com.mro.mobile.ui.res.controls.LongDescription;
/*  35:    */ import com.mro.mobile.ui.res.controls.LookupControl;
/*  36:    */ import com.mro.mobile.ui.res.controls.MenuBarControl;
/*  37:    */ import com.mro.mobile.ui.res.controls.MenuControl;
/*  38:    */ import com.mro.mobile.ui.res.controls.MenuItemControl;
/*  39:    */ import com.mro.mobile.ui.res.controls.MenuViewControl;
/*  40:    */ import com.mro.mobile.ui.res.controls.MessageBox;
/*  41:    */ import com.mro.mobile.ui.res.controls.MultiLineTextboxControl;
/*  42:    */ import com.mro.mobile.ui.res.controls.PageControl;
/*  43:    */ import com.mro.mobile.ui.res.controls.PageGroupControl;
/*  44:    */ import com.mro.mobile.ui.res.controls.PopUpImageControl;
/*  45:    */ import com.mro.mobile.ui.res.controls.ProgressControl;
/*  46:    */ import com.mro.mobile.ui.res.controls.ReasonForChangeControl;
/*  47:    */ import com.mro.mobile.ui.res.controls.SectionColControl;
/*  48:    */ import com.mro.mobile.ui.res.controls.SectionControl;
/*  49:    */ import com.mro.mobile.ui.res.controls.SectionRowControl;
/*  50:    */ import com.mro.mobile.ui.res.controls.SectionSeparatorControl;
/*  51:    */ import com.mro.mobile.ui.res.controls.SignatureCaptureControl;
/*  52:    */ import com.mro.mobile.ui.res.controls.SpinControl;
/*  53:    */ import com.mro.mobile.ui.res.controls.StateControl;
/*  54:    */ import com.mro.mobile.ui.res.controls.TabControl;
/*  55:    */ import com.mro.mobile.ui.res.controls.TabGroupControl;
/*  56:    */ import com.mro.mobile.ui.res.controls.TableColControl;
/*  57:    */ import com.mro.mobile.ui.res.controls.TableControl;
/*  58:    */ import com.mro.mobile.ui.res.controls.TextboxControl;
/*  59:    */ import com.mro.mobile.ui.res.controls.ToolBarContainerControl;
/*  60:    */ import com.mro.mobile.ui.res.controls.ToolBarLeftControl;
/*  61:    */ import com.mro.mobile.ui.res.controls.ToolBarRightControl;
/*  62:    */ import com.mro.mobile.ui.res.controls.TreeControl;
/*  63:    */ import com.mro.mobile.ui.res.widgets.android.ADWidgetFactory;
/*  64:    */ import com.mro.mobile.ui.res.widgets.android.AndroidEnv;
/*  65:    */ import com.mro.mobile.ui.res.widgets.android.AndroidMessageBoxAdapterFactory;
/*  66:    */ import com.mro.mobile.ui.res.widgets.android.components.ADProgressObserver;
/*  67:    */ import com.mro.mobile.ui.res.widgets.android.components.NPopUpDialog;
/*  68:    */ import com.mro.mobile.ui.res.widgets.android.components.NPopUpWindow;
/*  69:    */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  70:    */ import com.mro.mobile.util.MobileLogger;
/*  71:    */ import com.mro.mobile.util.MobileLoggerFactory;
/*  72:    */ import java.util.List;
/*  73:    */ 
/*  74:    */ public class AndroidMobileUIManager
/*  75:    */   extends MobileUIManager
/*  76:    */ {
/*  77: 91 */   private Boolean supportsCamera = null;
/*  78: 93 */   private boolean debugScreenViews = false;
/*  79:    */   private AndroidMobileAppEntryPoint<?> androidApplication;
/*  80:    */   
/*  81:    */   public AndroidMobileUIManager(AndroidMobileAppEntryPoint<?> androidApplication)
/*  82:    */   {
/*  83: 98 */     this.androidApplication = androidApplication;
/*  84:    */   }
/*  85:    */   
/*  86:    */   public void setFrameSize() {}
/*  87:    */   
/*  88:    */   public MobileMboDataFormatter getMobileMboDataFormatter()
/*  89:    */   {
/*  90:106 */     return new DefaultMobileMboDataFormatter();
/*  91:    */   }
/*  92:    */   
/*  93:    */   public void registerUIWidgetsForControls()
/*  94:    */   {
/*  95:110 */     MessageBox.resgiterMessageBoxAdapterFactory(new AndroidMessageBoxAdapterFactory());
/*  96:111 */     TextboxControl.registerWidgetCreator(ADWidgetFactory.initTextboxWidgetCreator());
/*  97:112 */     MultiLineTextboxControl.registerWidgetCreator(ADWidgetFactory.initMultiLineTextboxWidgetCreator());
/*  98:113 */     LongDescription.registerWidgetCreator(ADWidgetFactory.initLongDescriptionWidgetCreator());
/*  99:114 */     CheckboxControl.registerWidgetCreator(ADWidgetFactory.initCheckboxWidgetCreator());
/* 100:115 */     LabelControl.registerWidgetCreator(ADWidgetFactory.initLabelWidgetCreator());
/* 101:116 */     LinkControl.registerWidgetCreator(ADWidgetFactory.initLinkWidgetCreator());
/* 102:117 */     SectionControl.registerWidgetCreator(ADWidgetFactory.initSectionWidgetCreator());
/* 103:118 */     SectionRowControl.registerWidgetCreator(ADWidgetFactory.initSectionRowWidgetCreator());
/* 104:119 */     SectionColControl.registerWidgetCreator(ADWidgetFactory.initSectionColWidgetCreator());
/* 105:120 */     TabControl.registerWidgetCreator(ADWidgetFactory.initTabWidgetCreator());
/* 106:121 */     TabGroupControl.registerWidgetCreator(ADWidgetFactory.initTabGroupWidgetCreator());
/* 107:122 */     PageControl.registerWidgetCreator(ADWidgetFactory.initPageWidgetCreator());
/* 108:123 */     MenuControl.registerWidgetCreator(ADWidgetFactory.initMenuWidgetCreator());
/* 109:124 */     MenuViewControl.registerWidgetCreator(ADWidgetFactory.initMenuViewWidgetCreator());
/* 110:125 */     MenuBarControl.registerWidgetCreator(ADWidgetFactory.initMenuBarWidgetCreator());
/* 111:126 */     MenuItemControl.registerWidgetCreator(ADWidgetFactory.initMenuItemWidgetCreator());
/* 112:127 */     ToolBarContainerControl.registerWidgetCreator(ADWidgetFactory.initToolBarContainerCreator());
/* 113:128 */     ToolBarLeftControl.registerWidgetCreator(ADWidgetFactory.initToolBarLeftWidgetCreator());
/* 114:129 */     ToolBarRightControl.registerWidgetCreator(ADWidgetFactory.initToolBarRightWidgetCreator());
/* 115:130 */     PageGroupControl.registerWidgetCreator(ADWidgetFactory.initPageGroupWidgetCreator());
/* 116:131 */     TableColControl.registerWidgetCreator(ADWidgetFactory.initTableColWidgetCreator());
/* 117:132 */     TableControl.registerWidgetCreator(ADWidgetFactory.initTableWidgetCreator());
/* 118:133 */     ImageControl.registerWidgetCreator(ADWidgetFactory.initImageWidgetCreator());
/* 119:134 */     ButtonControl.registerWidgetCreator(ADWidgetFactory.initButtonWidgetCreator());
/* 120:135 */     DropDownControl.registerWidgetCreator(ADWidgetFactory.initDropDownWidgetCreator());
/* 121:136 */     StateControl.registerWidgetCreator(ADWidgetFactory.initStateWidgetCreator());
/* 122:137 */     LookupControl.registerWidgetCreator(ADWidgetFactory.initLookupWidgetCreator());
/* 123:138 */     ButtonStateControl.registerWidgetCreator(ADWidgetFactory.initButtonStateWidgetCreator());
/* 124:139 */     SectionSeparatorControl.registerWidgetCreator(ADWidgetFactory.initSectionSeparatorWidgetCreator());
/* 125:140 */     PopUpImageControl.registerWidgetCreator(ADWidgetFactory.initPopUpImageWidgetCreator());
/* 126:141 */     TreeControl.registerWidgetCreator(ADWidgetFactory.initTreeWidgetCreator());
/* 127:142 */     SignatureCaptureControl.registerWidgetCreator(ADWidgetFactory.initSignatureCaptureWidgetCreator());
/* 128:143 */     CalendarControl.registerWidgetCreator(ADWidgetFactory.initCalendarWidgetCreator());
/* 129:144 */     ReasonForChangeControl.registerWidgetCreator(ADWidgetFactory.initReasonForChangeWidgetCreator());
/* 130:145 */     FileDialogueControl.registerWidgetCreator(ADWidgetFactory.initFileDialogueWidgetCreator());
/* 131:146 */     ProgressControl.registerWidgetCreator(ADWidgetFactory.initStubWidgetCreator());
/* 132:147 */     SpinControl.registerWidgetCreator(ADWidgetFactory.initStubWidgetCreator());
/* 133:    */   }
/* 134:    */   
/* 135:    */   public void hidewait() {}
/* 136:    */   
/* 137:    */   public void showWait() {}
/* 138:    */   
/* 139:    */   protected void setWindowTitle(final String title)
/* 140:    */   {
/* 141:159 */     this.androidApplication.runOnUiThread(new Runnable()
/* 142:    */     {
/* 143:    */       public void run()
/* 144:    */       {
/* 145:162 */         AndroidEnv.getCurrentActivity().setTitle(title);
/* 146:    */       }
/* 147:    */     });
/* 148:    */   }
/* 149:    */   
/* 150:    */   public void setVisible(boolean visible) {}
/* 151:    */   
/* 152:    */   public void setFocusOnNothing()
/* 153:    */   {
/* 154:172 */     this.androidApplication.runOnUiThread(new Runnable()
/* 155:    */     {
/* 156:    */       public void run()
/* 157:    */       {
/* 158:175 */         AndroidEnv.getCurrentActivity().getWindow().getDecorView().requestFocus();
/* 159:    */       }
/* 160:    */     });
/* 161:    */   }
/* 162:    */   
/* 163:    */   protected void adjustPageFocus(AbstractMobileControl currentInput, PageControl screen)
/* 164:    */   {
/* 165:186 */     setFocusOnNothing();
/* 166:    */   }
/* 167:    */   
/* 168:    */   protected void setPageInWindow(final UIComponent screenPanel)
/* 169:    */   {
/* 170:190 */     if ((this.debugScreenViews) && ((screenPanel instanceof ViewGroup))) {
/* 171:191 */       ViewGroupAnalyzer.listAllChildViews("android mobile ui mamanmger's setPageInWindow", (ViewGroup)screenPanel);
/* 172:    */     }
/* 173:194 */     String pageId = screenPanel.getController().getId();
/* 174:197 */     if ("esigDialog".equals(pageId)) {
/* 175:    */       try
/* 176:    */       {
/* 177:199 */         popupPage(pageId, null);
/* 178:    */       }
/* 179:    */       catch (MobileApplicationException e)
/* 180:    */       {
/* 181:201 */         MobileLoggerFactory.getDefaultLogger().warn("Failed to popup page: " + pageId, e);
/* 182:    */       }
/* 183:    */     } else {
/* 184:204 */       this.androidApplication.runOnUiThread(new Runnable()
/* 185:    */       {
/* 186:    */         public void run()
/* 187:    */         {
/* 188:207 */           AndroidEnv.getCurrentActivity().setContentView((View)screenPanel);
/* 189:    */         }
/* 190:    */       });
/* 191:    */     }
/* 192:    */   }
/* 193:    */   
/* 194:    */   protected void exitApplication()
/* 195:    */   {
/* 196:214 */     this.androidApplication.shutdownMobileApplication();
/* 197:    */   }
/* 198:    */   
/* 199:    */   public ProgressObserver showProgressScreen(AbstractMobileControl mobControl, UIEvent event)
/* 200:    */     throws MobileApplicationException
/* 201:    */   {
/* 202:218 */     NPopUpDialog msgbox = new NPopUpDialog(AndroidEnv.getCurrentActivity());
/* 203:219 */     msgbox.show();
/* 204:220 */     return new ADProgressObserver(msgbox, this.androidApplication);
/* 205:    */   }
/* 206:    */   
/* 207:    */   public void release()
/* 208:    */   {
/* 209:    */     try
/* 210:    */     {
/* 211:225 */       com.mro.mobile.ui.res.UIUtil.getApplication().clearPageStack();
/* 212:    */     }
/* 213:    */     catch (Exception e) {}
/* 214:    */   }
/* 215:    */   
/* 216:    */   public void enableMenu(boolean enable) {}
/* 217:    */   
/* 218:    */   public int getWindowWidth()
/* 219:    */   {
/* 220:236 */     return AndroidEnv.getCurrentActivity().getWindowManager().getDefaultDisplay().getWidth();
/* 221:    */   }
/* 222:    */   
/* 223:    */   public int getWindowHeight()
/* 224:    */   {
/* 225:240 */     return AndroidEnv.getCurrentActivity().getWindowManager().getDefaultDisplay().getHeight();
/* 226:    */   }
/* 227:    */   
/* 228:    */   public Object getNativeWindowFrame()
/* 229:    */   {
/* 230:244 */     return AndroidEnv.getCurrentActivity().getWindow();
/* 231:    */   }
/* 232:    */   
/* 233:    */   public void removeMenuBar() {}
/* 234:    */   
/* 235:    */   public void popupPage(String pageName, UIEvent event)
/* 236:    */     throws MobileApplicationException
/* 237:    */   {
/* 238:252 */     AbstractMobileControl tempControl = MobileDeviceAppSession.getSession().getApplicationAsUIApplication().getScreen(pageName);
/* 239:253 */     if ((!(tempControl instanceof PageControl)) || (((PageControl)tempControl).sendInitEvent()))
/* 240:    */     {
/* 241:254 */       View view = (View)tempControl.composeComponents()[0];
/* 242:    */       
/* 243:    */ 
/* 244:    */ 
/* 245:258 */       view.setBackgroundResource(com.ibm.tivoli.maximo.mobile.android.util.UIUtil.getResourceId(R.drawable.class, "custom_dialog_background"));
/* 246:    */       
/* 247:260 */       NPopUpWindow popUp = new NPopUpWindow(AndroidEnv.getCurrentActivity());
/* 248:261 */       popUp.setContentView(view);
/* 249:262 */       if (pageAcceptsBackButtonInPopUp(pageName)) {
/* 250:263 */         popUp.enableBackButton();
/* 251:    */       }
/* 252:265 */       AndroidEnv.setPopUpPage(popUp);
/* 253:266 */       popUp.show();
/* 254:    */     }
/* 255:    */   }
/* 256:    */   
/* 257:    */   private boolean pageAcceptsBackButtonInPopUp(String pageName)
/* 258:    */   {
/* 259:271 */     return com.mro.mobile.ui.res.UIUtil.getApplication().pageAcceptsBackButtonInPopUp(pageName);
/* 260:    */   }
/* 261:    */   
/* 262:    */   public UIComponent getFocusOwner()
/* 263:    */   {
/* 264:275 */     Activity current = AndroidEnv.getCurrentActivity();
/* 265:276 */     if (current != null)
/* 266:    */     {
/* 267:277 */       View focusOwner = current.getWindow().getCurrentFocus();
/* 268:278 */       return (focusOwner instanceof UIComponent) ? (UIComponent)focusOwner : null;
/* 269:    */     }
/* 270:280 */     return null;
/* 271:    */   }
/* 272:    */   
/* 273:    */   public boolean isValidThreadToRefresh(Thread candidate)
/* 274:    */   {
/* 275:285 */     return this.androidApplication.isUIThread(candidate);
/* 276:    */   }
/* 277:    */   
/* 278:    */   public int getWindowMaxSizeForTable()
/* 279:    */   {
/* 280:290 */     return 2147483647;
/* 281:    */   }
/* 282:    */   
/* 283:    */   public boolean supportFontImageSizeConfiguration()
/* 284:    */   {
/* 285:294 */     return false;
/* 286:    */   }
/* 287:    */   
/* 288:    */   protected void showPageMenuBar(final PageControl page)
/* 289:    */   {
/* 290:299 */     this.androidApplication.runOnUiThread(new Runnable()
/* 291:    */     {
/* 292:    */       public void run()
/* 293:    */       {
/* 294:302 */         page.showMenuBar();
/* 295:    */       }
/* 296:    */     });
/* 297:    */   }
/* 298:    */   
/* 299:    */   public void setPageFocus(final PageControl page)
/* 300:    */   {
/* 301:309 */     this.androidApplication.runOnUiThread(new Runnable()
/* 302:    */     {
/* 303:    */       public void run()
/* 304:    */       {
/* 305:312 */         page.setPageFocus();
/* 306:    */       }
/* 307:    */     });
/* 308:    */   }
/* 309:    */   
/* 310:    */   public void refreshScreen(final AbstractMobileControl screen, final UIEvent event, final boolean addPageGroupMenubar)
/* 311:    */     throws MobileApplicationException
/* 312:    */   {
/* 313:318 */     this.androidApplication.runOnUiThread(new Runnable()
/* 314:    */     {
/* 315:    */       public void run()
/* 316:    */       {
/* 317:    */         try
/* 318:    */         {
/* 319:322 */           if ((addPageGroupMenubar) && 
/* 320:323 */             (screen.getPageGroup() != null)) {
/* 321:324 */             screen.addMenubar();
/* 322:    */           }
/* 323:327 */           screen.refresh(event);
/* 324:    */         }
/* 325:    */         catch (MobileApplicationException mae)
/* 326:    */         {
/* 327:329 */           com.mro.mobile.ui.res.UIUtil.showExceptionMessage(mae, event, 0);
/* 328:    */         }
/* 329:    */       }
/* 330:    */     });
/* 331:    */   }
/* 332:    */   
/* 333:    */   public boolean supportsCamera()
/* 334:    */     throws MobileApplicationException
/* 335:    */   {
/* 336:337 */     if (this.supportsCamera == null)
/* 337:    */     {
/* 338:338 */       Context context = AndroidEnv.getCurrentActivity();
/* 339:339 */       PackageManager packageManager = context.getPackageManager();
/* 340:340 */       Intent intent = new Intent("android.media.action.IMAGE_CAPTURE");
/* 341:341 */       List<ResolveInfo> list = packageManager.queryIntentActivities(intent, 65536);
/* 342:342 */       this.supportsCamera = Boolean.valueOf(list.size() > 0);
/* 343:    */     }
/* 344:344 */     return this.supportsCamera.booleanValue();
/* 345:    */   }
/* 346:    */   
/* 347:    */   public boolean supportsTableColumnResizer()
/* 348:    */   {
/* 349:348 */     return true;
/* 350:    */   }
/* 351:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.android.AndroidMobileUIManager
 * JD-Core Version:    0.7.0.1
 */