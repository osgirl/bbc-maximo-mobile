/*  1:   */ package com.mro.mobile.ui.res.android;
/*  2:   */ 
/*  3:   */ import android.graphics.Color;
/*  4:   */ import android.graphics.Typeface;
/*  5:   */ import com.mro.mobile.ui.res.FontColorResolver;
/*  6:   */ import com.mro.mobile.ui.res.MobileUIPropertiesSupport;
/*  7:   */ 
/*  8:   */ public class ADFontColorResolverImpl
/*  9:   */   implements FontColorResolver
/* 10:   */ {
/* 11:   */   public Object getColor(String key, MobileUIPropertiesSupport mobileUIProperties)
/* 12:   */   {
/* 13:31 */     Object colorVal = mobileUIProperties.get(key);
/* 14:32 */     Integer color = null;
/* 15:33 */     if ((colorVal instanceof Integer))
/* 16:   */     {
/* 17:34 */       color = (Integer)colorVal;
/* 18:   */     }
/* 19:35 */     else if ((colorVal instanceof String))
/* 20:   */     {
/* 21:37 */       color = (Integer)createColor((String)colorVal, mobileUIProperties);
/* 22:38 */       if (color != null) {
/* 23:39 */         mobileUIProperties.put(key, color);
/* 24:   */       }
/* 25:   */     }
/* 26:41 */     return color;
/* 27:   */   }
/* 28:   */   
/* 29:   */   public Object createColor(String color, MobileUIPropertiesSupport mobileUIProperties)
/* 30:   */   {
/* 31:46 */     if (color.startsWith("#")) {
/* 32:48 */       return new Integer(Color.parseColor(color));
/* 33:   */     }
/* 34:52 */     return getColor("color." + color, mobileUIProperties);
/* 35:   */   }
/* 36:   */   
/* 37:   */   public Object getFont(String key, MobileUIPropertiesSupport mobileUIProperties)
/* 38:   */   {
/* 39:58 */     Object fontVal = mobileUIProperties.get(key);
/* 40:59 */     Typeface font = null;
/* 41:60 */     if ((fontVal instanceof Typeface))
/* 42:   */     {
/* 43:61 */       font = (Typeface)fontVal;
/* 44:   */     }
/* 45:62 */     else if ((fontVal instanceof String))
/* 46:   */     {
/* 47:64 */       String val = (String)fontVal;
/* 48:65 */       int i = val.indexOf(",");
/* 49:66 */       int i2 = val.indexOf(",", i + 1);
/* 50:67 */       if ((i > 0) && (i2 > 0))
/* 51:   */       {
/* 52:69 */         String name = val.substring(1, i).trim();
/* 53:70 */         int style = Integer.parseInt(val.substring(i + 1, i2).trim());
/* 54:71 */         int size = Integer.parseInt(val.substring(i2 + 1).trim());
/* 55:   */         
/* 56:   */ 
/* 57:74 */         return Typeface.create(Typeface.SANS_SERIF, 0);
/* 58:   */       }
/* 59:77 */       if (font != null) {
/* 60:78 */         mobileUIProperties.put(key, font);
/* 61:   */       }
/* 62:   */     }
/* 63:80 */     return font;
/* 64:   */   }
/* 65:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.android.ADFontColorResolverImpl
 * JD-Core Version:    0.7.0.1
 */