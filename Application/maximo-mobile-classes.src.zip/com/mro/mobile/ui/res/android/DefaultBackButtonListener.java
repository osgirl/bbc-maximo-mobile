/*  1:   */ package com.mro.mobile.ui.res.android;
/*  2:   */ 
/*  3:   */ import android.content.DialogInterface;
/*  4:   */ import android.content.DialogInterface.OnKeyListener;
/*  5:   */ import android.view.KeyEvent;
/*  6:   */ import android.view.View;
/*  7:   */ import android.view.View.OnKeyListener;
/*  8:   */ 
/*  9:   */ public class DefaultBackButtonListener
/* 10:   */   implements DialogInterface.OnKeyListener, View.OnKeyListener
/* 11:   */ {
/* 12:27 */   private static DefaultBackButtonListener instance = new DefaultBackButtonListener();
/* 13:   */   
/* 14:   */   public static DefaultBackButtonListener getInstance()
/* 15:   */   {
/* 16:31 */     return instance;
/* 17:   */   }
/* 18:   */   
/* 19:   */   public boolean onKey(View v, int keyCode, KeyEvent event)
/* 20:   */   {
/* 21:41 */     return event.getKeyCode() == 4;
/* 22:   */   }
/* 23:   */   
/* 24:   */   public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event)
/* 25:   */   {
/* 26:49 */     return event.getKeyCode() == 4;
/* 27:   */   }
/* 28:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.android.DefaultBackButtonListener
 * JD-Core Version:    0.7.0.1
 */