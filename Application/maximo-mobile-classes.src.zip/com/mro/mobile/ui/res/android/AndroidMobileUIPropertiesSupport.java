/*   1:    */ package com.mro.mobile.ui.res.android;
/*   2:    */ 
/*   3:    */ import com.ibm.tivoli.maximo.mobile.android.util.PropertyUtil;
/*   4:    */ import com.ibm.tivoli.maximo.mobile.resources.R.string;
/*   5:    */ import com.mro.mobile.ui.res.MobileUIPropertiesSupport;
/*   6:    */ import java.util.HashMap;
/*   7:    */ 
/*   8:    */ public class AndroidMobileUIPropertiesSupport
/*   9:    */   implements MobileUIPropertiesSupport
/*  10:    */ {
/*  11:    */   static
/*  12:    */   {
/*  13: 29 */     PropertyUtil.registerRPropertyClass(R.string.class);
/*  14:    */   }
/*  15:    */   
/*  16: 32 */   private HashMap<String, Object> map = new HashMap();
/*  17:    */   
/*  18:    */   public boolean getBooleanValue(String key)
/*  19:    */   {
/*  20: 43 */     if (key != null)
/*  21:    */     {
/*  22: 44 */       Object value = get(key);
/*  23: 45 */       if ((value instanceof String))
/*  24:    */       {
/*  25: 46 */         if (value.equals("1")) {
/*  26: 47 */           return true;
/*  27:    */         }
/*  28: 49 */         return Boolean.valueOf((String)value).booleanValue();
/*  29:    */       }
/*  30:    */     }
/*  31: 52 */     return false;
/*  32:    */   }
/*  33:    */   
/*  34:    */   public String getStringValue(String key)
/*  35:    */   {
/*  36: 64 */     if (key != null)
/*  37:    */     {
/*  38: 65 */       Object value = get(key);
/*  39: 66 */       if ((value instanceof String)) {
/*  40: 67 */         return (String)value;
/*  41:    */       }
/*  42:    */     }
/*  43: 69 */     return null;
/*  44:    */   }
/*  45:    */   
/*  46:    */   public int getIntValue(String key, int defaultVal)
/*  47:    */   {
/*  48: 81 */     if (key != null)
/*  49:    */     {
/*  50: 82 */       Object value = get(key);
/*  51: 83 */       if ((value instanceof String)) {
/*  52: 84 */         return Integer.parseInt((String)value);
/*  53:    */       }
/*  54: 85 */       if ((value instanceof Integer)) {
/*  55: 86 */         return ((Integer)value).intValue();
/*  56:    */       }
/*  57:    */     }
/*  58: 88 */     return defaultVal;
/*  59:    */   }
/*  60:    */   
/*  61:    */   public Object getValue(String key)
/*  62:    */   {
/*  63:100 */     if (key != null) {
/*  64:101 */       return get(key);
/*  65:    */     }
/*  66:103 */     return null;
/*  67:    */   }
/*  68:    */   
/*  69:    */   public Object get(String key)
/*  70:    */   {
/*  71:114 */     if (key != null) {
/*  72:115 */       return get(key, false);
/*  73:    */     }
/*  74:117 */     return null;
/*  75:    */   }
/*  76:    */   
/*  77:    */   public Object getValue(String key, boolean exactMatch)
/*  78:    */   {
/*  79:129 */     if (key != null) {
/*  80:130 */       return get(key, exactMatch);
/*  81:    */     }
/*  82:132 */     return null;
/*  83:    */   }
/*  84:    */   
/*  85:    */   public void putValue(String key, Object value)
/*  86:    */   {
/*  87:144 */     put(key, value);
/*  88:    */   }
/*  89:    */   
/*  90:    */   public void put(String key, Object value)
/*  91:    */   {
/*  92:156 */     this.map.put(key, value);
/*  93:    */   }
/*  94:    */   
/*  95:    */   private Object get(String key, boolean exactMatch)
/*  96:    */   {
/*  97:160 */     Object obj = null;
/*  98:161 */     if (key != null)
/*  99:    */     {
/* 100:162 */       String newKey = key.replaceAll("\\.", "_");
/* 101:163 */       obj = PropertyUtil.findPropertyFromResources(newKey);
/* 102:164 */       if ((obj == null) && (!exactMatch))
/* 103:    */       {
/* 104:165 */         int index = 0;
/* 105:166 */         while ((obj == null) && ((index = newKey.indexOf("_", index + 1)) > 0)) {
/* 106:167 */           obj = PropertyUtil.findPropertyFromResources(newKey.substring(index + 1));
/* 107:    */         }
/* 108:    */       }
/* 109:    */     }
/* 110:171 */     if (obj == null) {
/* 111:172 */       return this.map.get(key);
/* 112:    */     }
/* 113:174 */     return obj;
/* 114:    */   }
/* 115:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.android.AndroidMobileUIPropertiesSupport
 * JD-Core Version:    0.7.0.1
 */