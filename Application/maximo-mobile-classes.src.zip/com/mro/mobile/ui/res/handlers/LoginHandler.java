/*   1:    */ package com.mro.mobile.ui.res.handlers;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.MobileMessageGenerator;
/*   5:    */ import com.mro.mobile.app.BasicMobileDeviceUIApplication;
/*   6:    */ import com.mro.mobile.app.DefaultEventHandler;
/*   7:    */ import com.mro.mobile.app.MobileDeviceAppSession;
/*   8:    */ import com.mro.mobile.mbo.MobileMbo;
/*   9:    */ import com.mro.mobile.ui.MobileMboDataBean;
/*  10:    */ import com.mro.mobile.ui.MobileMboDataBeanManager;
/*  11:    */ import com.mro.mobile.ui.event.UIEvent;
/*  12:    */ import com.mro.mobile.ui.res.UIUtil;
/*  13:    */ import com.mro.mobile.ui.res.controls.InputControl;
/*  14:    */ 
/*  15:    */ public class LoginHandler
/*  16:    */   extends DefaultEventHandler
/*  17:    */ {
/*  18:    */   public boolean signin(UIEvent event)
/*  19:    */     throws MobileApplicationException
/*  20:    */   {
/*  21: 46 */     InputControl uCtrl = (InputControl)UIUtil.findControl("username");
/*  22: 47 */     InputControl pCtrl = (InputControl)UIUtil.findControl("password");
/*  23: 48 */     String userName = uCtrl.getControlValue();
/*  24: 49 */     String password = pCtrl.getControlValue();
/*  25: 50 */     if ((UIUtil.isNull(userName)) || (UIUtil.isNull(password))) {
/*  26: 52 */       throw new MobileApplicationException("nouseridpswd");
/*  27:    */     }
/*  28: 55 */     MobileDeviceAppSession deviceAppSession = MobileDeviceAppSession.getSession();
/*  29: 56 */     BasicMobileDeviceUIApplication app = deviceAppSession.getApplicationAsUIApplication();
/*  30:    */     
/*  31: 58 */     app.initializeAppAccess(userName, password, false, event.getProgressObserver());
/*  32:    */     
/*  33: 60 */     return true;
/*  34:    */   }
/*  35:    */   
/*  36:    */   public boolean signinverifywithserver(UIEvent event)
/*  37:    */     throws MobileApplicationException
/*  38:    */   {
/*  39: 65 */     InputControl uCtrl = (InputControl)UIUtil.findControl("username");
/*  40: 66 */     InputControl pCtrl = (InputControl)UIUtil.findControl("password");
/*  41: 67 */     String userName = uCtrl.getControlValue();
/*  42: 68 */     String password = pCtrl.getControlValue();
/*  43:    */     
/*  44: 70 */     MobileDeviceAppSession deviceAppSession = MobileDeviceAppSession.getSession();
/*  45: 71 */     BasicMobileDeviceUIApplication app = deviceAppSession.getApplicationAsUIApplication();
/*  46:    */     
/*  47:    */ 
/*  48: 74 */     app.initializeAppAccess(userName, password, true, event.getProgressObserver());
/*  49:    */     
/*  50: 76 */     return true;
/*  51:    */   }
/*  52:    */   
/*  53:    */   public boolean changepwd(UIEvent event)
/*  54:    */     throws MobileApplicationException
/*  55:    */   {
/*  56: 84 */     MobileDeviceAppSession deviceAppSession = MobileDeviceAppSession.getSession();
/*  57: 85 */     BasicMobileDeviceUIApplication app = deviceAppSession.getApplicationAsUIApplication();
/*  58: 86 */     InputControl curPassCtrl = (InputControl)UIUtil.findControl("curpassword");
/*  59: 87 */     InputControl newPassCtrl = (InputControl)UIUtil.findControl("newpassword");
/*  60: 88 */     InputControl confirmNewPassCtrl = (InputControl)UIUtil.findControl("confirmnewpassword");
/*  61:    */     
/*  62: 90 */     String curPassword = curPassCtrl.getControlValue();
/*  63: 91 */     if (!app.isCurrentPasswordMatched(curPassword)) {
/*  64: 93 */       throw new MobileApplicationException("curpasswordinvalid");
/*  65:    */     }
/*  66: 96 */     String newPassword = newPassCtrl.getControlValue();
/*  67: 97 */     String confirmNewPassword = confirmNewPassCtrl.getControlValue();
/*  68: 99 */     if (!newPassword.equals(confirmNewPassword)) {
/*  69:101 */       throw new MobileApplicationException("passwordentriesdonotmatch");
/*  70:    */     }
/*  71:104 */     if (curPassword.equals(newPassword)) {
/*  72:106 */       throw new MobileApplicationException("passwordnewequalsold");
/*  73:    */     }
/*  74:109 */     if (app.isPasswordExpired()) {
/*  75:111 */       app.changeExpiredPassword(newPassword, event.getProgressObserver());
/*  76:    */     } else {
/*  77:115 */       app.changePassword(newPassword, event.getProgressObserver());
/*  78:    */     }
/*  79:118 */     return true;
/*  80:    */   }
/*  81:    */   
/*  82:121 */   boolean checkSnapshotCompleted = false;
/*  83:122 */   boolean snapshotMessageShown = false;
/*  84:    */   
/*  85:    */   public boolean performEvent(UIEvent event)
/*  86:    */     throws MobileApplicationException
/*  87:    */   {
/*  88:126 */     if (event != null)
/*  89:    */     {
/*  90:128 */       String eventId = event.getEventName();
/*  91:130 */       if (eventId.equalsIgnoreCase("signin"))
/*  92:    */       {
/*  93:132 */         MobileDeviceAppSession deviceAppSession1 = MobileDeviceAppSession.getSession();
/*  94:133 */         BasicMobileDeviceUIApplication app1 = deviceAppSession1.getApplicationAsUIApplication();
/*  95:135 */         if (app1.isSnapshotEnabled())
/*  96:    */         {
/*  97:137 */           InputControl uCtrl = (InputControl)UIUtil.findControl("username");
/*  98:138 */           String userName = uCtrl.getControlValue();
/*  99:    */           
/* 100:140 */           String alreadyUsedByUser = app1.getAlreadyUsedByUser(userName);
/* 101:141 */           if ((alreadyUsedByUser != null) && (!alreadyUsedByUser.equalsIgnoreCase(userName)))
/* 102:    */           {
/* 103:143 */             if ((!this.checkSnapshotCompleted) && (!this.snapshotMessageShown))
/* 104:    */             {
/* 105:145 */               String msg = MobileMessageGenerator.generate("saveotherusersnapshot", new Object[] { alreadyUsedByUser });
/* 106:    */               
/* 107:147 */               UIUtil.showOKCANCELMessageBox(event, msg);
/* 108:148 */               this.snapshotMessageShown = true;
/* 109:149 */               return true;
/* 110:    */             }
/* 111:151 */             if (this.snapshotMessageShown) {
/* 112:153 */               if (event.getMsgResponse().equals("1"))
/* 113:    */               {
/* 114:155 */                 this.checkSnapshotCompleted = true;
/* 115:156 */                 this.snapshotMessageShown = false;
/* 116:    */               }
/* 117:    */               else
/* 118:    */               {
/* 119:160 */                 this.checkSnapshotCompleted = false;
/* 120:161 */                 this.snapshotMessageShown = false;
/* 121:162 */                 return true;
/* 122:    */               }
/* 123:    */             }
/* 124:    */           }
/* 125:    */         }
/* 126:168 */         boolean verifyWithServer = false;
/* 127:170 */         if (event.getMsgResponse().equals("1")) {
/* 128:172 */           verifyWithServer = true;
/* 129:    */         }
/* 130:175 */         switch (event.getThreadStatus())
/* 131:    */         {
/* 132:    */         case -1: 
/* 133:178 */           UIUtil.startWorkerThread(this, event);
/* 134:179 */           break;
/* 135:    */         case 1: 
/* 136:182 */           if (verifyWithServer) {
/* 137:184 */             return signinverifywithserver(event);
/* 138:    */           }
/* 139:188 */           return signin(event);
/* 140:    */         case 2: 
/* 141:193 */           MobileDeviceAppSession deviceAppSession = MobileDeviceAppSession.getSession();
/* 142:194 */           BasicMobileDeviceUIApplication app = deviceAppSession.getApplicationAsUIApplication();
/* 143:    */           
/* 144:196 */           initMobileOptions();
/* 145:    */           
/* 146:198 */           UIUtil.getApplication().removeLoginScreen();
/* 147:    */           
/* 148:    */ 
/* 149:201 */           UIUtil.showPage(app.getStartupScreenId());
/* 150:207 */           if (!UIUtil.handleEvent("checkForUpdateLogin")) {
/* 151:208 */             return true;
/* 152:    */           }
/* 153:    */           break;
/* 154:    */         case 0: 
/* 155:    */           break;
/* 156:    */         case 3: 
/* 157:228 */           if ((event.getException() instanceof MobileApplicationException))
/* 158:    */           {
/* 159:230 */             MobileApplicationException appEx = event.getException();
/* 160:231 */             if ((appEx.getKey() != null) && (appEx.getKey().equalsIgnoreCase("passwordexpired")))
/* 161:    */             {
/* 162:233 */               UIUtil.showPage("changepassword");
/* 163:234 */               UIUtil.showExceptionMessage(event.getException(), null, 0);
/* 164:235 */               return true;
/* 165:    */             }
/* 166:237 */             if ((appEx.getKey() != null) && (appEx.getKey().equalsIgnoreCase("passworddurationnotify")))
/* 167:    */             {
/* 168:239 */               UIEvent event1 = new UIEvent(UIUtil.getCurrentScreen(), "changepwdduetoduraion", null, null);
/* 169:240 */               performEvent(event1);
/* 170:241 */               return true;
/* 171:    */             }
/* 172:243 */             if ((appEx.getKey() != null) && (appEx.getKey().equalsIgnoreCase("invaliduser")))
/* 173:    */             {
/* 174:245 */               UIEvent event1 = new UIEvent(UIUtil.getCurrentScreen(), "signinverifywithserver", null, null);
/* 175:246 */               performEvent(event1);
/* 176:247 */               return true;
/* 177:    */             }
/* 178:249 */             if ((appEx.getKey() != null) && (appEx.getKey().equalsIgnoreCase("noappauth")))
/* 179:    */             {
/* 180:251 */               UIEvent event1 = new UIEvent(UIUtil.getCurrentScreen(), "signinverifywithservernoappauth", null, null);
/* 181:252 */               performEvent(event1);
/* 182:253 */               return true;
/* 183:    */             }
/* 184:    */           }
/* 185:257 */           UIUtil.showExceptionMessage(event.getException(), null, 0);
/* 186:    */         }
/* 187:260 */         return true;
/* 188:    */       }
/* 189:262 */       if (eventId.equalsIgnoreCase("changepwdduetoduraion"))
/* 190:    */       {
/* 191:264 */         if (event.getMsgResponse().equals("-1"))
/* 192:    */         {
/* 193:266 */           MobileMboDataBeanManager dataBeanManager = new MobileMboDataBeanManager("PREFERENCES");
/* 194:267 */           MobileMboDataBean preferenceDataBean = dataBeanManager.getDataBean();
/* 195:268 */           Object[] param = { "" };
/* 196:269 */           if (preferenceDataBean != null) {
/* 197:271 */             preferenceDataBean.reset();
/* 198:    */           }
/* 199:273 */           long expdays = UIUtil.getApplication().getNumDaysToExpire();
/* 200:274 */           if (expdays >= 0L) {
/* 201:275 */             param[0] = ("" + expdays);
/* 202:    */           }
/* 203:276 */           UIUtil.showMessageBox("passworddurationnotify", param, "question", 12, event);
/* 204:277 */           return true;
/* 205:    */         }
/* 206:279 */         if (event.getMsgResponse().equals("1"))
/* 207:    */         {
/* 208:281 */           UIUtil.showPage("changepassword");
/* 209:282 */           return true;
/* 210:    */         }
/* 211:284 */         if (event.getMsgResponse().equals("0"))
/* 212:    */         {
/* 213:285 */           MobileDeviceAppSession deviceAppSession = MobileDeviceAppSession.getSession();
/* 214:286 */           BasicMobileDeviceUIApplication app = deviceAppSession.getApplicationAsUIApplication();
/* 215:287 */           UIUtil.getApplication().removeLoginScreen();
/* 216:    */           
/* 217:289 */           UIUtil.showPage(app.getStartupScreenId());
/* 218:290 */           initMobileOptions();
/* 219:291 */           if (!app.isAllDataRefreshedOnce())
/* 220:    */           {
/* 221:293 */             UIUtil.handleEvent("refreshalldataonce");
/* 222:294 */             return true;
/* 223:    */           }
/* 224:297 */           if (app.isRefreshWorkListOnSignInEnabled()) {
/* 225:299 */             UIUtil.handleEvent("refreshworksetnoprompt");
/* 226:    */           }
/* 227:301 */           return true;
/* 228:    */         }
/* 229:    */       }
/* 230:304 */       else if ((eventId.equalsIgnoreCase("signinverifywithserver")) || (eventId.equalsIgnoreCase("signinverifywithservernoappauth")))
/* 231:    */       {
/* 232:307 */         boolean verifyWithServer = false;
/* 233:309 */         if (event.getMsgResponse().equals("-1"))
/* 234:    */         {
/* 235:311 */           String msg = "";
/* 236:312 */           if (eventId.equalsIgnoreCase("signinverifywithserver")) {
/* 237:314 */             msg = MobileMessageGenerator.generate("invaliduserandverify", null);
/* 238:    */           } else {
/* 239:318 */             msg = MobileMessageGenerator.generate("noappauthandverify", null);
/* 240:    */           }
/* 241:321 */           UIUtil.showMessageBoxControl("invaliduserandverify", msg, event);
/* 242:322 */           return true;
/* 243:    */         }
/* 244:324 */         if (event.getMsgResponse().equals("1"))
/* 245:    */         {
/* 246:326 */           verifyWithServer = true;
/* 247:327 */           switch (event.getThreadStatus())
/* 248:    */           {
/* 249:    */           case -1: 
/* 250:330 */             UIUtil.startWorkerThread(this, event);
/* 251:331 */             break;
/* 252:    */           case 1: 
/* 253:334 */             if (verifyWithServer) {
/* 254:336 */               return signinverifywithserver(event);
/* 255:    */             }
/* 256:340 */             return signin(event);
/* 257:    */           case 2: 
/* 258:345 */             MobileDeviceAppSession deviceAppSession = MobileDeviceAppSession.getSession();
/* 259:346 */             BasicMobileDeviceUIApplication app = deviceAppSession.getApplicationAsUIApplication();
/* 260:    */             
/* 261:348 */             UIUtil.getApplication().removeLoginScreen();
/* 262:    */             
/* 263:    */ 
/* 264:351 */             UIUtil.showPage(app.getStartupScreenId());
/* 265:    */             
/* 266:353 */             initMobileOptions();
/* 267:354 */             if (app.isRefreshWorkListOnSignInEnabled()) {
/* 268:356 */               UIUtil.handleEvent("refreshworksetnoprompt");
/* 269:    */             }
/* 270:    */             break;
/* 271:    */           case 0: 
/* 272:    */             break;
/* 273:    */           case 3: 
/* 274:364 */             if ((event.getException() instanceof MobileApplicationException))
/* 275:    */             {
/* 276:366 */               MobileApplicationException appEx = event.getException();
/* 277:367 */               if ((appEx.getKey() != null) && (appEx.getKey().equalsIgnoreCase("passwordexpired")))
/* 278:    */               {
/* 279:369 */                 UIUtil.showPage("changepassword");
/* 280:370 */                 UIUtil.showExceptionMessage(event.getException(), null, 0);
/* 281:371 */                 return true;
/* 282:    */               }
/* 283:    */             }
/* 284:375 */             UIUtil.showExceptionMessage(event.getException(), null, 0);
/* 285:    */           }
/* 286:378 */           return true;
/* 287:    */         }
/* 288:    */       }
/* 289:    */       else
/* 290:    */       {
/* 291:381 */         if (eventId.equalsIgnoreCase("changepwd"))
/* 292:    */         {
/* 293:383 */           switch (event.getThreadStatus())
/* 294:    */           {
/* 295:    */           case -1: 
/* 296:386 */             UIUtil.startWorkerThread(this, event);
/* 297:387 */             break;
/* 298:    */           case 1: 
/* 299:390 */             changepwd(event);
/* 300:391 */             break;
/* 301:    */           case 2: 
/* 302:395 */             MobileDeviceAppSession deviceAppSession = MobileDeviceAppSession.getSession();
/* 303:396 */             BasicMobileDeviceUIApplication app = deviceAppSession.getApplicationAsUIApplication();
/* 304:397 */             UIUtil.showPage(app.getStartupScreenId());
/* 305:398 */             initMobileOptions();
/* 306:399 */             if (!app.isAllDataRefreshedOnce())
/* 307:    */             {
/* 308:401 */               UIUtil.handleEvent("refreshalldataonce");
/* 309:402 */               return true;
/* 310:    */             }
/* 311:405 */             if (app.isRefreshWorkListOnSignInEnabled()) {
/* 312:407 */               UIUtil.handleEvent("refreshworksetnoprompt");
/* 313:    */             }
/* 314:    */             break;
/* 315:    */           case 0: 
/* 316:    */             break;
/* 317:    */           case 3: 
/* 318:415 */             UIUtil.showExceptionMessage(event.getException(), null, 0);
/* 319:    */           }
/* 320:418 */           return true;
/* 321:    */         }
/* 322:420 */         if (eventId.equalsIgnoreCase("cancelchangepwd"))
/* 323:    */         {
/* 324:422 */           MobileDeviceAppSession deviceAppSession = MobileDeviceAppSession.getSession();
/* 325:423 */           BasicMobileDeviceUIApplication app = deviceAppSession.getApplicationAsUIApplication();
/* 326:424 */           if (app.isPasswordExpired()) {
/* 327:426 */             UIUtil.showPage("login");
/* 328:    */           } else {
/* 329:430 */             UIUtil.closePage();
/* 330:    */           }
/* 331:432 */           return true;
/* 332:    */         }
/* 333:    */       }
/* 334:    */     }
/* 335:435 */     return false;
/* 336:    */   }
/* 337:    */   
/* 338:    */   private void initMobileOptions()
/* 339:    */     throws MobileApplicationException
/* 340:    */   {
/* 341:440 */     MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager("MOBILEOPTIONS");
/* 342:441 */     MobileMboDataBean optionBean = mgrDBMgr.getDataBean();
/* 343:442 */     if (optionBean != null)
/* 344:    */     {
/* 345:444 */       int iLoop = 0;
/* 346:445 */       MobileMbo optionMbo = optionBean.getMobileMbo(0);
/* 347:446 */       while (optionMbo != null)
/* 348:    */       {
/* 349:448 */         String strValue = optionMbo.getValue("VALUE");
/* 350:449 */         if ((strValue != null) && (!strValue.equals(""))) {
/* 351:451 */           UIUtil.getApplication().setProperty(optionMbo.getValue("APP") + "." + optionMbo.getValue("NAME"), strValue);
/* 352:    */         }
/* 353:455 */         iLoop++;
/* 354:456 */         optionMbo = optionBean.getMobileMbo(iLoop);
/* 355:    */       }
/* 356:    */     }
/* 357:    */   }
/* 358:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.handlers.LoginHandler
 * JD-Core Version:    0.7.0.1
 */