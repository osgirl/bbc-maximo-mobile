/*  1:   */ package com.mro.mobile.ui.res;
/*  2:   */ 
/*  3:   */ public abstract class MobileUIResources
/*  4:   */ {
/*  5:   */   public static final String RESOURCES_FOLDER = "/resources";
/*  6:29 */   private static MobileUIResourcesType mode = MobileUIResourcesType.SMALL;
/*  7:   */   
/*  8:   */   public static MobileUIResources getInstance()
/*  9:   */   {
/* 10:32 */     return mode.getMobileUIResourcesHandler();
/* 11:   */   }
/* 12:   */   
/* 13:   */   public static void setMode(MobileUIResourcesType mode)
/* 14:   */   {
/* 15:36 */     mode = mode;
/* 16:   */   }
/* 17:   */   
/* 18:   */   public static MobileUIResourcesType getMode()
/* 19:   */   {
/* 20:40 */     return mode;
/* 21:   */   }
/* 22:   */   
/* 23:   */   public String getCurrentResourceFolder()
/* 24:   */   {
/* 25:44 */     StringBuffer attr1 = new StringBuffer("/resources");
/* 26:45 */     attr1.append(getFolderName());
/* 27:46 */     return attr1.toString();
/* 28:   */   }
/* 29:   */   
/* 30:   */   public String getImagePath(String image)
/* 31:   */   {
/* 32:50 */     String value = null;
/* 33:51 */     if (image.indexOf(getCurrentResourceFolder()) < 0)
/* 34:   */     {
/* 35:52 */       StringBuffer attr1 = new StringBuffer();
/* 36:53 */       attr1.append(getCurrentResourceFolder());
/* 37:54 */       if (image.charAt(0) != '/') {
/* 38:55 */         attr1.append("/");
/* 39:   */       }
/* 40:57 */       attr1.append(image);
/* 41:58 */       value = attr1.toString();
/* 42:59 */       return value;
/* 43:   */     }
/* 44:61 */     return image;
/* 45:   */   }
/* 46:   */   
/* 47:   */   public abstract String getFolderName();
/* 48:   */   
/* 49:   */   public abstract float getFactorMultiplierFont();
/* 50:   */   
/* 51:   */   public abstract float getFactorMultiplierTableWidth();
/* 52:   */   
/* 53:   */   public abstract float getFactorMultiplierImageSize();
/* 54:   */   
/* 55:   */   public abstract String toString();
/* 56:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.MobileUIResources
 * JD-Core Version:    0.7.0.1
 */