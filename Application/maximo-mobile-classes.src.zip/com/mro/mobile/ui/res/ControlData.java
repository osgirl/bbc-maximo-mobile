package com.mro.mobile.ui.res;

public abstract interface ControlData
{
  public abstract String getName();
  
  public abstract String getValue(String paramString);
  
  public abstract ControlData[] getChildControlData();
  
  public abstract void putValue(String paramString1, String paramString2);
  
  public abstract void resetValue(String paramString);
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.ControlData
 * JD-Core Version:    0.7.0.1
 */