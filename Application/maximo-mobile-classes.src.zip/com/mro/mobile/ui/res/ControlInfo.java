/*   1:    */ package com.mro.mobile.ui.res;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.type.Serializer;
/*   4:    */ import com.mro.mobile.type.TypeRegistry;
/*   5:    */ import java.io.DataInput;
/*   6:    */ import java.io.DataOutput;
/*   7:    */ import java.io.IOException;
/*   8:    */ import java.util.Enumeration;
/*   9:    */ import java.util.Hashtable;
/*  10:    */ import java.util.Vector;
/*  11:    */ 
/*  12:    */ public class ControlInfo
/*  13:    */   implements Serializer
/*  14:    */ {
/*  15: 28 */   private static final Vector dummy = new Vector(0);
/*  16: 30 */   private Hashtable components = new Hashtable();
/*  17:    */   
/*  18:    */   public Enumeration getAttributes(String componentName)
/*  19:    */   {
/*  20: 34 */     Object obj = this.components.get(componentName);
/*  21: 35 */     if (obj == null) {
/*  22: 37 */       return dummy.elements();
/*  23:    */     }
/*  24: 40 */     Vector attributes = (Vector)obj;
/*  25:    */     
/*  26: 42 */     return attributes.elements();
/*  27:    */   }
/*  28:    */   
/*  29:    */   public int getAttributeSize(String componentName)
/*  30:    */   {
/*  31: 47 */     Object obj = this.components.get(componentName);
/*  32: 48 */     if (obj == null) {
/*  33: 50 */       return 0;
/*  34:    */     }
/*  35: 53 */     Vector attributes = (Vector)obj;
/*  36:    */     
/*  37: 55 */     return attributes.size();
/*  38:    */   }
/*  39:    */   
/*  40:    */   public void addAttribute(String componentName, String attribute)
/*  41:    */   {
/*  42: 60 */     Object obj = this.components.get(componentName);
/*  43: 61 */     if (obj == null)
/*  44:    */     {
/*  45: 63 */       Vector attributes = new Vector();
/*  46: 64 */       attributes.addElement(attribute);
/*  47: 65 */       this.components.put(componentName, attributes);
/*  48:    */     }
/*  49:    */     else
/*  50:    */     {
/*  51: 69 */       Vector attributes = (Vector)obj;
/*  52: 70 */       attributes.addElement(attribute);
/*  53:    */     }
/*  54:    */   }
/*  55:    */   
/*  56:    */   static
/*  57:    */   {
/*  58: 77 */     ControlInfo i = new ControlInfo();
/*  59: 78 */     TypeRegistry.getTypeRegistry().addType("ComponentInfo", i.getClass(), i);
/*  60:    */   }
/*  61:    */   
/*  62:    */   public Object readInstance(DataInput input, String name)
/*  63:    */     throws IOException
/*  64:    */   {
/*  65: 86 */     if (name.equals("ComponentInfo"))
/*  66:    */     {
/*  67: 88 */       ControlInfo cInfo = new ControlInfo();
/*  68:    */       
/*  69: 90 */       int noOfComponents = input.readInt();
/*  70: 91 */       for (int i = 0; i < noOfComponents; i++)
/*  71:    */       {
/*  72: 93 */         String componentName = input.readUTF();
/*  73: 94 */         int noOfAttributes = input.readInt();
/*  74: 95 */         for (int j = 0; j < noOfAttributes; j++)
/*  75:    */         {
/*  76: 97 */           String attributeName = input.readUTF();
/*  77: 98 */           cInfo.addAttribute(componentName, attributeName);
/*  78:    */         }
/*  79:    */       }
/*  80:103 */       return cInfo;
/*  81:    */     }
/*  82:106 */     throw new RuntimeException("The type " + name + " not supported.");
/*  83:    */   }
/*  84:    */   
/*  85:    */   public void writeInstance(DataOutput output, Object obj)
/*  86:    */     throws IOException
/*  87:    */   {
/*  88:114 */     if ((obj instanceof ControlInfo))
/*  89:    */     {
/*  90:116 */       ControlInfo cInfo = (ControlInfo)obj;
/*  91:    */       
/*  92:118 */       int noOfComponents = this.components.size();
/*  93:119 */       output.writeInt(noOfComponents);
/*  94:    */       
/*  95:121 */       Enumeration keyEnum = this.components.keys();
/*  96:123 */       for (int i = 0; i < noOfComponents; i++)
/*  97:    */       {
/*  98:125 */         String componentName = (String)keyEnum.nextElement();
/*  99:126 */         output.writeUTF(componentName);
/* 100:    */         
/* 101:128 */         Vector cAttributes = (Vector)this.components.get(componentName);
/* 102:    */         
/* 103:130 */         int noOfAttributes = cAttributes.size();
/* 104:131 */         output.writeInt(noOfAttributes);
/* 105:132 */         for (int j = 0; j < noOfAttributes; j++)
/* 106:    */         {
/* 107:134 */           String attributeName = (String)cAttributes.elementAt(j);
/* 108:135 */           output.writeUTF(attributeName);
/* 109:    */         }
/* 110:    */       }
/* 111:    */     }
/* 112:    */   }
/* 113:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.ControlInfo
 * JD-Core Version:    0.7.0.1
 */