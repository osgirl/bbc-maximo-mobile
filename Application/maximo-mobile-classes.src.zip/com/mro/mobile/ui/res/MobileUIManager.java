/*   1:    */ package com.mro.mobile.ui.res;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.MobileMessageGenerator;
/*   5:    */ import com.mro.mobile.MobileScreenRegistry;
/*   6:    */ import com.mro.mobile.ProgressObserver;
/*   7:    */ import com.mro.mobile.ui.DataBeanCache;
/*   8:    */ import com.mro.mobile.ui.MobileMboDataBean;
/*   9:    */ import com.mro.mobile.ui.MobileMboDataFormatter;
/*  10:    */ import com.mro.mobile.ui.MobileUIControlData;
/*  11:    */ import com.mro.mobile.ui.UIControlManager;
/*  12:    */ import com.mro.mobile.ui.event.UIEvent;
/*  13:    */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*  14:    */ import com.mro.mobile.ui.res.controls.ButtonControl;
/*  15:    */ import com.mro.mobile.ui.res.controls.ButtonStateControl;
/*  16:    */ import com.mro.mobile.ui.res.controls.CalendarControl;
/*  17:    */ import com.mro.mobile.ui.res.controls.CheckboxControl;
/*  18:    */ import com.mro.mobile.ui.res.controls.DropDownControl;
/*  19:    */ import com.mro.mobile.ui.res.controls.FileDialogueControl;
/*  20:    */ import com.mro.mobile.ui.res.controls.ImageControl;
/*  21:    */ import com.mro.mobile.ui.res.controls.LabelControl;
/*  22:    */ import com.mro.mobile.ui.res.controls.LinkControl;
/*  23:    */ import com.mro.mobile.ui.res.controls.LongDescription;
/*  24:    */ import com.mro.mobile.ui.res.controls.LookupControl;
/*  25:    */ import com.mro.mobile.ui.res.controls.MenuBarControl;
/*  26:    */ import com.mro.mobile.ui.res.controls.MenuControl;
/*  27:    */ import com.mro.mobile.ui.res.controls.MenuItemControl;
/*  28:    */ import com.mro.mobile.ui.res.controls.MenuViewControl;
/*  29:    */ import com.mro.mobile.ui.res.controls.MultiLineTextboxControl;
/*  30:    */ import com.mro.mobile.ui.res.controls.PageControl;
/*  31:    */ import com.mro.mobile.ui.res.controls.PageGroupControl;
/*  32:    */ import com.mro.mobile.ui.res.controls.PopUpImageControl;
/*  33:    */ import com.mro.mobile.ui.res.controls.ProgressControl;
/*  34:    */ import com.mro.mobile.ui.res.controls.ReasonForChangeControl;
/*  35:    */ import com.mro.mobile.ui.res.controls.SectionColControl;
/*  36:    */ import com.mro.mobile.ui.res.controls.SectionControl;
/*  37:    */ import com.mro.mobile.ui.res.controls.SectionRowControl;
/*  38:    */ import com.mro.mobile.ui.res.controls.SectionSeparatorControl;
/*  39:    */ import com.mro.mobile.ui.res.controls.SignatureCaptureControl;
/*  40:    */ import com.mro.mobile.ui.res.controls.SpinControl;
/*  41:    */ import com.mro.mobile.ui.res.controls.StateControl;
/*  42:    */ import com.mro.mobile.ui.res.controls.TabControl;
/*  43:    */ import com.mro.mobile.ui.res.controls.TabGroupControl;
/*  44:    */ import com.mro.mobile.ui.res.controls.TableColControl;
/*  45:    */ import com.mro.mobile.ui.res.controls.TableControl;
/*  46:    */ import com.mro.mobile.ui.res.controls.TextboxControl;
/*  47:    */ import com.mro.mobile.ui.res.controls.ToolBarContainerControl;
/*  48:    */ import com.mro.mobile.ui.res.controls.ToolBarLeftControl;
/*  49:    */ import com.mro.mobile.ui.res.controls.ToolBarRightControl;
/*  50:    */ import com.mro.mobile.ui.res.controls.TreeControl;
/*  51:    */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  52:    */ import java.util.ArrayList;
/*  53:    */ import java.util.Enumeration;
/*  54:    */ import java.util.Iterator;
/*  55:    */ import java.util.Stack;
/*  56:    */ 
/*  57:    */ public abstract class MobileUIManager
/*  58:    */ {
/*  59: 61 */   private String startupScreenId = "STARTCENTER";
/*  60: 63 */   private Stack activeScreens = new Stack();
/*  61: 65 */   private UIEvent userEvent = null;
/*  62: 67 */   private boolean stopevents = false;
/*  63:    */   
/*  64:    */   public abstract void setFrameSize();
/*  65:    */   
/*  66:    */   public abstract MobileMboDataFormatter getMobileMboDataFormatter();
/*  67:    */   
/*  68:    */   protected abstract void registerUIWidgetsForControls();
/*  69:    */   
/*  70:    */   public abstract void hidewait();
/*  71:    */   
/*  72:    */   public abstract void showWait();
/*  73:    */   
/*  74:    */   public abstract void setVisible(boolean paramBoolean);
/*  75:    */   
/*  76:    */   public abstract void setFocusOnNothing();
/*  77:    */   
/*  78:    */   protected abstract void setPageInWindow(UIComponent paramUIComponent);
/*  79:    */   
/*  80:    */   protected abstract void setWindowTitle(String paramString);
/*  81:    */   
/*  82:    */   protected abstract void showPageMenuBar(PageControl paramPageControl);
/*  83:    */   
/*  84:    */   public abstract void setPageFocus(PageControl paramPageControl);
/*  85:    */   
/*  86:    */   public abstract void enableMenu(boolean paramBoolean);
/*  87:    */   
/*  88:    */   public abstract int getWindowWidth();
/*  89:    */   
/*  90:    */   public abstract int getWindowHeight();
/*  91:    */   
/*  92:    */   public abstract Object getNativeWindowFrame();
/*  93:    */   
/*  94:    */   public abstract void removeMenuBar();
/*  95:    */   
/*  96:    */   public abstract void popupPage(String paramString, UIEvent paramUIEvent)
/*  97:    */     throws MobileApplicationException;
/*  98:    */   
/*  99:    */   public abstract UIComponent getFocusOwner();
/* 100:    */   
/* 101:    */   public abstract void release();
/* 102:    */   
/* 103:    */   public String getStartupScreenId()
/* 104:    */   {
/* 105:111 */     return this.startupScreenId;
/* 106:    */   }
/* 107:    */   
/* 108:    */   public void setStartupScreenId(String startupScreenId)
/* 109:    */   {
/* 110:115 */     this.startupScreenId = startupScreenId;
/* 111:    */   }
/* 112:    */   
/* 113:    */   public void init()
/* 114:    */     throws MobileApplicationException
/* 115:    */   {
/* 116:119 */     registerUIWidgetsForControls();
/* 117:120 */     registerUIControls(UIControlManager.getInstance());
/* 118:    */   }
/* 119:    */   
/* 120:    */   public void registerUIControls(UIControlManager controlManager)
/* 121:    */   {
/* 122:124 */     controlManager.registerControl("pagegroup", new PageGroupControl());
/* 123:125 */     controlManager.registerControl("page", new PageControl());
/* 124:126 */     controlManager.registerControl("section", new SectionControl());
/* 125:127 */     controlManager.registerControl("sectionrow", new SectionRowControl());
/* 126:128 */     controlManager.registerControl("sectioncol", new SectionColControl());
/* 127:129 */     controlManager.registerControl("textbox", new TextboxControl());
/* 128:130 */     controlManager.registerControl("label", new LabelControl());
/* 129:131 */     controlManager.registerControl("button", new ButtonControl());
/* 130:132 */     controlManager.registerControl("statebutton", new ButtonStateControl());
/* 131:133 */     controlManager.registerControl("link", new LinkControl());
/* 132:134 */     controlManager.registerControl("toolbar", new ToolBarContainerControl());
/* 133:135 */     controlManager.registerControl("left", new ToolBarLeftControl());
/* 134:136 */     controlManager.registerControl("right", new ToolBarRightControl());
/* 135:137 */     controlManager.registerControl("image", new ImageControl());
/* 136:138 */     controlManager.registerControl("table", new TableControl());
/* 137:139 */     controlManager.registerControl("tab", new TabControl());
/* 138:140 */     controlManager.registerControl("tabgroup", new TabGroupControl());
/* 139:141 */     controlManager.registerControl("menubar", new MenuBarControl());
/* 140:142 */     controlManager.registerControl("menu", new MenuControl());
/* 141:143 */     controlManager.registerControl("menuitem", new MenuItemControl());
/* 142:144 */     controlManager.registerControl("menuview", new MenuViewControl());
/* 143:145 */     controlManager.registerControl("checkbox", new CheckboxControl());
/* 144:146 */     controlManager.registerControl("dropdown", new DropDownControl());
/* 145:147 */     controlManager.registerControl("popupmenu", new PopUpImageControl());
/* 146:148 */     controlManager.registerControl("lookup", new LookupControl());
/* 147:149 */     controlManager.registerControl("tablecolumn", new TableColControl());
/* 148:150 */     controlManager.registerControl("stateful", new StateControl());
/* 149:151 */     controlManager.registerControl("progress", new ProgressControl());
/* 150:152 */     controlManager.registerControl("calendar", new CalendarControl());
/* 151:153 */     controlManager.registerControl("reasonchange", new ReasonForChangeControl());
/* 152:154 */     controlManager.registerControl("signature", new SignatureCaptureControl());
/* 153:155 */     controlManager.registerControl("filedialogue", new FileDialogueControl());
/* 154:156 */     controlManager.registerControl("spin", new SpinControl());
/* 155:157 */     controlManager.registerControl("sectionseparator", new SectionSeparatorControl());
/* 156:158 */     controlManager.registerControl("tree", new TreeControl());
/* 157:159 */     controlManager.registerControl("multilinetextbox", new MultiLineTextboxControl());
/* 158:160 */     controlManager.registerControl("longdescription", new LongDescription());
/* 159:    */   }
/* 160:    */   
/* 161:    */   public UIComponent showScreen(AbstractMobileControl screen, AbstractMobileControl launchingControl, boolean stackPage, boolean savePage)
/* 162:    */     throws MobileApplicationException
/* 163:    */   {
/* 164:178 */     PageControl curPage = null;
/* 165:179 */     if (screen != null)
/* 166:    */     {
/* 167:180 */       if (!screen.isAuthorizedToCompose())
/* 168:    */       {
/* 169:181 */         UIUtil.showFailureMessageBox(MobileMessageGenerator.generate("nopageauth", null));
/* 170:182 */         return null;
/* 171:    */       }
/* 172:185 */       if (!this.activeScreens.isEmpty()) {
/* 173:186 */         curPage = (PageControl)this.activeScreens.peek();
/* 174:    */       }
/* 175:188 */       if (curPage != null)
/* 176:    */       {
/* 177:189 */         if (curPage.getId().equals(screen.getId())) {
/* 178:190 */           return null;
/* 179:    */         }
/* 180:191 */         curPage.setToBeRemoved(true);
/* 181:    */       }
/* 182:193 */       if ((!savePage) || (curPage == null) || (curPage.sendSaveEvent()))
/* 183:    */       {
/* 184:194 */         if (getStartupScreenId().equals(screen.getId()))
/* 185:    */         {
/* 186:197 */           DataBeanCache.removeAllDataBeans();
/* 187:198 */           while (this.activeScreens.size() > 0)
/* 188:    */           {
/* 189:199 */             PageControl page = (PageControl)this.activeScreens.pop();
/* 190:200 */             page.cleanup();
/* 191:    */           }
/* 192:204 */           if ((screen instanceof PageControl))
/* 193:    */           {
/* 194:205 */             ((PageControl)screen).setLaunchingControl(launchingControl);
/* 195:206 */             ((PageControl)screen).sendInitEvent();
/* 196:207 */             this.activeScreens.push(screen);
/* 197:    */           }
/* 198:    */         }
/* 199:    */         else
/* 200:    */         {
/* 201:210 */           boolean pageinstack = false;
/* 202:211 */           int stopPopIndex = this.activeScreens.size() - 1;
/* 203:215 */           if ((!stackPage) && (!this.activeScreens.isEmpty())) {
/* 204:216 */             for (; stopPopIndex >= 0; stopPopIndex--)
/* 205:    */             {
/* 206:217 */               AbstractMobileControl page = (AbstractMobileControl)this.activeScreens.get(stopPopIndex);
/* 207:218 */               if (page.getId().equals(screen.getId()))
/* 208:    */               {
/* 209:219 */                 screen = page;
/* 210:220 */                 pageinstack = true;
/* 211:221 */                 break;
/* 212:    */               }
/* 213:    */             }
/* 214:    */           }
/* 215:225 */           if (pageinstack) {
/* 216:227 */             while (this.activeScreens.size() > stopPopIndex + 1) {
/* 217:228 */               popPageFromStack((PageControl)screen);
/* 218:    */             }
/* 219:    */           }
/* 220:231 */           if ((screen instanceof PageControl))
/* 221:    */           {
/* 222:232 */             ((PageControl)screen).setLaunchingControl(launchingControl);
/* 223:233 */             if (!((PageControl)screen).sendInitEvent())
/* 224:    */             {
/* 225:237 */               if (curPage != null) {
/* 226:238 */                 curPage.setToBeRemoved(false);
/* 227:    */               }
/* 228:242 */               curPage = (PageControl)this.activeScreens.peek();
/* 229:243 */               if ((curPage != null) && (curPage.getComponents() != null))
/* 230:    */               {
/* 231:244 */                 curPage.refresh(null);
/* 232:245 */                 return null;
/* 233:    */               }
/* 234:247 */               screen = curPage;
/* 235:    */             }
/* 236:    */             else
/* 237:    */             {
/* 238:249 */               if ((!stackPage) && (!this.activeScreens.isEmpty())) {
/* 239:252 */                 popPageFromStack((PageControl)screen);
/* 240:253 */               } else if (curPage != null) {
/* 241:254 */                 curPage.setToBeRemoved(false);
/* 242:    */               }
/* 243:256 */               this.activeScreens.push(screen);
/* 244:    */             }
/* 245:    */           }
/* 246:    */           else
/* 247:    */           {
/* 248:259 */             this.activeScreens.push(screen);
/* 249:    */           }
/* 250:    */         }
/* 251:263 */         if (screen.getComponents() == null) {
/* 252:264 */           screen.setComponents(screen.composeComponents());
/* 253:    */         } else {
/* 254:268 */           screen.refresh(null);
/* 255:    */         }
/* 256:271 */         return addToFrame(screen);
/* 257:    */       }
/* 258:    */     }
/* 259:274 */     return null;
/* 260:    */   }
/* 261:    */   
/* 262:    */   protected UIComponent addToFrame(AbstractMobileControl screen)
/* 263:    */   {
/* 264:284 */     UIComponent[] components = screen.getComponents();
/* 265:285 */     if (components != null)
/* 266:    */     {
/* 267:286 */       UIComponent screenPanel = components[0];
/* 268:287 */       setPageInWindow(screenPanel);
/* 269:288 */       String title = null;
/* 270:    */       try
/* 271:    */       {
/* 272:290 */         if (screen.getBooleanValue("titleinappbar")) {
/* 273:291 */           title = screen.getTitle();
/* 274:    */         }
/* 275:    */       }
/* 276:    */       catch (MobileApplicationException e) {}
/* 277:294 */       setTitle(title);
/* 278:295 */       if ((screen instanceof PageControl))
/* 279:    */       {
/* 280:296 */         showPageMenuBar((PageControl)screen);
/* 281:297 */         AbstractMobileControl curInput = ((PageControl)screen).getCurrentInput();
/* 282:298 */         adjustPageFocus(curInput, (PageControl)screen);
/* 283:    */       }
/* 284:    */       else
/* 285:    */       {
/* 286:300 */         setFocusOnNothing();
/* 287:    */       }
/* 288:303 */       return screenPanel;
/* 289:    */     }
/* 290:305 */     return null;
/* 291:    */   }
/* 292:    */   
/* 293:    */   protected void adjustPageFocus(AbstractMobileControl currentInput, PageControl screen)
/* 294:    */   {
/* 295:309 */     if (currentInput != null) {
/* 296:310 */       setPageFocus(screen);
/* 297:    */     } else {
/* 298:312 */       setFocusOnNothing();
/* 299:    */     }
/* 300:    */   }
/* 301:    */   
/* 302:    */   public UIComponent showScreen(String screenName, AbstractMobileControl launchingControl, boolean stackPage)
/* 303:    */     throws MobileApplicationException
/* 304:    */   {
/* 305:316 */     return showScreen(screenName, launchingControl, stackPage, true);
/* 306:    */   }
/* 307:    */   
/* 308:    */   public UIComponent showScreen(String screenName, AbstractMobileControl launchingControl, boolean stackPage, boolean savePage)
/* 309:    */     throws MobileApplicationException
/* 310:    */   {
/* 311:334 */     if (screenName != null)
/* 312:    */     {
/* 313:335 */       AbstractMobileControl screen = getScreen(screenName);
/* 314:336 */       if (screen != null) {
/* 315:338 */         if (screen.getParentControl() != null) {
/* 316:339 */           ((PageGroupControl)screen.getParentControl()).setCurrentPage(screen);
/* 317:    */         }
/* 318:    */       }
/* 319:342 */       return showScreen(screen, launchingControl, stackPage, savePage);
/* 320:    */     }
/* 321:344 */     return null;
/* 322:    */   }
/* 323:    */   
/* 324:    */   public AbstractMobileControl getScreen(String screenName)
/* 325:    */     throws MobileApplicationException
/* 326:    */   {
/* 327:361 */     AbstractMobileControl retValue = null;
/* 328:362 */     if (screenName != null)
/* 329:    */     {
/* 330:363 */       AbstractMobileControl screen = null;
/* 331:364 */       UIControlManager cMgr = UIControlManager.getInstance();
/* 332:365 */       MobileScreenRegistry registry = MobileScreenRegistry.getInstance();
/* 333:366 */       MobileUIControlData screenData = (MobileUIControlData)registry.getScreenData(screenName);
/* 334:367 */       if (screenData != null)
/* 335:    */       {
/* 336:368 */         ControlData parentData = screenData.getParentComponentData();
/* 337:369 */         if (parentData != null)
/* 338:    */         {
/* 339:370 */           PageGroupControl pageGroup = null;
/* 340:371 */           String controlType = parentData.getName();
/* 341:372 */           PageGroupControl cc = (PageGroupControl)cMgr.getControlComposer(controlType);
/* 342:373 */           if (cc != null) {
/* 343:374 */             pageGroup = (PageGroupControl)cc.buildControl(parentData);
/* 344:    */           }
/* 345:376 */           if (pageGroup != null) {
/* 346:377 */             screen = pageGroup.getPage(screenName);
/* 347:    */           }
/* 348:    */         }
/* 349:380 */         if (screen == null)
/* 350:    */         {
/* 351:381 */           String controlType = screenData.getName();
/* 352:382 */           AbstractMobileControl cc = (AbstractMobileControl)cMgr.getControlComposer(controlType);
/* 353:383 */           if (cc != null) {
/* 354:384 */             screen = cc.buildControl(screenData);
/* 355:    */           }
/* 356:    */         }
/* 357:    */       }
/* 358:388 */       retValue = screen;
/* 359:    */     }
/* 360:391 */     if ("esigDialog".equals(screenName)) {
/* 361:394 */       retValue.getControlData().resetValue("datasrcname");
/* 362:    */     }
/* 363:396 */     return retValue;
/* 364:    */   }
/* 365:    */   
/* 366:    */   public UIComponent showScreen(String screenName)
/* 367:    */     throws MobileApplicationException
/* 368:    */   {
/* 369:408 */     return showScreen(screenName, getCurrentScreen(), false);
/* 370:    */   }
/* 371:    */   
/* 372:    */   public boolean sendEventToScreen(String targetId, UIEvent event)
/* 373:    */     throws MobileApplicationException
/* 374:    */   {
/* 375:426 */     AbstractMobileControl screen = getScreen(targetId);
/* 376:427 */     if (screen != null)
/* 377:    */     {
/* 378:428 */       if (!screen.isAuthorizedToCompose())
/* 379:    */       {
/* 380:429 */         UIUtil.showFailureMessageBox(MobileMessageGenerator.generate("sendeventtopagenoauth", null));
/* 381:430 */         event.setEventErrored();
/* 382:431 */         return false;
/* 383:    */       }
/* 384:434 */       AbstractMobileControl curScreen = getCurrentScreen();
/* 385:435 */       boolean poppage = !screen.getBooleanValue("stackpage");
/* 386:436 */       if (screen == curScreen)
/* 387:    */       {
/* 388:437 */         screen.handleEvent(event);
/* 389:438 */         return true;
/* 390:    */       }
/* 391:440 */       if ((curScreen != null) && ((curScreen instanceof PageControl)) && 
/* 392:441 */         (!((PageControl)curScreen).sendSaveEvent())) {
/* 393:442 */         return true;
/* 394:    */       }
/* 395:446 */       if ((screen instanceof PageControl))
/* 396:    */       {
/* 397:447 */         ((PageControl)screen).setLaunchingControl((AbstractMobileControl)event.getCreatingObject());
/* 398:448 */         if (!((PageControl)screen).sendInitEvent()) {
/* 399:449 */           return true;
/* 400:    */         }
/* 401:    */       }
/* 402:452 */       if ((curScreen != null) && (poppage)) {
/* 403:453 */         this.activeScreens.pop();
/* 404:    */       }
/* 405:455 */       if (screen.getParentControl() != null) {
/* 406:456 */         ((PageGroupControl)screen.getParentControl()).setCurrentPage(screen);
/* 407:    */       }
/* 408:458 */       this.activeScreens.push(screen);
/* 409:459 */       if (screen.getComponents() == null) {
/* 410:460 */         screen.setComponents(screen.composeComponents());
/* 411:    */       }
/* 412:463 */       screen.handleEvent(event);
/* 413:464 */       if (event.errorOccured())
/* 414:    */       {
/* 415:468 */         this.activeScreens.pop();
/* 416:469 */         if (curScreen != null)
/* 417:    */         {
/* 418:470 */           if (poppage) {
/* 419:471 */             this.activeScreens.push(curScreen);
/* 420:    */           }
/* 421:472 */           curScreen.refresh(null);
/* 422:    */         }
/* 423:    */       }
/* 424:    */       else
/* 425:    */       {
/* 426:475 */         if ((curScreen != null) && (poppage))
/* 427:    */         {
/* 428:476 */           closePageBeans((PageControl)curScreen, (PageControl)screen);
/* 429:477 */           if ((curScreen.getParentControl() instanceof PageGroupControl)) {
/* 430:478 */             ((PageGroupControl)curScreen.getParentControl()).closePage(curScreen);
/* 431:    */           } else {
/* 432:480 */             curScreen.cleanup();
/* 433:    */           }
/* 434:    */         }
/* 435:482 */         if (screen == getCurrentScreen()) {
/* 436:484 */           addToFrame(screen);
/* 437:    */         }
/* 438:    */       }
/* 439:    */     }
/* 440:488 */     return screen != null;
/* 441:    */   }
/* 442:    */   
/* 443:    */   public abstract ProgressObserver showProgressScreen(AbstractMobileControl paramAbstractMobileControl, UIEvent paramUIEvent)
/* 444:    */     throws MobileApplicationException;
/* 445:    */   
/* 446:    */   public void showLoginScreen()
/* 447:    */     throws MobileApplicationException
/* 448:    */   {
/* 449:494 */     showScreen("login");
/* 450:    */   }
/* 451:    */   
/* 452:    */   public void removeLoginScreen()
/* 453:    */     throws MobileApplicationException
/* 454:    */   {
/* 455:498 */     AbstractMobileControl screen = (AbstractMobileControl)this.activeScreens.peek();
/* 456:499 */     if (screen.getId().equalsIgnoreCase("login"))
/* 457:    */     {
/* 458:500 */       screen.cleanup();
/* 459:501 */       this.activeScreens.pop();
/* 460:    */     }
/* 461:    */   }
/* 462:    */   
/* 463:    */   public Enumeration getActiveScreens()
/* 464:    */   {
/* 465:506 */     return this.activeScreens.elements();
/* 466:    */   }
/* 467:    */   
/* 468:    */   public int getActiveScreensCount()
/* 469:    */   {
/* 470:510 */     return this.activeScreens.size();
/* 471:    */   }
/* 472:    */   
/* 473:    */   public AbstractMobileControl getCurrentScreen()
/* 474:    */   {
/* 475:514 */     if (this.activeScreens.empty()) {
/* 476:515 */       return null;
/* 477:    */     }
/* 478:518 */     AbstractMobileControl currentScreen = (AbstractMobileControl)this.activeScreens.peek();
/* 479:519 */     return currentScreen;
/* 480:    */   }
/* 481:    */   
/* 482:    */   protected void popPageFromStack(PageControl pageToBeAdded)
/* 483:    */     throws MobileApplicationException
/* 484:    */   {
/* 485:523 */     PageControl curPage = (PageControl)this.activeScreens.pop();
/* 486:524 */     closePageBeans(curPage, pageToBeAdded);
/* 487:525 */     if ((curPage.getParentControl() instanceof PageGroupControl)) {
/* 488:526 */       ((PageGroupControl)curPage.getParentControl()).closePage(curPage);
/* 489:    */     } else {
/* 490:528 */       curPage.cleanup();
/* 491:    */     }
/* 492:    */   }
/* 493:    */   
/* 494:    */   protected void closePageBeans(PageControl page, PageControl pageToBeAdded)
/* 495:    */     throws MobileApplicationException
/* 496:    */   {
/* 497:532 */     ArrayList beanList = page.getPageBeans();
/* 498:533 */     boolean beanused = false;
/* 499:534 */     Iterator i = beanList.iterator();
/* 500:535 */     while (i.hasNext())
/* 501:    */     {
/* 502:536 */       String chckBean = (String)i.next();
/* 503:537 */       if (!this.activeScreens.isEmpty())
/* 504:    */       {
/* 505:538 */         Enumeration screens = this.activeScreens.elements();
/* 506:539 */         while (screens.hasMoreElements())
/* 507:    */         {
/* 508:540 */           PageControl chckPage = (PageControl)screens.nextElement();
/* 509:541 */           if (chckPage.usesBean(chckBean))
/* 510:    */           {
/* 511:542 */             beanused = true;
/* 512:543 */             break;
/* 513:    */           }
/* 514:    */         }
/* 515:    */       }
/* 516:547 */       if ((!beanused) && (
/* 517:548 */         (pageToBeAdded == null) || (!pageToBeAdded.usesBean(chckBean))))
/* 518:    */       {
/* 519:549 */         MobileMboDataBean bean = DataBeanCache.findDataBean(chckBean);
/* 520:550 */         if (bean != null) {
/* 521:551 */           bean.reset();
/* 522:    */         }
/* 523:552 */         DataBeanCache.removeDataBean(chckBean);
/* 524:    */       }
/* 525:555 */       beanused = false;
/* 526:    */     }
/* 527:    */   }
/* 528:    */   
/* 529:    */   public void removeCurrentScreen(boolean autoSave)
/* 530:    */     throws MobileApplicationException
/* 531:    */   {
/* 532:567 */     PageControl currScreen = (PageControl)this.activeScreens.peek();
/* 533:568 */     if ((!autoSave) || (currScreen.sendSaveEvent()))
/* 534:    */     {
/* 535:569 */       popPageFromStack(null);
/* 536:570 */       if (this.activeScreens.isEmpty())
/* 537:    */       {
/* 538:571 */         exitApplication();
/* 539:    */       }
/* 540:    */       else
/* 541:    */       {
/* 542:573 */         AbstractMobileControl screen = (AbstractMobileControl)this.activeScreens.peek();
/* 543:574 */         if (getStartupScreenId().equals(screen.getId())) {
/* 544:575 */           DataBeanCache.removeAllDataBeans();
/* 545:    */         }
/* 546:576 */         if (screen.getComponents() == null) {
/* 547:577 */           screen.setComponents(screen.composeComponents());
/* 548:    */         } else {
/* 549:579 */           screen.refresh(null);
/* 550:    */         }
/* 551:580 */         addToFrame(screen);
/* 552:    */       }
/* 553:    */     }
/* 554:585 */     UIUtil.enableMenu(true);
/* 555:    */   }
/* 556:    */   
/* 557:    */   protected abstract void exitApplication();
/* 558:    */   
/* 559:    */   public void removeCurrentScreen()
/* 560:    */     throws MobileApplicationException
/* 561:    */   {
/* 562:597 */     removeCurrentScreen(false);
/* 563:    */   }
/* 564:    */   
/* 565:    */   public void setTitle(String title)
/* 566:    */   {
/* 567:601 */     String pName = null;
/* 568:602 */     if ((title == null) || (MobileUIProperties.getBooleanValue("showproductname"))) {
/* 569:603 */       pName = MobileMessageGenerator.generate("productname", null);
/* 570:    */     }
/* 571:605 */     String _title = (pName == null ? "" : new StringBuilder().append(pName).append(" ").toString()) + (title == null ? "" : title);
/* 572:606 */     setWindowTitle(_title);
/* 573:    */   }
/* 574:    */   
/* 575:    */   public void setUserEvent(UIEvent event)
/* 576:    */   {
/* 577:610 */     this.userEvent = event;
/* 578:    */   }
/* 579:    */   
/* 580:    */   public UIEvent getUserEvent()
/* 581:    */   {
/* 582:614 */     return this.userEvent;
/* 583:    */   }
/* 584:    */   
/* 585:    */   public void removeUserEvent(UIEvent event)
/* 586:    */   {
/* 587:618 */     if (this.userEvent == event)
/* 588:    */     {
/* 589:619 */       hidewait();
/* 590:620 */       this.userEvent = null;
/* 591:    */     }
/* 592:    */   }
/* 593:    */   
/* 594:    */   public void clearPageStack()
/* 595:    */   {
/* 596:    */     
/* 597:630 */     while (this.activeScreens.size() > 0)
/* 598:    */     {
/* 599:631 */       PageControl page = (PageControl)this.activeScreens.pop();
/* 600:632 */       page.cleanup();
/* 601:    */     }
/* 602:    */   }
/* 603:    */   
/* 604:    */   public boolean allowEvents()
/* 605:    */   {
/* 606:643 */     return !this.stopevents;
/* 607:    */   }
/* 608:    */   
/* 609:    */   public void setStopEvents(boolean stopevents)
/* 610:    */   {
/* 611:654 */     this.stopevents = stopevents;
/* 612:    */   }
/* 613:    */   
/* 614:    */   public abstract boolean isValidThreadToRefresh(Thread paramThread);
/* 615:    */   
/* 616:    */   public abstract int getWindowMaxSizeForTable();
/* 617:    */   
/* 618:    */   public abstract boolean supportFontImageSizeConfiguration();
/* 619:    */   
/* 620:    */   public abstract void refreshScreen(AbstractMobileControl paramAbstractMobileControl, UIEvent paramUIEvent, boolean paramBoolean)
/* 621:    */     throws MobileApplicationException;
/* 622:    */   
/* 623:    */   public abstract boolean supportsCamera()
/* 624:    */     throws MobileApplicationException;
/* 625:    */   
/* 626:    */   public abstract boolean supportsTableColumnResizer();
/* 627:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.MobileUIManager
 * JD-Core Version:    0.7.0.1
 */