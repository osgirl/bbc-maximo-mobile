/*   1:    */ package com.mro.mobile.ui.res;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.MobileMessageGenerator;
/*   5:    */ import com.mro.mobile.app.AppEventHandler;
/*   6:    */ import com.mro.mobile.app.BasicMobileDeviceUIApplication;
/*   7:    */ import com.mro.mobile.app.DefaultEventHandler;
/*   8:    */ import com.mro.mobile.app.MobileDeviceAppSession;
/*   9:    */ import com.mro.mobile.ui.DelegateWorker;
/*  10:    */ import com.mro.mobile.ui.LookupManager;
/*  11:    */ import com.mro.mobile.ui.MobileMboDataBean;
/*  12:    */ import com.mro.mobile.ui.MobileMboDataBeanManager;
/*  13:    */ import com.mro.mobile.ui.UIHandlerManager;
/*  14:    */ import com.mro.mobile.ui.event.UIEvent;
/*  15:    */ import com.mro.mobile.ui.event.UIEventHandler;
/*  16:    */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*  17:    */ import com.mro.mobile.ui.res.controls.MessageBox;
/*  18:    */ import com.mro.mobile.ui.res.controls.PageControl;
/*  19:    */ import com.mro.mobile.ui.res.controls.TabGroupControl;
/*  20:    */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  21:    */ import com.mro.mobile.util.MobileLogger;
/*  22:    */ import com.mro.mobile.util.MobileLoggerFactory;
/*  23:    */ import java.util.Enumeration;
/*  24:    */ import java.util.Iterator;
/*  25:    */ import java.util.StringTokenizer;
/*  26:    */ 
/*  27:    */ public class UIUtil
/*  28:    */ {
/*  29: 41 */   private static LookupManager lookupMngr = null;
/*  30:    */   
/*  31:    */   public static void showPage(String pageName)
/*  32:    */     throws MobileApplicationException
/*  33:    */   {
/*  34: 52 */     enableMenu(false);
/*  35: 53 */     BasicMobileDeviceUIApplication app = getApplication();
/*  36: 54 */     app.showScreen(pageName);
/*  37: 55 */     enableMenu(true);
/*  38:    */   }
/*  39:    */   
/*  40:    */   public static void popupPage(String pageName, UIEvent event)
/*  41:    */     throws MobileApplicationException
/*  42:    */   {
/*  43: 67 */     getApplication().popupPage(pageName, event);
/*  44:    */   }
/*  45:    */   
/*  46:    */   public static boolean checkESignature(UIEvent event, MobileMboDataBean mdb, String optionName, boolean checkSave)
/*  47:    */     throws MobileApplicationException
/*  48:    */   {
/*  49: 71 */     if ((event != null) && (!event.hasPassedESig()) && (mdb != null))
/*  50:    */     {
/*  51: 72 */       if (optionName == null)
/*  52:    */       {
/*  53: 73 */         if ((event.getCreatingObject() instanceof AbstractMobileControl)) {
/*  54: 74 */           optionName = ((AbstractMobileControl)event.getCreatingObject()).getStringValue("sigoption");
/*  55:    */         }
/*  56: 76 */         if (optionName == null) {
/*  57: 77 */           optionName = getCurrentScreen().getStringValue("sigoption");
/*  58:    */         }
/*  59:    */       }
/*  60: 80 */       boolean showDialog = (checkSave) && (mdb.isESigNeeded("SAVE"));
/*  61: 82 */       if ((!showDialog) && (optionName != null))
/*  62:    */       {
/*  63: 83 */         StringTokenizer options = new StringTokenizer(optionName, ",");
/*  64: 84 */         while ((!showDialog) && (options.hasMoreTokens())) {
/*  65: 85 */           showDialog = mdb.isESigNeeded(options.nextToken());
/*  66:    */         }
/*  67:    */       }
/*  68: 88 */       if (showDialog)
/*  69:    */       {
/*  70: 89 */         BasicMobileDeviceUIApplication app = getApplication();
/*  71: 90 */         UIEvent esigEvent = new UIEvent(app.getCurrentScreen(), optionName, null, event);
/*  72: 91 */         MobileDeviceAppSession session = MobileDeviceAppSession.getSession();
/*  73: 92 */         session.setAttribute("esig_event", esigEvent);
/*  74: 93 */         gotoPageNoSave("esigDialog", (AbstractMobileControl)event.getCreatingObject());
/*  75: 94 */         return false;
/*  76:    */       }
/*  77:    */     }
/*  78: 97 */     return true;
/*  79:    */   }
/*  80:    */   
/*  81:    */   public static boolean checkESignatureWithSave(UIEvent event, MobileMboDataBean mdb)
/*  82:    */     throws MobileApplicationException
/*  83:    */   {
/*  84:101 */     return checkESignature(event, mdb, null, true);
/*  85:    */   }
/*  86:    */   
/*  87:    */   public static boolean checkESignatureWithSave(UIEvent event, MobileMboDataBean mdb, String optionName)
/*  88:    */     throws MobileApplicationException
/*  89:    */   {
/*  90:105 */     return checkESignature(event, mdb, optionName, true);
/*  91:    */   }
/*  92:    */   
/*  93:    */   public static boolean checkESignature(UIEvent event, MobileMboDataBean mdb)
/*  94:    */     throws MobileApplicationException
/*  95:    */   {
/*  96:109 */     return checkESignature(event, mdb, null, false);
/*  97:    */   }
/*  98:    */   
/*  99:    */   public static boolean checkESignature(UIEvent event, MobileMboDataBean mdb, String optionName)
/* 100:    */     throws MobileApplicationException
/* 101:    */   {
/* 102:113 */     return checkESignature(event, mdb, optionName, false);
/* 103:    */   }
/* 104:    */   
/* 105:    */   public static boolean checkESignatureForSave(UIEvent event, MobileMboDataBean mdb)
/* 106:    */     throws MobileApplicationException
/* 107:    */   {
/* 108:117 */     return checkESignature(event, mdb, "SAVE", false);
/* 109:    */   }
/* 110:    */   
/* 111:    */   public static void showPageNoSave(String pageId, AbstractMobileControl launchingControl)
/* 112:    */     throws MobileApplicationException
/* 113:    */   {
/* 114:128 */     enableMenu(false);
/* 115:129 */     BasicMobileDeviceUIApplication app = getApplication();
/* 116:130 */     app.showScreen(pageId, launchingControl, false, false);
/* 117:131 */     enableMenu(true);
/* 118:    */   }
/* 119:    */   
/* 120:    */   public static void gotoPageNoSave(String pageId, AbstractMobileControl launchingControl)
/* 121:    */     throws MobileApplicationException
/* 122:    */   {
/* 123:142 */     enableMenu(false);
/* 124:143 */     BasicMobileDeviceUIApplication app = getApplication();
/* 125:144 */     app.showScreen(pageId, launchingControl, true, false);
/* 126:145 */     enableMenu(true);
/* 127:    */   }
/* 128:    */   
/* 129:    */   public static void gotoPage(String pageId, AbstractMobileControl launchingControl)
/* 130:    */     throws MobileApplicationException
/* 131:    */   {
/* 132:156 */     enableMenu(false);
/* 133:157 */     BasicMobileDeviceUIApplication app = getApplication();
/* 134:158 */     app.showScreen(pageId, launchingControl, true);
/* 135:159 */     enableMenu(true);
/* 136:    */   }
/* 137:    */   
/* 138:    */   public static void closePage()
/* 139:    */     throws MobileApplicationException
/* 140:    */   {
/* 141:169 */     enableMenu(false);
/* 142:170 */     BasicMobileDeviceUIApplication app = getApplication();
/* 143:171 */     app.removeCurrentScreen();
/* 144:172 */     enableMenu(true);
/* 145:    */   }
/* 146:    */   
/* 147:    */   public static void saveClosePage()
/* 148:    */     throws MobileApplicationException
/* 149:    */   {
/* 150:183 */     enableMenu(false);
/* 151:184 */     BasicMobileDeviceUIApplication app = getApplication();
/* 152:185 */     app.removeCurrentScreen(true);
/* 153:186 */     enableMenu(true);
/* 154:    */   }
/* 155:    */   
/* 156:    */   public static void cancelPage()
/* 157:    */     throws MobileApplicationException
/* 158:    */   {
/* 159:197 */     enableMenu(false);
/* 160:198 */     BasicMobileDeviceUIApplication app = getApplication();
/* 161:199 */     AbstractMobileControl page = app.getCurrentScreen();
/* 162:200 */     MobileMboDataBean bean = page.getDataBean();
/* 163:201 */     if (bean != null) {
/* 164:202 */       bean.getDataBeanManager().cancel();
/* 165:    */     }
/* 166:204 */     app.removeCurrentScreen();
/* 167:205 */     enableMenu(true);
/* 168:    */   }
/* 169:    */   
/* 170:    */   public static void cancelPageWithoutRemove()
/* 171:    */     throws MobileApplicationException
/* 172:    */   {
/* 173:209 */     enableMenu(false);
/* 174:210 */     BasicMobileDeviceUIApplication app = getApplication();
/* 175:211 */     AbstractMobileControl page = app.getCurrentScreen();
/* 176:212 */     MobileMboDataBean bean = page.getDataBean();
/* 177:213 */     if (bean != null) {
/* 178:214 */       bean.getDataBeanManager().cancel();
/* 179:    */     }
/* 180:216 */     enableMenu(true);
/* 181:    */   }
/* 182:    */   
/* 183:    */   public static void cancelShowPage(String pageId)
/* 184:    */     throws MobileApplicationException
/* 185:    */   {
/* 186:229 */     enableMenu(false);
/* 187:230 */     BasicMobileDeviceUIApplication app = getApplication();
/* 188:231 */     AbstractMobileControl page = app.getCurrentScreen();
/* 189:232 */     MobileMboDataBean bean = page.getDataBean();
/* 190:233 */     if (bean != null) {
/* 191:234 */       bean.getDataBeanManager().cancel();
/* 192:    */     }
/* 193:236 */     app.showScreen(pageId, page, false, false);
/* 194:237 */     enableMenu(true);
/* 195:    */   }
/* 196:    */   
/* 197:    */   public static AbstractMobileControl getCurrentScreen()
/* 198:    */   {
/* 199:246 */     return getApplication().getCurrentScreen();
/* 200:    */   }
/* 201:    */   
/* 202:    */   public static TabGroupControl getTabGroup(AbstractMobileControl currentControl)
/* 203:    */   {
/* 204:257 */     TabGroupControl retControl = null;
/* 205:258 */     Iterator iter = currentControl.getChildren();
/* 206:259 */     while ((iter != null) && (iter.hasNext()))
/* 207:    */     {
/* 208:260 */       AbstractMobileControl tempControl = (AbstractMobileControl)iter.next();
/* 209:261 */       if ((tempControl != null) && ((tempControl instanceof TabGroupControl)))
/* 210:    */       {
/* 211:262 */         retControl = (TabGroupControl)tempControl;
/* 212:    */       }
/* 213:    */       else
/* 214:    */       {
/* 215:265 */         retControl = getTabGroup(tempControl);
/* 216:266 */         if ((retControl != null) && ((retControl instanceof TabGroupControl))) {
/* 217:    */           break;
/* 218:    */         }
/* 219:    */       }
/* 220:    */     }
/* 221:271 */     return retControl;
/* 222:    */   }
/* 223:    */   
/* 224:    */   public static void refreshCurrentScreen()
/* 225:    */     throws MobileApplicationException
/* 226:    */   {
/* 227:278 */     refreshScreen(getCurrentScreen(), null, true);
/* 228:279 */     enableMenu(true);
/* 229:    */   }
/* 230:    */   
/* 231:    */   public static void refreshScreen(AbstractMobileControl screen, UIEvent event)
/* 232:    */     throws MobileApplicationException
/* 233:    */   {
/* 234:283 */     refreshScreen(screen, event, false);
/* 235:    */   }
/* 236:    */   
/* 237:    */   public static void refreshScreen(AbstractMobileControl screen, UIEvent event, boolean addPageGroupMenubar)
/* 238:    */     throws MobileApplicationException
/* 239:    */   {
/* 240:287 */     BasicMobileDeviceUIApplication app = getApplication();
/* 241:288 */     app.refreshScreen(screen, event, addPageGroupMenubar);
/* 242:    */   }
/* 243:    */   
/* 244:    */   public static UIComponent getComponent(UIComponent componentOnScreen, String id)
/* 245:    */   {
/* 246:292 */     if ((componentOnScreen instanceof UIComponent))
/* 247:    */     {
/* 248:293 */       UIComponent uiComponent = componentOnScreen;
/* 249:294 */       if ((uiComponent.getCId() != null) && (uiComponent.getCId().equalsIgnoreCase(id))) {
/* 250:295 */         return componentOnScreen;
/* 251:    */       }
/* 252:298 */       if (uiComponent.canContainChildren())
/* 253:    */       {
/* 254:299 */         Enumeration children = uiComponent.getChildren();
/* 255:300 */         while (children.hasMoreElements())
/* 256:    */         {
/* 257:301 */           Object child = children.nextElement();
/* 258:302 */           if ((child instanceof UIComponent))
/* 259:    */           {
/* 260:303 */             UIComponent c = getComponent((UIComponent)child, id);
/* 261:304 */             if (c != null) {
/* 262:307 */               return c;
/* 263:    */             }
/* 264:    */           }
/* 265:    */         }
/* 266:    */       }
/* 267:    */     }
/* 268:314 */     return null;
/* 269:    */   }
/* 270:    */   
/* 271:    */   public static AbstractMobileControl findControl(String controlId)
/* 272:    */   {
/* 273:324 */     BasicMobileDeviceUIApplication app = getApplication();
/* 274:325 */     AbstractMobileControl control = null;
/* 275:326 */     Enumeration pages = app.getActiveScreens();
/* 276:327 */     if (pages != null) {
/* 277:328 */       while ((control == null) && (pages.hasMoreElements()))
/* 278:    */       {
/* 279:329 */         PageControl page = (PageControl)pages.nextElement();
/* 280:330 */         control = page.findChild(controlId);
/* 281:    */       }
/* 282:    */     }
/* 283:334 */     return control;
/* 284:    */   }
/* 285:    */   
/* 286:    */   public static AppEventHandler getAppEventHandler()
/* 287:    */   {
/* 288:338 */     return MobileDeviceAppSession.getSession().getUIEventHandlerAsAppEventHandler();
/* 289:    */   }
/* 290:    */   
/* 291:    */   public static AppEventHandler getUIEventHandler()
/* 292:    */   {
/* 293:342 */     return getAppEventHandler();
/* 294:    */   }
/* 295:    */   
/* 296:    */   public static boolean handleEvent(String eventId)
/* 297:    */   {
/* 298:346 */     enableMenu(false);
/* 299:347 */     UIEventHandler eventHandler = getUIEventHandler();
/* 300:348 */     if (eventHandler != null)
/* 301:    */     {
/* 302:349 */       UIEvent event = new UIEvent(getCurrentScreen(), eventId, null, null);
/* 303:    */       try
/* 304:    */       {
/* 305:351 */         eventHandler.performEvent(event);
/* 306:352 */         enableMenu(true);
/* 307:353 */         return !event.errorOccured();
/* 308:    */       }
/* 309:    */       catch (MobileApplicationException e)
/* 310:    */       {
/* 311:355 */         showExceptionMessage(e, event, 0);
/* 312:356 */         return false;
/* 313:    */       }
/* 314:    */     }
/* 315:359 */     enableMenu(true);
/* 316:360 */     return true;
/* 317:    */   }
/* 318:    */   
/* 319:    */   public static UIEventHandler getControlHandler(AbstractMobileControl control)
/* 320:    */   {
/* 321:364 */     if (control != null)
/* 322:    */     {
/* 323:365 */       String handlerName = control.getValue("handler");
/* 324:366 */       if (handlerName != null)
/* 325:    */       {
/* 326:367 */         UIHandlerManager hMan = UIHandlerManager.getInstance();
/* 327:368 */         return hMan.getUIHandler(handlerName);
/* 328:    */       }
/* 329:    */     }
/* 330:371 */     return null;
/* 331:    */   }
/* 332:    */   
/* 333:    */   public static boolean sendEvent(UIEvent event)
/* 334:    */     throws MobileApplicationException
/* 335:    */   {
/* 336:375 */     enableMenu(false);
/* 337:376 */     String targetId = event.getTargetID();
/* 338:377 */     boolean ret = true;
/* 339:378 */     if (targetId != null) {
/* 340:379 */       if (targetId.equals("currentinput"))
/* 341:    */       {
/* 342:380 */         AbstractMobileControl input = ((PageControl)getCurrentScreen()).getCurrentInput();
/* 343:381 */         if (input != null)
/* 344:    */         {
/* 345:382 */           event.clearTarget();
/* 346:383 */           ret = input.handleEvent(event);
/* 347:    */         }
/* 348:    */       }
/* 349:385 */       else if ((!getApplication().sendEventToScreen(targetId, event)) && 
/* 350:386 */         (!event.errorOccured()))
/* 351:    */       {
/* 352:387 */         AbstractMobileControl ctrl = findControl(targetId);
/* 353:388 */         ret = ctrl.handleEvent(event);
/* 354:    */       }
/* 355:    */     }
/* 356:392 */     enableMenu(true);
/* 357:393 */     return ret;
/* 358:    */   }
/* 359:    */   
/* 360:    */   public static BasicMobileDeviceUIApplication getApplication()
/* 361:    */   {
/* 362:397 */     return MobileDeviceAppSession.getSession().getApplicationAsUIApplication();
/* 363:    */   }
/* 364:    */   
/* 365:    */   public static LookupManager getLookupManager()
/* 366:    */   {
/* 367:404 */     if (lookupMngr == null) {
/* 368:405 */       lookupMngr = new LookupManager();
/* 369:    */     }
/* 370:407 */     return lookupMngr;
/* 371:    */   }
/* 372:    */   
/* 373:    */   public static void startWorkerThread(DefaultEventHandler defEventHandler, UIEvent event)
/* 374:    */     throws MobileApplicationException
/* 375:    */   {
/* 376:418 */     DelegateWorker activeWorker = new DelegateWorker(defEventHandler, event, getApplication().getAsynchronousExecutor());
/* 377:419 */     activeWorker.startWork();
/* 378:    */   }
/* 379:    */   
/* 380:    */   public static void showExceptionMessage(MobileApplicationException mex, UIEvent event, int messageBoxType)
/* 381:    */   {
/* 382:430 */     switch (messageBoxType)
/* 383:    */     {
/* 384:    */     case 0: 
/* 385:432 */       showFailureMessageBox(mex.getCompleteMessage());
/* 386:433 */       break;
/* 387:    */     case 2: 
/* 388:435 */       showOKCANCELMessageBox(event, mex.getCompleteMessage());
/* 389:436 */       break;
/* 390:    */     case 3: 
/* 391:438 */       showYESNOCANCELMessageBox(event, mex.getCompleteMessage());
/* 392:439 */       break;
/* 393:    */     case 1: 
/* 394:    */     default: 
/* 395:441 */       showInfoMessageBox(mex.getCompleteMessage());
/* 396:    */     }
/* 397:445 */     MobileLoggerFactory.getDefaultLogger().warn(mex.getCompleteMessage(), mex);
/* 398:    */   }
/* 399:    */   
/* 400:    */   public static void showInfoMessageBox(String message)
/* 401:    */   {
/* 402:449 */     showMessageBox(message);
/* 403:    */   }
/* 404:    */   
/* 405:    */   public static void showFailureMessageBox(String message)
/* 406:    */   {
/* 407:453 */     showMessageBox(message, "warning", null);
/* 408:    */   }
/* 409:    */   
/* 410:    */   public static void showOKCANCELMessageBox(UIEvent event, String message)
/* 411:    */   {
/* 412:457 */     showMessageBox(message, "question", 3, event);
/* 413:    */   }
/* 414:    */   
/* 415:    */   public static void showYESNOCANCELMessageBox(UIEvent event, String message)
/* 416:    */   {
/* 417:461 */     showMessageBox(message, "question", 14, event);
/* 418:    */   }
/* 419:    */   
/* 420:    */   public static void showMessageBox(String message)
/* 421:    */   {
/* 422:465 */     new MessageBox(message, null).show();
/* 423:    */   }
/* 424:    */   
/* 425:    */   public static void showMessageBox(String message, String icon, UIEvent event)
/* 426:    */   {
/* 427:469 */     new MessageBox(message, icon, event).show();
/* 428:    */   }
/* 429:    */   
/* 430:    */   public static void showMessageBox(String message, String icon, int buttons, UIEvent event)
/* 431:    */   {
/* 432:473 */     new MessageBox(message, icon, buttons, event).show();
/* 433:    */   }
/* 434:    */   
/* 435:    */   public static void showMessageBox(Exception e)
/* 436:    */   {
/* 437:477 */     String message = null;
/* 438:478 */     if ((e instanceof MobileApplicationException)) {
/* 439:479 */       message = ((MobileApplicationException)e).getCompleteMessage();
/* 440:    */     } else {
/* 441:481 */       message = e.getMessage();
/* 442:    */     }
/* 443:482 */     showMessageBox(message, "warning", null);
/* 444:    */   }
/* 445:    */   
/* 446:    */   public static void showMessageBox(Exception e, int buttons, UIEvent event)
/* 447:    */   {
/* 448:486 */     String message = null;
/* 449:487 */     if ((e instanceof MobileApplicationException)) {
/* 450:488 */       message = ((MobileApplicationException)e).getCompleteMessage();
/* 451:    */     } else {
/* 452:490 */       message = e.getMessage();
/* 453:    */     }
/* 454:491 */     showMessageBox(message, "warning", buttons, event);
/* 455:    */   }
/* 456:    */   
/* 457:    */   public static void showMessageBox(String messageKey, Object[] params, UIEvent event)
/* 458:    */   {
/* 459:495 */     String message = MobileMessageGenerator.generate(messageKey, params);
/* 460:496 */     showMessageBox(message);
/* 461:    */   }
/* 462:    */   
/* 463:    */   public static void showMessageBox(String messageKey, Object[] params, String icon, UIEvent event)
/* 464:    */   {
/* 465:500 */     String message = MobileMessageGenerator.generate(messageKey, params);
/* 466:501 */     showMessageBox(message, icon, event);
/* 467:    */   }
/* 468:    */   
/* 469:    */   public static void showMessageBox(String messageKey, Object[] params, String icon, int buttons, UIEvent event)
/* 470:    */   {
/* 471:505 */     String message = MobileMessageGenerator.generate(messageKey, params);
/* 472:506 */     showMessageBox(message, icon, buttons, event);
/* 473:    */   }
/* 474:    */   
/* 475:    */   public static void showMessageBoxControl(String controlId, Exception e, UIEvent event)
/* 476:    */   {
/* 477:516 */     String msg = null;
/* 478:517 */     if ((e instanceof MobileApplicationException)) {
/* 479:518 */       msg = ((MobileApplicationException)e).getCompleteMessage();
/* 480:    */     } else {
/* 481:520 */       msg = e.getMessage();
/* 482:    */     }
/* 483:522 */     showMessageBoxControl(controlId, msg, event);
/* 484:    */   }
/* 485:    */   
/* 486:    */   public static void showMessageBoxControl(String controlId, String message, UIEvent event)
/* 487:    */   {
/* 488:526 */     MessageBox msgBox = new MessageBox(message, event);
/* 489:527 */     msgBox.setControlData(controlId);
/* 490:528 */     msgBox.show();
/* 491:    */   }
/* 492:    */   
/* 493:    */   public static void showMessageBoxControl(String controlId, String messageKey, Object[] params, UIEvent event)
/* 494:    */   {
/* 495:532 */     String message = MobileMessageGenerator.generate(messageKey, params);
/* 496:533 */     showMessageBoxControl(controlId, message, event);
/* 497:    */   }
/* 498:    */   
/* 499:    */   public static boolean isNull(String val)
/* 500:    */   {
/* 501:537 */     return (val == null) || (val.trim().equals(""));
/* 502:    */   }
/* 503:    */   
/* 504:    */   public static void setPageFocus()
/* 505:    */   {
/* 506:541 */     setPageFocus((PageControl)getCurrentScreen());
/* 507:    */   }
/* 508:    */   
/* 509:    */   public static void setPageFocus(PageControl page)
/* 510:    */   {
/* 511:545 */     BasicMobileDeviceUIApplication app = getApplication();
/* 512:546 */     app.pageFocus(page);
/* 513:    */   }
/* 514:    */   
/* 515:    */   public static void enableMenu(boolean enable)
/* 516:    */   {
/* 517:554 */     BasicMobileDeviceUIApplication app = getApplication();
/* 518:555 */     if (app != null)
/* 519:    */     {
/* 520:556 */       app.setStopEvents(!enable);
/* 521:557 */       app.enableMenu(enable);
/* 522:    */     }
/* 523:    */   }
/* 524:    */   
/* 525:    */   public static int getActiveScreensCount()
/* 526:    */   {
/* 527:562 */     BasicMobileDeviceUIApplication app = getApplication();
/* 528:563 */     if (app != null) {
/* 529:564 */       return app.getActiveScreensCount();
/* 530:    */     }
/* 531:566 */     return 0;
/* 532:    */   }
/* 533:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.res.UIUtil
 * JD-Core Version:    0.7.0.1
 */