/*  1:   */ package com.mro.mobile.ui;
/*  2:   */ 
/*  3:   */ import com.mro.mobile.mbo.MobileMbo;
/*  4:   */ import com.mro.mobile.persist.RDO;
/*  5:   */ import com.mro.mobile.persist.RDOEnumeration;
/*  6:   */ 
/*  7:   */ public class MobileMboEnumeration
/*  8:   */   implements RDOEnumeration
/*  9:   */ {
/* 10:22 */   RDOEnumeration rdoEnum = null;
/* 11:   */   
/* 12:   */   public MobileMboEnumeration(RDOEnumeration rdoEnum)
/* 13:   */   {
/* 14:26 */     this.rdoEnum = rdoEnum;
/* 15:   */   }
/* 16:   */   
/* 17:   */   public boolean hasMoreElements()
/* 18:   */   {
/* 19:31 */     if (this.rdoEnum == null) {
/* 20:33 */       return false;
/* 21:   */     }
/* 22:36 */     return this.rdoEnum.hasMoreElements();
/* 23:   */   }
/* 24:   */   
/* 25:   */   public Object nextElement()
/* 26:   */   {
/* 27:41 */     if (this.rdoEnum == null) {
/* 28:43 */       return null;
/* 29:   */     }
/* 30:46 */     RDO rdo = (RDO)this.rdoEnum.nextElement();
/* 31:47 */     return new MobileMbo(rdo);
/* 32:   */   }
/* 33:   */   
/* 34:   */   public void release()
/* 35:   */   {
/* 36:52 */     this.rdoEnum.release();
/* 37:   */   }
/* 38:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.MobileMboEnumeration
 * JD-Core Version:    0.7.0.1
 */