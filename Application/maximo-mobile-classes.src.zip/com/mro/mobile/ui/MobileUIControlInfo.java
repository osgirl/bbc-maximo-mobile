/*   1:    */ package com.mro.mobile.ui;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.persist.DefaultRDO;
/*   5:    */ import com.mro.mobile.persist.DefaultRDOAttributeInfo;
/*   6:    */ import com.mro.mobile.persist.DefaultRDOInfo;
/*   7:    */ import com.mro.mobile.persist.RDO;
/*   8:    */ import com.mro.mobile.persist.RDOInfo;
/*   9:    */ import com.mro.mobile.persist.RDOSerializer;
/*  10:    */ import com.mro.mobile.type.Serializer;
/*  11:    */ import com.mro.mobile.type.TypeRegistry;
/*  12:    */ import com.mro.mobile.util.MobileLogger;
/*  13:    */ import com.mro.mobile.util.MobileLoggerFactory;
/*  14:    */ import java.io.ByteArrayInputStream;
/*  15:    */ import java.io.ByteArrayOutputStream;
/*  16:    */ import java.io.DataInput;
/*  17:    */ import java.io.DataInputStream;
/*  18:    */ import java.io.DataOutput;
/*  19:    */ import java.io.DataOutputStream;
/*  20:    */ import java.io.IOException;
/*  21:    */ 
/*  22:    */ public class MobileUIControlInfo
/*  23:    */   implements Serializer
/*  24:    */ {
/*  25:    */   public static final String UICOMPONENTINFO = "UIComponentInfo";
/*  26:    */   public static final String UICOMPONENT = "UICOMPONENT";
/*  27:    */   public static final String COMPONENTNAME = "NAME";
/*  28:    */   public static final String COMPONENTTYPE = "TYPE";
/*  29:    */   public static final String COMPONENTDATA = "DATA";
/*  30: 45 */   private String appName = null;
/*  31: 46 */   private String componentName = null;
/*  32: 47 */   private int componentType = 0;
/*  33: 48 */   private MobileUIControlData componentData = null;
/*  34:    */   
/*  35:    */   public MobileUIControlInfo() {}
/*  36:    */   
/*  37:    */   public void setAppName(String name)
/*  38:    */   {
/*  39: 57 */     this.appName = name;
/*  40:    */   }
/*  41:    */   
/*  42:    */   public String getComponentName()
/*  43:    */   {
/*  44: 62 */     return this.componentName;
/*  45:    */   }
/*  46:    */   
/*  47:    */   public void setComponentName(String name)
/*  48:    */   {
/*  49: 67 */     this.componentName = name;
/*  50:    */   }
/*  51:    */   
/*  52:    */   public int getComponentType()
/*  53:    */   {
/*  54: 72 */     return this.componentType;
/*  55:    */   }
/*  56:    */   
/*  57:    */   public void setComponentType(int componentType)
/*  58:    */   {
/*  59: 77 */     this.componentType = componentType;
/*  60:    */   }
/*  61:    */   
/*  62:    */   public MobileUIControlData getComponentData()
/*  63:    */   {
/*  64: 82 */     return this.componentData;
/*  65:    */   }
/*  66:    */   
/*  67:    */   public void setComponentData(MobileUIControlData componentData)
/*  68:    */   {
/*  69: 87 */     this.componentData = componentData;
/*  70:    */   }
/*  71:    */   
/*  72:    */   public MobileUIControlInfo(RDO componentInfo)
/*  73:    */     throws MobileApplicationException
/*  74:    */   {
/*  75: 92 */     this.componentName = componentInfo.getStringValue("NAME");
/*  76: 93 */     this.appName = componentInfo.getAppName();
/*  77: 94 */     this.componentType = componentInfo.getIntValue("TYPE");
/*  78:    */     
/*  79: 96 */     loadUIComponentData(componentInfo);
/*  80:    */   }
/*  81:    */   
/*  82:    */   public RDO getRDO()
/*  83:    */     throws MobileApplicationException
/*  84:    */   {
/*  85:101 */     DefaultRDO rdo = new DefaultRDO(this.appName);
/*  86:102 */     rdo.setName("UICOMPONENT");
/*  87:103 */     rdo.setStringValue("NAME", this.componentName);
/*  88:104 */     rdo.setIntValue("TYPE", this.componentType);
/*  89:    */     
/*  90:106 */     ByteArrayOutputStream bos = new ByteArrayOutputStream();
/*  91:107 */     DataOutputStream dout = new DataOutputStream(bos);
/*  92:    */     try
/*  93:    */     {
/*  94:111 */       MobileUIControlData writer = new MobileUIControlData();
/*  95:    */       
/*  96:113 */       writer.writeInstance(dout, this.componentData);
/*  97:    */       
/*  98:115 */       dout.flush();
/*  99:116 */       rdo.setBinaryValue("DATA", bos.toByteArray());
/* 100:    */       
/* 101:    */ 
/* 102:119 */       bos.reset();
/* 103:120 */       return rdo;
/* 104:    */     }
/* 105:    */     catch (IOException e)
/* 106:    */     {
/* 107:124 */       MobileLoggerFactory.getDefaultLogger().warn("Failed to get RDO", e);
/* 108:    */     }
/* 109:127 */     return null;
/* 110:    */   }
/* 111:    */   
/* 112:    */   private void loadUIComponentData(RDO rdo)
/* 113:    */     throws MobileApplicationException
/* 114:    */   {
/* 115:133 */     byte[] data = rdo.getBinaryValue("DATA");
/* 116:134 */     ByteArrayInputStream bis = new ByteArrayInputStream(data);
/* 117:135 */     DataInputStream dis = new DataInputStream(bis);
/* 118:    */     try
/* 119:    */     {
/* 120:139 */       MobileUIControlData reader = new MobileUIControlData();
/* 121:140 */       this.componentData = ((MobileUIControlData)reader.readInstance(dis, "UIComponentData"));
/* 122:    */     }
/* 123:    */     catch (IOException e)
/* 124:    */     {
/* 125:145 */       MobileLoggerFactory.getDefaultLogger().warn("Failed to load UI compononent data", e);
/* 126:    */     }
/* 127:    */   }
/* 128:    */   
/* 129:    */   public static void initSerializer()
/* 130:    */   {
/* 131:152 */     MobileUIControlInfo i = new MobileUIControlInfo();
/* 132:153 */     TypeRegistry.getTypeRegistry().addType("UIComponentInfo", i.getClass(), i);
/* 133:    */   }
/* 134:    */   
/* 135:    */   public Object readInstance(DataInput input, String name)
/* 136:    */     throws IOException
/* 137:    */   {
/* 138:158 */     if (name.equals("UIComponentInfo"))
/* 139:    */     {
/* 140:160 */       RDOSerializer rdoSerializer = new RDOSerializer();
/* 141:161 */       RDO rdo = (RDO)rdoSerializer.readInstance(input);
/* 142:    */       try
/* 143:    */       {
/* 144:165 */         return new MobileUIControlInfo(rdo);
/* 145:    */       }
/* 146:    */       catch (MobileApplicationException e)
/* 147:    */       {
/* 148:169 */         throw new IOException(e.getMessage());
/* 149:    */       }
/* 150:    */     }
/* 151:173 */     throw new RuntimeException("The type " + name + " not supported.");
/* 152:    */   }
/* 153:    */   
/* 154:    */   public void writeInstance(DataOutput output, Object obj)
/* 155:    */     throws IOException
/* 156:    */   {
/* 157:178 */     if ((obj instanceof MobileUIControlInfo)) {
/* 158:    */       try
/* 159:    */       {
/* 160:182 */         RDOSerializer rdoSerializer = new RDOSerializer();
/* 161:183 */         MobileUIControlInfo uiComponentInfo = (MobileUIControlInfo)obj;
/* 162:184 */         rdoSerializer.writeInstance(output, uiComponentInfo.getRDO());
/* 163:    */       }
/* 164:    */       catch (MobileApplicationException e)
/* 165:    */       {
/* 166:188 */         throw new IOException(e.getMessage());
/* 167:    */       }
/* 168:    */     }
/* 169:    */   }
/* 170:    */   
/* 171:    */   public static RDOInfo getUIComponentInfo()
/* 172:    */   {
/* 173:196 */     DefaultRDOInfo componentInfo = new DefaultRDOInfo();
/* 174:197 */     componentInfo.setName("UICOMPONENT");
/* 175:    */     
/* 176:199 */     DefaultRDOAttributeInfo attr1 = new DefaultRDOAttributeInfo();
/* 177:200 */     attr1.setName("NAME");
/* 178:201 */     attr1.setKey(true);
/* 179:202 */     attr1.setDataType(1);
/* 180:    */     
/* 181:204 */     DefaultRDOAttributeInfo attr2 = new DefaultRDOAttributeInfo();
/* 182:205 */     attr2.setName("TYPE");
/* 183:206 */     attr2.setKey(true);
/* 184:207 */     attr2.setDataType(4);
/* 185:    */     
/* 186:209 */     DefaultRDOAttributeInfo attr3 = new DefaultRDOAttributeInfo();
/* 187:210 */     attr3.setName("DATA");
/* 188:211 */     attr3.setKey(false);
/* 189:212 */     attr3.setDataType(12);
/* 190:    */     
/* 191:    */ 
/* 192:215 */     componentInfo.addAttributeInfo(attr1);
/* 193:216 */     componentInfo.addAttributeInfo(attr2);
/* 194:217 */     componentInfo.addAttributeInfo(attr3);
/* 195:    */     
/* 196:219 */     return componentInfo;
/* 197:    */   }
/* 198:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.ui.MobileUIControlInfo
 * JD-Core Version:    0.7.0.1
 */