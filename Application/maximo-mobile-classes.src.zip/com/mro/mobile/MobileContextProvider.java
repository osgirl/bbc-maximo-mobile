package com.mro.mobile;

public abstract interface MobileContextProvider
{
  public abstract MobileContext getMobileContext()
    throws MobileApplicationException;
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.MobileContextProvider
 * JD-Core Version:    0.7.0.1
 */