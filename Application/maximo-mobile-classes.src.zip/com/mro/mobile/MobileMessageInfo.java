/*   1:    */ package com.mro.mobile;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.type.Serializer;
/*   4:    */ import com.mro.mobile.type.TypeRegistry;
/*   5:    */ import java.io.DataInput;
/*   6:    */ import java.io.DataOutput;
/*   7:    */ import java.io.IOException;
/*   8:    */ 
/*   9:    */ public class MobileMessageInfo
/*  10:    */   implements Serializer
/*  11:    */ {
/*  12: 25 */   private String messageKey = null;
/*  13: 26 */   private String message = null;
/*  14: 27 */   private String messageId = null;
/*  15: 28 */   private Boolean messagePrefix = null;
/*  16:    */   
/*  17:    */   public String getMessage()
/*  18:    */   {
/*  19: 32 */     return this.message;
/*  20:    */   }
/*  21:    */   
/*  22:    */   public void setMessage(String message)
/*  23:    */   {
/*  24: 37 */     this.message = message;
/*  25:    */   }
/*  26:    */   
/*  27:    */   public String getMessageKey()
/*  28:    */   {
/*  29: 42 */     return this.messageKey;
/*  30:    */   }
/*  31:    */   
/*  32:    */   public void setMessageKey(String messageKey)
/*  33:    */   {
/*  34: 47 */     this.messageKey = messageKey;
/*  35:    */   }
/*  36:    */   
/*  37:    */   public static void initSerializer()
/*  38:    */   {
/*  39: 52 */     MobileMessageInfo i = new MobileMessageInfo();
/*  40: 53 */     TypeRegistry.getTypeRegistry().addType("MobileMessageInfo", i.getClass(), i);
/*  41:    */   }
/*  42:    */   
/*  43:    */   public Object readInstance(DataInput input, String name)
/*  44:    */     throws IOException
/*  45:    */   {
/*  46: 58 */     if (name.equals("MobileMessageInfo"))
/*  47:    */     {
/*  48: 60 */       String readMessageKey = input.readUTF();
/*  49: 61 */       String readMessage = input.readUTF();
/*  50: 62 */       String readMessageId = input.readUTF();
/*  51: 63 */       boolean readMessagePrefix = input.readBoolean();
/*  52:    */       
/*  53: 65 */       MobileMessageInfo messageInfo = new MobileMessageInfo();
/*  54: 66 */       messageInfo.setMessageKey(readMessageKey);
/*  55: 67 */       messageInfo.setMessage(readMessage);
/*  56: 68 */       messageInfo.setMessageId(readMessageId);
/*  57: 69 */       messageInfo.setMessagePrefix(Boolean.valueOf(readMessagePrefix));
/*  58:    */       
/*  59: 71 */       return messageInfo;
/*  60:    */     }
/*  61: 74 */     throw new RuntimeException("The type " + name + " not supported.");
/*  62:    */   }
/*  63:    */   
/*  64:    */   public void writeInstance(DataOutput output, Object obj)
/*  65:    */     throws IOException
/*  66:    */   {
/*  67: 79 */     if ((obj instanceof MobileMessageInfo))
/*  68:    */     {
/*  69: 81 */       MobileMessageInfo mobileMessageInfo = (MobileMessageInfo)obj;
/*  70: 82 */       output.writeUTF(mobileMessageInfo.getMessageKey());
/*  71: 83 */       output.writeUTF(mobileMessageInfo.getMessage());
/*  72: 84 */       output.writeUTF(mobileMessageInfo.getMessageId());
/*  73: 85 */       output.writeBoolean(mobileMessageInfo.getMessagePrefix().booleanValue());
/*  74:    */     }
/*  75:    */   }
/*  76:    */   
/*  77:    */   public String getMessageId()
/*  78:    */   {
/*  79: 90 */     return this.messageId;
/*  80:    */   }
/*  81:    */   
/*  82:    */   public void setMessageId(String msgId)
/*  83:    */   {
/*  84: 94 */     this.messageId = msgId;
/*  85:    */   }
/*  86:    */   
/*  87:    */   public Boolean getMessagePrefix()
/*  88:    */   {
/*  89: 98 */     return this.messagePrefix;
/*  90:    */   }
/*  91:    */   
/*  92:    */   public void setMessagePrefix(Boolean messagePrefix)
/*  93:    */   {
/*  94:102 */     this.messagePrefix = messagePrefix;
/*  95:    */   }
/*  96:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.MobileMessageInfo
 * JD-Core Version:    0.7.0.1
 */