/*  1:   */ package com.mro.mobile;
/*  2:   */ 
/*  3:   */ import com.mro.mobile.ui.res.ControlData;
/*  4:   */ import java.util.Hashtable;
/*  5:   */ 
/*  6:   */ public class MobileScreenRegistry
/*  7:   */ {
/*  8:35 */   private static final MobileScreenRegistry screenRegistry = new MobileScreenRegistry();
/*  9:37 */   Hashtable registry = new Hashtable();
/* 10:   */   
/* 11:   */   public static MobileScreenRegistry getInstance()
/* 12:   */   {
/* 13:41 */     return screenRegistry;
/* 14:   */   }
/* 15:   */   
/* 16:   */   public void registerScreen(String screenId, ControlData controlData)
/* 17:   */   {
/* 18:46 */     this.registry.put(screenId, controlData);
/* 19:   */   }
/* 20:   */   
/* 21:   */   public ControlData getScreenData(String screenId)
/* 22:   */   {
/* 23:51 */     if (screenId != null) {
/* 24:52 */       return (ControlData)this.registry.get(screenId);
/* 25:   */     }
/* 26:53 */     return null;
/* 27:   */   }
/* 28:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.MobileScreenRegistry
 * JD-Core Version:    0.7.0.1
 */