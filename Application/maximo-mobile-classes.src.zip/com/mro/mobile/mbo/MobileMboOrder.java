/*   1:    */ package com.mro.mobile.mbo;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.persist.DefaultOrder;
/*   4:    */ import com.mro.mobile.persist.RDOException;
/*   5:    */ import com.mro.mobile.type.Serializer;
/*   6:    */ import com.mro.mobile.type.TypeRegistry;
/*   7:    */ import java.io.ByteArrayInputStream;
/*   8:    */ import java.io.ByteArrayOutputStream;
/*   9:    */ import java.io.DataInput;
/*  10:    */ import java.io.DataInputStream;
/*  11:    */ import java.io.DataOutput;
/*  12:    */ import java.io.DataOutputStream;
/*  13:    */ import java.io.IOException;
/*  14:    */ import java.util.Enumeration;
/*  15:    */ 
/*  16:    */ public class MobileMboOrder
/*  17:    */   extends DefaultOrder
/*  18:    */   implements Serializer
/*  19:    */ {
/*  20:    */   public MobileMboOrder() {}
/*  21:    */   
/*  22:    */   public MobileMboOrder(byte[] data)
/*  23:    */     throws IOException
/*  24:    */   {
/*  25: 39 */     ByteArrayInputStream bis = new ByteArrayInputStream(data);
/*  26: 40 */     DataInputStream dis = new DataInputStream(bis);
/*  27: 41 */     readState(dis);
/*  28:    */   }
/*  29:    */   
/*  30:    */   private void readState(DataInput input)
/*  31:    */     throws IOException
/*  32:    */   {
/*  33: 46 */     int noOfAttributes = input.readInt();
/*  34: 47 */     for (int i = 0; i < noOfAttributes; i++)
/*  35:    */     {
/*  36: 49 */       String attribute = input.readUTF();
/*  37: 50 */       boolean order = input.readBoolean();
/*  38: 51 */       setOrder(attribute, order);
/*  39:    */     }
/*  40:    */   }
/*  41:    */   
/*  42:    */   public byte[] getBinaryValue()
/*  43:    */     throws IOException
/*  44:    */   {
/*  45: 57 */     ByteArrayOutputStream bos = new ByteArrayOutputStream();
/*  46: 58 */     DataOutputStream output = new DataOutputStream(bos);
/*  47:    */     try
/*  48:    */     {
/*  49: 62 */       output.writeInt(size());
/*  50: 63 */       Enumeration attrOrderEnum = getOrderedAttributes();
/*  51: 64 */       while (attrOrderEnum.hasMoreElements())
/*  52:    */       {
/*  53: 66 */         String attribute = (String)attrOrderEnum.nextElement();
/*  54: 67 */         boolean order = getOrder(attribute);
/*  55: 68 */         output.writeUTF(attribute);
/*  56: 69 */         output.writeBoolean(order);
/*  57:    */       }
/*  58: 72 */       output.flush();
/*  59:    */     }
/*  60:    */     catch (RDOException e)
/*  61:    */     {
/*  62: 76 */       throw new IOException(e.getMessage());
/*  63:    */     }
/*  64: 79 */     return bos.toByteArray();
/*  65:    */   }
/*  66:    */   
/*  67:    */   public static void initSerializer()
/*  68:    */   {
/*  69: 85 */     MobileMboOrder i = new MobileMboOrder();
/*  70: 86 */     TypeRegistry.getTypeRegistry().addType("MobileMboOrder", i.getClass(), i);
/*  71:    */   }
/*  72:    */   
/*  73:    */   public Object readInstance(DataInput input, String name)
/*  74:    */     throws IOException
/*  75:    */   {
/*  76: 91 */     if (name.equals("MobileMboOrder"))
/*  77:    */     {
/*  78: 93 */       MobileMboOrder mboOrder = new MobileMboOrder();
/*  79: 94 */       int noOfAttributes = input.readInt();
/*  80: 95 */       for (int i = 0; i < noOfAttributes; i++)
/*  81:    */       {
/*  82: 97 */         String attribute = input.readUTF();
/*  83: 98 */         boolean order = input.readBoolean();
/*  84:    */         
/*  85:100 */         mboOrder.setOrder(attribute, order);
/*  86:    */       }
/*  87:103 */       return mboOrder;
/*  88:    */     }
/*  89:106 */     throw new RuntimeException("The type " + name + " not supported.");
/*  90:    */   }
/*  91:    */   
/*  92:    */   public void writeInstance(DataOutput output, Object obj)
/*  93:    */     throws IOException
/*  94:    */   {
/*  95:111 */     if ((obj instanceof MobileMboOrder)) {
/*  96:    */       try
/*  97:    */       {
/*  98:115 */         MobileMboOrder mboOrder = (MobileMboOrder)obj;
/*  99:    */         
/* 100:117 */         output.writeInt(mboOrder.size());
/* 101:118 */         Enumeration attrOrderEnum = mboOrder.getOrderedAttributes();
/* 102:119 */         while (attrOrderEnum.hasMoreElements())
/* 103:    */         {
/* 104:121 */           String attribute = (String)attrOrderEnum.nextElement();
/* 105:122 */           boolean order = mboOrder.getOrder(attribute);
/* 106:123 */           output.writeUTF(attribute);
/* 107:124 */           output.writeBoolean(order);
/* 108:    */         }
/* 109:    */       }
/* 110:    */       catch (RDOException e)
/* 111:    */       {
/* 112:129 */         throw new IOException(e.getMessage());
/* 113:    */       }
/* 114:    */     }
/* 115:    */   }
/* 116:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.mbo.MobileMboOrder
 * JD-Core Version:    0.7.0.1
 */