/*   1:    */ package com.mro.mobile.mbo;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.app.AbstractMobileDeviceApplication;
/*   5:    */ import com.mro.mobile.app.BasicMobileDeviceUIApplication;
/*   6:    */ import com.mro.mobile.app.MobileDeviceAppSession;
/*   7:    */ import com.mro.mobile.persist.RDO;
/*   8:    */ import com.mro.mobile.persist.RDOEnumeration;
/*   9:    */ import com.mro.mobile.persist.RDOManager;
/*  10:    */ import com.mro.mobile.persist.RDORuntime;
/*  11:    */ import com.mro.mobile.persist.RDOTransactionManager;
/*  12:    */ import com.mro.mobile.ui.DataBeanCache;
/*  13:    */ import com.mro.mobile.ui.MobileMboDataBean;
/*  14:    */ import com.mro.mobile.ui.MobileMboDataBeanManager;
/*  15:    */ import com.mro.mobile.ui.res.UIUtil;
/*  16:    */ import com.mro.mobile.util.MobileLogger;
/*  17:    */ import com.mro.mobile.util.MobileLoggerFactory;
/*  18:    */ import java.util.HashMap;
/*  19:    */ import java.util.HashSet;
/*  20:    */ import java.util.Iterator;
/*  21:    */ import java.util.Map;
/*  22:    */ import java.util.Set;
/*  23:    */ import java.util.StringTokenizer;
/*  24:    */ 
/*  25:    */ public class MobileMboDependencyManager
/*  26:    */ {
/*  27: 40 */   private static Map relations = new HashMap();
/*  28: 41 */   private static Map relationsDisplayInfo = new HashMap();
/*  29: 42 */   private static MobileMbo[] mobileMbosToSend = null;
/*  30: 43 */   private static Set queryCache = new HashSet();
/*  31:    */   
/*  32:    */   public static void registerDisplayInfo(String mobileMboName, RelationDisplayInfo info)
/*  33:    */   {
/*  34: 47 */     relationsDisplayInfo.put(mobileMboName, info);
/*  35:    */   }
/*  36:    */   
/*  37:    */   public static RelationDisplayInfo getDisplayInfo(String mobileMboName)
/*  38:    */   {
/*  39: 52 */     return (RelationDisplayInfo)relationsDisplayInfo.get(mobileMboName);
/*  40:    */   }
/*  41:    */   
/*  42:    */   public static void registryDependency(String targetMobileMboName, String targetMobileMboAttr, String sourceMobileMboName, String sourceMobileMboAttr)
/*  43:    */   {
/*  44: 69 */     registrySourceReferredFromTargetDependency(targetMobileMboName, targetMobileMboAttr, sourceMobileMboName, sourceMobileMboAttr);
/*  45: 70 */     registryTargetRefersToSourceDependency(targetMobileMboName, targetMobileMboAttr, sourceMobileMboName, sourceMobileMboAttr);
/*  46:    */   }
/*  47:    */   
/*  48:    */   private static void registrySourceReferredFromTargetDependency(String targetMobileMboName, String targetMobileMboAttr, String sourceMobileMboName, String sourceMobileMboAttr)
/*  49:    */   {
/*  50: 80 */     registryFromToDependency(sourceMobileMboName, sourceMobileMboAttr, targetMobileMboName, targetMobileMboAttr, 2);
/*  51:    */   }
/*  52:    */   
/*  53:    */   private static void registryTargetRefersToSourceDependency(String targetMobileMboName, String targetMobileMboAttr, String sourceMobileMboName, String sourceMobileMboAttr)
/*  54:    */   {
/*  55: 88 */     registryFromToDependency(targetMobileMboName, targetMobileMboAttr, sourceMobileMboName, sourceMobileMboAttr, 1);
/*  56:    */   }
/*  57:    */   
/*  58:    */   private static void registryFromToDependency(String fromMobileMboName, String fromMobileMboAttr, String toMobileMboName, String toMobileMboAttr, int relationType)
/*  59:    */   {
/*  60:114 */     int childSepPos = fromMobileMboName.indexOf('/');
/*  61:115 */     if (childSepPos > -1)
/*  62:    */     {
/*  63:117 */       String parentName = fromMobileMboName.substring(0, childSepPos);
/*  64:118 */       childSepPos++;
/*  65:119 */       int nextChildSepPos = fromMobileMboName.indexOf('/', childSepPos);
/*  66:120 */       String childName = null;
/*  67:121 */       if (nextChildSepPos > -1) {
/*  68:123 */         childName = fromMobileMboName.substring(childSepPos, nextChildSepPos);
/*  69:    */       } else {
/*  70:127 */         childName = fromMobileMboName.substring(childSepPos);
/*  71:    */       }
/*  72:130 */       DependentInfo fromInfo = getHierarchyDependentInfo(parentName);
/*  73:    */       
/*  74:132 */       fromInfo.addChild(childName);
/*  75:133 */       fromInfo.setRelationType(relationType);
/*  76:    */       
/*  77:135 */       addToRelationsMap(fromInfo, parentName);
/*  78:    */       
/*  79:    */ 
/*  80:    */ 
/*  81:139 */       fromMobileMboName = fromMobileMboName.substring(childSepPos);
/*  82:140 */       registryFromToDependency(fromMobileMboName, fromMobileMboAttr, toMobileMboName, toMobileMboAttr, relationType);
/*  83:    */     }
/*  84:    */     else
/*  85:    */     {
/*  86:144 */       DependentInfo toInfo = new DependentInfo(null);
/*  87:145 */       toInfo.setSourceMobileMboName(fromMobileMboName);
/*  88:146 */       toInfo.setSourceMobileMboAttribute(fromMobileMboAttr);
/*  89:147 */       String mobileMboName = toMobileMboName;
/*  90:148 */       int lastChildSepPos = mobileMboName.lastIndexOf('/');
/*  91:149 */       if (lastChildSepPos > -1)
/*  92:    */       {
/*  93:154 */         lastChildSepPos++;
/*  94:155 */         mobileMboName = mobileMboName.substring(lastChildSepPos);
/*  95:    */       }
/*  96:157 */       toInfo.setTargetMobileMboName(mobileMboName);
/*  97:158 */       toInfo.setTargetMobileMboAttribute(toMobileMboAttr);
/*  98:159 */       toInfo.setRelationType(relationType);
/*  99:160 */       addToRelationsMap(toInfo, fromMobileMboName);
/* 100:    */     }
/* 101:    */   }
/* 102:    */   
/* 103:    */   private static DependentInfo getHierarchyDependentInfo(String parentName)
/* 104:    */   {
/* 105:168 */     DependentInfo result = null;
/* 106:169 */     Set toInfoList = (Set)relations.get(parentName);
/* 107:170 */     if (toInfoList != null)
/* 108:    */     {
/* 109:172 */       Iterator iter = toInfoList.iterator();
/* 110:173 */       while (iter.hasNext())
/* 111:    */       {
/* 112:175 */         DependentInfo info = (DependentInfo)iter.next();
/* 113:176 */         if (info.hasChildren())
/* 114:    */         {
/* 115:178 */           result = info;
/* 116:179 */           break;
/* 117:    */         }
/* 118:    */       }
/* 119:    */     }
/* 120:184 */     return result != null ? result : new DependentInfo(null);
/* 121:    */   }
/* 122:    */   
/* 123:    */   private static void addToRelationsMap(DependentInfo toInfo, String keyName)
/* 124:    */   {
/* 125:188 */     Set toInfoList = (Set)relations.get(keyName);
/* 126:189 */     if (toInfoList == null)
/* 127:    */     {
/* 128:191 */       toInfoList = new HashSet();
/* 129:192 */       relations.put(keyName, toInfoList);
/* 130:    */     }
/* 131:194 */     toInfoList.add(toInfo);
/* 132:    */   }
/* 133:    */   
/* 134:    */   public static boolean handleDependencies(MobileMbo mobileMbo)
/* 135:    */     throws MobileApplicationException
/* 136:    */   {
/* 137:210 */     if (mobileMbosToSend != null) {
/* 138:212 */       return true;
/* 139:    */     }
/* 140:215 */     Set result = getRelations(mobileMbo);
/* 141:217 */     if (result.size() == 0) {
/* 142:219 */       return false;
/* 143:    */     }
/* 144:225 */     MobileDeviceAppSession deviceAppSession = MobileDeviceAppSession.getSession();
/* 145:226 */     String flagShowDepScreen = (String)deviceAppSession.getAttribute("_DONTSHOWDEPSCREEN");
/* 146:227 */     boolean autoDone = true;
/* 147:228 */     if (!"1".equals(flagShowDepScreen))
/* 148:    */     {
/* 149:230 */       showDependenciesPage(mobileMbo, result);
/* 150:231 */       autoDone = false;
/* 151:    */     }
/* 152:233 */     result.add(new ComparableMobileMbo(mobileMbo));
/* 153:234 */     keepDependencyListForLaterSend(result);
/* 154:236 */     if (autoDone) {
/* 155:238 */       doneAllDependencies();
/* 156:    */     }
/* 157:241 */     return true;
/* 158:    */   }
/* 159:    */   
/* 160:    */   public static void reset()
/* 161:    */   {
/* 162:246 */     mobileMbosToSend = null;
/* 163:247 */     queryCache.clear();
/* 164:    */   }
/* 165:    */   
/* 166:    */   public static void doneAllDependencies()
/* 167:    */     throws MobileApplicationException
/* 168:    */   {
/* 169:255 */     markAllDone();
/* 170:256 */     submitAll();
/* 171:257 */     reset();
/* 172:    */     
/* 173:    */ 
/* 174:260 */     DataBeanCache.removeAllDataBeans();
/* 175:    */   }
/* 176:    */   
/* 177:    */   private static void submitAll()
/* 178:    */     throws MobileApplicationException
/* 179:    */   {
/* 180:264 */     MobileDeviceAppSession.getSession().getApplication().performDataTransaction(mobileMbosToSend);
/* 181:    */   }
/* 182:    */   
/* 183:    */   private static void markAllDone()
/* 184:    */     throws MobileApplicationException
/* 185:    */   {
/* 186:269 */     MobileDeviceAppSession deviceAppSession = MobileDeviceAppSession.getSession();
/* 187:270 */     AbstractMobileDeviceApplication app = deviceAppSession.getApplication();
/* 188:    */     
/* 189:272 */     RDORuntime rdoRuntime = app.getRDORuntime();
/* 190:273 */     RDOManager rdoManager = rdoRuntime.getRDOManager();
/* 191:274 */     RDOTransactionManager txnManager = rdoRuntime.getRDOTransactionManager();
/* 192:    */     try
/* 193:    */     {
/* 194:278 */       txnManager.begin();
/* 195:279 */       int count = mobileMbosToSend.length;
/* 196:280 */       for (int index = 0; index < count; index++)
/* 197:    */       {
/* 198:282 */         MobileMbo mobileMbo = mobileMbosToSend[index];
/* 199:283 */         mobileMbo.setBooleanValue("_DONE", true);
/* 200:284 */         RDO rdo = mobileMbo.getRDO();
/* 201:285 */         rdoManager.update(rdo.getName(), rdo);
/* 202:    */       }
/* 203:288 */       txnManager.commit();
/* 204:    */     }
/* 205:    */     catch (Exception ex)
/* 206:    */     {
/* 207:293 */       MobileLoggerFactory.getDefaultLogger().warn("Failed to save and mark all done", ex);
/* 208:    */       try
/* 209:    */       {
/* 210:297 */         txnManager.rollback();
/* 211:    */       }
/* 212:    */       catch (Exception ex1) {}
/* 213:300 */       throw new MobileApplicationException("savefailed");
/* 214:    */     }
/* 215:    */   }
/* 216:    */   
/* 217:    */   private static void keepDependencyListForLaterSend(Set result)
/* 218:    */   {
/* 219:306 */     int size = result.size();
/* 220:307 */     mobileMbosToSend = new MobileMbo[size];
/* 221:308 */     Iterator iter = result.iterator();
/* 222:309 */     int index = 0;
/* 223:310 */     while (iter.hasNext())
/* 224:    */     {
/* 225:312 */       ComparableMobileMbo compMobileMbo = (ComparableMobileMbo)iter.next();
/* 226:313 */       mobileMbosToSend[index] = compMobileMbo.getMobileMbo();
/* 227:314 */       index++;
/* 228:    */     }
/* 229:    */   }
/* 230:    */   
/* 231:    */   private static void showDependenciesPage(MobileMbo mobileMboSent, Set depMobileMbos)
/* 232:    */     throws MobileApplicationException
/* 233:    */   {
/* 234:321 */     MobileMboDataBean titleBean = DataBeanCache.getDataBean("DEPENDENCYTITLE", "DEPENDENCYTITLE");
/* 235:    */     
/* 236:323 */     titleBean.reset();
/* 237:324 */     titleBean.insert();
/* 238:    */     
/* 239:326 */     RelationDisplayInfo displayInfo = getDisplayInfo(mobileMboSent.getName());
/* 240:327 */     String recDisplayType = displayInfo.getMobileMboNameToDisplay();
/* 241:328 */     String recNumAttr = displayInfo.getRecordNumAttr();
/* 242:329 */     String recNum = mobileMboSent.getValue(recNumAttr);
/* 243:    */     
/* 244:331 */     titleBean.setValue("MOBILEMBODISPLAYNAME", recDisplayType);
/* 245:332 */     titleBean.setValue("RECNUM", recNum);
/* 246:    */     
/* 247:334 */     titleBean.close();
/* 248:    */     
/* 249:336 */     MobileMboDataBean displayBean = DataBeanCache.getDataBean("DEPENDENCIESDISPLAY", "DEPENDENCIESDISPLAY");
/* 250:337 */     displayBean.reset();
/* 251:    */     
/* 252:339 */     Iterator iter = depMobileMbos.iterator();
/* 253:340 */     while (iter.hasNext())
/* 254:    */     {
/* 255:342 */       ComparableMobileMbo compMobileMbo = (ComparableMobileMbo)iter.next();
/* 256:343 */       MobileMbo mobileMbo = compMobileMbo.getMobileMbo();
/* 257:344 */       addMobileMboToDisplay(displayBean, mobileMbo);
/* 258:    */     }
/* 259:346 */     displayBean.close();
/* 260:    */     
/* 261:348 */     UIUtil.gotoPage("dependencies", UIUtil.getCurrentScreen());
/* 262:    */   }
/* 263:    */   
/* 264:    */   private static void addMobileMboToDisplay(MobileMboDataBean displayBean, MobileMbo mobileMbo)
/* 265:    */     throws MobileApplicationException
/* 266:    */   {
/* 267:356 */     displayBean.insert();
/* 268:357 */     MobileMbo displayMobileMbo = displayBean.getMobileMbo();
/* 269:    */     
/* 270:    */ 
/* 271:360 */     String mobileMboName = mobileMbo.getName();
/* 272:361 */     displayMobileMbo.setValue("MOBILEMBONAME", mobileMboName);
/* 273:362 */     displayMobileMbo.setValue("MOBILEMBODISPLAYNAME", mobileMboName);
/* 274:363 */     displayMobileMbo.setLongValue("RECID", mobileMbo.getId());
/* 275:    */     
/* 276:365 */     RelationDisplayInfo displayInfo = getDisplayInfo(mobileMboName);
/* 277:367 */     if (displayInfo != null)
/* 278:    */     {
/* 279:369 */       String recNumAttr = displayInfo.getRecordNumAttr();
/* 280:370 */       String recDescAttr = displayInfo.getRecordDescAttr();
/* 281:371 */       String recTypeName = displayInfo.getMobileMboNameToDisplay();
/* 282:373 */       if ((recTypeName != null) && (!recTypeName.trim().equals(""))) {
/* 283:375 */         displayMobileMbo.setValue("MOBILEMBODISPLAYNAME", recTypeName);
/* 284:    */       }
/* 285:378 */       if ((recNumAttr != null) && (!recNumAttr.trim().equals(""))) {
/* 286:380 */         displayMobileMbo.setValue("RECNUM", mobileMbo.getValue(recNumAttr));
/* 287:    */       }
/* 288:383 */       if ((recDescAttr != null) && (!recDescAttr.trim().equals(""))) {
/* 289:385 */         displayMobileMbo.setValue("DESCRIPTION", mobileMbo.getValue(recDescAttr));
/* 290:    */       }
/* 291:    */     }
/* 292:    */   }
/* 293:    */   
/* 294:    */   private static Set getRelations(MobileMbo mobileMbo)
/* 295:    */     throws MobileApplicationException
/* 296:    */   {
/* 297:393 */     Set result = new HashSet();
/* 298:394 */     queryCache.clear();
/* 299:395 */     addRelatesToMe(mobileMbo, result, null);
/* 300:    */     
/* 301:397 */     return result;
/* 302:    */   }
/* 303:    */   
/* 304:    */   private static void addRelatesToMe(MobileMbo mobileMbo, Set mobileMboList, ComparableMobileMbo mobileMboToExclude)
/* 305:    */     throws MobileApplicationException
/* 306:    */   {
/* 307:411 */     if (mobileMboToExclude == null) {
/* 308:413 */       mobileMboToExclude = new ComparableMobileMbo(mobileMbo);
/* 309:    */     }
/* 310:416 */     addNewMobileMbosReferredFromMe(mobileMbo, mobileMboList, mobileMboToExclude);
/* 311:418 */     if (mobileMbo.isNew()) {
/* 312:420 */       addMobileMbosReferToMe(mobileMbo, mobileMboList, mobileMboToExclude);
/* 313:    */     }
/* 314:    */   }
/* 315:    */   
/* 316:    */   private static void addRelatedMobileMbosWithMe(MobileMbo currentMobileMbo, Set mobileMboList, ComparableMobileMbo mobileMboToExclude, int relationType, boolean newOnly)
/* 317:    */     throws MobileApplicationException
/* 318:    */   {
/* 319:428 */     String mobileMboName = currentMobileMbo.getName();
/* 320:    */     
/* 321:430 */     Set relationInfoList = (Set)relations.get(mobileMboName);
/* 322:431 */     if ((relationInfoList == null) || (relationInfoList.size() == 0)) {
/* 323:433 */       return;
/* 324:    */     }
/* 325:436 */     Iterator iter = relationInfoList.iterator();
/* 326:437 */     while (iter.hasNext())
/* 327:    */     {
/* 328:439 */       DependentInfo relationInfo = (DependentInfo)iter.next();
/* 329:441 */       if (relationInfo.getRelationType() == relationType) {
/* 330:443 */         if (!relationInfo.hasChildren())
/* 331:    */         {
/* 332:445 */           MobileMbo[] foundReferers = getMobileMbos(currentMobileMbo, relationInfo, newOnly);
/* 333:447 */           if (foundReferers != null) {
/* 334:449 */             for (int index = 0; index < foundReferers.length; index++)
/* 335:    */             {
/* 336:451 */               MobileMbo relatedMobileMbo = foundReferers[index];
/* 337:452 */               ComparableMobileMbo compRelatedMobileMbo = new ComparableMobileMbo(relatedMobileMbo);
/* 338:453 */               boolean shouldInclude = !compRelatedMobileMbo.equals(mobileMboToExclude);
/* 339:454 */               if (shouldInclude)
/* 340:    */               {
/* 341:456 */                 boolean notInResultListYet = mobileMboList.add(compRelatedMobileMbo);
/* 342:457 */                 if (notInResultListYet) {
/* 343:461 */                   addRelatesToMe(relatedMobileMbo, mobileMboList, mobileMboToExclude);
/* 344:    */                 }
/* 345:    */               }
/* 346:    */             }
/* 347:    */           }
/* 348:    */         }
/* 349:    */         else
/* 350:    */         {
/* 351:469 */           addRelatedMobileMbosWithMyChildren(currentMobileMbo, mobileMboList, mobileMboToExclude, relationInfo, relationType, newOnly);
/* 352:    */         }
/* 353:    */       }
/* 354:    */     }
/* 355:    */   }
/* 356:    */   
/* 357:    */   private static void addRelatedMobileMbosWithMyChildren(MobileMbo currentMobileMbo, Set mobileMboList, ComparableMobileMbo mobileMboToExclude, DependentInfo parentInfo, int relationType, boolean newOnly)
/* 358:    */     throws MobileApplicationException
/* 359:    */   {
/* 360:479 */     String[] children = parentInfo.getChildren();
/* 361:480 */     int count = children.length;
/* 362:481 */     for (int index = 0; index < count; index++)
/* 363:    */     {
/* 364:483 */       String childName = children[index];
/* 365:484 */       RDO parentRDO = currentMobileMbo.getRDO();
/* 366:485 */       RDOEnumeration rdoEnum = UIUtil.getApplication().getRDORuntime().getRDOManager().getDependents(childName, parentRDO);
/* 367:487 */       while (rdoEnum.hasMoreElements())
/* 368:    */       {
/* 369:489 */         RDO rdo = (RDO)rdoEnum.nextElement();
/* 370:490 */         MobileMbo childMobileMbo = new MobileMbo(rdo);
/* 371:    */         
/* 372:492 */         addRelatedMobileMbosWithMe(childMobileMbo, mobileMboList, mobileMboToExclude, relationType, newOnly);
/* 373:    */       }
/* 374:    */     }
/* 375:    */   }
/* 376:    */   
/* 377:    */   private static void addMobileMbosReferToMe(MobileMbo currentMobileMbo, Set mobileMboList, ComparableMobileMbo mobileMboToExclude)
/* 378:    */     throws MobileApplicationException
/* 379:    */   {
/* 380:501 */     addRelatedMobileMbosWithMe(currentMobileMbo, mobileMboList, mobileMboToExclude, 2, false);
/* 381:    */   }
/* 382:    */   
/* 383:    */   private static void addNewMobileMbosReferredFromMe(MobileMbo currentMobileMbo, Set mobileMboList, ComparableMobileMbo mobileMboToExclude)
/* 384:    */     throws MobileApplicationException
/* 385:    */   {
/* 386:508 */     addRelatedMobileMbosWithMe(currentMobileMbo, mobileMboList, mobileMboToExclude, 1, true);
/* 387:    */   }
/* 388:    */   
/* 389:    */   private static MobileMbo[] getMobileMbos(MobileMbo mobileMbo, DependentInfo info, boolean newOnly)
/* 390:    */     throws MobileApplicationException
/* 391:    */   {
/* 392:513 */     MobileMbo[] result = null;
/* 393:    */     
/* 394:515 */     String sourceAttribute = info.getSourceMobileMboAttribute();
/* 395:516 */     String valueToSearch = mobileMbo.getValue(sourceAttribute);
/* 396:517 */     if ((valueToSearch != null) && (valueToSearch.trim().length() > 0))
/* 397:    */     {
/* 398:519 */       String mobileMboName = info.getTargetMobileMboName();
/* 399:520 */       String mobileMboAttribute = info.getTargetMobileMboAttribute();
/* 400:522 */       if (!queryAlreadyDone(mobileMboName, mobileMboAttribute, mobileMbo.getValue(sourceAttribute)))
/* 401:    */       {
/* 402:524 */         MobileMboDataBean databean = new MobileMboDataBeanManager(mobileMboName).getDataBean();
/* 403:    */         
/* 404:526 */         MobileMboQBE qbe = databean.getQBE();
/* 405:527 */         qbe.reset();
/* 406:528 */         qbe.setQbeExactMatch(true);
/* 407:529 */         qbe.setQBE(mobileMboAttribute, mobileMbo.getValue(sourceAttribute));
/* 408:531 */         if (newOnly) {
/* 409:533 */           qbe.setQBE("_NEW", "1");
/* 410:    */         }
/* 411:536 */         databean.reset();
/* 412:537 */         databean.getMobileMbo();
/* 413:    */         
/* 414:539 */         int count = databean.count();
/* 415:540 */         if (count > 0)
/* 416:    */         {
/* 417:542 */           result = new MobileMbo[count];
/* 418:544 */           for (int index = 0; index < count; index++) {
/* 419:546 */             result[index] = getParentOrSelf(databean.getMobileMbo(index));
/* 420:    */           }
/* 421:    */         }
/* 422:    */       }
/* 423:    */     }
/* 424:552 */     return result;
/* 425:    */   }
/* 426:    */   
/* 427:    */   private static boolean queryAlreadyDone(String mobileMboName, String mobileMboAttribute, String value)
/* 428:    */   {
/* 429:558 */     int bufLen = mobileMboName.length() + mobileMboAttribute.length() + value.length() + 3;
/* 430:559 */     StringBuffer bufQuery = new StringBuffer(bufLen);
/* 431:560 */     bufQuery.append(mobileMboName).append("$").append(mobileMboAttribute).append("$").append(value);
/* 432:    */     
/* 433:    */ 
/* 434:    */ 
/* 435:    */ 
/* 436:    */ 
/* 437:566 */     String keyQuery = bufQuery.toString();
/* 438:    */     
/* 439:568 */     return !queryCache.add(keyQuery);
/* 440:    */   }
/* 441:    */   
/* 442:    */   private static MobileMbo getParentOrSelf(MobileMbo mobileMbo)
/* 443:    */     throws MobileApplicationException
/* 444:    */   {
/* 445:573 */     MobileMbo result = mobileMbo;
/* 446:574 */     MobileMboInfo info = mobileMbo.getMobileMboInfo();
/* 447:575 */     String parent = info.getParent();
/* 448:576 */     if (parent != null)
/* 449:    */     {
/* 450:578 */       long parentId = mobileMbo.getLongValue("_PARENTID");
/* 451:579 */       RDO rdo = UIUtil.getApplication().getRDORuntime().getRDOManager().get(parent, parentId);
/* 452:580 */       if (rdo != null) {
/* 453:582 */         result = getParentOrSelf(new MobileMbo(rdo));
/* 454:    */       }
/* 455:    */     }
/* 456:586 */     return result;
/* 457:    */   }
/* 458:    */   
/* 459:    */   private static class DependentInfo
/* 460:    */   {
/* 461:    */     public static final int REFERS_TO = 1;
/* 462:    */     public static final int REFERRED_FROM = 2;
/* 463:    */     
/* 464:    */     public int getRelationType()
/* 465:    */     {
/* 466:594 */       return this.relationType;
/* 467:    */     }
/* 468:    */     
/* 469:    */     public void setRelationType(int relationType)
/* 470:    */     {
/* 471:598 */       this.relationType = relationType;
/* 472:    */     }
/* 473:    */     
/* 474:603 */     private StringBuffer children = null;
/* 475:604 */     private int childrenCount = 0;
/* 476:606 */     private String sourceMobileMboName = null;
/* 477:607 */     private String sourceMobileMboAttribute = null;
/* 478:608 */     private String targetMobileMboName = null;
/* 479:609 */     private String targetMobileMboAttribute = null;
/* 480:610 */     private int relationType = 1;
/* 481:    */     
/* 482:    */     public void addChild(String child)
/* 483:    */     {
/* 484:617 */       String formattedChild = '[' + child + ']';
/* 485:618 */       if (this.children == null) {
/* 486:620 */         this.children = new StringBuffer();
/* 487:    */       }
/* 488:622 */       if (this.children.indexOf(formattedChild) == -1)
/* 489:    */       {
/* 490:624 */         if (this.childrenCount > 0) {
/* 491:626 */           this.children.append(',');
/* 492:    */         }
/* 493:628 */         this.children.append(formattedChild);
/* 494:629 */         this.childrenCount += 1;
/* 495:    */       }
/* 496:    */     }
/* 497:    */     
/* 498:    */     public boolean hasChildren()
/* 499:    */     {
/* 500:635 */       return this.childrenCount > 0;
/* 501:    */     }
/* 502:    */     
/* 503:    */     public String[] getChildren()
/* 504:    */     {
/* 505:640 */       if (this.childrenCount == 0) {
/* 506:642 */         return null;
/* 507:    */       }
/* 508:644 */       String[] result = new String[this.childrenCount];
/* 509:645 */       StringTokenizer st = new StringTokenizer(this.children.toString(), ",");
/* 510:646 */       int index = 0;
/* 511:647 */       while (st.hasMoreTokens())
/* 512:    */       {
/* 513:650 */         String formattedName = st.nextToken();
/* 514:651 */         String unformattedName = formattedName.substring(1, formattedName.length() - 1);
/* 515:652 */         result[index] = unformattedName;
/* 516:    */       }
/* 517:655 */       return result;
/* 518:    */     }
/* 519:    */     
/* 520:    */     public String getTargetMobileMboAttribute()
/* 521:    */     {
/* 522:659 */       return this.targetMobileMboAttribute;
/* 523:    */     }
/* 524:    */     
/* 525:    */     public void setTargetMobileMboAttribute(String mobileMboAttribute)
/* 526:    */     {
/* 527:662 */       this.targetMobileMboAttribute = mobileMboAttribute;
/* 528:    */     }
/* 529:    */     
/* 530:    */     public String getSourceMobileMboAttribute()
/* 531:    */     {
/* 532:665 */       return this.sourceMobileMboAttribute;
/* 533:    */     }
/* 534:    */     
/* 535:    */     public void setSourceMobileMboAttribute(String keyAttribute)
/* 536:    */     {
/* 537:668 */       this.sourceMobileMboAttribute = keyAttribute;
/* 538:    */     }
/* 539:    */     
/* 540:    */     public String getTargetMobileMboName()
/* 541:    */     {
/* 542:671 */       return this.targetMobileMboName;
/* 543:    */     }
/* 544:    */     
/* 545:    */     public void setTargetMobileMboName(String mobileMboName)
/* 546:    */     {
/* 547:674 */       this.targetMobileMboName = mobileMboName;
/* 548:    */     }
/* 549:    */     
/* 550:    */     public String getSourceMobileMboName()
/* 551:    */     {
/* 552:677 */       return this.sourceMobileMboName;
/* 553:    */     }
/* 554:    */     
/* 555:    */     public void setSourceMobileMboName(String mobileMboName)
/* 556:    */     {
/* 557:680 */       this.sourceMobileMboName = mobileMboName;
/* 558:    */     }
/* 559:    */     
/* 560:    */     public int hashCode()
/* 561:    */     {
/* 562:684 */       int prime = 31;
/* 563:685 */       int result = 1;
/* 564:686 */       result = 31 * result + (this.children == null ? 0 : this.children.hashCode());
/* 565:    */       
/* 566:688 */       result = 31 * result + this.relationType;
/* 567:689 */       result = 31 * result + (this.sourceMobileMboAttribute == null ? 0 : this.sourceMobileMboAttribute.hashCode());
/* 568:    */       
/* 569:    */ 
/* 570:    */ 
/* 571:693 */       result = 31 * result + (this.sourceMobileMboName == null ? 0 : this.sourceMobileMboName.hashCode());
/* 572:    */       
/* 573:    */ 
/* 574:    */ 
/* 575:697 */       result = 31 * result + (this.targetMobileMboAttribute == null ? 0 : this.targetMobileMboAttribute.hashCode());
/* 576:    */       
/* 577:    */ 
/* 578:    */ 
/* 579:701 */       result = 31 * result + (this.targetMobileMboName == null ? 0 : this.targetMobileMboName.hashCode());
/* 580:    */       
/* 581:    */ 
/* 582:    */ 
/* 583:705 */       return result;
/* 584:    */     }
/* 585:    */     
/* 586:    */     public boolean equals(Object obj)
/* 587:    */     {
/* 588:709 */       if (this == obj) {
/* 589:710 */         return true;
/* 590:    */       }
/* 591:711 */       if (obj == null) {
/* 592:712 */         return false;
/* 593:    */       }
/* 594:713 */       if (!(obj instanceof DependentInfo)) {
/* 595:714 */         return false;
/* 596:    */       }
/* 597:715 */       DependentInfo other = (DependentInfo)obj;
/* 598:716 */       if (this.children == null)
/* 599:    */       {
/* 600:717 */         if (other.children != null) {
/* 601:718 */           return false;
/* 602:    */         }
/* 603:    */       }
/* 604:719 */       else if (!this.children.equals(other.children)) {
/* 605:720 */         return false;
/* 606:    */       }
/* 607:721 */       if (this.relationType != other.relationType) {
/* 608:722 */         return false;
/* 609:    */       }
/* 610:723 */       if (this.sourceMobileMboAttribute == null)
/* 611:    */       {
/* 612:724 */         if (other.sourceMobileMboAttribute != null) {
/* 613:725 */           return false;
/* 614:    */         }
/* 615:    */       }
/* 616:726 */       else if (!this.sourceMobileMboAttribute.equals(other.sourceMobileMboAttribute)) {
/* 617:728 */         return false;
/* 618:    */       }
/* 619:729 */       if (this.sourceMobileMboName == null)
/* 620:    */       {
/* 621:730 */         if (other.sourceMobileMboName != null) {
/* 622:731 */           return false;
/* 623:    */         }
/* 624:    */       }
/* 625:732 */       else if (!this.sourceMobileMboName.equals(other.sourceMobileMboName)) {
/* 626:733 */         return false;
/* 627:    */       }
/* 628:734 */       if (this.targetMobileMboAttribute == null)
/* 629:    */       {
/* 630:735 */         if (other.targetMobileMboAttribute != null) {
/* 631:736 */           return false;
/* 632:    */         }
/* 633:    */       }
/* 634:737 */       else if (!this.targetMobileMboAttribute.equals(other.targetMobileMboAttribute)) {
/* 635:739 */         return false;
/* 636:    */       }
/* 637:740 */       if (this.targetMobileMboName == null)
/* 638:    */       {
/* 639:741 */         if (other.targetMobileMboName != null) {
/* 640:742 */           return false;
/* 641:    */         }
/* 642:    */       }
/* 643:743 */       else if (!this.targetMobileMboName.equals(other.targetMobileMboName)) {
/* 644:744 */         return false;
/* 645:    */       }
/* 646:745 */       return true;
/* 647:    */     }
/* 648:    */     
/* 649:    */     public String toString()
/* 650:    */     {
/* 651:750 */       StringBuffer result = new StringBuffer();
/* 652:751 */       if (hasChildren()) {
/* 653:753 */         result.append("CHILDREN: ").append(this.children);
/* 654:    */       } else {
/* 655:757 */         result.append(getSourceMobileMboName()).append("@").append(getSourceMobileMboAttribute()).append(getRelationType() == 1 ? " => " : " <= ").append(getTargetMobileMboName()).append("@").append(getTargetMobileMboAttribute());
/* 656:    */       }
/* 657:766 */       return result.toString();
/* 658:    */     }
/* 659:    */   }
/* 660:    */   
/* 661:    */   private static class ComparableMobileMbo
/* 662:    */   {
/* 663:773 */     private MobileMbo mobileMbo = null;
/* 664:774 */     private String mobileMboName = null;
/* 665:775 */     private long mobileMboId = 0L;
/* 666:    */     
/* 667:    */     public ComparableMobileMbo(MobileMbo mobileMbo)
/* 668:    */       throws MobileApplicationException
/* 669:    */     {
/* 670:778 */       this.mobileMbo = mobileMbo;
/* 671:779 */       this.mobileMboName = mobileMbo.getName();
/* 672:780 */       this.mobileMboId = mobileMbo.getId();
/* 673:    */     }
/* 674:    */     
/* 675:    */     public MobileMbo getMobileMbo()
/* 676:    */     {
/* 677:783 */       return this.mobileMbo;
/* 678:    */     }
/* 679:    */     
/* 680:    */     public String getMobileMboName()
/* 681:    */     {
/* 682:787 */       return this.mobileMboName;
/* 683:    */     }
/* 684:    */     
/* 685:    */     public long getMobileMboId()
/* 686:    */     {
/* 687:791 */       return this.mobileMboId;
/* 688:    */     }
/* 689:    */     
/* 690:    */     public String toString()
/* 691:    */     {
/* 692:796 */       return this.mobileMboName + " (_ID=" + this.mobileMboId + ")";
/* 693:    */     }
/* 694:    */     
/* 695:    */     public int hashCode()
/* 696:    */     {
/* 697:801 */       int prime = 31;
/* 698:802 */       int result = 1;
/* 699:803 */       result = 31 * result + (int)(getMobileMboId() ^ getMobileMboId() >>> 32);
/* 700:    */       
/* 701:805 */       result = 31 * result + (getMobileMboName() == null ? 0 : getMobileMboName().hashCode());
/* 702:    */       
/* 703:807 */       return result;
/* 704:    */     }
/* 705:    */     
/* 706:    */     public boolean equals(Object obj)
/* 707:    */     {
/* 708:811 */       if (this == obj) {
/* 709:812 */         return true;
/* 710:    */       }
/* 711:813 */       if (obj == null) {
/* 712:814 */         return false;
/* 713:    */       }
/* 714:815 */       if (!(obj instanceof ComparableMobileMbo)) {
/* 715:816 */         return false;
/* 716:    */       }
/* 717:817 */       ComparableMobileMbo other = (ComparableMobileMbo)obj;
/* 718:818 */       if (getMobileMboId() != other.getMobileMboId()) {
/* 719:819 */         return false;
/* 720:    */       }
/* 721:820 */       if (getMobileMboName() == null)
/* 722:    */       {
/* 723:821 */         if (other.getMobileMboName() != null) {
/* 724:822 */           return false;
/* 725:    */         }
/* 726:    */       }
/* 727:823 */       else if (!getMobileMboName().equals(other.getMobileMboName())) {
/* 728:824 */         return false;
/* 729:    */       }
/* 730:825 */       return true;
/* 731:    */     }
/* 732:    */   }
/* 733:    */   
/* 734:    */   public static class RelationDisplayInfo
/* 735:    */   {
/* 736:832 */     private String recordNumAttr = null;
/* 737:833 */     private String recordDescAttr = null;
/* 738:834 */     private String pageIdToDisplay = null;
/* 739:835 */     private String mobileMboDataSrc = null;
/* 740:836 */     private String mobileMboNameToDisplay = null;
/* 741:    */     
/* 742:    */     public String getMobileMboNameToDisplay()
/* 743:    */     {
/* 744:839 */       return this.mobileMboNameToDisplay;
/* 745:    */     }
/* 746:    */     
/* 747:    */     public void setMobileMboNameToDisplay(String mobileMboNameToDisplay)
/* 748:    */     {
/* 749:843 */       this.mobileMboNameToDisplay = mobileMboNameToDisplay;
/* 750:    */     }
/* 751:    */     
/* 752:    */     public RelationDisplayInfo(String recordNumAttr, String recordDescAttr, String pageIdToDisplay, String mobileMboDataSrc, String mobileMboNameToDisplay)
/* 753:    */     {
/* 754:850 */       this.recordNumAttr = recordNumAttr;
/* 755:851 */       this.recordDescAttr = recordDescAttr;
/* 756:852 */       this.pageIdToDisplay = pageIdToDisplay;
/* 757:853 */       this.mobileMboDataSrc = mobileMboDataSrc;
/* 758:854 */       this.mobileMboNameToDisplay = mobileMboNameToDisplay;
/* 759:    */     }
/* 760:    */     
/* 761:    */     public String getMobileMboDataSrc()
/* 762:    */     {
/* 763:858 */       return this.mobileMboDataSrc;
/* 764:    */     }
/* 765:    */     
/* 766:    */     public void setMobileMboDataSrc(String mobileMboDataSrc)
/* 767:    */     {
/* 768:862 */       this.mobileMboDataSrc = mobileMboDataSrc;
/* 769:    */     }
/* 770:    */     
/* 771:    */     public String getRecordNumAttr()
/* 772:    */     {
/* 773:866 */       return this.recordNumAttr;
/* 774:    */     }
/* 775:    */     
/* 776:    */     public void setRecordNumAttr(String recordNumAttr)
/* 777:    */     {
/* 778:870 */       this.recordNumAttr = recordNumAttr;
/* 779:    */     }
/* 780:    */     
/* 781:    */     public String getRecordDescAttr()
/* 782:    */     {
/* 783:874 */       return this.recordDescAttr;
/* 784:    */     }
/* 785:    */     
/* 786:    */     public void setRecordDescAttr(String recordDescAttr)
/* 787:    */     {
/* 788:878 */       this.recordDescAttr = recordDescAttr;
/* 789:    */     }
/* 790:    */     
/* 791:    */     public String getPageIdToDisplay()
/* 792:    */     {
/* 793:882 */       return this.pageIdToDisplay;
/* 794:    */     }
/* 795:    */     
/* 796:    */     public void setPageIdToDisplay(String pageIdToDisplay)
/* 797:    */     {
/* 798:886 */       this.pageIdToDisplay = pageIdToDisplay;
/* 799:    */     }
/* 800:    */   }
/* 801:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.mbo.MobileMboDependencyManager
 * JD-Core Version:    0.7.0.1
 */