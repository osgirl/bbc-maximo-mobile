/*    1:     */ package com.mro.mobile.mbo;
/*    2:     */ 
/*    3:     */ import com.mro.mobile.MobileApplicationException;
/*    4:     */ import com.mro.mobile.persist.DefaultRDO;
/*    5:     */ import com.mro.mobile.persist.RDO;
/*    6:     */ import com.mro.mobile.persist.RDOException;
/*    7:     */ import com.mro.mobile.persist.RDOInfo;
/*    8:     */ import com.mro.mobile.persist.RDOSerializer;
/*    9:     */ import com.mro.mobile.persist.sql.MobileWhereClause;
/*   10:     */ import com.mro.mobile.type.Serializer;
/*   11:     */ import com.mro.mobile.type.TypeRegistry;
/*   12:     */ import com.mro.mobile.util.BitFlags;
/*   13:     */ import java.io.ByteArrayInputStream;
/*   14:     */ import java.io.ByteArrayOutputStream;
/*   15:     */ import java.io.DataInput;
/*   16:     */ import java.io.DataInputStream;
/*   17:     */ import java.io.DataOutput;
/*   18:     */ import java.io.DataOutputStream;
/*   19:     */ import java.io.IOException;
/*   20:     */ import java.util.Date;
/*   21:     */ import java.util.Enumeration;
/*   22:     */ import java.util.Hashtable;
/*   23:     */ import java.util.Vector;
/*   24:     */ 
/*   25:     */ public class MobileMbo
/*   26:     */   implements Serializer
/*   27:     */ {
/*   28:     */   private static final int TO_BE_INSERTED = 1;
/*   29:     */   private static final int TO_BE_UPDATED = 2;
/*   30:     */   private static final int TO_BE_DELETED = 3;
/*   31:     */   private static final int TO_BE_PROMPTEDFORESIG = 4;
/*   32:     */   private static final int CLOSED = 5;
/*   33:     */   private static final int SELECTED = 6;
/*   34:     */   public static final int READONLY = 1;
/*   35:     */   public static final int REQUIRED = 2;
/*   36:  57 */   private RDO rdo = null;
/*   37:  58 */   private Hashtable dependents = new Hashtable();
/*   38:  59 */   private Hashtable dependentsFetched = new Hashtable();
/*   39:  60 */   private MobileMbo owner = null;
/*   40:  62 */   private BitFlags internalFlags = new BitFlags(7);
/*   41:  67 */   private Vector readOnlyAttributes = null;
/*   42:     */   
/*   43:     */   private MobileMbo() {}
/*   44:     */   
/*   45:     */   public MobileMbo(RDO rdo)
/*   46:     */   {
/*   47:  75 */     this.rdo = rdo;
/*   48:     */   }
/*   49:     */   
/*   50:     */   public RDO getRDO()
/*   51:     */   {
/*   52:  80 */     return this.rdo;
/*   53:     */   }
/*   54:     */   
/*   55:     */   public String getAppName()
/*   56:     */   {
/*   57:  85 */     return this.rdo.getAppName();
/*   58:     */   }
/*   59:     */   
/*   60:     */   public String getName()
/*   61:     */   {
/*   62:  90 */     return this.rdo.getName();
/*   63:     */   }
/*   64:     */   
/*   65:     */   public String getDescription()
/*   66:     */   {
/*   67:  95 */     return getMobileMboInfo().getDescription();
/*   68:     */   }
/*   69:     */   
/*   70:     */   public String getAttributeDescription(String attributeName)
/*   71:     */   {
/*   72: 100 */     return getMobileMboInfo().getAttributeInfo(attributeName).getTitle();
/*   73:     */   }
/*   74:     */   
/*   75:     */   public MobileMboInfo getMobileMboInfo()
/*   76:     */   {
/*   77: 105 */     return MobileMboUtil.getMobileMboInfo(getAppName(), getName());
/*   78:     */   }
/*   79:     */   
/*   80:     */   public boolean isModified()
/*   81:     */     throws MobileApplicationException
/*   82:     */   {
/*   83: 110 */     MobileMboAttributeInfo modifiedAttrInfo = getMobileMboInfo().getAttributeInfo("_MODIFIED");
/*   84: 111 */     if (modifiedAttrInfo == null) {
/*   85: 113 */       return false;
/*   86:     */     }
/*   87: 116 */     return this.rdo.getBooleanValue("_MODIFIED");
/*   88:     */   }
/*   89:     */   
/*   90:     */   public void delete()
/*   91:     */     throws MobileApplicationException
/*   92:     */   {
/*   93: 121 */     if (isReadOnly()) {
/*   94: 123 */       throw new MobileApplicationException("readonly", new Object[] { getDescription() });
/*   95:     */     }
/*   96: 127 */     backupOriginal();
/*   97:     */     
/*   98: 129 */     this.rdo.setBooleanValue("_DELETED", true);
/*   99: 132 */     if (isNew()) {
/*  100: 134 */       this.internalFlags.set(3, true);
/*  101:     */     }
/*  102: 137 */     setToBeUpdated(true);
/*  103:     */   }
/*  104:     */   
/*  105:     */   public void undelete()
/*  106:     */     throws MobileApplicationException
/*  107:     */   {
/*  108: 142 */     if (isReadOnly()) {
/*  109: 144 */       throw new MobileApplicationException("readonly", new Object[] { getDescription() });
/*  110:     */     }
/*  111: 148 */     backupOriginal();
/*  112:     */     
/*  113: 150 */     this.rdo.setBooleanValue("_DELETED", false);
/*  114: 153 */     if (isNew()) {
/*  115: 155 */       this.internalFlags.set(3, false);
/*  116:     */     }
/*  117: 158 */     setToBeUpdated(true);
/*  118:     */   }
/*  119:     */   
/*  120:     */   public void deleteLocal()
/*  121:     */     throws MobileApplicationException
/*  122:     */   {
/*  123: 163 */     if (isReadOnly()) {
/*  124: 165 */       throw new MobileApplicationException("readonly", new Object[] { getDescription() });
/*  125:     */     }
/*  126: 169 */     backupOriginal();
/*  127:     */     
/*  128: 171 */     this.rdo.setBooleanValue("_DELETED", true);
/*  129: 172 */     this.internalFlags.set(3, true);
/*  130:     */   }
/*  131:     */   
/*  132:     */   public void undeleteLocal()
/*  133:     */     throws MobileApplicationException
/*  134:     */   {
/*  135: 177 */     if (isReadOnly()) {
/*  136: 179 */       throw new MobileApplicationException("readonly", new Object[] { getDescription() });
/*  137:     */     }
/*  138: 183 */     backupOriginal();
/*  139:     */     
/*  140: 185 */     this.rdo.setBooleanValue("_DELETED", false);
/*  141: 186 */     this.internalFlags.set(3, false);
/*  142:     */   }
/*  143:     */   
/*  144:     */   public boolean isDeleted()
/*  145:     */     throws MobileApplicationException
/*  146:     */   {
/*  147: 191 */     return this.rdo.getBooleanValue("_DELETED");
/*  148:     */   }
/*  149:     */   
/*  150:     */   public boolean isNew()
/*  151:     */     throws MobileApplicationException
/*  152:     */   {
/*  153: 196 */     return this.rdo.getBooleanValue("_NEW");
/*  154:     */   }
/*  155:     */   
/*  156:     */   public void setNew()
/*  157:     */     throws MobileApplicationException
/*  158:     */   {
/*  159: 201 */     if (isReadOnly()) {
/*  160: 203 */       throw new MobileApplicationException("readonly", new Object[] { getDescription() });
/*  161:     */     }
/*  162: 206 */     this.rdo.setBooleanValue("_NEW", true);
/*  163: 207 */     setToBeInserted(true);
/*  164:     */   }
/*  165:     */   
/*  166:     */   public void setToBeInserted(boolean toBeInserted)
/*  167:     */   {
/*  168: 212 */     this.internalFlags.set(1, toBeInserted);
/*  169:     */   }
/*  170:     */   
/*  171:     */   public boolean isToBeInserted()
/*  172:     */   {
/*  173: 217 */     return this.internalFlags.isSet(1);
/*  174:     */   }
/*  175:     */   
/*  176:     */   public void setToBeUpdated(boolean toBeUpdated)
/*  177:     */   {
/*  178: 222 */     this.internalFlags.set(2, toBeUpdated);
/*  179:     */   }
/*  180:     */   
/*  181:     */   public boolean isToBeUpdated()
/*  182:     */   {
/*  183: 227 */     return this.internalFlags.isSet(2);
/*  184:     */   }
/*  185:     */   
/*  186:     */   public void setToBeDeleted(boolean toBeDeleted)
/*  187:     */   {
/*  188: 232 */     this.internalFlags.set(3, toBeDeleted);
/*  189:     */   }
/*  190:     */   
/*  191:     */   public boolean isToBeDeleted()
/*  192:     */   {
/*  193: 237 */     return this.internalFlags.isSet(3);
/*  194:     */   }
/*  195:     */   
/*  196:     */   public boolean isSelected()
/*  197:     */   {
/*  198: 242 */     return this.internalFlags.isSet(6);
/*  199:     */   }
/*  200:     */   
/*  201:     */   public void select()
/*  202:     */   {
/*  203: 247 */     this.internalFlags.set(6, true);
/*  204:     */   }
/*  205:     */   
/*  206:     */   public void unselect()
/*  207:     */   {
/*  208: 252 */     this.internalFlags.set(6, false);
/*  209:     */   }
/*  210:     */   
/*  211:     */   public void close()
/*  212:     */   {
/*  213: 257 */     this.internalFlags.set(5, true);
/*  214:     */   }
/*  215:     */   
/*  216:     */   public boolean isClosed()
/*  217:     */   {
/*  218: 262 */     return this.internalFlags.isSet(5);
/*  219:     */   }
/*  220:     */   
/*  221:     */   public long getId()
/*  222:     */     throws MobileApplicationException
/*  223:     */   {
/*  224: 267 */     return this.rdo.getLongValue("_ID");
/*  225:     */   }
/*  226:     */   
/*  227:     */   public Enumeration getAttributeNames()
/*  228:     */   {
/*  229: 272 */     DefaultRDO drdo = (DefaultRDO)this.rdo;
/*  230:     */     
/*  231: 274 */     return drdo.getAttributeNames();
/*  232:     */   }
/*  233:     */   
/*  234:     */   public boolean isNull(String attributeName)
/*  235:     */     throws MobileApplicationException
/*  236:     */   {
/*  237: 279 */     return this.rdo.isNull(attributeName);
/*  238:     */   }
/*  239:     */   
/*  240:     */   public void setValue(String attributeName, String value)
/*  241:     */     throws MobileApplicationException
/*  242:     */   {
/*  243: 284 */     setValue(attributeName, value, true);
/*  244:     */   }
/*  245:     */   
/*  246:     */   public void setValue(String attributeName, String value, boolean accessCheck)
/*  247:     */     throws MobileApplicationException
/*  248:     */   {
/*  249: 289 */     String currentValue = this.rdo.getStringValue(attributeName);
/*  250: 290 */     if ((currentValue != null) && (currentValue.equals(value))) {
/*  251: 292 */       return;
/*  252:     */     }
/*  253: 295 */     MobileMboInfo mobileMboInfo = getMobileMboInfo();
/*  254:     */     
/*  255:     */ 
/*  256: 298 */     boolean persistentAttribute = mobileMboInfo.getAttributeInfo(attributeName).isPersistent();
/*  257: 299 */     if (persistentAttribute) {
/*  258: 301 */       if (accessCheck)
/*  259:     */       {
/*  260: 303 */         if (isReadOnly()) {
/*  261: 305 */           throw new MobileApplicationException("readonly", new Object[] { getDescription() });
/*  262:     */         }
/*  263: 308 */         if (isReadOnly(attributeName)) {
/*  264: 310 */           throw new MobileApplicationException("readonlyattr", new Object[] { getAttributeDescription(attributeName), getDescription() });
/*  265:     */         }
/*  266:     */       }
/*  267:     */     }
/*  268: 323 */     if (persistentAttribute) {
/*  269: 325 */       backupOriginal();
/*  270:     */     }
/*  271: 329 */     this.rdo.setStringValue(attributeName, value);
/*  272:     */     
/*  273:     */ 
/*  274: 332 */     setAttributeModified(attributeName);
/*  275:     */   }
/*  276:     */   
/*  277:     */   public String getValue(String attributeName)
/*  278:     */     throws MobileApplicationException
/*  279:     */   {
/*  280: 337 */     return this.rdo.getStringValue(attributeName);
/*  281:     */   }
/*  282:     */   
/*  283:     */   public void changeOriginalValue(String attributeName, String value)
/*  284:     */     throws MobileApplicationException
/*  285:     */   {
/*  286: 357 */     changeOriginalValueInternal(attributeName, value);
/*  287:     */   }
/*  288:     */   
/*  289:     */   public void changeOriginalBooleanValue(String attributeName, boolean value)
/*  290:     */     throws MobileApplicationException
/*  291:     */   {
/*  292: 378 */     changeOriginalValueInternal(attributeName, Boolean.valueOf(value));
/*  293:     */   }
/*  294:     */   
/*  295:     */   public void changeOriginalDateValue(String attributeName, Date value)
/*  296:     */     throws MobileApplicationException
/*  297:     */   {
/*  298: 398 */     changeOriginalValueInternal(attributeName, value);
/*  299:     */   }
/*  300:     */   
/*  301:     */   public void changeOriginalIntValue(String attributeName, int value)
/*  302:     */     throws MobileApplicationException
/*  303:     */   {
/*  304: 418 */     changeOriginalValueInternal(attributeName, new Integer(value));
/*  305:     */   }
/*  306:     */   
/*  307:     */   public void changeOriginalLongValue(String attributeName, long value)
/*  308:     */     throws MobileApplicationException
/*  309:     */   {
/*  310: 438 */     changeOriginalValueInternal(attributeName, new Long(value));
/*  311:     */   }
/*  312:     */   
/*  313:     */   public void changeOriginalBinaryValue(String attributeName, byte[] value)
/*  314:     */     throws MobileApplicationException
/*  315:     */   {
/*  316: 458 */     changeOriginalValueInternal(attributeName, value);
/*  317:     */   }
/*  318:     */   
/*  319:     */   private void changeOriginalValueInternal(String attributeName, Object value)
/*  320:     */     throws MobileApplicationException
/*  321:     */   {
/*  322: 478 */     RDO rdo = getRDO();
/*  323: 482 */     if ((!getMobileMboInfo().isWorkset()) && (!getMobileMboInfo().isLocalWorksetDownload())) {
/*  324: 485 */       return;
/*  325:     */     }
/*  326: 490 */     if (isNew()) {
/*  327: 492 */       return;
/*  328:     */     }
/*  329: 497 */     if (rdo.isNull("_ORIGINAL")) {
/*  330: 499 */       backupOriginal();
/*  331:     */     }
/*  332: 503 */     RDOSerializer rdoSerializer = new RDOSerializer();
/*  333:     */     
/*  334: 505 */     byte[] originalData = rdo.getBinaryValue("_ORIGINAL");
/*  335:     */     
/*  336: 507 */     RDO originalRDO = null;
/*  337:     */     
/*  338: 509 */     ByteArrayInputStream bis = new ByteArrayInputStream(originalData);
/*  339:     */     try
/*  340:     */     {
/*  341: 513 */       DataInputStream dis = new DataInputStream(bis);
/*  342:     */       
/*  343:     */ 
/*  344: 516 */       originalRDO = (RDO)rdoSerializer.readInstance(dis);
/*  345: 517 */       ((DefaultRDO)originalRDO).setPersistedData(true);
/*  346: 518 */       originalRDO.setBinaryValue("_ORIGINAL", null);
/*  347: 522 */       if ((value instanceof String)) {
/*  348: 524 */         originalRDO.setStringValue(attributeName, (String)value);
/*  349: 526 */       } else if ((value instanceof Integer)) {
/*  350: 528 */         originalRDO.setIntValue(attributeName, ((Integer)value).intValue());
/*  351: 530 */       } else if ((value instanceof Long)) {
/*  352: 532 */         originalRDO.setLongValue(attributeName, ((Long)value).longValue());
/*  353: 534 */       } else if ((value instanceof Date)) {
/*  354: 536 */         originalRDO.setDateValue(attributeName, (Date)value);
/*  355: 538 */       } else if ((value instanceof byte[])) {
/*  356: 540 */         originalRDO.setBinaryValue(attributeName, (byte[])value);
/*  357:     */       }
/*  358: 543 */       ByteArrayOutputStream bos = new ByteArrayOutputStream();
/*  359: 544 */       DataOutputStream dos = new DataOutputStream(bos);
/*  360:     */       
/*  361: 546 */       originalRDO.setBinaryValue("_ORIGINAL", null);
/*  362:     */       
/*  363:     */ 
/*  364: 549 */       rdoSerializer.writeInstance(dos, originalRDO, true);
/*  365: 550 */       dos.flush();
/*  366: 551 */       bos.flush();
/*  367:     */       
/*  368: 553 */       byte[] currentOriginalData = bos.toByteArray();
/*  369: 554 */       rdo.setBinaryValue("_ORIGINAL", currentOriginalData);
/*  370:     */     }
/*  371:     */     catch (Exception ex)
/*  372:     */     {
/*  373: 558 */       throw new MobileApplicationException("Failed to change original data.");
/*  374:     */     }
/*  375:     */   }
/*  376:     */   
/*  377:     */   private void backupOriginal()
/*  378:     */     throws MobileApplicationException
/*  379:     */   {
/*  380: 564 */     RDO rdo = getRDO();
/*  381: 568 */     if ((!getMobileMboInfo().isWorkset()) && (!getMobileMboInfo().isLocalWorksetDownload())) {
/*  382: 571 */       return;
/*  383:     */     }
/*  384: 576 */     if (isNew()) {
/*  385: 578 */       return;
/*  386:     */     }
/*  387: 584 */     if (!rdo.isNull("_ORIGINAL")) {
/*  388: 586 */       return;
/*  389:     */     }
/*  390: 590 */     RDOSerializer rdoSerializer = new RDOSerializer();
/*  391:     */     
/*  392: 592 */     ByteArrayOutputStream bos = new ByteArrayOutputStream();
/*  393:     */     try
/*  394:     */     {
/*  395: 596 */       DataOutputStream dos = new DataOutputStream(bos);
/*  396:     */       
/*  397: 598 */       rdo.setBinaryValue("_ORIGINAL", null);
/*  398:     */       
/*  399:     */ 
/*  400: 601 */       rdoSerializer.writeInstance(dos, rdo, true);
/*  401: 602 */       dos.flush();
/*  402: 603 */       bos.flush();
/*  403:     */       
/*  404: 605 */       byte[] originalData = bos.toByteArray();
/*  405: 606 */       rdo.setBinaryValue("_ORIGINAL", originalData);
/*  406:     */     }
/*  407:     */     catch (Exception ex)
/*  408:     */     {
/*  409: 610 */       throw new MobileApplicationException("Failed to copy original data.");
/*  410:     */     }
/*  411:     */   }
/*  412:     */   
/*  413:     */   public void restoreOriginal()
/*  414:     */     throws MobileApplicationException
/*  415:     */   {
/*  416: 616 */     RDO currentRdo = getRDO();
/*  417: 620 */     if ((!getMobileMboInfo().isWorkset()) && (!getMobileMboInfo().isLocalWorksetDownload())) {
/*  418: 623 */       return;
/*  419:     */     }
/*  420: 628 */     if (isNew()) {
/*  421: 630 */       return;
/*  422:     */     }
/*  423: 635 */     if (currentRdo.isNull("_ORIGINAL"))
/*  424:     */     {
/*  425: 637 */       if (isModified()) {
/*  426: 639 */         setModified(false);
/*  427:     */       }
/*  428: 642 */       return;
/*  429:     */     }
/*  430: 646 */     RDOSerializer rdoSerializer = new RDOSerializer();
/*  431:     */     
/*  432: 648 */     byte[] originalData = currentRdo.getBinaryValue("_ORIGINAL");
/*  433:     */     
/*  434: 650 */     ByteArrayInputStream bis = new ByteArrayInputStream(originalData);
/*  435:     */     try
/*  436:     */     {
/*  437: 654 */       DataInputStream dis = new DataInputStream(bis);
/*  438:     */       
/*  439:     */ 
/*  440: 657 */       this.rdo = ((RDO)rdoSerializer.readInstance(dis));
/*  441: 658 */       ((DefaultRDO)this.rdo).setPersistedData(true);
/*  442: 659 */       this.rdo.setBinaryValue("_ORIGINAL", null);
/*  443:     */       
/*  444: 661 */       setToBeUpdated(true);
/*  445:     */     }
/*  446:     */     catch (Exception ex)
/*  447:     */     {
/*  448: 665 */       throw new MobileApplicationException("Failed to copy original data.");
/*  449:     */     }
/*  450:     */   }
/*  451:     */   
/*  452:     */   public void setDateValue(String attributeName, Date value)
/*  453:     */     throws MobileApplicationException
/*  454:     */   {
/*  455: 671 */     setDateValue(attributeName, value, true);
/*  456:     */   }
/*  457:     */   
/*  458:     */   public void setDateValue(String attributeName, Date value, boolean accessCheck)
/*  459:     */     throws MobileApplicationException
/*  460:     */   {
/*  461: 676 */     MobileMboInfo mobileMboInfo = getMobileMboInfo();
/*  462:     */     
/*  463:     */ 
/*  464: 679 */     boolean persistentAttribute = mobileMboInfo.getAttributeInfo(attributeName).isPersistent();
/*  465: 680 */     if (persistentAttribute) {
/*  466: 682 */       if (accessCheck)
/*  467:     */       {
/*  468: 684 */         if (isReadOnly()) {
/*  469: 686 */           throw new MobileApplicationException("readonly", new Object[] { getDescription() });
/*  470:     */         }
/*  471: 689 */         if (isReadOnly(attributeName)) {
/*  472: 691 */           throw new MobileApplicationException("readonlyattr", new Object[] { getAttributeDescription(attributeName), getDescription() });
/*  473:     */         }
/*  474:     */       }
/*  475:     */     }
/*  476: 697 */     if (persistentAttribute) {
/*  477: 699 */       backupOriginal();
/*  478:     */     }
/*  479: 702 */     this.rdo.setDateValue(attributeName, value);
/*  480: 703 */     setAttributeModified(attributeName);
/*  481:     */   }
/*  482:     */   
/*  483:     */   public Date getDateValue(String attributeName)
/*  484:     */     throws MobileApplicationException
/*  485:     */   {
/*  486: 708 */     return this.rdo.getDateValue(attributeName);
/*  487:     */   }
/*  488:     */   
/*  489:     */   public void setBinaryValue(String attributeName, byte[] value)
/*  490:     */     throws MobileApplicationException
/*  491:     */   {
/*  492: 713 */     setBinaryValue(attributeName, value, true);
/*  493:     */   }
/*  494:     */   
/*  495:     */   public void setBinaryValue(String attributeName, byte[] value, boolean accessCheck)
/*  496:     */     throws MobileApplicationException
/*  497:     */   {
/*  498: 718 */     MobileMboInfo mobileMboInfo = getMobileMboInfo();
/*  499:     */     
/*  500:     */ 
/*  501: 721 */     boolean persistentAttribute = mobileMboInfo.getAttributeInfo(attributeName).isPersistent();
/*  502: 722 */     if (persistentAttribute) {
/*  503: 724 */       if (accessCheck)
/*  504:     */       {
/*  505: 726 */         if (isReadOnly()) {
/*  506: 728 */           throw new MobileApplicationException("readonly", new Object[] { getDescription() });
/*  507:     */         }
/*  508: 731 */         if (isReadOnly(attributeName)) {
/*  509: 733 */           throw new MobileApplicationException("readonlyattr", new Object[] { getAttributeDescription(attributeName), getDescription() });
/*  510:     */         }
/*  511:     */       }
/*  512:     */     }
/*  513: 739 */     if (persistentAttribute) {
/*  514: 741 */       backupOriginal();
/*  515:     */     }
/*  516: 744 */     this.rdo.setBinaryValue(attributeName, value);
/*  517: 745 */     setAttributeModified(attributeName);
/*  518:     */   }
/*  519:     */   
/*  520:     */   public byte[] getBinaryValue(String attributeName)
/*  521:     */     throws MobileApplicationException
/*  522:     */   {
/*  523: 750 */     return this.rdo.getBinaryValue(attributeName);
/*  524:     */   }
/*  525:     */   
/*  526:     */   public void setBooleanValue(String attributeName, boolean value, boolean accessCheck)
/*  527:     */     throws MobileApplicationException
/*  528:     */   {
/*  529: 755 */     MobileMboInfo mobileMboInfo = getMobileMboInfo();
/*  530:     */     
/*  531:     */ 
/*  532: 758 */     boolean persistentAttribute = mobileMboInfo.getAttributeInfo(attributeName).isPersistent();
/*  533: 759 */     if (persistentAttribute) {
/*  534: 761 */       if (accessCheck)
/*  535:     */       {
/*  536: 763 */         if (isReadOnly()) {
/*  537: 765 */           throw new MobileApplicationException("readonly", new Object[] { getDescription() });
/*  538:     */         }
/*  539: 768 */         if (isReadOnly(attributeName)) {
/*  540: 770 */           throw new MobileApplicationException("readonlyattr", new Object[] { getAttributeDescription(attributeName), getDescription() });
/*  541:     */         }
/*  542:     */       }
/*  543:     */     }
/*  544: 776 */     if (persistentAttribute) {
/*  545: 778 */       backupOriginal();
/*  546:     */     }
/*  547: 781 */     this.rdo.setBooleanValue(attributeName, value);
/*  548: 782 */     setAttributeModified(attributeName);
/*  549:     */   }
/*  550:     */   
/*  551:     */   public void setBooleanValue(String attributeName, boolean value)
/*  552:     */     throws MobileApplicationException
/*  553:     */   {
/*  554: 787 */     setBooleanValue(attributeName, value, true);
/*  555:     */   }
/*  556:     */   
/*  557:     */   public boolean getBooleanValue(String attributeName)
/*  558:     */     throws MobileApplicationException
/*  559:     */   {
/*  560: 792 */     return this.rdo.getBooleanValue(attributeName);
/*  561:     */   }
/*  562:     */   
/*  563:     */   public void setIntValue(String attributeName, int value, boolean accessCheck)
/*  564:     */     throws MobileApplicationException
/*  565:     */   {
/*  566: 797 */     MobileMboInfo mobileMboInfo = getMobileMboInfo();
/*  567:     */     
/*  568:     */ 
/*  569: 800 */     boolean persistentAttribute = mobileMboInfo.getAttributeInfo(attributeName).isPersistent();
/*  570: 801 */     if (persistentAttribute) {
/*  571: 803 */       if (accessCheck)
/*  572:     */       {
/*  573: 805 */         if (isReadOnly()) {
/*  574: 807 */           throw new MobileApplicationException("readonly", new Object[] { getDescription() });
/*  575:     */         }
/*  576: 810 */         if (isReadOnly(attributeName)) {
/*  577: 812 */           throw new MobileApplicationException("readonlyattr", new Object[] { getAttributeDescription(attributeName), getDescription() });
/*  578:     */         }
/*  579:     */       }
/*  580:     */     }
/*  581: 818 */     if (persistentAttribute) {
/*  582: 820 */       backupOriginal();
/*  583:     */     }
/*  584: 823 */     this.rdo.setIntValue(attributeName, value);
/*  585: 824 */     setAttributeModified(attributeName);
/*  586:     */   }
/*  587:     */   
/*  588:     */   public void setIntValue(String attributeName, int value)
/*  589:     */     throws MobileApplicationException
/*  590:     */   {
/*  591: 829 */     setIntValue(attributeName, value, true);
/*  592:     */   }
/*  593:     */   
/*  594:     */   public int getIntValue(String attributeName)
/*  595:     */     throws MobileApplicationException
/*  596:     */   {
/*  597: 834 */     return this.rdo.getIntValue(attributeName);
/*  598:     */   }
/*  599:     */   
/*  600:     */   public void setLongValue(String attributeName, long value, boolean accessCheck)
/*  601:     */     throws MobileApplicationException
/*  602:     */   {
/*  603: 839 */     MobileMboInfo mobileMboInfo = getMobileMboInfo();
/*  604:     */     
/*  605:     */ 
/*  606: 842 */     boolean persistentAttribute = mobileMboInfo.getAttributeInfo(attributeName).isPersistent();
/*  607: 843 */     if (persistentAttribute) {
/*  608: 845 */       if (accessCheck)
/*  609:     */       {
/*  610: 847 */         if (isReadOnly()) {
/*  611: 849 */           throw new MobileApplicationException("readonly", new Object[] { getDescription() });
/*  612:     */         }
/*  613: 852 */         if (isReadOnly(attributeName)) {
/*  614: 854 */           throw new MobileApplicationException("readonlyattr", new Object[] { getAttributeDescription(attributeName), getDescription() });
/*  615:     */         }
/*  616:     */       }
/*  617:     */     }
/*  618: 860 */     if (persistentAttribute) {
/*  619: 862 */       backupOriginal();
/*  620:     */     }
/*  621: 865 */     this.rdo.setLongValue(attributeName, value);
/*  622: 866 */     setAttributeModified(attributeName);
/*  623:     */   }
/*  624:     */   
/*  625:     */   public void setLongValue(String attributeName, long value)
/*  626:     */     throws MobileApplicationException
/*  627:     */   {
/*  628: 871 */     setLongValue(attributeName, value, true);
/*  629:     */   }
/*  630:     */   
/*  631:     */   public long getLongValue(String attributeName)
/*  632:     */     throws MobileApplicationException
/*  633:     */   {
/*  634: 876 */     return this.rdo.getLongValue(attributeName);
/*  635:     */   }
/*  636:     */   
/*  637:     */   public boolean isModified(String attributeName)
/*  638:     */     throws MobileApplicationException
/*  639:     */   {
/*  640: 881 */     byte[] data = this.rdo.getBinaryValue("_ATTRMODIFIED");
/*  641: 883 */     if (data == null) {
/*  642: 885 */       return false;
/*  643:     */     }
/*  644: 889 */     RDOInfo rdoInfo = this.rdo.getInfo();
/*  645: 890 */     int attrIndex = rdoInfo.getAttributeIndex(attributeName);
/*  646: 891 */     BitFlags modifiedFlags = new BitFlags(rdoInfo.getAttributeCount(), data);
/*  647: 892 */     boolean modified = modifiedFlags.isSet(attrIndex);
/*  648:     */     
/*  649: 894 */     return modified;
/*  650:     */   }
/*  651:     */   
/*  652:     */   private void setAttributeModified(String attributeName)
/*  653:     */     throws MobileApplicationException
/*  654:     */   {
/*  655: 899 */     MobileMboInfo mobileMboInfo = getMobileMboInfo();
/*  656: 903 */     if (mobileMboInfo.isLocalWorksetDownload())
/*  657:     */     {
/*  658: 905 */       if (!isToBeInserted()) {
/*  659: 907 */         this.internalFlags.set(2, true);
/*  660:     */       }
/*  661: 910 */       if (!isToBePromptedForESig()) {
/*  662: 912 */         if (getMobileMboInfo().getAttributeInfo(attributeName).isESigEnabled()) {
/*  663: 914 */           this.internalFlags.set(4, true);
/*  664:     */         }
/*  665:     */       }
/*  666: 918 */       return;
/*  667:     */     }
/*  668: 923 */     MobileMboAttributeInfo attrInfo = mobileMboInfo.getAttributeInfo(attributeName);
/*  669: 924 */     if (!attrInfo.isPersistent()) {
/*  670: 926 */       return;
/*  671:     */     }
/*  672: 929 */     if (attrInfo.isChangeTrackingEnabled())
/*  673:     */     {
/*  674: 931 */       BitFlags modifiedFlags = null;
/*  675:     */       
/*  676: 933 */       byte[] data = this.rdo.getBinaryValue("_ATTRMODIFIED");
/*  677: 934 */       RDOInfo rdoInfo = this.rdo.getInfo();
/*  678: 935 */       if (data == null) {
/*  679: 937 */         modifiedFlags = new BitFlags(rdoInfo.getAttributeCount());
/*  680:     */       } else {
/*  681: 941 */         modifiedFlags = new BitFlags(rdoInfo.getAttributeCount(), data);
/*  682:     */       }
/*  683: 944 */       int attrIndex = rdoInfo.getAttributeIndex(attributeName);
/*  684: 945 */       modifiedFlags.set(attrIndex);
/*  685: 946 */       data = modifiedFlags.getFlags();
/*  686: 947 */       this.rdo.setBinaryValue("_ATTRMODIFIED", data);
/*  687: 948 */       setModified(true);
/*  688:     */     }
/*  689: 957 */     if (!isToBeInserted()) {
/*  690: 959 */       this.internalFlags.set(2, true);
/*  691:     */     }
/*  692: 962 */     if (!isToBePromptedForESig()) {
/*  693: 964 */       if (getMobileMboInfo().getAttributeInfo(attributeName).isESigEnabled()) {
/*  694: 966 */         this.internalFlags.set(4, true);
/*  695:     */       }
/*  696:     */     }
/*  697:     */   }
/*  698:     */   
/*  699:     */   private void setModified(boolean modified)
/*  700:     */     throws MobileApplicationException
/*  701:     */   {
/*  702: 974 */     String readOnlyParent = getParentReadOnly(this);
/*  703: 975 */     if (readOnlyParent != null) {
/*  704: 976 */       throw new MobileApplicationException("readonly", new Object[] { readOnlyParent });
/*  705:     */     }
/*  706: 978 */     doSetModified(modified);
/*  707:     */   }
/*  708:     */   
/*  709:     */   private void doSetModified(boolean modified)
/*  710:     */     throws MobileApplicationException
/*  711:     */   {
/*  712: 983 */     MobileMboAttributeInfo modifiedAttrInfo = getMobileMboInfo().getAttributeInfo("_MODIFIED");
/*  713: 984 */     if (modifiedAttrInfo == null) {
/*  714: 986 */       return;
/*  715:     */     }
/*  716: 989 */     this.rdo.setBooleanValue("_MODIFIED", modified);
/*  717: 990 */     if (!isToBeInserted()) {
/*  718: 992 */       this.internalFlags.set(2, true);
/*  719:     */     }
/*  720: 995 */     if (getOwner() != null)
/*  721:     */     {
/*  722: 997 */       MobileMbo ownerMbo = getOwner();
/*  723: 998 */       ownerMbo.backupOriginal();
/*  724: 999 */       ownerMbo.doSetModified(true);
/*  725:     */     }
/*  726:     */   }
/*  727:     */   
/*  728:     */   private String getParentReadOnly(MobileMbo child)
/*  729:     */   {
/*  730:1005 */     if (child == null) {
/*  731:1005 */       return null;
/*  732:     */     }
/*  733:1006 */     if ((child.isReadOnly()) && ((child.getMobileMboInfo().isWorkset()) || (child.getMobileMboInfo().isLocalWorksetUpload()))) {
/*  734:1009 */       return child.getDescription();
/*  735:     */     }
/*  736:1011 */     return getParentReadOnly(child.getOwner());
/*  737:     */   }
/*  738:     */   
/*  739:     */   public boolean isToBePromptedForESig()
/*  740:     */   {
/*  741:1016 */     return this.internalFlags.isSet(4);
/*  742:     */   }
/*  743:     */   
/*  744:     */   public boolean isToBeSaved()
/*  745:     */   {
/*  746:1021 */     if (isReadOnly())
/*  747:     */     {
/*  748:1029 */       if (isToBeUpdated()) {
/*  749:1031 */         return true;
/*  750:     */       }
/*  751:1034 */       return false;
/*  752:     */     }
/*  753:1037 */     if ((isToBeInserted()) || (isToBeUpdated()) || (isToBeDeleted())) {
/*  754:1039 */       return true;
/*  755:     */     }
/*  756:1042 */     return false;
/*  757:     */   }
/*  758:     */   
/*  759:     */   public void setFlag(int flagIndex, boolean state)
/*  760:     */   {
/*  761:1056 */     this.rdo.setFlag(flagIndex, state);
/*  762:     */   }
/*  763:     */   
/*  764:     */   public void setReadOnly(boolean readOnly)
/*  765:     */   {
/*  766:1061 */     this.rdo.setFlag(1, readOnly);
/*  767:     */   }
/*  768:     */   
/*  769:     */   public boolean isReadOnly()
/*  770:     */   {
/*  771:1066 */     MobileMboInfo mmInfo = getMobileMboInfo();
/*  772:1068 */     if (mmInfo.isReadOnly()) {
/*  773:1070 */       return true;
/*  774:     */     }
/*  775:     */     try
/*  776:     */     {
/*  777:1075 */       if (!this.rdo.isNull("_READONLY")) {
/*  778:1077 */         if (this.rdo.getBooleanValue("_READONLY")) {
/*  779:1079 */           return true;
/*  780:     */         }
/*  781:     */       }
/*  782:     */     }
/*  783:     */     catch (RDOException e) {}
/*  784:1087 */     boolean readOnly = this.rdo.isFlagSet(1);
/*  785:1088 */     if (readOnly) {
/*  786:1090 */       return true;
/*  787:     */     }
/*  788:1096 */     if ((mmInfo.getParent() != null) && (mmInfo.getMobileMboName() == null))
/*  789:     */     {
/*  790:1098 */       MobileMbo ownerMbo = getOwner();
/*  791:1100 */       if (ownerMbo != null) {
/*  792:1102 */         return ownerMbo.isReadOnly();
/*  793:     */       }
/*  794:     */     }
/*  795:1106 */     return false;
/*  796:     */   }
/*  797:     */   
/*  798:     */   public void setReadOnly(String attribute, boolean readOnly)
/*  799:     */   {
/*  800:1111 */     this.rdo.setFlag(attribute, 1, readOnly);
/*  801:     */   }
/*  802:     */   
/*  803:     */   public boolean isReadOnly(String attribute)
/*  804:     */     throws MobileApplicationException
/*  805:     */   {
/*  806:1116 */     MobileMboInfo mmInfo = getMobileMboInfo();
/*  807:1118 */     if (mmInfo.isReadOnly()) {
/*  808:1120 */       return true;
/*  809:     */     }
/*  810:1123 */     MobileMboAttributeInfo mmAttrInfo = mmInfo.getAttributeInfo(attribute);
/*  811:1125 */     if (mmAttrInfo == null) {
/*  812:1126 */       return true;
/*  813:     */     }
/*  814:1129 */     if (mmAttrInfo.isReadOnly()) {
/*  815:1131 */       return true;
/*  816:     */     }
/*  817:1138 */     if ((mmInfo.isWorkset()) || (mmInfo.isLocalWorksetDownload()))
/*  818:     */     {
/*  819:1140 */       if (this.readOnlyAttributes == null)
/*  820:     */       {
/*  821:1142 */         this.readOnlyAttributes = new Vector();
/*  822:1144 */         if (!this.rdo.isNull("_READONLYATTRS"))
/*  823:     */         {
/*  824:1146 */           byte[] readOnlyAttrData = this.rdo.getBinaryValue("_READONLYATTRS");
/*  825:1147 */           ByteArrayInputStream bis = new ByteArrayInputStream(readOnlyAttrData);
/*  826:1148 */           DataInputStream dis = new DataInputStream(bis);
/*  827:     */           try
/*  828:     */           {
/*  829:1153 */             int noOfReadOnlyAttributes = dis.readInt();
/*  830:1154 */             for (int i = 0; i < noOfReadOnlyAttributes; i++)
/*  831:     */             {
/*  832:1156 */               String readOnlyAttributeName = dis.readUTF();
/*  833:1157 */               this.readOnlyAttributes.addElement(readOnlyAttributeName);
/*  834:     */             }
/*  835:     */           }
/*  836:     */           catch (IOException e) {}
/*  837:     */         }
/*  838:     */       }
/*  839:1167 */       int noOfReadOnlyAttributes = this.readOnlyAttributes.size();
/*  840:1168 */       for (int i = 0; i < noOfReadOnlyAttributes; i++)
/*  841:     */       {
/*  842:1170 */         String readOnlyAttributeName = (String)this.readOnlyAttributes.elementAt(i);
/*  843:1171 */         if (readOnlyAttributeName.equals(attribute)) {
/*  844:1173 */           return true;
/*  845:     */         }
/*  846:     */       }
/*  847:     */     }
/*  848:1178 */     return this.rdo.isFlagSet(attribute, 1);
/*  849:     */   }
/*  850:     */   
/*  851:     */   public void resetReadOnlyAttributesCache()
/*  852:     */   {
/*  853:1183 */     this.readOnlyAttributes = null;
/*  854:     */   }
/*  855:     */   
/*  856:     */   public void setRequired(String attribute, boolean required)
/*  857:     */   {
/*  858:1188 */     this.rdo.setFlag(attribute, 2, required);
/*  859:     */   }
/*  860:     */   
/*  861:     */   public boolean isRequired(String attribute)
/*  862:     */   {
/*  863:1193 */     if (attribute == null) {
/*  864:1195 */       return false;
/*  865:     */     }
/*  866:1198 */     return this.rdo.isFlagSet(attribute, 2);
/*  867:     */   }
/*  868:     */   
/*  869:     */   public MobileMbo getOwner()
/*  870:     */   {
/*  871:1203 */     return this.owner;
/*  872:     */   }
/*  873:     */   
/*  874:     */   public void setOwner(MobileMbo owner)
/*  875:     */   {
/*  876:1208 */     this.owner = owner;
/*  877:     */   }
/*  878:     */   
/*  879:     */   public MobileMbo createDependent(String name)
/*  880:     */     throws MobileApplicationException
/*  881:     */   {
/*  882:1213 */     Vector vec = null;
/*  883:     */     
/*  884:1215 */     Object obj = this.dependents.get(name);
/*  885:1216 */     if (obj == null)
/*  886:     */     {
/*  887:1218 */       vec = new Vector();
/*  888:1219 */       this.dependents.put(name, vec);
/*  889:     */     }
/*  890:     */     else
/*  891:     */     {
/*  892:1223 */       vec = (Vector)obj;
/*  893:     */     }
/*  894:1226 */     RDO newRDO = this.rdo.createDependent(name);
/*  895:1227 */     MobileMbo newMobileMbo = new MobileMbo(newRDO);
/*  896:1228 */     newMobileMbo.setOwner(this);
/*  897:     */     
/*  898:1230 */     vec.addElement(newMobileMbo);
/*  899:1231 */     return newMobileMbo;
/*  900:     */   }
/*  901:     */   
/*  902:     */   public void replaceDependent(String name, MobileMbo curDependentMbo, MobileMbo newDependentMbo)
/*  903:     */     throws MobileApplicationException
/*  904:     */   {
/*  905:1237 */     Vector vec = null;
/*  906:     */     
/*  907:1239 */     Object obj = this.dependents.get(name);
/*  908:1240 */     if (obj == null) {
/*  909:1242 */       return;
/*  910:     */     }
/*  911:1246 */     vec = (Vector)obj;
/*  912:     */     
/*  913:     */ 
/*  914:1249 */     int index = vec.indexOf(curDependentMbo);
/*  915:1250 */     vec.setElementAt(newDependentMbo, index);
/*  916:     */     
/*  917:1252 */     DefaultRDO newDependentRDO = (DefaultRDO)newDependentMbo.getRDO();
/*  918:1253 */     DefaultRDO thisRDO = (DefaultRDO)this.rdo;
/*  919:1254 */     thisRDO.replaceDependent(name, curDependentMbo.getRDO(), newDependentRDO);
/*  920:     */   }
/*  921:     */   
/*  922:     */   public void addDependent(String name, MobileMbo dependentMbo)
/*  923:     */     throws MobileApplicationException
/*  924:     */   {
/*  925:1259 */     if (isReadOnly()) {
/*  926:1261 */       throw new MobileApplicationException("readonly", new Object[] { getDescription() });
/*  927:     */     }
/*  928:1266 */     Vector vec = null;
/*  929:     */     
/*  930:1268 */     Object obj = this.dependents.get(name);
/*  931:1269 */     if (obj == null)
/*  932:     */     {
/*  933:1271 */       vec = new Vector();
/*  934:1272 */       this.dependents.put(name, vec);
/*  935:     */     }
/*  936:     */     else
/*  937:     */     {
/*  938:1276 */       vec = (Vector)obj;
/*  939:     */     }
/*  940:1279 */     dependentMbo.setOwner(this);
/*  941:     */     
/*  942:1281 */     vec.addElement(dependentMbo);
/*  943:     */   }
/*  944:     */   
/*  945:     */   public void removeDependent(String name, MobileMbo mbo)
/*  946:     */     throws MobileApplicationException
/*  947:     */   {
/*  948:1286 */     if (isReadOnly()) {
/*  949:1288 */       throw new MobileApplicationException("readonly", new Object[] { getDescription() });
/*  950:     */     }
/*  951:1291 */     this.rdo.removeDependent(name, mbo.getRDO());
/*  952:     */     
/*  953:1293 */     Vector vec = null;
/*  954:1294 */     Object obj = this.dependents.get(name);
/*  955:1295 */     if (obj == null) {
/*  956:1297 */       return;
/*  957:     */     }
/*  958:1300 */     vec = (Vector)obj;
/*  959:1302 */     if (mbo.isNew()) {
/*  960:1304 */       vec.removeElement(mbo);
/*  961:     */     }
/*  962:     */   }
/*  963:     */   
/*  964:     */   public void resetDependents()
/*  965:     */     throws MobileApplicationException
/*  966:     */   {
/*  967:1315 */     this.dependents = new Hashtable();
/*  968:1316 */     this.dependentsFetched = new Hashtable();
/*  969:1317 */     this.rdo.resetDependents();
/*  970:     */   }
/*  971:     */   
/*  972:     */   public void resetDependent(String dependentName)
/*  973:     */     throws MobileApplicationException
/*  974:     */   {
/*  975:1322 */     this.dependents.remove(dependentName);
/*  976:1323 */     this.dependentsFetched.remove(dependentName);
/*  977:1324 */     this.rdo.resetDependent(dependentName);
/*  978:     */   }
/*  979:     */   
/*  980:     */   public Enumeration getDependents(String dependentName)
/*  981:     */     throws MobileApplicationException
/*  982:     */   {
/*  983:1330 */     return getDependents(dependentName, null, null);
/*  984:     */   }
/*  985:     */   
/*  986:     */   public Enumeration getDependents(String dependentName, MobileMboQBE qbe, MobileMboOrder order)
/*  987:     */     throws MobileApplicationException
/*  988:     */   {
/*  989:1336 */     return getDependents(dependentName, qbe, null, order);
/*  990:     */   }
/*  991:     */   
/*  992:     */   public Enumeration getDependents(String dependentName, MobileMboQBE qbe, MobileWhereClause whereClause, MobileMboOrder order)
/*  993:     */     throws MobileApplicationException
/*  994:     */   {
/*  995:1341 */     Vector vec = null;
/*  996:     */     
/*  997:1343 */     Object obj = this.dependents.get(dependentName);
/*  998:1344 */     if (obj == null)
/*  999:     */     {
/* 1000:1346 */       vec = new Vector();
/* 1001:1347 */       this.dependents.put(dependentName, vec);
/* 1002:     */     }
/* 1003:     */     else
/* 1004:     */     {
/* 1005:1351 */       vec = (Vector)obj;
/* 1006:     */     }
/* 1007:1354 */     if (!isDependentDataFetched(dependentName))
/* 1008:     */     {
/* 1009:1356 */       Enumeration rdoEnum = this.rdo.getDependents(dependentName, qbe, whereClause, order);
/* 1010:1357 */       while (rdoEnum.hasMoreElements())
/* 1011:     */       {
/* 1012:1359 */         RDO rdo = (RDO)rdoEnum.nextElement();
/* 1013:1360 */         MobileMbo dependentMbo = new MobileMbo(rdo);
/* 1014:     */         
/* 1015:     */ 
/* 1016:1363 */         dependentMbo.setOwner(this);
/* 1017:     */         
/* 1018:1365 */         vec.addElement(dependentMbo);
/* 1019:     */       }
/* 1020:1368 */       setDependentDataFetched(dependentName);
/* 1021:     */     }
/* 1022:1371 */     return vec.elements();
/* 1023:     */   }
/* 1024:     */   
/* 1025:     */   public int getDependentSize(String name)
/* 1026:     */     throws MobileApplicationException
/* 1027:     */   {
/* 1028:1377 */     return this.rdo.getDependentSize(name);
/* 1029:     */   }
/* 1030:     */   
/* 1031:     */   public int getDependentSize(String name, MobileMboQBE qbe)
/* 1032:     */     throws MobileApplicationException
/* 1033:     */   {
/* 1034:1382 */     return this.rdo.getDependentSize(name, qbe);
/* 1035:     */   }
/* 1036:     */   
/* 1037:     */   public int getDependentSize(String name, MobileMboQBE qbe, MobileWhereClause whereClause)
/* 1038:     */   {
/* 1039:1387 */     return this.rdo.getDependentSize(name, qbe, whereClause);
/* 1040:     */   }
/* 1041:     */   
/* 1042:     */   private boolean isDependentDataFetched(String name)
/* 1043:     */   {
/* 1044:1392 */     if (isClosed()) {
/* 1045:1394 */       return true;
/* 1046:     */     }
/* 1047:1397 */     Object obj = this.dependentsFetched.get(name);
/* 1048:1398 */     if (obj != null) {
/* 1049:1400 */       return true;
/* 1050:     */     }
/* 1051:1403 */     return false;
/* 1052:     */   }
/* 1053:     */   
/* 1054:     */   public void setDependentDataFetched(String name)
/* 1055:     */   {
/* 1056:1408 */     this.dependentsFetched.put(name, name);
/* 1057:1409 */     ((DefaultRDO)this.rdo).setDependentDataFetched(name);
/* 1058:     */   }
/* 1059:     */   
/* 1060:     */   public static void initSerializer()
/* 1061:     */   {
/* 1062:1418 */     MobileMbo i = new MobileMbo();
/* 1063:1419 */     TypeRegistry.getTypeRegistry().addType("MobileMbo", i.getClass(), i);
/* 1064:1420 */     TypeRegistry.getTypeRegistry().addType("MobileMbo[]", new MobileMbo[0].getClass(), i);
/* 1065:     */   }
/* 1066:     */   
/* 1067:     */   public Object readInstance(DataInput input, String name)
/* 1068:     */     throws IOException
/* 1069:     */   {
/* 1070:1428 */     if (name.equals("MobileMbo"))
/* 1071:     */     {
/* 1072:1430 */       RDOSerializer rdoSerializer = new RDOSerializer();
/* 1073:1431 */       RDO rdo = (RDO)rdoSerializer.readInstance(input);
/* 1074:     */       
/* 1075:1433 */       return new MobileMbo(rdo);
/* 1076:     */     }
/* 1077:1435 */     if (name.equals("MobileMbo[]"))
/* 1078:     */     {
/* 1079:1437 */       int arraySize = input.readInt();
/* 1080:1438 */       MobileMbo[] array = new MobileMbo[arraySize];
/* 1081:1439 */       for (int i = 0; i < arraySize; i++)
/* 1082:     */       {
/* 1083:1441 */         String arrayElementType = input.readUTF();
/* 1084:1442 */         array[i] = ((MobileMbo)readInstance(input, arrayElementType));
/* 1085:     */       }
/* 1086:1444 */       return array;
/* 1087:     */     }
/* 1088:1447 */     throw new RuntimeException("The type " + name + " not supported.");
/* 1089:     */   }
/* 1090:     */   
/* 1091:     */   public void writeInstance(DataOutput output, Object obj)
/* 1092:     */     throws IOException
/* 1093:     */   {
/* 1094:1455 */     if ((obj instanceof MobileMbo))
/* 1095:     */     {
/* 1096:1457 */       RDOSerializer rdoSerializer = new RDOSerializer();
/* 1097:1458 */       MobileMbo mobileMbo = (MobileMbo)obj;
/* 1098:1459 */       rdoSerializer.writeInstance(output, mobileMbo.getRDO());
/* 1099:     */     }
/* 1100:1461 */     else if (obj.getClass().isArray())
/* 1101:     */     {
/* 1102:1463 */       MobileMbo[] array = (MobileMbo[])obj;
/* 1103:     */       
/* 1104:1465 */       output.writeInt(array.length);
/* 1105:1466 */       for (int i = 0; i < array.length; i++)
/* 1106:     */       {
/* 1107:1468 */         output.writeUTF(TypeRegistry.getTypeRegistry().getTypeInfo(array[i]));
/* 1108:1469 */         writeInstance(output, array[i]);
/* 1109:     */       }
/* 1110:     */     }
/* 1111:     */   }
/* 1112:     */   
/* 1113:     */   public MobileMbo simpleClone()
/* 1114:     */   {
/* 1115:1477 */     MobileMbo cloneMbo = null;
/* 1116:     */     
/* 1117:1479 */     DefaultRDO cRdo = (DefaultRDO)this.rdo;
/* 1118:     */     
/* 1119:1481 */     DefaultRDO cloneRdo = cRdo.simpleClone();
/* 1120:     */     
/* 1121:1483 */     cloneMbo = new MobileMbo(cloneRdo);
/* 1122:1484 */     cloneMbo.setOwner(this.owner);
/* 1123:     */     
/* 1124:1486 */     int flagSize = this.internalFlags.getSize();
/* 1125:1487 */     for (int i = 0; i < flagSize; i++) {
/* 1126:1489 */       if (this.internalFlags.isSet(i)) {
/* 1127:1491 */         cloneMbo.internalFlags.set(i);
/* 1128:     */       }
/* 1129:     */     }
/* 1130:1495 */     return cloneMbo;
/* 1131:     */   }
/* 1132:     */   
/* 1133:     */   public void copyAttributeValue(MobileMbo destMbo, String attributeName)
/* 1134:     */     throws MobileApplicationException
/* 1135:     */   {
/* 1136:1501 */     DefaultRDO sourceRDO = (DefaultRDO)getRDO();
/* 1137:1502 */     DefaultRDO destRDO = (DefaultRDO)destMbo.getRDO();
/* 1138:     */     
/* 1139:1504 */     sourceRDO.copyAttributeValue(destRDO, attributeName);
/* 1140:1505 */     if (!isReadOnly(attributeName)) {
/* 1141:1507 */       destMbo.setAttributeModified(attributeName);
/* 1142:     */     }
/* 1143:     */   }
/* 1144:     */   
/* 1145:     */   public void setDoubleValue(String attributeName, double value, boolean accessCheck)
/* 1146:     */     throws MobileApplicationException
/* 1147:     */   {
/* 1148:1513 */     MobileMboInfo mobileMboInfo = getMobileMboInfo();
/* 1149:     */     
/* 1150:     */ 
/* 1151:1516 */     boolean persistentAttribute = mobileMboInfo.getAttributeInfo(attributeName).isPersistent();
/* 1152:1517 */     if (persistentAttribute) {
/* 1153:1519 */       if (accessCheck)
/* 1154:     */       {
/* 1155:1521 */         if (isReadOnly()) {
/* 1156:1523 */           throw new MobileApplicationException("readonly", new Object[] { getDescription() });
/* 1157:     */         }
/* 1158:1526 */         if (isReadOnly(attributeName)) {
/* 1159:1528 */           throw new MobileApplicationException("readonlyattr", new Object[] { getAttributeDescription(attributeName), getDescription() });
/* 1160:     */         }
/* 1161:     */       }
/* 1162:     */     }
/* 1163:1534 */     if (persistentAttribute) {
/* 1164:1536 */       backupOriginal();
/* 1165:     */     }
/* 1166:1539 */     this.rdo.setDoubleValue(attributeName, value);
/* 1167:1540 */     setAttributeModified(attributeName);
/* 1168:     */   }
/* 1169:     */   
/* 1170:     */   public void setDoubleValue(String attributeName, double value)
/* 1171:     */     throws MobileApplicationException
/* 1172:     */   {
/* 1173:1545 */     setDoubleValue(attributeName, value, true);
/* 1174:     */   }
/* 1175:     */   
/* 1176:     */   public double getDoubleValue(String attributeName)
/* 1177:     */     throws MobileApplicationException
/* 1178:     */   {
/* 1179:1550 */     return this.rdo.getDoubleValue(attributeName);
/* 1180:     */   }
/* 1181:     */   
/* 1182:     */   public void setFloatValue(String attributeName, float value, boolean accessCheck)
/* 1183:     */     throws MobileApplicationException
/* 1184:     */   {
/* 1185:1555 */     MobileMboInfo mobileMboInfo = getMobileMboInfo();
/* 1186:     */     
/* 1187:     */ 
/* 1188:1558 */     boolean persistentAttribute = mobileMboInfo.getAttributeInfo(attributeName).isPersistent();
/* 1189:1559 */     if (persistentAttribute) {
/* 1190:1561 */       if (accessCheck)
/* 1191:     */       {
/* 1192:1563 */         if (isReadOnly()) {
/* 1193:1565 */           throw new MobileApplicationException("readonly", new Object[] { getDescription() });
/* 1194:     */         }
/* 1195:1568 */         if (isReadOnly(attributeName)) {
/* 1196:1570 */           throw new MobileApplicationException("readonlyattr", new Object[] { getAttributeDescription(attributeName), getDescription() });
/* 1197:     */         }
/* 1198:     */       }
/* 1199:     */     }
/* 1200:1576 */     if (persistentAttribute) {
/* 1201:1578 */       backupOriginal();
/* 1202:     */     }
/* 1203:1581 */     this.rdo.setFloatValue(attributeName, value);
/* 1204:1582 */     setAttributeModified(attributeName);
/* 1205:     */   }
/* 1206:     */   
/* 1207:     */   public void setFloatValue(String attributeName, float value)
/* 1208:     */     throws MobileApplicationException
/* 1209:     */   {
/* 1210:1587 */     setFloatValue(attributeName, value, true);
/* 1211:     */   }
/* 1212:     */   
/* 1213:     */   public float getFloatValue(String attributeName)
/* 1214:     */     throws MobileApplicationException
/* 1215:     */   {
/* 1216:1592 */     return this.rdo.getFloatValue(attributeName);
/* 1217:     */   }
/* 1218:     */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.mbo.MobileMbo
 * JD-Core Version:    0.7.0.1
 */