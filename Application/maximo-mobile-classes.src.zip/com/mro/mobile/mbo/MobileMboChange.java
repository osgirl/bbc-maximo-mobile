/*   1:    */ package com.mro.mobile.mbo;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.persist.RDO;
/*   5:    */ import com.mro.mobile.persist.RDOSerializer;
/*   6:    */ import com.mro.mobile.type.Serializer;
/*   7:    */ import com.mro.mobile.type.TypeRegistry;
/*   8:    */ import com.mro.mobile.util.MobileLogger;
/*   9:    */ import com.mro.mobile.util.MobileLoggerFactory;
/*  10:    */ import java.io.ByteArrayOutputStream;
/*  11:    */ import java.io.DataInput;
/*  12:    */ import java.io.DataOutput;
/*  13:    */ import java.io.DataOutputStream;
/*  14:    */ import java.io.IOException;
/*  15:    */ import java.util.Enumeration;
/*  16:    */ 
/*  17:    */ public class MobileMboChange
/*  18:    */   implements Serializer
/*  19:    */ {
/*  20:    */   public static final int CHANGETYPE_NEW = 1;
/*  21:    */   public static final int CHANGETYPE_UPDATE = 2;
/*  22:    */   public static final int CHANGETYPE_DELETE = 3;
/*  23: 40 */   private MobileMbo mobileMbo = null;
/*  24: 44 */   private boolean ignoreDependentChanges = false;
/*  25:    */   
/*  26:    */   private MobileMboChange() {}
/*  27:    */   
/*  28:    */   public MobileMboChange(MobileMbo mobileMbo)
/*  29:    */     throws MobileApplicationException
/*  30:    */   {
/*  31: 54 */     MobileMboInfo mobileMboInfo = mobileMbo.getMobileMboInfo();
/*  32: 56 */     if ((!mobileMboInfo.isWorkset()) && (!mobileMboInfo.isLocalWorkset()) && (!mobileMboInfo.isLocalWorksetUpload())) {
/*  33: 58 */       throw new MobileApplicationException("invalidmobilembochangeparam");
/*  34:    */     }
/*  35: 61 */     this.mobileMbo = mobileMbo;
/*  36:    */   }
/*  37:    */   
/*  38:    */   public MobileMboChange(MobileMbo mobileMbo, boolean ignoreDependentChanges)
/*  39:    */     throws MobileApplicationException
/*  40:    */   {
/*  41: 67 */     this(mobileMbo);
/*  42: 68 */     this.ignoreDependentChanges = ignoreDependentChanges;
/*  43:    */   }
/*  44:    */   
/*  45:    */   public MobileMbo getMobileMbo()
/*  46:    */   {
/*  47: 73 */     return this.mobileMbo;
/*  48:    */   }
/*  49:    */   
/*  50:    */   public static void initSerializer()
/*  51:    */   {
/*  52: 79 */     MobileMboChange i = new MobileMboChange();
/*  53: 80 */     TypeRegistry.getTypeRegistry().addType("MobileMboChange", i.getClass(), i);
/*  54:    */   }
/*  55:    */   
/*  56:    */   public Object readInstance(DataInput input, String name)
/*  57:    */     throws IOException
/*  58:    */   {
/*  59: 85 */     MobileMboChange mboChange = null;
/*  60:    */     try
/*  61:    */     {
/*  62: 89 */       if (name.equals("MobileMboChange"))
/*  63:    */       {
/*  64: 91 */         mboChange = new MobileMboChange();
/*  65:    */         
/*  66: 93 */         int changeType = input.readInt();
/*  67: 95 */         if (changeType == 3) {
/*  68: 97 */           return mboChange;
/*  69:    */         }
/*  70:100 */         mboChange.mobileMbo = ((MobileMbo)readMobileMboChangeInstance(input));
/*  71:    */       }
/*  72:    */     }
/*  73:    */     catch (Exception e)
/*  74:    */     {
/*  75:105 */       MobileLoggerFactory.getDefaultLogger().warn("Failed to read MobileMboChange", e);
/*  76:106 */       throw new IOException("Failed to read MobileMboChange");
/*  77:    */     }
/*  78:109 */     return mboChange;
/*  79:    */   }
/*  80:    */   
/*  81:    */   public void writeInstance(DataOutput output, Object obj)
/*  82:    */     throws IOException
/*  83:    */   {
/*  84:    */     try
/*  85:    */     {
/*  86:116 */       if ((obj instanceof MobileMboChange))
/*  87:    */       {
/*  88:118 */         MobileMboChange mobileMboChange = (MobileMboChange)obj;
/*  89:120 */         if (mobileMboChange.mobileMbo.isDeleted()) {
/*  90:122 */           output.writeInt(3);
/*  91:124 */         } else if (mobileMboChange.mobileMbo.isNew()) {
/*  92:126 */           output.writeInt(1);
/*  93:    */         } else {
/*  94:130 */           output.writeInt(2);
/*  95:    */         }
/*  96:133 */         if (!mobileMboChange.mobileMbo.isDeleted()) {
/*  97:137 */           writeMobileMboInstance(output, mobileMboChange.mobileMbo);
/*  98:    */         }
/*  99:    */       }
/* 100:    */     }
/* 101:    */     catch (Exception ex)
/* 102:    */     {
/* 103:143 */       MobileLoggerFactory.getDefaultLogger().warn("Failed to write MobileMboChange", ex);
/* 104:144 */       throw new IOException("Failed to write MobileMboChange");
/* 105:    */     }
/* 106:    */   }
/* 107:    */   
/* 108:    */   public Object readMobileMboChangeInstance(DataInput input)
/* 109:    */     throws Exception
/* 110:    */   {
/* 111:151 */     RDOSerializer rdoSerializer = new RDOSerializer();
/* 112:    */     
/* 113:    */ 
/* 114:154 */     RDO rdo = (RDO)rdoSerializer.readInstance(input);
/* 115:155 */     MobileMbo mobileMbo = new MobileMbo(rdo);
/* 116:    */     
/* 117:    */ 
/* 118:158 */     MobileMboInfo mboInfo = MobileMboUtil.getMobileMboInfo(mobileMbo.getAppName(), mobileMbo.getName());
/* 119:159 */     String[] dependentNames = mboInfo.getDependentNames();
/* 120:160 */     int noOfDependents = input.readInt();
/* 121:162 */     for (int i = 0; i < noOfDependents; i++)
/* 122:    */     {
/* 123:164 */       int noOfDependentsChanged = input.readInt();
/* 124:165 */       for (int j = 0; j < noOfDependentsChanged; j++)
/* 125:    */       {
/* 126:171 */         MobileMbo dependentMobileMbo = (MobileMbo)readMobileMboChangeInstance(input);
/* 127:172 */         mobileMbo.addDependent(dependentNames[i], dependentMobileMbo);
/* 128:    */       }
/* 129:    */     }
/* 130:178 */     return mobileMbo;
/* 131:    */   }
/* 132:    */   
/* 133:    */   public void writeMobileMboInstance(DataOutput output, Object obj)
/* 134:    */     throws Exception
/* 135:    */   {
/* 136:183 */     MobileMbo mobileMbo = (MobileMbo)obj;
/* 137:    */     
/* 138:185 */     RDOSerializer rdoSerializer = new RDOSerializer();
/* 139:    */     
/* 140:    */ 
/* 141:188 */     rdoSerializer.writeInstance(output, mobileMbo.getRDO(), true);
/* 142:191 */     if (this.ignoreDependentChanges) {
/* 143:193 */       return;
/* 144:    */     }
/* 145:197 */     MobileMboInfo mboInfo = MobileMboUtil.getMobileMboInfo(mobileMbo.getAppName(), mobileMbo.getName());
/* 146:198 */     String[] dependentNames = mboInfo.getDependentNames();
/* 147:    */     
/* 148:200 */     output.writeInt(dependentNames.length);
/* 149:201 */     for (int i = 0; i < dependentNames.length; i++)
/* 150:    */     {
/* 151:203 */       MobileMboInfo depMobileMboInfo = MobileMboUtil.getMobileMboInfo(mobileMbo.getAppName(), dependentNames[i]);
/* 152:204 */       if ((!depMobileMboInfo.isWorkset()) && (!depMobileMboInfo.isLocalWorkset()) && (!depMobileMboInfo.isLocalWorksetUpload()))
/* 153:    */       {
/* 154:206 */         output.writeInt(0);
/* 155:    */       }
/* 156:    */       else
/* 157:    */       {
/* 158:210 */         ByteArrayOutputStream bos = new ByteArrayOutputStream();
/* 159:211 */         DataOutputStream dos = new DataOutputStream(bos);
/* 160:    */         
/* 161:213 */         int noOfDependentsChanged = 0;
/* 162:214 */         Enumeration depEnum = mobileMbo.getDependents(dependentNames[i]);
/* 163:215 */         while (depEnum.hasMoreElements())
/* 164:    */         {
/* 165:217 */           MobileMbo dependentMobileMbo = (MobileMbo)depEnum.nextElement();
/* 166:218 */           if (dependentMobileMbo.isModified())
/* 167:    */           {
/* 168:220 */             noOfDependentsChanged++;
/* 169:    */             
/* 170:222 */             writeMobileMboInstance(dos, dependentMobileMbo);
/* 171:    */           }
/* 172:    */         }
/* 173:226 */         dos.flush();
/* 174:    */         
/* 175:228 */         output.writeInt(noOfDependentsChanged);
/* 176:229 */         output.write(bos.toByteArray());
/* 177:    */       }
/* 178:    */     }
/* 179:    */   }
/* 180:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.mbo.MobileMboChange
 * JD-Core Version:    0.7.0.1
 */