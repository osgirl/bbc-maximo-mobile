/*  1:   */ package com.mro.mobile.mbo;
/*  2:   */ 
/*  3:   */ import com.mro.mobile.persist.RDODependentRelation;
/*  4:   */ import java.io.IOException;
/*  5:   */ 
/*  6:   */ public class MobileMboDependentRelation
/*  7:   */   extends RDODependentRelation
/*  8:   */ {
/*  9:   */   public MobileMboDependentRelation() {}
/* 10:   */   
/* 11:   */   public MobileMboDependentRelation(byte[] data)
/* 12:   */     throws IOException
/* 13:   */   {
/* 14:29 */     super(data);
/* 15:   */   }
/* 16:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.mbo.MobileMboDependentRelation
 * JD-Core Version:    0.7.0.1
 */