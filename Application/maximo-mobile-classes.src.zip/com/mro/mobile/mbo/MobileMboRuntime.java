/*  1:   */ package com.mro.mobile.mbo;
/*  2:   */ 
/*  3:   */ import java.util.Enumeration;
/*  4:   */ import java.util.Hashtable;
/*  5:   */ 
/*  6:   */ public class MobileMboRuntime
/*  7:   */ {
/*  8:23 */   private Hashtable mobileMboInfoMap = new Hashtable();
/*  9:   */   
/* 10:   */   public void registerMobileMboInfo(MobileMboInfo mboInfo)
/* 11:   */   {
/* 12:28 */     this.mobileMboInfoMap.put(mboInfo.getName(), mboInfo);
/* 13:   */   }
/* 14:   */   
/* 15:   */   public MobileMboInfo getMobileMboInfo(String name)
/* 16:   */   {
/* 17:33 */     return (MobileMboInfo)this.mobileMboInfoMap.get(name);
/* 18:   */   }
/* 19:   */   
/* 20:   */   public Enumeration getAllMobileMboNames()
/* 21:   */   {
/* 22:38 */     return this.mobileMboInfoMap.keys();
/* 23:   */   }
/* 24:   */   
/* 25:42 */   private static Hashtable mobileMboRuntimes = new Hashtable();
/* 26:   */   
/* 27:   */   public static MobileMboRuntime getInstance(String appName)
/* 28:   */   {
/* 29:46 */     return (MobileMboRuntime)mobileMboRuntimes.get(appName);
/* 30:   */   }
/* 31:   */   
/* 32:   */   public static void registerInstance(String appName, MobileMboRuntime mobileMboRuntime)
/* 33:   */   {
/* 34:51 */     mobileMboRuntimes.put(appName, mobileMboRuntime);
/* 35:   */   }
/* 36:   */   
/* 37:   */   public static void unregisterInstance(String appName)
/* 38:   */   {
/* 39:56 */     mobileMboRuntimes.remove(appName);
/* 40:   */   }
/* 41:   */   
/* 42:   */   public static MobileMboRuntime getNewInstance()
/* 43:   */   {
/* 44:61 */     return new MobileMboRuntime();
/* 45:   */   }
/* 46:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.mbo.MobileMboRuntime
 * JD-Core Version:    0.7.0.1
 */