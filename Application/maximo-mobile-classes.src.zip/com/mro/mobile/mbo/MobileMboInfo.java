/*    1:     */ package com.mro.mobile.mbo;
/*    2:     */ 
/*    3:     */ import com.mro.mobile.MobileApplicationException;
/*    4:     */ import com.mro.mobile.persist.DefaultRDO;
/*    5:     */ import com.mro.mobile.persist.DefaultRDOAttributeInfo;
/*    6:     */ import com.mro.mobile.persist.DefaultRDOInfo;
/*    7:     */ import com.mro.mobile.persist.RDO;
/*    8:     */ import com.mro.mobile.persist.RDOInfo;
/*    9:     */ import com.mro.mobile.persist.RDOSerializer;
/*   10:     */ import com.mro.mobile.type.Serializer;
/*   11:     */ import com.mro.mobile.type.TypeRegistry;
/*   12:     */ import java.io.ByteArrayInputStream;
/*   13:     */ import java.io.ByteArrayOutputStream;
/*   14:     */ import java.io.DataInput;
/*   15:     */ import java.io.DataInputStream;
/*   16:     */ import java.io.DataOutput;
/*   17:     */ import java.io.DataOutputStream;
/*   18:     */ import java.io.IOException;
/*   19:     */ import java.util.Date;
/*   20:     */ import java.util.Enumeration;
/*   21:     */ import java.util.Hashtable;
/*   22:     */ import java.util.Vector;
/*   23:     */ 
/*   24:     */ public class MobileMboInfo
/*   25:     */   implements Serializer
/*   26:     */ {
/*   27:     */   public static final int TYPE_DEFAULT = 0;
/*   28:     */   public static final int TYPE_WORKSET = 1;
/*   29:     */   public static final int TYPE_LOCALWORKSET = 2;
/*   30:     */   public static final int TYPE_LOCALWORKSET_DOWNLOAD = 3;
/*   31:     */   public static final int TYPE_LOCALWORKSET_UPLOAD = 4;
/*   32:     */   public static final int MULTISITETYPE_SYSTEM = 0;
/*   33:     */   public static final int MULTISITETYPE_SITE = 1;
/*   34:     */   public static final int MULTISITETYPE_ORG = 2;
/*   35:     */   public static final int MULTISITETYPE_ITEMSET = 3;
/*   36:     */   public static final int MULTISITETYPE_COMPANYSET = 4;
/*   37:  68 */   private String appName = null;
/*   38:  71 */   private String name = null;
/*   39:  74 */   private String description = null;
/*   40:  77 */   private String parent = null;
/*   41:  80 */   private String[] dependentNames = null;
/*   42:  85 */   private int type = 0;
/*   43:  90 */   private String mobileMboName = null;
/*   44:  95 */   private MobileMboDependentRelation dependentRelation = null;
/*   45:  99 */   private boolean readOnly = false;
/*   46: 102 */   private boolean hierarchical = false;
/*   47: 105 */   private Date lastDownloadTime = null;
/*   48: 108 */   private Vector mboAttributes = new Vector();
/*   49: 110 */   private Hashtable attributesPosition = new Hashtable();
/*   50: 114 */   private MobileMboOrder defaultOrder = new MobileMboOrder();
/*   51: 119 */   private String siteAttribute = null;
/*   52: 122 */   private String orgAttribute = null;
/*   53: 125 */   private String itemSetAttribute = null;
/*   54: 128 */   private String companySetAttribute = null;
/*   55: 131 */   private int multiSiteType = 0;
/*   56: 134 */   private boolean domain = false;
/*   57: 142 */   private boolean associatedWithMbo = false;
/*   58:     */   public static final String MAXOBJECT = "MAXOBJECT";
/*   59:     */   
/*   60:     */   private MobileMboInfo() {}
/*   61:     */   
/*   62:     */   public MobileMboInfo(String appName, String name)
/*   63:     */   {
/*   64: 158 */     this.appName = appName;
/*   65: 159 */     this.name = name;
/*   66:     */   }
/*   67:     */   
/*   68:     */   public MobileMboInfo(RDO rdo)
/*   69:     */     throws MobileApplicationException
/*   70:     */   {
/*   71: 170 */     this.appName = rdo.getAppName();
/*   72: 171 */     this.name = rdo.getStringValue("NAME");
/*   73: 172 */     this.description = rdo.getStringValue("DESCRIPTION");
/*   74: 173 */     this.readOnly = rdo.getBooleanValue("READONLY");
/*   75: 174 */     this.hierarchical = rdo.getBooleanValue("HIERARCHICAL");
/*   76: 175 */     this.mobileMboName = rdo.getStringValue("MOBILEMBONAME");
/*   77: 176 */     this.lastDownloadTime = rdo.getDateValue("LASTDOWNLOADDATE");
/*   78: 177 */     this.type = rdo.getIntValue("MBOTYPE");
/*   79: 178 */     this.domain = rdo.getBooleanValue("DOMAIN");
/*   80: 179 */     this.associatedWithMbo = rdo.getBooleanValue("MBOASSOCIATED");
/*   81: 181 */     if (!rdo.isNull("MULTISITETYPE")) {
/*   82: 183 */       this.multiSiteType = rdo.getIntValue("MULTISITETYPE");
/*   83:     */     }
/*   84: 186 */     if (!rdo.isNull("SITEATTR")) {
/*   85: 188 */       this.siteAttribute = rdo.getStringValue("SITEATTR");
/*   86:     */     }
/*   87: 191 */     if (!rdo.isNull("ORGATTR")) {
/*   88: 193 */       this.orgAttribute = rdo.getStringValue("ORGATTR");
/*   89:     */     }
/*   90: 196 */     if (!rdo.isNull("ITEMSETATTR")) {
/*   91: 198 */       this.itemSetAttribute = rdo.getStringValue("ITEMSETATTR");
/*   92:     */     }
/*   93: 201 */     if (!rdo.isNull("COMPSETATTR")) {
/*   94: 203 */       this.companySetAttribute = rdo.getStringValue("COMPSETATTR");
/*   95:     */     }
/*   96:     */     try
/*   97:     */     {
/*   98: 208 */       byte[] bValue = rdo.getBinaryValue("DEPRELATION");
/*   99: 209 */       if (bValue != null) {
/*  100: 211 */         this.dependentRelation = new MobileMboDependentRelation(bValue);
/*  101:     */       }
/*  102: 214 */       bValue = rdo.getBinaryValue("DEFORDER");
/*  103: 215 */       if (bValue != null) {
/*  104: 217 */         this.defaultOrder = new MobileMboOrder(bValue);
/*  105:     */       }
/*  106:     */     }
/*  107:     */     catch (IOException e)
/*  108:     */     {
/*  109: 222 */       throw new MobileApplicationException("invalidmobilemboinfo");
/*  110:     */     }
/*  111: 225 */     this.parent = rdo.getStringValue("PARENT");
/*  112: 226 */     if (this.parent.trim().length() == 0) {
/*  113: 228 */       this.parent = null;
/*  114:     */     }
/*  115: 231 */     loadAttributeDetails(rdo);
/*  116: 232 */     loadDependentNames(rdo);
/*  117:     */   }
/*  118:     */   
/*  119:     */   public RDO getRDO()
/*  120:     */     throws MobileApplicationException
/*  121:     */   {
/*  122: 243 */     DefaultRDO rdo = new DefaultRDO(this.appName);
/*  123: 244 */     rdo.setName("MAXOBJECT");
/*  124: 245 */     rdo.setStringValue("NAME", this.name);
/*  125: 246 */     rdo.setStringValue("DESCRIPTION", this.description);
/*  126: 247 */     rdo.setBooleanValue("READONLY", this.readOnly);
/*  127: 248 */     rdo.setIntValue("MBOTYPE", this.type);
/*  128: 249 */     rdo.setBooleanValue("HIERARCHICAL", this.hierarchical);
/*  129: 250 */     rdo.setBooleanValue("DOMAIN", this.domain);
/*  130: 251 */     rdo.setBooleanValue("MBOASSOCIATED", this.associatedWithMbo);
/*  131: 253 */     if (this.parent != null) {
/*  132: 255 */       rdo.setStringValue("PARENT", this.parent);
/*  133:     */     }
/*  134: 258 */     rdo.setStringValue("MOBILEMBONAME", this.mobileMboName);
/*  135:     */     
/*  136: 260 */     rdo.setIntValue("MULTISITETYPE", this.multiSiteType);
/*  137: 262 */     if (this.siteAttribute != null) {
/*  138: 264 */       rdo.setStringValue("SITEATTR", this.siteAttribute);
/*  139:     */     }
/*  140: 267 */     if (this.orgAttribute != null) {
/*  141: 269 */       rdo.setStringValue("ORGATTR", this.orgAttribute);
/*  142:     */     }
/*  143: 272 */     if (this.itemSetAttribute != null) {
/*  144: 274 */       rdo.setStringValue("ITEMSETATTR", this.itemSetAttribute);
/*  145:     */     }
/*  146: 277 */     if (this.companySetAttribute != null) {
/*  147: 279 */       rdo.setStringValue("COMPSETATTR", this.companySetAttribute);
/*  148:     */     }
/*  149: 282 */     ByteArrayOutputStream bos = new ByteArrayOutputStream();
/*  150: 283 */     DataOutputStream dout = new DataOutputStream(bos);
/*  151:     */     try
/*  152:     */     {
/*  153: 287 */       if (this.dependentRelation != null) {
/*  154: 289 */         rdo.setBinaryValue("DEPRELATION", this.dependentRelation.getBinaryValue());
/*  155:     */       }
/*  156: 292 */       if (this.defaultOrder != null) {
/*  157: 294 */         rdo.setBinaryValue("DEFORDER", this.defaultOrder.getBinaryValue());
/*  158:     */       }
/*  159: 297 */       int attrCount = this.mboAttributes.size();
/*  160: 298 */       dout.writeInt(attrCount);
/*  161: 299 */       for (int i = 0; i < attrCount; i++)
/*  162:     */       {
/*  163: 301 */         MobileMboAttributeInfo attrInfo = (MobileMboAttributeInfo)this.mboAttributes.elementAt(i);
/*  164: 302 */         attrInfo.serialize(dout);
/*  165:     */       }
/*  166: 305 */       dout.flush();
/*  167: 306 */       rdo.setBinaryValue("ATTRIBUTES", bos.toByteArray());
/*  168:     */       
/*  169:     */ 
/*  170: 309 */       bos.reset();
/*  171: 311 */       if (this.dependentNames == null)
/*  172:     */       {
/*  173: 313 */         dout.writeInt(0);
/*  174:     */       }
/*  175:     */       else
/*  176:     */       {
/*  177: 317 */         dout.writeInt(this.dependentNames.length);
/*  178: 318 */         for (int i = 0; i < this.dependentNames.length; i++) {
/*  179: 320 */           dout.writeUTF(this.dependentNames[i]);
/*  180:     */         }
/*  181:     */       }
/*  182: 323 */       dout.flush();
/*  183:     */       
/*  184: 325 */       rdo.setBinaryValue("DEPENDENTNAMES", bos.toByteArray());
/*  185: 326 */       rdo.setDateValue("LASTDOWNLOADDATE", this.lastDownloadTime);
/*  186:     */       
/*  187: 328 */       return rdo;
/*  188:     */     }
/*  189:     */     catch (IOException e)
/*  190:     */     {
/*  191: 332 */       throw new MobileApplicationException("getrdofailed", new Object[] { this.name });
/*  192:     */     }
/*  193:     */   }
/*  194:     */   
/*  195:     */   public String getName()
/*  196:     */   {
/*  197: 343 */     return this.name;
/*  198:     */   }
/*  199:     */   
/*  200:     */   public void setName(String name)
/*  201:     */   {
/*  202: 353 */     this.name = name;
/*  203:     */   }
/*  204:     */   
/*  205:     */   public String getDescription()
/*  206:     */   {
/*  207: 363 */     return this.description;
/*  208:     */   }
/*  209:     */   
/*  210:     */   public void setDescription(String description)
/*  211:     */   {
/*  212: 373 */     this.description = description;
/*  213:     */   }
/*  214:     */   
/*  215:     */   public String getAppName()
/*  216:     */   {
/*  217: 383 */     return this.appName;
/*  218:     */   }
/*  219:     */   
/*  220:     */   public void setAppName(String appName)
/*  221:     */   {
/*  222: 393 */     this.appName = appName;
/*  223:     */   }
/*  224:     */   
/*  225:     */   public String[] getAttributeNames()
/*  226:     */   {
/*  227: 403 */     String[] names = new String[this.mboAttributes.size()];
/*  228: 404 */     int i = 0;
/*  229: 405 */     Enumeration attrEnum = this.mboAttributes.elements();
/*  230: 406 */     while (attrEnum.hasMoreElements())
/*  231:     */     {
/*  232: 408 */       MobileMboAttributeInfo attrInfo = (MobileMboAttributeInfo)attrEnum.nextElement();
/*  233: 409 */       String attrName = attrInfo.getName();
/*  234: 410 */       names[i] = attrName;
/*  235: 411 */       i++;
/*  236:     */     }
/*  237: 415 */     return names;
/*  238:     */   }
/*  239:     */   
/*  240:     */   public int getAttributeCount()
/*  241:     */   {
/*  242: 425 */     return this.mboAttributes.size();
/*  243:     */   }
/*  244:     */   
/*  245:     */   public MobileMboAttributeInfo getAttributeInfo(String name)
/*  246:     */   {
/*  247: 437 */     int index = name.indexOf(".");
/*  248: 438 */     if (index > 0)
/*  249:     */     {
/*  250: 440 */       String depName = name.substring(0, index);
/*  251: 441 */       String depAttrName = name.substring(index + 1);
/*  252:     */       
/*  253:     */ 
/*  254: 444 */       MobileMboInfo depInfo = MobileMboUtil.getMobileMboInfo(getAppName(), depName);
/*  255: 445 */       if (depInfo == null) {
/*  256: 447 */         return null;
/*  257:     */       }
/*  258: 450 */       return depInfo.getAttributeInfo(depAttrName);
/*  259:     */     }
/*  260: 453 */     if (this.attributesPosition.containsKey(name))
/*  261:     */     {
/*  262: 454 */       Integer position = (Integer)this.attributesPosition.get(name);
/*  263: 455 */       return (MobileMboAttributeInfo)this.mboAttributes.get(position.intValue());
/*  264:     */     }
/*  265: 471 */     return null;
/*  266:     */   }
/*  267:     */   
/*  268:     */   public boolean isReadOnly()
/*  269:     */   {
/*  270: 483 */     return this.readOnly;
/*  271:     */   }
/*  272:     */   
/*  273:     */   public void setReadOnly(boolean readOnly)
/*  274:     */   {
/*  275: 495 */     this.readOnly = readOnly;
/*  276:     */   }
/*  277:     */   
/*  278:     */   public boolean isHierarchical()
/*  279:     */   {
/*  280: 504 */     return this.hierarchical;
/*  281:     */   }
/*  282:     */   
/*  283:     */   public void setHierarchical(boolean hierarchical)
/*  284:     */   {
/*  285: 514 */     this.hierarchical = hierarchical;
/*  286:     */   }
/*  287:     */   
/*  288:     */   public boolean isDomain()
/*  289:     */   {
/*  290: 523 */     return this.domain;
/*  291:     */   }
/*  292:     */   
/*  293:     */   public void setDomain(boolean domain)
/*  294:     */   {
/*  295: 532 */     this.domain = domain;
/*  296:     */   }
/*  297:     */   
/*  298:     */   public boolean isAssociatedWithMbo()
/*  299:     */   {
/*  300: 542 */     return this.associatedWithMbo;
/*  301:     */   }
/*  302:     */   
/*  303:     */   public void setAssociatedWithMbo(boolean associatedWithMbo)
/*  304:     */   {
/*  305: 547 */     this.associatedWithMbo = associatedWithMbo;
/*  306:     */   }
/*  307:     */   
/*  308:     */   public String getParent()
/*  309:     */   {
/*  310: 557 */     return this.parent;
/*  311:     */   }
/*  312:     */   
/*  313:     */   public void setParent(String parent)
/*  314:     */   {
/*  315: 567 */     this.parent = parent;
/*  316:     */   }
/*  317:     */   
/*  318:     */   public void addAttributeInfo(MobileMboAttributeInfo attrInfo)
/*  319:     */   {
/*  320: 577 */     this.mboAttributes.addElement(attrInfo);
/*  321: 578 */     this.attributesPosition.put(attrInfo.getName(), new Integer(this.mboAttributes.size() - 1));
/*  322:     */   }
/*  323:     */   
/*  324:     */   private void loadAttributeDetails(RDO rdo)
/*  325:     */     throws MobileApplicationException
/*  326:     */   {
/*  327: 589 */     byte[] data = rdo.getBinaryValue("ATTRIBUTES");
/*  328:     */     
/*  329: 591 */     ByteArrayInputStream bis = new ByteArrayInputStream(data);
/*  330: 592 */     DataInputStream dis = new DataInputStream(bis);
/*  331:     */     try
/*  332:     */     {
/*  333: 596 */       int noOfAttributes = dis.readInt();
/*  334: 597 */       for (int i = 0; i < noOfAttributes; i++)
/*  335:     */       {
/*  336: 599 */         MobileMboAttributeInfo attrInfo = new MobileMboAttributeInfo();
/*  337: 600 */         attrInfo.deserialize(dis);
/*  338:     */         
/*  339: 602 */         addAttributeInfo(attrInfo);
/*  340:     */       }
/*  341:     */     }
/*  342:     */     catch (IOException e)
/*  343:     */     {
/*  344: 607 */       throw new MobileApplicationException("loadattrfailed", new Object[] { this.name });
/*  345:     */     }
/*  346:     */   }
/*  347:     */   
/*  348:     */   private void loadDependentNames(RDO rdo)
/*  349:     */     throws MobileApplicationException
/*  350:     */   {
/*  351: 619 */     byte[] data = rdo.getBinaryValue("DEPENDENTNAMES");
/*  352:     */     
/*  353: 621 */     ByteArrayInputStream bis = new ByteArrayInputStream(data);
/*  354: 622 */     DataInputStream dis = new DataInputStream(bis);
/*  355:     */     try
/*  356:     */     {
/*  357: 626 */       int noOfDependents = dis.readInt();
/*  358: 627 */       this.dependentNames = new String[noOfDependents];
/*  359: 628 */       for (int i = 0; i < noOfDependents; i++)
/*  360:     */       {
/*  361: 630 */         String dependentName = dis.readUTF();
/*  362: 631 */         this.dependentNames[i] = dependentName;
/*  363:     */       }
/*  364:     */     }
/*  365:     */     catch (IOException e)
/*  366:     */     {
/*  367: 636 */       throw new MobileApplicationException("loaddepnamesfailed", new Object[] { this.name });
/*  368:     */     }
/*  369:     */   }
/*  370:     */   
/*  371:     */   public String[] getDependentNames()
/*  372:     */   {
/*  373: 647 */     return this.dependentNames;
/*  374:     */   }
/*  375:     */   
/*  376:     */   public void setDependentNames(String[] dependentNames)
/*  377:     */   {
/*  378: 657 */     this.dependentNames = dependentNames;
/*  379:     */   }
/*  380:     */   
/*  381:     */   public void setType(int mboType)
/*  382:     */   {
/*  383: 669 */     if ((mboType != 0) && (mboType != 1) && (mboType != 2) && (mboType != 3) && (mboType != 4)) {
/*  384: 675 */       this.type = 0;
/*  385:     */     } else {
/*  386: 679 */       this.type = mboType;
/*  387:     */     }
/*  388:     */   }
/*  389:     */   
/*  390:     */   public boolean isWorkset()
/*  391:     */   {
/*  392: 690 */     if (this.type == 1) {
/*  393: 692 */       return true;
/*  394:     */     }
/*  395: 695 */     return false;
/*  396:     */   }
/*  397:     */   
/*  398:     */   public boolean isLocalWorkset()
/*  399:     */   {
/*  400: 705 */     if (this.type == 2) {
/*  401: 707 */       return true;
/*  402:     */     }
/*  403: 710 */     return false;
/*  404:     */   }
/*  405:     */   
/*  406:     */   public boolean isLocalWorksetDownload()
/*  407:     */   {
/*  408: 719 */     if (this.type == 3) {
/*  409: 721 */       return true;
/*  410:     */     }
/*  411: 724 */     return false;
/*  412:     */   }
/*  413:     */   
/*  414:     */   public boolean isLocalWorksetUpload()
/*  415:     */   {
/*  416: 733 */     if (this.type == 4) {
/*  417: 735 */       return true;
/*  418:     */     }
/*  419: 738 */     return false;
/*  420:     */   }
/*  421:     */   
/*  422:     */   public String getMobileMboName()
/*  423:     */   {
/*  424: 748 */     return this.mobileMboName;
/*  425:     */   }
/*  426:     */   
/*  427:     */   public void setMobileMboName(String mobileMboName)
/*  428:     */   {
/*  429: 758 */     this.mobileMboName = mobileMboName;
/*  430:     */   }
/*  431:     */   
/*  432:     */   public MobileMboDependentRelation getDependentRelation()
/*  433:     */   {
/*  434: 769 */     return this.dependentRelation;
/*  435:     */   }
/*  436:     */   
/*  437:     */   public void setDependentRelation(MobileMboDependentRelation dependentRelation)
/*  438:     */   {
/*  439: 780 */     this.dependentRelation = dependentRelation;
/*  440:     */   }
/*  441:     */   
/*  442:     */   public MobileMboOrder getDefaultOrder()
/*  443:     */   {
/*  444: 790 */     return this.defaultOrder;
/*  445:     */   }
/*  446:     */   
/*  447:     */   public String getSiteAttribute()
/*  448:     */   {
/*  449: 800 */     return this.siteAttribute;
/*  450:     */   }
/*  451:     */   
/*  452:     */   public void setSiteAttribute(String siteAttribute)
/*  453:     */   {
/*  454: 810 */     this.siteAttribute = siteAttribute;
/*  455:     */   }
/*  456:     */   
/*  457:     */   public String getOrgAttribute()
/*  458:     */   {
/*  459: 820 */     return this.orgAttribute;
/*  460:     */   }
/*  461:     */   
/*  462:     */   public void setOrgAttribute(String orgAttribute)
/*  463:     */   {
/*  464: 830 */     this.orgAttribute = orgAttribute;
/*  465:     */   }
/*  466:     */   
/*  467:     */   public String getItemSetAttribute()
/*  468:     */   {
/*  469: 840 */     return this.itemSetAttribute;
/*  470:     */   }
/*  471:     */   
/*  472:     */   public void setItemSetAttribute(String itemSetAttribute)
/*  473:     */   {
/*  474: 850 */     this.itemSetAttribute = itemSetAttribute;
/*  475:     */   }
/*  476:     */   
/*  477:     */   public String getCompanySetAttribute()
/*  478:     */   {
/*  479: 860 */     return this.companySetAttribute;
/*  480:     */   }
/*  481:     */   
/*  482:     */   public void setCompanySetAttribute(String companySetAttribute)
/*  483:     */   {
/*  484: 870 */     this.companySetAttribute = companySetAttribute;
/*  485:     */   }
/*  486:     */   
/*  487:     */   public boolean isSiteLevel()
/*  488:     */   {
/*  489: 880 */     if (this.multiSiteType == 1) {
/*  490: 882 */       return true;
/*  491:     */     }
/*  492: 885 */     return false;
/*  493:     */   }
/*  494:     */   
/*  495:     */   public boolean isOrgLevel()
/*  496:     */   {
/*  497: 895 */     if (this.multiSiteType == 2) {
/*  498: 897 */       return true;
/*  499:     */     }
/*  500: 900 */     return false;
/*  501:     */   }
/*  502:     */   
/*  503:     */   public boolean isItemSetLevel()
/*  504:     */   {
/*  505: 910 */     if (this.multiSiteType == 3) {
/*  506: 912 */       return true;
/*  507:     */     }
/*  508: 915 */     return false;
/*  509:     */   }
/*  510:     */   
/*  511:     */   public boolean isCompanySetLevel()
/*  512:     */   {
/*  513: 925 */     if (this.multiSiteType == 4) {
/*  514: 927 */       return true;
/*  515:     */     }
/*  516: 930 */     return false;
/*  517:     */   }
/*  518:     */   
/*  519:     */   public boolean isSystemLevel()
/*  520:     */   {
/*  521: 940 */     if (this.multiSiteType == 0) {
/*  522: 942 */       return true;
/*  523:     */     }
/*  524: 945 */     return false;
/*  525:     */   }
/*  526:     */   
/*  527:     */   public int getMultiSiteType()
/*  528:     */   {
/*  529: 955 */     return this.multiSiteType;
/*  530:     */   }
/*  531:     */   
/*  532:     */   public void setMultiSiteType(int multiSiteType)
/*  533:     */   {
/*  534: 965 */     if ((multiSiteType != 0) && (multiSiteType != 1) && (multiSiteType != 2) && (multiSiteType != 3) && (multiSiteType != 4)) {
/*  535: 971 */       this.multiSiteType = 0;
/*  536:     */     } else {
/*  537: 975 */       this.multiSiteType = multiSiteType;
/*  538:     */     }
/*  539:     */   }
/*  540:     */   
/*  541:     */   public Date getLastDownloadTime()
/*  542:     */   {
/*  543: 986 */     return this.lastDownloadTime;
/*  544:     */   }
/*  545:     */   
/*  546:     */   public void setLastDownloadTime(Date lastDownloadTime)
/*  547:     */   {
/*  548: 996 */     this.lastDownloadTime = lastDownloadTime;
/*  549:     */   }
/*  550:     */   
/*  551:     */   public static void initSerializer()
/*  552:     */   {
/*  553:1001 */     MobileMboInfo i = new MobileMboInfo();
/*  554:1002 */     TypeRegistry.getTypeRegistry().addType("MobileMboInfo", i.getClass(), i);
/*  555:1003 */     TypeRegistry.getTypeRegistry().addType("MobileMboInfo[]", new MobileMboInfo[0].getClass(), i);
/*  556:     */   }
/*  557:     */   
/*  558:     */   public Object readInstance(DataInput input, String name)
/*  559:     */     throws IOException
/*  560:     */   {
/*  561:1011 */     if (name.equals("MobileMboInfo"))
/*  562:     */     {
/*  563:1013 */       RDOSerializer rdoSerializer = new RDOSerializer();
/*  564:1014 */       RDO rdo = (RDO)rdoSerializer.readInstance(input);
/*  565:     */       try
/*  566:     */       {
/*  567:1018 */         return new MobileMboInfo(rdo);
/*  568:     */       }
/*  569:     */       catch (MobileApplicationException e)
/*  570:     */       {
/*  571:1022 */         throw new IOException(e.getMessage());
/*  572:     */       }
/*  573:     */     }
/*  574:1025 */     if (name.equals("MobileMboInfo[]"))
/*  575:     */     {
/*  576:1027 */       int arraySize = input.readInt();
/*  577:1028 */       MobileMboInfo[] array = new MobileMboInfo[arraySize];
/*  578:1029 */       for (int i = 0; i < arraySize; i++)
/*  579:     */       {
/*  580:1031 */         String arrayElementType = input.readUTF();
/*  581:1032 */         array[i] = ((MobileMboInfo)readInstance(input, arrayElementType));
/*  582:     */       }
/*  583:1034 */       return array;
/*  584:     */     }
/*  585:1037 */     throw new RuntimeException("The type " + name + " not supported.");
/*  586:     */   }
/*  587:     */   
/*  588:     */   public void writeInstance(DataOutput output, Object obj)
/*  589:     */     throws IOException
/*  590:     */   {
/*  591:1045 */     if ((obj instanceof MobileMboInfo))
/*  592:     */     {
/*  593:1047 */       RDOSerializer rdoSerializer = new RDOSerializer();
/*  594:1048 */       MobileMboInfo info = (MobileMboInfo)obj;
/*  595:     */       try
/*  596:     */       {
/*  597:1051 */         rdoSerializer.writeInstance(output, info.getRDO());
/*  598:     */       }
/*  599:     */       catch (MobileApplicationException e)
/*  600:     */       {
/*  601:1055 */         throw new IOException(e.getMessage());
/*  602:     */       }
/*  603:     */     }
/*  604:1058 */     else if (obj.getClass().isArray())
/*  605:     */     {
/*  606:1060 */       MobileMboInfo[] array = (MobileMboInfo[])obj;
/*  607:     */       
/*  608:1062 */       output.writeInt(array.length);
/*  609:1063 */       for (int i = 0; i < array.length; i++)
/*  610:     */       {
/*  611:1065 */         output.writeUTF(TypeRegistry.getTypeRegistry().getTypeInfo(array[i]));
/*  612:1066 */         writeInstance(output, array[i]);
/*  613:     */       }
/*  614:     */     }
/*  615:     */   }
/*  616:     */   
/*  617:     */   public static RDOInfo getMobileMboInfo()
/*  618:     */   {
/*  619:1075 */     DefaultRDOInfo maxobjectInfo = new DefaultRDOInfo();
/*  620:1076 */     maxobjectInfo.setName("MAXOBJECT");
/*  621:     */     
/*  622:1078 */     DefaultRDOAttributeInfo attr1 = new DefaultRDOAttributeInfo();
/*  623:1079 */     attr1.setName("NAME");
/*  624:1080 */     attr1.setKey(true);
/*  625:1081 */     attr1.setDataType(2);
/*  626:     */     
/*  627:1083 */     DefaultRDOAttributeInfo attr2 = new DefaultRDOAttributeInfo();
/*  628:1084 */     attr2.setName("DESCRIPTION");
/*  629:1085 */     attr2.setKey(false);
/*  630:     */     
/*  631:1087 */     DefaultRDOAttributeInfo attr3 = new DefaultRDOAttributeInfo();
/*  632:1088 */     attr3.setName("MBOTYPE");
/*  633:1089 */     attr3.setKey(false);
/*  634:1090 */     attr3.setDataType(4);
/*  635:     */     
/*  636:1092 */     DefaultRDOAttributeInfo attr4 = new DefaultRDOAttributeInfo();
/*  637:1093 */     attr4.setName("READONLY");
/*  638:1094 */     attr4.setKey(false);
/*  639:1095 */     attr4.setDataType(8);
/*  640:     */     
/*  641:1097 */     DefaultRDOAttributeInfo attr5 = new DefaultRDOAttributeInfo();
/*  642:1098 */     attr5.setName("HIERARCHICAL");
/*  643:1099 */     attr5.setKey(false);
/*  644:1100 */     attr5.setDataType(8);
/*  645:     */     
/*  646:1102 */     DefaultRDOAttributeInfo attr6 = new DefaultRDOAttributeInfo();
/*  647:1103 */     attr6.setName("ATTRIBUTES");
/*  648:1104 */     attr6.setKey(false);
/*  649:1105 */     attr6.setDataType(12);
/*  650:     */     
/*  651:1107 */     DefaultRDOAttributeInfo attr7 = new DefaultRDOAttributeInfo();
/*  652:1108 */     attr7.setName("PARENT");
/*  653:1109 */     attr7.setKey(false);
/*  654:1110 */     attr7.setDataType(2);
/*  655:     */     
/*  656:1112 */     DefaultRDOAttributeInfo attr8 = new DefaultRDOAttributeInfo();
/*  657:1113 */     attr8.setName("DEPENDENTNAMES");
/*  658:1114 */     attr8.setKey(false);
/*  659:1115 */     attr8.setDataType(12);
/*  660:     */     
/*  661:1117 */     DefaultRDOAttributeInfo attr9 = new DefaultRDOAttributeInfo();
/*  662:1118 */     attr9.setName("MOBILEMBONAME");
/*  663:1119 */     attr9.setKey(false);
/*  664:1120 */     attr9.setDataType(1);
/*  665:     */     
/*  666:1122 */     DefaultRDOAttributeInfo attr10 = new DefaultRDOAttributeInfo();
/*  667:1123 */     attr10.setName("DEPRELATION");
/*  668:1124 */     attr10.setKey(false);
/*  669:1125 */     attr10.setDataType(12);
/*  670:     */     
/*  671:1127 */     DefaultRDOAttributeInfo attr11 = new DefaultRDOAttributeInfo();
/*  672:1128 */     attr11.setName("LASTDOWNLOADDATE");
/*  673:1129 */     attr11.setKey(false);
/*  674:1130 */     attr11.setDataType(11);
/*  675:     */     
/*  676:1132 */     DefaultRDOAttributeInfo attr12 = new DefaultRDOAttributeInfo();
/*  677:1133 */     attr12.setName("DEFORDER");
/*  678:1134 */     attr12.setKey(false);
/*  679:1135 */     attr12.setDataType(12);
/*  680:     */     
/*  681:1137 */     DefaultRDOAttributeInfo attr13 = new DefaultRDOAttributeInfo();
/*  682:1138 */     attr13.setName("SITEATTR");
/*  683:1139 */     attr13.setKey(false);
/*  684:1140 */     attr13.setDataType(1);
/*  685:     */     
/*  686:1142 */     DefaultRDOAttributeInfo attr14 = new DefaultRDOAttributeInfo();
/*  687:1143 */     attr14.setName("ORGATTR");
/*  688:1144 */     attr14.setKey(false);
/*  689:1145 */     attr14.setDataType(1);
/*  690:     */     
/*  691:1147 */     DefaultRDOAttributeInfo attr15 = new DefaultRDOAttributeInfo();
/*  692:1148 */     attr15.setName("ITEMSETATTR");
/*  693:1149 */     attr15.setKey(false);
/*  694:1150 */     attr15.setDataType(1);
/*  695:     */     
/*  696:1152 */     DefaultRDOAttributeInfo attr16 = new DefaultRDOAttributeInfo();
/*  697:1153 */     attr16.setName("COMPSETATTR");
/*  698:1154 */     attr16.setKey(false);
/*  699:1155 */     attr16.setDataType(1);
/*  700:     */     
/*  701:1157 */     DefaultRDOAttributeInfo attr17 = new DefaultRDOAttributeInfo();
/*  702:1158 */     attr17.setName("MULTISITETYPE");
/*  703:1159 */     attr17.setKey(false);
/*  704:1160 */     attr17.setDataType(4);
/*  705:     */     
/*  706:1162 */     DefaultRDOAttributeInfo attr18 = new DefaultRDOAttributeInfo();
/*  707:1163 */     attr18.setName("DOMAIN");
/*  708:1164 */     attr18.setKey(false);
/*  709:1165 */     attr18.setDataType(8);
/*  710:     */     
/*  711:1167 */     DefaultRDOAttributeInfo attr19 = new DefaultRDOAttributeInfo();
/*  712:1168 */     attr19.setName("MBOASSOCIATED");
/*  713:1169 */     attr19.setKey(false);
/*  714:1170 */     attr19.setDataType(8);
/*  715:     */     
/*  716:1172 */     maxobjectInfo.addAttributeInfo(attr1);
/*  717:1173 */     maxobjectInfo.addAttributeInfo(attr2);
/*  718:1174 */     maxobjectInfo.addAttributeInfo(attr3);
/*  719:1175 */     maxobjectInfo.addAttributeInfo(attr4);
/*  720:1176 */     maxobjectInfo.addAttributeInfo(attr5);
/*  721:1177 */     maxobjectInfo.addAttributeInfo(attr6);
/*  722:1178 */     maxobjectInfo.addAttributeInfo(attr7);
/*  723:1179 */     maxobjectInfo.addAttributeInfo(attr8);
/*  724:1180 */     maxobjectInfo.addAttributeInfo(attr9);
/*  725:1181 */     maxobjectInfo.addAttributeInfo(attr10);
/*  726:1182 */     maxobjectInfo.addAttributeInfo(attr11);
/*  727:1183 */     maxobjectInfo.addAttributeInfo(attr12);
/*  728:1184 */     maxobjectInfo.addAttributeInfo(attr13);
/*  729:1185 */     maxobjectInfo.addAttributeInfo(attr14);
/*  730:1186 */     maxobjectInfo.addAttributeInfo(attr15);
/*  731:1187 */     maxobjectInfo.addAttributeInfo(attr16);
/*  732:1188 */     maxobjectInfo.addAttributeInfo(attr17);
/*  733:1189 */     maxobjectInfo.addAttributeInfo(attr18);
/*  734:1190 */     maxobjectInfo.addAttributeInfo(attr19);
/*  735:     */     
/*  736:1192 */     return maxobjectInfo;
/*  737:     */   }
/*  738:     */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.mbo.MobileMboInfo
 * JD-Core Version:    0.7.0.1
 */