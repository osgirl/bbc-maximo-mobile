/*   1:    */ package com.mro.mobile.mbo;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.util.MobileLogger;
/*   4:    */ import com.mro.mobile.util.MobileLoggerFactory;
/*   5:    */ import java.io.IOException;
/*   6:    */ import java.io.ObjectInputStream;
/*   7:    */ import java.util.HashMap;
/*   8:    */ import java.util.Iterator;
/*   9:    */ import java.util.Map;
/*  10:    */ import java.util.Set;
/*  11:    */ 
/*  12:    */ public class MobileMboUpdate
/*  13:    */ {
/*  14:    */   public static final int MOBILEMBOID = 0;
/*  15:    */   public static final int ATTRIBUTES = 1;
/*  16:    */   public static final int VALUES = 2;
/*  17:    */   public static final int MOBILEMBONAME = 0;
/*  18:    */   public static final int MOBILEMBORECID = 1;
/*  19: 32 */   private String mobileMboName = null;
/*  20: 33 */   private Long mobileMboID = null;
/*  21: 34 */   private Map attributeValues = new HashMap();
/*  22: 36 */   private Map dependents = new HashMap();
/*  23:    */   
/*  24:    */   public void setID(long id)
/*  25:    */   {
/*  26: 40 */     this.mobileMboID = new Long(id);
/*  27:    */   }
/*  28:    */   
/*  29:    */   public long getID()
/*  30:    */   {
/*  31: 45 */     return this.mobileMboID.longValue();
/*  32:    */   }
/*  33:    */   
/*  34:    */   public void setName(String name)
/*  35:    */   {
/*  36: 50 */     this.mobileMboName = name;
/*  37:    */   }
/*  38:    */   
/*  39:    */   public String getName()
/*  40:    */   {
/*  41: 55 */     return this.mobileMboName;
/*  42:    */   }
/*  43:    */   
/*  44:    */   public void addAttribute(String attributeName, Object attributeValue)
/*  45:    */   {
/*  46: 60 */     this.attributeValues.put(attributeName, attributeValue);
/*  47:    */   }
/*  48:    */   
/*  49:    */   public Iterator getAttributeNames()
/*  50:    */   {
/*  51: 65 */     return this.attributeValues.keySet().iterator();
/*  52:    */   }
/*  53:    */   
/*  54:    */   public Object getAttributeValue(String attributeName)
/*  55:    */   {
/*  56: 70 */     return this.attributeValues.get(attributeName);
/*  57:    */   }
/*  58:    */   
/*  59:    */   public void readInstance(ObjectInputStream input)
/*  60:    */     throws IOException
/*  61:    */   {
/*  62: 75 */     Object[][] result = (Object[][])null;
/*  63:    */     try
/*  64:    */     {
/*  65: 78 */       result = (Object[][])input.readObject();
/*  66:    */     }
/*  67:    */     catch (ClassNotFoundException e)
/*  68:    */     {
/*  69: 81 */       MobileLoggerFactory.getDefaultLogger().warn("Failed to read instance", e);
/*  70:    */       
/*  71:    */ 
/*  72: 84 */       return;
/*  73:    */     }
/*  74: 87 */     Object[] mobileMboRecID = result[0];
/*  75: 88 */     this.mobileMboName = ((String)mobileMboRecID[0]);
/*  76: 89 */     this.mobileMboID = ((Long)mobileMboRecID[1]);
/*  77:    */     
/*  78: 91 */     Object[] attributes = result[1];
/*  79: 92 */     Object[] values = result[2];
/*  80: 93 */     int nAttributes = attributes.length;
/*  81: 94 */     for (int i = 0; i < nAttributes; i++)
/*  82:    */     {
/*  83: 96 */       String attributeName = (String)attributes[i];
/*  84: 97 */       Object value = values[i];
/*  85: 98 */       this.attributeValues.put(attributeName, value);
/*  86:    */     }
/*  87:102 */     readDependents(input);
/*  88:    */   }
/*  89:    */   
/*  90:    */   private void readDependents(ObjectInputStream input)
/*  91:    */     throws IOException
/*  92:    */   {
/*  93:108 */     int numDependents = input.readInt();
/*  94:109 */     for (int index = 0; index < numDependents; index++)
/*  95:    */     {
/*  96:111 */       MobileMboUpdate depUpdate = new MobileMboUpdate();
/*  97:112 */       depUpdate.readInstance(input);
/*  98:113 */       String key = null;
/*  99:114 */       key = depUpdate.getName() + ":" + depUpdate.getID();
/* 100:115 */       this.dependents.put(key, depUpdate);
/* 101:    */     }
/* 102:    */   }
/* 103:    */   
/* 104:    */   public MobileMboUpdate getDependent(String mobileMboName, long mobileMboId)
/* 105:    */   {
/* 106:122 */     String key = null;
/* 107:123 */     key = mobileMboName + ":" + mobileMboId;
/* 108:    */     
/* 109:125 */     return (MobileMboUpdate)this.dependents.get(key);
/* 110:    */   }
/* 111:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.mbo.MobileMboUpdate
 * JD-Core Version:    0.7.0.1
 */