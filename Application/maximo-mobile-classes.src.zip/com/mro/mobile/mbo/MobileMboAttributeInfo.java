/*   1:    */ package com.mro.mobile.mbo;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.util.BitFlags;
/*   4:    */ import java.io.DataInput;
/*   5:    */ import java.io.DataOutput;
/*   6:    */ import java.io.IOException;
/*   7:    */ 
/*   8:    */ public class MobileMboAttributeInfo
/*   9:    */ {
/*  10:    */   public static final int ALN = 1;
/*  11:    */   public static final int UPPER = 2;
/*  12:    */   public static final int LOWER = 3;
/*  13:    */   public static final int INTEGER = 4;
/*  14:    */   public static final int LONG = 5;
/*  15:    */   public static final int FLOAT = 6;
/*  16:    */   public static final int DOUBLE = 7;
/*  17:    */   public static final int BOOLEAN = 8;
/*  18:    */   public static final int DATE = 9;
/*  19:    */   public static final int TIME = 10;
/*  20:    */   public static final int DATETIME = 11;
/*  21:    */   public static final int BINARY = 12;
/*  22:    */   public static final int DURATION = 13;
/*  23:    */   private static final int READONLY_BIT = 1;
/*  24:    */   private static final int PRIMARYKEY_BIT = 2;
/*  25:    */   private static final int POSITIVE_BIT = 3;
/*  26:    */   private static final int REQUIRED_BIT = 4;
/*  27:    */   private static final int ESIGENABLED_BIT = 5;
/*  28:    */   private static final int PERSISTENT_BIT = 6;
/*  29:    */   private static final int DISABLECHANGETRACK_BIT = 7;
/*  30: 49 */   private String name = null;
/*  31: 50 */   private String title = "";
/*  32: 51 */   private int dataType = 0;
/*  33: 52 */   private String domainName = "";
/*  34: 53 */   private int length = 50;
/*  35: 54 */   private int scale = 0;
/*  36: 55 */   private BitFlags flags = new BitFlags(7);
/*  37:    */   private boolean relationshipBased;
/*  38:    */   
/*  39:    */   public String getName()
/*  40:    */   {
/*  41: 67 */     return this.name;
/*  42:    */   }
/*  43:    */   
/*  44:    */   public void setName(String name)
/*  45:    */   {
/*  46: 71 */     this.name = name;
/*  47:    */   }
/*  48:    */   
/*  49:    */   public String getTitle()
/*  50:    */   {
/*  51: 76 */     return this.title;
/*  52:    */   }
/*  53:    */   
/*  54:    */   public void setTitle(String title)
/*  55:    */   {
/*  56: 81 */     if (title == null) {
/*  57: 83 */       this.title = "";
/*  58:    */     } else {
/*  59: 87 */       this.title = title;
/*  60:    */     }
/*  61:    */   }
/*  62:    */   
/*  63:    */   public int getDataType()
/*  64:    */   {
/*  65: 93 */     return this.dataType;
/*  66:    */   }
/*  67:    */   
/*  68:    */   public void setDataType(int dataType)
/*  69:    */   {
/*  70: 98 */     this.dataType = dataType;
/*  71:    */   }
/*  72:    */   
/*  73:    */   public String getDomainName()
/*  74:    */   {
/*  75:103 */     if (this.domainName == null) {
/*  76:105 */       return "";
/*  77:    */     }
/*  78:107 */     return this.domainName;
/*  79:    */   }
/*  80:    */   
/*  81:    */   public void setDomainName(String domainName)
/*  82:    */   {
/*  83:112 */     this.domainName = domainName;
/*  84:    */   }
/*  85:    */   
/*  86:    */   public boolean isKey()
/*  87:    */   {
/*  88:117 */     return this.flags.isSet(2);
/*  89:    */   }
/*  90:    */   
/*  91:    */   public void setKey(boolean key)
/*  92:    */   {
/*  93:122 */     if (key) {
/*  94:124 */       this.flags.set(2);
/*  95:    */     } else {
/*  96:128 */       this.flags.clear(2);
/*  97:    */     }
/*  98:    */   }
/*  99:    */   
/* 100:    */   public boolean isReadOnly()
/* 101:    */   {
/* 102:134 */     return this.flags.isSet(1);
/* 103:    */   }
/* 104:    */   
/* 105:    */   public void setReadOnly(boolean readOnly)
/* 106:    */   {
/* 107:139 */     if (readOnly) {
/* 108:141 */       this.flags.set(1);
/* 109:    */     } else {
/* 110:145 */       this.flags.clear(1);
/* 111:    */     }
/* 112:    */   }
/* 113:    */   
/* 114:    */   public int getLength()
/* 115:    */   {
/* 116:152 */     return this.length;
/* 117:    */   }
/* 118:    */   
/* 119:    */   public void setLength(int length)
/* 120:    */   {
/* 121:157 */     this.length = length;
/* 122:    */   }
/* 123:    */   
/* 124:    */   public int getScale()
/* 125:    */   {
/* 126:162 */     return this.scale;
/* 127:    */   }
/* 128:    */   
/* 129:    */   public void setScale(int scale)
/* 130:    */   {
/* 131:167 */     this.scale = scale;
/* 132:    */   }
/* 133:    */   
/* 134:    */   public boolean isRequired()
/* 135:    */   {
/* 136:172 */     return this.flags.isSet(4);
/* 137:    */   }
/* 138:    */   
/* 139:    */   public void setRequired(boolean required)
/* 140:    */   {
/* 141:177 */     if (required) {
/* 142:179 */       this.flags.set(4);
/* 143:    */     } else {
/* 144:183 */       this.flags.clear(4);
/* 145:    */     }
/* 146:    */   }
/* 147:    */   
/* 148:    */   public boolean isPositive()
/* 149:    */   {
/* 150:189 */     return this.flags.isSet(3);
/* 151:    */   }
/* 152:    */   
/* 153:    */   public void setPositive(boolean positive)
/* 154:    */   {
/* 155:194 */     if (positive) {
/* 156:196 */       this.flags.set(3);
/* 157:    */     } else {
/* 158:200 */       this.flags.clear(3);
/* 159:    */     }
/* 160:    */   }
/* 161:    */   
/* 162:    */   public boolean isESigEnabled()
/* 163:    */   {
/* 164:206 */     return this.flags.isSet(5);
/* 165:    */   }
/* 166:    */   
/* 167:    */   public void setPersistent(boolean persistent)
/* 168:    */   {
/* 169:211 */     if (persistent) {
/* 170:213 */       this.flags.set(6);
/* 171:    */     } else {
/* 172:217 */       this.flags.clear(6);
/* 173:    */     }
/* 174:    */   }
/* 175:    */   
/* 176:    */   public boolean isPersistent()
/* 177:    */   {
/* 178:223 */     return this.flags.isSet(6);
/* 179:    */   }
/* 180:    */   
/* 181:    */   public void setESigEnabled(boolean enabled)
/* 182:    */   {
/* 183:228 */     if (enabled) {
/* 184:230 */       this.flags.set(5);
/* 185:    */     } else {
/* 186:234 */       this.flags.clear(5);
/* 187:    */     }
/* 188:    */   }
/* 189:    */   
/* 190:    */   public boolean isChangeTrackingEnabled()
/* 191:    */   {
/* 192:240 */     return !this.flags.isSet(7);
/* 193:    */   }
/* 194:    */   
/* 195:    */   public void setChangeTrackingEnabled(boolean enable)
/* 196:    */   {
/* 197:245 */     if (enable) {
/* 198:247 */       this.flags.clear(7);
/* 199:    */     } else {
/* 200:251 */       this.flags.set(7);
/* 201:    */     }
/* 202:    */   }
/* 203:    */   
/* 204:    */   public void serialize(DataOutput dout)
/* 205:    */     throws IOException
/* 206:    */   {
/* 207:258 */     dout.writeUTF(getName());
/* 208:259 */     dout.writeUTF(getTitle());
/* 209:260 */     dout.writeInt(getDataType());
/* 210:261 */     dout.writeInt(getLength());
/* 211:262 */     dout.writeInt(getScale());
/* 212:263 */     dout.writeUTF(getDomainName());
/* 213:264 */     dout.writeBoolean(isKey());
/* 214:265 */     dout.writeBoolean(isReadOnly());
/* 215:266 */     dout.writeBoolean(isRequired());
/* 216:267 */     dout.writeBoolean(isPositive());
/* 217:268 */     dout.writeBoolean(isESigEnabled());
/* 218:269 */     dout.writeBoolean(isPersistent());
/* 219:270 */     dout.writeBoolean(isChangeTrackingEnabled());
/* 220:    */     
/* 221:272 */     dout.writeBoolean(isRelationshipBased());
/* 222:    */   }
/* 223:    */   
/* 224:    */   public void deserialize(DataInput dis)
/* 225:    */     throws IOException
/* 226:    */   {
/* 227:277 */     setName(dis.readUTF());
/* 228:278 */     setTitle(dis.readUTF());
/* 229:279 */     setDataType(dis.readInt());
/* 230:280 */     setLength(dis.readInt());
/* 231:281 */     setScale(dis.readInt());
/* 232:282 */     setDomainName(dis.readUTF());
/* 233:283 */     setKey(dis.readBoolean());
/* 234:284 */     setReadOnly(dis.readBoolean());
/* 235:285 */     setRequired(dis.readBoolean());
/* 236:286 */     setPositive(dis.readBoolean());
/* 237:287 */     setESigEnabled(dis.readBoolean());
/* 238:288 */     setPersistent(dis.readBoolean());
/* 239:289 */     setChangeTrackingEnabled(dis.readBoolean());
/* 240:    */     
/* 241:291 */     setRelationshipBased(dis.readBoolean());
/* 242:    */   }
/* 243:    */   
/* 244:    */   public boolean isRelationshipBased()
/* 245:    */   {
/* 246:296 */     return this.relationshipBased;
/* 247:    */   }
/* 248:    */   
/* 249:    */   public void setRelationshipBased(boolean relationshipBased)
/* 250:    */   {
/* 251:300 */     this.relationshipBased = relationshipBased;
/* 252:    */   }
/* 253:    */   
/* 254:    */   public boolean isSortable()
/* 255:    */   {
/* 256:306 */     return (this.dataType != 12) && (this.dataType != 8);
/* 257:    */   }
/* 258:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.mbo.MobileMboAttributeInfo
 * JD-Core Version:    0.7.0.1
 */