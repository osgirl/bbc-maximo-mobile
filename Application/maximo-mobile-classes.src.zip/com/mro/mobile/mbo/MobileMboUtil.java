/*   1:    */ package com.mro.mobile.mbo;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.MobileApplicationException;
/*   4:    */ import com.mro.mobile.persist.DefaultRDOAttributeInfo;
/*   5:    */ import com.mro.mobile.persist.DefaultRDOInfo;
/*   6:    */ import com.mro.mobile.persist.RDO;
/*   7:    */ import com.mro.mobile.persist.RDOException;
/*   8:    */ import com.mro.mobile.persist.RDOInfoManager;
/*   9:    */ import com.mro.mobile.persist.RDOManager;
/*  10:    */ import com.mro.mobile.persist.RDORuntime;
/*  11:    */ import com.mro.mobile.util.MobileLogger;
/*  12:    */ import com.mro.mobile.util.MobileLoggerFactory;
/*  13:    */ import java.util.Enumeration;
/*  14:    */ 
/*  15:    */ public class MobileMboUtil
/*  16:    */ {
/*  17:    */   public static final int DURATION_PRECISION = 4;
/*  18:    */   
/*  19:    */   public static void createMboObjectDef(RDORuntime rdoRuntime, MobileMboInfo mboInfo)
/*  20:    */     throws MobileApplicationException
/*  21:    */   {
/*  22: 41 */     RDOManager rdoManager = rdoRuntime.getRDOManager();
/*  23: 42 */     RDOInfoManager rdoInfoManager = rdoRuntime.getRDOInfoManager();
/*  24: 44 */     if (rdoInfoManager.infoExists(mboInfo.getName())) {
/*  25: 46 */       return;
/*  26:    */     }
/*  27: 49 */     DefaultRDOInfo rdoInfo = new DefaultRDOInfo();
/*  28: 51 */     if ((mboInfo.getMobileMboName() == null) || (mboInfo.getMobileMboName().length() == 0)) {
/*  29: 53 */       rdoInfo.setName(mboInfo.getName());
/*  30:    */     } else {
/*  31: 57 */       rdoInfo.setName(mboInfo.getMobileMboName());
/*  32:    */     }
/*  33: 60 */     rdoInfo.setParent(mboInfo.getParent());
/*  34: 61 */     rdoInfo.setHierarchical(mboInfo.isHierarchical());
/*  35: 62 */     MobileMboDependentRelation depRelation = mboInfo.getDependentRelation();
/*  36: 63 */     if (depRelation != null) {
/*  37: 65 */       rdoInfo.setDependentRelation(depRelation);
/*  38:    */     }
/*  39: 69 */     String[] attrNames = mboInfo.getAttributeNames();
/*  40: 70 */     for (int i = 0; i < attrNames.length; i++)
/*  41:    */     {
/*  42: 72 */       MobileMboAttributeInfo attrInfo = mboInfo.getAttributeInfo(attrNames[i]);
/*  43: 73 */       String attrName = attrInfo.getName();
/*  44: 74 */       int attrDataType = attrInfo.getDataType();
/*  45: 75 */       boolean key = attrInfo.isKey();
/*  46: 76 */       int length = attrInfo.getLength();
/*  47: 77 */       int scale = attrInfo.getScale();
/*  48: 78 */       boolean persistent = attrInfo.isPersistent();
/*  49:    */       
/*  50: 80 */       DefaultRDOAttributeInfo attr = new DefaultRDOAttributeInfo();
/*  51: 81 */       attr.setName(attrName);
/*  52: 82 */       attr.setDataType(getRDOAttributeDataType(attrDataType));
/*  53: 83 */       attr.setKey(key);
/*  54: 84 */       attr.setLength(length);
/*  55: 93 */       if (attrDataType != 13) {
/*  56: 94 */         attr.setScale(scale);
/*  57:    */       } else {
/*  58: 97 */         attr.setScale(4);
/*  59:    */       }
/*  60: 99 */       attr.setPersistent(persistent);
/*  61:    */       
/*  62:101 */       rdoInfo.addAttributeInfo(attr);
/*  63:    */     }
/*  64:105 */     String[] dependentNames = mboInfo.getDependentNames();
/*  65:106 */     for (int i = 0; i < dependentNames.length; i++)
/*  66:    */     {
/*  67:108 */       String dependentName = dependentNames[i];
/*  68:109 */       rdoInfo.addDependent(dependentName);
/*  69:    */     }
/*  70:    */     try
/*  71:    */     {
/*  72:114 */       RDO rdo = mboInfo.getRDO();
/*  73:115 */       rdoInfoManager.registerInfo(mboInfo.getName(), rdoInfo);
/*  74:116 */       rdoManager.insert("MAXOBJECT", rdo);
/*  75:    */     }
/*  76:    */     catch (RDOException e)
/*  77:    */     {
/*  78:120 */       MobileLoggerFactory.getDefaultLogger().warn("Failed to create MBO definition", e);
/*  79:121 */       throw new MobileApplicationException("mbodefcreatefailed", new Object[] { mboInfo.getName() });
/*  80:    */     }
/*  81:    */   }
/*  82:    */   
/*  83:    */   public static int getRDOAttributeDataType(int mobileMboDataType)
/*  84:    */   {
/*  85:127 */     int rdoAttributeDataType = 1;
/*  86:129 */     switch (mobileMboDataType)
/*  87:    */     {
/*  88:    */     case 1: 
/*  89:132 */       rdoAttributeDataType = 1;
/*  90:133 */       break;
/*  91:    */     case 2: 
/*  92:135 */       rdoAttributeDataType = 2;
/*  93:136 */       break;
/*  94:    */     case 3: 
/*  95:138 */       rdoAttributeDataType = 3;
/*  96:139 */       break;
/*  97:    */     case 4: 
/*  98:141 */       rdoAttributeDataType = 4;
/*  99:142 */       break;
/* 100:    */     case 5: 
/* 101:144 */       rdoAttributeDataType = 5;
/* 102:145 */       break;
/* 103:    */     case 6: 
/* 104:147 */       rdoAttributeDataType = 6;
/* 105:148 */       break;
/* 106:    */     case 7: 
/* 107:150 */       rdoAttributeDataType = 7;
/* 108:151 */       break;
/* 109:    */     case 13: 
/* 110:153 */       rdoAttributeDataType = 7;
/* 111:154 */       break;
/* 112:    */     case 8: 
/* 113:156 */       rdoAttributeDataType = 8;
/* 114:157 */       break;
/* 115:    */     case 9: 
/* 116:159 */       rdoAttributeDataType = 9;
/* 117:160 */       break;
/* 118:    */     case 10: 
/* 119:162 */       rdoAttributeDataType = 10;
/* 120:163 */       break;
/* 121:    */     case 11: 
/* 122:165 */       rdoAttributeDataType = 11;
/* 123:166 */       break;
/* 124:    */     case 12: 
/* 125:168 */       rdoAttributeDataType = 12;
/* 126:169 */       break;
/* 127:    */     }
/* 128:174 */     return rdoAttributeDataType;
/* 129:    */   }
/* 130:    */   
/* 131:    */   public static MobileMboInfo getMobileMboInfo(String appName, String name)
/* 132:    */   {
/* 133:180 */     MobileMboRuntime mobileMboRuntime = MobileMboRuntime.getInstance(appName);
/* 134:182 */     if (mobileMboRuntime != null) {
/* 135:184 */       return mobileMboRuntime.getMobileMboInfo(name);
/* 136:    */     }
/* 137:187 */     return null;
/* 138:    */   }
/* 139:    */   
/* 140:    */   public static Enumeration getAllMobileMboNames(String appName)
/* 141:    */   {
/* 142:192 */     MobileMboRuntime mobileMboRuntime = MobileMboRuntime.getInstance(appName);
/* 143:193 */     return mobileMboRuntime.getAllMobileMboNames();
/* 144:    */   }
/* 145:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.mbo.MobileMboUtil
 * JD-Core Version:    0.7.0.1
 */