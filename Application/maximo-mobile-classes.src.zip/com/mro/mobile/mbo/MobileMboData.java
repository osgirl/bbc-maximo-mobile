/*   1:    */ package com.mro.mobile.mbo;
/*   2:    */ 
/*   3:    */ import com.mro.mobile.persist.RDO;
/*   4:    */ import com.mro.mobile.persist.RDOSerializer;
/*   5:    */ import com.mro.mobile.type.Serializer;
/*   6:    */ import com.mro.mobile.type.TypeRegistry;
/*   7:    */ import java.io.ByteArrayInputStream;
/*   8:    */ import java.io.ByteArrayOutputStream;
/*   9:    */ import java.io.DataInput;
/*  10:    */ import java.io.DataInputStream;
/*  11:    */ import java.io.DataOutput;
/*  12:    */ import java.io.DataOutputStream;
/*  13:    */ import java.io.IOException;
/*  14:    */ 
/*  15:    */ public class MobileMboData
/*  16:    */   implements Serializer
/*  17:    */ {
/*  18:    */   public static final int ERR_MOBILEMBO_NOTFOUND = -1;
/*  19:    */   public static final int ERR_MBOSET_NOTFOUND = -2;
/*  20:    */   public static final int ERR_MOBILEMBO_PROCESSING = -3;
/*  21: 38 */   private MobileMbo[] mobileMbos = null;
/*  22: 39 */   private int startIndex = 0;
/*  23: 40 */   private int endIndex = 0;
/*  24: 41 */   private int size = 0;
/*  25: 42 */   private boolean moreAvailable = false;
/*  26:    */   
/*  27:    */   public MobileMbo[] getMobileMbos()
/*  28:    */   {
/*  29: 47 */     return this.mobileMbos;
/*  30:    */   }
/*  31:    */   
/*  32:    */   public void setMobileMbos(MobileMbo[] mobileMbos)
/*  33:    */   {
/*  34: 52 */     this.mobileMbos = mobileMbos;
/*  35:    */   }
/*  36:    */   
/*  37:    */   public int getEndIndex()
/*  38:    */   {
/*  39: 58 */     return this.endIndex;
/*  40:    */   }
/*  41:    */   
/*  42:    */   public void setEndIndex(int endIndex)
/*  43:    */   {
/*  44: 63 */     this.endIndex = endIndex;
/*  45:    */   }
/*  46:    */   
/*  47:    */   public boolean isMoreAvailable()
/*  48:    */   {
/*  49: 68 */     return this.moreAvailable;
/*  50:    */   }
/*  51:    */   
/*  52:    */   public void setMoreAvailable(boolean moreAvailable)
/*  53:    */   {
/*  54: 73 */     this.moreAvailable = moreAvailable;
/*  55:    */   }
/*  56:    */   
/*  57:    */   public int getSize()
/*  58:    */   {
/*  59: 77 */     return this.size;
/*  60:    */   }
/*  61:    */   
/*  62:    */   public void setSize(int size)
/*  63:    */   {
/*  64: 82 */     this.size = size;
/*  65:    */   }
/*  66:    */   
/*  67:    */   public int getStartIndex()
/*  68:    */   {
/*  69: 87 */     return this.startIndex;
/*  70:    */   }
/*  71:    */   
/*  72:    */   public void setStartIndex(int startIndex)
/*  73:    */   {
/*  74: 92 */     this.startIndex = startIndex;
/*  75:    */   }
/*  76:    */   
/*  77:    */   public static void initSerializer()
/*  78:    */   {
/*  79: 97 */     MobileMboData i = new MobileMboData();
/*  80: 98 */     TypeRegistry.getTypeRegistry().addType("MobileMboData", i.getClass(), i);
/*  81:    */   }
/*  82:    */   
/*  83:    */   public Object readInstance(DataInput input, String name)
/*  84:    */     throws IOException
/*  85:    */   {
/*  86:104 */     if (name.equals("MobileMboData"))
/*  87:    */     {
/*  88:106 */       int noOfMobileMbos = input.readInt();
/*  89:107 */       int startIndex = input.readInt();
/*  90:108 */       int endIndex = input.readInt();
/*  91:    */       
/*  92:    */ 
/*  93:111 */       input.readInt();
/*  94:112 */       boolean moreAvailable = input.readBoolean();
/*  95:    */       
/*  96:114 */       int[] mboByteSizes = new int[noOfMobileMbos];
/*  97:115 */       for (int i = 0; i < noOfMobileMbos; i++) {
/*  98:117 */         mboByteSizes[i] = input.readInt();
/*  99:    */       }
/* 100:120 */       Object[] mboBytes = new Object[noOfMobileMbos];
/* 101:121 */       for (int i = 0; i < noOfMobileMbos; i++)
/* 102:    */       {
/* 103:123 */         int mboByteSize = mboByteSizes[i];
/* 104:124 */         if (mboByteSize > 0)
/* 105:    */         {
/* 106:126 */           byte[] mboDataBytes = new byte[mboByteSize];
/* 107:127 */           input.readFully(mboDataBytes, 0, mboByteSize);
/* 108:128 */           mboBytes[i] = mboDataBytes;
/* 109:    */         }
/* 110:    */       }
/* 111:132 */       int noOfNullMbos = 0;
/* 112:133 */       RDOSerializer rdoSerializer = new RDOSerializer();
/* 113:134 */       MobileMbo[] mbos = new MobileMbo[noOfMobileMbos];
/* 114:135 */       for (int i = 0; i < noOfMobileMbos; i++)
/* 115:    */       {
/* 116:137 */         int mboByteSize = mboByteSizes[i];
/* 117:138 */         if (mboByteSize == 0)
/* 118:    */         {
/* 119:140 */           noOfNullMbos++;
/* 120:    */         }
/* 121:    */         else
/* 122:    */         {
/* 123:145 */           byte[] mboDataBytes = (byte[])mboBytes[i];
/* 124:    */           try
/* 125:    */           {
/* 126:148 */             ByteArrayInputStream bais = new ByteArrayInputStream(mboDataBytes);
/* 127:149 */             DataInputStream dis = new DataInputStream(bais);
/* 128:150 */             RDO rdo = (RDO)rdoSerializer.readInstance(dis);
/* 129:151 */             mbos[i] = new MobileMbo(rdo);
/* 130:    */           }
/* 131:    */           catch (IOException ex)
/* 132:    */           {
/* 133:156 */             mbos[i] = null;
/* 134:157 */             noOfNullMbos++;
/* 135:    */           }
/* 136:    */         }
/* 137:    */       }
/* 138:161 */       MobileMbo[] validMbos = mbos;
/* 139:163 */       if (noOfNullMbos > 0)
/* 140:    */       {
/* 141:165 */         validMbos = new MobileMbo[noOfMobileMbos - noOfNullMbos];
/* 142:166 */         int j = 0;
/* 143:167 */         for (int i = 0; i < noOfMobileMbos; i++) {
/* 144:169 */           if (mbos[i] != null)
/* 145:    */           {
/* 146:173 */             validMbos[j] = mbos[i];
/* 147:174 */             j++;
/* 148:    */           }
/* 149:    */         }
/* 150:    */       }
/* 151:178 */       MobileMboData x = new MobileMboData();
/* 152:179 */       x.setMobileMbos(validMbos);
/* 153:180 */       x.setStartIndex(startIndex);
/* 154:181 */       x.setEndIndex(endIndex);
/* 155:182 */       x.setSize(validMbos.length);
/* 156:183 */       x.setMoreAvailable(moreAvailable);
/* 157:    */       
/* 158:185 */       return x;
/* 159:    */     }
/* 160:188 */     throw new RuntimeException("The type " + name + " not supported.");
/* 161:    */   }
/* 162:    */   
/* 163:    */   public void writeInstance(DataOutput output, Object obj)
/* 164:    */     throws IOException
/* 165:    */   {
/* 166:193 */     if ((obj instanceof MobileMboData))
/* 167:    */     {
/* 168:195 */       MobileMboData x = (MobileMboData)obj;
/* 169:196 */       int noOfMobileMbos = x.getSize();
/* 170:    */       
/* 171:198 */       output.writeInt(noOfMobileMbos);
/* 172:199 */       output.writeInt(x.getStartIndex());
/* 173:200 */       output.writeInt(x.getEndIndex());
/* 174:201 */       output.writeInt(x.getSize());
/* 175:202 */       output.writeBoolean(x.isMoreAvailable());
/* 176:204 */       if (noOfMobileMbos > 0)
/* 177:    */       {
/* 178:206 */         int[] mboByteSizes = new int[noOfMobileMbos];
/* 179:207 */         Object[] mboBytes = new Object[noOfMobileMbos];
/* 180:208 */         MobileMbo[] mbos = x.getMobileMbos();
/* 181:209 */         for (int i = 0; i < mbos.length; i++) {
/* 182:    */           try
/* 183:    */           {
/* 184:213 */             ByteArrayOutputStream baos = new ByteArrayOutputStream();
/* 185:214 */             DataOutputStream dos = new DataOutputStream(baos);
/* 186:215 */             RDOSerializer rdoSerializer = new RDOSerializer();
/* 187:    */             
/* 188:217 */             MobileMbo mobileMbo = mbos[i];
/* 189:218 */             if (mobileMbo == null)
/* 190:    */             {
/* 191:220 */               mboBytes[i] = new byte[0];
/* 192:221 */               mboByteSizes[i] = 0;
/* 193:    */             }
/* 194:    */             else
/* 195:    */             {
/* 196:225 */               rdoSerializer.writeInstance(dos, mobileMbo.getRDO());
/* 197:226 */               dos.flush();
/* 198:227 */               baos.flush();
/* 199:    */               
/* 200:229 */               byte[] mboDataBytes = baos.toByteArray();
/* 201:230 */               mboBytes[i] = mboDataBytes;
/* 202:231 */               mboByteSizes[i] = mboDataBytes.length;
/* 203:    */             }
/* 204:    */           }
/* 205:    */           catch (IOException ex)
/* 206:    */           {
/* 207:237 */             mboBytes[i] = new byte[0];
/* 208:238 */             mboByteSizes[i] = 0;
/* 209:    */           }
/* 210:    */         }
/* 211:243 */         for (int i = 0; i < mbos.length; i++) {
/* 212:245 */           output.writeInt(mboByteSizes[i]);
/* 213:    */         }
/* 214:249 */         for (int i = 0; i < mbos.length; i++) {
/* 215:251 */           if (mboByteSizes[i] > 0) {
/* 216:253 */             output.write((byte[])mboBytes[i]);
/* 217:    */           }
/* 218:    */         }
/* 219:    */       }
/* 220:    */     }
/* 221:    */   }
/* 222:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.mbo.MobileMboData
 * JD-Core Version:    0.7.0.1
 */