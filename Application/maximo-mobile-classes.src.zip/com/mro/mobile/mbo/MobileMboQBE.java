/*  1:   */ package com.mro.mobile.mbo;
/*  2:   */ 
/*  3:   */ import com.mro.mobile.persist.DefaultQBE;
/*  4:   */ import com.mro.mobile.persist.RDOException;
/*  5:   */ import com.mro.mobile.type.Serializer;
/*  6:   */ import com.mro.mobile.type.TypeRegistry;
/*  7:   */ import java.io.DataInput;
/*  8:   */ import java.io.DataOutput;
/*  9:   */ import java.io.IOException;
/* 10:   */ import java.util.Enumeration;
/* 11:   */ import java.util.Map;
/* 12:   */ 
/* 13:   */ public class MobileMboQBE
/* 14:   */   extends DefaultQBE
/* 15:   */   implements Serializer
/* 16:   */ {
/* 17:   */   public static void initSerializer()
/* 18:   */   {
/* 19:32 */     MobileMboQBE i = new MobileMboQBE();
/* 20:33 */     TypeRegistry.getTypeRegistry().addType("MobileMboQBE", i.getClass(), i);
/* 21:   */   }
/* 22:   */   
/* 23:   */   public Object readInstance(DataInput input, String name)
/* 24:   */     throws IOException
/* 25:   */   {
/* 26:38 */     if (name.equals("MobileMboQBE")) {
/* 27:   */       try
/* 28:   */       {
/* 29:42 */         MobileMboQBE mboQbe = new MobileMboQBE();
/* 30:43 */         int noOfAttributes = input.readInt();
/* 31:44 */         for (int i = 0; i < noOfAttributes; i++)
/* 32:   */         {
/* 33:46 */           String attribute = input.readUTF();
/* 34:47 */           String value = input.readUTF();
/* 35:   */           
/* 36:49 */           mboQbe.setQBE(attribute, value);
/* 37:   */         }
/* 38:52 */         boolean exactMatch = input.readBoolean();
/* 39:53 */         mboQbe.setQbeExactMatch(exactMatch);
/* 40:   */         
/* 41:55 */         return mboQbe;
/* 42:   */       }
/* 43:   */       catch (RDOException e)
/* 44:   */       {
/* 45:59 */         throw new IOException(e.getMessage());
/* 46:   */       }
/* 47:   */     }
/* 48:63 */     throw new RuntimeException("The type " + name + " not supported.");
/* 49:   */   }
/* 50:   */   
/* 51:   */   public void writeInstance(DataOutput output, Object obj)
/* 52:   */     throws IOException
/* 53:   */   {
/* 54:68 */     if ((obj instanceof MobileMboQBE)) {
/* 55:   */       try
/* 56:   */       {
/* 57:72 */         MobileMboQBE mboQbe = (MobileMboQBE)obj;
/* 58:   */         
/* 59:74 */         output.writeInt(mboQbe.size());
/* 60:75 */         Enumeration qbeAttrEnum = mboQbe.getQBEAttributes();
/* 61:76 */         while (qbeAttrEnum.hasMoreElements())
/* 62:   */         {
/* 63:78 */           String attribute = (String)qbeAttrEnum.nextElement();
/* 64:79 */           String value = mboQbe.getQBE(attribute);
/* 65:80 */           output.writeUTF(attribute);
/* 66:81 */           output.writeUTF(value);
/* 67:   */         }
/* 68:84 */         Enumeration qbeParamEnum = mboQbe.getLookupParameters();
/* 69:85 */         while (qbeParamEnum.hasMoreElements())
/* 70:   */         {
/* 71:87 */           Map key = (Map)qbeParamEnum.nextElement();
/* 72:88 */           String objectName = (String)key.get("OBJECT");
/* 73:89 */           String attributeName = (String)key.get("FIELD");
/* 74:   */           
/* 75:91 */           String value = mboQbe.getLookupParameter(objectName, attributeName);
/* 76:92 */           output.writeUTF(mboQbe.getRawLookupParameterKey(objectName, attributeName));
/* 77:93 */           output.writeUTF(value);
/* 78:   */         }
/* 79:95 */         output.writeBoolean(mboQbe.isQbeExactMatch());
/* 80:   */       }
/* 81:   */       catch (RDOException e)
/* 82:   */       {
/* 83:99 */         throw new IOException(e.getMessage());
/* 84:   */       }
/* 85:   */     }
/* 86:   */   }
/* 87:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.mbo.MobileMboQBE
 * JD-Core Version:    0.7.0.1
 */