/*  1:   */ package com.mro.mobile.mbo;
/*  2:   */ 
/*  3:   */ import com.mro.mobile.type.Serializer;
/*  4:   */ import com.mro.mobile.type.TypeRegistry;
/*  5:   */ import com.mro.mobile.util.MobileLogger;
/*  6:   */ import com.mro.mobile.util.MobileLoggerFactory;
/*  7:   */ import java.io.DataInput;
/*  8:   */ import java.io.DataOutput;
/*  9:   */ import java.io.IOException;
/* 10:   */ 
/* 11:   */ public class MobileMboDataPage
/* 12:   */   implements Serializer
/* 13:   */ {
/* 14:   */   String[][] attributeValues;
/* 15:   */   
/* 16:   */   public String getValue(int rowIndex, int attributeIndex)
/* 17:   */   {
/* 18:30 */     return this.attributeValues[rowIndex][attributeIndex];
/* 19:   */   }
/* 20:   */   
/* 21:   */   public void setPageData(String[][] data)
/* 22:   */   {
/* 23:35 */     this.attributeValues = data;
/* 24:   */   }
/* 25:   */   
/* 26:   */   public String[][] getPageData()
/* 27:   */   {
/* 28:40 */     return this.attributeValues;
/* 29:   */   }
/* 30:   */   
/* 31:   */   static
/* 32:   */   {
/* 33:   */     try
/* 34:   */     {
/* 35:47 */       MobileMboDataPage i = new MobileMboDataPage();
/* 36:48 */       TypeRegistry.getTypeRegistry().addType("MobileMboDataPage", i.getClass(), i);
/* 37:   */     }
/* 38:   */     catch (Exception e)
/* 39:   */     {
/* 40:52 */       MobileLoggerFactory.getDefaultLogger().warn("Failed to register new type", e);
/* 41:   */     }
/* 42:   */   }
/* 43:   */   
/* 44:   */   public Object readInstance(DataInput input, String name)
/* 45:   */     throws IOException
/* 46:   */   {
/* 47:59 */     if (name.equals("MobileMboDataPage"))
/* 48:   */     {
/* 49:61 */       MobileMboDataPage dataPage = new MobileMboDataPage();
/* 50:   */       
/* 51:63 */       int noOfRows = input.readInt();
/* 52:64 */       dataPage.attributeValues = new String[noOfRows][];
/* 53:65 */       for (int i = 0; i < noOfRows; i++)
/* 54:   */       {
/* 55:67 */         int noOfAttributes = input.readInt();
/* 56:68 */         dataPage.attributeValues[i] = new String[noOfAttributes];
/* 57:69 */         for (int j = 0; j < noOfAttributes; j++) {
/* 58:71 */           dataPage.attributeValues[i][j] = input.readUTF();
/* 59:   */         }
/* 60:   */       }
/* 61:75 */       return dataPage;
/* 62:   */     }
/* 63:78 */     throw new RuntimeException("The type " + name + " not supported.");
/* 64:   */   }
/* 65:   */   
/* 66:   */   public void writeInstance(DataOutput output, Object obj)
/* 67:   */     throws IOException
/* 68:   */   {
/* 69:83 */     if ((obj instanceof MobileMboDataPage))
/* 70:   */     {
/* 71:85 */       MobileMboDataPage dataPage = (MobileMboDataPage)obj;
/* 72:   */       
/* 73:87 */       output.writeInt(dataPage.attributeValues.length);
/* 74:88 */       for (int i = 0; i < dataPage.attributeValues.length; i++)
/* 75:   */       {
/* 76:90 */         output.writeInt(dataPage.attributeValues[i].length);
/* 77:91 */         for (int j = 0; j < dataPage.attributeValues[i].length; j++) {
/* 78:93 */           output.writeUTF(dataPage.attributeValues[i][j]);
/* 79:   */         }
/* 80:   */       }
/* 81:   */     }
/* 82:   */   }
/* 83:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.mbo.MobileMboDataPage
 * JD-Core Version:    0.7.0.1
 */