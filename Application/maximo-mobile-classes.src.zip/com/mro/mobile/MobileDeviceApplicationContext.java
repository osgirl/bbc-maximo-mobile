/*  1:   */ package com.mro.mobile;
/*  2:   */ 
/*  3:   */ public class MobileDeviceApplicationContext
/*  4:   */   implements MobileContext
/*  5:   */ {
/*  6:18 */   private String appName = null;
/*  7:   */   
/*  8:   */   public MobileDeviceApplicationContext(String appName)
/*  9:   */   {
/* 10:22 */     this.appName = appName;
/* 11:   */   }
/* 12:   */   
/* 13:   */   public String getAppName()
/* 14:   */     throws MobileApplicationException
/* 15:   */   {
/* 16:27 */     return this.appName;
/* 17:   */   }
/* 18:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.MobileDeviceApplicationContext
 * JD-Core Version:    0.7.0.1
 */