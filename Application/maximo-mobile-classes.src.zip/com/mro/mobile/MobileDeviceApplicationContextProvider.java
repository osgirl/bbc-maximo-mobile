/*  1:   */ package com.mro.mobile;
/*  2:   */ 
/*  3:   */ public class MobileDeviceApplicationContextProvider
/*  4:   */   implements MobileContextProvider
/*  5:   */ {
/*  6:18 */   private MobileDeviceApplicationContext deviceAppContext = null;
/*  7:   */   
/*  8:   */   public MobileDeviceApplicationContextProvider(String appName)
/*  9:   */   {
/* 10:23 */     this.deviceAppContext = new MobileDeviceApplicationContext(appName);
/* 11:   */   }
/* 12:   */   
/* 13:   */   public MobileContext getMobileContext()
/* 14:   */     throws MobileApplicationException
/* 15:   */   {
/* 16:29 */     return this.deviceAppContext;
/* 17:   */   }
/* 18:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.MobileDeviceApplicationContextProvider
 * JD-Core Version:    0.7.0.1
 */