/*  1:   */ package com.mro.mobile;
/*  2:   */ 
/*  3:   */ public class MobileInitialContext
/*  4:   */   implements MobileContext
/*  5:   */ {
/*  6:18 */   private static MobileContextProvider defaultMobileContextProvider = null;
/*  7:   */   
/*  8:   */   public static void setMobileContextProvider(MobileContextProvider f)
/*  9:   */   {
/* 10:23 */     defaultMobileContextProvider = f;
/* 11:   */   }
/* 12:   */   
/* 13:   */   public MobileContextProvider getMobileContextProvider()
/* 14:   */   {
/* 15:28 */     return defaultMobileContextProvider;
/* 16:   */   }
/* 17:   */   
/* 18:   */   protected MobileContext getDefaultInitCtx()
/* 19:   */     throws MobileApplicationException
/* 20:   */   {
/* 21:34 */     if (defaultMobileContextProvider == null) {
/* 22:36 */       throw new MobileApplicationException("nomobilecontextprovider");
/* 23:   */     }
/* 24:39 */     return defaultMobileContextProvider.getMobileContext();
/* 25:   */   }
/* 26:   */   
/* 27:   */   public String getAppName()
/* 28:   */     throws MobileApplicationException
/* 29:   */   {
/* 30:44 */     return getDefaultInitCtx().getAppName();
/* 31:   */   }
/* 32:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobile.MobileInitialContext
 * JD-Core Version:    0.7.0.1
 */