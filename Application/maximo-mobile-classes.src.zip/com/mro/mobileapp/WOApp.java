/*    1:     */ package com.mro.mobileapp;
/*    2:     */ 
/*    3:     */ import com.mro.mobile.MobileApplicationException;
/*    4:     */ import com.mro.mobile.ProgressObserver;
/*    5:     */ import com.mro.mobile.app.BasicMobileDeviceUIApplication;
/*    6:     */ import com.mro.mobile.app.DefaultMobileWebServiceProxy;
/*    7:     */ import com.mro.mobile.app.OperationContainer;
/*    8:     */ import com.mro.mobile.app.mobilewo.AssetMenuBarEventHandler;
/*    9:     */ import com.mro.mobile.app.mobilewo.AssetSpecEventHandler;
/*   10:     */ import com.mro.mobile.app.mobilewo.BulkLaborReportingLabTransEventHandler;
/*   11:     */ import com.mro.mobile.app.mobilewo.ChangeOwnerEventHandler;
/*   12:     */ import com.mro.mobile.app.mobilewo.ClassifSpecEventHandler;
/*   13:     */ import com.mro.mobile.app.mobilewo.CommonLabTransOperationHandler;
/*   14:     */ import com.mro.mobile.app.mobilewo.CreateCommEventHandler;
/*   15:     */ import com.mro.mobile.app.mobilewo.CrewLaborReportingEventHandler;
/*   16:     */ import com.mro.mobile.app.mobilewo.CustomWOHandler;
/*   17:     */ import com.mro.mobile.app.mobilewo.LinearAssetEventHandler;
/*   18:     */ import com.mro.mobile.app.mobilewo.LocMenuBarEventHandler;
/*   19:     */ import com.mro.mobile.app.mobilewo.LockOutTagOutEventHandler;
/*   20:     */ import com.mro.mobile.app.mobilewo.MatRequestEventHandler;
/*   21:     */ import com.mro.mobile.app.mobilewo.MobileWOAppEventHandler;
/*   22:     */ import com.mro.mobile.app.mobilewo.MobileWOWebServiceProxy;
/*   23:     */ import com.mro.mobile.app.mobilewo.RelRecEventHandler;
/*   24:     */ import com.mro.mobile.app.mobilewo.SelectPlannedLaborEventHandler;
/*   25:     */ import com.mro.mobile.app.mobilewo.SelectPlannedMaterialEventHandler;
/*   26:     */ import com.mro.mobile.app.mobilewo.SelectPlannedToolEventHandler;
/*   27:     */ import com.mro.mobile.app.mobilewo.SimilarTicketEventHandler;
/*   28:     */ import com.mro.mobile.app.mobilewo.SrvRequestEventHandler;
/*   29:     */ import com.mro.mobile.app.mobilewo.TKChangeStatusEventHandler;
/*   30:     */ import com.mro.mobile.app.mobilewo.TKEventHandler;
/*   31:     */ import com.mro.mobile.app.mobilewo.TKLabTransOperationHandler;
/*   32:     */ import com.mro.mobile.app.mobilewo.TKMenuBarEventHandler;
/*   33:     */ import com.mro.mobile.app.mobilewo.TKMultiEventHandler;
/*   34:     */ import com.mro.mobile.app.mobilewo.TktDoneOperationHandler;
/*   35:     */ import com.mro.mobile.app.mobilewo.WOAllPlanEventHandler;
/*   36:     */ import com.mro.mobile.app.mobilewo.WOChangeStatusEventHandler;
/*   37:     */ import com.mro.mobile.app.mobilewo.WODirectDownloadEventHandler;
/*   38:     */ import com.mro.mobile.app.mobilewo.WODoneOperationHandler;
/*   39:     */ import com.mro.mobile.app.mobilewo.WODowntimeEventHandler;
/*   40:     */ import com.mro.mobile.app.mobilewo.WOEventHandler;
/*   41:     */ import com.mro.mobile.app.mobilewo.WOFailCodeEventHandler;
/*   42:     */ import com.mro.mobile.app.mobilewo.WOLabTransEventHandler;
/*   43:     */ import com.mro.mobile.app.mobilewo.WOLabTransOperationHandler;
/*   44:     */ import com.mro.mobile.app.mobilewo.WOLaborCraftRateEventHandler;
/*   45:     */ import com.mro.mobile.app.mobilewo.WOMatTransEventHandler;
/*   46:     */ import com.mro.mobile.app.mobilewo.WOMenuBarEventHandler;
/*   47:     */ import com.mro.mobile.app.mobilewo.WOMeterReadingEventHandler;
/*   48:     */ import com.mro.mobile.app.mobilewo.WOMoveAssetEventHandler;
/*   49:     */ import com.mro.mobile.app.mobilewo.WOMultiEventHandler;
/*   50:     */ import com.mro.mobile.app.mobilewo.WOSpecEventHandler;
/*   51:     */ import com.mro.mobile.app.mobilewo.WOToolTransEventHandler;
/*   52:     */ import com.mro.mobile.app.pluscmobwo.PlusCMobRepeatabilityEventHandler;
/*   53:     */ import com.mro.mobile.comm.impl.HTTPCommunicationChannel;
/*   54:     */ import com.mro.mobile.mbo.MobileMbo;
/*   55:     */ import com.mro.mobile.mbo.MobileMboAttributeInfo;
/*   56:     */ import com.mro.mobile.mbo.MobileMboChange;
/*   57:     */ import com.mro.mobile.mbo.MobileMboInfo;
/*   58:     */ import com.mro.mobile.mbo.MobileMboQBE;
/*   59:     */ import com.mro.mobile.persist.DefaultRDO;
/*   60:     */ import com.mro.mobile.persist.RDO;
/*   61:     */ import com.mro.mobile.persist.RDOEnumeration;
/*   62:     */ import com.mro.mobile.persist.RDOException;
/*   63:     */ import com.mro.mobile.persist.RDOManager;
/*   64:     */ import com.mro.mobile.persist.RDORuntime;
/*   65:     */ import com.mro.mobile.persist.RDOTransactionManager;
/*   66:     */ import com.mro.mobile.ui.DataBeanCache;
/*   67:     */ import com.mro.mobile.ui.DataBeanCacheItem;
/*   68:     */ import com.mro.mobile.ui.MobileMboDataBean;
/*   69:     */ import com.mro.mobile.ui.MobileMboDataBeanManager;
/*   70:     */ import com.mro.mobile.ui.UIHandlerManager;
/*   71:     */ import com.mro.mobile.ui.event.UIEventHandler;
/*   72:     */ import com.mro.mobile.ui.res.MobileUIManager;
/*   73:     */ import com.mro.mobile.ui.res.handlers.LoginHandler;
/*   74:     */ import com.mro.mobile.util.MobileLogger;
/*   75:     */ import com.mro.mobile.util.MobileLoggerFactory;
/*   76:     */ import java.util.ArrayList;
/*   77:     */ import java.util.Date;
/*   78:     */ import java.util.GregorianCalendar;
/*   79:     */ import java.util.HashSet;
/*   80:     */ import java.util.Hashtable;
/*   81:     */ import java.util.Set;
/*   82:     */ 
/*   83:     */ public class WOApp
/*   84:     */   extends BasicMobileDeviceUIApplication
/*   85:     */ {
/*   86:     */   protected static Hashtable htPageTabMap;
/*   87:     */   
/*   88:     */   public WOApp(MobileUIManager uiManager)
/*   89:     */   {
/*   90:  61 */     super(uiManager);
/*   91:     */   }
/*   92:     */   
/*   93:  66 */   private static MobileLogger DBLOGGER = MobileLoggerFactory.getLogger("maximo.mobile.persistence");
/*   94:     */   
/*   95:     */   protected DefaultMobileWebServiceProxy createMobileWebServiceProxy()
/*   96:     */     throws MobileApplicationException
/*   97:     */   {
/*   98:  72 */     MobileWOWebServiceProxy proxy = new MobileWOWebServiceProxy(getAppName());
/*   99:  73 */     proxy.setCommunicationChannel(new HTTPCommunicationChannel());
/*  100:     */     
/*  101:  75 */     initProxy(proxy);
/*  102:     */     
/*  103:  77 */     return proxy;
/*  104:     */   }
/*  105:     */   
/*  106:     */   protected UIEventHandler createEventHandler()
/*  107:     */     throws MobileApplicationException
/*  108:     */   {
/*  109:  82 */     UIHandlerManager hMan = UIHandlerManager.getInstance();
/*  110:  83 */     hMan.registerHandler("loginhandler", new LoginHandler());
/*  111:     */     
/*  112:  85 */     hMan.registerHandler("wohandler", new WOEventHandler());
/*  113:  86 */     hMan.registerHandler("womenubarhandler", new WOMenuBarEventHandler());
/*  114:     */     
/*  115:  88 */     hMan.registerHandler("assetmenubarhandler", new AssetMenuBarEventHandler());
/*  116:  89 */     hMan.registerHandler("locmenubarhandler", new LocMenuBarEventHandler());
/*  117:  90 */     hMan.registerHandler("servicerequesthandler", new SrvRequestEventHandler());
/*  118:  91 */     hMan.registerHandler("wospecshandler", new WOSpecEventHandler());
/*  119:  92 */     hMan.registerHandler("assetspechandler", new AssetSpecEventHandler());
/*  120:  93 */     hMan.registerHandler("womoveassethandler", new WOMoveAssetEventHandler());
/*  121:     */     
/*  122:  95 */     hMan.registerHandler("wochangestatushandler", new WOChangeStatusEventHandler());
/*  123:     */     
/*  124:     */ 
/*  125:     */ 
/*  126:  99 */     hMan.registerHandler("bulklaborreportinghandler", new BulkLaborReportingLabTransEventHandler());
/*  127:     */     
/*  128: 101 */     hMan.registerHandler("wolabtranshandler", new WOLabTransEventHandler());
/*  129: 102 */     hMan.registerHandler("womattranshandler", new WOMatTransEventHandler());
/*  130:     */     
/*  131: 104 */     hMan.registerHandler("wotooltranshandler", new WOToolTransEventHandler());
/*  132:     */     
/*  133: 106 */     hMan.registerHandler("wofailcodehandler", new WOFailCodeEventHandler());
/*  134: 107 */     hMan.registerHandler("wolaborcraftratehandler", new WOLaborCraftRateEventHandler());
/*  135: 108 */     hMan.registerHandler("plannedlaborhandler", new SelectPlannedLaborEventHandler());
/*  136: 109 */     hMan.registerHandler("plannedmathandler", new SelectPlannedMaterialEventHandler());
/*  137: 110 */     hMan.registerHandler("plannedtoolhandler", new SelectPlannedToolEventHandler());
/*  138: 111 */     hMan.registerHandler("wodowntimehandler", new WODowntimeEventHandler());
/*  139: 112 */     hMan.registerHandler("wometerreadinghandler", new WOMeterReadingEventHandler());
/*  140: 113 */     hMan.registerHandler("woallplanhandler", new WOAllPlanEventHandler());
/*  141: 114 */     hMan.registerHandler("createcommhandler", new CreateCommEventHandler());
/*  142: 115 */     hMan.registerHandler("lockouttagouthandler", new LockOutTagOutEventHandler());
/*  143: 116 */     hMan.registerHandler("materialrequesthandler", new MatRequestEventHandler());
/*  144:     */     
/*  145: 118 */     hMan.registerHandler("tkhandler", new TKEventHandler());
/*  146: 119 */     hMan.registerHandler("tkmenubarhandler", new TKMenuBarEventHandler());
/*  147: 120 */     hMan.registerHandler("tkchangestatushandler", new TKChangeStatusEventHandler());
/*  148:     */     
/*  149: 122 */     hMan.registerHandler("changeownerhandler", new ChangeOwnerEventHandler());
/*  150: 123 */     hMan.registerHandler("simularticketshandler", new SimilarTicketEventHandler());
/*  151:     */     
/*  152: 125 */     hMan.registerHandler("relreceventhandler", new RelRecEventHandler());
/*  153:     */     
/*  154: 127 */     hMan.registerHandler("directdownloadeventhandler", new WODirectDownloadEventHandler());
/*  155: 128 */     hMan.registerHandler("customwohandler", new CustomWOHandler());
/*  156:     */     
/*  157: 130 */     hMan.registerHandler("womultihandler", new WOMultiEventHandler());
/*  158: 131 */     hMan.registerHandler("tkmultihandler", new TKMultiEventHandler());
/*  159:     */     
/*  160: 133 */     hMan.registerHandler("classifspechandler", new ClassifSpecEventHandler());
/*  161:     */     
/*  162: 135 */     hMan.registerHandler("crewlaborreportinghandler", new CrewLaborReportingEventHandler());
/*  163:     */     
/*  164: 137 */     hMan.registerHandler("linearassethandler", new LinearAssetEventHandler());
/*  165:     */     
/*  166:     */ 
/*  167: 140 */     hMan.registerHandler("PlusCMobRepeatabilityEventHandler", new PlusCMobRepeatabilityEventHandler());
/*  168:     */     
/*  169:     */ 
/*  170: 143 */     return new MobileWOAppEventHandler();
/*  171:     */   }
/*  172:     */   
/*  173:     */   public void createServiceRequest(MobileMbo servreq)
/*  174:     */     throws MobileApplicationException
/*  175:     */   {
/*  176: 148 */     MobileWOWebServiceProxy proxy = (MobileWOWebServiceProxy)getDefaultMobileWebServiceProxy();
/*  177: 149 */     proxy.createServiceRequest(new MobileMboChange(servreq));
/*  178:     */   }
/*  179:     */   
/*  180:     */   public void initializeApplication()
/*  181:     */     throws MobileApplicationException
/*  182:     */   {
/*  183: 156 */     registerOperationHandler("done", "WORKORDER", new WODoneOperationHandler());
/*  184: 157 */     registerOperationHandler("done", "TICKET", new TktDoneOperationHandler());
/*  185:     */     
/*  186: 159 */     registerOperationHandler("undo", "WORKORDER", new WODoneOperationHandler());
/*  187: 160 */     registerOperationHandler("undo", "TICKET", new TktDoneOperationHandler());
/*  188:     */     
/*  189: 162 */     registerOperationHandler("save", "WORKORDER", new WODoneOperationHandler());
/*  190: 163 */     registerOperationHandler("save", "TICKET", new TktDoneOperationHandler());
/*  191:     */     
/*  192:     */ 
/*  193: 166 */     registerOperationHandler("save", "WOLABTRANS", new WOLabTransOperationHandler());
/*  194: 167 */     registerOperationHandler("save", "TKLABTRANS", new TKLabTransOperationHandler());
/*  195:     */     
/*  196: 169 */     getWpAllFlags();
/*  197: 170 */     htPageTabMap = initPageTabMapHashtable();
/*  198:     */   }
/*  199:     */   
/*  200:     */   public String getInternalValue(MobileMboDataBean databean, String listname, String maxvalue)
/*  201:     */     throws MobileApplicationException
/*  202:     */   {
/*  203: 176 */     return getDomainValue(databean, listname, maxvalue, "VALUE", "MAXVALUE");
/*  204:     */   }
/*  205:     */   
/*  206:     */   public String getExternalValue(MobileMboDataBean databean, String listname, String maxvalue)
/*  207:     */     throws MobileApplicationException
/*  208:     */   {
/*  209: 183 */     return getDomainValue(databean, listname, maxvalue, "MAXVALUE", "VALUE");
/*  210:     */   }
/*  211:     */   
/*  212:     */   private String getDomainValue(MobileMboDataBean databean, String listname, String maxvalue, String searchField, String returnField)
/*  213:     */     throws MobileApplicationException
/*  214:     */   {
/*  215: 193 */     String siteid = (databean == null) || (databean.getValue("SITEID") == null) ? "" : databean.getValue("SITEID");
/*  216: 194 */     String orgid = (databean == null) || (databean.getValue("ORGID") == null) ? "" : databean.getValue("ORGID");
/*  217:     */     
/*  218: 196 */     String value = "";
/*  219: 197 */     MobileMbo listMbo = null;
/*  220:     */     
/*  221: 199 */     boolean useDefaults = false;
/*  222: 200 */     if (returnField.equalsIgnoreCase("VALUE")) {
/*  223: 201 */       useDefaults = true;
/*  224:     */     }
/*  225: 203 */     String indexName = listname + searchField;
/*  226: 204 */     MobileMboDataBean listBean = DataBeanCache.getDataBean(listname, listname);
/*  227:     */     
/*  228: 206 */     int count = listBean.count();
/*  229: 207 */     listBean.dataExists(count);
/*  230: 208 */     listBean.close();
/*  231:     */     
/*  232: 210 */     listBean.indexMobileMboDataBean(indexName, new String[] { "SITEID", "ORGID", searchField }, false);
/*  233: 211 */     listBean.indexMobileMboDataBean(indexName + "DEFAULTS", new String[] { "SITEID", "ORGID", searchField, "DEFAULTS" }, false);
/*  234: 214 */     if (!siteid.equals(""))
/*  235:     */     {
/*  236: 215 */       if (useDefaults) {
/*  237: 216 */         listMbo = listBean.getIndexedMobileMbo(indexName + "DEFAULTS", new String[] { siteid, "", maxvalue, "1" });
/*  238:     */       } else {
/*  239: 218 */         listMbo = listBean.getIndexedMobileMbo(indexName, new String[] { siteid, "", maxvalue });
/*  240:     */       }
/*  241: 220 */       if (listMbo != null) {
/*  242: 221 */         return listMbo.getValue(returnField);
/*  243:     */       }
/*  244:     */     }
/*  245: 226 */     if (!orgid.equals(""))
/*  246:     */     {
/*  247: 227 */       if (useDefaults) {
/*  248: 228 */         listMbo = listBean.getIndexedMobileMbo(indexName + "DEFAULTS", new String[] { "", orgid, maxvalue, "1" });
/*  249:     */       } else {
/*  250: 230 */         listMbo = listBean.getIndexedMobileMbo(indexName, new String[] { "", orgid, maxvalue });
/*  251:     */       }
/*  252: 232 */       if (listMbo != null) {
/*  253: 233 */         return listMbo.getValue(returnField);
/*  254:     */       }
/*  255:     */     }
/*  256: 238 */     if ((!orgid.equals("")) && (!siteid.equals("")))
/*  257:     */     {
/*  258: 239 */       if (useDefaults) {
/*  259: 240 */         listMbo = listBean.getIndexedMobileMbo(indexName + "DEFAULTS", new String[] { siteid, orgid, maxvalue, "1" });
/*  260:     */       } else {
/*  261: 242 */         listMbo = listBean.getIndexedMobileMbo(indexName, new String[] { siteid, orgid, maxvalue });
/*  262:     */       }
/*  263: 244 */       if (listMbo != null) {
/*  264: 245 */         return listMbo.getValue(returnField);
/*  265:     */       }
/*  266:     */     }
/*  267: 250 */     if (useDefaults) {
/*  268: 251 */       listMbo = listBean.getIndexedMobileMbo(indexName + "DEFAULTS", new String[] { "", "", maxvalue, "1" });
/*  269:     */     } else {
/*  270: 253 */       listMbo = listBean.getIndexedMobileMbo(indexName, new String[] { "", "", maxvalue });
/*  271:     */     }
/*  272: 255 */     if (listMbo != null) {
/*  273: 256 */       return listMbo.getValue(returnField);
/*  274:     */     }
/*  275: 259 */     return value;
/*  276:     */   }
/*  277:     */   
/*  278:     */   public String getDefaultValue(MobileMboDataBean databean, String listname, String maxvalue)
/*  279:     */     throws MobileApplicationException
/*  280:     */   {
/*  281: 267 */     String siteid = (databean == null) || (databean.getValue("SITEID") == null) ? "" : databean.getValue("SITEID");
/*  282: 268 */     String orgid = (databean == null) || (databean.getValue("ORGID") == null) ? "" : databean.getValue("ORGID");
/*  283:     */     
/*  284: 270 */     String value = "";
/*  285: 271 */     MobileMbo listMbo = null;
/*  286:     */     
/*  287: 273 */     MobileMboDataBean listBean = DataBeanCache.getDataBean(listname, listname);
/*  288:     */     
/*  289: 275 */     int count = listBean.count();
/*  290: 276 */     listBean.dataExists(count);
/*  291: 277 */     listBean.close();
/*  292:     */     
/*  293: 279 */     listBean.indexMobileMboDataBean(listname + "DEFAULTS", new String[] { "SITEID", "ORGID", "MAXVALUE", "DEFAULTS" }, false);
/*  294: 282 */     if (!siteid.equals(""))
/*  295:     */     {
/*  296: 283 */       listMbo = listBean.getIndexedMobileMbo(listname + "DEFAULTS", new String[] { siteid, "", maxvalue, "1" });
/*  297: 284 */       if (listMbo != null) {
/*  298: 285 */         return listMbo.getValue("VALUE");
/*  299:     */       }
/*  300:     */     }
/*  301: 290 */     if (!orgid.equals(""))
/*  302:     */     {
/*  303: 291 */       listMbo = listBean.getIndexedMobileMbo(listname + "DEFAULTS", new String[] { "", orgid, maxvalue, "1" });
/*  304: 293 */       if (listMbo != null) {
/*  305: 294 */         return listMbo.getValue("VALUE");
/*  306:     */       }
/*  307:     */     }
/*  308: 299 */     if ((!orgid.equals("")) && (!siteid.equals("")))
/*  309:     */     {
/*  310: 300 */       listMbo = listBean.getIndexedMobileMbo(listname + "DEFAULTS", new String[] { siteid, orgid, maxvalue, "1" });
/*  311: 301 */       if (listMbo != null) {
/*  312: 302 */         return listMbo.getValue("VALUE");
/*  313:     */       }
/*  314:     */     }
/*  315: 307 */     listMbo = listBean.getIndexedMobileMbo(listname + "DEFAULTS", new String[] { "", "", maxvalue, "1" });
/*  316: 308 */     if (listMbo != null) {
/*  317: 309 */       return listMbo.getValue("VALUE");
/*  318:     */     }
/*  319: 312 */     return value;
/*  320:     */   }
/*  321:     */   
/*  322:     */   public String getSynonymValues(MobileMboDataBean databean, String listname, String maxvalue)
/*  323:     */     throws MobileApplicationException
/*  324:     */   {
/*  325: 322 */     String synStr = "";
/*  326: 323 */     MobileMbo listMbo = null;
/*  327:     */     
/*  328: 325 */     MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager(listname);
/*  329: 326 */     MobileMboDataBean listBean = mgrDBMgr.getDataBean();
/*  330:     */     
/*  331:     */ 
/*  332: 329 */     listBean.getQBE().reset();
/*  333: 330 */     listBean.getQBE().setQbeExactMatch(true);
/*  334: 331 */     listBean.getQBE().setQBE("SITEID", databean.getValue("SITEID"));
/*  335: 332 */     listBean.getQBE().setQBE("MAXVALUE", maxvalue);
/*  336: 333 */     listBean.reset();
/*  337: 334 */     listMbo = listBean.getMobileMbo(0);
/*  338: 335 */     if (listMbo != null)
/*  339:     */     {
/*  340: 338 */       listBean.getQBE().reset();
/*  341: 339 */       listBean.getQBE().setQbeExactMatch(true);
/*  342: 340 */       listBean.getQBE().setQBE("SITEID", databean.getValue("SITEID"));
/*  343: 341 */       listBean.getQBE().setQBE("MAXVALUE", maxvalue);
/*  344: 342 */       listBean.reset();
/*  345: 343 */       synStr = createSynString(listBean);
/*  346:     */       
/*  347: 345 */       return synStr;
/*  348:     */     }
/*  349: 349 */     listBean.getQBE().reset();
/*  350: 350 */     listBean.getQBE().setQbeExactMatch(true);
/*  351: 351 */     listBean.getQBE().setQBE("ORGID", databean.getValue("ORGID"));
/*  352: 352 */     listBean.getQBE().setQBE("SITEID", "~NULL~");
/*  353: 353 */     listBean.getQBE().setQBE("MAXVALUE", maxvalue);
/*  354: 354 */     listBean.reset();
/*  355: 355 */     listMbo = listBean.getMobileMbo(0);
/*  356: 356 */     if (listMbo != null)
/*  357:     */     {
/*  358: 359 */       listBean.getQBE().reset();
/*  359: 360 */       listBean.getQBE().setQbeExactMatch(true);
/*  360: 361 */       listBean.getQBE().setQBE("ORGID", databean.getValue("ORGID"));
/*  361: 362 */       listBean.getQBE().setQBE("SITEID", "~NULL~");
/*  362: 363 */       listBean.getQBE().setQBE("MAXVALUE", maxvalue);
/*  363: 364 */       listBean.reset();
/*  364: 365 */       synStr = createSynString(listBean);
/*  365:     */       
/*  366: 367 */       return synStr;
/*  367:     */     }
/*  368: 371 */     listBean.getQBE().reset();
/*  369: 372 */     listBean.getQBE().setQbeExactMatch(true);
/*  370: 373 */     listBean.getQBE().setQBE("SITEID", "~NULL~");
/*  371: 374 */     listBean.getQBE().setQBE("ORGID", "~NULL~");
/*  372: 375 */     listBean.getQBE().setQBE("MAXVALUE", maxvalue);
/*  373: 376 */     listBean.reset();
/*  374: 377 */     listMbo = listBean.getMobileMbo(0);
/*  375: 378 */     if (listMbo != null)
/*  376:     */     {
/*  377: 381 */       listBean.getQBE().reset();
/*  378: 382 */       listBean.getQBE().setQbeExactMatch(true);
/*  379: 383 */       listBean.getQBE().setQBE("SITEID", "~NULL~");
/*  380: 384 */       listBean.getQBE().setQBE("ORGID", "~NULL~");
/*  381: 385 */       listBean.getQBE().setQBE("MAXVALUE", maxvalue);
/*  382: 386 */       listBean.reset();
/*  383: 387 */       synStr = createSynString(listBean);
/*  384:     */       
/*  385: 389 */       return synStr;
/*  386:     */     }
/*  387: 392 */     return synStr;
/*  388:     */   }
/*  389:     */   
/*  390:     */   public String createSynString(MobileMboDataBean databean)
/*  391:     */     throws MobileApplicationException
/*  392:     */   {
/*  393: 397 */     StringBuffer synStr = new StringBuffer();
/*  394:     */     
/*  395: 399 */     int count = databean.count();
/*  396: 400 */     for (int i = 0; i < count; i++) {
/*  397: 402 */       if (databean.getMobileMbo(i) != null)
/*  398:     */       {
/*  399: 404 */         if (synStr.length() > 0) {
/*  400: 405 */           synStr.append(",");
/*  401:     */         }
/*  402: 406 */         synStr.append(databean.getMobileMbo(i).getValue("VALUE"));
/*  403:     */       }
/*  404:     */     }
/*  405: 410 */     return synStr.toString();
/*  406:     */   }
/*  407:     */   
/*  408:     */   public String getMaxVar(MobileMboDataBean databean, String varname)
/*  409:     */     throws MobileApplicationException
/*  410:     */   {
/*  411: 415 */     String maxvartype = null;
/*  412: 416 */     String value = "";
/*  413:     */     
/*  414:     */ 
/*  415:     */ 
/*  416: 420 */     MobileMboDataBean listBean = DataBeanCache.getDataBean("MAXVARTYPE", "MAXVARTYPE");
/*  417:     */     
/*  418: 422 */     int count = listBean.count();
/*  419: 423 */     listBean.dataExists(count);
/*  420: 424 */     listBean.close();
/*  421:     */     
/*  422: 426 */     listBean.indexMobileMboDataBean("MAXVARTYPE", new String[] { "VARNAME" }, false);
/*  423:     */     
/*  424: 428 */     MobileMbo mbo = listBean.getIndexedMobileMbo("MAXVARTYPE", new String[] { varname });
/*  425: 429 */     if (mbo != null) {
/*  426: 430 */       maxvartype = mbo.getValue("VARTYPE");
/*  427:     */     } else {
/*  428: 432 */       return "";
/*  429:     */     }
/*  430: 435 */     MobileMboDataBean varsBean = DataBeanCache.getDataBean("MAXVARS", "MAXVARS");
/*  431:     */     
/*  432: 437 */     int count2 = varsBean.count();
/*  433: 438 */     varsBean.dataExists(count2);
/*  434: 439 */     varsBean.close();
/*  435: 440 */     varsBean.indexMobileMboDataBean("MAXVARS", new String[] { "SITEID", "ORGID", "VARNAME" }, false);
/*  436: 442 */     if (maxvartype.equals("SITE"))
/*  437:     */     {
/*  438: 443 */       mbo = varsBean.getIndexedMobileMbo("MAXVARS", new String[] { databean.getValue("SITEID"), "", varname });
/*  439: 444 */       if (mbo != null) {
/*  440: 445 */         return mbo.getValue("VARVALUE");
/*  441:     */       }
/*  442:     */     }
/*  443: 449 */     if (maxvartype.equals("ORG"))
/*  444:     */     {
/*  445: 451 */       mbo = varsBean.getIndexedMobileMbo("MAXVARS", new String[] { "", databean.getValue("ORGID"), varname });
/*  446: 452 */       if (mbo != null) {
/*  447: 453 */         return mbo.getValue("VARVALUE");
/*  448:     */       }
/*  449:     */     }
/*  450: 457 */     if (maxvartype.equals("SYSTEM"))
/*  451:     */     {
/*  452: 458 */       mbo = varsBean.getIndexedMobileMbo("MAXVARS", new String[] { "", "", varname });
/*  453: 459 */       if (mbo != null) {
/*  454: 460 */         return mbo.getValue("VARVALUE");
/*  455:     */       }
/*  456:     */     }
/*  457: 464 */     return value;
/*  458:     */   }
/*  459:     */   
/*  460:     */   public static String getUsersLaborcode(String orgid)
/*  461:     */     throws MobileApplicationException
/*  462:     */   {
/*  463: 471 */     String laborcode = "";
/*  464:     */     
/*  465:     */ 
/*  466: 474 */     MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager("PERSON");
/*  467: 475 */     MobileMboDataBean personBean = mgrDBMgr.getDataBean();
/*  468: 476 */     personBean.getQBE().reset();
/*  469:     */     
/*  470:     */ 
/*  471: 479 */     mgrDBMgr = new MobileMboDataBeanManager("LABOR");
/*  472: 480 */     MobileMboDataBean lbrBean = mgrDBMgr.getDataBean();
/*  473: 481 */     lbrBean.getQBE().reset();
/*  474: 482 */     lbrBean.getQBE().setQbeExactMatch(true);
/*  475: 483 */     lbrBean.getQBE().setQBE("ORGID", orgid);
/*  476: 484 */     lbrBean.getQBE().setQBE("PERSONID", personBean.getMobileMbo(0).getValue("PERSONID"));
/*  477: 485 */     lbrBean.reset();
/*  478: 486 */     MobileMbo lbrMbo = lbrBean.getMobileMbo(0);
/*  479: 487 */     if (lbrMbo != null) {
/*  480: 489 */       laborcode = lbrMbo.getValue("LABORCODE");
/*  481:     */     }
/*  482: 492 */     return laborcode;
/*  483:     */   }
/*  484:     */   
/*  485:     */   public static String getUsersPersonId()
/*  486:     */     throws MobileApplicationException
/*  487:     */   {
/*  488: 498 */     MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager("PERSON");
/*  489: 499 */     MobileMboDataBean personBean = mgrDBMgr.getDataBean();
/*  490: 500 */     personBean.getQBE().reset();
/*  491:     */     
/*  492: 502 */     return personBean.getMobileMbo(0).getValue("PERSONID");
/*  493:     */   }
/*  494:     */   
/*  495:     */   public static String getUserId()
/*  496:     */     throws MobileApplicationException
/*  497:     */   {
/*  498: 507 */     MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager("USER");
/*  499: 508 */     MobileMboDataBean userBean = mgrDBMgr.getDataBean();
/*  500: 509 */     userBean.getQBE().reset();
/*  501: 510 */     return userBean.getMobileMbo(0).getValue("USERID");
/*  502:     */   }
/*  503:     */   
/*  504:     */   public static String getStoreroomSite()
/*  505:     */     throws MobileApplicationException
/*  506:     */   {
/*  507: 516 */     MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager("USER");
/*  508: 517 */     MobileMboDataBean userBean = mgrDBMgr.getDataBean();
/*  509: 518 */     userBean.getQBE().reset();
/*  510:     */     
/*  511: 520 */     return userBean.getMobileMbo(0).getValue("STOREROOMSITE");
/*  512:     */   }
/*  513:     */   
/*  514:     */   public static String getDefStoreroom()
/*  515:     */     throws MobileApplicationException
/*  516:     */   {
/*  517: 526 */     MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager("USER");
/*  518: 527 */     MobileMboDataBean userBean = mgrDBMgr.getDataBean();
/*  519: 528 */     userBean.getQBE().reset();
/*  520:     */     
/*  521: 530 */     return userBean.getMobileMbo(0).getValue("DEFSTOREROOM");
/*  522:     */   }
/*  523:     */   
/*  524:     */   public static double calculateHours(Date startDate, Date finishDate)
/*  525:     */   {
/*  526: 535 */     double summaryhrs = 0.0D;
/*  527: 536 */     if ((finishDate != null) && (startDate != null)) {
/*  528: 539 */       summaryhrs = (finishDate.getTime() - startDate.getTime()) / 60000L / 60.0D;
/*  529:     */     }
/*  530: 541 */     return summaryhrs;
/*  531:     */   }
/*  532:     */   
/*  533:     */   public static Date getTimeFromDate(Date date)
/*  534:     */   {
/*  535: 546 */     Date theTime = null;
/*  536: 547 */     GregorianCalendar cal = new GregorianCalendar();
/*  537: 548 */     cal.setTime(date);
/*  538: 549 */     cal.set(1, 0);
/*  539: 550 */     cal.set(2, 0);
/*  540: 551 */     cal.set(5, 0);
/*  541: 552 */     cal.set(13, 0);
/*  542: 553 */     cal.set(14, 0);
/*  543:     */     
/*  544: 555 */     theTime = cal.getTime();
/*  545: 556 */     return theTime;
/*  546:     */   }
/*  547:     */   
/*  548:     */   public static Date getDateFromDate(Date date)
/*  549:     */   {
/*  550: 561 */     Date theDate = null;
/*  551: 562 */     GregorianCalendar cal = new GregorianCalendar();
/*  552: 563 */     cal.setTime(date);
/*  553: 564 */     cal.set(11, 0);
/*  554: 565 */     cal.set(12, 0);
/*  555: 566 */     cal.set(13, 0);
/*  556: 567 */     cal.set(14, 0);
/*  557:     */     
/*  558: 569 */     theDate = cal.getTime();
/*  559: 570 */     return theDate;
/*  560:     */   }
/*  561:     */   
/*  562:     */   public static MobileMbo setStoreLocSiteForStoreroom(MobileMboDataBean databean, String storeroom, String storeLocSiteAttr)
/*  563:     */     throws MobileApplicationException
/*  564:     */   {
/*  565: 576 */     if ((storeroom == null) || (storeroom.equals(""))) {
/*  566: 577 */       return null;
/*  567:     */     }
/*  568: 579 */     MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager("STOREROOMS");
/*  569: 580 */     MobileMboDataBean storeroomBean = mgrDBMgr.getDataBean();
/*  570: 581 */     storeroomBean.getQBE().reset();
/*  571: 582 */     storeroomBean.getQBE().setQbeExactMatch(true);
/*  572: 583 */     storeroomBean.getQBE().setQBE("LOCATION", storeroom);
/*  573: 584 */     storeroomBean.reset();
/*  574:     */     
/*  575:     */ 
/*  576: 587 */     MobileMbo storeroomMbo = storeroomBean.getMobileMbo(0);
/*  577: 588 */     if (storeroomMbo == null) {
/*  578: 589 */       databean.setValue(storeLocSiteAttr, "");
/*  579:     */     } else {
/*  580: 591 */       databean.setValue(storeLocSiteAttr, storeroomMbo.getValue("SITEID"));
/*  581:     */     }
/*  582: 593 */     return storeroomMbo;
/*  583:     */   }
/*  584:     */   
/*  585:     */   public static MobileMbo setItemSetForItem(MobileMboDataBean databean, String dataset, String itemnum, String itemSetAttr)
/*  586:     */     throws MobileApplicationException
/*  587:     */   {
/*  588: 599 */     if ((itemnum == null) || (itemnum.equals(""))) {
/*  589: 600 */       return null;
/*  590:     */     }
/*  591: 602 */     MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager(dataset);
/*  592: 603 */     MobileMboDataBean itemBean = mgrDBMgr.getDataBean();
/*  593: 604 */     itemBean.getQBE().reset();
/*  594: 605 */     itemBean.getQBE().setQbeExactMatch(true);
/*  595: 606 */     itemBean.getQBE().setQBE("ITEMNUM", itemnum);
/*  596: 607 */     itemBean.reset();
/*  597:     */     
/*  598:     */ 
/*  599: 610 */     MobileMbo itemMbo = itemBean.getMobileMbo(0);
/*  600: 613 */     if (databean.getValue("ITEMSETID").trim().length() == 0) {
/*  601: 615 */       if (itemMbo == null) {
/*  602: 616 */         databean.setValue(itemSetAttr, "");
/*  603:     */       } else {
/*  604: 618 */         databean.setValue(itemSetAttr, itemMbo.getValue(itemSetAttr));
/*  605:     */       }
/*  606:     */     }
/*  607: 621 */     return itemMbo;
/*  608:     */   }
/*  609:     */   
/*  610:     */   public static MobileMboDataBean getWpAllFlags()
/*  611:     */     throws MobileApplicationException
/*  612:     */   {
/*  613: 626 */     MobileMboDataBean allflagsBean = DataBeanCache.findDataBean("WPALLFLAGS");
/*  614: 627 */     if (allflagsBean == null)
/*  615:     */     {
/*  616: 629 */       MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager("WPALLFLAGS");
/*  617: 630 */       allflagsBean = mgrDBMgr.getDataBean();
/*  618: 631 */       if (allflagsBean.getMobileMbo(0) == null)
/*  619:     */       {
/*  620: 633 */         allflagsBean.insert();
/*  621: 634 */         allflagsBean.getDataBeanManager().save();
/*  622:     */       }
/*  623: 637 */       DataBeanCache.cacheDataBean("WPALLFLAGS", new DataBeanCacheItem("WPALLFLAGS", "WPALLFLAGS", allflagsBean));
/*  624:     */     }
/*  625: 640 */     allflagsBean.setCurrentPosition(0);
/*  626: 641 */     return allflagsBean;
/*  627:     */   }
/*  628:     */   
/*  629:     */   protected void appPreRefreshMobileMbos(boolean includeWorkList, boolean includeRelatedList)
/*  630:     */     throws MobileApplicationException
/*  631:     */   {
/*  632: 648 */     super.appPreRefreshMobileMbos(includeWorkList, includeRelatedList);
/*  633:     */     
/*  634: 650 */     autoSendAll("WORKORDER");
/*  635: 651 */     autoSendAll("TICKET");
/*  636:     */   }
/*  637:     */   
/*  638:     */   public static boolean isActivityAlsoWO()
/*  639:     */     throws MobileApplicationException
/*  640:     */   {
/*  641: 662 */     MobileMboDataBean databean = DataBeanCache.findDataBean("WOACTIVITY");
/*  642: 663 */     if ((databean != null) && (databean.getMobileMbo() != null))
/*  643:     */     {
/*  644: 666 */       MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager("WORKORDER");
/*  645: 667 */       MobileMboDataBean woBean = mgrDBMgr.getDataBean();
/*  646: 668 */       woBean.getQBE().setQbeExactMatch(true);
/*  647: 669 */       woBean.getQBE().setQBE("WONUM", databean.getMobileMbo().getValue("WONUM"));
/*  648: 670 */       woBean.getQBE().setQBE("SITEID", databean.getMobileMbo().getValue("SITEID"));
/*  649: 671 */       if (woBean.getMobileMbo(0) != null) {
/*  650: 673 */         return true;
/*  651:     */       }
/*  652:     */     }
/*  653: 676 */     return false;
/*  654:     */   }
/*  655:     */   
/*  656:     */   public static boolean isTaskAlsoWO()
/*  657:     */     throws MobileApplicationException
/*  658:     */   {
/*  659: 681 */     MobileMboDataBean databean = DataBeanCache.findDataBean("WOTASKS");
/*  660: 682 */     if ((databean.getMobileMbo() == null) || (databean.getMobileMbo().getValue("WONUM").equals(""))) {
/*  661: 683 */       return false;
/*  662:     */     }
/*  663: 686 */     MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager("WORKORDER");
/*  664: 687 */     MobileMboDataBean woBean = mgrDBMgr.getDataBean();
/*  665: 688 */     woBean.getQBE().setQbeExactMatch(true);
/*  666: 689 */     woBean.getQBE().setQBE("WONUM", databean.getMobileMbo().getValue("WONUM"));
/*  667: 690 */     woBean.getQBE().setQBE("SITEID", databean.getMobileMbo().getValue("SITEID"));
/*  668: 691 */     if (woBean.getMobileMbo(0) != null) {
/*  669: 693 */       return true;
/*  670:     */     }
/*  671: 696 */     return false;
/*  672:     */   }
/*  673:     */   
/*  674:     */   protected void appPostRefreshMobileMbos(boolean includeWorkList, boolean includeRelatedList)
/*  675:     */     throws MobileApplicationException
/*  676:     */   {
/*  677: 705 */     MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager("WORKLIST");
/*  678: 706 */     MobileMboDataBean worklistBean = mgrDBMgr.getDataBean();
/*  679: 707 */     worklistBean.reset();
/*  680: 708 */     int count = worklistBean.count();
/*  681: 709 */     for (int i = count - 1; i >= 0; i--) {
/*  682: 711 */       if (worklistBean.getMobileMbo(i) != null) {
/*  683: 712 */         worklistBean.deleteLocal(i);
/*  684:     */       }
/*  685:     */     }
/*  686: 715 */     worklistBean.getDataBeanManager().save();
/*  687: 716 */     mgrDBMgr = new MobileMboDataBeanManager("WORKLIST");
/*  688: 717 */     worklistBean = mgrDBMgr.getDataBean();
/*  689:     */     
/*  690:     */ 
/*  691: 720 */     mgrDBMgr = new MobileMboDataBeanManager("WORKORDER");
/*  692: 721 */     MobileMboDataBean wolistBean = mgrDBMgr.getDataBean();
/*  693: 722 */     wolistBean.reset();
/*  694: 723 */     count = wolistBean.count();
/*  695: 724 */     for (int i = 0; i < count; i++) {
/*  696: 726 */       copyMboToWorkList(worklistBean, wolistBean, wolistBean.getMobileMbo(i));
/*  697:     */     }
/*  698: 730 */     mgrDBMgr = new MobileMboDataBeanManager("TICKET");
/*  699: 731 */     MobileMboDataBean tktlistBean = mgrDBMgr.getDataBean();
/*  700: 732 */     tktlistBean.reset();
/*  701: 733 */     count = tktlistBean.count();
/*  702: 734 */     for (int i = 0; i < count; i++) {
/*  703: 736 */       copyMboToWorkList(worklistBean, tktlistBean, tktlistBean.getMobileMbo(i));
/*  704:     */     }
/*  705: 739 */     worklistBean.getDataBeanManager().save();
/*  706:     */     
/*  707:     */ 
/*  708: 742 */     rebuildLabTrans();
/*  709:     */     
/*  710:     */ 
/*  711: 745 */     rebuildFailureLookupTable();
/*  712:     */   }
/*  713:     */   
/*  714:     */   public void rebuildFailureLookupTable()
/*  715:     */     throws MobileApplicationException
/*  716:     */   {
/*  717: 752 */     RDOTransactionManager transaction = getTransactionManager();
/*  718: 753 */     RDOManager manager = getRDOManager();
/*  719:     */     try
/*  720:     */     {
/*  721: 755 */       transaction.begin();
/*  722: 756 */       cleanUpFailureLookup(manager);
/*  723: 757 */       Set created = createFromFailureClass(manager);
/*  724: 758 */       createFromFailureList(manager, created);
/*  725: 759 */       transaction.commit();
/*  726:     */     }
/*  727:     */     catch (RDOException e)
/*  728:     */     {
/*  729: 761 */       DBLOGGER.error(e.getMessage(), e);
/*  730:     */       try
/*  731:     */       {
/*  732: 763 */         transaction.rollback();
/*  733:     */       }
/*  734:     */       catch (Exception e1)
/*  735:     */       {
/*  736: 765 */         DBLOGGER.error(e1.getMessage(), e1);
/*  737:     */       }
/*  738: 767 */       throw new MobileApplicationException(e.getMessage());
/*  739:     */     }
/*  740:     */   }
/*  741:     */   
/*  742:     */   public RDOManager getRDOManager()
/*  743:     */   {
/*  744: 772 */     return getRDORuntime().getRDOManager();
/*  745:     */   }
/*  746:     */   
/*  747:     */   public RDOTransactionManager getTransactionManager()
/*  748:     */   {
/*  749: 776 */     return getRDORuntime().getRDOTransactionManager();
/*  750:     */   }
/*  751:     */   
/*  752:     */   public void cleanUpFailureLookup(RDOManager manager)
/*  753:     */     throws RDOException
/*  754:     */   {
/*  755: 781 */     manager.removeAll("FAILURELOOKUP");
/*  756:     */   }
/*  757:     */   
/*  758:     */   public void createFromFailureList(RDOManager manager, Set ignore)
/*  759:     */     throws RDOException
/*  760:     */   {
/*  761: 785 */     MobileMboQBE qbe = new MobileMboQBE();
/*  762: 786 */     qbe.setQbeExactMatch(true);
/*  763: 787 */     qbe.setQBE("PARENT", "~NULL~");
/*  764: 788 */     RDOEnumeration enumeration = manager.getAll("FAILURELIST", qbe, null);
/*  765: 789 */     while (enumeration.hasMoreElements())
/*  766:     */     {
/*  767: 790 */       RDO rdo = (RDO)enumeration.nextElement();
/*  768: 791 */       if (!ignore.contains(rdo.getStringValue("FAILURECODE"))) {
/*  769: 792 */         manager.insert("FAILURELOOKUP", buildFailureLookupRDOFromFailureList(rdo));
/*  770:     */       }
/*  771:     */     }
/*  772:     */   }
/*  773:     */   
/*  774:     */   public Set createFromFailureClass(RDOManager manager)
/*  775:     */     throws RDOException
/*  776:     */   {
/*  777: 799 */     Set created = new HashSet();
/*  778: 800 */     RDOEnumeration enumeration = manager.getAll("FAILURECLASS");
/*  779: 801 */     while (enumeration.hasMoreElements())
/*  780:     */     {
/*  781: 802 */       RDO rdo = (RDO)enumeration.nextElement();
/*  782: 803 */       manager.insert("FAILURELOOKUP", buildFailureLookupRDOFromFailureClass(rdo));
/*  783: 804 */       created.add(rdo.getStringValue("FAILURECODE"));
/*  784:     */       
/*  785: 806 */       ensureExistsInDependentHierTable(manager, rdo);
/*  786:     */     }
/*  787: 808 */     return created;
/*  788:     */   }
/*  789:     */   
/*  790:     */   protected void ensureExistsInDependentHierTable(RDOManager manager, RDO rdo)
/*  791:     */     throws RDOException
/*  792:     */   {
/*  793: 813 */     if (!manager.exists("FAILURECLASSHIER", rdo.getLongValue("_ID"))) {
/*  794: 814 */       manager.insert("FAILURECLASSHIER", buildFailureClassHierRDO(rdo));
/*  795:     */     }
/*  796:     */   }
/*  797:     */   
/*  798:     */   public void ensureExistsInFailureLookupTable(MobileMbo selected)
/*  799:     */     throws MobileApplicationException
/*  800:     */   {
/*  801: 820 */     RDOTransactionManager transaction = getTransactionManager();
/*  802: 821 */     RDOManager manager = getRDOManager();
/*  803:     */     try
/*  804:     */     {
/*  805: 823 */       transaction.begin();
/*  806: 824 */       RDO rdo = selected.getRDO();
/*  807: 826 */       if (!manager.exists("FAILURELOOKUP", rdo.getLongValue("_ID"))) {
/*  808: 827 */         manager.insert("FAILURELOOKUP", buildFailureLookupRDOFromFailureClass(rdo));
/*  809:     */       }
/*  810: 829 */       if (!manager.exists("FAILURECLASS", rdo.getLongValue("_ID")))
/*  811:     */       {
/*  812: 830 */         manager.insert("FAILURECLASS", buildFailureClassRDO(rdo));
/*  813: 831 */         if (!manager.exists("FAILURECLASSHIER", rdo.getLongValue("_ID"))) {
/*  814: 832 */           manager.insert("FAILURECLASSHIER", buildFailureClassHierRDO(rdo));
/*  815:     */         }
/*  816:     */       }
/*  817: 835 */       transaction.commit();
/*  818:     */     }
/*  819:     */     catch (RDOException e)
/*  820:     */     {
/*  821: 837 */       DBLOGGER.error(e.getMessage(), e);
/*  822:     */       try
/*  823:     */       {
/*  824: 839 */         transaction.rollback();
/*  825:     */       }
/*  826:     */       catch (Exception e1)
/*  827:     */       {
/*  828: 841 */         DBLOGGER.error(e1.getMessage(), e1);
/*  829:     */       }
/*  830: 843 */       throw new MobileApplicationException(e.getMessage());
/*  831:     */     }
/*  832:     */   }
/*  833:     */   
/*  834:     */   public RDO buildFailureClassRDO(RDO rdo)
/*  835:     */     throws RDOException
/*  836:     */   {
/*  837: 849 */     return buildRDOFor(rdo, "FAILURECLASS");
/*  838:     */   }
/*  839:     */   
/*  840:     */   protected RDO buildRDOFor(RDO rdo, String name)
/*  841:     */     throws RDOException
/*  842:     */   {
/*  843: 853 */     DefaultRDO newRDO = createPersistentRDO(rdo.getAppName());
/*  844: 854 */     newRDO.setName(name);
/*  845: 855 */     newRDO.setStringValue("FAILURECODE", rdo.getStringValue("FAILURECODE"));
/*  846: 856 */     newRDO.setStringValue("DESCRIPTION", rdo.getStringValue("DESCRIPTION"));
/*  847: 857 */     newRDO.setLongValue("FAILURELIST", rdo.getLongValue("FAILURELIST"));
/*  848: 858 */     newRDO.setStringValue("ORGID", rdo.getStringValue("ORGID"));
/*  849: 859 */     newRDO.setLongValue("_ID", rdo.getLongValue("_ID"));
/*  850: 860 */     newRDO.setStringValue("TYPE", rdo.getStringValue("TYPE"));
/*  851: 861 */     if (rdo.isNull("MOBTOPPARENT")) {
/*  852: 862 */       newRDO.setStringValue("MOBTOPPARENT", rdo.getStringValue("FAILURECODE"));
/*  853:     */     } else {
/*  854: 864 */       newRDO.setStringValue("MOBTOPPARENT", rdo.getStringValue("MOBTOPPARENT"));
/*  855:     */     }
/*  856: 866 */     return newRDO;
/*  857:     */   }
/*  858:     */   
/*  859:     */   public RDO buildFailureClassHierRDO(RDO rdo)
/*  860:     */     throws RDOException
/*  861:     */   {
/*  862: 871 */     return buildRDOFor(rdo, "FAILURECLASSHIER");
/*  863:     */   }
/*  864:     */   
/*  865:     */   protected RDO buildFailureLookupRDOFromFailureList(RDO rdo)
/*  866:     */     throws RDOException
/*  867:     */   {
/*  868: 876 */     return buildFailureLookupRDO(rdo, "FAILURELIST");
/*  869:     */   }
/*  870:     */   
/*  871:     */   public RDO buildFailureLookupRDOFromFailureClass(RDO rdo)
/*  872:     */     throws RDOException
/*  873:     */   {
/*  874: 881 */     return buildFailureLookupRDO(rdo, "FAILURECLASSHIER");
/*  875:     */   }
/*  876:     */   
/*  877:     */   protected DefaultRDO buildFailureLookupRDO(RDO rdo, String fromObject)
/*  878:     */     throws RDOException
/*  879:     */   {
/*  880: 886 */     DefaultRDO newRDO = createPersistentRDO(rdo.getAppName());
/*  881: 887 */     newRDO.setName("FAILURELOOKUP");
/*  882: 888 */     newRDO.setStringValue("FAILURECODE", rdo.getStringValue("FAILURECODE"));
/*  883: 889 */     newRDO.setStringValue("DESCRIPTION", rdo.getStringValue("DESCRIPTION"));
/*  884: 890 */     newRDO.setLongValue("FAILURELIST", rdo.getLongValue("FAILURELIST"));
/*  885: 891 */     newRDO.setStringValue("ORGID", rdo.getStringValue("ORGID"));
/*  886: 892 */     newRDO.setLongValue("_ID", rdo.getLongValue("_ID"));
/*  887: 893 */     newRDO.setStringValue("LOOKUPFROMOBJECT", fromObject);
/*  888: 894 */     return newRDO;
/*  889:     */   }
/*  890:     */   
/*  891:     */   public void refreshMobileMbos(String mboName, ProgressObserver observer, boolean dependentFilterOnly)
/*  892:     */     throws MobileApplicationException
/*  893:     */   {
/*  894: 899 */     super.refreshMobileMbos(mboName, observer, dependentFilterOnly);
/*  895: 900 */     if ((mboName != null) && (mboName.equalsIgnoreCase("FAILURELIST"))) {
/*  896: 901 */       rebuildFailureLookupTable();
/*  897:     */     }
/*  898:     */   }
/*  899:     */   
/*  900:     */   protected DefaultRDO createPersistentRDO(String name)
/*  901:     */   {
/*  902: 906 */     return new DefaultRDO(name, true);
/*  903:     */   }
/*  904:     */   
/*  905:     */   public void rebuildLabTrans()
/*  906:     */     throws MobileApplicationException
/*  907:     */   {
/*  908: 922 */     MobileMboDataBeanManager dataMgr = new MobileMboDataBeanManager("LABTRANS");
/*  909: 923 */     MobileMboDataBean labTransBean = dataMgr.getDataBean();
/*  910:     */     
/*  911: 925 */     int labTransCount = labTransBean.count();
/*  912: 926 */     for (int i = 0; i < labTransCount; i++) {
/*  913: 928 */       labTransBean.deleteLocal(i);
/*  914:     */     }
/*  915: 932 */     dataMgr = new MobileMboDataBeanManager("WOLABTRANS");
/*  916: 933 */     MobileMboDataBean woLabTransBean = dataMgr.getDataBean();
/*  917: 934 */     woLabTransBean.reset();
/*  918:     */     
/*  919:     */ 
/*  920: 937 */     dataMgr = new MobileMboDataBeanManager("TKLABTRANS");
/*  921: 938 */     MobileMboDataBean tkLabTransBean = dataMgr.getDataBean();
/*  922: 939 */     tkLabTransBean.reset();
/*  923:     */     
/*  924: 941 */     int woLabTransCount = woLabTransBean.count();
/*  925: 944 */     if (woLabTransCount > 0)
/*  926:     */     {
/*  927: 946 */       MobileMboDataBean woDataBean = DataBeanCache.getDataBean("WORKORDER", "WORKORDER");
/*  928: 947 */       woDataBean.getQBE().reset();
/*  929: 948 */       woDataBean.reset();
/*  930:     */       
/*  931:     */ 
/*  932: 951 */       MobileMboDataBean tasksDataBean = DataBeanCache.getDataBean("WOTASKS", "WOTASKS");
/*  933: 952 */       tasksDataBean.getQBE().reset();
/*  934: 953 */       tasksDataBean.reset();
/*  935:     */       
/*  936:     */ 
/*  937: 956 */       StringBuffer sql = new StringBuffer();
/*  938: 957 */       ArrayList listParams = new ArrayList();
/*  939: 958 */       for (int i = 0; i < woLabTransCount; i++)
/*  940:     */       {
/*  941: 960 */         if (sql.length() > 0) {
/*  942: 962 */           sql.append(" OR ");
/*  943:     */         }
/*  944: 964 */         sql.append("(WONUM = ? AND SITEID = ?)");
/*  945: 965 */         listParams.add(woLabTransBean.getValue(i, "REFWO"));
/*  946: 966 */         listParams.add(woLabTransBean.getValue(i, "SITEID"));
/*  947:     */       }
/*  948: 968 */       Object[] params = listParams.toArray();
/*  949: 969 */       String whereClause = sql.toString();
/*  950: 970 */       woDataBean.setAdditionalWhere(whereClause, params);
/*  951: 971 */       tasksDataBean.setAdditionalWhere(whereClause, params);
/*  952: 972 */       woDataBean.reset();
/*  953: 973 */       tasksDataBean.reset();
/*  954: 975 */       for (int i = 0; i < woLabTransCount; i++) {
/*  955: 977 */         if ((!woIsDone(woDataBean, woLabTransBean.getValue(i, "REFWO"), woLabTransBean.getValue(i, "SITEID"))) || (!woIsDone(tasksDataBean, woLabTransBean.getValue(i, "REFWO"), woLabTransBean.getValue(i, "SITEID"))))
/*  956:     */         {
/*  957: 980 */           labTransBean.insert();
/*  958:     */           
/*  959: 982 */           woLabTransBean.setCurrentPosition(i);
/*  960: 983 */           copyMboToLabTrans(labTransBean, woLabTransBean, "WOLABTRANS");
/*  961:     */         }
/*  962:     */       }
/*  963:     */     }
/*  964: 989 */     int tkLabTransCount = tkLabTransBean.count();
/*  965: 992 */     if (tkLabTransCount > 0)
/*  966:     */     {
/*  967: 994 */       MobileMboDataBean tkDataBean = DataBeanCache.getDataBean("TICKET", "TICKET");
/*  968: 995 */       tkDataBean.getQBE().reset();
/*  969: 996 */       tkDataBean.reset();
/*  970:     */       
/*  971:     */ 
/*  972: 999 */       MobileMboDataBean activitiesDataBean = DataBeanCache.getDataBean("WOACTIVITY", "WOACTIVITY");
/*  973:1000 */       activitiesDataBean.getQBE().reset();
/*  974:1001 */       activitiesDataBean.reset();
/*  975:     */       
/*  976:1003 */       StringBuffer sqlWO = new StringBuffer();
/*  977:1004 */       StringBuffer sqlTK = new StringBuffer();
/*  978:1005 */       ArrayList listParamsWO = new ArrayList();
/*  979:1006 */       ArrayList listParamsTK = new ArrayList();
/*  980:1007 */       for (int i = 0; i < woLabTransCount; i++)
/*  981:     */       {
/*  982:1009 */         if (sqlWO.length() > 0)
/*  983:     */         {
/*  984:1011 */           sqlWO.append(" OR ");
/*  985:1012 */           sqlTK.append(" OR ");
/*  986:     */         }
/*  987:1014 */         sqlWO.append("(WONUM = ? AND SITEID = ?)");
/*  988:1015 */         sqlTK.append("(TICKETID = ? AND CLASS = ?)");
/*  989:1016 */         listParamsWO.add(woLabTransBean.getValue(i, "REFWO"));
/*  990:1017 */         listParamsWO.add(woLabTransBean.getValue(i, "SITEID"));
/*  991:1018 */         listParamsTK.add(woLabTransBean.getValue(i, "TICKETID"));
/*  992:1019 */         listParamsTK.add(woLabTransBean.getValue(i, "TICKETCLASS"));
/*  993:     */       }
/*  994:1021 */       Object[] paramsWO = listParamsWO.toArray();
/*  995:1022 */       Object[] paramsTK = listParamsTK.toArray();
/*  996:1023 */       String whereClauseWO = sqlWO.toString();
/*  997:1024 */       String whereClauseTK = sqlTK.toString();
/*  998:1025 */       tkDataBean.setAdditionalWhere(whereClauseTK, paramsTK);
/*  999:1026 */       activitiesDataBean.setAdditionalWhere(whereClauseWO, paramsWO);
/* 1000:1027 */       tkDataBean.reset();
/* 1001:1028 */       activitiesDataBean.reset();
/* 1002:1030 */       for (int i = 0; i < tkLabTransCount; i++) {
/* 1003:1032 */         if ((!tkIsDone(tkDataBean, tkLabTransBean.getValue(i, "TICKETID"), tkLabTransBean.getValue(i, "TICKETCLASS"))) || (!woIsDone(activitiesDataBean, tkLabTransBean.getValue(i, "REFWO"), tkLabTransBean.getValue(i, "SITEID"))))
/* 1004:     */         {
/* 1005:1035 */           labTransBean.insert();
/* 1006:     */           
/* 1007:1037 */           tkLabTransBean.setCurrentPosition(i);
/* 1008:1038 */           copyMboToLabTrans(labTransBean, tkLabTransBean, "TKLABTRANS");
/* 1009:     */         }
/* 1010:     */       }
/* 1011:     */     }
/* 1012:1043 */     labTransBean.getDataBeanManager().save();
/* 1013:     */   }
/* 1014:     */   
/* 1015:     */   private void copyMboToLabTrans(MobileMboDataBean labTransBean, MobileMboDataBean woTkLabTransBean, String beanName)
/* 1016:     */     throws MobileApplicationException
/* 1017:     */   {
/* 1018:1060 */     OperationContainer oc = getOperationContainer(beanName, "save");
/* 1019:1061 */     CommonLabTransOperationHandler labTransOperHandler = (CommonLabTransOperationHandler)oc.getHandler();
/* 1020:1062 */     labTransOperHandler.copyMboValues(labTransBean, woTkLabTransBean);
/* 1021:     */   }
/* 1022:     */   
/* 1023:     */   private boolean woIsDone(MobileMboDataBean woDataBean, String woNum, String siteId)
/* 1024:     */     throws MobileApplicationException
/* 1025:     */   {
/* 1026:1077 */     int index = 0;
/* 1027:1078 */     MobileMbo woMbo = woDataBean.getMobileMbo(index);
/* 1028:1079 */     while (woMbo != null)
/* 1029:     */     {
/* 1030:1081 */       String currentWoNum = woMbo.getValue("WONUM");
/* 1031:1082 */       String currentSiteId = woMbo.getValue("SITEID");
/* 1032:1083 */       if ((woNum.equalsIgnoreCase(currentWoNum)) && (siteId.equalsIgnoreCase(currentSiteId)) && (woMbo.getBooleanValue("_DONE"))) {
/* 1033:1087 */         return true;
/* 1034:     */       }
/* 1035:1089 */       woMbo = woDataBean.getMobileMbo(++index);
/* 1036:     */     }
/* 1037:1092 */     return false;
/* 1038:     */   }
/* 1039:     */   
/* 1040:     */   private boolean tkIsDone(MobileMboDataBean tkDataBean, String ticketId, String ticketClass)
/* 1041:     */     throws MobileApplicationException
/* 1042:     */   {
/* 1043:1108 */     int index = 0;
/* 1044:1109 */     MobileMbo tkMbo = tkDataBean.getMobileMbo(index);
/* 1045:1110 */     while (tkMbo != null)
/* 1046:     */     {
/* 1047:1112 */       String currentTicketId = tkMbo.getValue("TICKETID");
/* 1048:1113 */       String currentTicketClass = tkMbo.getValue("CLASS");
/* 1049:1114 */       if ((currentTicketId.equalsIgnoreCase(ticketId)) && (currentTicketClass.equalsIgnoreCase(ticketClass)) && (tkMbo.getBooleanValue("_DONE"))) {
/* 1050:1118 */         return true;
/* 1051:     */       }
/* 1052:1120 */       tkMbo = tkDataBean.getMobileMbo(++index);
/* 1053:     */     }
/* 1054:1123 */     return false;
/* 1055:     */   }
/* 1056:     */   
/* 1057:     */   public void copyMboToWorkList(MobileMboDataBean worklistBean, MobileMboDataBean mobileMboDataBean, MobileMbo mobileMbo)
/* 1058:     */     throws MobileApplicationException
/* 1059:     */   {
/* 1060:1130 */     worklistBean.insert();
/* 1061:1131 */     updateMboInDataBean(worklistBean, worklistBean.getCurrentPosition(), mobileMboDataBean, mobileMbo);
/* 1062:     */   }
/* 1063:     */   
/* 1064:     */   public void updateMboInDataBean(MobileMboDataBean destDataBean, int destIndex, MobileMboDataBean srcMobileMboDataBean, MobileMbo srcMobileMbo)
/* 1065:     */     throws MobileApplicationException
/* 1066:     */   {
/* 1067:1137 */     String srcfield = "";
/* 1068:1138 */     int datatype = 0;
/* 1069:1139 */     String[] destAttrNames = destDataBean.getMobileMboInfo().getAttributeNames();
/* 1070:1141 */     for (int l = 0; l < destAttrNames.length; l++) {
/* 1071:1143 */       if (!destDataBean.getMobileMbo(destIndex).isReadOnly(destAttrNames[l]))
/* 1072:     */       {
/* 1073:1145 */         srcfield = destAttrNames[l];
/* 1074:     */         
/* 1075:1147 */         destDataBean.getMobileMboInfo().getAttributeInfo(srcfield).setChangeTrackingEnabled(false);
/* 1076:1149 */         if (!srcfield.equalsIgnoreCase("_ID")) {
/* 1077:1151 */           if (!srcfield.equalsIgnoreCase("_READONLY")) {
/* 1078:1153 */             if (!srcfield.equalsIgnoreCase("_ORIGINAL")) {
/* 1079:1155 */               if (!srcfield.equalsIgnoreCase("_READONLYATTRS")) {
/* 1080:1157 */                 if (!srcfield.equalsIgnoreCase("_ATTRMODIFIED"))
/* 1081:     */                 {
/* 1082:1166 */                   if (destAttrNames[l].equalsIgnoreCase("_RECID")) {
/* 1083:1167 */                     srcfield = "_ID";
/* 1084:     */                   }
/* 1085:1168 */                   if (srcMobileMboDataBean.getName().equals("WORKORDER"))
/* 1086:     */                   {
/* 1087:1170 */                     if (destAttrNames[l].equalsIgnoreCase("RECORDID")) {
/* 1088:1171 */                       srcfield = "WONUM";
/* 1089:1172 */                     } else if (destAttrNames[l].equalsIgnoreCase("CLASS")) {
/* 1090:1173 */                       srcfield = "WOCLASS";
/* 1091:1174 */                     } else if (destAttrNames[l].equalsIgnoreCase("PRIORITY")) {
/* 1092:1175 */                       srcfield = "WOPRIORITY";
/* 1093:     */                     }
/* 1094:     */                   }
/* 1095:1177 */                   else if (srcMobileMboDataBean.getName().equals("TICKET")) {
/* 1096:1179 */                     if (destAttrNames[l].equalsIgnoreCase("RECORDID")) {
/* 1097:1180 */                       srcfield = "TICKETID";
/* 1098:1181 */                     } else if (destAttrNames[l].equalsIgnoreCase("PRIORITY")) {
/* 1099:1182 */                       srcfield = "INTERNALPRIORITY";
/* 1100:     */                     }
/* 1101:     */                   }
/* 1102:1185 */                   if (srcMobileMboDataBean.getMobileMboInfo().getAttributeInfo(srcfield) != null)
/* 1103:     */                   {
/* 1104:1187 */                     datatype = srcMobileMboDataBean.getMobileMboInfo().getAttributeInfo(srcfield).getDataType();
/* 1105:1188 */                     if (datatype == 11)
/* 1106:     */                     {
/* 1107:1190 */                       if (srcMobileMbo.getDateValue(srcfield) != null) {
/* 1108:1191 */                         destDataBean.getMobileMbo(destIndex).setDateValue(destAttrNames[l], srcMobileMbo.getDateValue(srcfield));
/* 1109:     */                       }
/* 1110:     */                     }
/* 1111:1193 */                     else if (datatype == 4)
/* 1112:     */                     {
/* 1113:1195 */                       if (srcMobileMbo.getIntValue(srcfield) != 0) {
/* 1114:1196 */                         destDataBean.getMobileMbo(destIndex).setValue(destAttrNames[l], "" + srcMobileMbo.getIntValue(srcfield));
/* 1115:     */                       }
/* 1116:     */                     }
/* 1117:     */                     else {
/* 1118:1200 */                       destDataBean.getMobileMbo(destIndex).setValue(destAttrNames[l], srcMobileMbo.getValue(srcfield));
/* 1119:     */                     }
/* 1120:     */                   }
/* 1121:     */                 }
/* 1122:     */               }
/* 1123:     */             }
/* 1124:     */           }
/* 1125:     */         }
/* 1126:     */       }
/* 1127:     */     }
/* 1128:1204 */     destDataBean.getMobileMbo(destIndex).setValue("_MODIFIED", srcMobileMbo.getValue("_MODIFIED"));
/* 1129:     */   }
/* 1130:     */   
/* 1131:     */   public int findMboInWorkList(MobileMboDataBean dataBeanToSearch, MobileMbo mobileMboToFind)
/* 1132:     */     throws MobileApplicationException
/* 1133:     */   {
/* 1134:1211 */     if (dataBeanToSearch.getCurrentPosition() > -1) {
/* 1135:1213 */       if (dataBeanToSearch.getMobileMbo(dataBeanToSearch.getCurrentPosition()).getValue("_RECID").equalsIgnoreCase(mobileMboToFind.getValue("_ID"))) {
/* 1136:1214 */         return dataBeanToSearch.getCurrentPosition();
/* 1137:     */       }
/* 1138:     */     }
/* 1139:1217 */     int count = dataBeanToSearch.count();
/* 1140:1218 */     for (int i = 0; i < count; i++) {
/* 1141:1220 */       if (dataBeanToSearch.getMobileMbo(i).getValue("_RECID").equalsIgnoreCase(mobileMboToFind.getValue("_ID"))) {
/* 1142:1222 */         return i;
/* 1143:     */       }
/* 1144:     */     }
/* 1145:1226 */     return -1;
/* 1146:     */   }
/* 1147:     */   
/* 1148:     */   public boolean addRelatedRecToWO(String workorderid, String wonum, String orgid, String siteid, String woclass, long relatedreckeyid, String relatedrecname, String relatetype, String relatedreckey, String relatedrecorgid, String relatedrecsiteid, String relatedrecclass)
/* 1149:     */     throws MobileApplicationException
/* 1150:     */   {
/* 1151:1237 */     MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager("WORKORDER");
/* 1152:1238 */     MobileMboDataBean woBean = mgrDBMgr.getDataBean();
/* 1153:1239 */     woBean.getQBE().setQbeExactMatch(true);
/* 1154:1240 */     woBean.getQBE().setQBE("_ID", workorderid);
/* 1155:1241 */     if (woBean.getMobileMbo(0) == null) {
/* 1156:1242 */       return false;
/* 1157:     */     }
/* 1158:1245 */     String relatedset = "WORELWOS";
/* 1159:1246 */     if (relatedrecname.equalsIgnoreCase("TICKET")) {
/* 1160:1247 */       relatedset = "WORELTICKETS";
/* 1161:     */     }
/* 1162:1248 */     MobileMboDataBean reldatabean = woBean.getDataBean(relatedset);
/* 1163:     */     
/* 1164:1250 */     reldatabean.insert();
/* 1165:1251 */     reldatabean.setValue("RECORDKEYID", workorderid);
/* 1166:1252 */     reldatabean.setValue("RECORDKEY", wonum);
/* 1167:1253 */     reldatabean.setValue("CLASS", woclass);
/* 1168:1254 */     reldatabean.setValue("ORGID", orgid);
/* 1169:1255 */     reldatabean.setValue("SITEID", siteid);
/* 1170:1256 */     reldatabean.setValue("RELATETYPE", relatetype);
/* 1171:1257 */     reldatabean.getMobileMbo().setLongValue("RELATEDRECKEYID", relatedreckeyid);
/* 1172:1258 */     reldatabean.setValue("RELATEDRECORGID", relatedrecorgid);
/* 1173:1259 */     reldatabean.setValue("RELATEDRECSITEID", relatedrecsiteid);
/* 1174:1261 */     if (relatedrecname.equalsIgnoreCase("WORKORDER"))
/* 1175:     */     {
/* 1176:1263 */       reldatabean.setValue("RELATEDRECWONUM", relatedreckey);
/* 1177:1264 */       reldatabean.setValue("RELATEDRECWOCLASS", relatedrecclass);
/* 1178:     */     }
/* 1179:     */     else
/* 1180:     */     {
/* 1181:1268 */       reldatabean.setValue("RELATEDRECKEY", relatedreckey);
/* 1182:1269 */       reldatabean.setValue("RELATEDRECCLASS", relatedrecclass);
/* 1183:     */     }
/* 1184:1273 */     reldatabean.setValue("ASSETNUM", woBean.getMobileMbo(0).getValue("ASSETNUM"));
/* 1185:1274 */     reldatabean.setValue("LOCATION", woBean.getMobileMbo(0).getValue("LOCATION"));
/* 1186:1275 */     reldatabean.setValue("DESCRIPTION", woBean.getMobileMbo(0).getValue("DESCRIPTION"));
/* 1187:1276 */     reldatabean.setValue("DESCRIPTION_LONGDESCRIPTION", woBean.getMobileMbo(0).getValue("DESCRIPTION_LONGDESCRIPTION"));
/* 1188:     */     
/* 1189:1278 */     reldatabean = addInfoToRelatedRec(reldatabean);
/* 1190:1279 */     woBean.getDataBeanManager().save();
/* 1191:     */     
/* 1192:1281 */     return true;
/* 1193:     */   }
/* 1194:     */   
/* 1195:     */   public boolean addRelatedRecordToWO(MobileMbo wo, MobileMbo relatedRec, String relatedrecname)
/* 1196:     */     throws MobileApplicationException
/* 1197:     */   {
/* 1198:1289 */     MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager("WORKORDER");
/* 1199:1290 */     MobileMboDataBean woBean = mgrDBMgr.getDataBean();
/* 1200:1291 */     woBean.getQBE().setQbeExactMatch(true);
/* 1201:1292 */     woBean.getQBE().setQBE("_ID", wo.getValue("_ID"));
/* 1202:1293 */     if (woBean.getMobileMbo(0) == null) {
/* 1203:1294 */       return false;
/* 1204:     */     }
/* 1205:1297 */     String relatedset = "WORELWOS";
/* 1206:1298 */     if (relatedrecname.equalsIgnoreCase("TICKET")) {
/* 1207:1299 */       relatedset = "WORELTICKETS";
/* 1208:     */     }
/* 1209:1300 */     MobileMboDataBean reldatabean = woBean.getDataBean(relatedset);
/* 1210:     */     
/* 1211:1302 */     reldatabean.insert();
/* 1212:1303 */     reldatabean.setValue("RECORDKEYID", wo.getValue("_ID"));
/* 1213:1304 */     reldatabean.setValue("RECORDKEY", wo.getValue("WONUM"));
/* 1214:1305 */     reldatabean.setValue("CLASS", wo.getValue("WOCLASS"));
/* 1215:1306 */     reldatabean.setValue("ORGID", wo.getValue("ORGID"));
/* 1216:1307 */     reldatabean.setValue("SITEID", wo.getValue("SITEID"));
/* 1217:1308 */     reldatabean.setValue("RELATETYPE", "");
/* 1218:1309 */     reldatabean.setValue("RELATEDRECKEYID", relatedRec.getValue("_ID"));
/* 1219:1310 */     reldatabean.setValue("RELATEDRECORGID", relatedRec.getValue("ORGID"));
/* 1220:1311 */     reldatabean.setValue("RELATEDRECSITEID", relatedRec.getValue("SITEID"));
/* 1221:1313 */     if (relatedrecname.equalsIgnoreCase("WORKORDER"))
/* 1222:     */     {
/* 1223:1315 */       reldatabean.setValue("RELATEDRECWONUM", relatedRec.getValue("WONUM"));
/* 1224:1316 */       reldatabean.setValue("RELATEDRECWOCLASS", relatedRec.getValue("WOCLASS"));
/* 1225:     */     }
/* 1226:     */     else
/* 1227:     */     {
/* 1228:1320 */       reldatabean.setValue("RELATEDRECKEY", relatedRec.getValue("TICKETID"));
/* 1229:1321 */       reldatabean.setValue("RELATEDRECCLASS", relatedRec.getValue("CLASS"));
/* 1230:     */     }
/* 1231:1324 */     reldatabean.setValue("STATUS", relatedRec.getValue("STATUS"));
/* 1232:1325 */     reldatabean.setValue("ASSETNUM", relatedRec.getValue("ASSETNUM"));
/* 1233:1326 */     reldatabean.setValue("LOCATION", relatedRec.getValue("LOCATION"));
/* 1234:1327 */     reldatabean.setValue("DESCRIPTION", relatedRec.getValue("DESCRIPTION"));
/* 1235:1328 */     reldatabean.setValue("DESCRIPTION_LONGDESCRIPTION", relatedRec.getValue("DESCRIPTION_LONGDESCRIPTION"));
/* 1236:     */     
/* 1237:1330 */     reldatabean = addInfoToRelatedRec(reldatabean);
/* 1238:1331 */     woBean.getDataBeanManager().save();
/* 1239:     */     
/* 1240:1333 */     return true;
/* 1241:     */   }
/* 1242:     */   
/* 1243:     */   public boolean addRelatedRecToTK(String ticketuid, String ticketid, String orgid, String siteid, String tkclass, long relatedreckeyid, String relatedrecname, String relatetype, String relatedreckey, String relatedrecorgid, String relatedrecsiteid, String relatedrecclass)
/* 1244:     */     throws MobileApplicationException
/* 1245:     */   {
/* 1246:1344 */     MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager("TICKET");
/* 1247:1345 */     MobileMboDataBean tkBean = mgrDBMgr.getDataBean();
/* 1248:1346 */     tkBean.getQBE().setQbeExactMatch(true);
/* 1249:1347 */     tkBean.getQBE().setQBE("_ID", ticketuid);
/* 1250:1348 */     if (tkBean.getMobileMbo(0) == null) {
/* 1251:1349 */       return false;
/* 1252:     */     }
/* 1253:1352 */     String relatedset = "TKRELWOS";
/* 1254:1353 */     if (relatedrecname.equalsIgnoreCase("TICKET")) {
/* 1255:1354 */       relatedset = "TKRELTICKETS";
/* 1256:     */     }
/* 1257:1355 */     MobileMboDataBean reldatabean = tkBean.getDataBean(relatedset);
/* 1258:     */     
/* 1259:1357 */     reldatabean.insert();
/* 1260:1358 */     reldatabean.setValue("RECORDKEYID", ticketuid);
/* 1261:1359 */     reldatabean.setValue("RECORDKEY", ticketid);
/* 1262:1360 */     reldatabean.setValue("CLASS", tkclass);
/* 1263:1361 */     reldatabean.setValue("ORGID", orgid);
/* 1264:1362 */     reldatabean.setValue("SITEID", siteid);
/* 1265:1363 */     reldatabean.setValue("RELATETYPE", relatetype);
/* 1266:1364 */     reldatabean.getMobileMbo().setLongValue("RELATEDRECKEYID", relatedreckeyid);
/* 1267:1365 */     reldatabean.setValue("RELATEDRECORGID", relatedrecorgid);
/* 1268:1366 */     reldatabean.setValue("RELATEDRECSITEID", relatedrecsiteid);
/* 1269:1368 */     if (relatedrecname.equalsIgnoreCase("WORKORDER"))
/* 1270:     */     {
/* 1271:1370 */       reldatabean.setValue("RELATEDRECWONUM", relatedreckey);
/* 1272:1371 */       reldatabean.setValue("RELATEDRECWOCLASS", relatedrecclass);
/* 1273:     */     }
/* 1274:     */     else
/* 1275:     */     {
/* 1276:1375 */       reldatabean.setValue("RELATEDRECKEY", relatedreckey);
/* 1277:1376 */       reldatabean.setValue("RELATEDRECCLASS", relatedrecclass);
/* 1278:     */     }
/* 1279:1380 */     reldatabean.setValue("ASSETNUM", tkBean.getMobileMbo(0).getValue("ASSETNUM"));
/* 1280:1381 */     reldatabean.setValue("LOCATION", tkBean.getMobileMbo(0).getValue("LOCATION"));
/* 1281:1382 */     reldatabean.setValue("DESCRIPTION", tkBean.getMobileMbo(0).getValue("DESCRIPTION"));
/* 1282:1383 */     reldatabean.setValue("DESCRIPTION_LONGDESCRIPTION", tkBean.getMobileMbo(0).getValue("DESCRIPTION_LONGDESCRIPTION"));
/* 1283:     */     
/* 1284:1385 */     reldatabean = addInfoToRelatedRec(reldatabean);
/* 1285:1386 */     tkBean.getDataBeanManager().save();
/* 1286:     */     
/* 1287:1388 */     return true;
/* 1288:     */   }
/* 1289:     */   
/* 1290:     */   public boolean addRelatedRecordToTK(MobileMbo tk, MobileMbo relatedRec, String relatedrecname)
/* 1291:     */     throws MobileApplicationException
/* 1292:     */   {
/* 1293:1396 */     MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager("TICKET");
/* 1294:1397 */     MobileMboDataBean tkBean = mgrDBMgr.getDataBean();
/* 1295:1398 */     tkBean.getQBE().setQbeExactMatch(true);
/* 1296:1399 */     tkBean.getQBE().setQBE("_ID", tk.getValue("_ID"));
/* 1297:1400 */     if (tkBean.getMobileMbo(0) == null) {
/* 1298:1401 */       return false;
/* 1299:     */     }
/* 1300:1404 */     String relatedset = "TKRELWOS";
/* 1301:1405 */     if (relatedrecname.equalsIgnoreCase("TICKET")) {
/* 1302:1406 */       relatedset = "TKRELTICKETS";
/* 1303:     */     }
/* 1304:1407 */     MobileMboDataBean reldatabean = tkBean.getDataBean(relatedset);
/* 1305:     */     
/* 1306:1409 */     reldatabean.insert();
/* 1307:1410 */     reldatabean.setValue("RECORDKEYID", tk.getValue("_ID"));
/* 1308:1411 */     reldatabean.setValue("RECORDKEY", tk.getValue("TICKETID"));
/* 1309:1412 */     reldatabean.setValue("CLASS", tk.getValue("CLASS"));
/* 1310:1413 */     reldatabean.setValue("ORGID", tk.getValue("ORGID"));
/* 1311:1414 */     reldatabean.setValue("SITEID", tk.getValue("SITEID"));
/* 1312:1415 */     reldatabean.setValue("RELATETYPE", "");
/* 1313:1416 */     reldatabean.setValue("RELATEDRECKEYID", relatedRec.getValue("_ID"));
/* 1314:1417 */     reldatabean.setValue("RELATEDRECORGID", relatedRec.getValue("ORGID"));
/* 1315:1418 */     reldatabean.setValue("RELATEDRECSITEID", relatedRec.getValue("SITEID"));
/* 1316:1420 */     if (relatedrecname.equalsIgnoreCase("WORKORDER"))
/* 1317:     */     {
/* 1318:1421 */       reldatabean.setValue("RELATEDRECWONUM", relatedRec.getValue("WONUM"));
/* 1319:1422 */       reldatabean.setValue("RELATEDRECWOCLASS", relatedRec.getValue("WOCLASS"));
/* 1320:     */     }
/* 1321:     */     else
/* 1322:     */     {
/* 1323:1425 */       reldatabean.setValue("RELATEDRECKEY", relatedRec.getValue("TICKETID"));
/* 1324:1426 */       reldatabean.setValue("RELATEDRECCLASS", relatedRec.getValue("CLASS"));
/* 1325:     */     }
/* 1326:1429 */     reldatabean.setValue("STATUS", relatedRec.getValue("STATUS"));
/* 1327:1430 */     reldatabean.setValue("ASSETNUM", relatedRec.getValue("ASSETNUM"));
/* 1328:1431 */     reldatabean.setValue("LOCATION", relatedRec.getValue("LOCATION"));
/* 1329:1432 */     reldatabean.setValue("DESCRIPTION", relatedRec.getValue("DESCRIPTION"));
/* 1330:1433 */     reldatabean.setValue("DESCRIPTION_LONGDESCRIPTION", relatedRec.getValue("DESCRIPTION_LONGDESCRIPTION"));
/* 1331:     */     
/* 1332:1435 */     reldatabean = addInfoToRelatedRec(reldatabean);
/* 1333:1436 */     tkBean.getDataBeanManager().save();
/* 1334:     */     
/* 1335:1438 */     return true;
/* 1336:     */   }
/* 1337:     */   
/* 1338:     */   public MobileMboDataBean addInfoToRelatedRec(MobileMboDataBean reldatabean)
/* 1339:     */     throws MobileApplicationException
/* 1340:     */   {
/* 1341:1444 */     if (!reldatabean.getValue("ASSETNUM").equals(""))
/* 1342:     */     {
/* 1343:1446 */       MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager("ASSET");
/* 1344:1447 */       MobileMboDataBean bean = mgrDBMgr.getDataBean();
/* 1345:1448 */       bean.getQBE().reset();
/* 1346:1449 */       bean.getQBE().setQbeExactMatch(true);
/* 1347:1450 */       bean.getQBE().setQBE("SITEID", reldatabean.getValue("RELATEDRECSITEID"));
/* 1348:1451 */       bean.getQBE().setQBE("ASSETNUM", reldatabean.getValue("ASSETNUM"));
/* 1349:1452 */       bean.reset();
/* 1350:1453 */       if (bean.getMobileMbo(0) != null)
/* 1351:     */       {
/* 1352:1455 */         reldatabean.setValue("ASSET_DESCRIPTION", bean.getMobileMbo(0).getValue("DESCRIPTION"));
/* 1353:1456 */         reldatabean.setValue("ASSET_LONGDESCRIPTION", bean.getMobileMbo(0).getValue("DESCRIPTION_LONGDESCRIPTION"));
/* 1354:     */       }
/* 1355:     */     }
/* 1356:1461 */     if (!reldatabean.getValue("LOCATION").equals(""))
/* 1357:     */     {
/* 1358:1463 */       MobileMboDataBeanManager mgrDBMgr = new MobileMboDataBeanManager("LOCATIONS");
/* 1359:1464 */       MobileMboDataBean bean = mgrDBMgr.getDataBean();
/* 1360:1465 */       bean.getQBE().reset();
/* 1361:1466 */       bean.getQBE().setQbeExactMatch(true);
/* 1362:1467 */       bean.getQBE().setQBE("SITEID", reldatabean.getValue("RELATEDRECSITEID"));
/* 1363:1468 */       bean.getQBE().setQBE("LOCATION", reldatabean.getValue("LOCATION"));
/* 1364:1469 */       bean.reset();
/* 1365:1470 */       if (bean.getMobileMbo(0) != null)
/* 1366:     */       {
/* 1367:1472 */         reldatabean.setValue("LOCATION_DESCRIPTION", bean.getMobileMbo(0).getValue("DESCRIPTION"));
/* 1368:1473 */         reldatabean.setValue("LOCATION_LONGDESCRIPTION", bean.getMobileMbo(0).getValue("DESCRIPTION_LONGDESCRIPTION"));
/* 1369:     */       }
/* 1370:     */     }
/* 1371:1477 */     return reldatabean;
/* 1372:     */   }
/* 1373:     */   
/* 1374:     */   public static Hashtable initPageTabMapHashtable()
/* 1375:     */     throws MobileApplicationException
/* 1376:     */   {
/* 1377:1482 */     Hashtable ht = new Hashtable();
/* 1378:     */     
/* 1379:     */ 
/* 1380:     */ 
/* 1381:     */ 
/* 1382:     */ 
/* 1383:     */ 
/* 1384:1489 */     ht.put("workorder^main", "womain^womainTab1");
/* 1385:1490 */     ht.put("workorder^maindates", "womain^womainTab2");
/* 1386:1491 */     ht.put("workorder^mainother", "womain^womainTab3");
/* 1387:1492 */     ht.put("workorder^planstasks", "woplans^plansTab1");
/* 1388:1493 */     ht.put("workorder^planslabor", "woplans^plansTab2");
/* 1389:1494 */     ht.put("workorder^plansmaterial", "woplans^plansTab13");
/* 1390:1495 */     ht.put("workorder^plansservices", "woplans^plansTab4");
/* 1391:1496 */     ht.put("workorder^planstools", "woplans^plansTab5");
/* 1392:1497 */     ht.put("workorder^actualstasks", "actuals^tasksTab1");
/* 1393:1498 */     ht.put("workorder^actualslabor", "actuals^labactuals");
/* 1394:1499 */     ht.put("workorder^actualsmaterials", "actuals^matactuals");
/* 1395:1500 */     ht.put("workorder^actualstools", "actuals^toolactuals");
/* 1396:1501 */     ht.put("workorder^assetlist", "assetlist^alTab1");
/* 1397:1502 */     ht.put("workorder^locationlist", "assetlist^alTab2");
/* 1398:1503 */     ht.put("workorder^assetmeters", "meterread^metersTab1");
/* 1399:1504 */     ht.put("workorder^locationmeters", "meterread^metersTab2");
/* 1400:1505 */     ht.put("workorder^failurereport", "wofailure");
/* 1401:1506 */     ht.put("workorder^hazards", "wohazardspg^hazTab1");
/* 1402:1507 */     ht.put("workorder^lockouttagout", "wohazardspg^hazTab2");
/* 1403:1508 */     ht.put("workorder^worklog", "logs^wologTab1");
/* 1404:1509 */     ht.put("workorder^commlog", "logs^wologTab2");
/* 1405:1510 */     ht.put("workorder^satushist", "logs^wologTab3");
/* 1406:1511 */     ht.put("workorder^ownerhist", "logs^wologTab4");
/* 1407:1512 */     ht.put("workorder^attachments", "woviewattachments");
/* 1408:1513 */     ht.put("workorder^relticket", "worelatedrecords^worrTab1");
/* 1409:1514 */     ht.put("workorder^relwo", "worelatedrecords^worrTab2");
/* 1410:     */     
/* 1411:1516 */     ht.put("workorder^multiassetlocci", "womultiassetloccilist^tabmainwomulti");
/* 1412:     */     
/* 1413:     */ 
/* 1414:1519 */     ht.put("activity^main", "womain^womainTab1");
/* 1415:1520 */     ht.put("activity^maindates", "womain^womainTab2");
/* 1416:1521 */     ht.put("activity^mainother", "womain^womainTab3");
/* 1417:1522 */     ht.put("activity^planstasks", "woplans^plansTab1");
/* 1418:1523 */     ht.put("activity^planslabor", "woplans^plansTab2");
/* 1419:1524 */     ht.put("activity^plansmaterial", "woplans^plansTab13");
/* 1420:1525 */     ht.put("activity^plansservices", "woplans^plansTab4");
/* 1421:1526 */     ht.put("activity^planstools", "woplans^plansTab5");
/* 1422:1527 */     ht.put("activity^actualstasks", "actuals^tasksTab1");
/* 1423:1528 */     ht.put("activity^actualslabor", "actuals^labactuals");
/* 1424:1529 */     ht.put("activity^actualsmaterials", "actuals^matactuals");
/* 1425:1530 */     ht.put("activity^actualstools", "actuals^toolactuals");
/* 1426:1531 */     ht.put("activity^assetlist", "assetlist^alTab1");
/* 1427:1532 */     ht.put("activity^locationlist", "assetlist^alTab2");
/* 1428:1533 */     ht.put("activity^assetmeters", "meterread^metersTab1");
/* 1429:1534 */     ht.put("activity^locationmeters", "meterread^metersTab2");
/* 1430:1535 */     ht.put("activity^failurereport", "wofailure");
/* 1431:1536 */     ht.put("activity^hazards", "wohazardspg^hazTab1");
/* 1432:1537 */     ht.put("activity^lockouttagout", "wohazardspg^hazTab2");
/* 1433:1538 */     ht.put("activity^worklog", "logs^wologTab1");
/* 1434:1539 */     ht.put("activity^commlog", "logs^wologTab2");
/* 1435:1540 */     ht.put("activity^satushist", "logs^wologTab3");
/* 1436:1541 */     ht.put("activity^ownerhist", "logs^wologTab4");
/* 1437:1542 */     ht.put("activity^attachments", "woviewattachments");
/* 1438:1543 */     ht.put("activity^relticket", "worelatedrecords^worrTab1");
/* 1439:1544 */     ht.put("activity^relwo", "worelatedrecords^worrTab2");
/* 1440:     */     
/* 1441:1546 */     ht.put("activity^multiassetlocci", "womultiassetloccilist^tabmainwomulti");
/* 1442:     */     
/* 1443:     */ 
/* 1444:     */ 
/* 1445:     */ 
/* 1446:     */ 
/* 1447:     */ 
/* 1448:     */ 
/* 1449:1554 */     ht.put("anyvalue^anyvalue", "tkactivity^acttab1");
/* 1450:     */     
/* 1451:     */ 
/* 1452:1557 */     ht.put("change^main", "womain^womainTab1");
/* 1453:1558 */     ht.put("change^maindates", "womain^womainTab2");
/* 1454:1559 */     ht.put("change^mainother", "womain^womainTab3");
/* 1455:1560 */     ht.put("change^planstasks", "woplans^plansTab1");
/* 1456:1561 */     ht.put("change^planslabor", "woplans^plansTab2");
/* 1457:1562 */     ht.put("change^plansmaterial", "woplans^plansTab13");
/* 1458:1563 */     ht.put("change^plansservices", "woplans^plansTab4");
/* 1459:1564 */     ht.put("change^planstools", "woplans^plansTab5");
/* 1460:1565 */     ht.put("change^actualstasks", "actuals^tasksTab1");
/* 1461:1566 */     ht.put("change^actualslabor", "actuals^labactuals");
/* 1462:1567 */     ht.put("change^actualsmaterials", "actuals^matactuals");
/* 1463:1568 */     ht.put("change^actualstools", "actuals^toolactuals");
/* 1464:1569 */     ht.put("change^assetlist", "assetlist^alTab1");
/* 1465:1570 */     ht.put("change^locationlist", "assetlist^alTab2");
/* 1466:1571 */     ht.put("change^assetmeters", "meterread^metersTab1");
/* 1467:1572 */     ht.put("change^locationmeters", "meterread^metersTab2");
/* 1468:1573 */     ht.put("change^failurereport", "wofailure");
/* 1469:1574 */     ht.put("change^hazards", "wohazardspg^hazTab1");
/* 1470:1575 */     ht.put("change^lockouttagout", "wohazardspg^hazTab2");
/* 1471:1576 */     ht.put("change^worklog", "logs^wologTab1");
/* 1472:1577 */     ht.put("change^commlog", "logs^wologTab2");
/* 1473:1578 */     ht.put("change^satushist", "logs^wologTab3");
/* 1474:1579 */     ht.put("change^ownerhist", "logs^wologTab4");
/* 1475:1580 */     ht.put("change^attachments", "woviewattachments");
/* 1476:1581 */     ht.put("change^relticket", "worelatedrecords^worrTab1");
/* 1477:1582 */     ht.put("change^relwo", "worelatedrecords^worrTab2");
/* 1478:1583 */     ht.put("change^areasaffected", "woareasaffected");
/* 1479:     */     
/* 1480:1585 */     ht.put("change^multiassetlocci", "womultiassetloccilist^tabmainwomulti");
/* 1481:     */     
/* 1482:     */ 
/* 1483:1588 */     ht.put("release^main", "womain^womainTab1");
/* 1484:1589 */     ht.put("release^maindates", "womain^womainTab2");
/* 1485:1590 */     ht.put("release^mainother", "womain^womainTab3");
/* 1486:1591 */     ht.put("release^planstasks", "woplans^plansTab1");
/* 1487:1592 */     ht.put("release^planslabor", "woplans^plansTab2");
/* 1488:1593 */     ht.put("release^plansmaterial", "woplans^plansTab13");
/* 1489:1594 */     ht.put("release^plansservices", "woplans^plansTab4");
/* 1490:1595 */     ht.put("release^planstools", "woplans^plansTab5");
/* 1491:1596 */     ht.put("release^actualstasks", "actuals^tasksTab1");
/* 1492:1597 */     ht.put("release^actualslabor", "actuals^labactuals");
/* 1493:1598 */     ht.put("release^actualsmaterials", "actuals^matactuals");
/* 1494:1599 */     ht.put("release^actualstools", "actuals^toolactuals");
/* 1495:1600 */     ht.put("release^assetlist", "assetlist^alTab1");
/* 1496:1601 */     ht.put("release^locationlist", "assetlist^alTab2");
/* 1497:1602 */     ht.put("release^assetmeters", "meterread^metersTab1");
/* 1498:1603 */     ht.put("release^locationmeters", "meterread^metersTab2");
/* 1499:1604 */     ht.put("release^failurereport", "wofailure");
/* 1500:1605 */     ht.put("release^hazards", "wohazardspg^hazTab1");
/* 1501:1606 */     ht.put("release^lockouttagout", "wohazardspg^hazTab2");
/* 1502:1607 */     ht.put("release^worklog", "logs^wologTab1");
/* 1503:1608 */     ht.put("release^commlog", "logs^wologTab2");
/* 1504:1609 */     ht.put("release^satushist", "logs^wologTab3");
/* 1505:1610 */     ht.put("release^ownerhist", "logs^wologTab4");
/* 1506:1611 */     ht.put("release^attachments", "woviewattachments");
/* 1507:1612 */     ht.put("release^relticket", "worelatedrecords^worrTab1");
/* 1508:1613 */     ht.put("release^relwo", "worelatedrecords^worrTab2");
/* 1509:1614 */     ht.put("release^areasaffected", "woareasaffected");
/* 1510:     */     
/* 1511:1616 */     ht.put("release^multiassetlocci", "womultiassetloccilist^tabmainwomulti");
/* 1512:     */     
/* 1513:     */ 
/* 1514:1619 */     ht.put("sr^main", "ticketmain^tktmainTab1");
/* 1515:1620 */     ht.put("sr^maindates", "ticketmain^tktmainTab2");
/* 1516:1621 */     ht.put("sr^mainother", "ticketmain^tktmainTab4");
/* 1517:1622 */     ht.put("sr^activity", "tkactivity");
/* 1518:1623 */     ht.put("sr^time", "tktime");
/* 1519:1624 */     ht.put("sr^worklog", "tkhistory^tklogTab1");
/* 1520:1625 */     ht.put("sr^commlog", "tkhistory^tklogTab2");
/* 1521:1626 */     ht.put("sr^satushist", "tkhistory^tklogTab3");
/* 1522:1627 */     ht.put("sr^ownerhist", "tkhistory^tklogTab4");
/* 1523:1628 */     ht.put("sr^relticket", "tkrelatedrecords^tkrrTab1");
/* 1524:1629 */     ht.put("sr^relwo", "tkrelatedrecords^tkrrTab2");
/* 1525:1630 */     ht.put("sr^solution", "tksoluton");
/* 1526:1631 */     ht.put("sr^failurereport", "tkfailure");
/* 1527:1632 */     ht.put("sr^attachments", "tkviewattachments");
/* 1528:     */     
/* 1529:1634 */     ht.put("sr^multiassetlocci", "tkmultiassetloccilist^tabmaintkmulti");
/* 1530:     */     
/* 1531:     */ 
/* 1532:1637 */     ht.put("incident^main", "ticketmain^tktmainTab1");
/* 1533:1638 */     ht.put("incident^maindates", "ticketmain^tktmainTab2");
/* 1534:1639 */     ht.put("incident^mainother", "ticketmain^tktmainTab4");
/* 1535:1640 */     ht.put("incident^activity", "tkactivity");
/* 1536:1641 */     ht.put("incident^time", "tktime");
/* 1537:1642 */     ht.put("incident^worklog", "tkhistory^tklogTab1");
/* 1538:1643 */     ht.put("incident^commlog", "tkhistory^tklogTab2");
/* 1539:1644 */     ht.put("incident^satushist", "tkhistory^tklogTab3");
/* 1540:1645 */     ht.put("incident^ownerhist", "tkhistory^tklogTab4");
/* 1541:1646 */     ht.put("incident^relticket", "tkrelatedrecords^tkrrTab1");
/* 1542:1647 */     ht.put("incident^relwo", "tkrelatedrecords^tkrrTab2");
/* 1543:1648 */     ht.put("incident^solution", "tksoluton");
/* 1544:1649 */     ht.put("incident^failurereport", "tkfailure");
/* 1545:1650 */     ht.put("incident^attachments", "tkviewattachments");
/* 1546:     */     
/* 1547:1652 */     ht.put("incident^multiassetlocci", "tkmultiassetloccilist^tabmaintkmulti");
/* 1548:     */     
/* 1549:     */ 
/* 1550:1655 */     ht.put("problem^main", "ticketmain^tktmainTab1");
/* 1551:1656 */     ht.put("problem^maindates", "ticketmain^tktmainTab2");
/* 1552:1657 */     ht.put("problem^mainother", "ticketmain^tktmainTab4");
/* 1553:1658 */     ht.put("problem^activity", "tkactivity");
/* 1554:1659 */     ht.put("problem^time", "tktime");
/* 1555:1660 */     ht.put("problem^worklog", "tkhistory^tklogTab1");
/* 1556:1661 */     ht.put("problem^commlog", "tkhistory^tklogTab2");
/* 1557:1662 */     ht.put("problem^satushist", "tkhistory^tklogTab3");
/* 1558:1663 */     ht.put("problem^ownerhist", "tkhistory^tklogTab4");
/* 1559:1664 */     ht.put("problem^relticket", "tkrelatedrecords^tkrrTab1");
/* 1560:1665 */     ht.put("problem^relwo", "tkrelatedrecords^tkrrTab2");
/* 1561:1666 */     ht.put("problem^solution", "tksoluton");
/* 1562:1667 */     ht.put("problem^failurereport", "tkfailure");
/* 1563:1668 */     ht.put("problem^attachments", "tkviewattachments");
/* 1564:     */     
/* 1565:1670 */     ht.put("problem^multiassetlocci", "tkmultiassetloccilist^tabmaintkmulti");
/* 1566:     */     
/* 1567:1672 */     return ht;
/* 1568:     */   }
/* 1569:     */   
/* 1570:     */   public static Hashtable getHtPageTabMap()
/* 1571:     */     throws MobileApplicationException
/* 1572:     */   {
/* 1573:1677 */     return htPageTabMap;
/* 1574:     */   }
/* 1575:     */   
/* 1576:     */   protected String[] recordsToWatchModifications()
/* 1577:     */   {
/* 1578:1681 */     return new String[] { "WORKORDER", "TICKET" };
/* 1579:     */   }
/* 1580:     */   
/* 1581:     */   public boolean pageAcceptsBackButtonInPopUp(String pageName)
/* 1582:     */   {
/* 1583:1685 */     if (pageName == null) {
/* 1584:1686 */       return false;
/* 1585:     */     }
/* 1586:1687 */     return ("selectworklistrecordtype".equalsIgnoreCase(pageName)) || (super.pageAcceptsBackButtonInPopUp(pageName));
/* 1587:     */   }
/* 1588:     */   
/* 1589:     */   public boolean sendsUserLocationWhenConnected()
/* 1590:     */   {
/* 1591:1691 */     boolean result = false;
/* 1592:1692 */     if (isUserLocationProfileSet()) {
/* 1593:     */       try
/* 1594:     */       {
/* 1595:1694 */         result = (isDataCollectionEnaled()) && (getLBSCollectionInterval() > 0L);
/* 1596:     */       }
/* 1597:     */       catch (Exception e)
/* 1598:     */       {
/* 1599:1696 */         MobileLoggerFactory.getDefaultLogger().warn("Could not define if user current location needs to be sent or not. Using default to not send it.", e);
/* 1600:     */       }
/* 1601:     */     }
/* 1602:1699 */     return result;
/* 1603:     */   }
/* 1604:     */   
/* 1605:     */   public static String getGlobalWOMaxProperty(String key)
/* 1606:     */     throws MobileApplicationException
/* 1607:     */   {
/* 1608:1703 */     MobileMboDataBean listBean = DataBeanCache.getDataBean("WOMAXPROPS", "WOMAXPROPS");
/* 1609:1704 */     int count = listBean.count();
/* 1610:1705 */     listBean.dataExists(count);
/* 1611:1706 */     listBean.close();
/* 1612:1707 */     listBean.indexMobileMboDataBean("WOMAXPROPS", new String[] { "PROPNAME" }, false);
/* 1613:     */     
/* 1614:1709 */     MobileMbo mbo = listBean.getIndexedMobileMbo("WOMAXPROPS", new String[] { key });
/* 1615:1710 */     if (mbo != null) {
/* 1616:1711 */       return mbo.getValue("PROPVALUE");
/* 1617:     */     }
/* 1618:1713 */     return "";
/* 1619:     */   }
/* 1620:     */   
/* 1621:     */   public boolean isDataCollectionEnaled()
/* 1622:     */     throws MobileApplicationException
/* 1623:     */   {
/* 1624:1718 */     return "1".equals(getGlobalWOMaxProperty("mxe.lbs.dataCollection.enabled"));
/* 1625:     */   }
/* 1626:     */   
/* 1627:     */   public long getLBSCollectionInterval()
/* 1628:     */     throws MobileApplicationException
/* 1629:     */   {
/* 1630:1722 */     MobileMboDataBean listBean = DataBeanCache.getDataBean("LABORPOSCOLSETTINGS", "LABORPOSCOLSETTINGS");
/* 1631:1723 */     listBean.dataExists(0);
/* 1632:1724 */     MobileMbo laborSettings = listBean.getMobileMbo(0);
/* 1633:1725 */     if (laborSettings == null) {
/* 1634:1726 */       return 0L;
/* 1635:     */     }
/* 1636:1728 */     return laborSettings.getLongValue("LBSINTERVAL");
/* 1637:     */   }
/* 1638:     */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.mro.mobileapp.WOApp
 * JD-Core Version:    0.7.0.1
 */