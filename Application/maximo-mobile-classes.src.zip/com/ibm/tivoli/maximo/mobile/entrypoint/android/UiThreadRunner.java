package com.ibm.tivoli.maximo.mobile.entrypoint.android;

public abstract interface UiThreadRunner
{
  public abstract void runOnUiThread(Runnable paramRunnable);
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.ibm.tivoli.maximo.mobile.entrypoint.android.UiThreadRunner
 * JD-Core Version:    0.7.0.1
 */