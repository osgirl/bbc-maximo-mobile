/*   1:    */ package com.ibm.tivoli.maximo.mobile.entrypoint.android;
/*   2:    */ 
/*   3:    */ import android.app.Activity;
/*   4:    */ import android.app.Application;
/*   5:    */ import android.content.Context;
/*   6:    */ import android.content.Intent;
/*   7:    */ import android.content.pm.ApplicationInfo;
/*   8:    */ import android.location.LocationManager;
/*   9:    */ import android.os.Bundle;
/*  10:    */ import android.os.Environment;
/*  11:    */ import android.os.Handler;
/*  12:    */ import android.os.Process;
/*  13:    */ import android.util.Log;
/*  14:    */ import com.ibm.tivoli.maximo.mobile.android.BaseStartupActivity;
/*  15:    */ import com.ibm.tivoli.maximo.mobile.android.DefaultMaximoMobileActivity;
/*  16:    */ import com.ibm.tivoli.maximo.mobile.android.persist.AndroidRDORuntimeFactory;
/*  17:    */ import com.ibm.tivoli.maximo.mobile.android.sensor.barcode.AndroidBarcodeReaderSupport;
/*  18:    */ import com.ibm.tivoli.maximo.mobile.android.sensor.rfid.AndroidRFIDReaderSupport;
/*  19:    */ import com.ibm.tivoli.maximo.mobile.android.userlocation.AndroidGPSNetworkUserLocationProvider;
/*  20:    */ import com.ibm.tivoli.maximo.mobile.android.util.LaunchResult;
/*  21:    */ import com.ibm.tivoli.maximo.mobile.comm.AndroidConnectionTimeoutConfigurator;
/*  22:    */ import com.ibm.tivoli.maximo.mobile.entrypoint.MobileAppEntryPoint;
/*  23:    */ import com.mro.mobile.MobileApplicationException;
/*  24:    */ import com.mro.mobile.app.BasicMobileDeviceUIApplication;
/*  25:    */ import com.mro.mobile.app.SystemInterface;
/*  26:    */ import com.mro.mobile.app.async.android.AndroidAsynchronousExecutor;
/*  27:    */ import com.mro.mobile.app.update.android.AndroidSoftwareUpdateHelper;
/*  28:    */ import com.mro.mobile.comm.ConnectionTimeoutConfigurator;
/*  29:    */ import com.mro.mobile.ui.res.MobileUIProperties;
/*  30:    */ import com.mro.mobile.ui.res.android.ADFontColorResolverImpl;
/*  31:    */ import com.mro.mobile.ui.res.android.AndroidMobileUIPropertiesSupport;
/*  32:    */ import com.mro.mobile.ui.res.controls.utils.ControlStyle;
/*  33:    */ import com.mro.mobile.ui.res.controls.utils.StyleManager;
/*  34:    */ import com.mro.mobile.ui.res.controls.utils.android.ADFontCreatorImpl;
/*  35:    */ import com.mro.mobile.ui.res.controls.utils.android.AndroidStyleManagerSupport;
/*  36:    */ import com.mro.mobile.ui.res.widgets.android.AndroidEnv;
/*  37:    */ import com.mro.mobile.util.MobileLogger;
/*  38:    */ import com.mro.mobile.util.MobileLoggerFactory;
/*  39:    */ import com.mro.mobile.util.MultiStreamer;
/*  40:    */ import com.mro.mobile.util.PlatformIndicator;
/*  41:    */ import com.mro.mobile.util.android.ADFileStreamerImpl;
/*  42:    */ import com.mro.mobile.util.android.ADStreamerImpl;
/*  43:    */ import java.io.File;
/*  44:    */ 
/*  45:    */ public abstract class AndroidMobileAppEntryPoint<T extends BasicMobileDeviceUIApplication>
/*  46:    */   extends Application
/*  47:    */   implements MobileAppEntryPoint, ActivityLifecycleListener, UiThreadRunner
/*  48:    */ {
/*  49:    */   public static final String NEED_POST_LAUNCH = "MAXIMO_MOBILE_NEED_POST_LAUNCH";
/*  50:    */   private static final String PREVPID = "PREVPID";
/*  51: 68 */   private Handler mHandler = null;
/*  52: 70 */   private Thread mUiThread = null;
/*  53:    */   private T application;
/*  54:    */   
/*  55:    */   static
/*  56:    */   {
/*  57: 75 */     ControlStyle.registerFontCreator(new ADFontCreatorImpl());
/*  58: 76 */     StyleManager.registerStyleManagerSupport(new AndroidStyleManagerSupport());
/*  59: 77 */     PlatformIndicator.setPlatformIndicator(PlatformIndicator.ANDROID);
/*  60:    */   }
/*  61:    */   
/*  62:    */   public void onCreate()
/*  63:    */   {
/*  64: 81 */     super.onCreate();
/*  65:    */     
/*  66:    */ 
/*  67: 84 */     MultiStreamer logStreamer = new MultiStreamer(new ADStreamerImpl(), new ADFileStreamerImpl(getApplicationInfo().packageName));
/*  68: 85 */     MobileLogger.registerStreamer(logStreamer);
/*  69:    */     
/*  70: 87 */     this.mHandler = new Handler();
/*  71: 88 */     this.mUiThread = Thread.currentThread();
/*  72:    */   }
/*  73:    */   
/*  74:    */   public LaunchResult launchMaximoMobile()
/*  75:    */   {
/*  76:100 */     LaunchResult result = null;
/*  77:101 */     if (this.application == null)
/*  78:    */     {
/*  79:102 */       this.application = newApplicationInstance();
/*  80:    */       try
/*  81:    */       {
/*  82:104 */         start(this.application);
/*  83:105 */         result = new LaunchResult();
/*  84:    */       }
/*  85:    */       catch (Exception e)
/*  86:    */       {
/*  87:107 */         cleanUp();
/*  88:108 */         result = new LaunchResult(e);
/*  89:109 */         Log.e("MAXIMO_MOBILE", e.getMessage(), e);
/*  90:    */       }
/*  91:    */     }
/*  92:    */     else
/*  93:    */     {
/*  94:112 */       result = new LaunchResult(new IllegalStateException("Application already launched"));
/*  95:    */     }
/*  96:114 */     return result;
/*  97:    */   }
/*  98:    */   
/*  99:    */   public void shutdownMobileApplication()
/* 100:    */   {
/* 101:118 */     cleanUp();
/* 102:119 */     AndroidEnv.getCurrentActivity().finish();
/* 103:120 */     Process.killProcess(Process.myPid());
/* 104:    */   }
/* 105:    */   
/* 106:    */   protected void cleanUp()
/* 107:    */   {
/* 108:124 */     if (this.application != null) {
/* 109:    */       try
/* 110:    */       {
/* 111:126 */         this.application.releaseApplication();
/* 112:127 */         this.application = null;
/* 113:    */       }
/* 114:    */       catch (Exception e2) {}
/* 115:    */     }
/* 116:    */   }
/* 117:    */   
/* 118:    */   public T getMaximoMobileApplication()
/* 119:    */   {
/* 120:134 */     return this.application;
/* 121:    */   }
/* 122:    */   
/* 123:    */   public void onTerminate()
/* 124:    */   {
/* 125:139 */     super.onTerminate();
/* 126:140 */     cleanUp();
/* 127:    */   }
/* 128:    */   
/* 129:    */   public void injectPlugabbleComponentsBeforeBoot(BasicMobileDeviceUIApplication application)
/* 130:    */     throws Exception
/* 131:    */   {
/* 132:145 */     setupSystemInterface(application);
/* 133:146 */     setupSystemProperties(application);
/* 134:147 */     setupSoftwareUpdateHelper(application);
/* 135:148 */     setupRDORuntimeFactory(application);
/* 136:149 */     setupAsynchronousExecutor(application);
/* 137:150 */     setupBarcodeReader(application);
/* 138:151 */     setupRFIDReader(application);
/* 139:152 */     setupGPSLocationProvider(application);
/* 140:    */   }
/* 141:    */   
/* 142:    */   public void setupGPSLocationProvider(BasicMobileDeviceUIApplication application)
/* 143:    */   {
/* 144:156 */     application.pluginGPSUserLocationProvider(new AndroidGPSNetworkUserLocationProvider(this, (LocationManager)getSystemService("location"), MobileLoggerFactory.getLogger("maximo.mobile.sensor")));
/* 145:    */   }
/* 146:    */   
/* 147:    */   public void setupSystemInterface(BasicMobileDeviceUIApplication application)
/* 148:    */   {
/* 149:163 */     SystemInterface sif = new SystemInterface()
/* 150:    */     {
/* 151:    */       public void exitSystem()
/* 152:    */       {
/* 153:166 */         AndroidMobileAppEntryPoint.this.cleanUp();
/* 154:167 */         AndroidEnv.getCurrentActivity().finish();
/* 155:168 */         Process.killProcess(Process.myPid());
/* 156:    */       }
/* 157:171 */     };
/* 158:172 */     application.setSystemInterface(sif);
/* 159:    */   }
/* 160:    */   
/* 161:    */   public void setupSoftwareUpdateHelper(BasicMobileDeviceUIApplication application)
/* 162:    */   {
/* 163:177 */     new AndroidSoftwareUpdateHelper(application, getApplicationInfo().packageName, MobileLoggerFactory.getDefaultLogger());
/* 164:    */   }
/* 165:    */   
/* 166:    */   public void setupSystemProperties(BasicMobileDeviceUIApplication application)
/* 167:    */   {
/* 168:182 */     application.setSystemProperty("database.name", "sqlite");
/* 169:183 */     application.setSystemProperty("database.home", getDatabasePath(getMaximoMobileApplicationAcronym()).getAbsolutePath());
/* 170:    */     
/* 171:    */ 
/* 172:186 */     String connectTimeout = application.getProperty("maximo.mobile.android.connection.connecttimeout");
/* 173:187 */     String readTimeout = application.getProperty("maximo.mobile.android.connection.readtimeout");
/* 174:188 */     application.setSystemProperty("maximo.mobile.android.connection.connecttimeout", connectTimeout);
/* 175:189 */     application.setSystemProperty("maximo.mobile.android.connection.readtimeout", readTimeout);
/* 176:190 */     setupAttachmentOutputFolder(application);
/* 177:    */   }
/* 178:    */   
/* 179:    */   protected void setupAttachmentOutputFolder(BasicMobileDeviceUIApplication application)
/* 180:    */   {
/* 181:194 */     File rootStorageDir = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + File.separator + "maximomobile");
/* 182:196 */     if ((rootStorageDir != null) && 
/* 183:197 */       (!rootStorageDir.exists()) && 
/* 184:198 */       (!rootStorageDir.mkdirs())) {
/* 185:199 */       MobileLoggerFactory.getDefaultLogger().warn("Failed to create root file storage dir: " + rootStorageDir.getAbsolutePath());
/* 186:    */     }
/* 187:203 */     application.setSystemProperty("maximo.mobile.root.storage.folder", rootStorageDir.getAbsolutePath());
/* 188:    */   }
/* 189:    */   
/* 190:    */   protected String getMaximoMobileApplicationAcronym()
/* 191:    */   {
/* 192:207 */     String packageName = getApplicationContext().getPackageName();
/* 193:208 */     int index = packageName.lastIndexOf("mobile");
/* 194:209 */     String result = index >= 0 ? packageName.substring(index) : "aMobileApplication";
/* 195:210 */     return result;
/* 196:    */   }
/* 197:    */   
/* 198:    */   public void setupAsynchronousExecutor(BasicMobileDeviceUIApplication application)
/* 199:    */   {
/* 200:215 */     application.setAsynchronousExecutor(new AndroidAsynchronousExecutor(this));
/* 201:    */   }
/* 202:    */   
/* 203:    */   public void setupRDORuntimeFactory(BasicMobileDeviceUIApplication application)
/* 204:    */     throws Exception
/* 205:    */   {
/* 206:220 */     String databaseName = application.getSystemProperty("database.name");
/* 207:221 */     String databaseHome = application.getSystemProperty("database.home");
/* 208:222 */     application.setRDORuntimeFactory(new AndroidRDORuntimeFactory(this, databaseHome, databaseName, MobileLoggerFactory.getLogger("maximo.mobile.persistence")));
/* 209:    */   }
/* 210:    */   
/* 211:    */   public void injectPlugabbleComponentsAfterBoot(BasicMobileDeviceUIApplication application)
/* 212:    */     throws Exception
/* 213:    */   {
/* 214:228 */     setupConnectionTimeoutConfigurator(application);
/* 215:    */   }
/* 216:    */   
/* 217:    */   public void start(BasicMobileDeviceUIApplication application)
/* 218:    */     throws Exception
/* 219:    */   {
/* 220:233 */     injectPlugabbleComponentsBeforeBoot(application);
/* 221:234 */     application.boot();
/* 222:235 */     injectPlugabbleComponentsAfterBoot(application);
/* 223:236 */     registerGlobalSettingsAfterBoot();
/* 224:237 */     application.start();
/* 225:    */   }
/* 226:    */   
/* 227:    */   public void registerGlobalSettingsAfterBoot()
/* 228:    */   {
/* 229:242 */     MobileUIProperties.registerMobileUIPropertiesSupport(new AndroidMobileUIPropertiesSupport());
/* 230:243 */     MobileUIProperties.registerFontColorResolver(new ADFontColorResolverImpl());
/* 231:    */   }
/* 232:    */   
/* 233:    */   public void setupBarcodeReader(BasicMobileDeviceUIApplication application)
/* 234:    */   {
/* 235:248 */     String builtinNameOrClassName = application.getProperty("maximo.mobile.barcode");
/* 236:249 */     if (builtinNameOrClassName != null) {
/* 237:250 */       application.plugBarcodeReaderSupport(new AndroidBarcodeReaderSupport(builtinNameOrClassName));
/* 238:    */     }
/* 239:    */   }
/* 240:    */   
/* 241:    */   public void setupRFIDReader(BasicMobileDeviceUIApplication application)
/* 242:    */   {
/* 243:256 */     String builtinNameOrClassName = application.getProperty("maximo.mobile.rfid");
/* 244:257 */     if (builtinNameOrClassName != null) {
/* 245:258 */       application.plugRFIDReaderSupport(new AndroidRFIDReaderSupport(builtinNameOrClassName));
/* 246:    */     }
/* 247:    */   }
/* 248:    */   
/* 249:    */   public void setupConnectionTimeoutConfigurator(BasicMobileDeviceUIApplication application)
/* 250:    */   {
/* 251:263 */     ConnectionTimeoutConfigurator configurator = new AndroidConnectionTimeoutConfigurator();
/* 252:264 */     application.pluginConnectionTimeoutConfigurator(configurator);
/* 253:    */   }
/* 254:    */   
/* 255:    */   public void postLaunchMaximoMobile()
/* 256:    */     throws MobileApplicationException
/* 257:    */   {
/* 258:268 */     if (this.application != null) {
/* 259:269 */       this.application.postStart();
/* 260:    */     }
/* 261:    */   }
/* 262:    */   
/* 263:    */   public void launchNewActivityOnStack()
/* 264:    */   {
/* 265:274 */     Intent intent = new Intent(this, DefaultMaximoMobileActivity.class);
/* 266:275 */     getCurrentActivity().startActivity(intent);
/* 267:    */   }
/* 268:    */   
/* 269:    */   public void launchNewActivityAfterApplicationLaunch()
/* 270:    */   {
/* 271:279 */     Intent intent = new Intent(this, DefaultMaximoMobileActivity.class);
/* 272:280 */     intent.putExtra("MAXIMO_MOBILE_NEED_POST_LAUNCH", true);
/* 273:281 */     intent.setFlags(268435456);
/* 274:282 */     startActivity(intent);
/* 275:    */   }
/* 276:    */   
/* 277:    */   public Activity getCurrentActivity()
/* 278:    */   {
/* 279:286 */     return AndroidEnv.getCurrentActivity();
/* 280:    */   }
/* 281:    */   
/* 282:    */   public void onActivityCreated(Activity activity, Bundle savedInstanceState)
/* 283:    */   {
/* 284:291 */     if ((savedInstanceState != null) && 
/* 285:292 */       (foundNewProcessForCurrentApp(savedInstanceState)))
/* 286:    */     {
/* 287:    */       try
/* 288:    */       {
/* 289:294 */         Intent intent = new Intent(activity, getSplashScreenClass());
/* 290:295 */         intent.setFlags(268435456);
/* 291:296 */         startActivity(intent);
/* 292:    */       }
/* 293:    */       finally
/* 294:    */       {
/* 295:299 */         activity.finish();
/* 296:    */       }
/* 297:301 */       return;
/* 298:    */     }
/* 299:304 */     AndroidEnv.setCurrentActivity(activity);
/* 300:    */   }
/* 301:    */   
/* 302:    */   public void onActivityDestroyed(Activity activity)
/* 303:    */   {
/* 304:309 */     AndroidEnv.removeActivity(activity);
/* 305:310 */     cleanUp();
/* 306:    */   }
/* 307:    */   
/* 308:    */   public void onActivityResumed(Activity activity)
/* 309:    */   {
/* 310:319 */     AndroidEnv.setCurrentActivity(activity);
/* 311:    */   }
/* 312:    */   
/* 313:    */   public void onActivitySaveInstanceState(Activity activity, Bundle outState)
/* 314:    */   {
/* 315:324 */     outState.putInt("PREVPID", Process.myPid());
/* 316:    */   }
/* 317:    */   
/* 318:    */   public void onActivityStarted(Activity activity)
/* 319:    */   {
/* 320:329 */     AndroidEnv.setCurrentActivity(activity);
/* 321:    */   }
/* 322:    */   
/* 323:    */   public final void runOnUiThread(Runnable action)
/* 324:    */   {
/* 325:337 */     if (Thread.currentThread() != this.mUiThread) {
/* 326:338 */       this.mHandler.post(action);
/* 327:    */     } else {
/* 328:340 */       action.run();
/* 329:    */     }
/* 330:    */   }
/* 331:    */   
/* 332:    */   public boolean isUIThread(Thread candidate)
/* 333:    */   {
/* 334:345 */     return candidate == this.mUiThread;
/* 335:    */   }
/* 336:    */   
/* 337:    */   private boolean foundNewProcessForCurrentApp(Bundle savedInstanceState)
/* 338:    */   {
/* 339:357 */     return Process.myPid() != savedInstanceState.getInt("PREVPID");
/* 340:    */   }
/* 341:    */   
/* 342:    */   protected abstract T newApplicationInstance();
/* 343:    */   
/* 344:    */   public void onActivityPaused(Activity activity) {}
/* 345:    */   
/* 346:    */   public void onActivityStopped(Activity activity) {}
/* 347:    */   
/* 348:    */   protected abstract Class<? extends BaseStartupActivity> getSplashScreenClass();
/* 349:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.ibm.tivoli.maximo.mobile.entrypoint.android.AndroidMobileAppEntryPoint
 * JD-Core Version:    0.7.0.1
 */