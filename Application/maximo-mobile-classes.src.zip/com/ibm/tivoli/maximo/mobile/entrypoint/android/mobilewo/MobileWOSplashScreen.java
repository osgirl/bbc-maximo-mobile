/*  1:   */ package com.ibm.tivoli.maximo.mobile.entrypoint.android.mobilewo;
/*  2:   */ 
/*  3:   */ import com.ibm.tivoli.maximo.mobile.android.BaseStartupActivity;
/*  4:   */ import com.ibm.tivoli.maximo.mobile.android.util.UIUtil;
/*  5:   */ 
/*  6:   */ public class MobileWOSplashScreen
/*  7:   */   extends BaseStartupActivity
/*  8:   */ {
/*  9:   */   protected int getSplashScreenId()
/* 10:   */   {
/* 11:27 */     return UIUtil.getResourceId(R.layout.class, "splash_screen");
/* 12:   */   }
/* 13:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.ibm.tivoli.maximo.mobile.entrypoint.android.mobilewo.MobileWOSplashScreen
 * JD-Core Version:    0.7.0.1
 */