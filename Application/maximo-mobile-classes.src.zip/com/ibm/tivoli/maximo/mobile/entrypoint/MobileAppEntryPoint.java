package com.ibm.tivoli.maximo.mobile.entrypoint;

import com.mro.mobile.app.BasicMobileDeviceUIApplication;

public abstract interface MobileAppEntryPoint
{
  public abstract void injectPlugabbleComponentsBeforeBoot(BasicMobileDeviceUIApplication paramBasicMobileDeviceUIApplication)
    throws Exception;
  
  public abstract void setupSystemProperties(BasicMobileDeviceUIApplication paramBasicMobileDeviceUIApplication);
  
  public abstract void setupAsynchronousExecutor(BasicMobileDeviceUIApplication paramBasicMobileDeviceUIApplication);
  
  public abstract void setupRDORuntimeFactory(BasicMobileDeviceUIApplication paramBasicMobileDeviceUIApplication)
    throws Exception;
  
  public abstract void injectPlugabbleComponentsAfterBoot(BasicMobileDeviceUIApplication paramBasicMobileDeviceUIApplication)
    throws Exception;
  
  public abstract void start(BasicMobileDeviceUIApplication paramBasicMobileDeviceUIApplication)
    throws Exception;
  
  public abstract void registerGlobalSettingsAfterBoot();
  
  public abstract void setupBarcodeReader(BasicMobileDeviceUIApplication paramBasicMobileDeviceUIApplication);
  
  public abstract void setupRFIDReader(BasicMobileDeviceUIApplication paramBasicMobileDeviceUIApplication);
  
  public abstract void setupSoftwareUpdateHelper(BasicMobileDeviceUIApplication paramBasicMobileDeviceUIApplication);
  
  public abstract void setupSystemInterface(BasicMobileDeviceUIApplication paramBasicMobileDeviceUIApplication);
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.ibm.tivoli.maximo.mobile.entrypoint.MobileAppEntryPoint
 * JD-Core Version:    0.7.0.1
 */