/*  1:   */ package com.ibm.tivoli.maximo.mobile.entrypoint.android.mobilewo;
/*  2:   */ 
/*  3:   */ import com.ibm.tivoli.maximo.mobile.android.BaseStartupActivity;
/*  4:   */ import com.ibm.tivoli.maximo.mobile.android.util.ImageUtil;
/*  5:   */ import com.ibm.tivoli.maximo.mobile.entrypoint.android.AndroidMobileAppEntryPoint;
/*  6:   */ import com.mro.mobile.ui.res.android.AndroidMobileUIManager;
/*  7:   */ import com.mro.mobileapp.WOApp;
/*  8:   */ 
/*  9:   */ public class AndroidWOAppEntryPoint
/* 10:   */   extends AndroidMobileAppEntryPoint<WOApp>
/* 11:   */ {
/* 12:   */   protected WOApp newApplicationInstance()
/* 13:   */   {
/* 14:13 */     return new WOApp(new AndroidMobileUIManager(this));
/* 15:   */   }
/* 16:   */   
/* 17:   */   public void registerGlobalSettingsAfterBoot()
/* 18:   */   {
/* 19:18 */     super.registerGlobalSettingsAfterBoot();
/* 20:19 */     ImageUtil.registerRDrawableClass(R.drawable.class);
/* 21:   */   }
/* 22:   */   
/* 23:   */   protected Class<? extends BaseStartupActivity> getSplashScreenClass()
/* 24:   */   {
/* 25:24 */     return MobileWOSplashScreen.class;
/* 26:   */   }
/* 27:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.ibm.tivoli.maximo.mobile.entrypoint.android.mobilewo.AndroidWOAppEntryPoint
 * JD-Core Version:    0.7.0.1
 */