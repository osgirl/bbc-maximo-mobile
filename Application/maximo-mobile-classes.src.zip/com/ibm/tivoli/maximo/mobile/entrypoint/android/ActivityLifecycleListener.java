package com.ibm.tivoli.maximo.mobile.entrypoint.android;

import android.app.Activity;
import android.os.Bundle;

public abstract interface ActivityLifecycleListener
{
  public abstract void onActivityCreated(Activity paramActivity, Bundle paramBundle);
  
  public abstract void onActivityDestroyed(Activity paramActivity);
  
  public abstract void onActivityPaused(Activity paramActivity);
  
  public abstract void onActivityResumed(Activity paramActivity);
  
  public abstract void onActivitySaveInstanceState(Activity paramActivity, Bundle paramBundle);
  
  public abstract void onActivityStarted(Activity paramActivity);
  
  public abstract void onActivityStopped(Activity paramActivity);
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.ibm.tivoli.maximo.mobile.entrypoint.android.ActivityLifecycleListener
 * JD-Core Version:    0.7.0.1
 */