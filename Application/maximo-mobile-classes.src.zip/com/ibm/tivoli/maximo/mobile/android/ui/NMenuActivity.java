/*  1:   */ package com.ibm.tivoli.maximo.mobile.android.ui;
/*  2:   */ 
/*  3:   */ import android.app.ListActivity;
/*  4:   */ import android.os.Bundle;
/*  5:   */ import android.view.View;
/*  6:   */ import android.widget.AdapterView;
/*  7:   */ import android.widget.AdapterView.OnItemClickListener;
/*  8:   */ import android.widget.ListAdapter;
/*  9:   */ import android.widget.ListView;
/* 10:   */ import com.ibm.tivoli.maximo.mobile.android.widget.NMenuAdapter;
/* 11:   */ import com.mro.mobile.ui.res.widgets.android.components.NMenu;
/* 12:   */ import com.mro.mobile.ui.res.widgets.android.components.NMenuItem;
/* 13:   */ import java.util.Stack;
/* 14:   */ 
/* 15:   */ public abstract class NMenuActivity
/* 16:   */   extends ListActivity
/* 17:   */ {
/* 18:33 */   private Stack<ListAdapter> previousAdapters = new Stack();
/* 19:   */   
/* 20:   */   protected void onCreate(Bundle savedInstanceState)
/* 21:   */   {
/* 22:36 */     super.onCreate(savedInstanceState);
/* 23:   */     
/* 24:38 */     setListAdapter(createListAdapter());
/* 25:   */     
/* 26:40 */     getListView().setOnItemClickListener(new AdapterView.OnItemClickListener()
/* 27:   */     {
/* 28:   */       public void onItemClick(AdapterView<?> parentView, View childView, int position, long id)
/* 29:   */       {
/* 30:43 */         NMenu selectedMenu = (NMenu)NMenuActivity.this.getListView().getItemAtPosition(position);
/* 31:45 */         if ((selectedMenu instanceof NMenuItem))
/* 32:   */         {
/* 33:46 */           NMenuItem item = (NMenuItem)selectedMenu;
/* 34:47 */           item.handleMenuSelect();
/* 35:48 */           NMenuActivity.this.finish();
/* 36:   */         }
/* 37:   */         else
/* 38:   */         {
/* 39:50 */           NMenuActivity.this.previousAdapters.push(NMenuActivity.this.getListAdapter());
/* 40:51 */           NMenuActivity.this.getListView().setAdapter(new NMenuAdapter(parentView.getContext(), selectedMenu));
/* 41:   */         }
/* 42:   */       }
/* 43:   */     });
/* 44:   */   }
/* 45:   */   
/* 46:   */   public void onBackPressed()
/* 47:   */   {
/* 48:61 */     if (this.previousAdapters.isEmpty()) {
/* 49:62 */       super.onBackPressed();
/* 50:   */     } else {
/* 51:64 */       getListView().setAdapter((ListAdapter)this.previousAdapters.pop());
/* 52:   */     }
/* 53:   */   }
/* 54:   */   
/* 55:   */   protected abstract ListAdapter createListAdapter();
/* 56:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.ibm.tivoli.maximo.mobile.android.ui.NMenuActivity
 * JD-Core Version:    0.7.0.1
 */