/*  1:   */ package com.ibm.tivoli.maximo.mobile.android.util;
/*  2:   */ 
/*  3:   */ import android.app.Activity;
/*  4:   */ import android.content.Intent;
/*  5:   */ import android.util.Log;
/*  6:   */ import android.view.Menu;
/*  7:   */ import android.view.MenuItem;
/*  8:   */ import com.ibm.tivoli.maximo.mobile.android.ui.MenuBarMenuActivity;
/*  9:   */ import com.mro.mobile.MobileApplicationException;
/* 10:   */ import com.mro.mobile.ui.res.UIUtil;
/* 11:   */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/* 12:   */ import com.mro.mobile.ui.res.controls.MenuBarControl;
/* 13:   */ import com.mro.mobile.ui.res.controls.MenuControl;
/* 14:   */ import com.mro.mobile.ui.res.controls.MenuViewControl;
/* 15:   */ import com.mro.mobile.ui.res.widgets.android.ADMenuWidgetImpl;
/* 16:   */ import com.mro.mobile.ui.res.widgets.android.components.NIDMapper;
/* 17:   */ import com.mro.mobile.ui.res.widgets.android.components.NMenu;
/* 18:   */ import com.mro.mobile.ui.res.widgets.def.MenuWidget;
/* 19:   */ import java.util.Iterator;
/* 20:   */ import java.util.Vector;
/* 21:   */ 
/* 22:   */ public class MenuUtil
/* 23:   */ {
/* 24:   */   public static void buildTopLevelOptionsMenu(Menu menu)
/* 25:   */   {
/* 26:38 */     menu.clear();
/* 27:   */     
/* 28:40 */     MenuBarControl menuBarCtrl = (MenuBarControl)UIUtil.getCurrentScreen().getMenuBar();
/* 29:41 */     if (menuBarCtrl == null) {
/* 30:42 */       return;
/* 31:   */     }
/* 32:45 */     Iterator<AbstractMobileControl> firstLevelMenus = menuBarCtrl.getChildren();
/* 33:46 */     if (firstLevelMenus == null) {
/* 34:47 */       return;
/* 35:   */     }
/* 36:52 */     while (firstLevelMenus.hasNext())
/* 37:   */     {
/* 38:53 */       AbstractMobileControl currentMenu = (AbstractMobileControl)firstLevelMenus.next();
/* 39:   */       try
/* 40:   */       {
/* 41:56 */         String label = null;
/* 42:57 */         if ((currentMenu instanceof MenuViewControl)) {
/* 43:58 */           label = ((MenuViewControl)currentMenu).getMenuWidget().getMenuLabel();
/* 44:59 */         } else if ((currentMenu instanceof MenuControl)) {
/* 45:60 */           label = ((MenuControl)currentMenu).getLabel();
/* 46:   */         }
/* 47:64 */         boolean hasMenuEntries = false;
/* 48:65 */         if ((currentMenu instanceof MenuControl)) {
/* 49:66 */           hasMenuEntries = !((ADMenuWidgetImpl)((MenuControl)currentMenu).getMenuWidget()).getMenuComponent().getChildrenAsVector().isEmpty();
/* 50:   */         }
/* 51:69 */         if ((label != null) && (hasMenuEntries))
/* 52:   */         {
/* 53:70 */           int androidId = NIDMapper.getAndroidIdFor(currentMenu.getId());
/* 54:71 */           menu.add(androidId, androidId, 2, label);
/* 55:   */         }
/* 56:   */       }
/* 57:   */       catch (MobileApplicationException e)
/* 58:   */       {
/* 59:75 */         Log.e("MENU", "Failed to build menu item", e);
/* 60:   */       }
/* 61:   */     }
/* 62:   */   }
/* 63:   */   
/* 64:   */   public static void handleTopLevelOptionsMenuSelected(Activity activity, MenuItem item)
/* 65:   */   {
/* 66:81 */     MenuBarControl menuBarCtrl = (MenuBarControl)UIUtil.getCurrentScreen().getMenuBar();
/* 67:82 */     Iterator<AbstractMobileControl> firstLevelMenus = menuBarCtrl.getChildren();
/* 68:85 */     while (firstLevelMenus.hasNext())
/* 69:   */     {
/* 70:86 */       AbstractMobileControl currentMenu = (AbstractMobileControl)firstLevelMenus.next();
/* 71:88 */       if ((currentMenu instanceof MenuControl))
/* 72:   */       {
/* 73:89 */         MenuControl menuControl = (MenuControl)currentMenu;
/* 74:90 */         int androidId = NIDMapper.getAndroidIdFor(menuControl.getId());
/* 75:92 */         if (item.getItemId() == androidId)
/* 76:   */         {
/* 77:93 */           Intent intent = MenuBarMenuActivity.gotoThisActivity(activity, menuControl);
/* 78:94 */           activity.startActivity(intent);
/* 79:   */         }
/* 80:   */       }
/* 81:   */     }
/* 82:   */   }
/* 83:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.ibm.tivoli.maximo.mobile.android.util.MenuUtil
 * JD-Core Version:    0.7.0.1
 */