/*  1:   */ package com.ibm.tivoli.maximo.mobile.android.persist.sqlite;
/*  2:   */ 
/*  3:   */ import java.util.ArrayList;
/*  4:   */ import java.util.Arrays;
/*  5:   */ 
/*  6:   */ public class SQLiteQBEDependentInfo
/*  7:   */ {
/*  8:   */   private String name;
/*  9: 9 */   private ArrayList<String> attributes = new ArrayList();
/* 10:   */   
/* 11:   */   public SQLiteQBEDependentInfo(String name, String... attributes)
/* 12:   */   {
/* 13:12 */     this.name = name;
/* 14:13 */     this.attributes.addAll(Arrays.asList(attributes));
/* 15:   */   }
/* 16:   */   
/* 17:   */   public String getName()
/* 18:   */   {
/* 19:17 */     return this.name;
/* 20:   */   }
/* 21:   */   
/* 22:   */   public String[] getAttributes()
/* 23:   */   {
/* 24:21 */     return (String[])this.attributes.toArray(new String[this.attributes.size()]);
/* 25:   */   }
/* 26:   */   
/* 27:   */   public void addAttribute(String attribute)
/* 28:   */   {
/* 29:25 */     this.attributes.add(attribute);
/* 30:   */   }
/* 31:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.ibm.tivoli.maximo.mobile.android.persist.sqlite.SQLiteQBEDependentInfo
 * JD-Core Version:    0.7.0.1
 */