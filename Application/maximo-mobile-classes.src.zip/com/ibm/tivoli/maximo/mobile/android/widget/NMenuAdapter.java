/*  1:   */ package com.ibm.tivoli.maximo.mobile.android.widget;
/*  2:   */ 
/*  3:   */ import android.content.Context;
/*  4:   */ import android.view.LayoutInflater;
/*  5:   */ import android.view.View;
/*  6:   */ import android.view.ViewGroup;
/*  7:   */ import android.widget.BaseAdapter;
/*  8:   */ import android.widget.TextView;
/*  9:   */ import com.ibm.tivoli.maximo.mobile.android.util.UIUtil;
/* 10:   */ import com.ibm.tivoli.maximo.mobile.resources.R.id;
/* 11:   */ import com.ibm.tivoli.maximo.mobile.resources.R.layout;
/* 12:   */ import com.mro.mobile.ui.res.widgets.android.components.NMenu;
/* 13:   */ import com.mro.mobile.ui.res.widgets.android.components.NMenuItem;
/* 14:   */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/* 15:   */ import java.util.Vector;
/* 16:   */ 
/* 17:   */ public class NMenuAdapter
/* 18:   */   extends BaseAdapter
/* 19:   */ {
/* 20:   */   private Context context;
/* 21:36 */   private NMenu nMenu = null;
/* 22:   */   
/* 23:   */   public NMenuAdapter(Context context, NMenu nMenu)
/* 24:   */   {
/* 25:39 */     this.context = context;
/* 26:40 */     this.nMenu = nMenu;
/* 27:   */   }
/* 28:   */   
/* 29:   */   public int getCount()
/* 30:   */   {
/* 31:44 */     return this.nMenu.getChildrenAsVector().size();
/* 32:   */   }
/* 33:   */   
/* 34:   */   public Object getItem(int position)
/* 35:   */   {
/* 36:48 */     return this.nMenu.getChildrenAsVector().get(position);
/* 37:   */   }
/* 38:   */   
/* 39:   */   public long getItemId(int position)
/* 40:   */   {
/* 41:52 */     return position;
/* 42:   */   }
/* 43:   */   
/* 44:   */   public View getView(int position, View convertView, ViewGroup parent)
/* 45:   */   {
/* 46:58 */     View rowView = convertView;
/* 47:60 */     if (rowView == null)
/* 48:   */     {
/* 49:61 */       LayoutInflater inflater = (LayoutInflater)this.context.getSystemService("layout_inflater");
/* 50:62 */       rowView = inflater.inflate(UIUtil.getResourceId(R.layout.class, "nmenu_adapter"), parent, false);
/* 51:   */       
/* 52:   */ 
/* 53:65 */       ViewHolder viewHolder = new ViewHolder(null);
/* 54:66 */       viewHolder.menuLabel = ((TextView)rowView.findViewById(UIUtil.getResourceId(R.id.class, "menulabel")));
/* 55:67 */       rowView.setTag(viewHolder);
/* 56:   */     }
/* 57:70 */     ViewHolder holder = (ViewHolder)rowView.getTag();
/* 58:   */     
/* 59:72 */     String menuLabel = "";
/* 60:   */     
/* 61:74 */     UIComponent comp = (UIComponent)getItem(position);
/* 62:75 */     if ((comp instanceof NMenuItem))
/* 63:   */     {
/* 64:76 */       NMenuItem mi = (NMenuItem)comp;
/* 65:77 */       menuLabel = mi.getLabel();
/* 66:   */     }
/* 67:78 */     else if ((comp instanceof NMenu))
/* 68:   */     {
/* 69:79 */       menuLabel = ((NMenu)comp).getMenuLabel() + " ...";
/* 70:   */     }
/* 71:82 */     holder.menuLabel.setText(menuLabel);
/* 72:   */     
/* 73:84 */     return rowView;
/* 74:   */   }
/* 75:   */   
/* 76:   */   private static class ViewHolder
/* 77:   */   {
/* 78:   */     public TextView menuLabel;
/* 79:   */   }
/* 80:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.ibm.tivoli.maximo.mobile.android.widget.NMenuAdapter
 * JD-Core Version:    0.7.0.1
 */