package com.ibm.tivoli.maximo.mobile.android.sensor;

import android.content.Intent;
import com.mro.mobile.sensor.barcode.MobileBarcodeEvent;
import com.mro.mobile.sensor.barcode.MobileBarcodeReader;

public abstract interface AndroidIntentBarcodeReader
  extends MobileBarcodeReader
{
  public abstract void launchIntentForResult();
  
  public abstract void callbackIntentResult(int paramInt, Intent paramIntent);
  
  public abstract Intent getBarcodeIntentSettings();
  
  public abstract MobileBarcodeEvent getMobileBarcodeEventResultOnSuccess(int paramInt, Intent paramIntent);
  
  public abstract MobileBarcodeEvent getMobileBarcodeEventResultOnError(int paramInt, Intent paramIntent);
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.ibm.tivoli.maximo.mobile.android.sensor.AndroidIntentBarcodeReader
 * JD-Core Version:    0.7.0.1
 */