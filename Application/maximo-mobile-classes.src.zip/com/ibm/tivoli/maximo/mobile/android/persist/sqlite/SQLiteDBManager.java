/*   1:    */ package com.ibm.tivoli.maximo.mobile.android.persist.sqlite;
/*   2:    */ 
/*   3:    */ import android.content.Context;
/*   4:    */ import android.database.Cursor;
/*   5:    */ import android.database.sqlite.SQLiteDatabase;
/*   6:    */ import android.database.sqlite.SQLiteStatement;
/*   7:    */ import com.mro.mobile.persist.RDOException;
/*   8:    */ import com.mro.mobile.util.MobileLogger;
/*   9:    */ import java.io.File;
/*  10:    */ 
/*  11:    */ public class SQLiteDBManager
/*  12:    */ {
/*  13:    */   private SQLiteDatabase database;
/*  14:    */   private MobileLogger logger;
/*  15:    */   
/*  16:    */   public static SQLiteDBManager openOrCreateDBManager(Context context, String name, String databaseFile, MobileLogger dbLogger)
/*  17:    */   {
/*  18: 23 */     SQLiteDBManager instance = new SQLiteDBManager(context, name, 1, dbLogger);
/*  19: 24 */     instance.openDatabase(databaseFile);
/*  20: 25 */     return instance;
/*  21:    */   }
/*  22:    */   
/*  23:    */   SQLiteDBManager(Context context, String name, int version, MobileLogger dbLogger)
/*  24:    */   {
/*  25: 29 */     if (dbLogger == null) {
/*  26: 29 */       throw new IllegalArgumentException("Logger cannot be null");
/*  27:    */     }
/*  28: 30 */     this.logger = dbLogger;
/*  29:    */   }
/*  30:    */   
/*  31:    */   private void openDatabase(String databaseHome)
/*  32:    */   {
/*  33: 34 */     this.logger.info("Trying to create/open database in folder " + databaseHome);
/*  34: 35 */     this.database = SQLiteDatabase.openOrCreateDatabase(databaseHome, null);
/*  35: 36 */     this.database.setLockingEnabled(false);
/*  36: 37 */     createBaseTablesIfNew();
/*  37:    */   }
/*  38:    */   
/*  39:    */   private void createBaseTablesIfNew()
/*  40:    */   {
/*  41: 41 */     if (!existsTable("RDOINFO")) {
/*  42: 42 */       createRDOInfoTable();
/*  43:    */     }
/*  44: 44 */     if (!existsTable("RDOINDEXINFO")) {
/*  45: 45 */       createRDOIndexInfoTable();
/*  46:    */     }
/*  47:    */   }
/*  48:    */   
/*  49:    */   public boolean existsTable(String tableName)
/*  50:    */   {
/*  51: 50 */     Cursor c = null;
/*  52: 51 */     boolean result = false;
/*  53:    */     try
/*  54:    */     {
/*  55: 53 */       c = this.database.rawQuery(String.format("SELECT name FROM sqlite_master WHERE type='table' AND name='%s'", new Object[] { tableName }), SQLiteUtil.EMPTY_STRING_ARRAY);
/*  56: 54 */       result = c.moveToNext();
/*  57:    */     }
/*  58:    */     catch (Exception e)
/*  59:    */     {
/*  60: 56 */       this.logger.info("Table " + tableName + " does not exist.");
/*  61:    */     }
/*  62:    */     finally
/*  63:    */     {
/*  64: 58 */       SQLiteUtil.safelyCloseCursor(c, this.logger);
/*  65:    */     }
/*  66: 60 */     return result;
/*  67:    */   }
/*  68:    */   
/*  69:    */   private void createRDOIndexInfoTable()
/*  70:    */   {
/*  71: 64 */     String statement = "CREATE TABLE RDOINDEXINFO (NAME VARCHAR(100) NOT NULL, RDONAME VARCHAR(100) NOT NULL, COLNAME VARCHAR(100) NOT NULL, COLORDER VARCHAR(100), PRIMARY KEY (NAME, RDONAME, COLNAME))";
/*  72:    */     
/*  73:    */ 
/*  74:    */ 
/*  75:    */ 
/*  76:    */ 
/*  77: 70 */     this.logger.info(statement);
/*  78: 71 */     this.database.execSQL(statement);
/*  79:    */   }
/*  80:    */   
/*  81:    */   private void createRDOInfoTable()
/*  82:    */   {
/*  83: 75 */     String statement = "CREATE TABLE RDOINFO (NAME VARCHAR(200) PRIMARY KEY, INFODATA BLOB)";
/*  84:    */     
/*  85:    */ 
/*  86: 78 */     this.logger.info(statement);
/*  87: 79 */     this.database.execSQL(statement);
/*  88:    */   }
/*  89:    */   
/*  90:    */   public SQLiteDatabase getDatabase()
/*  91:    */   {
/*  92: 83 */     return this.database;
/*  93:    */   }
/*  94:    */   
/*  95:    */   public long getAffectedRecordsCount()
/*  96:    */     throws Exception
/*  97:    */   {
/*  98: 87 */     SQLiteStatement statement = null;
/*  99:    */     try
/* 100:    */     {
/* 101: 89 */       statement = this.database.compileStatement("select changes()");
/* 102: 90 */       return statement.simpleQueryForLong();
/* 103:    */     }
/* 104:    */     catch (Exception e)
/* 105:    */     {
/* 106: 92 */       this.logger.warn("Could not get affect records count: " + e.getMessage(), e);
/* 107: 93 */       throw e;
/* 108:    */     }
/* 109:    */     finally
/* 110:    */     {
/* 111: 95 */       SQLiteUtil.safelyCloseStatement(statement, this.logger);
/* 112:    */     }
/* 113:    */   }
/* 114:    */   
/* 115:    */   public void close()
/* 116:    */   {
/* 117:    */     try
/* 118:    */     {
/* 119:101 */       this.database.close();
/* 120:    */     }
/* 121:    */     catch (Exception e)
/* 122:    */     {
/* 123:103 */       this.logger.warn("Error closing database: " + e.getMessage(), e);
/* 124:    */     }
/* 125:    */   }
/* 126:    */   
/* 127:    */   public boolean isOpen()
/* 128:    */   {
/* 129:108 */     return this.database.isOpen();
/* 130:    */   }
/* 131:    */   
/* 132:    */   protected void resetDatabase()
/* 133:    */     throws RDOException
/* 134:    */   {
/* 135:112 */     this.logger.info("About to reset the database");
/* 136:113 */     String filePath = this.database.getPath();
/* 137:114 */     this.logger.info("Database path: " + filePath);
/* 138:115 */     if (filePath != null)
/* 139:    */     {
/* 140:116 */       File dbFile = new File(filePath);
/* 141:117 */       this.logger.info("Closing database");
/* 142:118 */       this.database.close();
/* 143:119 */       this.logger.info("Trying to delete database file");
/* 144:120 */       if (dbFile.delete())
/* 145:    */       {
/* 146:121 */         this.logger.info("Database file deleted");
/* 147:122 */         openDatabase(dbFile.getAbsolutePath());
/* 148:    */       }
/* 149:    */       else
/* 150:    */       {
/* 151:124 */         this.logger.warn("Could not delete database file - reopening the database (if closed)");
/* 152:125 */         if (!this.database.isOpen()) {
/* 153:126 */           openDatabase(dbFile.getAbsolutePath());
/* 154:    */         }
/* 155:128 */         throw new RDOException("Could not delete db file.");
/* 156:    */       }
/* 157:    */     }
/* 158:    */     else
/* 159:    */     {
/* 160:131 */       throw new RDOException("Could not retrieve db file info.");
/* 161:    */     }
/* 162:    */   }
/* 163:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.ibm.tivoli.maximo.mobile.android.persist.sqlite.SQLiteDBManager
 * JD-Core Version:    0.7.0.1
 */