/*   1:    */ package com.ibm.tivoli.maximo.mobile.android.userlocation;
/*   2:    */ 
/*   3:    */ import android.app.PendingIntent;
/*   4:    */ import android.content.BroadcastReceiver;
/*   5:    */ import android.content.Context;
/*   6:    */ import android.content.Intent;
/*   7:    */ import android.content.IntentFilter;
/*   8:    */ import android.location.Location;
/*   9:    */ import android.location.LocationListener;
/*  10:    */ import android.location.LocationManager;
/*  11:    */ import android.os.Bundle;
/*  12:    */ import com.mro.mobile.app.userlocation.UserLocationProvider;
/*  13:    */ import com.mro.mobile.userlocation.UserLocationDataInfo;
/*  14:    */ import com.mro.mobile.util.MobileLogger;
/*  15:    */ import java.util.concurrent.atomic.AtomicBoolean;
/*  16:    */ 
/*  17:    */ public class AndroidGPSNetworkUserLocationProvider
/*  18:    */   implements UserLocationProvider, LocationListener
/*  19:    */ {
/*  20:    */   private LocationManager locationManager;
/*  21:    */   private MobileLogger logger;
/*  22:    */   private PendingIntent pendingIntent;
/*  23:    */   private Context context;
/*  24: 46 */   private AtomicBoolean locationRequested = new AtomicBoolean(false);
/*  25:    */   private static final String INTENT_NAME = "com.ibm.tivoli.maximo.mobile.android.userlocation.SINGLE_UPDATE";
/*  26:    */   private static final long _2_MINUTES = 120000L;
/*  27:    */   protected BroadcastReceiver updateReceiver;
/*  28:    */   
/*  29:    */   public AndroidGPSNetworkUserLocationProvider(Context context, LocationManager locationManager, MobileLogger logger)
/*  30:    */   {
/*  31: 56 */     this.locationManager = locationManager;
/*  32: 57 */     this.logger = logger;
/*  33: 58 */     this.context = context;
/*  34:    */   }
/*  35:    */   
/*  36:    */   public void initialize()
/*  37:    */   {
/*  38: 63 */     logIfEnabled("Initializing AndroidGPSNEtworkUserLocationProvider");
/*  39: 64 */     this.pendingIntent = PendingIntent.getBroadcast(this.context, 0, new Intent("com.ibm.tivoli.maximo.mobile.android.userlocation.SINGLE_UPDATE"), 134217728);
/*  40: 65 */     this.updateReceiver = new BroadcastReceiver()
/*  41:    */     {
/*  42:    */       public void onReceive(Context context, Intent intent)
/*  43:    */       {
/*  44: 68 */         context.unregisterReceiver(AndroidGPSNetworkUserLocationProvider.this.updateReceiver);
/*  45: 69 */         Location location = (Location)intent.getExtras().get("location");
/*  46: 70 */         if (location != null)
/*  47:    */         {
/*  48: 71 */           AndroidGPSNetworkUserLocationProvider.this.locationRequested.set(false);
/*  49: 72 */           AndroidGPSNetworkUserLocationProvider.this.onLocationChanged(location);
/*  50:    */         }
/*  51: 74 */         AndroidGPSNetworkUserLocationProvider.this.locationManager.removeUpdates(AndroidGPSNetworkUserLocationProvider.this.pendingIntent);
/*  52:    */       }
/*  53:    */     };
/*  54: 77 */     if (hasLocationProviderEnabled()) {
/*  55: 79 */       getCurrentUserLocation();
/*  56:    */     }
/*  57:    */   }
/*  58:    */   
/*  59:    */   private Location getLocationFromProvider(String provider)
/*  60:    */   {
/*  61: 85 */     Location location = null;
/*  62: 86 */     if (this.locationManager.isProviderEnabled(provider)) {
/*  63: 87 */       location = this.locationManager.getLastKnownLocation(provider);
/*  64:    */     } else {
/*  65: 89 */       this.logger.warn("Could not get GPS information for provider: " + provider);
/*  66:    */     }
/*  67: 91 */     return location;
/*  68:    */   }
/*  69:    */   
/*  70:    */   public boolean hasLocationProviderEnabled()
/*  71:    */   {
/*  72: 96 */     return (isGPSProviderAvailable()) || (isNetworkProviderAvailable());
/*  73:    */   }
/*  74:    */   
/*  75:    */   private boolean isNetworkProviderAvailable()
/*  76:    */   {
/*  77:101 */     return this.locationManager.isProviderEnabled("network");
/*  78:    */   }
/*  79:    */   
/*  80:    */   private boolean isGPSProviderAvailable()
/*  81:    */   {
/*  82:105 */     return this.locationManager.isProviderEnabled("gps");
/*  83:    */   }
/*  84:    */   
/*  85:    */   protected Location getBetterLocation(Location candidate1, Location candidate2)
/*  86:    */   {
/*  87:110 */     if ((candidate1 == null) && (candidate2 == null))
/*  88:    */     {
/*  89:111 */       logIfEnabled("Not found a valid location");
/*  90:112 */       requestLocationUpdate();
/*  91:113 */       return null;
/*  92:    */     }
/*  93:116 */     if (candidate1 == null)
/*  94:    */     {
/*  95:117 */       logIfEnabled("Best location is = " + candidate2);
/*  96:118 */       return candidate2;
/*  97:    */     }
/*  98:120 */     if (candidate2 == null)
/*  99:    */     {
/* 100:121 */       logIfEnabled("Best location is = " + candidate1);
/* 101:122 */       return candidate1;
/* 102:    */     }
/* 103:125 */     long diff = candidate1.getTime() - candidate2.getTime();
/* 104:126 */     boolean muchNewer = diff > 120000L;
/* 105:127 */     boolean muchOlder = diff < -120000L;
/* 106:129 */     if (muchNewer) {
/* 107:130 */       return candidate2;
/* 108:    */     }
/* 109:133 */     if (muchOlder) {
/* 110:134 */       return candidate1;
/* 111:    */     }
/* 112:137 */     if (candidate1.getAccuracy() <= candidate2.getAccuracy())
/* 113:    */     {
/* 114:138 */       logIfEnabled("Best location is = " + candidate1);
/* 115:139 */       return candidate1;
/* 116:    */     }
/* 117:141 */     logIfEnabled("Best location is = " + candidate2);
/* 118:142 */     return candidate2;
/* 119:    */   }
/* 120:    */   
/* 121:    */   private void requestLocationUpdate()
/* 122:    */   {
/* 123:146 */     if (!this.locationRequested.get())
/* 124:    */     {
/* 125:147 */       logIfEnabled("Requesting a new location");
/* 126:148 */       IntentFilter locIntentFilter = new IntentFilter("com.ibm.tivoli.maximo.mobile.android.userlocation.SINGLE_UPDATE");
/* 127:149 */       this.context.registerReceiver(this.updateReceiver, locIntentFilter);
/* 128:    */       try
/* 129:    */       {
/* 130:151 */         if (isGPSProviderAvailable())
/* 131:    */         {
/* 132:152 */           this.locationManager.requestSingleUpdate("gps", this.pendingIntent);
/* 133:153 */           this.locationRequested.set(true);
/* 134:    */         }
/* 135:155 */         else if (isNetworkProviderAvailable())
/* 136:    */         {
/* 137:156 */           this.locationManager.requestSingleUpdate("network", this.pendingIntent);
/* 138:157 */           this.locationRequested.set(true);
/* 139:    */         }
/* 140:    */         else
/* 141:    */         {
/* 142:159 */           logIfEnabled("No location provider enabled to request location");
/* 143:    */         }
/* 144:    */       }
/* 145:    */       catch (Exception e)
/* 146:    */       {
/* 147:162 */         this.logger.warn("Could not find any enabled location provider", e);
/* 148:163 */         this.context.unregisterReceiver(this.updateReceiver);
/* 149:    */       }
/* 150:    */     }
/* 151:    */   }
/* 152:    */   
/* 153:    */   protected UserLocationDataInfo toGPSUSerLocationDataInfo(Location location)
/* 154:    */   {
/* 155:169 */     if (location == null) {
/* 156:169 */       return null;
/* 157:    */     }
/* 158:170 */     return new UserLocationDataInfo(location.getLatitude(), location.getLongitude(), location.getAccuracy(), location.getAltitude(), location.getAccuracy(), location.getBearing(), location.getSpeed(), location.getTime());
/* 159:    */   }
/* 160:    */   
/* 161:    */   public void shutdown()
/* 162:    */   {
/* 163:182 */     logIfEnabled("shutting down location provider");
/* 164:183 */     this.locationManager.removeUpdates(this.pendingIntent);
/* 165:    */   }
/* 166:    */   
/* 167:    */   public UserLocationDataInfo getCurrentUserLocation()
/* 168:    */   {
/* 169:188 */     return toGPSUSerLocationDataInfo(getMostAccurateLocation());
/* 170:    */   }
/* 171:    */   
/* 172:    */   private Location getMostAccurateLocation()
/* 173:    */   {
/* 174:192 */     Location gpsLocation = null;
/* 175:193 */     Location networkLocation = null;
/* 176:194 */     logIfEnabled("Getting most accurate location");
/* 177:195 */     if (isGPSProviderAvailable())
/* 178:    */     {
/* 179:196 */       logIfEnabled("GPS is available");
/* 180:197 */       gpsLocation = getGPSLocation();
/* 181:198 */       logIfEnabled("GPS Location = " + gpsLocation);
/* 182:    */     }
/* 183:200 */     if (isNetworkProviderAvailable())
/* 184:    */     {
/* 185:201 */       logIfEnabled("Network is available");
/* 186:202 */       networkLocation = getNetworkLocation();
/* 187:203 */       logIfEnabled("Network location = " + networkLocation);
/* 188:    */     }
/* 189:206 */     return getBetterLocation(gpsLocation, networkLocation);
/* 190:    */   }
/* 191:    */   
/* 192:    */   private Location getGPSLocation()
/* 193:    */   {
/* 194:210 */     return getLocationFromProvider("gps");
/* 195:    */   }
/* 196:    */   
/* 197:    */   private Location getNetworkLocation()
/* 198:    */   {
/* 199:214 */     return getLocationFromProvider("network");
/* 200:    */   }
/* 201:    */   
/* 202:    */   private void logIfEnabled(String log)
/* 203:    */   {
/* 204:219 */     if ((this.logger != null) && (this.logger.isInfoEnabled())) {
/* 205:220 */       this.logger.info(log);
/* 206:    */     }
/* 207:    */   }
/* 208:    */   
/* 209:    */   public void onLocationChanged(Location location)
/* 210:    */   {
/* 211:227 */     logIfEnabled("Received update of location = " + location);
/* 212:    */   }
/* 213:    */   
/* 214:    */   public void onProviderDisabled(String provider) {}
/* 215:    */   
/* 216:    */   public void onProviderEnabled(String provider) {}
/* 217:    */   
/* 218:    */   public void onStatusChanged(String provider, int status, Bundle extras) {}
/* 219:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.ibm.tivoli.maximo.mobile.android.userlocation.AndroidGPSNetworkUserLocationProvider
 * JD-Core Version:    0.7.0.1
 */