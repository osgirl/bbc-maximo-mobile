/*   1:    */ package com.ibm.tivoli.maximo.mobile.android.util;
/*   2:    */ 
/*   3:    */ import android.app.Activity;
/*   4:    */ import android.content.res.AssetManager;
/*   5:    */ import android.content.res.Resources;
/*   6:    */ import android.graphics.drawable.Drawable;
/*   7:    */ import android.util.Log;
/*   8:    */ import com.mro.mobile.ui.res.widgets.android.AndroidEnv;
/*   9:    */ import java.io.FileNotFoundException;
/*  10:    */ import java.io.IOException;
/*  11:    */ import java.io.InputStream;
/*  12:    */ 
/*  13:    */ public class ImageUtil
/*  14:    */ {
/*  15: 27 */   private static Class<?> R_DRAWABLE_CLASS = null;
/*  16:    */   
/*  17:    */   public static void registerRDrawableClass(Class<?> drawableClass)
/*  18:    */   {
/*  19: 30 */     R_DRAWABLE_CLASS = drawableClass;
/*  20:    */   }
/*  21:    */   
/*  22:    */   public static Drawable findImageFromResources(String imagePath)
/*  23:    */   {
/*  24: 45 */     Drawable image = null;
/*  25:    */     try
/*  26:    */     {
/*  27: 52 */       String filename = imagePath;
/*  28:    */       
/*  29: 54 */       int lastSlash = imagePath.lastIndexOf("/");
/*  30: 55 */       if (lastSlash > -1) {
/*  31: 56 */         filename = imagePath.substring(lastSlash + 1, imagePath.length());
/*  32:    */       }
/*  33: 59 */       int dot = filename.lastIndexOf(".");
/*  34: 60 */       if (dot > -1) {
/*  35: 61 */         filename = filename.substring(0, dot);
/*  36:    */       }
/*  37: 65 */       filename = filename.toLowerCase();
/*  38:    */       
/*  39: 67 */       int id = UIUtil.getResourceId(R_DRAWABLE_CLASS, filename);
/*  40: 68 */       if (id > 0) {
/*  41: 69 */         image = AndroidEnv.getCurrentActivity().getResources().getDrawable(id);
/*  42:    */       } else {
/*  43: 71 */         Log.w("IMAGE", "image " + filename + " not found");
/*  44:    */       }
/*  45:    */     }
/*  46:    */     catch (OutOfMemoryError e)
/*  47:    */     {
/*  48: 75 */       Log.e("IMAGE", "Out of memory finding image: " + imagePath, e);
/*  49:    */     }
/*  50: 77 */     return image;
/*  51:    */   }
/*  52:    */   
/*  53:    */   public static Drawable findImageFromAssets(String imagePath)
/*  54:    */   {
/*  55: 85 */     image = null;
/*  56: 86 */     InputStream is = null;
/*  57:    */     try
/*  58:    */     {
/*  59: 89 */       int forwardSlash = imagePath.indexOf("/");
/*  60: 90 */       if (forwardSlash == 0) {
/*  61: 91 */         imagePath = imagePath.substring(1, imagePath.length());
/*  62:    */       }
/*  63: 94 */       is = AndroidEnv.getCurrentActivity().getAssets().open(imagePath);
/*  64: 96 */       if ((is != null) && (is.available() > 0)) {}
/*  65: 97 */       return Drawable.createFromStream(is, null);
/*  66:    */     }
/*  67:    */     catch (FileNotFoundException e)
/*  68:    */     {
/*  69:101 */       Log.w("IMAGE", "Could not located file under 'assets' directory: imagePath: " + imagePath);
/*  70:    */     }
/*  71:    */     catch (IOException e)
/*  72:    */     {
/*  73:103 */       Log.w("IMAGE", "Failed to get imagePath: " + imagePath);
/*  74:    */     }
/*  75:    */     catch (OutOfMemoryError e)
/*  76:    */     {
/*  77:105 */       Log.e("IMAGE", "Out of memory finding image: " + imagePath, e);
/*  78:    */     }
/*  79:    */     finally
/*  80:    */     {
/*  81:107 */       if (is != null) {
/*  82:    */         try
/*  83:    */         {
/*  84:109 */           is.close();
/*  85:    */         }
/*  86:    */         catch (IOException e)
/*  87:    */         {
/*  88:111 */           is = null;
/*  89:    */         }
/*  90:    */       }
/*  91:    */     }
/*  92:    */   }
/*  93:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.ibm.tivoli.maximo.mobile.android.util.ImageUtil
 * JD-Core Version:    0.7.0.1
 */