/*  1:   */ package com.ibm.tivoli.maximo.mobile.android.widget;
/*  2:   */ 
/*  3:   */ import android.app.Activity;
/*  4:   */ import android.content.Context;
/*  5:   */ import android.content.res.Resources;
/*  6:   */ import android.graphics.drawable.Drawable;
/*  7:   */ import android.view.LayoutInflater;
/*  8:   */ import android.view.View;
/*  9:   */ import android.view.ViewGroup;
/* 10:   */ import android.widget.ArrayAdapter;
/* 11:   */ import android.widget.ImageView;
/* 12:   */ import android.widget.TextView;
/* 13:   */ import com.ibm.tivoli.maximo.mobile.android.util.UIUtil;
/* 14:   */ import com.ibm.tivoli.maximo.mobile.resources.R.drawable;
/* 15:   */ import com.ibm.tivoli.maximo.mobile.resources.R.id;
/* 16:   */ import com.ibm.tivoli.maximo.mobile.resources.R.layout;
/* 17:   */ import com.mro.mobile.ui.res.widgets.android.AndroidEnv;
/* 18:   */ import java.io.File;
/* 19:   */ 
/* 20:   */ public class FileChooserAdapter
/* 21:   */   extends ArrayAdapter<File>
/* 22:   */ {
/* 23:20 */   private static final int DEFAULT_XML_LAYOUT = UIUtil.getResourceId(R.layout.class, "nfilechooser_row");
/* 24:   */   private LayoutInflater inflater;
/* 25:   */   
/* 26:   */   public FileChooserAdapter(Context context, File[] f)
/* 27:   */   {
/* 28:25 */     super(context, DEFAULT_XML_LAYOUT, f);
/* 29:26 */     this.inflater = ((LayoutInflater)context.getSystemService("layout_inflater"));
/* 30:   */   }
/* 31:   */   
/* 32:   */   public View getView(int position, View convertView, ViewGroup parent)
/* 33:   */   {
/* 34:32 */     if (convertView == null)
/* 35:   */     {
/* 36:33 */       convertView = this.inflater.inflate(DEFAULT_XML_LAYOUT, parent, false);
/* 37:   */       
/* 38:35 */       ViewHolder viewHolder = new ViewHolder(null);
/* 39:36 */       viewHolder.image = ((ImageView)convertView.findViewById(UIUtil.getResourceId(R.id.class, "image")));
/* 40:37 */       viewHolder.name = ((TextView)convertView.findViewById(UIUtil.getResourceId(R.id.class, "name")));
/* 41:   */       
/* 42:39 */       convertView.setTag(viewHolder);
/* 43:   */     }
/* 44:43 */     ViewHolder viewHolder = (ViewHolder)convertView.getTag();
/* 45:   */     
/* 46:45 */     File file = (File)getItem(position);
/* 47:46 */     viewHolder.name.setText(file.getName());
/* 48:   */     
/* 49:48 */     Drawable icon = null;
/* 50:49 */     if (file.isDirectory()) {
/* 51:50 */       icon = AndroidEnv.getCurrentActivity().getResources().getDrawable(UIUtil.getResourceId(R.drawable.class, "btntb_folder"));
/* 52:   */     } else {
/* 53:52 */       icon = AndroidEnv.getCurrentActivity().getResources().getDrawable(UIUtil.getResourceId(R.drawable.class, "btntb_file"));
/* 54:   */     }
/* 55:55 */     if (icon != null) {
/* 56:56 */       viewHolder.image.setImageDrawable(icon);
/* 57:   */     }
/* 58:59 */     return convertView;
/* 59:   */   }
/* 60:   */   
/* 61:   */   private static class ViewHolder
/* 62:   */   {
/* 63:   */     ImageView image;
/* 64:   */     TextView name;
/* 65:   */   }
/* 66:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.ibm.tivoli.maximo.mobile.android.widget.FileChooserAdapter
 * JD-Core Version:    0.7.0.1
 */