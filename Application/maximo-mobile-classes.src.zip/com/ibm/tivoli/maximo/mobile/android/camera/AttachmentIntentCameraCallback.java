/*   1:    */ package com.ibm.tivoli.maximo.mobile.android.camera;
/*   2:    */ 
/*   3:    */ import android.content.Intent;
/*   4:    */ import android.net.Uri;
/*   5:    */ import android.os.Environment;
/*   6:    */ import com.ibm.tivoli.maximo.mobile.android.DefaultMaximoMobileActivity;
/*   7:    */ import com.mro.mobile.MobileApplicationException;
/*   8:    */ import com.mro.mobile.MobileMessageGenerator;
/*   9:    */ import com.mro.mobile.mbo.MobileMbo;
/*  10:    */ import com.mro.mobile.ui.MobileMboDataBean;
/*  11:    */ import com.mro.mobile.ui.MobileMboDataBeanManager;
/*  12:    */ import com.mro.mobile.ui.res.UIUtil;
/*  13:    */ import com.mro.mobile.ui.res.controls.LinkControl;
/*  14:    */ import com.mro.mobile.ui.res.widgets.android.AndroidEnv;
/*  15:    */ import com.mro.mobile.util.MobileLogger;
/*  16:    */ import com.mro.mobile.util.MobileLoggerFactory;
/*  17:    */ import java.io.File;
/*  18:    */ import java.io.FileInputStream;
/*  19:    */ import java.io.IOException;
/*  20:    */ import java.io.InputStream;
/*  21:    */ 
/*  22:    */ public class AttachmentIntentCameraCallback
/*  23:    */   implements AndroidIntentCameraCallback
/*  24:    */ {
/*  25:    */   private LinkControl launcher;
/*  26: 44 */   private File location = null;
/*  27: 46 */   private File picture = null;
/*  28:    */   
/*  29:    */   public AttachmentIntentCameraCallback(LinkControl launcher)
/*  30:    */   {
/*  31: 49 */     this.launcher = launcher;
/*  32:    */   }
/*  33:    */   
/*  34:    */   public void launchIntentForResult()
/*  35:    */     throws MobileApplicationException
/*  36:    */   {
/*  37:    */     try
/*  38:    */     {
/*  39: 55 */       AndroidEnv.getCurrentActivityAsMobileActivity().startCameraActivityForResult(cameraIntent(), this);
/*  40:    */     }
/*  41:    */     catch (Exception e)
/*  42:    */     {
/*  43: 57 */       MobileLoggerFactory.getDefaultLogger().error("Error opening camera: " + e.getMessage(), e);
/*  44: 58 */       MobileApplicationException me = new MobileApplicationException("erroropeningcamera", new Object[] { e.getMessage() });
/*  45: 59 */       throw me;
/*  46:    */     }
/*  47:    */   }
/*  48:    */   
/*  49:    */   public void callbackIntentResult(int resultCode, Intent intent)
/*  50:    */     throws MobileApplicationException
/*  51:    */   {
/*  52: 65 */     if ((this.launcher != null) && (resultCode == -1))
/*  53:    */     {
/*  54: 66 */       attachPicture();
/*  55: 67 */       UIUtil.closePage();
/*  56: 68 */       UIUtil.showInfoMessageBox(MobileMessageGenerator.generate("photoattachedsuccess", new Object[] { this.picture.getName() }));
/*  57:    */     }
/*  58:    */   }
/*  59:    */   
/*  60:    */   protected void attachPicture()
/*  61:    */     throws MobileApplicationException
/*  62:    */   {
/*  63: 73 */     String setAttr = this.launcher.getStringValue("dataattribute");
/*  64: 74 */     if ((setAttr != null) && 
/*  65: 75 */       (this.picture != null)) {
/*  66:    */       try
/*  67:    */       {
/*  68: 78 */         MobileMbo attachment = this.launcher.getDataBean().getMobileMbo();
/*  69: 79 */         byte[] dataBytes = new byte[(int)this.picture.length()];
/*  70: 80 */         InputStream fis = new FileInputStream(this.picture);
/*  71: 81 */         fis.read(dataBytes);
/*  72: 82 */         attachment.setValue("FILENAME", this.picture.getName());
/*  73: 83 */         attachment.setBinaryValue(setAttr, dataBytes);
/*  74: 84 */         this.launcher.getDataBean().getDataBeanManager().save();
/*  75:    */       }
/*  76:    */       catch (Exception ioe)
/*  77:    */       {
/*  78:    */         try
/*  79:    */         {
/*  80: 87 */           this.launcher.getDataBean().delete();
/*  81: 88 */           this.launcher.getDataBean().deleteLocal();
/*  82: 89 */           this.launcher.getDataBean().getDataBeanManager().save();
/*  83:    */         }
/*  84:    */         catch (Exception e)
/*  85:    */         {
/*  86: 91 */           MobileLoggerFactory.getDefaultLogger().error("Error clean up attached picture", e);
/*  87:    */         }
/*  88: 93 */         throw new MobileApplicationException(ioe.getMessage());
/*  89:    */       }
/*  90:    */       finally
/*  91:    */       {
/*  92:    */         try
/*  93:    */         {
/*  94: 96 */           this.picture.delete();
/*  95:    */         }
/*  96:    */         catch (Exception e)
/*  97:    */         {
/*  98: 98 */           MobileLoggerFactory.getDefaultLogger().warn("Error removing picture file.", e);
/*  99:    */         }
/* 100:    */       }
/* 101:    */     }
/* 102:    */   }
/* 103:    */   
/* 104:    */   protected Intent cameraIntent()
/* 105:    */     throws IOException
/* 106:    */   {
/* 107:106 */     Intent cameraIntent = new Intent("android.media.action.IMAGE_CAPTURE");
/* 108:107 */     cameraIntent.putExtra("output", Uri.fromFile(createImageFile()));
/* 109:108 */     return cameraIntent;
/* 110:    */   }
/* 111:    */   
/* 112:    */   protected File createImageFile()
/* 113:    */     throws IOException
/* 114:    */   {
/* 115:112 */     String directoryName = Environment.getExternalStorageDirectory().getAbsolutePath() + "/maximomobile/camera";
/* 116:113 */     String fileName = "maximo_mobile_pic_" + System.currentTimeMillis() + ".jpg";
/* 117:114 */     if (this.location == null) {
/* 118:115 */       if (isExternalStorageWritable())
/* 119:    */       {
/* 120:116 */         this.location = new File(directoryName);
/* 121:    */       }
/* 122:    */       else
/* 123:    */       {
/* 124:119 */         MobileApplicationException ex = new MobileApplicationException("updatedeterminejarfailed", new Object[] { directoryName });
/* 125:120 */         throw new IOException(ex.getCompleteMessage());
/* 126:    */       }
/* 127:    */     }
/* 128:123 */     if (this.location != null)
/* 129:    */     {
/* 130:124 */       if (!this.location.exists())
/* 131:    */       {
/* 132:125 */         if (!this.location.mkdirs())
/* 133:    */         {
/* 134:126 */           MobileApplicationException ex = new MobileApplicationException("updatedeterminejarfailed", new Object[] { this.location.getAbsolutePath() });
/* 135:127 */           throw new IOException(ex.getCompleteMessage());
/* 136:    */         }
/* 137:129 */         this.picture = new File(this.location, fileName);
/* 138:130 */         return this.picture;
/* 139:    */       }
/* 140:133 */       this.picture = new File(this.location, fileName);
/* 141:134 */       return this.picture;
/* 142:    */     }
/* 143:137 */     MobileApplicationException ex = new MobileApplicationException("updatedeterminejarfailed", new Object[] { directoryName + "/" + fileName });
/* 144:138 */     throw new IOException(ex.getCompleteMessage());
/* 145:    */   }
/* 146:    */   
/* 147:    */   protected boolean isExternalStorageWritable()
/* 148:    */   {
/* 149:142 */     return "mounted".equals(Environment.getExternalStorageState());
/* 150:    */   }
/* 151:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.ibm.tivoli.maximo.mobile.android.camera.AttachmentIntentCameraCallback
 * JD-Core Version:    0.7.0.1
 */