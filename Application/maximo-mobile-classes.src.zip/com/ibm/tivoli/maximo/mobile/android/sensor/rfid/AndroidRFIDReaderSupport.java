/*  1:   */ package com.ibm.tivoli.maximo.mobile.android.sensor.rfid;
/*  2:   */ 
/*  3:   */ import com.mro.mobile.sensor.rfid.MobileRFIDReader;
/*  4:   */ import com.mro.mobile.sensor.rfid.MobileRFIDReaderWrapper;
/*  5:   */ import com.mro.mobile.util.MobileLogger;
/*  6:   */ import com.mro.mobile.util.MobileLoggerFactory;
/*  7:   */ 
/*  8:   */ public class AndroidRFIDReaderSupport
/*  9:   */   extends MobileRFIDReaderWrapper
/* 10:   */ {
/* 11:   */   public AndroidRFIDReaderSupport(String builtinAliasOrClassName)
/* 12:   */   {
/* 13:26 */     super(builtinAliasOrClassName);
/* 14:   */   }
/* 15:   */   
/* 16:   */   protected MobileRFIDReader createMobileRFIDReader(String builtinAliasOrClassName)
/* 17:   */   {
/* 18:31 */     String rfid = builtinAliasOrClassName;
/* 19:32 */     MobileRFIDReader reader = null;
/* 20:33 */     if (rfid == null) {
/* 21:34 */       return null;
/* 22:   */     }
/* 23:37 */     MobileLogger logger = MobileLoggerFactory.getDefaultLogger();
/* 24:   */     
/* 25:39 */     rfid = rfid.trim();
/* 26:   */     try
/* 27:   */     {
/* 28:49 */       reader = (MobileRFIDReader)Class.forName(rfid).newInstance();
/* 29:   */     }
/* 30:   */     catch (Exception e)
/* 31:   */     {
/* 32:51 */       logger.warn("Failed to create new rfid reader for class: " + rfid, e);
/* 33:   */     }
/* 34:   */     try
/* 35:   */     {
/* 36:56 */       if (reader != null) {
/* 37:57 */         reader.initialize();
/* 38:   */       }
/* 39:   */     }
/* 40:   */     catch (Exception e)
/* 41:   */     {
/* 42:60 */       logger.warn("Failed to initialize rfid reader: " + rfid, e);
/* 43:61 */       reader = null;
/* 44:   */     }
/* 45:63 */     return reader;
/* 46:   */   }
/* 47:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.ibm.tivoli.maximo.mobile.android.sensor.rfid.AndroidRFIDReaderSupport
 * JD-Core Version:    0.7.0.1
 */