/*  1:   */ package com.ibm.tivoli.maximo.mobile.android.persist;
/*  2:   */ 
/*  3:   */ import android.content.Context;
/*  4:   */ import com.ibm.tivoli.maximo.mobile.android.persist.sqlite.SQLiteDBManager;
/*  5:   */ import com.ibm.tivoli.maximo.mobile.android.persist.sqlite.SQLiteDBRDOInfoManager;
/*  6:   */ import com.ibm.tivoli.maximo.mobile.android.persist.sqlite.SQLiteDBRDOManager;
/*  7:   */ import com.ibm.tivoli.maximo.mobile.android.persist.sqlite.SQLiteDBRDOTransactionManager;
/*  8:   */ import com.mro.mobile.MobileApplicationException;
/*  9:   */ import com.mro.mobile.ProgressObserver;
/* 10:   */ import com.mro.mobile.persist.RDORuntime;
/* 11:   */ import com.mro.mobile.persist.RDORuntimeFactory;
/* 12:   */ import com.mro.mobile.util.MobileLogger;
/* 13:   */ import java.io.File;
/* 14:   */ 
/* 15:   */ public class AndroidRDORuntimeFactory
/* 16:   */   extends RDORuntimeFactory
/* 17:   */ {
/* 18:   */   private Context context;
/* 19:   */   private MobileLogger logger;
/* 20:   */   
/* 21:   */   public AndroidRDORuntimeFactory(Context context, String databaseHome, MobileLogger persistenceLogger)
/* 22:   */   {
/* 23:23 */     this(context, databaseHome, "sqlite", persistenceLogger);
/* 24:   */   }
/* 25:   */   
/* 26:   */   public AndroidRDORuntimeFactory(Context context, String databaseHome, String databaseName, MobileLogger persistenceLogger)
/* 27:   */   {
/* 28:27 */     super(databaseHome, databaseName);
/* 29:28 */     if (context == null) {
/* 30:28 */       throw new IllegalArgumentException("context cannot be null");
/* 31:   */     }
/* 32:29 */     if (persistenceLogger == null) {
/* 33:29 */       throw new IllegalArgumentException("logger cannot be null");
/* 34:   */     }
/* 35:30 */     this.context = context;
/* 36:31 */     this.logger = persistenceLogger;
/* 37:   */   }
/* 38:   */   
/* 39:   */   public RDORuntime createRDORuntime(String appName, String userName)
/* 40:   */     throws MobileApplicationException
/* 41:   */   {
/* 42:36 */     return createRDORuntime(appName, userName, null);
/* 43:   */   }
/* 44:   */   
/* 45:   */   public RDORuntime createRDORuntime(String appName, String userName, ProgressObserver observer)
/* 46:   */     throws MobileApplicationException
/* 47:   */   {
/* 48:41 */     String dbName = getDatabaseName();
/* 49:42 */     RDORuntime rdoRuntime = null;
/* 50:43 */     if (dbName.equalsIgnoreCase("sqlite")) {
/* 51:44 */       rdoRuntime = createSQLiteBasedRDORuntime(appName, userName, buildFolderPath(appName));
/* 52:   */     }
/* 53:46 */     return rdoRuntime;
/* 54:   */   }
/* 55:   */   
/* 56:   */   protected RDORuntime createSQLiteBasedRDORuntime(String appName, String userName, String dbFolder)
/* 57:   */     throws MobileApplicationException
/* 58:   */   {
/* 59:50 */     RDORuntime rdoRuntime = RDORuntime.getNewInstance();
/* 60:51 */     ensureFolderExists(dbFolder);
/* 61:52 */     String databaseFile = dbFolder + userName + ".db";
/* 62:53 */     SQLiteDBManager dbManager = SQLiteDBManager.openOrCreateDBManager(this.context, appName, databaseFile, this.logger);
/* 63:54 */     SQLiteDBRDOInfoManager rdoInfoManager = new SQLiteDBRDOInfoManager(dbManager, this.logger);
/* 64:55 */     SQLiteDBRDOManager rdoManager = new SQLiteDBRDOManager(appName, dbManager, rdoInfoManager, this.logger);
/* 65:56 */     SQLiteDBRDOTransactionManager rdoTxnManager = new SQLiteDBRDOTransactionManager(dbManager, this.logger);
/* 66:57 */     rdoRuntime.registerRDOInfoManager(rdoInfoManager);
/* 67:58 */     rdoRuntime.registerRDOManager(rdoManager);
/* 68:59 */     rdoRuntime.registerRDOTransactionManager(rdoTxnManager);
/* 69:60 */     return rdoRuntime;
/* 70:   */   }
/* 71:   */   
/* 72:   */   protected void ensureDBNameIsValid()
/* 73:   */   {
/* 74:64 */     if (!isDBValid()) {
/* 75:65 */       throw new IllegalArgumentException("database.name is not valid: " + getDatabaseName());
/* 76:   */     }
/* 77:   */   }
/* 78:   */   
/* 79:   */   protected void ensureFolderExists(String databaseHome)
/* 80:   */   {
/* 81:70 */     File f = new File(databaseHome);
/* 82:71 */     if (!f.exists()) {
/* 83:72 */       f.mkdirs();
/* 84:   */     }
/* 85:   */   }
/* 86:   */   
/* 87:   */   private boolean isDBValid()
/* 88:   */   {
/* 89:77 */     String dbName = getDatabaseName();
/* 90:78 */     return (dbName != null) && (dbName.equals("sqlite"));
/* 91:   */   }
/* 92:   */   
/* 93:   */   protected String buildFolderPath(String appName)
/* 94:   */   {
/* 95:82 */     return getDatabaseHome() + File.separator + appName.toUpperCase() + File.separator;
/* 96:   */   }
/* 97:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.ibm.tivoli.maximo.mobile.android.persist.AndroidRDORuntimeFactory
 * JD-Core Version:    0.7.0.1
 */