/*  1:   */ package com.ibm.tivoli.maximo.mobile.android.sensor.barcode;
/*  2:   */ 
/*  3:   */ import com.ibm.tivoli.maximo.mobile.android.sensor.barcode.camera.zxing.ZXingIntentBarcodeReader;
/*  4:   */ import com.ibm.tivoli.maximo.mobile.android.sensor.barcode.datawedge.AndroidDataWedgeBarcodeReader;
/*  5:   */ import com.mro.mobile.sensor.barcode.MobileBarcodeReader;
/*  6:   */ import com.mro.mobile.sensor.barcode.MobileBarcodeReaderWrapper;
/*  7:   */ import com.mro.mobile.util.MobileLogger;
/*  8:   */ import com.mro.mobile.util.MobileLoggerFactory;
/*  9:   */ 
/* 10:   */ public class AndroidBarcodeReaderSupport
/* 11:   */   extends MobileBarcodeReaderWrapper
/* 12:   */ {
/* 13:   */   public AndroidBarcodeReaderSupport(String builtinAliasOrClassName)
/* 14:   */   {
/* 15:28 */     super(builtinAliasOrClassName);
/* 16:   */   }
/* 17:   */   
/* 18:   */   protected MobileBarcodeReader createMobileBarcodeReader(String builtinAliasOrClassName)
/* 19:   */   {
/* 20:32 */     String barcode = builtinAliasOrClassName;
/* 21:33 */     MobileBarcodeReader reader = null;
/* 22:34 */     if (barcode == null) {
/* 23:35 */       return null;
/* 24:   */     }
/* 25:38 */     MobileLogger logger = MobileLoggerFactory.getDefaultLogger();
/* 26:   */     
/* 27:40 */     barcode = barcode.trim();
/* 28:42 */     if (barcode.equalsIgnoreCase("ZXING")) {
/* 29:43 */       reader = new ZXingIntentBarcodeReader();
/* 30:45 */     } else if (barcode.equalsIgnoreCase("DATAWEDGE")) {
/* 31:46 */       reader = new AndroidDataWedgeBarcodeReader();
/* 32:   */     } else {
/* 33:   */       try
/* 34:   */       {
/* 35:49 */         reader = (MobileBarcodeReader)Class.forName(barcode).newInstance();
/* 36:   */       }
/* 37:   */       catch (Exception e)
/* 38:   */       {
/* 39:51 */         logger.warn("Failed to create new barcode reader for class: " + barcode, e);
/* 40:   */       }
/* 41:   */     }
/* 42:   */     try
/* 43:   */     {
/* 44:56 */       if (reader != null) {
/* 45:57 */         reader.initialize();
/* 46:   */       }
/* 47:   */     }
/* 48:   */     catch (Exception e)
/* 49:   */     {
/* 50:60 */       logger.warn("Failed to initialize barcode reader: " + barcode, e);
/* 51:61 */       reader = null;
/* 52:   */     }
/* 53:63 */     return reader;
/* 54:   */   }
/* 55:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.ibm.tivoli.maximo.mobile.android.sensor.barcode.AndroidBarcodeReaderSupport
 * JD-Core Version:    0.7.0.1
 */