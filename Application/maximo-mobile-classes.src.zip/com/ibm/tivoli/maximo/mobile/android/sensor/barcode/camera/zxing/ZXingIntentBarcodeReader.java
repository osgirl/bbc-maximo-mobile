/*  1:   */ package com.ibm.tivoli.maximo.mobile.android.sensor.barcode.camera.zxing;
/*  2:   */ 
/*  3:   */ import android.content.Intent;
/*  4:   */ import com.ibm.tivoli.maximo.mobile.android.sensor.barcode.camera.AndroidCameraBarcodeReader;
/*  5:   */ import com.mro.mobile.sensor.barcode.MobileBarcodeEvent;
/*  6:   */ 
/*  7:   */ public class ZXingIntentBarcodeReader
/*  8:   */   extends AndroidCameraBarcodeReader
/*  9:   */ {
/* 10:   */   public MobileBarcodeEvent getMobileBarcodeEventResultOnSuccess(int resultCode, Intent intent)
/* 11:   */   {
/* 12:26 */     String contents = intent.getStringExtra("SCAN_RESULT");
/* 13:27 */     return new MobileBarcodeEvent(intent, contents);
/* 14:   */   }
/* 15:   */   
/* 16:   */   public Intent getBarcodeIntentSettings()
/* 17:   */   {
/* 18:32 */     Intent intent = new Intent("com.google.zxing.client.android.SCAN");
/* 19:33 */     intent.addCategory("android.intent.category.DEFAULT");
/* 20:34 */     intent.putExtra("SCAN_WIDTH", 800);
/* 21:35 */     intent.putExtra("SCAN_HEIGHT", 200);
/* 22:36 */     intent.putExtra("RESULT_DISPLAY_DURATION_MS", 2000L);
/* 23:37 */     intent.putExtra("PROMPT_MESSAGE", "");
/* 24:38 */     return intent;
/* 25:   */   }
/* 26:   */   
/* 27:   */   public MobileBarcodeEvent getMobileBarcodeEventResultOnError(int resultCode, Intent intentResult)
/* 28:   */   {
/* 29:43 */     return new MobileBarcodeEvent(new Exception("Error code received from barcode reader: " + resultCode));
/* 30:   */   }
/* 31:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.ibm.tivoli.maximo.mobile.android.sensor.barcode.camera.zxing.ZXingIntentBarcodeReader
 * JD-Core Version:    0.7.0.1
 */