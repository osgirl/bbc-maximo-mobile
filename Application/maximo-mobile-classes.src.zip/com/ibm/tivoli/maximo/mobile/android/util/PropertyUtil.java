/*  1:   */ package com.ibm.tivoli.maximo.mobile.android.util;
/*  2:   */ 
/*  3:   */ import android.app.Activity;
/*  4:   */ import android.content.res.Resources;
/*  5:   */ import android.util.Log;
/*  6:   */ import com.mro.mobile.ui.res.widgets.android.AndroidEnv;
/*  7:   */ 
/*  8:   */ public class PropertyUtil
/*  9:   */ {
/* 10:22 */   private static Class<?> R_PROPERTY_CLASS = null;
/* 11:   */   
/* 12:   */   public static void registerRPropertyClass(Class<?> drawableClass)
/* 13:   */   {
/* 14:25 */     R_PROPERTY_CLASS = drawableClass;
/* 15:   */   }
/* 16:   */   
/* 17:   */   public static String findPropertyFromResources(String propertyKey)
/* 18:   */   {
/* 19:40 */     int id = UIUtil.getResourceId(R_PROPERTY_CLASS, propertyKey);
/* 20:41 */     if (id > 0) {
/* 21:42 */       return AndroidEnv.getCurrentActivity().getResources().getString(id);
/* 22:   */     }
/* 23:44 */     Log.w("PROPERTY", "property key " + propertyKey + " not found");
/* 24:   */     
/* 25:46 */     return null;
/* 26:   */   }
/* 27:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.ibm.tivoli.maximo.mobile.android.util.PropertyUtil
 * JD-Core Version:    0.7.0.1
 */