/*  1:   */ package com.ibm.tivoli.maximo.mobile.android.persist.sqlite;
/*  2:   */ 
/*  3:   */ import android.database.Cursor;
/*  4:   */ import android.database.sqlite.SQLiteStatement;
/*  5:   */ import com.mro.mobile.util.MobileLogger;
/*  6:   */ 
/*  7:   */ public class SQLiteUtil
/*  8:   */ {
/*  9:10 */   public static final String[] EMPTY_STRING_ARRAY = new String[0];
/* 10:   */   
/* 11:   */   public static void safelyCloseStatement(SQLiteStatement stmt, MobileLogger logger)
/* 12:   */   {
/* 13:13 */     if (stmt != null) {
/* 14:   */       try
/* 15:   */       {
/* 16:15 */         stmt.close();
/* 17:   */       }
/* 18:   */       catch (Exception e)
/* 19:   */       {
/* 20:17 */         if (logger != null) {
/* 21:18 */           logger.warn("Could not close SQLiteStatement.", e);
/* 22:   */         }
/* 23:   */       }
/* 24:   */     }
/* 25:   */   }
/* 26:   */   
/* 27:   */   public static void safelyCloseCursor(Cursor cursor)
/* 28:   */   {
/* 29:25 */     safelyCloseCursor(cursor, null);
/* 30:   */   }
/* 31:   */   
/* 32:   */   public static void safelyCloseCursor(Cursor cursor, MobileLogger logger)
/* 33:   */   {
/* 34:29 */     if (cursor != null) {
/* 35:   */       try
/* 36:   */       {
/* 37:31 */         cursor.close();
/* 38:   */       }
/* 39:   */       catch (Exception e)
/* 40:   */       {
/* 41:33 */         if (logger != null) {
/* 42:34 */           logger.warn("Could not close Cursor.", e);
/* 43:   */         }
/* 44:   */       }
/* 45:   */     }
/* 46:   */   }
/* 47:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.ibm.tivoli.maximo.mobile.android.persist.sqlite.SQLiteUtil
 * JD-Core Version:    0.7.0.1
 */