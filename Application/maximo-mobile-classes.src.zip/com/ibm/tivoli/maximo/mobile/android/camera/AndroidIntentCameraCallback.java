package com.ibm.tivoli.maximo.mobile.android.camera;

import android.content.Intent;
import com.mro.mobile.MobileApplicationException;

public abstract interface AndroidIntentCameraCallback
{
  public abstract void launchIntentForResult()
    throws MobileApplicationException;
  
  public abstract void callbackIntentResult(int paramInt, Intent paramIntent)
    throws MobileApplicationException;
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.ibm.tivoli.maximo.mobile.android.camera.AndroidIntentCameraCallback
 * JD-Core Version:    0.7.0.1
 */