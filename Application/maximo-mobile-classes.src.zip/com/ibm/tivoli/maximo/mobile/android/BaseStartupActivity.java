/*  1:   */ package com.ibm.tivoli.maximo.mobile.android;
/*  2:   */ 
/*  3:   */ import android.app.Activity;
/*  4:   */ import android.app.AlertDialog;
/*  5:   */ import android.app.AlertDialog.Builder;
/*  6:   */ import android.content.DialogInterface;
/*  7:   */ import android.content.DialogInterface.OnClickListener;
/*  8:   */ import android.os.AsyncTask;
/*  9:   */ import android.os.Bundle;
/* 10:   */ import android.view.KeyEvent;
/* 11:   */ import android.view.Window;
/* 12:   */ import com.ibm.tivoli.maximo.mobile.android.util.LaunchResult;
/* 13:   */ import com.ibm.tivoli.maximo.mobile.entrypoint.android.AndroidMobileAppEntryPoint;
/* 14:   */ import com.mro.mobile.ui.res.android.DefaultBackButtonListener;
/* 15:   */ 
/* 16:   */ public abstract class BaseStartupActivity
/* 17:   */   extends Activity
/* 18:   */ {
/* 19:   */   public void onCreate(Bundle savedInstanceState)
/* 20:   */   {
/* 21:20 */     super.onCreate(savedInstanceState);
/* 22:21 */     getWindow().requestFeature(1);
/* 23:22 */     setContentView(getSplashScreenId());
/* 24:23 */     runOnUiThread(new Runnable()
/* 25:   */     {
/* 26:   */       public void run()
/* 27:   */       {
/* 28:25 */         new BaseStartupActivity.LaunchTask(BaseStartupActivity.this, null).execute(new Void[0]);
/* 29:   */       }
/* 30:   */     });
/* 31:   */   }
/* 32:   */   
/* 33:   */   public boolean dispatchKeyEvent(KeyEvent event)
/* 34:   */   {
/* 35:32 */     return event.getKeyCode() == 4 ? true : super.dispatchKeyEvent(event);
/* 36:   */   }
/* 37:   */   
/* 38:   */   protected abstract int getSplashScreenId();
/* 39:   */   
/* 40:   */   private class LaunchTask
/* 41:   */     extends AsyncTask<Void, Void, LaunchResult>
/* 42:   */   {
/* 43:   */     private LaunchTask() {}
/* 44:   */     
/* 45:   */     protected LaunchResult doInBackground(Void... params)
/* 46:   */     {
/* 47:41 */       AndroidMobileAppEntryPoint<?> application = (AndroidMobileAppEntryPoint)BaseStartupActivity.this.getApplication();
/* 48:42 */       return application.launchMaximoMobile();
/* 49:   */     }
/* 50:   */     
/* 51:   */     protected void onPostExecute(LaunchResult result)
/* 52:   */     {
/* 53:47 */       if (result.successful())
/* 54:   */       {
/* 55:48 */         AndroidMobileAppEntryPoint<?> application = (AndroidMobileAppEntryPoint)BaseStartupActivity.this.getApplication();
/* 56:49 */         BaseStartupActivity.this.finish();
/* 57:50 */         application.launchNewActivityAfterApplicationLaunch();
/* 58:   */       }
/* 59:   */       else
/* 60:   */       {
/* 61:52 */         AlertDialog.Builder builder = new AlertDialog.Builder(BaseStartupActivity.this);
/* 62:53 */         builder.setMessage("Failed to launch application: " + result.getErrorIfFailedOrNull().getMessage());
/* 63:54 */         builder.setTitle("Error");
/* 64:55 */         builder.setNeutralButton("Close", new DialogInterface.OnClickListener()
/* 65:   */         {
/* 66:   */           public void onClick(DialogInterface dialog, int which)
/* 67:   */           {
/* 68:58 */             BaseStartupActivity.this.finish();
/* 69:   */           }
/* 70:60 */         });
/* 71:61 */         AlertDialog dialog = builder.create();
/* 72:62 */         dialog.setIcon(17301543);
/* 73:63 */         dialog.setOnKeyListener(DefaultBackButtonListener.getInstance());
/* 74:64 */         dialog.show();
/* 75:   */       }
/* 76:   */     }
/* 77:   */   }
/* 78:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.ibm.tivoli.maximo.mobile.android.BaseStartupActivity
 * JD-Core Version:    0.7.0.1
 */