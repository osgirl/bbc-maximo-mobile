/*  1:   */ package com.ibm.tivoli.maximo.mobile.android.sensor.barcode.camera;
/*  2:   */ 
/*  3:   */ import android.content.Intent;
/*  4:   */ import com.ibm.tivoli.maximo.mobile.android.DefaultMaximoMobileActivity;
/*  5:   */ import com.ibm.tivoli.maximo.mobile.android.sensor.AndroidIntentBarcodeReader;
/*  6:   */ import com.mro.mobile.MobileApplicationException;
/*  7:   */ import com.mro.mobile.sensor.barcode.AbstractBarcodeReader;
/*  8:   */ import com.mro.mobile.ui.res.widgets.android.AndroidEnv;
/*  9:   */ 
/* 10:   */ public abstract class AndroidCameraBarcodeReader
/* 11:   */   extends AbstractBarcodeReader
/* 12:   */   implements AndroidIntentBarcodeReader
/* 13:   */ {
/* 14:   */   public void initialize()
/* 15:   */     throws MobileApplicationException
/* 16:   */   {}
/* 17:   */   
/* 18:   */   public void release()
/* 19:   */     throws MobileApplicationException
/* 20:   */   {}
/* 21:   */   
/* 22:   */   public void launchIntentForResult()
/* 23:   */   {
/* 24:37 */     AndroidEnv.getCurrentActivityAsMobileActivity().startBarcodeActivityForResult(getBarcodeIntentSettings(), this);
/* 25:   */   }
/* 26:   */   
/* 27:   */   public void callbackIntentResult(int resultCode, Intent intent)
/* 28:   */   {
/* 29:42 */     if (resultCode == -1) {
/* 30:43 */       fireBarcodeReadSuccessEvent(getMobileBarcodeEventResultOnSuccess(resultCode, intent));
/* 31:   */     } else {
/* 32:46 */       fireBarcodeReadErrorEvent(getMobileBarcodeEventResultOnError(resultCode, intent));
/* 33:   */     }
/* 34:   */   }
/* 35:   */   
/* 36:   */   public boolean isIntentBased()
/* 37:   */   {
/* 38:52 */     return true;
/* 39:   */   }
/* 40:   */   
/* 41:   */   public void launchIntent()
/* 42:   */   {
/* 43:57 */     launchIntentForResult();
/* 44:   */   }
/* 45:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.ibm.tivoli.maximo.mobile.android.sensor.barcode.camera.AndroidCameraBarcodeReader
 * JD-Core Version:    0.7.0.1
 */