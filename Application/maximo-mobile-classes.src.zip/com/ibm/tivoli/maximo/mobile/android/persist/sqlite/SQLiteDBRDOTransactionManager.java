/*  1:   */ package com.ibm.tivoli.maximo.mobile.android.persist.sqlite;
/*  2:   */ 
/*  3:   */ import com.mro.mobile.persist.RDOException;
/*  4:   */ import com.mro.mobile.persist.RDOTransactionManager;
/*  5:   */ import com.mro.mobile.util.MobileLogger;
/*  6:   */ 
/*  7:   */ public class SQLiteDBRDOTransactionManager
/*  8:   */   implements RDOTransactionManager
/*  9:   */ {
/* 10:   */   private SQLiteDBManager dbManager;
/* 11:   */   private MobileLogger logger;
/* 12:   */   private int transactionRefCount;
/* 13:   */   
/* 14:   */   public SQLiteDBRDOTransactionManager(SQLiteDBManager dbManager, MobileLogger logger)
/* 15:   */   {
/* 16:14 */     if (dbManager == null) {
/* 17:14 */       throw new IllegalArgumentException("DBManager cannot be null");
/* 18:   */     }
/* 19:15 */     if (logger == null) {
/* 20:15 */       throw new IllegalArgumentException("Logger cannot be null");
/* 21:   */     }
/* 22:17 */     this.dbManager = dbManager;
/* 23:18 */     this.logger = logger;
/* 24:   */   }
/* 25:   */   
/* 26:   */   public void begin()
/* 27:   */     throws RDOException
/* 28:   */   {
/* 29:23 */     if (this.transactionRefCount > 0) {
/* 30:24 */       this.logger.info("Transaction already started - ref = " + this.transactionRefCount);
/* 31:   */     } else {
/* 32:26 */       this.logger.info("Transaction started");
/* 33:   */     }
/* 34:30 */     this.transactionRefCount += 1;
/* 35:   */   }
/* 36:   */   
/* 37:   */   public void commit()
/* 38:   */     throws RDOException
/* 39:   */   {
/* 40:35 */     if (this.transactionRefCount <= 0) {
/* 41:36 */       throw new RDOException("notxnstart");
/* 42:   */     }
/* 43:38 */     this.transactionRefCount -= 1;
/* 44:39 */     if (this.transactionRefCount > 0) {
/* 45:40 */       this.logger.info("Transaction commit pending - ref = " + this.transactionRefCount);
/* 46:   */     } else {
/* 47:   */       try
/* 48:   */       {
/* 49:47 */         this.logger.info("Transaction commit done");
/* 50:   */       }
/* 51:   */       catch (Exception e)
/* 52:   */       {
/* 53:49 */         throw new RDOException("txncommitfailed", e);
/* 54:   */       }
/* 55:   */     }
/* 56:   */   }
/* 57:   */   
/* 58:   */   public void rollback()
/* 59:   */     throws RDOException
/* 60:   */   {
/* 61:56 */     if (this.transactionRefCount > 0) {
/* 62:   */       try
/* 63:   */       {
/* 64:60 */         this.transactionRefCount = 0;
/* 65:61 */         this.logger.info("Transaction rollback done");
/* 66:   */       }
/* 67:   */       catch (Exception e)
/* 68:   */       {
/* 69:63 */         throw new RDOException("txnrollbackfailed", e);
/* 70:   */       }
/* 71:   */     }
/* 72:   */   }
/* 73:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.ibm.tivoli.maximo.mobile.android.persist.sqlite.SQLiteDBRDOTransactionManager
 * JD-Core Version:    0.7.0.1
 */