/*  1:   */ package com.ibm.tivoli.maximo.mobile.android.persist.sqlite;
/*  2:   */ 
/*  3:   */ import java.util.ArrayList;
/*  4:   */ 
/*  5:   */ public class SQLiteCustomQueryStatement
/*  6:   */ {
/*  7: 7 */   private ArrayList<String> list = new ArrayList(20);
/*  8:   */   
/*  9:   */   public void bindString(int bindIndex, String value)
/* 10:   */   {
/* 11:10 */     bindIndex -= 1;
/* 12:11 */     ensureSize(bindIndex);
/* 13:12 */     this.list.set(bindIndex, value);
/* 14:   */   }
/* 15:   */   
/* 16:   */   private void ensureSize(int desiredIndex)
/* 17:   */   {
/* 18:16 */     while (this.list.size() <= desiredIndex) {
/* 19:17 */       this.list.add(null);
/* 20:   */     }
/* 21:   */   }
/* 22:   */   
/* 23:   */   public void bindLong(int bindIndex, Long value)
/* 24:   */   {
/* 25:22 */     bindString(bindIndex, value.toString());
/* 26:   */   }
/* 27:   */   
/* 28:   */   public void bindDouble(int bindIndex, Double value)
/* 29:   */   {
/* 30:26 */     bindString(bindIndex, value.toString());
/* 31:   */   }
/* 32:   */   
/* 33:   */   public String[] toSelectionArgs()
/* 34:   */   {
/* 35:30 */     return (String[])this.list.toArray(new String[0]);
/* 36:   */   }
/* 37:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.ibm.tivoli.maximo.mobile.android.persist.sqlite.SQLiteCustomQueryStatement
 * JD-Core Version:    0.7.0.1
 */