/*    1:     */ package com.ibm.tivoli.maximo.mobile.android.persist.sqlite;
/*    2:     */ 
/*    3:     */ import android.database.Cursor;
/*    4:     */ import android.database.sqlite.SQLiteStatement;
/*    5:     */ import com.mro.mobile.persist.ConditionValue;
/*    6:     */ import com.mro.mobile.persist.DefaultRDO;
/*    7:     */ import com.mro.mobile.persist.Order;
/*    8:     */ import com.mro.mobile.persist.QBE;
/*    9:     */ import com.mro.mobile.persist.QBEData;
/*   10:     */ import com.mro.mobile.persist.RDO;
/*   11:     */ import com.mro.mobile.persist.RDOAttributeInfo;
/*   12:     */ import com.mro.mobile.persist.RDODependentRelation;
/*   13:     */ import com.mro.mobile.persist.RDOException;
/*   14:     */ import com.mro.mobile.persist.RDOInfo;
/*   15:     */ import com.mro.mobile.persist.RDOKey;
/*   16:     */ import com.mro.mobile.persist.sql.MobileWhereClause;
/*   17:     */ import com.mro.mobile.persist.sql.MobileWhereClauseVariableResolver;
/*   18:     */ import com.mro.mobile.util.MobileLogger;
/*   19:     */ import java.util.ArrayList;
/*   20:     */ import java.util.Calendar;
/*   21:     */ import java.util.Collection;
/*   22:     */ import java.util.Date;
/*   23:     */ import java.util.Enumeration;
/*   24:     */ import java.util.HashMap;
/*   25:     */ import java.util.HashSet;
/*   26:     */ import java.util.List;
/*   27:     */ 
/*   28:     */ public class SQLiteDBRDOManagerHelper
/*   29:     */ {
/*   30:     */   private static final int PARENT_ATTRIBUTE_POS = 0;
/*   31:     */   private static final int CHILD_ATTRIBUTE_POS = 1;
/*   32:     */   private MobileLogger logger;
/*   33:  43 */   private MobileWhereClauseVariableResolver resolver = new SQLiteMobileWhereClauseVariableResolver();
/*   34:     */   
/*   35:     */   public SQLiteDBRDOManagerHelper(MobileLogger persistenceLogger)
/*   36:     */   {
/*   37:  50 */     if (persistenceLogger == null) {
/*   38:  50 */       throw new IllegalArgumentException("logger cannot be null");
/*   39:     */     }
/*   40:  51 */     this.logger = persistenceLogger;
/*   41:     */   }
/*   42:     */   
/*   43:     */   public String buildInsertStatement(RDOInfo info)
/*   44:     */   {
/*   45:  64 */     StringBuilder statement = new StringBuilder("INSERT INTO ");
/*   46:  65 */     statement.append(formatName(info.getName()));
/*   47:  66 */     statement.append(" ( ");
/*   48:  67 */     String[] attrNames = info.getAttributeNames();
/*   49:  68 */     for (int i = 0; i < attrNames.length; i++) {
/*   50:  69 */       if (info.getAttributeInfo(i).isPersistent())
/*   51:     */       {
/*   52:  70 */         statement.append(formatName(attrNames[i]));
/*   53:  71 */         statement.append(",");
/*   54:     */       }
/*   55:     */     }
/*   56:  74 */     removeExtraChars(statement, ",");
/*   57:  75 */     statement.append(") VALUES (");
/*   58:  76 */     for (int i = 0; i < attrNames.length; i++) {
/*   59:  77 */       if (info.getAttributeInfo(i).isPersistent())
/*   60:     */       {
/*   61:  78 */         statement.append("?");
/*   62:  79 */         statement.append(",");
/*   63:     */       }
/*   64:     */     }
/*   65:  82 */     removeExtraChars(statement, ",");
/*   66:  83 */     statement.append(")");
/*   67:  84 */     return statement.toString();
/*   68:     */   }
/*   69:     */   
/*   70:     */   public String buildUpdateStatement(RDOInfo info)
/*   71:     */   {
/*   72: 100 */     boolean updateUsingId = info.getAttributeInfo("_ID") != null;
/*   73: 101 */     StringBuilder statement = new StringBuilder("UPDATE ");
/*   74: 102 */     statement.append(formatName(info.getName()));
/*   75: 103 */     statement.append(" SET ");
/*   76: 104 */     int count = info.getAttributeCount();
/*   77: 105 */     for (int i = 0; i < count; i++)
/*   78:     */     {
/*   79: 106 */       RDOAttributeInfo attrInfo = info.getAttributeInfo(i);
/*   80: 107 */       String attributeName = attrInfo.getName();
/*   81: 108 */       if ((attrInfo.isPersistent()) && 
/*   82: 109 */         (updateUsingId ? 
/*   83: 110 */         (!attributeName.equals("_ID")) || (!attributeName.equals("_PARENTID")) : 
/*   84:     */         
/*   85:     */ 
/*   86:     */ 
/*   87:     */ 
/*   88: 115 */         !attrInfo.isKey())) {
/*   89: 119 */         statement.append(formatName(attributeName)).append(" = ?, ");
/*   90:     */       }
/*   91:     */     }
/*   92: 122 */     removeExtraChars(statement, ", ");
/*   93: 123 */     statement.append(" WHERE ");
/*   94: 124 */     for (int i = 0; i < count; i++)
/*   95:     */     {
/*   96: 125 */       RDOAttributeInfo attrInfo = info.getAttributeInfo(i);
/*   97: 126 */       String attributeName = attrInfo.getName();
/*   98: 127 */       if ((!updateUsingId) || 
/*   99: 128 */         (attributeName.equals("_ID")) || (attributeName.equals("_PARENTID"))) {
/*  100: 133 */         if ((attrInfo.isKey()) || (attributeName.equals("_ID")) || ((info.isDependent()) && (attributeName.equals("_PARENTID"))))
/*  101:     */         {
/*  102: 134 */           statement.append(formatName(attrInfo.getName()));
/*  103: 135 */           statement.append(" = ? AND ");
/*  104:     */         }
/*  105:     */       }
/*  106:     */     }
/*  107: 138 */     removeExtraChars(statement, " AND ");
/*  108: 139 */     return statement.toString();
/*  109:     */   }
/*  110:     */   
/*  111:     */   public void bindUpdateStatementValues(SQLiteStatement statement, RDOInfo info, RDO rdo)
/*  112:     */     throws RDOException
/*  113:     */   {
/*  114: 151 */     String[] attrNames = info.getAttributeNames();
/*  115: 152 */     boolean updateUsingId = info.getAttributeInfo("_ID") != null;
/*  116: 153 */     int bindIndex = 1;
/*  117: 154 */     bindIndex = bindUpdateAttributeValues(statement, info, rdo, attrNames, updateUsingId, bindIndex);
/*  118: 155 */     bindUpdateKeyValues(statement, info, rdo, attrNames, updateUsingId, bindIndex);
/*  119:     */   }
/*  120:     */   
/*  121:     */   private int bindUpdateAttributeValues(SQLiteStatement statement, RDOInfo info, RDO rdo, String[] attrNames, boolean updateUsingId, int bindIndex)
/*  122:     */     throws RDOException
/*  123:     */   {
/*  124: 160 */     for (int i = 0; i < attrNames.length; i++)
/*  125:     */     {
/*  126: 161 */       RDOAttributeInfo attrInfo = info.getAttributeInfo(i);
/*  127: 162 */       String attributeName = attrInfo.getName();
/*  128: 163 */       if ((attrInfo.isPersistent()) && 
/*  129: 164 */         (updateUsingId ? 
/*  130: 165 */         (!attributeName.equals("_ID")) || (!attrInfo.getName().equals("_PARENTID")) : 
/*  131:     */         
/*  132:     */ 
/*  133:     */ 
/*  134: 169 */         !attrInfo.isKey()))
/*  135:     */       {
/*  136: 172 */         setBindValue(statement, bindIndex, attrInfo, rdo);
/*  137: 173 */         bindIndex++;
/*  138:     */       }
/*  139:     */     }
/*  140: 176 */     return bindIndex;
/*  141:     */   }
/*  142:     */   
/*  143:     */   private int bindUpdateKeyValues(SQLiteStatement statement, RDOInfo info, RDO rdo, String[] attrNames, boolean updateUsingId, int bindIndex)
/*  144:     */     throws RDOException
/*  145:     */   {
/*  146: 181 */     for (int i = 0; i < attrNames.length; i++)
/*  147:     */     {
/*  148: 182 */       RDOAttributeInfo attrInfo = info.getAttributeInfo(i);
/*  149: 183 */       String attributeName = attrInfo.getName();
/*  150: 184 */       if ((!updateUsingId) || 
/*  151: 185 */         (attributeName.equals("_ID")) || (attributeName.equals("_PARENTID"))) {
/*  152: 189 */         if ((info.isDependent()) && (attributeName.equals("_PARENTID")))
/*  153:     */         {
/*  154: 190 */           setBindValue(statement, bindIndex, attrInfo, rdo);
/*  155: 191 */           bindIndex++;
/*  156:     */         }
/*  157: 193 */         else if ((attrInfo.isKey()) || (attrInfo.getName().equals("_ID")))
/*  158:     */         {
/*  159: 197 */           setBindValue(statement, bindIndex, attrInfo, rdo);
/*  160: 198 */           bindIndex++;
/*  161:     */         }
/*  162:     */       }
/*  163:     */     }
/*  164: 201 */     return bindIndex;
/*  165:     */   }
/*  166:     */   
/*  167:     */   public String buildDeleteStatementBasedOnKeys(RDOInfo info, RDOKey key)
/*  168:     */   {
/*  169: 212 */     String[] attrNames = info.getAttributeNames();
/*  170: 213 */     String[] keyValues = key.getKeyValues();
/*  171: 214 */     StringBuilder builder = new StringBuilder("DELETE FROM ");
/*  172: 215 */     builder.append(formatName(info.getName()));
/*  173: 216 */     builder.append(" WHERE ");
/*  174: 217 */     boolean navThroughKey = false;
/*  175: 218 */     int keyPos = 0;
/*  176: 219 */     for (int i = 0; i < attrNames.length; i++)
/*  177:     */     {
/*  178: 220 */       RDOAttributeInfo attrInfo = info.getAttributeInfo(attrNames[i]);
/*  179: 221 */       if (attrInfo.isKey())
/*  180:     */       {
/*  181: 222 */         if (navThroughKey) {
/*  182: 223 */           builder.append(" and ");
/*  183:     */         }
/*  184: 225 */         builder.append(formatName(attrInfo.getName()));
/*  185: 226 */         if (keyValues[keyPos] != null) {
/*  186: 227 */           builder.append(" = ?");
/*  187:     */         } else {
/*  188: 229 */           builder.append(" is NULL");
/*  189:     */         }
/*  190: 231 */         keyPos++;
/*  191: 232 */         navThroughKey = true;
/*  192:     */       }
/*  193:     */     }
/*  194: 235 */     return builder.toString();
/*  195:     */   }
/*  196:     */   
/*  197:     */   public String buildSimpleDeleteStatement(String name)
/*  198:     */   {
/*  199: 246 */     return String.format("DELETE FROM %s", new Object[] { formatName(name) });
/*  200:     */   }
/*  201:     */   
/*  202:     */   public String buildDeleteStatementWithID(String name)
/*  203:     */   {
/*  204: 257 */     return String.format("DELETE FROM %s WHERE %s = ?", new Object[] { formatName(name), formatName("_ID") });
/*  205:     */   }
/*  206:     */   
/*  207:     */   public String buildDeleteStatementWithIDAndParentId(String name)
/*  208:     */   {
/*  209: 268 */     return String.format("DELETE FROM %s WHERE %s = ? and %s = ?", new Object[] { formatName(name), formatName("_ID"), formatName("_PARENTID") });
/*  210:     */   }
/*  211:     */   
/*  212:     */   public String buildDeleteStatementWithParentId(String name)
/*  213:     */   {
/*  214: 279 */     return String.format("DELETE FROM %s WHERE %s = ?", new Object[] { formatName(name), formatName("_PARENTID") });
/*  215:     */   }
/*  216:     */   
/*  217:     */   public String buildDeleteStatementWithOwnerId(String name)
/*  218:     */   {
/*  219: 290 */     return String.format("DELETE FROM %s WHERE %s = ?", new Object[] { formatName(name), formatName("_OWNERID") });
/*  220:     */   }
/*  221:     */   
/*  222:     */   public String formatName(String name)
/*  223:     */   {
/*  224: 300 */     return "\"" + name + "\"";
/*  225:     */   }
/*  226:     */   
/*  227:     */   public String buildSimpleQueryByKey(RDOInfo info, RDOKey key)
/*  228:     */   {
/*  229: 311 */     StringBuilder query = new StringBuilder("SELECT * FROM %s WHERE ");
/*  230: 312 */     String[] keys = info.getKeyAttributeNames();
/*  231: 313 */     String[] values = key.getKeyValues();
/*  232: 314 */     for (int i = 0; i < keys.length; i++)
/*  233:     */     {
/*  234: 315 */       query.append(keys[i]);
/*  235: 316 */       if (values[i] == null) {
/*  236: 317 */         query.append(" is NULL and ");
/*  237:     */       } else {
/*  238: 320 */         query.append(" = ? and ");
/*  239:     */       }
/*  240:     */     }
/*  241: 323 */     removeExtraChars(query, "and ");
/*  242: 324 */     return String.format(query.toString(), new Object[] { formatName(info.getName()) });
/*  243:     */   }
/*  244:     */   
/*  245:     */   void removeExtraChars(StringBuilder statement, String extra)
/*  246:     */   {
/*  247: 328 */     int index = statement.lastIndexOf(extra);
/*  248: 329 */     if (index >= 0) {
/*  249: 330 */       statement.delete(index, index + extra.length());
/*  250:     */     }
/*  251:     */   }
/*  252:     */   
/*  253:     */   public void setBindValue(SQLiteStatement statement, int bindIndex, RDOAttributeInfo attributeInfo, RDO rdo)
/*  254:     */     throws RDOException
/*  255:     */   {
/*  256: 347 */     String attributeName = attributeInfo.getName();
/*  257: 348 */     switch (attributeInfo.getDataType())
/*  258:     */     {
/*  259:     */     case 1: 
/*  260:     */     case 2: 
/*  261:     */     case 3: 
/*  262: 352 */       if (rdo.isNull(attributeName))
/*  263:     */       {
/*  264: 353 */         this.logger.info(String.format("bind value for %s = NULL", new Object[] { attributeName }));
/*  265: 354 */         statement.bindNull(bindIndex);
/*  266:     */       }
/*  267:     */       else
/*  268:     */       {
/*  269: 356 */         this.logger.info(String.format("bind value for %s = %s", new Object[] { attributeName, rdo.getStringValue(attributeName) }));
/*  270: 357 */         statement.bindString(bindIndex, rdo.getStringValue(attributeName));
/*  271:     */       }
/*  272: 359 */       break;
/*  273:     */     case 8: 
/*  274: 361 */       this.logger.info(String.format("bind value for %s = %d", new Object[] { attributeName, Integer.valueOf(rdo.getBooleanValue(attributeName) ? 1 : 0) }));
/*  275: 362 */       statement.bindLong(bindIndex, rdo.getBooleanValue(attributeName) ? 1L : 0L);
/*  276: 363 */       break;
/*  277:     */     case 4: 
/*  278: 365 */       if (rdo.isNull(attributeName))
/*  279:     */       {
/*  280: 366 */         this.logger.info(String.format("bind value for %s = NULL", new Object[] { attributeName }));
/*  281: 367 */         statement.bindNull(bindIndex);
/*  282:     */       }
/*  283:     */       else
/*  284:     */       {
/*  285: 369 */         this.logger.info(String.format("bind value for %s = %d", new Object[] { attributeName, Integer.valueOf(rdo.getIntValue(attributeName)) }));
/*  286: 370 */         statement.bindLong(bindIndex, rdo.getIntValue(attributeName));
/*  287:     */       }
/*  288: 372 */       break;
/*  289:     */     case 5: 
/*  290: 374 */       if (rdo.isNull(attributeName))
/*  291:     */       {
/*  292: 375 */         this.logger.info(String.format("bind value for %s = NULL", new Object[] { attributeName }));
/*  293: 376 */         statement.bindNull(bindIndex);
/*  294:     */       }
/*  295:     */       else
/*  296:     */       {
/*  297: 378 */         this.logger.info(String.format("bind value for %s = %d", new Object[] { attributeName, Long.valueOf(rdo.getLongValue(attributeName)) }));
/*  298: 379 */         statement.bindLong(bindIndex, rdo.getLongValue(attributeName));
/*  299:     */       }
/*  300: 381 */       break;
/*  301:     */     case 6: 
/*  302: 383 */       if (rdo.isNull(attributeName))
/*  303:     */       {
/*  304: 384 */         this.logger.info(String.format("bind value for %s = NULL", new Object[] { attributeName }));
/*  305: 385 */         statement.bindNull(bindIndex);
/*  306:     */       }
/*  307:     */       else
/*  308:     */       {
/*  309: 387 */         this.logger.info(String.format("bind value for %s = %f", new Object[] { attributeName, Float.valueOf(rdo.getFloatValue(attributeName)) }));
/*  310: 388 */         statement.bindDouble(bindIndex, rdo.getFloatValue(attributeName));
/*  311:     */       }
/*  312: 390 */       break;
/*  313:     */     case 7: 
/*  314: 392 */       if (rdo.isNull(attributeName))
/*  315:     */       {
/*  316: 393 */         this.logger.info(String.format("bind value for %s = NULL", new Object[] { attributeName }));
/*  317: 394 */         statement.bindNull(bindIndex);
/*  318:     */       }
/*  319:     */       else
/*  320:     */       {
/*  321: 396 */         this.logger.info(String.format("bind value for %s = %f", new Object[] { attributeName, Double.valueOf(rdo.getDoubleValue(attributeName)) }));
/*  322: 397 */         statement.bindDouble(bindIndex, rdo.getDoubleValue(attributeName));
/*  323:     */       }
/*  324: 399 */       break;
/*  325:     */     case 9: 
/*  326:     */     case 10: 
/*  327:     */     case 11: 
/*  328: 403 */       if (rdo.isNull(attributeName))
/*  329:     */       {
/*  330: 404 */         this.logger.info(String.format("bind value for %s = NULL", new Object[] { attributeName }));
/*  331: 405 */         statement.bindNull(bindIndex);
/*  332:     */       }
/*  333:     */       else
/*  334:     */       {
/*  335: 407 */         this.logger.info(String.format("bind value for %s = %d", new Object[] { attributeName, Long.valueOf(rdo.getDateValue(attributeName).getTime()) }));
/*  336: 408 */         statement.bindLong(bindIndex, rdo.getDateValue(attributeName).getTime());
/*  337:     */       }
/*  338: 410 */       break;
/*  339:     */     case 12: 
/*  340: 412 */       if (rdo.isNull(attributeName))
/*  341:     */       {
/*  342: 413 */         this.logger.info(String.format("bind value for %s = NULL", new Object[] { attributeName }));
/*  343: 414 */         statement.bindNull(bindIndex);
/*  344:     */       }
/*  345:     */       else
/*  346:     */       {
/*  347: 416 */         byte[] b = rdo.getBinaryValue(attributeName);
/*  348: 417 */         this.logger.info(String.format("bind value for %s = %s - length: %d", new Object[] { attributeName, b.toString(), Integer.valueOf(b.length) }));
/*  349: 418 */         statement.bindBlob(bindIndex, rdo.getBinaryValue(attributeName));
/*  350:     */       }
/*  351: 420 */       break;
/*  352:     */     default: 
/*  353: 422 */       if (rdo.isNull(attributeName))
/*  354:     */       {
/*  355: 423 */         this.logger.info(String.format("bind value for %s = NULL", new Object[] { attributeName }));
/*  356: 424 */         statement.bindNull(bindIndex);
/*  357:     */       }
/*  358:     */       else
/*  359:     */       {
/*  360: 426 */         this.logger.info(String.format("bind value for %s = %s", new Object[] { attributeName, rdo.getStringValue(attributeName) }));
/*  361: 427 */         statement.bindString(bindIndex, rdo.getStringValue(attributeName));
/*  362:     */       }
/*  363:     */       break;
/*  364:     */     }
/*  365:     */   }
/*  366:     */   
/*  367:     */   public String buildSimpleCountQuery(RDOInfo info)
/*  368:     */   {
/*  369: 441 */     StringBuilder builder = new StringBuilder("SELECT COUNT(*) FROM %s");
/*  370: 442 */     if (info.isHierarchical())
/*  371:     */     {
/*  372: 443 */       builder.append(" WHERE %s is NULL");
/*  373: 444 */       return String.format(builder.toString(), new Object[] { formatName(info.getName()), formatName("_OWNERID") });
/*  374:     */     }
/*  375: 446 */     return String.format(builder.toString(), new Object[] { formatName(info.getName()) });
/*  376:     */   }
/*  377:     */   
/*  378:     */   public String buildSimpleDependentQuery(String name, long id, long parentId)
/*  379:     */   {
/*  380: 459 */     return String.format("SELECT * FROM %s WHERE %s = %d and %s = %d", new Object[] { name, formatName("_ID"), Long.valueOf(id), formatName("_PARENTID"), Long.valueOf(parentId) });
/*  381:     */   }
/*  382:     */   
/*  383:     */   public String buildSimpleIdQuery(String name, long id)
/*  384:     */   {
/*  385: 471 */     return String.format("SELECT * FROM %s WHERE %s = %d", new Object[] { name, formatName("_ID"), Long.valueOf(id) });
/*  386:     */   }
/*  387:     */   
/*  388:     */   public RDO buildRDO(Cursor cursor, RDOInfo rdoInfo, String appName)
/*  389:     */     throws RDOException
/*  390:     */   {
/*  391: 484 */     DefaultRDO rdo = new DefaultRDO(appName, true);
/*  392: 485 */     rdo.setName(rdoInfo.getName());
/*  393: 486 */     for (String name : rdoInfo.getAttributeNames())
/*  394:     */     {
/*  395: 487 */       int index = cursor.getColumnIndex(name);
/*  396: 488 */       if (index < 0)
/*  397:     */       {
/*  398: 489 */         this.logger.warn("Could not find index for column " + name + " when build RDO for object " + rdoInfo.getName());
/*  399:     */       }
/*  400:     */       else
/*  401:     */       {
/*  402: 491 */         RDOAttributeInfo attrInfo = rdoInfo.getAttributeInfo(name);
/*  403: 492 */         if (attrInfo.isPersistent())
/*  404:     */         {
/*  405: 493 */           int dataType = attrInfo.getDataType();
/*  406: 494 */           switch (dataType)
/*  407:     */           {
/*  408:     */           case 1: 
/*  409:     */           case 2: 
/*  410:     */           case 3: 
/*  411: 498 */             rdo.setStringValue(name, cursor.getString(index));
/*  412: 499 */             break;
/*  413:     */           case 4: 
/*  414: 501 */             if (!cursor.isNull(index)) {
/*  415: 502 */               rdo.setIntValue(name, cursor.getInt(index));
/*  416:     */             }
/*  417:     */             break;
/*  418:     */           case 5: 
/*  419: 506 */             if (!cursor.isNull(index)) {
/*  420: 507 */               rdo.setLongValue(name, cursor.getLong(index));
/*  421:     */             }
/*  422:     */             break;
/*  423:     */           case 6: 
/*  424: 511 */             if (!cursor.isNull(index)) {
/*  425: 512 */               rdo.setFloatValue(name, cursor.getFloat(index));
/*  426:     */             }
/*  427:     */             break;
/*  428:     */           case 7: 
/*  429: 516 */             if (!cursor.isNull(index)) {
/*  430: 517 */               rdo.setDoubleValue(name, cursor.getDouble(index));
/*  431:     */             }
/*  432:     */             break;
/*  433:     */           case 8: 
/*  434: 521 */             rdo.setBooleanValue(name, cursor.getInt(index) == 1);
/*  435: 522 */             break;
/*  436:     */           case 9: 
/*  437: 524 */             if (!cursor.isNull(index))
/*  438:     */             {
/*  439: 525 */               Calendar c = Calendar.getInstance();
/*  440: 526 */               c.setTimeInMillis(cursor.getLong(index));
/*  441: 527 */               rdo.setDateValue(name, c.getTime());
/*  442:     */             }
/*  443: 528 */             break;
/*  444:     */           case 10: 
/*  445: 531 */             if (!cursor.isNull(index))
/*  446:     */             {
/*  447: 532 */               Calendar c = Calendar.getInstance();
/*  448: 533 */               c.setTimeInMillis(cursor.getLong(index));
/*  449: 534 */               rdo.setDateValue(name, c.getTime());
/*  450:     */             }
/*  451: 535 */             break;
/*  452:     */           case 11: 
/*  453: 538 */             if (!cursor.isNull(index))
/*  454:     */             {
/*  455: 539 */               Calendar c = Calendar.getInstance();
/*  456: 540 */               c.setTimeInMillis(cursor.getLong(index));
/*  457: 541 */               rdo.setDateValue(name, c.getTime());
/*  458:     */             }
/*  459: 542 */             break;
/*  460:     */           case 12: 
/*  461: 545 */             rdo.setBinaryValue(name, cursor.getBlob(index));
/*  462: 546 */             break;
/*  463:     */           default: 
/*  464: 548 */             rdo.setStringValue(name, cursor.getString(index));
/*  465:     */           }
/*  466:     */         }
/*  467:     */       }
/*  468:     */     }
/*  469: 554 */     return rdo;
/*  470:     */   }
/*  471:     */   
/*  472:     */   public String getOrderClause(Order order)
/*  473:     */     throws RDOException
/*  474:     */   {
/*  475: 565 */     StringBuilder orderWhere = new StringBuilder();
/*  476: 566 */     if (order != null)
/*  477:     */     {
/*  478: 567 */       Enumeration<?> orderEnum = order.getOrderedAttributes();
/*  479: 568 */       while (orderEnum.hasMoreElements())
/*  480:     */       {
/*  481: 569 */         String attribute = (String)orderEnum.nextElement();
/*  482: 570 */         boolean ascending = order.getOrder(attribute);
/*  483: 571 */         orderWhere.append(formatName(attribute));
/*  484: 572 */         orderWhere.append(" ");
/*  485: 573 */         orderWhere.append(ascending ? "ASC" : "DESC");
/*  486: 574 */         orderWhere.append(",");
/*  487:     */       }
/*  488: 576 */       removeExtraChars(orderWhere, ",");
/*  489:     */     }
/*  490: 578 */     return orderWhere.toString();
/*  491:     */   }
/*  492:     */   
/*  493:     */   public String buildQBEDependentWhere(RDOInfo depInfo, QBE qbeFilter, SQLiteQBEDependentInfo dependentInfo)
/*  494:     */     throws RDOException
/*  495:     */   {
/*  496: 594 */     StringBuilder depQBEWhere = new StringBuilder();
/*  497: 595 */     for (String depAttributeName : dependentInfo.getAttributes())
/*  498:     */     {
/*  499: 596 */       String setQBEAttr = dependentInfo.getName() + "." + depAttributeName;
/*  500: 597 */       String depQBEValue = qbeFilter.getQBE(setQBEAttr);
/*  501: 598 */       String depQBEAttrWhere = getQBEAttrWhere(depInfo, depAttributeName, depQBEValue, qbeFilter.getQBEData(setQBEAttr), qbeFilter.isQbeExactMatch());
/*  502:     */       
/*  503:     */ 
/*  504:     */ 
/*  505:     */ 
/*  506: 603 */       depQBEWhere.append(" ");
/*  507: 604 */       depQBEWhere.append(depQBEAttrWhere);
/*  508: 605 */       depQBEWhere.append(" AND");
/*  509:     */     }
/*  510: 607 */     removeExtraChars(depQBEWhere, "AND");
/*  511: 608 */     return depQBEWhere.toString();
/*  512:     */   }
/*  513:     */   
/*  514:     */   protected int getConditionExpression(String qbeValue)
/*  515:     */   {
/*  516: 612 */     for (int i = 0; i < QBE.EXPRLIST.length; i++)
/*  517:     */     {
/*  518: 613 */       String condition = QBE.EXPRLIST[i];
/*  519: 614 */       if ((qbeValue.length() >= condition.length()) && 
/*  520: 615 */         (qbeValue.startsWith(condition))) {
/*  521: 616 */         return i;
/*  522:     */       }
/*  523:     */     }
/*  524: 620 */     return -1;
/*  525:     */   }
/*  526:     */   
/*  527:     */   public String getQBEAttrWhere(RDOInfo info, String attribute, String value, QBEData qbeData, boolean exactMatch)
/*  528:     */   {
/*  529: 635 */     StringBuilder qbeAttrWhere = new StringBuilder();
/*  530: 636 */     RDOAttributeInfo attrInfo = info.getAttributeInfo(attribute);
/*  531: 637 */     String formattedAttribute = formatName(attribute);
/*  532: 638 */     if (value.equals("~NULL~"))
/*  533:     */     {
/*  534: 639 */       if (attrInfo.isAlphaNumeric()) {
/*  535: 640 */         qbeAttrWhere.append("(" + formattedAttribute + " is null or " + formattedAttribute + " = '')");
/*  536:     */       } else {
/*  537: 642 */         qbeAttrWhere.append(formattedAttribute + " is null ");
/*  538:     */       }
/*  539:     */     }
/*  540: 644 */     else if (value.equals("!=~NULL~"))
/*  541:     */     {
/*  542: 645 */       if (attrInfo.isAlphaNumeric()) {
/*  543: 646 */         qbeAttrWhere.append("(" + formattedAttribute + " is not null or " + formattedAttribute + " != '')");
/*  544:     */       } else {
/*  545: 648 */         qbeAttrWhere.append(formattedAttribute + " is not null ");
/*  546:     */       }
/*  547:     */     }
/*  548:     */     else
/*  549:     */     {
/*  550: 651 */       int conditionIndex = getConditionExpression(value);
/*  551: 652 */       if (attrInfo.isAlphaNumeric())
/*  552:     */       {
/*  553: 653 */         if (qbeData.hasMultipleValues())
/*  554:     */         {
/*  555: 654 */           String[] values = (String[])qbeData.getInternalValue();
/*  556: 655 */           for (int j = 0; j < values.length; j++)
/*  557:     */           {
/*  558: 656 */             if (j > 0) {
/*  559: 657 */               qbeAttrWhere.append(" OR ");
/*  560:     */             }
/*  561: 659 */             if (exactMatch) {
/*  562: 660 */               qbeAttrWhere.append(formattedAttribute + " = ?");
/*  563:     */             } else {
/*  564: 662 */               qbeAttrWhere.append("UPPER(" + formattedAttribute + ") like UPPER(?)");
/*  565:     */             }
/*  566:     */           }
/*  567: 665 */           qbeAttrWhere = new StringBuilder("(" + qbeAttrWhere + ")");
/*  568:     */         }
/*  569: 667 */         else if (conditionIndex >= 0)
/*  570:     */         {
/*  571: 668 */           qbeAttrWhere.append(formattedAttribute + " " + QBE.EXPRLIST[conditionIndex] + " ?");
/*  572:     */         }
/*  573: 670 */         else if (exactMatch)
/*  574:     */         {
/*  575: 671 */           qbeAttrWhere.append(formattedAttribute + " = ?");
/*  576:     */         }
/*  577:     */         else
/*  578:     */         {
/*  579: 673 */           qbeAttrWhere.append("UPPER(" + formattedAttribute + ") like UPPER(?)");
/*  580:     */         }
/*  581:     */       }
/*  582: 677 */       else if (attrInfo.isNumeric())
/*  583:     */       {
/*  584: 678 */         if (qbeData.hasMultipleValues())
/*  585:     */         {
/*  586: 679 */           String[] values = (String[])qbeData.getInternalValue();
/*  587: 680 */           for (int j = 0; j < values.length; j++) {
/*  588: 681 */             qbeAttrWhere.append("?,");
/*  589:     */           }
/*  590: 683 */           removeExtraChars(qbeAttrWhere, ",");
/*  591: 684 */           qbeAttrWhere = new StringBuilder(formattedAttribute + " IN (" + qbeAttrWhere + ")");
/*  592:     */         }
/*  593: 686 */         else if (conditionIndex >= 0)
/*  594:     */         {
/*  595: 687 */           qbeAttrWhere.append(formattedAttribute + " " + QBE.EXPRLIST[conditionIndex] + " ?");
/*  596:     */         }
/*  597:     */         else
/*  598:     */         {
/*  599: 689 */           qbeAttrWhere.append(formattedAttribute + " = ?");
/*  600:     */         }
/*  601:     */       }
/*  602: 692 */       else if (attrInfo.isBoolean()) {
/*  603: 693 */         qbeAttrWhere.append(formattedAttribute + " = ?");
/*  604: 694 */       } else if (attrInfo.isDate())
/*  605:     */       {
/*  606: 695 */         if (conditionIndex >= 0) {
/*  607: 696 */           qbeAttrWhere.append(formattedAttribute + " " + QBE.EXPRLIST[conditionIndex] + " ?");
/*  608:     */         } else {
/*  609: 698 */           qbeAttrWhere.append(formattedAttribute + " = ?");
/*  610:     */         }
/*  611:     */       }
/*  612: 700 */       else if (attrInfo.isTime())
/*  613:     */       {
/*  614: 701 */         if (conditionIndex >= 0) {
/*  615: 702 */           qbeAttrWhere.append(formattedAttribute + " " + QBE.EXPRLIST[conditionIndex] + " ?");
/*  616:     */         } else {
/*  617: 704 */           qbeAttrWhere.append(formattedAttribute + " = ?");
/*  618:     */         }
/*  619:     */       }
/*  620: 706 */       else if (attrInfo.isDateTime()) {
/*  621: 707 */         if (conditionIndex >= 0) {
/*  622: 708 */           qbeAttrWhere.append(formattedAttribute + " " + QBE.EXPRLIST[conditionIndex] + " ?");
/*  623:     */         } else {
/*  624: 710 */           qbeAttrWhere.append("(" + formattedAttribute + " >= ? and " + formattedAttribute + " <= ?" + ")");
/*  625:     */         }
/*  626:     */       }
/*  627:     */     }
/*  628: 714 */     return qbeAttrWhere.toString();
/*  629:     */   }
/*  630:     */   
/*  631:     */   public String getQBEWhere(RDOInfo info, QBE qbeFilter, SQLiteDBRDOManager rdoManager)
/*  632:     */     throws RDOException
/*  633:     */   {
/*  634: 730 */     StringBuilder qbeWhere = new StringBuilder();
/*  635: 731 */     if (qbeFilter != null)
/*  636:     */     {
/*  637: 732 */       Enumeration<?> attrEnum = qbeFilter.getQBEAttributes();
/*  638: 733 */       while (attrEnum.hasMoreElements())
/*  639:     */       {
/*  640: 734 */         String attribute = (String)attrEnum.nextElement();
/*  641: 735 */         if (!isDependentQBEAttribute(attribute))
/*  642:     */         {
/*  643: 736 */           String value = qbeFilter.getQBE(attribute);
/*  644: 737 */           String qbeAttrWhere = getQBEAttrWhere(info, attribute, value, qbeFilter.getQBEData(attribute), qbeFilter.isQbeExactMatch());
/*  645: 738 */           if (qbeAttrWhere.length() > 0)
/*  646:     */           {
/*  647: 739 */             qbeWhere.append(qbeAttrWhere);
/*  648: 740 */             qbeWhere.append(" AND ");
/*  649:     */           }
/*  650:     */         }
/*  651:     */       }
/*  652: 744 */       removeExtraChars(qbeWhere, " AND ");
/*  653: 745 */       Collection<SQLiteQBEDependentInfo> depQBEData = getDependentQBEData(qbeFilter);
/*  654: 746 */       if (!depQBEData.isEmpty())
/*  655:     */       {
/*  656: 750 */         String dependentBasedQuery = getDependentBasedQbeWhere(info, depQBEData, qbeFilter, rdoManager);
/*  657: 751 */         if (qbeWhere.length() > 0)
/*  658:     */         {
/*  659: 752 */           qbeWhere = new StringBuilder("(" + qbeWhere.toString() + ")");
/*  660: 753 */           qbeWhere.append(" OR ");
/*  661:     */         }
/*  662: 755 */         qbeWhere.append(" " + dependentBasedQuery);
/*  663:     */       }
/*  664:     */     }
/*  665: 758 */     return qbeWhere.toString();
/*  666:     */   }
/*  667:     */   
/*  668:     */   protected String getDependentBasedQbeWhere(RDOInfo parentInfo, Collection<SQLiteQBEDependentInfo> depQBEData, QBE qbeFilter, SQLiteDBRDOManager rdoManager)
/*  669:     */     throws RDOException
/*  670:     */   {
/*  671: 762 */     StringBuilder dependentQuery = new StringBuilder();
/*  672:     */     HashSet<String> depNamesArrayList;
/*  673: 763 */     if (depQBEData.size() > 0)
/*  674:     */     {
/*  675: 764 */       String[] depNames = parentInfo.getDependentNames();
/*  676: 765 */       depNamesArrayList = new HashSet();
/*  677: 766 */       for (int j = 0; j < depNames.length; j++) {
/*  678: 767 */         depNamesArrayList.add(depNames[j]);
/*  679:     */       }
/*  680: 770 */       for (SQLiteQBEDependentInfo dependentInfo : depQBEData)
/*  681:     */       {
/*  682: 771 */         String depName = dependentInfo.getName();
/*  683: 772 */         if (depNamesArrayList.contains(depName))
/*  684:     */         {
/*  685: 773 */           String depWhere = "";
/*  686: 774 */           RDOInfo depInfo = rdoManager.getRDOInfoOrThrowException(depName);
/*  687: 775 */           if (depInfo.getDependentRelation() != null) {
/*  688: 776 */             depWhere = buildQBEDependentWhereByKey(depInfo, qbeFilter, dependentInfo, rdoManager);
/*  689:     */           } else {
/*  690: 778 */             depWhere = buildQBEDependentWhereById(depInfo, qbeFilter, dependentInfo, rdoManager);
/*  691:     */           }
/*  692: 780 */           if (depWhere.length() > 0) {
/*  693: 781 */             if (dependentQuery.length() > 0)
/*  694:     */             {
/*  695: 782 */               dependentQuery.append(" AND ");
/*  696: 783 */               dependentQuery.append(depWhere);
/*  697:     */             }
/*  698:     */             else
/*  699:     */             {
/*  700: 785 */               dependentQuery.append(depWhere);
/*  701:     */             }
/*  702:     */           }
/*  703:     */         }
/*  704:     */       }
/*  705:     */     }
/*  706: 791 */     return dependentQuery.toString();
/*  707:     */   }
/*  708:     */   
/*  709:     */   public String buildQBEDependentWhereByKey(RDOInfo depInfo, QBE qbeFilter, SQLiteQBEDependentInfo dependentInfo, SQLiteDBRDOManager rdoManager)
/*  710:     */     throws RDOException
/*  711:     */   {
/*  712: 795 */     StringBuilder depQBEWhere = new StringBuilder();
/*  713: 796 */     for (String depAttributeName : dependentInfo.getAttributes())
/*  714:     */     {
/*  715: 797 */       String setQBEAttr = dependentInfo.getName() + "." + depAttributeName;
/*  716: 798 */       String depQBEValue = qbeFilter.getQBE(setQBEAttr);
/*  717: 799 */       String depQBEAttrWhere = getQBEAttrWhere(depInfo, depAttributeName, depQBEValue, qbeFilter.getQBEData(setQBEAttr), qbeFilter.isQbeExactMatch());
/*  718: 800 */       depQBEWhere.append(" ");
/*  719: 801 */       depQBEWhere.append(depQBEAttrWhere);
/*  720: 802 */       depQBEWhere.append(" AND ");
/*  721:     */     }
/*  722: 804 */     removeExtraChars(depQBEWhere, " AND ");
/*  723: 805 */     String query = String.format("SELECT DISTINCT(%s) FROM %s where %s", new Object[] { formatName("_PARENTID"), depInfo.getName(), depQBEWhere.toString() });
/*  724: 806 */     ArrayList<ConditionValue> parentKeyList = rdoManager.getParentKeyList(depInfo, query, qbeFilter, dependentInfo);
/*  725: 811 */     if (parentKeyList.isEmpty()) {
/*  726: 812 */       return "(1=2)";
/*  727:     */     }
/*  728: 814 */     return buildWhereFromParentKeyList(depInfo, parentKeyList);
/*  729:     */   }
/*  730:     */   
/*  731:     */   public String buildQBEDependentWhereById(RDOInfo depInfo, QBE qbeFilter, SQLiteQBEDependentInfo dependentInfo, SQLiteDBRDOManager rdoManager)
/*  732:     */     throws RDOException
/*  733:     */   {
/*  734: 818 */     StringBuilder depQBEWhere = new StringBuilder();
/*  735: 819 */     String[] depAttrs = dependentInfo.getAttributes();
/*  736: 820 */     for (String qDepAttributeName : depAttrs)
/*  737:     */     {
/*  738: 821 */       String setQBEAttr = dependentInfo.getName() + "." + qDepAttributeName;
/*  739: 822 */       String depQBEValue = qbeFilter.getQBE(setQBEAttr);
/*  740: 823 */       String depQBEAttrWhere = getQBEAttrWhere(depInfo, qDepAttributeName, depQBEValue, qbeFilter.getQBEData(setQBEAttr), qbeFilter.isQbeExactMatch());
/*  741: 824 */       depQBEWhere.append(depQBEAttrWhere);
/*  742: 825 */       depQBEWhere.append(" AND ");
/*  743:     */     }
/*  744: 827 */     removeExtraChars(depQBEWhere, " AND ");
/*  745: 828 */     String query = String.format("SELECT DISTINCT(%s) FROM %s where %s", new Object[] { formatName("_PARENTID"), depInfo.getName(), depQBEWhere.toString() });
/*  746: 829 */     ArrayList<Long> parentIdList = rdoManager.getParentIdList(query, qbeFilter, depInfo.getName(), dependentInfo);
/*  747: 834 */     if (parentIdList.isEmpty()) {
/*  748: 835 */       return "(1=2)";
/*  749:     */     }
/*  750: 837 */     return buildWhereFromParentIdList(parentIdList);
/*  751:     */   }
/*  752:     */   
/*  753:     */   public int applyDepQBEBindings(RDOInfo depInfo, QBE qbe, SQLiteCustomQueryStatement ps, int bindIndex, SQLiteQBEDependentInfo dependentInfo)
/*  754:     */     throws RDOException
/*  755:     */   {
/*  756: 841 */     if (qbe != null)
/*  757:     */     {
/*  758: 842 */       String[] attributes = dependentInfo.getAttributes();
/*  759: 843 */       String dependentName = dependentInfo.getName();
/*  760: 844 */       for (String qbeAttrName : attributes)
/*  761:     */       {
/*  762: 845 */         String qbeValue = qbe.getQBE(dependentName + "." + qbeAttrName);
/*  763: 846 */         QBEData filterData = qbe.getQBEData(dependentName + "." + qbeAttrName);
/*  764: 847 */         if (!filterData.isNullValueCheck()) {
/*  765: 848 */           bindIndex = setQBEBinding(depInfo.getAttributeInfo(qbeAttrName), filterData, ps, bindIndex, qbeValue, qbe);
/*  766:     */         }
/*  767:     */       }
/*  768:     */     }
/*  769: 852 */     return bindIndex;
/*  770:     */   }
/*  771:     */   
/*  772:     */   private String replaceStarWithPercent(String str)
/*  773:     */   {
/*  774: 856 */     StringBuilder newBuf = new StringBuilder();
/*  775: 857 */     char[] charArray = str.toCharArray();
/*  776: 858 */     for (int i = 0; i < charArray.length; i++)
/*  777:     */     {
/*  778: 859 */       char c = charArray[i];
/*  779: 860 */       if (c == '*') {
/*  780: 861 */         newBuf.append("%");
/*  781:     */       } else {
/*  782: 863 */         newBuf.append(c);
/*  783:     */       }
/*  784:     */     }
/*  785: 866 */     return newBuf.toString();
/*  786:     */   }
/*  787:     */   
/*  788:     */   public int setQBEBinding(RDOAttributeInfo attributeInfo, QBEData qbeData, SQLiteCustomQueryStatement ps, int bindIndex, Object bindValue, QBE qbe)
/*  789:     */     throws RDOException
/*  790:     */   {
/*  791: 870 */     String attributeName = attributeInfo.getName();
/*  792: 871 */     if (attributeInfo.isAlphaNumeric())
/*  793:     */     {
/*  794: 872 */       if (qbeData.hasMultipleValues())
/*  795:     */       {
/*  796: 873 */         String[] values = (String[])qbeData.getInternalValue();
/*  797: 874 */         for (int i = 0; i < values.length; i++)
/*  798:     */         {
/*  799: 875 */           String strValue = values[i];
/*  800: 876 */           if (attributeInfo.getDataType() == 2) {
/*  801: 877 */             strValue = strValue.toUpperCase();
/*  802: 878 */           } else if (attributeInfo.getDataType() == 3) {
/*  803: 879 */             strValue = strValue.toLowerCase();
/*  804:     */           }
/*  805: 881 */           if (!qbe.isQbeExactMatch()) {
/*  806: 882 */             strValue = replaceStarWithPercent(strValue);
/*  807:     */           }
/*  808: 884 */           if ((!qbe.isQbeExactMatch()) && (qbeData.getCondition().length() == 0))
/*  809:     */           {
/*  810: 885 */             strValue = strValue.toUpperCase();
/*  811: 886 */             strValue = "%" + strValue + "%";
/*  812:     */           }
/*  813: 888 */           this.logger.info(String.format("bind value for %s = %s", new Object[] { attributeName, strValue }));
/*  814: 889 */           ps.bindString(bindIndex, strValue);
/*  815: 890 */           bindIndex++;
/*  816:     */         }
/*  817:     */       }
/*  818:     */       else
/*  819:     */       {
/*  820: 893 */         String strValue = (String)qbeData.getInternalValue();
/*  821: 894 */         if (attributeInfo.getDataType() == 2) {
/*  822: 895 */           strValue = strValue.toUpperCase();
/*  823: 896 */         } else if (attributeInfo.getDataType() == 3) {
/*  824: 897 */           strValue = strValue.toLowerCase();
/*  825:     */         }
/*  826: 899 */         if (!qbe.isQbeExactMatch()) {
/*  827: 900 */           strValue = replaceStarWithPercent(strValue);
/*  828:     */         }
/*  829: 902 */         if ((!qbe.isQbeExactMatch()) && (qbeData.getCondition().length() == 0))
/*  830:     */         {
/*  831: 903 */           strValue = strValue.toUpperCase();
/*  832: 904 */           strValue = "%" + strValue + "%";
/*  833:     */         }
/*  834: 906 */         this.logger.info(String.format("bind value for %s = %s", new Object[] { attributeName, strValue }));
/*  835: 907 */         ps.bindString(bindIndex, strValue);
/*  836: 908 */         bindIndex++;
/*  837:     */       }
/*  838:     */     }
/*  839: 911 */     else if (attributeInfo.isBoolean())
/*  840:     */     {
/*  841: 912 */       long intValue = Integer.parseInt((String)qbeData.getInternalValue());
/*  842: 913 */       this.logger.info(String.format("bind value for %s = %d", new Object[] { attributeName, Long.valueOf(intValue) }));
/*  843: 914 */       ps.bindLong(bindIndex, Long.valueOf(intValue));
/*  844: 915 */       bindIndex++;
/*  845:     */     }
/*  846: 918 */     else if (attributeInfo.isInteger())
/*  847:     */     {
/*  848: 919 */       if (qbeData.hasMultipleValues())
/*  849:     */       {
/*  850: 920 */         String[] values = (String[])qbeData.getInternalValue();
/*  851: 921 */         for (int i = 0; i < values.length; i++)
/*  852:     */         {
/*  853: 922 */           String strValue = values[i];
/*  854: 923 */           long longValue = Long.parseLong(strValue);
/*  855: 924 */           this.logger.info(String.format("bind value for %s = %d", new Object[] { attributeName, Long.valueOf(longValue) }));
/*  856: 925 */           ps.bindLong(bindIndex, Long.valueOf(longValue));
/*  857: 926 */           bindIndex++;
/*  858:     */         }
/*  859:     */       }
/*  860:     */       else
/*  861:     */       {
/*  862: 929 */         long longValue = Long.parseLong((String)qbeData.getInternalValue());
/*  863: 930 */         this.logger.info(String.format("bind value for %s = %d", new Object[] { attributeName, Long.valueOf(longValue) }));
/*  864: 931 */         ps.bindLong(bindIndex, Long.valueOf(longValue));
/*  865: 932 */         bindIndex++;
/*  866:     */       }
/*  867:     */     }
/*  868: 935 */     else if (attributeInfo.isDecimal())
/*  869:     */     {
/*  870: 936 */       if (qbeData.hasMultipleValues())
/*  871:     */       {
/*  872: 937 */         String[] values = (String[])qbeData.getInternalValue();
/*  873: 938 */         for (int i = 0; i < values.length; i++)
/*  874:     */         {
/*  875: 939 */           String strValue = values[i];
/*  876: 940 */           this.logger.info(String.format("bind value for %s = %s", new Object[] { attributeName, strValue }));
/*  877: 941 */           ps.bindDouble(bindIndex, new Double(strValue));
/*  878: 942 */           bindIndex++;
/*  879:     */         }
/*  880:     */       }
/*  881:     */       else
/*  882:     */       {
/*  883: 945 */         String floatValue = (String)qbeData.getInternalValue();
/*  884: 946 */         this.logger.info(String.format("bind value for %s = %s", new Object[] { attributeName, floatValue }));
/*  885: 947 */         ps.bindDouble(bindIndex, new Double(floatValue));
/*  886: 948 */         bindIndex++;
/*  887:     */       }
/*  888:     */     }
/*  889: 951 */     else if ((attributeInfo.isDate()) || (attributeInfo.isTime()))
/*  890:     */     {
/*  891: 952 */       long longValue = qbe.getQBEData(attributeName).getInternalDateValue().getTime();
/*  892: 953 */       this.logger.info("bind value for " + attributeName + " = " + longValue + " (" + bindValue + ")");
/*  893: 954 */       ps.bindLong(bindIndex, Long.valueOf(longValue));
/*  894: 955 */       bindIndex++;
/*  895:     */     }
/*  896: 957 */     else if (attributeInfo.isDateTime())
/*  897:     */     {
/*  898: 958 */       String condition = qbeData.getCondition();
/*  899: 959 */       if ((condition == null) || (condition.length() == 0))
/*  900:     */       {
/*  901: 960 */         Object obj = qbe.getQBEData(attributeName).getInternalDateValue();
/*  902: 961 */         Date qbeDate = (Date)obj;
/*  903: 962 */         Calendar c1 = Calendar.getInstance();
/*  904: 963 */         c1.setTime(qbeDate);
/*  905: 964 */         c1.set(11, 0);
/*  906: 965 */         c1.set(12, 0);
/*  907: 966 */         c1.set(13, 0);
/*  908: 967 */         c1.set(14, 0);
/*  909:     */         
/*  910: 969 */         Calendar c2 = Calendar.getInstance();
/*  911: 970 */         c2.setTime(qbeDate);
/*  912: 971 */         c2.set(11, 23);
/*  913: 972 */         c2.set(12, 59);
/*  914: 973 */         c2.set(13, 59);
/*  915: 974 */         c2.set(14, 999);
/*  916: 975 */         long value1 = c1.getTime().getTime();
/*  917: 976 */         this.logger.info("bind value for " + attributeName + " = " + value1 + " (" + c1.getTime() + ")");
/*  918: 977 */         ps.bindLong(bindIndex, Long.valueOf(value1));
/*  919: 978 */         bindIndex++;
/*  920:     */         
/*  921: 980 */         long value2 = c2.getTime().getTime();
/*  922: 981 */         this.logger.info("bind value for " + attributeName + " = " + value2 + " (" + c2.getTime() + ")");
/*  923: 982 */         ps.bindLong(bindIndex, Long.valueOf(value2));
/*  924: 983 */         bindIndex++;
/*  925:     */       }
/*  926:     */       else
/*  927:     */       {
/*  928: 985 */         Object obj = qbe.getQBEData(attributeName).getInternalDateValue();
/*  929: 986 */         long value = ((Date)obj).getTime();
/*  930: 987 */         this.logger.info("bind value for " + attributeName + " = " + value + " (" + obj + ")");
/*  931: 988 */         ps.bindLong(bindIndex, Long.valueOf(value));
/*  932: 989 */         bindIndex++;
/*  933:     */       }
/*  934:     */     }
/*  935: 992 */     else if (attributeInfo.isBinary())
/*  936:     */     {
/*  937: 993 */       this.logger.warn("Binary filter is not supported", new RuntimeException());
/*  938:     */     }
/*  939:     */     else
/*  940:     */     {
/*  941: 996 */       this.logger.warn("QBE filter is not supported", new RuntimeException());
/*  942:     */     }
/*  943: 999 */     return bindIndex;
/*  944:     */   }
/*  945:     */   
/*  946:     */   public boolean isDependentQBEAttribute(String attributeName)
/*  947:     */   {
/*  948:1003 */     return attributeName.indexOf(".") > 0;
/*  949:     */   }
/*  950:     */   
/*  951:     */   public Collection<SQLiteQBEDependentInfo> getDependentQBEData(QBE qbe)
/*  952:     */     throws RDOException
/*  953:     */   {
/*  954:1007 */     HashMap<String, SQLiteQBEDependentInfo> cache = new HashMap();
/*  955:1008 */     if (qbe != null)
/*  956:     */     {
/*  957:1009 */       Enumeration<?> qbeAttrEnum = qbe.getQBEAttributes();
/*  958:1010 */       while (qbeAttrEnum.hasMoreElements())
/*  959:     */       {
/*  960:1011 */         String qbeAttribute = (String)qbeAttrEnum.nextElement();
/*  961:1012 */         if (isDependentQBEAttribute(qbeAttribute))
/*  962:     */         {
/*  963:1013 */           int index = qbeAttribute.indexOf(".");
/*  964:1014 */           if (index > 0)
/*  965:     */           {
/*  966:1015 */             String dependentName = qbeAttribute.substring(0, index);
/*  967:1016 */             String dependentAttrName = qbeAttribute.substring(index + 1);
/*  968:1017 */             SQLiteQBEDependentInfo info = (SQLiteQBEDependentInfo)cache.get(dependentName);
/*  969:1018 */             if (info == null) {
/*  970:1019 */               info = new SQLiteQBEDependentInfo(dependentName, new String[] { dependentAttrName });
/*  971:     */             } else {
/*  972:1022 */               info.addAttribute(dependentAttrName);
/*  973:     */             }
/*  974:1024 */             cache.put(dependentName, info);
/*  975:     */           }
/*  976:     */         }
/*  977:     */       }
/*  978:     */     }
/*  979:1029 */     return cache.values();
/*  980:     */   }
/*  981:     */   
/*  982:     */   public String buildWhereFromParentKeyList(RDOInfo depInfo, ArrayList<ConditionValue> parentKeyList)
/*  983:     */   {
/*  984:1033 */     StringBuilder buf = new StringBuilder();
/*  985:1034 */     RDODependentRelation depRelation = depInfo.getDependentRelation();
/*  986:1035 */     int noOfConditions = depRelation.size();
/*  987:1036 */     String[] parentConditions = new String[noOfConditions];
/*  988:1037 */     String[] childConditions = new String[noOfConditions];
/*  989:1038 */     for (int i = 0; i < noOfConditions; i++)
/*  990:     */     {
/*  991:1039 */       String[] condition = depRelation.getCondition(i);
/*  992:1040 */       parentConditions[i] = condition[0];
/*  993:1041 */       childConditions[i] = condition[1];
/*  994:     */     }
/*  995:1043 */     int i = 0;
/*  996:1044 */     for (ConditionValue conditionValue : parentKeyList)
/*  997:     */     {
/*  998:1045 */       if (i > 0) {
/*  999:1046 */         buf.append(" OR ");
/* 1000:     */       }
/* 1001:1048 */       buf.append("(");
/* 1002:1049 */       Object[] values = conditionValue.getValues();
/* 1003:1051 */       for (int j = 0; j < parentConditions.length; j++)
/* 1004:     */       {
/* 1005:1052 */         if (j > 0) {
/* 1006:1053 */           buf.append(" AND ");
/* 1007:     */         }
/* 1008:1055 */         buf.append(parentConditions[j]);
/* 1009:1056 */         buf.append("=");
/* 1010:1057 */         if (depInfo.getAttributeInfo(childConditions[j]).isAlphaNumeric()) {
/* 1011:1058 */           buf.append("'" + values[j] + "'");
/* 1012:     */         } else {
/* 1013:1060 */           buf.append(values[j]);
/* 1014:     */         }
/* 1015:     */       }
/* 1016:1063 */       buf.append(")");
/* 1017:1064 */       i++;
/* 1018:     */     }
/* 1019:1066 */     if (i > 0) {
/* 1020:1067 */       return "(" + buf.toString() + ")";
/* 1021:     */     }
/* 1022:1069 */     return buf.toString();
/* 1023:     */   }
/* 1024:     */   
/* 1025:     */   public String buildWhereFromParentIdList(List<Long> parentIdList)
/* 1026:     */   {
/* 1027:1073 */     StringBuilder buf = new StringBuilder();
/* 1028:1074 */     for (Long parentId : parentIdList)
/* 1029:     */     {
/* 1030:1075 */       buf.append(parentId);
/* 1031:1076 */       buf.append(",");
/* 1032:     */     }
/* 1033:1078 */     removeExtraChars(buf, ",");
/* 1034:1079 */     return formatName("_ID") + " IN (" + buf.toString() + ")";
/* 1035:     */   }
/* 1036:     */   
/* 1037:     */   public ArrayList<ConditionValue> buildConditionValueList(RDOInfo depInfo, Cursor cursor)
/* 1038:     */   {
/* 1039:1084 */     ArrayList<ConditionValue> parentKeys = new ArrayList();
/* 1040:1085 */     RDODependentRelation depRelation = depInfo.getDependentRelation();
/* 1041:1086 */     int noOfConditions = depRelation.size();
/* 1042:1087 */     String[] parentConditions = new String[noOfConditions];
/* 1043:1088 */     String[] childConditions = new String[noOfConditions];
/* 1044:1089 */     for (int i = 0; i < noOfConditions; i++)
/* 1045:     */     {
/* 1046:1090 */       String[] condition = depRelation.getCondition(i);
/* 1047:1091 */       parentConditions[i] = condition[0];
/* 1048:1092 */       childConditions[i] = condition[1];
/* 1049:     */     }
/* 1050:1094 */     int attributeIndex = 0;
/* 1051:1095 */     for (; cursor.moveToNext(); goto 105)
/* 1052:     */     {
/* 1053:1096 */       boolean valueNull = false;
/* 1054:1097 */       Object[] conditionValues = new Object[noOfConditions];
/* 1055:1098 */       int i = 0;
/* 1056:1098 */       if ((i < noOfConditions) && (!valueNull))
/* 1057:     */       {
/* 1058:1099 */         RDOAttributeInfo attrInfo = depInfo.getAttributeInfo(childConditions[i]);
/* 1059:1100 */         attributeIndex = cursor.getColumnIndex(childConditions[i]);
/* 1060:1101 */         if (attributeIndex < 0) {
/* 1061:1102 */           this.logger.warn("Could not find index for column " + childConditions[i] + " when building condition values for object " + depInfo.getName());
/* 1062:1104 */         } else if (attrInfo.isAlphaNumeric())
/* 1063:     */         {
/* 1064:1105 */           if (cursor.isNull(attributeIndex)) {
/* 1065:1106 */             valueNull = true;
/* 1066:     */           } else {
/* 1067:1108 */             conditionValues[i] = cursor.getString(attributeIndex);
/* 1068:     */           }
/* 1069:     */         }
/* 1070:1111 */         else if (attrInfo.isInteger())
/* 1071:     */         {
/* 1072:1112 */           if (cursor.isNull(attributeIndex)) {
/* 1073:1113 */             valueNull = true;
/* 1074:     */           } else {
/* 1075:1115 */             conditionValues[i] = Long.valueOf(cursor.getLong(attributeIndex));
/* 1076:     */           }
/* 1077:     */         }
/* 1078:1118 */         else if (attrInfo.isDecimal())
/* 1079:     */         {
/* 1080:1119 */           if (cursor.isNull(attributeIndex)) {
/* 1081:1120 */             valueNull = true;
/* 1082:     */           } else {
/* 1083:1122 */             conditionValues[i] = Double.valueOf(cursor.getDouble(attributeIndex));
/* 1084:     */           }
/* 1085:     */         }
/* 1086:1125 */         else if (attrInfo.isBoolean()) {
/* 1087:1126 */           if (cursor.isNull(attributeIndex)) {
/* 1088:1127 */             valueNull = true;
/* 1089:     */           } else {
/* 1090:1129 */             conditionValues[i] = Integer.valueOf(cursor.getInt(attributeIndex));
/* 1091:     */           }
/* 1092:     */         }
/* 1093:1133 */         if (!valueNull) {
/* 1094:1134 */           parentKeys.add(new ConditionValue(conditionValues));
/* 1095:     */         }
/* 1096:1098 */         i++;
/* 1097:     */       }
/* 1098:     */     }
/* 1099:1138 */     return parentKeys;
/* 1100:     */   }
/* 1101:     */   
/* 1102:     */   public ArrayList<Long> buildParentIdList(Cursor cursor)
/* 1103:     */   {
/* 1104:1142 */     ArrayList<Long> result = new ArrayList();
/* 1105:1143 */     while (cursor.moveToNext()) {
/* 1106:1144 */       result.add(Long.valueOf(cursor.getLong(0)));
/* 1107:     */     }
/* 1108:1146 */     return result;
/* 1109:     */   }
/* 1110:     */   
/* 1111:     */   public String buildComplexQueryStatement(RDOInfo info, QBE filter, MobileWhereClause whereClause, Order order, SQLiteDBRDOManager rdoManager)
/* 1112:     */     throws RDOException
/* 1113:     */   {
/* 1114:1151 */     StringBuilder query = new StringBuilder();
/* 1115:1152 */     query.append("SELECT * FROM ");
/* 1116:1153 */     query.append(formatName(info.getName()));
/* 1117:1154 */     String qbeWhere = getQBEWhere(info, filter, rdoManager);
/* 1118:1155 */     boolean whereAdded = false;
/* 1119:1157 */     if (info.isHierarchical())
/* 1120:     */     {
/* 1121:1158 */       query.append(formatName("_OWNERID"));
/* 1122:1159 */       query.append(" = ?");
/* 1123:1160 */       if (qbeWhere.length() > 0)
/* 1124:     */       {
/* 1125:1161 */         query.append(" AND ");
/* 1126:1162 */         query.append(qbeWhere);
/* 1127:     */       }
/* 1128:1164 */       whereAdded = true;
/* 1129:     */     }
/* 1130:1166 */     else if (qbeWhere.length() > 0)
/* 1131:     */     {
/* 1132:1167 */       query.append(" WHERE ");
/* 1133:1168 */       query.append(qbeWhere);
/* 1134:1169 */       whereAdded = true;
/* 1135:     */     }
/* 1136:1173 */     if (whereClause != null)
/* 1137:     */     {
/* 1138:1174 */       if (!whereAdded) {
/* 1139:1175 */         query.append(" WHERE ");
/* 1140:     */       } else {
/* 1141:1177 */         query.append(" AND ");
/* 1142:     */       }
/* 1143:1179 */       query.append("(");
/* 1144:1180 */       query.append(whereClause.getConvertedWhere(this.resolver));
/* 1145:1181 */       query.append(")");
/* 1146:     */     }
/* 1147:1184 */     String orderClause = getOrderClause(order);
/* 1148:1185 */     if (orderClause.length() > 0)
/* 1149:     */     {
/* 1150:1186 */       query.append(" ORDER BY ");
/* 1151:1187 */       query.append(orderClause);
/* 1152:     */     }
/* 1153:1189 */     return query.toString();
/* 1154:     */   }
/* 1155:     */   
/* 1156:     */   public String buildComplexDependentCountQueryStatement(RDOInfo info, RDOInfo parentInfo, RDODependentRelation dependentRelation, RDO parentRDO, QBE filter, MobileWhereClause whereClause, SQLiteDBRDOManager rdoManager)
/* 1157:     */     throws RDOException
/* 1158:     */   {
/* 1159:1193 */     boolean fetchChildrenInHierarchy = false;
/* 1160:1194 */     if (parentInfo.isHierarchical()) {
/* 1161:1195 */       fetchChildrenInHierarchy = true;
/* 1162:     */     }
/* 1163:1197 */     StringBuilder builder = new StringBuilder("SELECT COUNT(*) FROM ");
/* 1164:1198 */     builder.append(formatName(info.getName()));
/* 1165:1199 */     String qbeWhere = getQBEWhere(info, filter, rdoManager);
/* 1166:1201 */     if (fetchChildrenInHierarchy)
/* 1167:     */     {
/* 1168:1202 */       builder.append(" WHERE ");
/* 1169:1203 */       builder.append(formatName("_OWNERID"));
/* 1170:1204 */       builder.append(" = ?");
/* 1171:1205 */       if (qbeWhere.length() > 0)
/* 1172:     */       {
/* 1173:1206 */         builder.append(" AND ");
/* 1174:1207 */         builder.append(qbeWhere);
/* 1175:     */       }
/* 1176:     */     }
/* 1177:1210 */     else if (dependentRelation == null)
/* 1178:     */     {
/* 1179:1211 */       builder.append(" WHERE ");
/* 1180:1212 */       builder.append(formatName("_PARENTID"));
/* 1181:1213 */       builder.append(" = ?");
/* 1182:1214 */       if (qbeWhere.length() > 0)
/* 1183:     */       {
/* 1184:1215 */         builder.append(" AND ");
/* 1185:1216 */         builder.append(qbeWhere);
/* 1186:     */       }
/* 1187:     */     }
/* 1188:     */     else
/* 1189:     */     {
/* 1190:1219 */       String dependentRelationWhere = getDependentRelationWhere(info, parentInfo, dependentRelation, parentRDO);
/* 1191:1220 */       if (dependentRelationWhere.trim().length() > 0)
/* 1192:     */       {
/* 1193:1221 */         builder.append(" WHERE ");
/* 1194:1222 */         builder.append(dependentRelationWhere);
/* 1195:1223 */         if (qbeWhere.length() > 0)
/* 1196:     */         {
/* 1197:1224 */           builder.append(" AND ");
/* 1198:1225 */           builder.append(qbeWhere);
/* 1199:     */         }
/* 1200:     */       }
/* 1201:     */     }
/* 1202:1231 */     String additionalWhere = null;
/* 1203:1232 */     if (whereClause != null) {
/* 1204:1233 */       additionalWhere = whereClause.getConvertedWhere(this.resolver);
/* 1205:     */     }
/* 1206:1236 */     if ((additionalWhere != null) && (additionalWhere.length() > 0))
/* 1207:     */     {
/* 1208:1237 */       builder.append(" AND (");
/* 1209:1238 */       builder.append(additionalWhere);
/* 1210:1239 */       builder.append(")");
/* 1211:     */     }
/* 1212:1241 */     return builder.toString();
/* 1213:     */   }
/* 1214:     */   
/* 1215:     */   private String getDependentRelationWhere(RDOInfo dependentInfo, RDOInfo parentInfo, RDODependentRelation dependentRelation, RDO parentRDO)
/* 1216:     */   {
/* 1217:1245 */     StringBuffer relationWhere = new StringBuffer();
/* 1218:1246 */     int noOfConditions = dependentRelation.size();
/* 1219:1247 */     for (int i = 0; i < noOfConditions; i++)
/* 1220:     */     {
/* 1221:1248 */       String[] condition = dependentRelation.getCondition(i);
/* 1222:1249 */       String childAttr = condition[1];
/* 1223:1250 */       if (i > 0) {
/* 1224:1251 */         relationWhere.append(" AND ");
/* 1225:     */       }
/* 1226:1253 */       relationWhere.append(childAttr);
/* 1227:1254 */       relationWhere.append(" = ");
/* 1228:1255 */       relationWhere.append("?");
/* 1229:     */     }
/* 1230:1258 */     return relationWhere.toString();
/* 1231:     */   }
/* 1232:     */   
/* 1233:     */   public int bindDependentRelation(RDODependentRelation dependentRelation, RDO parentRDO, SQLiteCustomQueryStatement statement, int bindIndex)
/* 1234:     */     throws RDOException
/* 1235:     */   {
/* 1236:1263 */     int noOfConditions = dependentRelation.size();
/* 1237:1264 */     for (int i = 0; i < noOfConditions; i++)
/* 1238:     */     {
/* 1239:1265 */       String[] condition = dependentRelation.getCondition(i);
/* 1240:1266 */       String value = parentRDO.getStringValue(condition[0]);
/* 1241:1267 */       this.logger.info(String.format("bind value for %s = %s", new Object[] { condition[1], value }));
/* 1242:1268 */       statement.bindString(bindIndex, value);
/* 1243:1269 */       bindIndex++;
/* 1244:     */     }
/* 1245:1271 */     return bindIndex;
/* 1246:     */   }
/* 1247:     */   
/* 1248:     */   public String buildComplexCountQueryStatement(RDOInfo info, QBE filter, MobileWhereClause whereClause, SQLiteDBRDOManager rdoManager)
/* 1249:     */     throws RDOException
/* 1250:     */   {
/* 1251:1275 */     StringBuilder query = new StringBuilder("SELECT COUNT(*) FROM ");
/* 1252:1276 */     query.append(formatName(info.getName()));
/* 1253:1277 */     boolean whereAdded = false;
/* 1254:1278 */     if (info.isHierarchical())
/* 1255:     */     {
/* 1256:1279 */       query.append(" WHERE ");
/* 1257:1280 */       query.append(formatName("_OWNERID") + " = 0");
/* 1258:1281 */       whereAdded = true;
/* 1259:     */     }
/* 1260:1283 */     if (filter != null)
/* 1261:     */     {
/* 1262:1284 */       String qbeWhere = getQBEWhere(info, filter, rdoManager);
/* 1263:1285 */       if (qbeWhere.length() > 0)
/* 1264:     */       {
/* 1265:1286 */         if (whereAdded)
/* 1266:     */         {
/* 1267:1287 */           query.append(" AND ");
/* 1268:     */         }
/* 1269:     */         else
/* 1270:     */         {
/* 1271:1289 */           query.append(" WHERE ");
/* 1272:1290 */           whereAdded = true;
/* 1273:     */         }
/* 1274:1292 */         query.append(qbeWhere);
/* 1275:     */       }
/* 1276:     */     }
/* 1277:1295 */     if (whereClause != null)
/* 1278:     */     {
/* 1279:1297 */       String additionalWhere = whereClause.getConvertedWhere(this.resolver);
/* 1280:1298 */       if (whereAdded)
/* 1281:     */       {
/* 1282:1299 */         query.append(" AND ");
/* 1283:     */       }
/* 1284:     */       else
/* 1285:     */       {
/* 1286:1301 */         query.append(" WHERE ");
/* 1287:1302 */         whereAdded = true;
/* 1288:     */       }
/* 1289:1304 */       query.append("(" + additionalWhere + ")");
/* 1290:     */     }
/* 1291:1306 */     return query.toString();
/* 1292:     */   }
/* 1293:     */   
/* 1294:     */   public int applyQBEBindings(RDOInfo info, QBE qbe, SQLiteCustomQueryStatement statement, int startBindIndex)
/* 1295:     */     throws RDOException
/* 1296:     */   {
/* 1297:1310 */     if (qbe != null)
/* 1298:     */     {
/* 1299:1311 */       Enumeration<?> qbeAttrEnum = qbe.getQBEAttributes();
/* 1300:1312 */       while (qbeAttrEnum.hasMoreElements())
/* 1301:     */       {
/* 1302:1313 */         String qbeAttrName = (String)qbeAttrEnum.nextElement();
/* 1303:1314 */         if (!isDependentQBEAttribute(qbeAttrName))
/* 1304:     */         {
/* 1305:1315 */           String qbeValue = qbe.getQBE(qbeAttrName);
/* 1306:1316 */           if (!qbe.getQBEData(qbeAttrName).isNullValueCheck()) {
/* 1307:1317 */             startBindIndex = setQBEBinding(info.getAttributeInfo(qbeAttrName), qbe.getQBEData(qbeAttrName), statement, startBindIndex, qbeValue, qbe);
/* 1308:     */           }
/* 1309:     */         }
/* 1310:     */       }
/* 1311:     */     }
/* 1312:1322 */     return startBindIndex;
/* 1313:     */   }
/* 1314:     */   
/* 1315:     */   public String buildComplexDependentQueryStatement(RDOInfo info, RDOInfo parentInfo, RDODependentRelation dependentRelation, RDO parentRDO, QBE filter, MobileWhereClause whereClause, Order order, SQLiteDBRDOManager rdoManager)
/* 1316:     */     throws RDOException
/* 1317:     */   {
/* 1318:1327 */     boolean fetchChildrenInHierarchy = false;
/* 1319:1328 */     if (parentInfo.isHierarchical()) {
/* 1320:1329 */       fetchChildrenInHierarchy = true;
/* 1321:     */     }
/* 1322:1331 */     StringBuilder builder = new StringBuilder("SELECT * FROM ");
/* 1323:1332 */     builder.append(formatName(info.getName()));
/* 1324:1333 */     String qbeWhere = getQBEWhere(info, filter, rdoManager);
/* 1325:1335 */     if (fetchChildrenInHierarchy)
/* 1326:     */     {
/* 1327:1336 */       builder.append(" WHERE ");
/* 1328:1337 */       builder.append(formatName("_OWNERID"));
/* 1329:1338 */       builder.append(" = ?");
/* 1330:1339 */       if (qbeWhere.length() > 0)
/* 1331:     */       {
/* 1332:1340 */         builder.append(" AND ");
/* 1333:1341 */         builder.append(qbeWhere);
/* 1334:     */       }
/* 1335:     */     }
/* 1336:1344 */     else if (dependentRelation == null)
/* 1337:     */     {
/* 1338:1345 */       builder.append(" WHERE ");
/* 1339:1346 */       builder.append(formatName("_PARENTID"));
/* 1340:1347 */       builder.append(" = ?");
/* 1341:1348 */       if (qbeWhere.length() > 0)
/* 1342:     */       {
/* 1343:1349 */         builder.append(" AND ");
/* 1344:1350 */         builder.append(qbeWhere);
/* 1345:     */       }
/* 1346:     */     }
/* 1347:     */     else
/* 1348:     */     {
/* 1349:1353 */       String dependentRelationWhere = getDependentRelationWhere(info, parentInfo, dependentRelation, parentRDO);
/* 1350:1354 */       if (dependentRelationWhere.trim().length() > 0)
/* 1351:     */       {
/* 1352:1355 */         builder.append(" WHERE ");
/* 1353:1356 */         builder.append(dependentRelationWhere);
/* 1354:1357 */         if (qbeWhere.length() > 0)
/* 1355:     */         {
/* 1356:1358 */           builder.append(" AND ");
/* 1357:1359 */           builder.append(qbeWhere);
/* 1358:     */         }
/* 1359:     */       }
/* 1360:     */     }
/* 1361:1365 */     String additionalWhere = null;
/* 1362:1366 */     if (whereClause != null) {
/* 1363:1367 */       additionalWhere = whereClause.getConvertedWhere(this.resolver);
/* 1364:     */     }
/* 1365:1370 */     if ((additionalWhere != null) && (additionalWhere.length() > 0))
/* 1366:     */     {
/* 1367:1371 */       builder.append(" AND (");
/* 1368:1372 */       builder.append(additionalWhere);
/* 1369:1373 */       builder.append(")");
/* 1370:     */     }
/* 1371:1376 */     String orderClause = getOrderClause(order);
/* 1372:1377 */     if (orderClause.length() > 0)
/* 1373:     */     {
/* 1374:1378 */       builder.append(" ORDER BY ");
/* 1375:1379 */       builder.append(orderClause);
/* 1376:     */     }
/* 1377:1382 */     return builder.toString();
/* 1378:     */   }
/* 1379:     */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.ibm.tivoli.maximo.mobile.android.persist.sqlite.SQLiteDBRDOManagerHelper
 * JD-Core Version:    0.7.0.1
 */