/*   1:    */ package com.ibm.tivoli.maximo.mobile.android.persist.sqlite;
/*   2:    */ 
/*   3:    */ import android.database.Cursor;
/*   4:    */ import com.mro.mobile.persist.DefaultRDO;
/*   5:    */ import com.mro.mobile.persist.RDO;
/*   6:    */ import com.mro.mobile.persist.RDOAttributeInfo;
/*   7:    */ import com.mro.mobile.persist.RDOEnumeration;
/*   8:    */ import com.mro.mobile.persist.RDOInfo;
/*   9:    */ import com.mro.mobile.util.MobileLogger;
/*  10:    */ import java.util.Calendar;
/*  11:    */ 
/*  12:    */ public class SQLiteRDOEnumeration
/*  13:    */   implements RDOEnumeration
/*  14:    */ {
/*  15:    */   private Cursor cursor;
/*  16:    */   private RDOInfo rdoInfo;
/*  17:    */   private boolean moreElementsCalled;
/*  18:    */   private boolean moreElementsExist;
/*  19:    */   private String appName;
/*  20:    */   private MobileLogger logger;
/*  21:    */   
/*  22:    */   SQLiteRDOEnumeration(String appName, RDOInfo info, Cursor cursor, MobileLogger logger)
/*  23:    */   {
/*  24: 25 */     if (info == null) {
/*  25: 26 */       throw new IllegalArgumentException("RDOInfo must not be null");
/*  26:    */     }
/*  27: 28 */     if (cursor == null) {
/*  28: 29 */       throw new IllegalArgumentException("Cursor must not be null");
/*  29:    */     }
/*  30: 31 */     if (appName == null) {
/*  31: 32 */       throw new IllegalArgumentException("Application must not be null");
/*  32:    */     }
/*  33: 34 */     if (logger == null) {
/*  34: 35 */       throw new IllegalArgumentException("logger must not be null");
/*  35:    */     }
/*  36: 37 */     this.rdoInfo = info;
/*  37: 38 */     this.cursor = cursor;
/*  38: 39 */     this.appName = appName;
/*  39: 40 */     this.logger = logger;
/*  40:    */   }
/*  41:    */   
/*  42:    */   public boolean hasMoreElements()
/*  43:    */   {
/*  44: 45 */     if (!this.moreElementsCalled) {
/*  45: 46 */       if (resultExists())
/*  46:    */       {
/*  47: 47 */         this.moreElementsCalled = true;
/*  48: 48 */         this.moreElementsExist = true;
/*  49:    */       }
/*  50:    */       else
/*  51:    */       {
/*  52: 51 */         this.moreElementsCalled = true;
/*  53: 52 */         this.moreElementsExist = false;
/*  54: 53 */         release();
/*  55:    */       }
/*  56:    */     }
/*  57: 56 */     return this.moreElementsExist;
/*  58:    */   }
/*  59:    */   
/*  60:    */   boolean resultExists()
/*  61:    */   {
/*  62: 61 */     boolean result = (this.cursor != null) && (!this.cursor.isClosed()) && (!this.cursor.isLast()) && (this.cursor.getCount() > 0);
/*  63: 62 */     return result;
/*  64:    */   }
/*  65:    */   
/*  66:    */   public RDO nextElement()
/*  67:    */   {
/*  68: 67 */     RDO rdo = null;
/*  69: 68 */     if (this.moreElementsCalled)
/*  70:    */     {
/*  71: 69 */       this.moreElementsCalled = false;
/*  72: 70 */       this.moreElementsExist = false;
/*  73:    */     }
/*  74: 72 */     if ((!isReleased()) && (this.cursor.moveToNext()))
/*  75:    */     {
/*  76: 73 */       rdo = buildRDO(this.cursor);
/*  77:    */     }
/*  78:    */     else
/*  79:    */     {
/*  80: 75 */       this.moreElementsCalled = true;
/*  81: 76 */       this.moreElementsExist = false;
/*  82: 77 */       release();
/*  83:    */     }
/*  84: 79 */     return rdo;
/*  85:    */   }
/*  86:    */   
/*  87:    */   public void release()
/*  88:    */   {
/*  89: 84 */     SQLiteUtil.safelyCloseCursor(this.cursor, this.logger);
/*  90: 85 */     this.cursor = null;
/*  91:    */   }
/*  92:    */   
/*  93:    */   public boolean isReleased()
/*  94:    */   {
/*  95: 89 */     return (this.cursor == null) || (this.cursor.isClosed());
/*  96:    */   }
/*  97:    */   
/*  98:    */   protected RDO buildRDO(Cursor current)
/*  99:    */   {
/* 100: 93 */     DefaultRDO rdo = new DefaultRDO(this.appName, true);
/* 101: 94 */     rdo.setName(this.rdoInfo.getName());
/* 102:    */     try
/* 103:    */     {
/* 104: 96 */       for (String name : this.rdoInfo.getAttributeNames())
/* 105:    */       {
/* 106: 97 */         RDOAttributeInfo attrInfo = this.rdoInfo.getAttributeInfo(name);
/* 107: 98 */         if (attrInfo.isPersistent())
/* 108:    */         {
/* 109: 99 */           int index = this.cursor.getColumnIndex(name);
/* 110:100 */           if (index < 0) {
/* 111:101 */             throw new RuntimeException(String.format("Index not found for attribute %s.%s", new Object[] { this.rdoInfo.getName(), name }));
/* 112:    */           }
/* 113:103 */           int dataType = attrInfo.getDataType();
/* 114:104 */           switch (dataType)
/* 115:    */           {
/* 116:    */           case 1: 
/* 117:    */           case 2: 
/* 118:    */           case 3: 
/* 119:108 */             rdo.setStringValue(name, this.cursor.getString(index));
/* 120:109 */             break;
/* 121:    */           case 4: 
/* 122:111 */             if (!this.cursor.isNull(index)) {
/* 123:112 */               rdo.setIntValue(name, this.cursor.getInt(index));
/* 124:    */             }
/* 125:    */             break;
/* 126:    */           case 5: 
/* 127:116 */             if (!this.cursor.isNull(index)) {
/* 128:117 */               rdo.setLongValue(name, this.cursor.getLong(index));
/* 129:    */             }
/* 130:    */             break;
/* 131:    */           case 6: 
/* 132:121 */             if (!this.cursor.isNull(index)) {
/* 133:122 */               rdo.setFloatValue(name, this.cursor.getFloat(index));
/* 134:    */             }
/* 135:    */             break;
/* 136:    */           case 7: 
/* 137:126 */             if (!this.cursor.isNull(index)) {
/* 138:127 */               rdo.setDoubleValue(name, this.cursor.getDouble(index));
/* 139:    */             }
/* 140:    */             break;
/* 141:    */           case 8: 
/* 142:131 */             rdo.setBooleanValue(name, this.cursor.getInt(index) == 1);
/* 143:132 */             break;
/* 144:    */           case 9: 
/* 145:134 */             if (!this.cursor.isNull(index))
/* 146:    */             {
/* 147:135 */               Calendar c = Calendar.getInstance();
/* 148:136 */               c.setTimeInMillis(this.cursor.getLong(index));
/* 149:137 */               rdo.setDateValue(name, c.getTime());
/* 150:    */             }
/* 151:138 */             break;
/* 152:    */           case 10: 
/* 153:141 */             if (!this.cursor.isNull(index))
/* 154:    */             {
/* 155:142 */               Calendar c = Calendar.getInstance();
/* 156:143 */               c.setTimeInMillis(this.cursor.getLong(index));
/* 157:144 */               rdo.setDateValue(name, c.getTime());
/* 158:    */             }
/* 159:145 */             break;
/* 160:    */           case 11: 
/* 161:148 */             if (!this.cursor.isNull(index))
/* 162:    */             {
/* 163:149 */               Calendar c = Calendar.getInstance();
/* 164:150 */               c.setTimeInMillis(this.cursor.getLong(index));
/* 165:151 */               rdo.setDateValue(name, c.getTime());
/* 166:    */             }
/* 167:152 */             break;
/* 168:    */           case 12: 
/* 169:155 */             rdo.setBinaryValue(name, this.cursor.getBlob(index));
/* 170:156 */             break;
/* 171:    */           default: 
/* 172:158 */             rdo.setStringValue(name, this.cursor.getString(index));
/* 173:    */           }
/* 174:    */         }
/* 175:    */       }
/* 176:163 */       return rdo;
/* 177:    */     }
/* 178:    */     catch (Exception e)
/* 179:    */     {
/* 180:165 */       this.logger.error(e.getMessage(), e);
/* 181:    */     }
/* 182:166 */     return null;
/* 183:    */   }
/* 184:    */   
/* 185:    */   public int count()
/* 186:    */   {
/* 187:171 */     if (this.cursor == null) {
/* 188:171 */       return -1;
/* 189:    */     }
/* 190:172 */     return this.cursor.getCount();
/* 191:    */   }
/* 192:    */   
/* 193:    */   public RDO getRDO(int position)
/* 194:    */   {
/* 195:176 */     int currentPos = this.cursor.getPosition();
/* 196:177 */     this.cursor.moveToPosition(position);
/* 197:178 */     RDO rdo = buildRDO(this.cursor);
/* 198:179 */     this.cursor.moveToPosition(currentPos);
/* 199:180 */     return rdo;
/* 200:    */   }
/* 201:    */   
/* 202:    */   public Cursor getCursor()
/* 203:    */   {
/* 204:184 */     return this.cursor;
/* 205:    */   }
/* 206:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.ibm.tivoli.maximo.mobile.android.persist.sqlite.SQLiteRDOEnumeration
 * JD-Core Version:    0.7.0.1
 */