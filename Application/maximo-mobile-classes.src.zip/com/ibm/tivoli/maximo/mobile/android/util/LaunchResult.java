/*  1:   */ package com.ibm.tivoli.maximo.mobile.android.util;
/*  2:   */ 
/*  3:   */ public class LaunchResult
/*  4:   */ {
/*  5:   */   private Exception error;
/*  6:   */   
/*  7:   */   public LaunchResult()
/*  8:   */   {
/*  9:22 */     this(null);
/* 10:   */   }
/* 11:   */   
/* 12:   */   public LaunchResult(Exception error)
/* 13:   */   {
/* 14:26 */     this.error = error;
/* 15:   */   }
/* 16:   */   
/* 17:   */   public boolean successful()
/* 18:   */   {
/* 19:30 */     return this.error == null;
/* 20:   */   }
/* 21:   */   
/* 22:   */   public boolean failed()
/* 23:   */   {
/* 24:34 */     return !successful();
/* 25:   */   }
/* 26:   */   
/* 27:   */   public Exception getErrorIfFailedOrNull()
/* 28:   */   {
/* 29:38 */     return this.error;
/* 30:   */   }
/* 31:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.ibm.tivoli.maximo.mobile.android.util.LaunchResult
 * JD-Core Version:    0.7.0.1
 */