/*  1:   */ package com.ibm.tivoli.maximo.mobile.android.persist.sqlite;
/*  2:   */ 
/*  3:   */ import com.mro.mobile.persist.sql.DefaultMobileWhereClauseVariableResolver;
/*  4:   */ 
/*  5:   */ public class SQLiteMobileWhereClauseVariableResolver
/*  6:   */   extends DefaultMobileWhereClauseVariableResolver
/*  7:   */ {
/*  8:   */   public String getValueForDate()
/*  9:   */   {
/* 10: 9 */     return "DATE('NOW')";
/* 11:   */   }
/* 12:   */   
/* 13:   */   public String getValueForDateTime()
/* 14:   */   {
/* 15:14 */     return "DATETIME('NOW')";
/* 16:   */   }
/* 17:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.ibm.tivoli.maximo.mobile.android.persist.sqlite.SQLiteMobileWhereClauseVariableResolver
 * JD-Core Version:    0.7.0.1
 */