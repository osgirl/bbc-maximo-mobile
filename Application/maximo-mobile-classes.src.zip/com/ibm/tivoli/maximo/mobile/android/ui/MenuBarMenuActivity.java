/*  1:   */ package com.ibm.tivoli.maximo.mobile.android.ui;
/*  2:   */ 
/*  3:   */ import android.app.Activity;
/*  4:   */ import android.content.Intent;
/*  5:   */ import android.os.Bundle;
/*  6:   */ import android.widget.BaseAdapter;
/*  7:   */ import com.ibm.tivoli.maximo.mobile.android.widget.NMenuAdapter;
/*  8:   */ import com.mro.mobile.ui.res.UIUtil;
/*  9:   */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/* 10:   */ import com.mro.mobile.ui.res.controls.MenuBarControl;
/* 11:   */ import com.mro.mobile.ui.res.controls.MenuControl;
/* 12:   */ import com.mro.mobile.ui.res.widgets.android.ADMenuWidgetImpl;
/* 13:   */ import java.util.Iterator;
/* 14:   */ 
/* 15:   */ public class MenuBarMenuActivity
/* 16:   */   extends NMenuActivity
/* 17:   */ {
/* 18:   */   public static Intent gotoThisActivity(Activity context, MenuControl menuControl)
/* 19:   */   {
/* 20:35 */     Intent intent = new Intent(context, MenuBarMenuActivity.class);
/* 21:36 */     intent.putExtra("menucontrolid", menuControl.getId());
/* 22:37 */     return intent;
/* 23:   */   }
/* 24:   */   
/* 25:40 */   private MenuControl menuControl = null;
/* 26:   */   
/* 27:   */   protected BaseAdapter createListAdapter()
/* 28:   */   {
/* 29:43 */     String menuControlId = getIntent().getExtras().getString("menucontrolid");
/* 30:   */     
/* 31:45 */     MenuBarControl menuBarCtrl = (MenuBarControl)UIUtil.getCurrentScreen().getMenuBar();
/* 32:46 */     Iterator<AbstractMobileControl> firstLevelMenus = menuBarCtrl.getChildren();
/* 33:49 */     while (firstLevelMenus.hasNext())
/* 34:   */     {
/* 35:50 */       AbstractMobileControl currentMenu = (AbstractMobileControl)firstLevelMenus.next();
/* 36:52 */       if ((currentMenu instanceof MenuControl))
/* 37:   */       {
/* 38:54 */         this.menuControl = ((MenuControl)currentMenu);
/* 39:56 */         if (menuControlId.equals(this.menuControl.getId())) {
/* 40:   */           break;
/* 41:   */         }
/* 42:   */       }
/* 43:   */     }
/* 44:62 */     return new NMenuAdapter(this, ((ADMenuWidgetImpl)this.menuControl.getMenuWidget()).getMenuComponent());
/* 45:   */   }
/* 46:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.ibm.tivoli.maximo.mobile.android.ui.MenuBarMenuActivity
 * JD-Core Version:    0.7.0.1
 */