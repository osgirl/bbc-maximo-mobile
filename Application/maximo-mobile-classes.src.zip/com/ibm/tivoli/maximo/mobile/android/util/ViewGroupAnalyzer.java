/*   1:    */ package com.ibm.tivoli.maximo.mobile.android.util;
/*   2:    */ 
/*   3:    */ import android.util.Log;
/*   4:    */ import android.view.View;
/*   5:    */ import android.view.ViewGroup;
/*   6:    */ import android.view.ViewGroup.LayoutParams;
/*   7:    */ import android.widget.LinearLayout;
/*   8:    */ import android.widget.TextView;
/*   9:    */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*  10:    */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  11:    */ 
/*  12:    */ public class ViewGroupAnalyzer
/*  13:    */ {
/*  14:    */   private static final String LOGTAG = "LVG ";
/*  15:    */   private static final int indent = 3;
/*  16: 31 */   private int spacenum = 0;
/*  17:    */   
/*  18:    */   private String identspaces()
/*  19:    */   {
/*  20: 37 */     StringBuffer sb = new StringBuffer();
/*  21: 38 */     for (int i = 0; i < this.spacenum; i++) {
/*  22: 39 */       sb.append(" ");
/*  23:    */     }
/*  24: 41 */     return sb.toString();
/*  25:    */   }
/*  26:    */   
/*  27:    */   private void listViewGroupKids(String desc, ViewGroup vg)
/*  28:    */   {
/*  29: 45 */     if (vg == null) {
/*  30: 46 */       return;
/*  31:    */     }
/*  32: 48 */     if (desc != null) {
/*  33: 49 */       Log.d("LVG ", "List views " + desc);
/*  34:    */     }
/*  35: 51 */     Log.d("LVG ", "TOP PARENT: " + setupViewOutText(vg));
/*  36:    */     
/*  37:    */ 
/*  38:    */ 
/*  39:    */ 
/*  40: 56 */     this.spacenum = -3;
/*  41: 57 */     doListViewGroupKids(vg);
/*  42:    */   }
/*  43:    */   
/*  44:    */   private void doListViewGroupKids(ViewGroup vg)
/*  45:    */   {
/*  46: 61 */     this.spacenum += 3;
/*  47:    */     
/*  48: 63 */     int numOfKids = vg.getChildCount();
/*  49: 64 */     for (int i = 0; i < numOfKids; i++)
/*  50:    */     {
/*  51: 65 */       View kid = vg.getChildAt(i);
/*  52: 66 */       Log.d("LVG ", identspaces() + i + ": " + setupViewOutText(kid));
/*  53: 67 */       if ((kid instanceof ViewGroup)) {
/*  54: 71 */         doListViewGroupKids((ViewGroup)kid);
/*  55:    */       }
/*  56:    */     }
/*  57: 75 */     this.spacenum -= 3;
/*  58:    */   }
/*  59:    */   
/*  60:    */   private String setupViewOutText(View view)
/*  61:    */   {
/*  62: 79 */     StringBuffer sb = new StringBuffer();
/*  63:    */     
/*  64: 81 */     addToSB(sb, view.toString());
/*  65: 82 */     addToSB(sb, "id=[" + view.getId() + "]");
/*  66: 84 */     if ((view instanceof UIComponent))
/*  67:    */     {
/*  68: 85 */       UIComponent uic = (UIComponent)view;
/*  69: 86 */       if (uic.getController() != null)
/*  70:    */       {
/*  71: 87 */         addToSB(sb, "ctrlId=[" + uic.getController().getId() + "]");
/*  72: 88 */         addToSB(sb, "cmpId=[" + uic.getCId() + "]");
/*  73:    */       }
/*  74:    */       else
/*  75:    */       {
/*  76: 91 */         addToSB(sb, "cid=[null]");
/*  77:    */       }
/*  78:    */     }
/*  79: 96 */     if ((view instanceof TextView)) {
/*  80: 97 */       addToSB(sb, "text=[" + ((TextView)view).getText() + "]");
/*  81:    */     }
/*  82:100 */     addToSB(sb, "visible=[" + (view.getVisibility() == 0 ? "T" : "F") + "]");
/*  83:102 */     if (view.getLayoutParams() == null) {
/*  84:103 */       addToSB(sb, "LP=[" + view.getLayoutParams() + "]");
/*  85:    */     } else {
/*  86:106 */       addToSB(sb, "LP.w=[" + view.getLayoutParams().width + "], LP.h=[" + view.getLayoutParams().height + "]");
/*  87:    */     }
/*  88:109 */     if ((view instanceof LinearLayout))
/*  89:    */     {
/*  90:110 */       int orientation = ((LinearLayout)view).getOrientation();
/*  91:111 */       addToSB(sb, "HV=[" + (orientation == 0 ? "H" : "V") + "]");
/*  92:    */     }
/*  93:114 */     return sb.toString();
/*  94:    */   }
/*  95:    */   
/*  96:    */   private void addToSB(StringBuffer sb, String s)
/*  97:    */   {
/*  98:118 */     if (sb.length() > 0) {
/*  99:118 */       sb.append(",");
/* 100:    */     }
/* 101:119 */     sb.append(s);
/* 102:    */   }
/* 103:    */   
/* 104:    */   public static void listAllChildViews(String desc, ViewGroup vg)
/* 105:    */   {
/* 106:128 */     new ViewGroupAnalyzer().listViewGroupKids(desc, vg);
/* 107:    */   }
/* 108:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.ibm.tivoli.maximo.mobile.android.util.ViewGroupAnalyzer
 * JD-Core Version:    0.7.0.1
 */