/*  1:   */ package com.ibm.tivoli.maximo.mobile.android.persist.sqlite;
/*  2:   */ 
/*  3:   */ import com.mro.mobile.persist.sql.ApplyParametersValueProcessor;
/*  4:   */ import com.mro.mobile.util.MobileLogger;
/*  5:   */ import java.util.Date;
/*  6:   */ 
/*  7:   */ public class SQLiteStatementApplyParametersValueProcessor
/*  8:   */   extends ApplyParametersValueProcessor
/*  9:   */ {
/* 10:   */   private SQLiteCustomQueryStatement statement;
/* 11:   */   private MobileLogger logger;
/* 12:   */   
/* 13:   */   public SQLiteStatementApplyParametersValueProcessor(SQLiteCustomQueryStatement statement, int startPosition, MobileLogger logger)
/* 14:   */   {
/* 15:14 */     super(statement, startPosition, logger);
/* 16:15 */     this.statement = statement;
/* 17:16 */     this.logger = logger;
/* 18:   */   }
/* 19:   */   
/* 20:   */   public void processByte(byte value)
/* 21:   */   {
/* 22:21 */     processLong(value);
/* 23:   */   }
/* 24:   */   
/* 25:   */   public void processChar(char value)
/* 26:   */   {
/* 27:26 */     processString(String.valueOf(value));
/* 28:   */   }
/* 29:   */   
/* 30:   */   public void processString(String value)
/* 31:   */   {
/* 32:31 */     this.logger.info("bind value = " + value);
/* 33:32 */     this.statement.bindString(this.currentPos++, value);
/* 34:   */   }
/* 35:   */   
/* 36:   */   public void processShort(short value)
/* 37:   */   {
/* 38:37 */     processLong(value);
/* 39:   */   }
/* 40:   */   
/* 41:   */   public void processInt(int value)
/* 42:   */   {
/* 43:42 */     processLong(value);
/* 44:   */   }
/* 45:   */   
/* 46:   */   public void processLong(long value)
/* 47:   */   {
/* 48:47 */     this.logger.info("bind value = " + value);
/* 49:48 */     this.statement.bindLong(this.currentPos++, Long.valueOf(value));
/* 50:   */   }
/* 51:   */   
/* 52:   */   public void processFloat(float value)
/* 53:   */   {
/* 54:53 */     processDouble(value);
/* 55:   */   }
/* 56:   */   
/* 57:   */   public void processDouble(double value)
/* 58:   */   {
/* 59:58 */     this.logger.info("bind value = " + value);
/* 60:59 */     this.statement.bindDouble(this.currentPos++, Double.valueOf(value));
/* 61:   */   }
/* 62:   */   
/* 63:   */   public void processDate(Date value)
/* 64:   */   {
/* 65:64 */     this.logger.info("bind value = " + value);
/* 66:65 */     this.statement.bindLong(this.currentPos++, Long.valueOf(value.getTime()));
/* 67:   */   }
/* 68:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.ibm.tivoli.maximo.mobile.android.persist.sqlite.SQLiteStatementApplyParametersValueProcessor
 * JD-Core Version:    0.7.0.1
 */