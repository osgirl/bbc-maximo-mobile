/*   1:    */ package com.ibm.tivoli.maximo.mobile.android.persist.sqlite;
/*   2:    */ 
/*   3:    */ import android.database.Cursor;
/*   4:    */ import android.database.sqlite.SQLiteDatabase;
/*   5:    */ import android.database.sqlite.SQLiteDoneException;
/*   6:    */ import android.database.sqlite.SQLiteStatement;
/*   7:    */ import com.mro.mobile.persist.ConditionValue;
/*   8:    */ import com.mro.mobile.persist.Order;
/*   9:    */ import com.mro.mobile.persist.QBE;
/*  10:    */ import com.mro.mobile.persist.RDO;
/*  11:    */ import com.mro.mobile.persist.RDOAttributeInfo;
/*  12:    */ import com.mro.mobile.persist.RDODependentRelation;
/*  13:    */ import com.mro.mobile.persist.RDOEnumeration;
/*  14:    */ import com.mro.mobile.persist.RDOException;
/*  15:    */ import com.mro.mobile.persist.RDOInfo;
/*  16:    */ import com.mro.mobile.persist.RDOKey;
/*  17:    */ import com.mro.mobile.persist.RDOManager;
/*  18:    */ import com.mro.mobile.persist.sql.MobileWhereClause;
/*  19:    */ import com.mro.mobile.util.MobileLogger;
/*  20:    */ import java.util.ArrayList;
/*  21:    */ import java.util.Enumeration;
/*  22:    */ 
/*  23:    */ public class SQLiteDBRDOManager
/*  24:    */   implements RDOManager
/*  25:    */ {
/*  26:    */   private String appName;
/*  27:    */   private SQLiteDBManager dbManager;
/*  28:    */   private SQLiteDBRDOInfoManager rdoInfoManager;
/*  29:    */   private MobileLogger logger;
/*  30:    */   private SQLiteDBRDOManagerHelper sqliteHelper;
/*  31:    */   
/*  32:    */   public SQLiteDBRDOManager(String appName, SQLiteDBManager dbManager, SQLiteDBRDOInfoManager rdoInfoManager, MobileLogger logger)
/*  33:    */   {
/*  34: 41 */     this(appName, dbManager, rdoInfoManager, logger, new SQLiteDBRDOManagerHelper(logger));
/*  35:    */   }
/*  36:    */   
/*  37:    */   public SQLiteDBRDOManager(String appName, SQLiteDBManager dbManager, SQLiteDBRDOInfoManager rdoInfoManager, MobileLogger logger, SQLiteDBRDOManagerHelper sqliteHelper)
/*  38:    */   {
/*  39: 46 */     ensureArgumentsAreValid(appName, dbManager, rdoInfoManager, logger, sqliteHelper);
/*  40: 47 */     this.appName = appName;
/*  41: 48 */     this.dbManager = dbManager;
/*  42: 49 */     this.rdoInfoManager = rdoInfoManager;
/*  43: 50 */     this.logger = logger;
/*  44: 51 */     this.sqliteHelper = sqliteHelper;
/*  45:    */   }
/*  46:    */   
/*  47:    */   protected void ensureArgumentsAreValid(String appName, SQLiteDBManager dbManager, SQLiteDBRDOInfoManager rdoInfoManager, MobileLogger logger, SQLiteDBRDOManagerHelper helper)
/*  48:    */   {
/*  49: 56 */     if (dbManager == null) {
/*  50: 57 */       throw new IllegalArgumentException("DB Manager cannot be null.");
/*  51:    */     }
/*  52: 58 */     if (logger == null) {
/*  53: 59 */       throw new IllegalArgumentException("Logger cannot be null.");
/*  54:    */     }
/*  55: 60 */     if (appName == null) {
/*  56: 61 */       throw new IllegalArgumentException("Application name cannot be null.");
/*  57:    */     }
/*  58: 62 */     if (rdoInfoManager == null) {
/*  59: 63 */       throw new IllegalArgumentException("RDO info manager cannot be null.");
/*  60:    */     }
/*  61: 64 */     if (helper == null) {
/*  62: 65 */       throw new IllegalArgumentException("RDO manager helper cannot be null.");
/*  63:    */     }
/*  64:    */   }
/*  65:    */   
/*  66:    */   protected SQLiteDBRDOManagerHelper getDBHelper()
/*  67:    */   {
/*  68: 69 */     return this.sqliteHelper;
/*  69:    */   }
/*  70:    */   
/*  71:    */   public RDOEnumeration getAll(String name)
/*  72:    */     throws RDOException
/*  73:    */   {
/*  74: 74 */     return getAll(name, null, null, null);
/*  75:    */   }
/*  76:    */   
/*  77:    */   public RDOEnumeration getAll(String name, QBE filter, Order order)
/*  78:    */     throws RDOException
/*  79:    */   {
/*  80: 79 */     return getAll(name, filter, null, order);
/*  81:    */   }
/*  82:    */   
/*  83:    */   public RDOEnumeration getAll(String name, QBE filter, MobileWhereClause whereClause, Order order)
/*  84:    */     throws RDOException
/*  85:    */   {
/*  86: 84 */     RDOInfo info = getRDOInfoOrThrowException(name);
/*  87: 85 */     String query = this.sqliteHelper.buildComplexQueryStatement(info, filter, whereClause, order, this);
/*  88: 86 */     SQLiteCustomQueryStatement statement = new SQLiteCustomQueryStatement();
/*  89:    */     try
/*  90:    */     {
/*  91: 88 */       this.logger.info(query);
/*  92: 89 */       int bindIndex = 1;
/*  93: 90 */       if (info.isHierarchical())
/*  94:    */       {
/*  95: 91 */         this.logger.info("bind value for _OWNERID = 0");
/*  96: 92 */         statement.bindLong(bindIndex, Long.valueOf(0L));
/*  97: 93 */         bindIndex++;
/*  98:    */       }
/*  99: 95 */       bindIndex = this.sqliteHelper.applyQBEBindings(info, filter, statement, bindIndex);
/* 100: 96 */       if (whereClause != null) {
/* 101: 97 */         whereClause.applyParameters(new SQLiteStatementApplyParametersValueProcessor(statement, bindIndex, this.logger));
/* 102:    */       }
/* 103: 99 */       Cursor cursor = this.dbManager.getDatabase().rawQuery(query, statement.toSelectionArgs());
/* 104:100 */       return new SQLiteRDOEnumeration(this.appName, info, cursor, this.logger);
/* 105:    */     }
/* 106:    */     catch (Exception e)
/* 107:    */     {
/* 108:103 */       this.logger.error(e.getMessage(), e);
/* 109:104 */       throw new RDOException("rdogetfailed", new Object[] { name }, e);
/* 110:    */     }
/* 111:    */   }
/* 112:    */   
/* 113:    */   protected RDOInfo getRDOInfoOrThrowException(String name)
/* 114:    */     throws RDOException
/* 115:    */   {
/* 116:109 */     RDOInfo info = this.rdoInfoManager.getInfo(name);
/* 117:110 */     if (info == null) {
/* 118:111 */       throw new RDOException("unknownrdo", new Object[] { name });
/* 119:    */     }
/* 120:113 */     return info;
/* 121:    */   }
/* 122:    */   
/* 123:    */   public void insert(String name, RDO rdo)
/* 124:    */     throws RDOException
/* 125:    */   {
/* 126:118 */     RDOInfo info = getRDOInfoOrThrowException(name);
/* 127:119 */     String stmt = this.sqliteHelper.buildInsertStatement(info);
/* 128:120 */     SQLiteStatement statement = null;
/* 129:    */     try
/* 130:    */     {
/* 131:122 */       this.logger.info(stmt);
/* 132:123 */       statement = this.dbManager.getDatabase().compileStatement(stmt);
/* 133:124 */       String[] attrNames = info.getAttributeNames();
/* 134:125 */       int bindIndex = 1;
/* 135:126 */       for (int i = 0; i < attrNames.length; i++)
/* 136:    */       {
/* 137:127 */         RDOAttributeInfo attributeInfo = info.getAttributeInfo(i);
/* 138:128 */         if (attributeInfo.isPersistent())
/* 139:    */         {
/* 140:129 */           this.sqliteHelper.setBindValue(statement, bindIndex, attributeInfo, rdo);
/* 141:130 */           bindIndex++;
/* 142:    */         }
/* 143:    */       }
/* 144:133 */       this.logger.info("insert count: " + statement.executeInsert());
/* 145:    */     }
/* 146:    */     catch (Exception e)
/* 147:    */     {
/* 148:135 */       this.logger.error(e.getMessage(), e);
/* 149:136 */       throw new RDOException("rdoinsertfailed", new Object[] { name }, e);
/* 150:    */     }
/* 151:    */     finally
/* 152:    */     {
/* 153:138 */       SQLiteUtil.safelyCloseStatement(statement, this.logger);
/* 154:    */     }
/* 155:    */   }
/* 156:    */   
/* 157:    */   public void remove(String name, RDO rdo)
/* 158:    */     throws RDOException
/* 159:    */   {
/* 160:144 */     RDOInfo info = getRDOInfoOrThrowException(name);
/* 161:145 */     if (info.hasAttribute("_ID"))
/* 162:    */     {
/* 163:146 */       long id = rdo.getLongValue("_ID");
/* 164:147 */       remove(name, id);
/* 165:    */     }
/* 166:    */     else
/* 167:    */     {
/* 168:149 */       RDO r = get(name, rdo.getKey());
/* 169:150 */       String[] dependents = info.getDependentNames();
/* 170:151 */       for (int j = 0; j < dependents.length; j++) {
/* 171:152 */         removeDependents(dependents[j], r);
/* 172:    */       }
/* 173:154 */       if (info.isHierarchical()) {
/* 174:155 */         removeDependents(name, r);
/* 175:    */       }
/* 176:158 */       SQLiteStatement statement = null;
/* 177:159 */       String delete = this.sqliteHelper.buildDeleteStatementBasedOnKeys(info, rdo.getKey());
/* 178:    */       try
/* 179:    */       {
/* 180:161 */         this.logger.info(delete);
/* 181:162 */         statement = this.dbManager.getDatabase().compileStatement(delete);
/* 182:163 */         int bindIndex = 1;
/* 183:164 */         String[] attrNames = info.getAttributeNames();
/* 184:165 */         for (int i = 0; i < attrNames.length; i++)
/* 185:    */         {
/* 186:166 */           RDOAttributeInfo attrInfo = info.getAttributeInfo(attrNames[i]);
/* 187:167 */           if ((attrInfo.isKey()) && (!rdo.isNull(attrNames[i])))
/* 188:    */           {
/* 189:168 */             this.sqliteHelper.setBindValue(statement, bindIndex, attrInfo, rdo);
/* 190:169 */             bindIndex++;
/* 191:    */           }
/* 192:    */         }
/* 193:172 */         statement.execute();
/* 194:173 */         this.logger.info("delete count:" + this.dbManager.getAffectedRecordsCount());
/* 195:    */       }
/* 196:    */       catch (Exception e)
/* 197:    */       {
/* 198:175 */         this.logger.error(e.getMessage(), e);
/* 199:176 */         throw new RDOException("rdoremovefailed", new Object[] { name, rdo.getKey() }, e);
/* 200:    */       }
/* 201:    */       finally
/* 202:    */       {
/* 203:178 */         SQLiteUtil.safelyCloseStatement(statement, this.logger);
/* 204:    */       }
/* 205:    */     }
/* 206:    */   }
/* 207:    */   
/* 208:    */   public void remove(String name, long id)
/* 209:    */     throws RDOException
/* 210:    */   {
/* 211:185 */     RDOInfo info = getRDOInfoOrThrowException(name);
/* 212:186 */     RDO rdo = get(name, id);
/* 213:187 */     if (rdo != null)
/* 214:    */     {
/* 215:188 */       String[] dependents = info.getDependentNames();
/* 216:189 */       for (int j = 0; j < dependents.length; j++) {
/* 217:190 */         removeDependents(dependents[j], rdo);
/* 218:    */       }
/* 219:192 */       if (info.isHierarchical()) {
/* 220:193 */         removeDependents(name, rdo);
/* 221:    */       }
/* 222:196 */       SQLiteStatement statement = null;
/* 223:    */       try
/* 224:    */       {
/* 225:198 */         String delete = this.sqliteHelper.buildDeleteStatementWithID(name);
/* 226:199 */         this.logger.info(delete);
/* 227:200 */         statement = this.dbManager.getDatabase().compileStatement(delete);
/* 228:201 */         this.logger.info("bind value for _ID = " + id);
/* 229:202 */         statement.bindLong(1, id);
/* 230:203 */         statement.execute();
/* 231:204 */         this.logger.info("delete count:" + this.dbManager.getAffectedRecordsCount());
/* 232:    */       }
/* 233:    */       catch (Exception e)
/* 234:    */       {
/* 235:206 */         this.logger.error(e.getMessage(), e);
/* 236:207 */         throw new RDOException("rdoremovefailed", new Object[] { name, Long.valueOf(id) }, e);
/* 237:    */       }
/* 238:    */       finally
/* 239:    */       {
/* 240:209 */         SQLiteUtil.safelyCloseStatement(statement, this.logger);
/* 241:    */       }
/* 242:    */     }
/* 243:    */   }
/* 244:    */   
/* 245:    */   public void removeDependent(String name, long id, long parentId)
/* 246:    */     throws RDOException
/* 247:    */   {
/* 248:216 */     RDOInfo info = getRDOInfoOrThrowException(name);
/* 249:    */     
/* 250:218 */     RDO rdo = get(name, id, parentId);
/* 251:219 */     if (rdo != null)
/* 252:    */     {
/* 253:220 */       String[] dependents = info.getDependentNames();
/* 254:221 */       for (int j = 0; j < dependents.length; j++) {
/* 255:222 */         removeDependents(dependents[j], rdo);
/* 256:    */       }
/* 257:224 */       if (info.isHierarchical()) {
/* 258:225 */         removeDependents(name, rdo);
/* 259:    */       }
/* 260:227 */       SQLiteStatement statement = null;
/* 261:    */       try
/* 262:    */       {
/* 263:229 */         String delete = this.sqliteHelper.buildDeleteStatementWithIDAndParentId(name);
/* 264:230 */         this.logger.info(delete);
/* 265:231 */         statement = this.dbManager.getDatabase().compileStatement(delete);
/* 266:232 */         this.logger.info("bind value for _ID = " + id);
/* 267:233 */         statement.bindLong(1, id);
/* 268:234 */         this.logger.info("bind value for _PARENTID = " + parentId);
/* 269:235 */         statement.bindLong(2, parentId);
/* 270:236 */         statement.execute();
/* 271:237 */         this.logger.info("delete count:" + this.dbManager.getAffectedRecordsCount());
/* 272:    */       }
/* 273:    */       catch (Exception e)
/* 274:    */       {
/* 275:239 */         this.logger.error(e.getMessage(), e);
/* 276:240 */         throw new RDOException("rdogetdependentfailed", new Object[] { name, Long.valueOf(id), Long.valueOf(parentId) }, e);
/* 277:    */       }
/* 278:    */       finally
/* 279:    */       {
/* 280:242 */         SQLiteUtil.safelyCloseStatement(statement, this.logger);
/* 281:    */       }
/* 282:    */     }
/* 283:    */   }
/* 284:    */   
/* 285:    */   private RDO get(String name, long id, long parentId)
/* 286:    */     throws RDOException
/* 287:    */   {
/* 288:248 */     RDOInfo info = getRDOInfoOrThrowException(name);
/* 289:249 */     String query = this.sqliteHelper.buildSimpleDependentQuery(name, id, parentId);
/* 290:250 */     Cursor c = null;
/* 291:    */     try
/* 292:    */     {
/* 293:252 */       this.logger.info(query);
/* 294:253 */       c = this.dbManager.getDatabase().rawQuery(query, SQLiteUtil.EMPTY_STRING_ARRAY);
/* 295:254 */       if (c.moveToNext())
/* 296:    */       {
/* 297:255 */         RDO rdo = this.sqliteHelper.buildRDO(c, info, this.appName);
/* 298:256 */         return rdo;
/* 299:    */       }
/* 300:    */     }
/* 301:    */     catch (Exception e)
/* 302:    */     {
/* 303:259 */       this.logger.error(e.getMessage(), e);
/* 304:260 */       throw new RDOException("rdogetdependentfailed", new Object[] { name, new Long(id), new Long(parentId) }, e);
/* 305:    */     }
/* 306:    */     finally
/* 307:    */     {
/* 308:262 */       SQLiteUtil.safelyCloseCursor(c, this.logger);
/* 309:    */     }
/* 310:264 */     return null;
/* 311:    */   }
/* 312:    */   
/* 313:    */   protected void removeDependents(String dependentName, RDO parentRDO)
/* 314:    */     throws RDOException
/* 315:    */   {
/* 316:268 */     if (parentRDO != null)
/* 317:    */     {
/* 318:269 */       RDOInfo depInfo = getRDOInfoOrThrowException(dependentName);
/* 319:270 */       if (depInfo.getDependentRelation() == null)
/* 320:    */       {
/* 321:271 */         long parentId = parentRDO.getId();
/* 322:272 */         RDOInfo info = depInfo;
/* 323:273 */         String[] dependents = info.getDependentNames();
/* 324:274 */         ArrayList<RDO> dependentRDOsToRemove = new ArrayList();
/* 325:275 */         if ((dependents.length > 0) || (info.isHierarchical()))
/* 326:    */         {
/* 327:276 */           RDOEnumeration rdoEnum = parentRDO.getDependents(dependentName);
/* 328:277 */           while (rdoEnum.hasMoreElements()) {
/* 329:278 */             dependentRDOsToRemove.add((RDO)rdoEnum.nextElement());
/* 330:    */           }
/* 331:    */         }
/* 332:282 */         String delete = null;
/* 333:283 */         if (info.isDependent()) {
/* 334:284 */           delete = this.sqliteHelper.buildDeleteStatementWithParentId(info.getName());
/* 335:285 */         } else if (info.isHierarchical()) {
/* 336:286 */           delete = this.sqliteHelper.buildDeleteStatementWithOwnerId(info.getName());
/* 337:    */         } else {
/* 338:288 */           return;
/* 339:    */         }
/* 340:291 */         SQLiteStatement statement = null;
/* 341:    */         try
/* 342:    */         {
/* 343:293 */           this.logger.info(delete);
/* 344:294 */           statement = this.dbManager.getDatabase().compileStatement(delete);
/* 345:295 */           if (info.isDependent()) {
/* 346:296 */             this.logger.info("bind value for _PARENTID = " + parentId);
/* 347:    */           } else {
/* 348:298 */             this.logger.info("bind value for _OWNERID = " + parentId);
/* 349:    */           }
/* 350:300 */           statement.bindLong(1, parentId);
/* 351:301 */           statement.execute();
/* 352:302 */           this.logger.info("delete count:" + this.dbManager.getAffectedRecordsCount());
/* 353:    */         }
/* 354:    */         catch (Exception e)
/* 355:    */         {
/* 356:304 */           this.logger.error(e.getMessage(), e);
/* 357:305 */           throw new RDOException("rdoremovefailed", new Object[] { dependentName, new Long(parentId) }, e);
/* 358:    */         }
/* 359:    */         finally
/* 360:    */         {
/* 361:307 */           SQLiteUtil.safelyCloseStatement(statement, this.logger);
/* 362:    */         }
/* 363:310 */         String parentName = dependentName;
/* 364:311 */         int noOfDependentRecords = dependentRDOsToRemove.size();
/* 365:312 */         if ((dependents.length == 0) && (!info.isHierarchical())) {
/* 366:313 */           return;
/* 367:    */         }
/* 368:316 */         for (int i = 0; i < noOfDependentRecords; i++)
/* 369:    */         {
/* 370:317 */           RDO rdo = (RDO)dependentRDOsToRemove.get(i);
/* 371:318 */           for (int j = 0; j < dependents.length; j++) {
/* 372:319 */             removeDependents(dependents[j], rdo);
/* 373:    */           }
/* 374:321 */           if (info.isHierarchical()) {
/* 375:322 */             removeDependents(parentName, rdo);
/* 376:    */           }
/* 377:    */         }
/* 378:    */       }
/* 379:    */     }
/* 380:    */   }
/* 381:    */   
/* 382:    */   public void removeAll(String name)
/* 383:    */     throws RDOException
/* 384:    */   {
/* 385:332 */     RDOInfo info = getRDOInfoOrThrowException(name);
/* 386:333 */     if (!info.isDependent()) {
/* 387:334 */       removeAllRecordsWithDependents(info);
/* 388:    */     }
/* 389:    */   }
/* 390:    */   
/* 391:    */   protected void removeAllRecordsWithDependents(RDOInfo info)
/* 392:    */     throws RDOException
/* 393:    */   {
/* 394:339 */     SQLiteStatement statement = null;
/* 395:340 */     String name = info.getName();
/* 396:341 */     String delete = this.sqliteHelper.buildSimpleDeleteStatement(name);
/* 397:    */     try
/* 398:    */     {
/* 399:343 */       this.logger.info(delete);
/* 400:344 */       statement = this.dbManager.getDatabase().compileStatement(delete);
/* 401:345 */       statement.execute();
/* 402:346 */       this.logger.info("delete count:" + this.dbManager.getAffectedRecordsCount());
/* 403:    */     }
/* 404:    */     catch (Exception e)
/* 405:    */     {
/* 406:348 */       this.logger.error(e.getMessage(), e);
/* 407:349 */       throw new RDOException("rdoremoveallfailed", new Object[] { name }, e);
/* 408:    */     }
/* 409:    */     finally
/* 410:    */     {
/* 411:351 */       SQLiteUtil.safelyCloseStatement(statement, this.logger);
/* 412:    */     }
/* 413:354 */     String[] dependentNames = info.getDependentNames();
/* 414:355 */     for (int i = 0; i < dependentNames.length; i++)
/* 415:    */     {
/* 416:356 */       RDOInfo depInfo = getRDOInfoOrThrowException(dependentNames[i]);
/* 417:357 */       if (depInfo.getDependentRelation() == null) {
/* 418:358 */         removeAllRecordsWithDependents(depInfo);
/* 419:    */       }
/* 420:    */     }
/* 421:    */   }
/* 422:    */   
/* 423:    */   public void update(String name, RDO rdo)
/* 424:    */     throws RDOException
/* 425:    */   {
/* 426:365 */     RDOInfo info = getRDOInfoOrThrowException(name);
/* 427:366 */     String stmt = this.sqliteHelper.buildUpdateStatement(info);
/* 428:367 */     SQLiteStatement statement = null;
/* 429:    */     try
/* 430:    */     {
/* 431:369 */       this.logger.info(stmt);
/* 432:370 */       statement = this.dbManager.getDatabase().compileStatement(stmt);
/* 433:371 */       this.sqliteHelper.bindUpdateStatementValues(statement, info, rdo);
/* 434:372 */       statement.execute();
/* 435:373 */       this.logger.info("update count:" + this.dbManager.getAffectedRecordsCount());
/* 436:    */     }
/* 437:    */     catch (Exception e)
/* 438:    */     {
/* 439:375 */       this.logger.error(e.getMessage(), e);
/* 440:376 */       throw new RDOException("rdoupdatefailed", new Object[] { name, rdo.getKey() }, e);
/* 441:    */     }
/* 442:    */     finally
/* 443:    */     {
/* 444:378 */       SQLiteUtil.safelyCloseStatement(statement, this.logger);
/* 445:    */     }
/* 446:    */   }
/* 447:    */   
/* 448:    */   public boolean exists(String name, RDOKey key)
/* 449:    */     throws RDOException
/* 450:    */   {
/* 451:384 */     RDOInfo info = getRDOInfoOrThrowException(name);
/* 452:385 */     if (key != null)
/* 453:    */     {
/* 454:386 */       String query = this.sqliteHelper.buildSimpleQueryByKey(info, key);
/* 455:387 */       Cursor c = null;
/* 456:    */       try
/* 457:    */       {
/* 458:389 */         this.logger.info(query);
/* 459:390 */         String[] keyNames = info.getKeyAttributeNames();
/* 460:391 */         String[] keyValues = key.getKeyValues();
/* 461:392 */         ArrayList<String> params = new ArrayList();
/* 462:393 */         for (int i = 0; i < keyValues.length; i++) {
/* 463:394 */           if (keyValues[i] != null)
/* 464:    */           {
/* 465:395 */             this.logger.info("bind value for " + keyNames[i] + " = " + keyValues[i]);
/* 466:396 */             params.add(keyValues[i]);
/* 467:    */           }
/* 468:    */         }
/* 469:399 */         c = this.dbManager.getDatabase().rawQuery(query, (String[])params.toArray(SQLiteUtil.EMPTY_STRING_ARRAY));
/* 470:400 */         if (c.moveToNext()) {
/* 471:401 */           return 1;
/* 472:    */         }
/* 473:    */       }
/* 474:    */       catch (Exception e)
/* 475:    */       {
/* 476:404 */         this.logger.error(e.getMessage(), e);
/* 477:405 */         throw new RDOException("rdocheckexistfailed", new Object[] { name, key }, e);
/* 478:    */       }
/* 479:    */       finally
/* 480:    */       {
/* 481:407 */         SQLiteUtil.safelyCloseCursor(c, this.logger);
/* 482:    */       }
/* 483:    */     }
/* 484:410 */     return false;
/* 485:    */   }
/* 486:    */   
/* 487:    */   public boolean existsDependent(String name, long id, long parentId)
/* 488:    */     throws RDOException
/* 489:    */   {
/* 490:415 */     getRDOInfoOrThrowException(name);
/* 491:416 */     String query = this.sqliteHelper.buildSimpleDependentQuery(name, id, parentId);
/* 492:417 */     Cursor c = null;
/* 493:    */     try
/* 494:    */     {
/* 495:419 */       this.logger.info(query);
/* 496:420 */       c = this.dbManager.getDatabase().rawQuery(query, SQLiteUtil.EMPTY_STRING_ARRAY);
/* 497:421 */       if (c.moveToNext()) {
/* 498:422 */         return true;
/* 499:    */       }
/* 500:    */     }
/* 501:    */     catch (Exception e)
/* 502:    */     {
/* 503:425 */       this.logger.error(e.getMessage(), e);
/* 504:426 */       throw new RDOException("rdocheckexistdependentfailed", new Object[] { name, new Long(id), new Long(parentId) }, e);
/* 505:    */     }
/* 506:    */     finally
/* 507:    */     {
/* 508:428 */       SQLiteUtil.safelyCloseCursor(c, this.logger);
/* 509:    */     }
/* 510:430 */     return false;
/* 511:    */   }
/* 512:    */   
/* 513:    */   public boolean exists(String name, long id)
/* 514:    */     throws RDOException
/* 515:    */   {
/* 516:435 */     getRDOInfoOrThrowException(name);
/* 517:436 */     String query = this.sqliteHelper.buildSimpleIdQuery(name, id);
/* 518:437 */     Cursor c = null;
/* 519:    */     try
/* 520:    */     {
/* 521:439 */       this.logger.info(query);
/* 522:440 */       c = this.dbManager.getDatabase().rawQuery(query, SQLiteUtil.EMPTY_STRING_ARRAY);
/* 523:441 */       if (c.moveToNext()) {
/* 524:442 */         return true;
/* 525:    */       }
/* 526:    */     }
/* 527:    */     catch (Exception e)
/* 528:    */     {
/* 529:445 */       this.logger.error(e.getMessage(), e);
/* 530:446 */       throw new RDOException("rdocheckexistfailed", new Object[] { name, new Long(id) }, e);
/* 531:    */     }
/* 532:    */     finally
/* 533:    */     {
/* 534:448 */       SQLiteUtil.safelyCloseCursor(c, this.logger);
/* 535:    */     }
/* 536:450 */     return false;
/* 537:    */   }
/* 538:    */   
/* 539:    */   public RDO get(String name, RDOKey key)
/* 540:    */     throws RDOException
/* 541:    */   {
/* 542:455 */     RDOInfo info = getRDOInfoOrThrowException(name);
/* 543:456 */     if (key != null)
/* 544:    */     {
/* 545:457 */       String query = this.sqliteHelper.buildSimpleQueryByKey(info, key);
/* 546:458 */       Cursor c = null;
/* 547:    */       try
/* 548:    */       {
/* 549:460 */         this.logger.info(query);
/* 550:461 */         String[] keyNames = info.getKeyAttributeNames();
/* 551:462 */         String[] keyValues = filterNullsOut(key.getKeyValues());
/* 552:463 */         for (int i = 0; i < keyValues.length; i++) {
/* 553:464 */           this.logger.info("bind value for " + keyNames[i] + " = " + keyValues[i]);
/* 554:    */         }
/* 555:466 */         c = this.dbManager.getDatabase().rawQuery(query, keyValues);
/* 556:467 */         if (c.moveToNext())
/* 557:    */         {
/* 558:468 */           RDO rdo = this.sqliteHelper.buildRDO(c, info, this.appName);
/* 559:469 */           return rdo;
/* 560:    */         }
/* 561:    */       }
/* 562:    */       catch (Exception e)
/* 563:    */       {
/* 564:472 */         this.logger.error(e.getMessage(), e);
/* 565:473 */         throw new RDOException("rdocheckexistfailed", new Object[] { name, key }, e);
/* 566:    */       }
/* 567:    */       finally
/* 568:    */       {
/* 569:475 */         SQLiteUtil.safelyCloseCursor(c, this.logger);
/* 570:    */       }
/* 571:    */     }
/* 572:478 */     return null;
/* 573:    */   }
/* 574:    */   
/* 575:    */   private String[] filterNullsOut(String[] keyValues)
/* 576:    */   {
/* 577:482 */     ArrayList<String> list = new ArrayList();
/* 578:483 */     int count = 0;
/* 579:484 */     for (String value : list) {
/* 580:485 */       if (value != null)
/* 581:    */       {
/* 582:486 */         list.add(value);
/* 583:487 */         count++;
/* 584:    */       }
/* 585:    */     }
/* 586:490 */     return (String[])list.toArray(new String[count]);
/* 587:    */   }
/* 588:    */   
/* 589:    */   public RDO get(String name, long id)
/* 590:    */     throws RDOException
/* 591:    */   {
/* 592:495 */     RDOInfo info = getRDOInfoOrThrowException(name);
/* 593:496 */     String query = this.sqliteHelper.buildSimpleIdQuery(name, id);
/* 594:497 */     Cursor c = null;
/* 595:    */     try
/* 596:    */     {
/* 597:499 */       this.logger.info(query);
/* 598:500 */       c = this.dbManager.getDatabase().rawQuery(query, SQLiteUtil.EMPTY_STRING_ARRAY);
/* 599:501 */       if (c.moveToNext())
/* 600:    */       {
/* 601:502 */         RDO rdo = this.sqliteHelper.buildRDO(c, info, this.appName);
/* 602:503 */         return rdo;
/* 603:    */       }
/* 604:    */     }
/* 605:    */     catch (Exception e)
/* 606:    */     {
/* 607:506 */       this.logger.error(e.getMessage(), e);
/* 608:507 */       throw new RDOException("rdogetfailed", new Object[] { name, new Long(id) }, e);
/* 609:    */     }
/* 610:    */     finally
/* 611:    */     {
/* 612:509 */       SQLiteUtil.safelyCloseCursor(c, this.logger);
/* 613:    */     }
/* 614:511 */     return null;
/* 615:    */   }
/* 616:    */   
/* 617:    */   public int size(String name)
/* 618:    */     throws RDOException
/* 619:    */   {
/* 620:516 */     RDOInfo info = getRDOInfoOrThrowException(name);
/* 621:517 */     String query = this.sqliteHelper.buildSimpleCountQuery(info);
/* 622:518 */     SQLiteStatement statement = null;
/* 623:519 */     int result = 0;
/* 624:    */     try
/* 625:    */     {
/* 626:521 */       this.logger.info(query);
/* 627:522 */       statement = this.dbManager.getDatabase().compileStatement(query);
/* 628:523 */       result = (int)statement.simpleQueryForLong();
/* 629:    */     }
/* 630:    */     catch (SQLiteDoneException e)
/* 631:    */     {
/* 632:525 */       this.logger.warn(e.getMessage(), e);
/* 633:    */     }
/* 634:    */     catch (Exception e)
/* 635:    */     {
/* 636:527 */       this.logger.error(e.getMessage(), e);
/* 637:528 */       throw new RDOException("rdogetsizefailed", new Object[] { name }, e);
/* 638:    */     }
/* 639:    */     finally
/* 640:    */     {
/* 641:530 */       SQLiteUtil.safelyCloseStatement(statement, this.logger);
/* 642:    */     }
/* 643:532 */     return result;
/* 644:    */   }
/* 645:    */   
/* 646:    */   public int size(String name, QBE filter)
/* 647:    */     throws RDOException
/* 648:    */   {
/* 649:537 */     return size(name, filter, null);
/* 650:    */   }
/* 651:    */   
/* 652:    */   public int size(String name, QBE filter, MobileWhereClause whereClause)
/* 653:    */     throws RDOException
/* 654:    */   {
/* 655:542 */     RDOInfo info = getRDOInfoOrThrowException(name);
/* 656:543 */     String query = this.sqliteHelper.buildComplexCountQueryStatement(info, filter, whereClause, this);
/* 657:544 */     SQLiteCustomQueryStatement statement = new SQLiteCustomQueryStatement();
/* 658:545 */     Cursor cursor = null;
/* 659:    */     try
/* 660:    */     {
/* 661:547 */       this.logger.info(query);
/* 662:548 */       int bindIndex = 1;
/* 663:549 */       bindIndex = this.sqliteHelper.applyQBEBindings(info, filter, statement, bindIndex);
/* 664:550 */       if (whereClause != null) {
/* 665:551 */         whereClause.applyParameters(new SQLiteStatementApplyParametersValueProcessor(statement, bindIndex, this.logger));
/* 666:    */       }
/* 667:553 */       cursor = this.dbManager.getDatabase().rawQuery(query, statement.toSelectionArgs());
/* 668:    */       int i;
/* 669:554 */       if (cursor.moveToNext()) {
/* 670:555 */         return cursor.getInt(0);
/* 671:    */       }
/* 672:557 */       return 0;
/* 673:    */     }
/* 674:    */     catch (Exception e)
/* 675:    */     {
/* 676:560 */       this.logger.error(e.getMessage(), e);
/* 677:561 */       throw new RDOException("rdogetsizefailed", new Object[] { name }, e);
/* 678:    */     }
/* 679:    */     finally
/* 680:    */     {
/* 681:563 */       SQLiteUtil.safelyCloseCursor(cursor, this.logger);
/* 682:    */     }
/* 683:    */   }
/* 684:    */   
/* 685:    */   public boolean exists(String name)
/* 686:    */     throws RDOException
/* 687:    */   {
/* 688:569 */     return this.dbManager.existsTable(name);
/* 689:    */   }
/* 690:    */   
/* 691:    */   public void removeAll()
/* 692:    */     throws RDOException
/* 693:    */   {
/* 694:574 */     Enumeration<String> nameEnum = this.rdoInfoManager.getAllNames();
/* 695:575 */     while (nameEnum.hasMoreElements())
/* 696:    */     {
/* 697:576 */       String rdoName = (String)nameEnum.nextElement();
/* 698:577 */       removeAll(rdoName);
/* 699:    */     }
/* 700:    */   }
/* 701:    */   
/* 702:    */   public RDOEnumeration getDependents(String name, RDO parentRDO)
/* 703:    */     throws RDOException
/* 704:    */   {
/* 705:583 */     return getDependents(name, null, null, parentRDO);
/* 706:    */   }
/* 707:    */   
/* 708:    */   public RDOEnumeration getDependents(String name, QBE filter, Order order, RDO parentRDO)
/* 709:    */     throws RDOException
/* 710:    */   {
/* 711:588 */     return getDependents(name, filter, null, order, parentRDO);
/* 712:    */   }
/* 713:    */   
/* 714:    */   public RDOEnumeration getDependents(String name, QBE filter, MobileWhereClause whereClause, Order order, RDO parentRDO)
/* 715:    */     throws RDOException
/* 716:    */   {
/* 717:593 */     if (name.equals("CHILDREN"))
/* 718:    */     {
/* 719:594 */       RDOInfo info = parentRDO.getInfo();
/* 720:595 */       if (info.isHierarchical()) {
/* 721:596 */         name = parentRDO.getName();
/* 722:    */       } else {
/* 723:599 */         return new EmptySQLiteDBRDOEnumeration();
/* 724:    */       }
/* 725:    */     }
/* 726:602 */     return getAllDependentResultSet(getRDOInfoOrThrowException(name), filter, whereClause, order, parentRDO);
/* 727:    */   }
/* 728:    */   
/* 729:    */   private RDOEnumeration getAllDependentResultSet(RDOInfo info, QBE qbe, MobileWhereClause whereClause, Order order, RDO parentRDO)
/* 730:    */     throws RDOException
/* 731:    */   {
/* 732:606 */     RDOInfo parentInfo = parentRDO.getInfo();
/* 733:607 */     RDODependentRelation depRelation = info.getDependentRelation();
/* 734:608 */     String query = this.sqliteHelper.buildComplexDependentQueryStatement(info, parentInfo, depRelation, parentRDO, qbe, whereClause, order, this);
/* 735:609 */     SQLiteCustomQueryStatement statement = new SQLiteCustomQueryStatement();
/* 736:610 */     Cursor cursor = null;
/* 737:    */     try
/* 738:    */     {
/* 739:612 */       this.logger.info(query);
/* 740:613 */       int bindIndex = 1;
/* 741:614 */       if (info.isHierarchical())
/* 742:    */       {
/* 743:615 */         this.logger.info("bind value for _OWNERID = " + parentRDO.getId());
/* 744:616 */         statement.bindLong(bindIndex, Long.valueOf(parentRDO.getId()));
/* 745:617 */         bindIndex++;
/* 746:    */       }
/* 747:620 */       else if (depRelation == null)
/* 748:    */       {
/* 749:621 */         this.logger.info("bind value for _PARENTID = " + parentRDO.getId());
/* 750:622 */         statement.bindLong(bindIndex, Long.valueOf(parentRDO.getId()));
/* 751:623 */         bindIndex++;
/* 752:    */       }
/* 753:    */       else
/* 754:    */       {
/* 755:625 */         bindIndex = this.sqliteHelper.bindDependentRelation(depRelation, parentRDO, statement, bindIndex);
/* 756:    */       }
/* 757:628 */       bindIndex = this.sqliteHelper.applyQBEBindings(info, qbe, statement, bindIndex);
/* 758:629 */       if (whereClause != null) {
/* 759:630 */         whereClause.applyParameters(new SQLiteStatementApplyParametersValueProcessor(statement, bindIndex, this.logger));
/* 760:    */       }
/* 761:632 */       cursor = this.dbManager.getDatabase().rawQuery(query, statement.toSelectionArgs());
/* 762:633 */       return new SQLiteRDOEnumeration(this.appName, info, cursor, this.logger);
/* 763:    */     }
/* 764:    */     catch (Exception e)
/* 765:    */     {
/* 766:636 */       this.logger.error(e.getMessage(), e);
/* 767:637 */       throw new RDOException("rdogetdepfailed", new Object[] { parentRDO.getName(), info.getName() }, e);
/* 768:    */     }
/* 769:    */   }
/* 770:    */   
/* 771:    */   public int getDependentsSize(String name, QBE qbe, MobileWhereClause whereClause, RDO parentRDO)
/* 772:    */     throws RDOException
/* 773:    */   {
/* 774:643 */     if (name.equals("CHILDREN"))
/* 775:    */     {
/* 776:644 */       RDOInfo info = parentRDO.getInfo();
/* 777:645 */       if (info.isHierarchical()) {
/* 778:646 */         name = parentRDO.getName();
/* 779:    */       } else {
/* 780:649 */         return 0;
/* 781:    */       }
/* 782:    */     }
/* 783:652 */     return findDependentSizeCount(getRDOInfoOrThrowException(name), qbe, whereClause, parentRDO);
/* 784:    */   }
/* 785:    */   
/* 786:    */   private int findDependentSizeCount(RDOInfo info, QBE qbe, MobileWhereClause whereClause, RDO parentRDO)
/* 787:    */     throws RDOException
/* 788:    */   {
/* 789:656 */     RDOInfo parentInfo = parentRDO.getInfo();
/* 790:657 */     RDODependentRelation depRelation = info.getDependentRelation();
/* 791:658 */     String query = this.sqliteHelper.buildComplexDependentCountQueryStatement(info, parentInfo, depRelation, parentRDO, qbe, whereClause, this);
/* 792:659 */     SQLiteCustomQueryStatement statement = new SQLiteCustomQueryStatement();
/* 793:660 */     Cursor cursor = null;
/* 794:    */     try
/* 795:    */     {
/* 796:662 */       this.logger.info(query);
/* 797:663 */       int bindIndex = 1;
/* 798:664 */       if (info.isHierarchical())
/* 799:    */       {
/* 800:665 */         this.logger.info("bind value for _OWNERID = " + parentRDO.getId());
/* 801:666 */         statement.bindLong(bindIndex, Long.valueOf(parentRDO.getId()));
/* 802:667 */         bindIndex++;
/* 803:    */       }
/* 804:670 */       else if (depRelation == null)
/* 805:    */       {
/* 806:671 */         this.logger.info("bind value for _PARENTID = " + parentRDO.getId());
/* 807:672 */         statement.bindLong(bindIndex, Long.valueOf(parentRDO.getId()));
/* 808:673 */         bindIndex++;
/* 809:    */       }
/* 810:    */       else
/* 811:    */       {
/* 812:675 */         bindIndex = this.sqliteHelper.bindDependentRelation(depRelation, parentRDO, statement, bindIndex);
/* 813:    */       }
/* 814:678 */       bindIndex = this.sqliteHelper.applyQBEBindings(info, qbe, statement, bindIndex);
/* 815:679 */       if (whereClause != null) {
/* 816:680 */         whereClause.applyParameters(new SQLiteStatementApplyParametersValueProcessor(statement, bindIndex, this.logger));
/* 817:    */       }
/* 818:682 */       cursor = this.dbManager.getDatabase().rawQuery(query, statement.toSelectionArgs());
/* 819:    */       int i;
/* 820:683 */       if (cursor.moveToNext()) {
/* 821:684 */         return cursor.getInt(0);
/* 822:    */       }
/* 823:686 */       return 0;
/* 824:    */     }
/* 825:    */     catch (Exception e)
/* 826:    */     {
/* 827:689 */       this.logger.error(e.getMessage(), e);
/* 828:690 */       throw new RDOException("rdofinddepsizefailed", new Object[] { parentRDO.getName(), info.getName() }, e);
/* 829:    */     }
/* 830:    */     finally
/* 831:    */     {
/* 832:692 */       SQLiteUtil.safelyCloseCursor(cursor, this.logger);
/* 833:    */     }
/* 834:    */   }
/* 835:    */   
/* 836:    */   public int getDependentsSize(String name, RDO parentRDO)
/* 837:    */     throws RDOException
/* 838:    */   {
/* 839:698 */     return getDependentsSize(name, null, parentRDO);
/* 840:    */   }
/* 841:    */   
/* 842:    */   public int getDependentsSize(String name, QBE filter, RDO parentRDO)
/* 843:    */     throws RDOException
/* 844:    */   {
/* 845:703 */     return getDependentsSize(name, filter, null, parentRDO);
/* 846:    */   }
/* 847:    */   
/* 848:    */   public void release()
/* 849:    */     throws RDOException
/* 850:    */   {
/* 851:708 */     this.dbManager.close();
/* 852:    */   }
/* 853:    */   
/* 854:    */   ArrayList<Long> getParentIdList(String query, QBE qbeFilter, String depName, SQLiteQBEDependentInfo dependentInfo)
/* 855:    */     throws RDOException
/* 856:    */   {
/* 857:712 */     SQLiteCustomQueryStatement statement = new SQLiteCustomQueryStatement();
/* 858:713 */     Cursor cursor = null;
/* 859:    */     try
/* 860:    */     {
/* 861:715 */       this.logger.info(query);
/* 862:716 */       this.sqliteHelper.applyDepQBEBindings(getRDOInfoOrThrowException(depName), qbeFilter, statement, 1, dependentInfo);
/* 863:717 */       cursor = this.dbManager.getDatabase().rawQuery(query, statement.toSelectionArgs());
/* 864:718 */       return this.sqliteHelper.buildParentIdList(cursor);
/* 865:    */     }
/* 866:    */     catch (Exception e)
/* 867:    */     {
/* 868:720 */       this.logger.warn("Could not get list of _PARENTID: " + e.getMessage(), e);
/* 869:721 */       return new ArrayList();
/* 870:    */     }
/* 871:    */     finally
/* 872:    */     {
/* 873:723 */       SQLiteUtil.safelyCloseCursor(cursor, this.logger);
/* 874:    */     }
/* 875:    */   }
/* 876:    */   
/* 877:    */   ArrayList<ConditionValue> getParentKeyList(RDOInfo depInfo, String query, QBE qbeFilter, SQLiteQBEDependentInfo dependentInfo)
/* 878:    */     throws RDOException
/* 879:    */   {
/* 880:728 */     SQLiteCustomQueryStatement statement = new SQLiteCustomQueryStatement();
/* 881:729 */     Cursor cursor = null;
/* 882:    */     try
/* 883:    */     {
/* 884:731 */       this.logger.info(query);
/* 885:732 */       this.sqliteHelper.applyDepQBEBindings(depInfo, qbeFilter, statement, 1, dependentInfo);
/* 886:733 */       cursor = this.dbManager.getDatabase().rawQuery(query, statement.toSelectionArgs());
/* 887:734 */       return this.sqliteHelper.buildConditionValueList(depInfo, cursor);
/* 888:    */     }
/* 889:    */     catch (Exception e)
/* 890:    */     {
/* 891:736 */       this.logger.warn("Could not get list of parent by key: " + e.getMessage(), e);
/* 892:737 */       return new ArrayList();
/* 893:    */     }
/* 894:    */     finally
/* 895:    */     {
/* 896:739 */       SQLiteUtil.safelyCloseCursor(cursor, this.logger);
/* 897:    */     }
/* 898:    */   }
/* 899:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.ibm.tivoli.maximo.mobile.android.persist.sqlite.SQLiteDBRDOManager
 * JD-Core Version:    0.7.0.1
 */