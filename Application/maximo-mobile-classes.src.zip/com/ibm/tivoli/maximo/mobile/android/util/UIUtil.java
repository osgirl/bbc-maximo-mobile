/*   1:    */ package com.ibm.tivoli.maximo.mobile.android.util;
/*   2:    */ 
/*   3:    */ import android.app.Activity;
/*   4:    */ import android.content.res.Resources;
/*   5:    */ import android.text.SpannableString;
/*   6:    */ import android.text.style.UnderlineSpan;
/*   7:    */ import android.util.DisplayMetrics;
/*   8:    */ import android.util.Log;
/*   9:    */ import android.view.View;
/*  10:    */ import android.view.ViewParent;
/*  11:    */ import android.widget.TextView;
/*  12:    */ import com.mro.mobile.ui.res.widgets.android.AndroidEnv;
/*  13:    */ import com.mro.mobile.ui.res.widgets.android.components.NPanel;
/*  14:    */ import com.mro.mobile.ui.res.widgets.android.components.NScrollPan;
/*  15:    */ import java.lang.reflect.Field;
/*  16:    */ 
/*  17:    */ public class UIUtil
/*  18:    */ {
/*  19:    */   public static int getResourceId(Class<?> clazz, String variableName)
/*  20:    */   {
/*  21: 21 */     Field field = null;
/*  22: 22 */     int resId = 0;
/*  23:    */     try
/*  24:    */     {
/*  25: 24 */       field = clazz.getField(variableName);
/*  26: 25 */       resId = field.getInt(null);
/*  27:    */     }
/*  28:    */     catch (Exception e)
/*  29:    */     {
/*  30: 27 */       Log.w("UIUTIL", "Could not resource id for: " + variableName + " in class " + clazz.getName());
/*  31:    */     }
/*  32: 30 */     if (resId == 0) {
/*  33: 31 */       Log.w("UIUTIL", "property key " + variableName + " not found for class: " + clazz.getName());
/*  34:    */     }
/*  35: 33 */     return resId;
/*  36:    */   }
/*  37:    */   
/*  38:    */   public static int getIntegerFromResource(Class<?> clazz, String variableName)
/*  39:    */   {
/*  40: 38 */     int resId = getResourceId(clazz, variableName);
/*  41: 39 */     return AndroidEnv.getCurrentActivity().getResources().getInteger(resId);
/*  42:    */   }
/*  43:    */   
/*  44:    */   public static void underline(TextView tv)
/*  45:    */   {
/*  46: 48 */     SpannableString content = new SpannableString(tv.getText().toString());
/*  47: 49 */     content.setSpan(new UnderlineSpan(), 0, content.length(), 0);
/*  48: 50 */     tv.setText(content);
/*  49:    */   }
/*  50:    */   
/*  51:    */   public static void bold(TextView tv)
/*  52:    */   {
/*  53: 54 */     tv.setTypeface(tv.getTypeface(), 1);
/*  54:    */   }
/*  55:    */   
/*  56:    */   public static void boldAndItalic(TextView tv)
/*  57:    */   {
/*  58: 58 */     tv.setTypeface(tv.getTypeface(), 3);
/*  59:    */   }
/*  60:    */   
/*  61:    */   public static void italic(TextView tv)
/*  62:    */   {
/*  63: 62 */     tv.setTypeface(tv.getTypeface(), 2);
/*  64:    */   }
/*  65:    */   
/*  66:    */   public static void moveChildrenToParent(NScrollPan pageScrollView)
/*  67:    */   {
/*  68: 71 */     ViewParent newPanel = pageScrollView.getParent();
/*  69: 72 */     if ((newPanel instanceof NPanel)) {
/*  70: 73 */       for (int i = 0; i < pageScrollView.getChildCount(); i++)
/*  71:    */       {
/*  72: 74 */         View child = pageScrollView.getChildAt(i);
/*  73: 75 */         pageScrollView.removeView(child);
/*  74: 76 */         ((NPanel)newPanel).addView(child, i);
/*  75:    */       }
/*  76:    */     }
/*  77:    */   }
/*  78:    */   
/*  79:    */   public static NScrollPan findHolderScrollPan(View candidate)
/*  80:    */   {
/*  81: 87 */     ViewParent parent = candidate.getParent();
/*  82: 88 */     while (parent != null)
/*  83:    */     {
/*  84: 89 */       if ((parent instanceof NScrollPan)) {
/*  85: 90 */         return (NScrollPan)parent;
/*  86:    */       }
/*  87: 92 */       parent = parent.getParent();
/*  88:    */     }
/*  89: 94 */     return null;
/*  90:    */   }
/*  91:    */   
/*  92:    */   public static int convertDIPtoPixels(int dip)
/*  93:    */   {
/*  94:101 */     float scale = AndroidEnv.getCurrentActivity().getResources().getDisplayMetrics().density;
/*  95:102 */     return (int)(dip * scale + 0.5F);
/*  96:    */   }
/*  97:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.ibm.tivoli.maximo.mobile.android.util.UIUtil
 * JD-Core Version:    0.7.0.1
 */