/*  1:   */ package com.ibm.tivoli.maximo.mobile.android.persist.sqlite;
/*  2:   */ 
/*  3:   */ import com.mro.mobile.persist.RDOEnumeration;
/*  4:   */ 
/*  5:   */ class EmptySQLiteDBRDOEnumeration
/*  6:   */   implements RDOEnumeration
/*  7:   */ {
/*  8:   */   public boolean hasMoreElements()
/*  9:   */   {
/* 10:12 */     return false;
/* 11:   */   }
/* 12:   */   
/* 13:   */   public Object nextElement()
/* 14:   */   {
/* 15:17 */     return null;
/* 16:   */   }
/* 17:   */   
/* 18:   */   public void release() {}
/* 19:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.ibm.tivoli.maximo.mobile.android.persist.sqlite.EmptySQLiteDBRDOEnumeration
 * JD-Core Version:    0.7.0.1
 */