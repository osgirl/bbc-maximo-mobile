/*  1:   */ package com.ibm.tivoli.maximo.mobile.android.sensor.barcode.datawedge;
/*  2:   */ 
/*  3:   */ import android.content.BroadcastReceiver;
/*  4:   */ import android.content.Context;
/*  5:   */ import android.content.Intent;
/*  6:   */ import android.content.IntentFilter;
/*  7:   */ import com.ibm.tivoli.maximo.mobile.android.DefaultMaximoMobileActivity;
/*  8:   */ import com.mro.mobile.MobileApplicationException;
/*  9:   */ import com.mro.mobile.sensor.barcode.AbstractBarcodeReader;
/* 10:   */ import com.mro.mobile.sensor.barcode.MobileBarcodeEvent;
/* 11:   */ import com.mro.mobile.sensor.barcode.MobileBarcodeReader;
/* 12:   */ import com.mro.mobile.ui.res.widgets.android.AndroidEnv;
/* 13:   */ import com.mro.mobile.util.StringUtils;
/* 14:   */ 
/* 15:   */ public class AndroidDataWedgeBarcodeReader
/* 16:   */   extends AbstractBarcodeReader
/* 17:   */   implements MobileBarcodeReader
/* 18:   */ {
/* 19:   */   public static final String MOTOROLA_DATAWEDGE_ACTION_FOUND = "com.ibm.maximo.mobile.android.datawedge.action.FOUND";
/* 20:   */   private static final String DATA_STRING_TAG = "com.motorolasolutions.emdk.datawedge.data_string";
/* 21:32 */   private BroadcastReceiver mReceiver = null;
/* 22:   */   
/* 23:   */   public void initialize()
/* 24:   */     throws MobileApplicationException
/* 25:   */   {
/* 26:36 */     this.mReceiver = new BroadcastReceiver()
/* 27:   */     {
/* 28:   */       public void onReceive(Context context, Intent intent)
/* 29:   */       {
/* 30:38 */         String action = intent.getAction();
/* 31:39 */         if (!"com.ibm.maximo.mobile.android.datawedge.action.FOUND".equals(action)) {
/* 32:40 */           return;
/* 33:   */         }
/* 34:46 */         String data = intent.getStringExtra("com.motorolasolutions.emdk.datawedge.data_string");
/* 35:47 */         if (StringUtils.isStringEmpty(data))
/* 36:   */         {
/* 37:48 */           MobileApplicationException ex = new MobileApplicationException("Got empty bar code from datawedge");
/* 38:49 */           MobileBarcodeEvent e = new MobileBarcodeEvent(ex);
/* 39:50 */           AndroidDataWedgeBarcodeReader.this.fireBarcodeReadErrorEvent(e);
/* 40:51 */           return;
/* 41:   */         }
/* 42:54 */         MobileBarcodeEvent e = new MobileBarcodeEvent(intent, data);
/* 43:55 */         AndroidDataWedgeBarcodeReader.this.fireBarcodeReadSuccessEvent(e);
/* 44:   */       }
/* 45:   */     };
/* 46:   */   }
/* 47:   */   
/* 48:   */   public void startScan()
/* 49:   */     throws MobileApplicationException
/* 50:   */   {
/* 51:62 */     IntentFilter filter = new IntentFilter("com.ibm.maximo.mobile.android.datawedge.action.FOUND");
/* 52:63 */     AndroidEnv.getCurrentActivityAsMobileActivity().registerReceiver(this.mReceiver, filter);
/* 53:   */   }
/* 54:   */   
/* 55:   */   public void stopScan()
/* 56:   */     throws MobileApplicationException
/* 57:   */   {
/* 58:68 */     AndroidEnv.getCurrentActivityAsMobileActivity().unregisterReceiver(this.mReceiver);
/* 59:   */   }
/* 60:   */   
/* 61:   */   public void release()
/* 62:   */     throws MobileApplicationException
/* 63:   */   {}
/* 64:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.ibm.tivoli.maximo.mobile.android.sensor.barcode.datawedge.AndroidDataWedgeBarcodeReader
 * JD-Core Version:    0.7.0.1
 */