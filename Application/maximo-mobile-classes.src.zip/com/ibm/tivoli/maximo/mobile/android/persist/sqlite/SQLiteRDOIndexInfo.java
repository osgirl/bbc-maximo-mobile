/*  1:   */ package com.ibm.tivoli.maximo.mobile.android.persist.sqlite;
/*  2:   */ 
/*  3:   */ import java.util.Arrays;
/*  4:   */ 
/*  5:   */ public class SQLiteRDOIndexInfo
/*  6:   */ {
/*  7:   */   private String indexName;
/*  8:   */   private String rdoName;
/*  9:   */   private String[] colNames;
/* 10:   */   
/* 11:   */   public SQLiteRDOIndexInfo(String indexName, String rdoName, String[] colNames)
/* 12:   */   {
/* 13:13 */     this.indexName = indexName;
/* 14:14 */     this.rdoName = rdoName;
/* 15:15 */     this.colNames = safeCopy(colNames);
/* 16:   */   }
/* 17:   */   
/* 18:   */   private String[] safeCopy(String[] cols)
/* 19:   */   {
/* 20:19 */     String[] array = null;
/* 21:20 */     if (cols != null)
/* 22:   */     {
/* 23:21 */       array = new String[cols.length];
/* 24:22 */       for (int i = 0; i < array.length; i++) {
/* 25:22 */         array[i] = cols[i].replaceAll("\"", "");
/* 26:   */       }
/* 27:   */     }
/* 28:24 */     return array;
/* 29:   */   }
/* 30:   */   
/* 31:   */   public String getIndexName()
/* 32:   */   {
/* 33:28 */     return this.indexName;
/* 34:   */   }
/* 35:   */   
/* 36:   */   public String[] getColNames()
/* 37:   */   {
/* 38:32 */     return this.colNames;
/* 39:   */   }
/* 40:   */   
/* 41:   */   public String getRDOName()
/* 42:   */   {
/* 43:36 */     return this.rdoName;
/* 44:   */   }
/* 45:   */   
/* 46:   */   public int hashCode()
/* 47:   */   {
/* 48:41 */     int prime = 31;
/* 49:42 */     int result = 1;
/* 50:43 */     result = 31 * result + Arrays.hashCode(this.colNames);
/* 51:44 */     result = 31 * result + (this.indexName == null ? 0 : this.indexName.hashCode());
/* 52:   */     
/* 53:46 */     result = 31 * result + (this.rdoName == null ? 0 : this.rdoName.hashCode());
/* 54:47 */     return result;
/* 55:   */   }
/* 56:   */   
/* 57:   */   public boolean equals(Object obj)
/* 58:   */   {
/* 59:52 */     if (this == obj) {
/* 60:53 */       return true;
/* 61:   */     }
/* 62:54 */     if (obj == null) {
/* 63:55 */       return false;
/* 64:   */     }
/* 65:56 */     if (getClass() != obj.getClass()) {
/* 66:57 */       return false;
/* 67:   */     }
/* 68:58 */     SQLiteRDOIndexInfo other = (SQLiteRDOIndexInfo)obj;
/* 69:59 */     if (!Arrays.equals(this.colNames, other.colNames)) {
/* 70:60 */       return false;
/* 71:   */     }
/* 72:61 */     if (this.indexName == null)
/* 73:   */     {
/* 74:62 */       if (other.indexName != null) {
/* 75:63 */         return false;
/* 76:   */       }
/* 77:   */     }
/* 78:64 */     else if (!this.indexName.equals(other.indexName)) {
/* 79:65 */       return false;
/* 80:   */     }
/* 81:66 */     if (this.rdoName == null)
/* 82:   */     {
/* 83:67 */       if (other.rdoName != null) {
/* 84:68 */         return false;
/* 85:   */       }
/* 86:   */     }
/* 87:69 */     else if (!this.rdoName.equals(other.rdoName)) {
/* 88:70 */       return false;
/* 89:   */     }
/* 90:71 */     return true;
/* 91:   */   }
/* 92:   */   
/* 93:   */   public String toString()
/* 94:   */   {
/* 95:76 */     return "SQLiteIndexInfo [indexName=" + this.indexName + ", rdoName=" + this.rdoName + ", colNames=" + Arrays.toString(this.colNames) + "]";
/* 96:   */   }
/* 97:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.ibm.tivoli.maximo.mobile.android.persist.sqlite.SQLiteRDOIndexInfo
 * JD-Core Version:    0.7.0.1
 */