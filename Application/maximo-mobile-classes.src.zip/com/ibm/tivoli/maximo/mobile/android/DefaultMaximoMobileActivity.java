/*   1:    */ package com.ibm.tivoli.maximo.mobile.android;
/*   2:    */ 
/*   3:    */ import android.app.Activity;
/*   4:    */ import android.content.Intent;
/*   5:    */ import android.os.Bundle;
/*   6:    */ import android.view.KeyEvent;
/*   7:    */ import android.view.LayoutInflater;
/*   8:    */ import android.view.Menu;
/*   9:    */ import android.view.MenuItem;
/*  10:    */ import android.view.MotionEvent;
/*  11:    */ import android.view.View;
/*  12:    */ import android.view.ViewGroup;
/*  13:    */ import android.view.Window;
/*  14:    */ import android.widget.FrameLayout;
/*  15:    */ import android.widget.TextView;
/*  16:    */ import com.ibm.tivoli.maximo.mobile.android.camera.AndroidIntentCameraCallback;
/*  17:    */ import com.ibm.tivoli.maximo.mobile.android.sensor.AndroidIntentBarcodeReader;
/*  18:    */ import com.ibm.tivoli.maximo.mobile.android.util.MenuUtil;
/*  19:    */ import com.ibm.tivoli.maximo.mobile.entrypoint.android.ActivityLifecycleListener;
/*  20:    */ import com.ibm.tivoli.maximo.mobile.entrypoint.android.AndroidMobileAppEntryPoint;
/*  21:    */ import com.ibm.tivoli.maximo.mobile.resources.R.id;
/*  22:    */ import com.ibm.tivoli.maximo.mobile.resources.R.layout;
/*  23:    */ import com.mro.mobile.MobileApplicationException;
/*  24:    */ import com.mro.mobile.app.AppEventHandler;
/*  25:    */ import com.mro.mobile.app.BasicMobileDeviceUIApplication;
/*  26:    */ import com.mro.mobile.app.MobileDeviceAppSession;
/*  27:    */ import com.mro.mobile.app.SystemInterface;
/*  28:    */ import com.mro.mobile.ui.res.controls.AbstractMobileControl;
/*  29:    */ import com.mro.mobile.ui.res.widgets.android.components.NTextField;
/*  30:    */ import com.mro.mobile.ui.res.widgets.def.UIComponent;
/*  31:    */ import com.mro.mobile.util.MobileLogger;
/*  32:    */ import com.mro.mobile.util.MobileLoggerFactory;
/*  33:    */ 
/*  34:    */ public class DefaultMaximoMobileActivity
/*  35:    */   extends Activity
/*  36:    */ {
/*  37:    */   private static final int BARCODE_INTENT_REQUESTID = 1000;
/*  38:    */   private static final int CAMERA_INTENT_REQUESTID = 2000;
/*  39: 36 */   private AndroidIntentBarcodeReader barcodeReaderCallback = null;
/*  40: 38 */   private ActivityLifecycleListener activityLifecycleListener = null;
/*  41: 40 */   private AndroidIntentCameraCallback cameraCallback = null;
/*  42:    */   
/*  43:    */   protected ActivityLifecycleListener getActivityLifecycleListener()
/*  44:    */   {
/*  45: 43 */     return this.activityLifecycleListener;
/*  46:    */   }
/*  47:    */   
/*  48:    */   protected void onCreate(Bundle savedInstanceState)
/*  49:    */   {
/*  50: 47 */     super.onCreate(savedInstanceState);
/*  51:    */     
/*  52:    */ 
/*  53: 50 */     getWindow().requestFeature(1);
/*  54:    */     
/*  55: 52 */     this.activityLifecycleListener = getActivityListener();
/*  56: 53 */     this.activityLifecycleListener.onActivityCreated(this, savedInstanceState);
/*  57: 55 */     if (callToPostLaunchNeeded()) {
/*  58:    */       try
/*  59:    */       {
/*  60: 57 */         getApplicationEntryPoint().postLaunchMaximoMobile();
/*  61:    */       }
/*  62:    */       catch (MobileApplicationException e)
/*  63:    */       {
/*  64: 59 */         com.mro.mobile.ui.res.UIUtil.showFailureMessageBox(e.getCompleteMessage());
/*  65: 60 */         MobileLoggerFactory.getDefaultLogger().warn("Error encountered during post launch", e);
/*  66:    */       }
/*  67:    */     }
/*  68:    */   }
/*  69:    */   
/*  70:    */   public void setTitle(CharSequence title)
/*  71:    */   {
/*  72: 67 */     TextView tv = (TextView)findViewById(16908310);
/*  73: 68 */     tv.setText(title);
/*  74:    */   }
/*  75:    */   
/*  76:    */   public void setContentView(View view)
/*  77:    */   {
/*  78: 75 */     ViewGroup pageLayout = (ViewGroup)getLayoutInflater().inflate(com.ibm.tivoli.maximo.mobile.android.util.UIUtil.getResourceId(R.layout.class, "page_layout"), null);
/*  79: 76 */     FrameLayout contentRoot = (FrameLayout)pageLayout.findViewById(com.ibm.tivoli.maximo.mobile.android.util.UIUtil.getResourceId(R.id.class, "content_root"));
/*  80: 77 */     if (view.getParent() != null) {
/*  81: 78 */       ((ViewGroup)view.getParent()).removeView(view);
/*  82:    */     }
/*  83: 80 */     contentRoot.removeAllViews();
/*  84: 81 */     contentRoot.addView(view);
/*  85:    */     
/*  86: 83 */     super.setContentView(pageLayout);
/*  87:    */   }
/*  88:    */   
/*  89:    */   protected boolean callToPostLaunchNeeded()
/*  90:    */   {
/*  91: 87 */     boolean result = getIntent().getBooleanExtra("MAXIMO_MOBILE_NEED_POST_LAUNCH", false);
/*  92: 88 */     getIntent().removeExtra("MAXIMO_MOBILE_NEED_POST_LAUNCH");
/*  93: 89 */     return result;
/*  94:    */   }
/*  95:    */   
/*  96:    */   protected ActivityLifecycleListener getActivityListener()
/*  97:    */   {
/*  98: 93 */     return (ActivityLifecycleListener)getApplication();
/*  99:    */   }
/* 100:    */   
/* 101:    */   protected AndroidMobileAppEntryPoint<?> getApplicationEntryPoint()
/* 102:    */   {
/* 103: 97 */     return (AndroidMobileAppEntryPoint)getApplication();
/* 104:    */   }
/* 105:    */   
/* 106:    */   protected void onDestroy()
/* 107:    */   {
/* 108:101 */     super.onDestroy();
/* 109:102 */     this.activityLifecycleListener.onActivityDestroyed(this);
/* 110:    */   }
/* 111:    */   
/* 112:    */   protected void onStart()
/* 113:    */   {
/* 114:106 */     super.onStart();
/* 115:107 */     this.activityLifecycleListener.onActivityStarted(this);
/* 116:    */   }
/* 117:    */   
/* 118:    */   protected void onStop()
/* 119:    */   {
/* 120:111 */     super.onStop();
/* 121:112 */     this.activityLifecycleListener.onActivityStopped(this);
/* 122:    */   }
/* 123:    */   
/* 124:    */   protected void onResume()
/* 125:    */   {
/* 126:116 */     super.onResume();
/* 127:117 */     this.activityLifecycleListener.onActivityResumed(this);
/* 128:    */   }
/* 129:    */   
/* 130:    */   protected void onPause()
/* 131:    */   {
/* 132:121 */     super.onPause();
/* 133:122 */     this.activityLifecycleListener.onActivityPaused(this);
/* 134:    */   }
/* 135:    */   
/* 136:    */   public void onBackPressed()
/* 137:    */   {
/* 138:    */     try
/* 139:    */     {
/* 140:128 */       if (com.mro.mobile.ui.res.UIUtil.getActiveScreensCount() > 1)
/* 141:    */       {
/* 142:129 */         com.mro.mobile.ui.res.UIUtil.cancelPage();
/* 143:    */       }
/* 144:131 */       else if (isLoginScreenOnTop())
/* 145:    */       {
/* 146:132 */         getApplicationEntryPoint().getMaximoMobileApplication().getSystemInterface().exitSystem();
/* 147:    */       }
/* 148:133 */       else if (isStartCenterOnTop())
/* 149:    */       {
/* 150:134 */         com.mro.mobile.ui.res.UIUtil.handleEvent("exit");
/* 151:    */       }
/* 152:    */       else
/* 153:    */       {
/* 154:137 */         com.mro.mobile.ui.res.UIUtil.cancelPageWithoutRemove();
/* 155:138 */         MobileDeviceAppSession.getSession().getUIEventHandlerAsAppEventHandler().startcenter(null);
/* 156:    */       }
/* 157:    */     }
/* 158:    */     catch (MobileApplicationException e)
/* 159:    */     {
/* 160:142 */       com.mro.mobile.ui.res.UIUtil.showFailureMessageBox(e.getCompleteMessage());
/* 161:143 */       MobileLoggerFactory.getDefaultLogger().warn("Error encountered handling back press", e);
/* 162:    */     }
/* 163:    */   }
/* 164:    */   
/* 165:    */   protected boolean isStartCenterOnTop()
/* 166:    */   {
/* 167:148 */     String id = MobileDeviceAppSession.getSession().getApplicationAsUIApplication().getStartupScreenId();
/* 168:149 */     return (com.mro.mobile.ui.res.UIUtil.getCurrentScreen() != null) && (com.mro.mobile.ui.res.UIUtil.getCurrentScreen().getId().equals(id));
/* 169:    */   }
/* 170:    */   
/* 171:    */   protected boolean isLoginScreenOnTop()
/* 172:    */   {
/* 173:153 */     return (com.mro.mobile.ui.res.UIUtil.getCurrentScreen() != null) && (com.mro.mobile.ui.res.UIUtil.getCurrentScreen().getId().indexOf("login") >= 0);
/* 174:    */   }
/* 175:    */   
/* 176:    */   protected void onSaveInstanceState(Bundle outState)
/* 177:    */   {
/* 178:157 */     super.onSaveInstanceState(outState);
/* 179:158 */     this.activityLifecycleListener.onActivitySaveInstanceState(this, outState);
/* 180:    */   }
/* 181:    */   
/* 182:    */   public boolean dispatchKeyEvent(KeyEvent event)
/* 183:    */   {
/* 184:163 */     return super.dispatchKeyEvent(event);
/* 185:    */   }
/* 186:    */   
/* 187:    */   public boolean dispatchTouchEvent(MotionEvent ev)
/* 188:    */   {
/* 189:168 */     if ((1 == ev.getAction()) && 
/* 190:169 */       (notifyFocusLost())) {
/* 191:170 */       return true;
/* 192:    */     }
/* 193:173 */     return super.dispatchTouchEvent(ev);
/* 194:    */   }
/* 195:    */   
/* 196:    */   protected boolean notifyFocusLost()
/* 197:    */   {
/* 198:177 */     View focusOwner = getCurrentFocus();
/* 199:178 */     if ((focusOwner instanceof NTextField))
/* 200:    */     {
/* 201:179 */       NTextField field = (NTextField)focusOwner;
/* 202:180 */       AbstractMobileControl ctrl = ((UIComponent)focusOwner).getController();
/* 203:181 */       boolean send = (ctrl == null) || (!ctrl.isCancelEvent());
/* 204:182 */       if ((send) && 
/* 205:183 */         (!field.sendSetValue())) {
/* 206:184 */         return true;
/* 207:    */       }
/* 208:    */     }
/* 209:188 */     return false;
/* 210:    */   }
/* 211:    */   
/* 212:    */   public boolean onPrepareOptionsMenu(Menu menu)
/* 213:    */   {
/* 214:192 */     if (!notifyFocusLost()) {
/* 215:193 */       MenuUtil.buildTopLevelOptionsMenu(menu);
/* 216:    */     }
/* 217:195 */     return true;
/* 218:    */   }
/* 219:    */   
/* 220:    */   public boolean onOptionsItemSelected(MenuItem item)
/* 221:    */   {
/* 222:199 */     MenuUtil.handleTopLevelOptionsMenuSelected(this, item);
/* 223:200 */     return true;
/* 224:    */   }
/* 225:    */   
/* 226:    */   public void startBarcodeActivityForResult(Intent intent, AndroidIntentBarcodeReader reader)
/* 227:    */   {
/* 228:204 */     this.barcodeReaderCallback = reader;
/* 229:205 */     startActivityForResult(intent, 1000);
/* 230:    */   }
/* 231:    */   
/* 232:    */   protected void onActivityResult(int requestCode, int resultCode, Intent intent)
/* 233:    */   {
/* 234:    */     try
/* 235:    */     {
/* 236:211 */       if ((requestCode == 1000) && 
/* 237:212 */         (this.barcodeReaderCallback != null))
/* 238:    */       {
/* 239:213 */         this.barcodeReaderCallback.callbackIntentResult(resultCode, intent);
/* 240:214 */         this.barcodeReaderCallback = null;
/* 241:    */       }
/* 242:217 */       if ((requestCode == 2000) && 
/* 243:218 */         (this.cameraCallback != null))
/* 244:    */       {
/* 245:219 */         this.cameraCallback.callbackIntentResult(resultCode, intent);
/* 246:220 */         this.cameraCallback = null;
/* 247:    */       }
/* 248:    */     }
/* 249:    */     catch (MobileApplicationException e)
/* 250:    */     {
/* 251:224 */       com.mro.mobile.ui.res.UIUtil.showFailureMessageBox(e.getCompleteMessage());
/* 252:225 */       MobileLoggerFactory.getDefaultLogger().error("Error receiving intent callback", e);
/* 253:    */     }
/* 254:    */   }
/* 255:    */   
/* 256:    */   public void startCameraActivityForResult(Intent intent, AndroidIntentCameraCallback camera)
/* 257:    */   {
/* 258:230 */     this.cameraCallback = camera;
/* 259:231 */     startActivityForResult(intent, 2000);
/* 260:    */   }
/* 261:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.ibm.tivoli.maximo.mobile.android.DefaultMaximoMobileActivity
 * JD-Core Version:    0.7.0.1
 */