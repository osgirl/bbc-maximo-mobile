/*   1:    */ package com.ibm.tivoli.maximo.mobile.android.persist.sqlite;
/*   2:    */ 
/*   3:    */ import android.database.Cursor;
/*   4:    */ import android.database.sqlite.SQLiteDatabase;
/*   5:    */ import android.database.sqlite.SQLiteStatement;
/*   6:    */ import com.mro.mobile.persist.RDOAttributeInfo;
/*   7:    */ import com.mro.mobile.persist.RDOException;
/*   8:    */ import com.mro.mobile.persist.RDOInfo;
/*   9:    */ import com.mro.mobile.persist.RDOInfoManager;
/*  10:    */ import com.mro.mobile.persist.RDOInfoSerializer;
/*  11:    */ import com.mro.mobile.util.MobileLogger;
/*  12:    */ import java.io.ByteArrayInputStream;
/*  13:    */ import java.io.ByteArrayOutputStream;
/*  14:    */ import java.io.DataInputStream;
/*  15:    */ import java.io.DataOutputStream;
/*  16:    */ import java.io.IOException;
/*  17:    */ import java.util.ArrayList;
/*  18:    */ import java.util.Enumeration;
/*  19:    */ import java.util.HashMap;
/*  20:    */ import java.util.List;
/*  21:    */ import java.util.Map;
/*  22:    */ import java.util.Vector;
/*  23:    */ 
/*  24:    */ public class SQLiteDBRDOInfoManager
/*  25:    */   implements RDOInfoManager
/*  26:    */ {
/*  27:    */   private SQLiteDBManager dbManager;
/*  28:    */   private MobileLogger logger;
/*  29: 36 */   private Map<String, RDOInfo> rdoInfoMap = new HashMap();
/*  30: 38 */   private Map<String, SQLiteRDOIndexInfo> rdoIndexMap = new HashMap();
/*  31:    */   
/*  32:    */   public SQLiteDBRDOInfoManager(SQLiteDBManager dbManager, MobileLogger logger)
/*  33:    */   {
/*  34: 41 */     ensureArgumentsAreValid(dbManager, logger);
/*  35: 42 */     this.dbManager = dbManager;
/*  36: 43 */     this.logger = logger;
/*  37:    */   }
/*  38:    */   
/*  39:    */   protected void ensureArgumentsAreValid(SQLiteDBManager dbManager, MobileLogger logger)
/*  40:    */   {
/*  41: 47 */     if (dbManager == null) {
/*  42: 47 */       throw new IllegalArgumentException("DB Manager cannot be null.");
/*  43:    */     }
/*  44: 48 */     if (logger == null) {
/*  45: 48 */       throw new IllegalArgumentException("Logger cannot be null.");
/*  46:    */     }
/*  47:    */   }
/*  48:    */   
/*  49:    */   public void registerInfo(String name, RDOInfo info)
/*  50:    */     throws RDOException
/*  51:    */   {
/*  52: 53 */     if (!infoExists(name))
/*  53:    */     {
/*  54: 54 */       insertIntoRDOInfo(name, info);
/*  55: 55 */       createTable(name, info);
/*  56: 56 */       createIndexesForObject(name, info);
/*  57: 57 */       registerInCache(name, info);
/*  58:    */     }
/*  59:    */   }
/*  60:    */   
/*  61:    */   protected void registerInCache(String name, RDOInfo info)
/*  62:    */   {
/*  63: 62 */     this.rdoInfoMap.put(name, info);
/*  64:    */   }
/*  65:    */   
/*  66:    */   protected void createTable(String name, RDOInfo info)
/*  67:    */     throws RDOException
/*  68:    */   {
/*  69: 66 */     String statement = buildCreateTableStatement(name, info);
/*  70: 67 */     this.logger.info(statement);
/*  71:    */     try
/*  72:    */     {
/*  73: 69 */       this.dbManager.getDatabase().execSQL(statement);
/*  74:    */     }
/*  75:    */     catch (Exception e)
/*  76:    */     {
/*  77: 71 */       this.logger.error(e.getMessage(), e);
/*  78: 72 */       throw new RDOException("rdodefcreatefailed", new Object[] { info.getName() }, e);
/*  79:    */     }
/*  80:    */   }
/*  81:    */   
/*  82:    */   protected String buildCreateTableStatement(String name, RDOInfo info)
/*  83:    */   {
/*  84: 77 */     String stmt = "CREATE TABLE %s (%s)";
/*  85: 78 */     StringBuilder builder = new StringBuilder(" ");
/*  86: 79 */     for (String attribute : info.getAttributeNames())
/*  87:    */     {
/*  88: 80 */       RDOAttributeInfo attrInfo = info.getAttributeInfo(attribute);
/*  89: 81 */       if (attrInfo.isPersistent())
/*  90:    */       {
/*  91: 84 */         builder.append(format(attribute));
/*  92: 85 */         builder.append(" ");
/*  93: 86 */         builder.append(getSQLDataType(attrInfo.getDataType(), attrInfo.getLength(), attrInfo.getScale()));
/*  94:    */         
/*  95: 88 */         builder.append((attrInfo.isKey()) && (attrInfo.getName().equals("_ID")) ? " NOT NULL," : ",");
/*  96:    */       }
/*  97:    */     }
/*  98: 90 */     builder.deleteCharAt(builder.length() - 1);
/*  99: 91 */     return String.format(stmt, new Object[] { name, builder.toString() });
/* 100:    */   }
/* 101:    */   
/* 102:    */   protected void createIndexesForObject(String name, RDOInfo info)
/* 103:    */     throws RDOException
/* 104:    */   {
/* 105: 95 */     createIndexForOwner(name, info);
/* 106: 96 */     createIndexForId(name, info);
/* 107: 97 */     createIndexForPairDoneErr(name, info);
/* 108: 98 */     createIndexForErr(name, info);
/* 109: 99 */     createIndexForDone(name, info);
/* 110:100 */     createIndexForUniqueKey(name, info);
/* 111:    */   }
/* 112:    */   
/* 113:    */   protected void createIndexForOwner(String name, RDOInfo info)
/* 114:    */     throws RDOException
/* 115:    */   {
/* 116:104 */     if (info.isHierarchical()) {
/* 117:105 */       createIndex(name + "NDX", name, new String[] { "_OWNERID" }, false);
/* 118:    */     }
/* 119:    */   }
/* 120:    */   
/* 121:    */   protected void createIndexForId(String name, RDOInfo info)
/* 122:    */     throws RDOException
/* 123:    */   {
/* 124:110 */     if (info.hasAttribute("_ID")) {
/* 125:111 */       if (info.hasAttribute("_PARENTID")) {
/* 126:112 */         createIndex(name + "NDXID", name, new String[] { "_ID", "_PARENTID" }, false);
/* 127:    */       } else {
/* 128:114 */         createIndex(name + "NDXID", name, new String[] { "_ID" }, false);
/* 129:    */       }
/* 130:    */     }
/* 131:    */   }
/* 132:    */   
/* 133:    */   protected void createIndexForPairDoneErr(String name, RDOInfo info)
/* 134:    */     throws RDOException
/* 135:    */   {
/* 136:120 */     if ((info.hasAttribute("_DONE")) && (info.hasAttribute("_ERR"))) {
/* 137:121 */       createIndex("_IDXT01" + name, name, new String[] { "_ERR", "_DONE" }, false);
/* 138:    */     }
/* 139:    */   }
/* 140:    */   
/* 141:    */   protected void createIndexForErr(String name, RDOInfo info)
/* 142:    */     throws RDOException
/* 143:    */   {
/* 144:126 */     if (info.hasAttribute("_ERR")) {
/* 145:127 */       createIndexSafely("_IDXT02" + name, name, new String[] { "_ERR" }, false);
/* 146:    */     }
/* 147:    */   }
/* 148:    */   
/* 149:    */   protected void createIndexForDone(String name, RDOInfo info)
/* 150:    */     throws RDOException
/* 151:    */   {
/* 152:132 */     if (info.hasAttribute("_DONE")) {
/* 153:133 */       createIndexSafely("_IDXT03" + name, name, new String[] { "_DONE" }, false);
/* 154:    */     }
/* 155:    */   }
/* 156:    */   
/* 157:    */   protected void createIndexForUniqueKey(String name, RDOInfo info)
/* 158:    */     throws RDOException
/* 159:    */   {
/* 160:138 */     List<String> primaryKey = new ArrayList();
/* 161:139 */     for (String attribute : info.getKeyAttributeNames())
/* 162:    */     {
/* 163:140 */       RDOAttributeInfo attrInfo = info.getAttributeInfo(attribute);
/* 164:141 */       if ((attrInfo.isPersistent()) && (!attribute.equalsIgnoreCase("_ID"))) {
/* 165:142 */         primaryKey.add(attribute);
/* 166:    */       }
/* 167:    */     }
/* 168:145 */     if (!primaryKey.isEmpty()) {
/* 169:146 */       createIndexSafely(name + "NDXK", name, (String[])primaryKey.toArray(SQLiteUtil.EMPTY_STRING_ARRAY), false);
/* 170:    */     }
/* 171:    */   }
/* 172:    */   
/* 173:    */   protected void createIndexSafely(String indexName, String objectName, String[] columns, boolean userDefined)
/* 174:    */     throws RDOException
/* 175:    */   {
/* 176:151 */     boolean needToCreate = true;
/* 177:152 */     SQLiteRDOIndexInfo candidate = new SQLiteRDOIndexInfo(indexName, objectName, columns);
/* 178:153 */     if ((userDefined) && 
/* 179:154 */       (indexInfoExistsInCache(indexName)))
/* 180:    */     {
/* 181:155 */       SQLiteRDOIndexInfo indexInfo = getFromIndexCache(indexName);
/* 182:156 */       if (indexInfo.equals(candidate)) {
/* 183:157 */         needToCreate = false;
/* 184:    */       } else {
/* 185:159 */         dropIndex(indexName);
/* 186:    */       }
/* 187:    */     }
/* 188:163 */     if (needToCreate)
/* 189:    */     {
/* 190:164 */       doIndexCreation(candidate.getIndexName(), candidate.getRDOName(), candidate.getColNames());
/* 191:165 */       if (userDefined)
/* 192:    */       {
/* 193:166 */         insertIntoIndexInfo(candidate);
/* 194:167 */         registerInIndexCache(indexName, candidate);
/* 195:    */       }
/* 196:    */     }
/* 197:    */   }
/* 198:    */   
/* 199:    */   protected void doIndexCreation(String indexName, String objectName, String[] columns)
/* 200:    */     throws RDOException
/* 201:    */   {
/* 202:173 */     String statement = buildCreateIndexStatement(indexName, objectName, columns);
/* 203:174 */     this.logger.info(statement);
/* 204:    */     try
/* 205:    */     {
/* 206:176 */       this.dbManager.getDatabase().execSQL(statement);
/* 207:    */     }
/* 208:    */     catch (Exception e)
/* 209:    */     {
/* 210:178 */       this.logger.error(e.getMessage(), e);
/* 211:179 */       throw new RDOException("rdodefcreateindexfailed", new Object[] { indexName }, e);
/* 212:    */     }
/* 213:    */   }
/* 214:    */   
/* 215:    */   protected SQLiteRDOIndexInfo getFromIndexCache(String indexName)
/* 216:    */   {
/* 217:184 */     return (SQLiteRDOIndexInfo)this.rdoIndexMap.get(indexName);
/* 218:    */   }
/* 219:    */   
/* 220:    */   protected void registerInIndexCache(String indexName, SQLiteRDOIndexInfo candidate)
/* 221:    */   {
/* 222:188 */     this.rdoIndexMap.put(indexName, candidate);
/* 223:    */   }
/* 224:    */   
/* 225:    */   protected boolean indexInfoExistsInCache(String indexName)
/* 226:    */   {
/* 227:192 */     if (this.rdoIndexMap.isEmpty()) {
/* 228:193 */       loadIndexCache();
/* 229:    */     }
/* 230:195 */     return this.rdoIndexMap.containsKey(indexName);
/* 231:    */   }
/* 232:    */   
/* 233:    */   protected void loadIndexCache()
/* 234:    */   {
/* 235:199 */     String statement = "SELECT NAME, RDONAME, COLNAME, COLORDER FROM RDOINDEXINFO ORDER BY NAME";
/* 236:200 */     this.logger.info(statement);
/* 237:201 */     Cursor cursor = null;
/* 238:    */     try
/* 239:    */     {
/* 240:203 */       cursor = this.dbManager.getDatabase().rawQuery(statement, SQLiteUtil.EMPTY_STRING_ARRAY);
/* 241:204 */       this.rdoIndexMap = getAllIndexData(cursor);
/* 242:    */     }
/* 243:    */     catch (Exception e)
/* 244:    */     {
/* 245:206 */       this.logger.error("Could not load index cache: " + e.getMessage(), e);
/* 246:    */     }
/* 247:    */     finally
/* 248:    */     {
/* 249:208 */       SQLiteUtil.safelyCloseCursor(cursor, this.logger);
/* 250:    */     }
/* 251:    */   }
/* 252:    */   
/* 253:    */   protected Map<String, SQLiteRDOIndexInfo> getAllIndexData(Cursor cursor)
/* 254:    */   {
/* 255:213 */     String previousName = null;
/* 256:214 */     String indexName = "";
/* 257:215 */     String rdoName = "";
/* 258:216 */     List<String> columns = new ArrayList();
/* 259:217 */     Map<String, SQLiteRDOIndexInfo> map = new HashMap();
/* 260:218 */     while (cursor.moveToNext())
/* 261:    */     {
/* 262:219 */       indexName = cursor.getString(cursor.getColumnIndex("NAME"));
/* 263:220 */       if ((previousName != null) && (!indexName.equalsIgnoreCase(previousName)))
/* 264:    */       {
/* 265:221 */         map.put(previousName, new SQLiteRDOIndexInfo(previousName, rdoName, (String[])columns.toArray(SQLiteUtil.EMPTY_STRING_ARRAY)));
/* 266:222 */         columns = new ArrayList();
/* 267:    */       }
/* 268:224 */       columns.add(cursor.getString(cursor.getColumnIndex("COLNAME")));
/* 269:225 */       rdoName = cursor.getString(cursor.getColumnIndex("RDONAME"));
/* 270:226 */       previousName = indexName;
/* 271:    */     }
/* 272:228 */     if (columns.size() > 0) {
/* 273:229 */       map.put(previousName, new SQLiteRDOIndexInfo(indexName, rdoName, (String[])columns.toArray(SQLiteUtil.EMPTY_STRING_ARRAY)));
/* 274:    */     }
/* 275:231 */     return map;
/* 276:    */   }
/* 277:    */   
/* 278:    */   protected void insertIntoRDOInfo(String name, RDOInfo info)
/* 279:    */     throws RDOException
/* 280:    */   {
/* 281:235 */     SQLiteStatement statement = null;
/* 282:236 */     String insert = "INSERT INTO RDOINFO (NAME, INFODATA) VALUES (?, ?)";
/* 283:    */     try
/* 284:    */     {
/* 285:238 */       this.logger.info(insert);
/* 286:239 */       statement = this.dbManager.getDatabase().compileStatement(insert);
/* 287:    */       
/* 288:    */ 
/* 289:242 */       this.logger.info("bind value for NAME = " + name);
/* 290:243 */       statement.bindString(1, name);
/* 291:    */       
/* 292:245 */       byte[] infoData = convertToBinary(info);
/* 293:246 */       this.logger.info("bind value for INFODATA = " + infoData + " - length: " + infoData.length);
/* 294:247 */       statement.bindBlob(2, infoData);
/* 295:    */       
/* 296:249 */       statement.executeInsert();
/* 297:    */     }
/* 298:    */     catch (Exception e)
/* 299:    */     {
/* 300:251 */       this.logger.error(e.getMessage(), e);
/* 301:252 */       throw new RDOException("rdodefcreatefailed", new Object[] { name }, e);
/* 302:    */     }
/* 303:    */     finally
/* 304:    */     {
/* 305:254 */       SQLiteUtil.safelyCloseStatement(statement, this.logger);
/* 306:    */     }
/* 307:    */   }
/* 308:    */   
/* 309:    */   protected void insertIntoIndexInfo(SQLiteRDOIndexInfo info)
/* 310:    */     throws RDOException
/* 311:    */   {
/* 312:259 */     SQLiteStatement statement = null;
/* 313:260 */     String insert = "INSERT INTO RDOINDEXINFO (NAME, RDONAME, COLNAME, COLORDER) VALUES (?, ?, ?, 'ASC')";
/* 314:261 */     String indexName = info.getIndexName();
/* 315:    */     try
/* 316:    */     {
/* 317:263 */       for (String column : info.getColNames())
/* 318:    */       {
/* 319:264 */         this.logger.info(insert);
/* 320:265 */         statement = this.dbManager.getDatabase().compileStatement(insert);
/* 321:    */         
/* 322:267 */         this.logger.info("bind value for NAME = " + indexName);
/* 323:268 */         statement.bindString(1, indexName);
/* 324:    */         
/* 325:270 */         String rdoName = info.getRDOName();
/* 326:271 */         this.logger.info("bind value for RDONAME = " + rdoName);
/* 327:272 */         statement.bindString(2, rdoName);
/* 328:    */         
/* 329:274 */         this.logger.info("bind value for COLNAME = " + column);
/* 330:275 */         statement.bindString(3, column);
/* 331:    */         
/* 332:277 */         statement.executeInsert();
/* 333:    */       }
/* 334:    */     }
/* 335:    */     catch (Exception e)
/* 336:    */     {
/* 337:280 */       this.logger.error(e.getMessage(), e);
/* 338:281 */       throw new RDOException("rdodefcreateindexfailed", new Object[] { indexName }, e);
/* 339:    */     }
/* 340:    */     finally
/* 341:    */     {
/* 342:283 */       SQLiteUtil.safelyCloseStatement(statement, this.logger);
/* 343:    */     }
/* 344:    */   }
/* 345:    */   
/* 346:    */   private byte[] convertToBinary(RDOInfo info)
/* 347:    */     throws IOException
/* 348:    */   {
/* 349:288 */     ByteArrayOutputStream bos = new ByteArrayOutputStream();
/* 350:289 */     DataOutputStream dos = new DataOutputStream(bos);
/* 351:290 */     RDOInfoSerializer rdoInfoSerializer = new RDOInfoSerializer();
/* 352:291 */     rdoInfoSerializer.writeInstance(dos, info);
/* 353:292 */     dos.flush();
/* 354:293 */     return bos.toByteArray();
/* 355:    */   }
/* 356:    */   
/* 357:    */   private RDOInfo convertToRDOInfo(byte[] data)
/* 358:    */   {
/* 359:297 */     ByteArrayInputStream bis = new ByteArrayInputStream(data);
/* 360:298 */     DataInputStream dis = new DataInputStream(bis);
/* 361:299 */     RDOInfoSerializer rdoInfoSerializer = new RDOInfoSerializer();
/* 362:    */     try
/* 363:    */     {
/* 364:301 */       return (RDOInfo)rdoInfoSerializer.readInstance(dis);
/* 365:    */     }
/* 366:    */     catch (IOException e)
/* 367:    */     {
/* 368:303 */       throw new RuntimeException(e);
/* 369:    */     }
/* 370:    */   }
/* 371:    */   
/* 372:    */   protected String buildCreateIndexStatement(String indexName, String objectName, String... columns)
/* 373:    */   {
/* 374:308 */     String stmt = "CREATE INDEX IF NOT EXISTS %s ON %s (%s)";
/* 375:309 */     StringBuilder columnsWithComma = new StringBuilder();
/* 376:310 */     if (columns.length == 0) {
/* 377:311 */       throw new IllegalArgumentException("Must have at least one column");
/* 378:    */     }
/* 379:312 */     for (String column : columns)
/* 380:    */     {
/* 381:313 */       columnsWithComma.append(format(column));
/* 382:314 */       columnsWithComma.append(",");
/* 383:    */     }
/* 384:316 */     columnsWithComma.deleteCharAt(columnsWithComma.length() - 1);
/* 385:317 */     return String.format(stmt, new Object[] { format(indexName), format(objectName), columnsWithComma });
/* 386:    */   }
/* 387:    */   
/* 388:    */   protected String buildDropIndexStatement(String indexName)
/* 389:    */   {
/* 390:321 */     return String.format("DROP INDEX %s", new Object[] { format(indexName) });
/* 391:    */   }
/* 392:    */   
/* 393:    */   public RDOInfo getInfo(String name)
/* 394:    */   {
/* 395:326 */     RDOInfo info = null;
/* 396:327 */     if (this.rdoInfoMap.containsKey(name))
/* 397:    */     {
/* 398:328 */       info = (RDOInfo)this.rdoInfoMap.get(name);
/* 399:    */     }
/* 400:    */     else
/* 401:    */     {
/* 402:330 */       info = loadRDOInfo(name);
/* 403:331 */       this.rdoInfoMap.put(name, info);
/* 404:    */     }
/* 405:333 */     return info;
/* 406:    */   }
/* 407:    */   
/* 408:    */   protected List<RDOInfo> loadRDOInfos(String filterForNameOrNull)
/* 409:    */   {
/* 410:337 */     Cursor cursor = null;
/* 411:    */     try
/* 412:    */     {
/* 413:339 */       String query = "SELECT INFODATA FROM RDOINFO";
/* 414:340 */       if (filterForNameOrNull != null) {
/* 415:341 */         query = query + " WHERE NAME=?";
/* 416:    */       }
/* 417:343 */       this.logger.info(query);
/* 418:344 */       if (filterForNameOrNull != null) {
/* 419:345 */         this.logger.info("bind value for NAME = " + filterForNameOrNull);
/* 420:    */       }
/* 421:347 */       cursor = this.dbManager.getDatabase().rawQuery(query, new String[] { filterForNameOrNull == null ? SQLiteUtil.EMPTY_STRING_ARRAY : filterForNameOrNull });
/* 422:348 */       List<RDOInfo> result = new ArrayList();
/* 423:    */       byte[] b;
/* 424:349 */       while (cursor.moveToNext())
/* 425:    */       {
/* 426:350 */         b = cursor.getBlob(0);
/* 427:351 */         if (b != null) {
/* 428:352 */           result.add(convertToRDOInfo(b));
/* 429:    */         }
/* 430:    */       }
/* 431:355 */       return result;
/* 432:    */     }
/* 433:    */     catch (Exception e)
/* 434:    */     {
/* 435:357 */       this.logger.error(e.getMessage(), e);
/* 436:358 */       throw new RuntimeException(e);
/* 437:    */     }
/* 438:    */     finally
/* 439:    */     {
/* 440:360 */       SQLiteUtil.safelyCloseCursor(cursor, this.logger);
/* 441:    */     }
/* 442:    */   }
/* 443:    */   
/* 444:    */   protected RDOInfo loadRDOInfo(String name)
/* 445:    */   {
/* 446:365 */     List<RDOInfo> result = loadRDOInfos(name);
/* 447:366 */     return result.isEmpty() ? null : (RDOInfo)result.get(0);
/* 448:    */   }
/* 449:    */   
/* 450:    */   public boolean infoExists(String name)
/* 451:    */   {
/* 452:371 */     return getInfo(name) != null;
/* 453:    */   }
/* 454:    */   
/* 455:    */   public Enumeration<RDOInfo> getAllInfo()
/* 456:    */   {
/* 457:376 */     List<RDOInfo> infos = loadRDOInfos(null);
/* 458:377 */     for (RDOInfo rdoInfo : infos) {
/* 459:378 */       if (!this.rdoInfoMap.containsKey(rdoInfo.getName())) {
/* 460:379 */         registerInCache(rdoInfo.getName(), rdoInfo);
/* 461:    */       }
/* 462:    */     }
/* 463:382 */     Vector<RDOInfo> v = new Vector();
/* 464:383 */     v.addAll(this.rdoInfoMap.values());
/* 465:384 */     return v.elements();
/* 466:    */   }
/* 467:    */   
/* 468:    */   public Enumeration<String> getAllNames()
/* 469:    */   {
/* 470:389 */     Cursor cursor = null;
/* 471:390 */     Vector<String> names = new Vector();
/* 472:    */     try
/* 473:    */     {
/* 474:392 */       String query = "SELECT NAME FROM RDOINFO";
/* 475:393 */       this.logger.info(query);
/* 476:394 */       cursor = this.dbManager.getDatabase().rawQuery(query, SQLiteUtil.EMPTY_STRING_ARRAY);
/* 477:395 */       while (cursor.moveToNext()) {
/* 478:396 */         names.add(cursor.getString(0));
/* 479:    */       }
/* 480:398 */       return names.elements();
/* 481:    */     }
/* 482:    */     catch (Exception e)
/* 483:    */     {
/* 484:400 */       this.logger.error(e.getMessage(), e);
/* 485:401 */       throw new RuntimeException(e);
/* 486:    */     }
/* 487:    */     finally
/* 488:    */     {
/* 489:403 */       SQLiteUtil.safelyCloseCursor(cursor, this.logger);
/* 490:    */     }
/* 491:    */   }
/* 492:    */   
/* 493:    */   public void removeInfo(String name)
/* 494:    */     throws RDOException
/* 495:    */   {
/* 496:409 */     deleteFromRDOInfo(name);
/* 497:410 */     dropTable(name);
/* 498:411 */     removeFromCache(name);
/* 499:    */   }
/* 500:    */   
/* 501:    */   protected void dropTable(String name)
/* 502:    */     throws RDOException
/* 503:    */   {
/* 504:415 */     String statement = buildDropTableStatement(name);
/* 505:416 */     this.logger.info(statement);
/* 506:    */     try
/* 507:    */     {
/* 508:418 */       this.dbManager.getDatabase().execSQL(statement);
/* 509:    */     }
/* 510:    */     catch (Exception e)
/* 511:    */     {
/* 512:420 */       this.logger.error(e.getMessage(), e);
/* 513:421 */       throw new RDOException("rdoremoveinfofailed", new Object[] { name }, e);
/* 514:    */     }
/* 515:    */   }
/* 516:    */   
/* 517:    */   protected String buildDropTableStatement(String name)
/* 518:    */   {
/* 519:426 */     return String.format("DROP TABLE IF EXISTS %s", new Object[] { format(name) });
/* 520:    */   }
/* 521:    */   
/* 522:    */   protected void deleteFromRDOInfo(String name)
/* 523:    */     throws RDOException
/* 524:    */   {
/* 525:430 */     SQLiteStatement statement = null;
/* 526:    */     try
/* 527:    */     {
/* 528:432 */       String delete = "DELETE FROM RDOINFO WHERE NAME = ?";
/* 529:433 */       this.logger.info(delete);
/* 530:434 */       statement = this.dbManager.getDatabase().compileStatement(delete);
/* 531:435 */       this.logger.info("bind value for NAME = " + name);
/* 532:436 */       statement.bindString(1, name);
/* 533:437 */       statement.execute();
/* 534:438 */       this.logger.info("delete count:" + this.dbManager.getAffectedRecordsCount());
/* 535:    */     }
/* 536:    */     catch (Exception e)
/* 537:    */     {
/* 538:440 */       this.logger.error(e.getMessage(), e);
/* 539:441 */       throw new RDOException("rdoremoveinfofailed", new Object[] { name }, e);
/* 540:    */     }
/* 541:    */     finally
/* 542:    */     {
/* 543:443 */       SQLiteUtil.safelyCloseStatement(statement, this.logger);
/* 544:    */     }
/* 545:    */   }
/* 546:    */   
/* 547:    */   protected void removeFromCache(String name)
/* 548:    */   {
/* 549:449 */     this.rdoInfoMap.remove(name);
/* 550:    */   }
/* 551:    */   
/* 552:    */   public void removeAll()
/* 553:    */     throws RDOException
/* 554:    */   {
/* 555:    */     try
/* 556:    */     {
/* 557:455 */       this.dbManager.resetDatabase();
/* 558:    */     }
/* 559:    */     catch (RDOException e)
/* 560:    */     {
/* 561:457 */       this.logger.warn("Could not reset database.", e);
/* 562:458 */       Enumeration<String> names = getAllNames();
/* 563:459 */       while (names.hasMoreElements()) {
/* 564:460 */         removeInfo((String)names.nextElement());
/* 565:    */       }
/* 566:    */     }
/* 567:    */   }
/* 568:    */   
/* 569:    */   public void release()
/* 570:    */     throws RDOException
/* 571:    */   {
/* 572:467 */     this.dbManager.getDatabase().close();
/* 573:    */   }
/* 574:    */   
/* 575:    */   public void createIndex(String indexName, String rdoName, String[] colNames)
/* 576:    */     throws RDOException
/* 577:    */   {
/* 578:472 */     createIndex(indexName, rdoName, colNames, true);
/* 579:    */   }
/* 580:    */   
/* 581:    */   public void createIndex(String indexName, String rdoName, String[] colNames, boolean userDefined)
/* 582:    */     throws RDOException
/* 583:    */   {
/* 584:476 */     createIndexSafely(indexName, rdoName, colNames, userDefined);
/* 585:    */   }
/* 586:    */   
/* 587:    */   public Vector<String> getIndexNames()
/* 588:    */     throws RDOException
/* 589:    */   {
/* 590:481 */     if (this.rdoIndexMap.isEmpty()) {
/* 591:482 */       loadIndexCache();
/* 592:    */     }
/* 593:484 */     Vector<String> list = new Vector();
/* 594:485 */     list.addAll(this.rdoIndexMap.keySet());
/* 595:486 */     return list;
/* 596:    */   }
/* 597:    */   
/* 598:    */   public void dropIndex(String indexName)
/* 599:    */     throws RDOException
/* 600:    */   {
/* 601:491 */     if (indexInfoExistsInCache(indexName))
/* 602:    */     {
/* 603:492 */       doIndexRemoval(indexName);
/* 604:493 */       deleteFromRDOIndexInfo(indexName);
/* 605:494 */       removeFromIndexCache(indexName);
/* 606:    */     }
/* 607:    */   }
/* 608:    */   
/* 609:    */   protected void doIndexRemoval(String indexName)
/* 610:    */     throws RDOException
/* 611:    */   {
/* 612:499 */     String statement = buildDropIndexStatement(indexName);
/* 613:500 */     this.logger.info(statement);
/* 614:    */     try
/* 615:    */     {
/* 616:502 */       this.dbManager.getDatabase().execSQL(statement);
/* 617:    */     }
/* 618:    */     catch (Exception e)
/* 619:    */     {
/* 620:504 */       this.logger.error(e.getMessage(), e);
/* 621:505 */       throw new RDOException("rdodefdropindexfailed", new Object[] { indexName }, e);
/* 622:    */     }
/* 623:    */   }
/* 624:    */   
/* 625:    */   protected void removeFromIndexCache(String indexName)
/* 626:    */   {
/* 627:511 */     this.rdoIndexMap.remove(indexName);
/* 628:    */   }
/* 629:    */   
/* 630:    */   protected void deleteFromRDOIndexInfo(String indexName)
/* 631:    */     throws RDOException
/* 632:    */   {
/* 633:515 */     SQLiteStatement statement = null;
/* 634:    */     try
/* 635:    */     {
/* 636:517 */       String delete = "DELETE FROM RDOINDEXINFO WHERE NAME = ?";
/* 637:518 */       this.logger.info(delete);
/* 638:519 */       statement = this.dbManager.getDatabase().compileStatement(delete);
/* 639:520 */       this.logger.info("bind value for NAME = " + indexName);
/* 640:521 */       statement.bindString(1, indexName);
/* 641:522 */       statement.execute();
/* 642:523 */       this.logger.info("delete count:" + this.dbManager.getAffectedRecordsCount());
/* 643:    */     }
/* 644:    */     catch (Exception e)
/* 645:    */     {
/* 646:525 */       this.logger.error(e.getMessage(), e);
/* 647:526 */       throw new RDOException("rdodefdropindexfailed", new Object[] { indexName }, e);
/* 648:    */     }
/* 649:    */     finally
/* 650:    */     {
/* 651:528 */       SQLiteUtil.safelyCloseStatement(statement, this.logger);
/* 652:    */     }
/* 653:    */   }
/* 654:    */   
/* 655:    */   protected String format(String name)
/* 656:    */   {
/* 657:533 */     return "\"" + name + "\"";
/* 658:    */   }
/* 659:    */   
/* 660:    */   protected String getSQLDataType(int dataType, int length, int scale)
/* 661:    */   {
/* 662:537 */     String dataTypeS = "VARCHAR";
/* 663:538 */     switch (dataType)
/* 664:    */     {
/* 665:    */     case 1: 
/* 666:    */     case 2: 
/* 667:    */     case 3: 
/* 668:542 */       length *= 3;
/* 669:543 */       dataTypeS = "VARCHAR(" + (length > 16398 ? 16398 : length) + ")";
/* 670:544 */       break;
/* 671:    */     case 4: 
/* 672:546 */       dataTypeS = "INTEGER";
/* 673:547 */       break;
/* 674:    */     case 5: 
/* 675:549 */       if (length >= 31) {
/* 676:550 */         length = 31;
/* 677:    */       }
/* 678:552 */       dataTypeS = "DECIMAL(" + length + ",0)";
/* 679:553 */       break;
/* 680:    */     case 6: 
/* 681:    */     case 7: 
/* 682:556 */       if (length >= 31) {
/* 683:557 */         length = 31;
/* 684:    */       }
/* 685:559 */       dataTypeS = "DECIMAL(" + length + "," + scale + ")";
/* 686:560 */       break;
/* 687:    */     case 8: 
/* 688:562 */       dataTypeS = "INTEGER";
/* 689:563 */       break;
/* 690:    */     case 9: 
/* 691:565 */       dataTypeS = "DATE";
/* 692:566 */       break;
/* 693:    */     case 10: 
/* 694:568 */       dataTypeS = "DATETIME";
/* 695:569 */       break;
/* 696:    */     case 11: 
/* 697:571 */       dataTypeS = "DATETIME";
/* 698:572 */       break;
/* 699:    */     case 12: 
/* 700:574 */       dataTypeS = "BLOB";
/* 701:575 */       break;
/* 702:    */     }
/* 703:579 */     return dataTypeS;
/* 704:    */   }
/* 705:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.ibm.tivoli.maximo.mobile.android.persist.sqlite.SQLiteDBRDOInfoManager
 * JD-Core Version:    0.7.0.1
 */