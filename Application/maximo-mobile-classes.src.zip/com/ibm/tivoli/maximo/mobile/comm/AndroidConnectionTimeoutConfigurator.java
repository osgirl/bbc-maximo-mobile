/*  1:   */ package com.ibm.tivoli.maximo.mobile.comm;
/*  2:   */ 
/*  3:   */ import android.util.Log;
/*  4:   */ import com.mro.mobile.app.AbstractMobileDeviceApplication;
/*  5:   */ import com.mro.mobile.app.MobileDeviceAppSession;
/*  6:   */ import com.mro.mobile.comm.ConnectionTimeoutConfigurator;
/*  7:   */ import java.net.HttpURLConnection;
/*  8:   */ 
/*  9:   */ public class AndroidConnectionTimeoutConfigurator
/* 10:   */   implements ConnectionTimeoutConfigurator
/* 11:   */ {
/* 12:   */   public static final int DEFAULT_CONNECT_TIMEOUT = 20000;
/* 13:   */   public static final int DEFAULT_READ_TIMEOUT = 60000;
/* 14:16 */   private int connectTimeout = 20000;
/* 15:17 */   private int readTimeout = 60000;
/* 16:   */   
/* 17:   */   public AndroidConnectionTimeoutConfigurator()
/* 18:   */   {
/* 19:20 */     AbstractMobileDeviceApplication application = MobileDeviceAppSession.getSession().getApplication();
/* 20:   */     try
/* 21:   */     {
/* 22:23 */       this.connectTimeout = Integer.parseInt(application.getSystemProperty("maximo.mobile.android.connection.connecttimeout"));
/* 23:   */     }
/* 24:   */     catch (NumberFormatException e)
/* 25:   */     {
/* 26:25 */       Log.e("MAXIMO_MOBILE", "Failed to int parse property [maximo.mobile.android.connection.connecttimeout]");
/* 27:   */     }
/* 28:   */     try
/* 29:   */     {
/* 30:29 */       this.readTimeout = Integer.parseInt(application.getSystemProperty("maximo.mobile.android.connection.readtimeout"));
/* 31:   */     }
/* 32:   */     catch (NumberFormatException e)
/* 33:   */     {
/* 34:31 */       Log.e("MAXIMO_MOBILE", "Failed to int parse property [maximo.mobile.android.connection.readtimeout]");
/* 35:   */     }
/* 36:   */   }
/* 37:   */   
/* 38:   */   public void setupConnectionTimeoutSetttings(HttpURLConnection connection)
/* 39:   */   {
/* 40:36 */     connection.setConnectTimeout(this.connectTimeout);
/* 41:37 */     connection.setReadTimeout(this.readTimeout);
/* 42:   */   }
/* 43:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.ibm.tivoli.maximo.mobile.comm.AndroidConnectionTimeoutConfigurator
 * JD-Core Version:    0.7.0.1
 */