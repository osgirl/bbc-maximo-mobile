/*  1:   */ package com.ibm.tivoli.maximo.util.mboadapter;
/*  2:   */ 
/*  3:   */ import java.util.Iterator;
/*  4:   */ import java.util.Vector;
/*  5:   */ 
/*  6:   */ public abstract class MboSetAdapterBase
/*  7:   */   implements MboSetAdapter
/*  8:   */ {
/*  9:   */   public MboAdapter[] getMbosByAttribValues(String[][] attributeValues)
/* 10:   */     throws Exception
/* 11:   */   {
/* 12:31 */     Vector retval = new Vector();
/* 13:   */     
/* 14:33 */     Iterator it = iterator();
/* 15:34 */     while (it.hasNext())
/* 16:   */     {
/* 17:36 */       MboAdapter mbo = (MboAdapter)it.next();
/* 18:37 */       boolean found = true;
/* 19:38 */       for (int i = 0; i < attributeValues.length; i++)
/* 20:   */       {
/* 21:40 */         String attr = attributeValues[i][0];
/* 22:41 */         String oneValue = attributeValues[i][1];
/* 23:42 */         String anotherValue = mbo.getString(attr);
/* 24:43 */         if (((oneValue == null) && (anotherValue != null)) || ((oneValue != null) && (!oneValue.equals(anotherValue))))
/* 25:   */         {
/* 26:45 */           found = false;
/* 27:46 */           break;
/* 28:   */         }
/* 29:   */       }
/* 30:50 */       if (found) {
/* 31:51 */         retval.add(mbo);
/* 32:   */       }
/* 33:   */     }
/* 34:54 */     return (MboAdapter[])retval.toArray(new MboAdapter[0]);
/* 35:   */   }
/* 36:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.ibm.tivoli.maximo.util.mboadapter.MboSetAdapterBase
 * JD-Core Version:    0.7.0.1
 */