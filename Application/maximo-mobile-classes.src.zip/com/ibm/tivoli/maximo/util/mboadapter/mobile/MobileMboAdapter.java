/*   1:    */ package com.ibm.tivoli.maximo.util.mboadapter.mobile;
/*   2:    */ 
/*   3:    */ import com.ibm.tivoli.maximo.util.mboadapter.MboAdapter;
/*   4:    */ import com.ibm.tivoli.maximo.util.mboadapter.MboAdapterConstants;
/*   5:    */ import com.ibm.tivoli.maximo.util.mboadapter.MboSetAdapter;
/*   6:    */ import com.mro.mobile.MobileApplicationException;
/*   7:    */ import com.mro.mobile.mbo.MobileMbo;
/*   8:    */ import com.mro.mobile.ui.MobileMboDataBean;
/*   9:    */ import com.mro.mobile.ui.res.UIUtil;
/*  10:    */ import com.mro.mobileapp.WOApp;
/*  11:    */ import java.util.Date;
/*  12:    */ 
/*  13:    */ public class MobileMboAdapter
/*  14:    */   implements MboAdapter, MboAdapterConstants
/*  15:    */ {
/*  16:    */   MobileMbo mbo;
/*  17:    */   MobileMboDataBean databean;
/*  18:    */   
/*  19:    */   public MobileMboAdapter(MobileMbo mbo, MobileMboDataBean databean)
/*  20:    */   {
/*  21: 42 */     if ((mbo == null) || (databean == null)) {
/*  22: 43 */       throw new IllegalArgumentException("mbo=" + mbo + ", databean=" + databean);
/*  23:    */     }
/*  24: 45 */     this.mbo = mbo;
/*  25: 46 */     this.databean = databean;
/*  26:    */   }
/*  27:    */   
/*  28:    */   public MobileMbo getMbo()
/*  29:    */   {
/*  30: 50 */     return this.mbo;
/*  31:    */   }
/*  32:    */   
/*  33:    */   public MobileMboDataBean getDatabean()
/*  34:    */   {
/*  35: 54 */     return this.databean;
/*  36:    */   }
/*  37:    */   
/*  38:    */   public void setValue(String attributeName, String value)
/*  39:    */     throws MobileApplicationException
/*  40:    */   {
/*  41: 64 */     setValue(attributeName, value, 0L);
/*  42:    */   }
/*  43:    */   
/*  44:    */   public void setValue(String attributeName, String value, long flags)
/*  45:    */     throws MobileApplicationException
/*  46:    */   {
/*  47: 68 */     this.mbo.setValue(attributeName, value, isAccessCheck(flags));
/*  48:    */   }
/*  49:    */   
/*  50:    */   public void setValue(String attributeName, boolean value)
/*  51:    */     throws MobileApplicationException
/*  52:    */   {
/*  53: 72 */     setValue(attributeName, value, 0L);
/*  54:    */   }
/*  55:    */   
/*  56:    */   public void setValue(String attributeName, boolean value, long flags)
/*  57:    */     throws MobileApplicationException
/*  58:    */   {
/*  59: 76 */     this.mbo.setBooleanValue(attributeName, value, isAccessCheck(flags));
/*  60:    */   }
/*  61:    */   
/*  62:    */   public void setValueIfDifferent(String attributeName, boolean value)
/*  63:    */     throws MobileApplicationException
/*  64:    */   {
/*  65: 80 */     setValueIfDifferent(attributeName, value, 0L);
/*  66:    */   }
/*  67:    */   
/*  68:    */   public void setValueIfDifferent(String attributeName, boolean value, long flags)
/*  69:    */     throws MobileApplicationException
/*  70:    */   {
/*  71: 84 */     if (getBoolean(attributeName) != value) {
/*  72: 85 */       setValue(attributeName, value, flags);
/*  73:    */     }
/*  74:    */   }
/*  75:    */   
/*  76:    */   public void setValue(String attributeName, int value)
/*  77:    */     throws MobileApplicationException
/*  78:    */   {
/*  79: 90 */     setValue(attributeName, value, 0L);
/*  80:    */   }
/*  81:    */   
/*  82:    */   public void setValue(String attributeName, int value, long flags)
/*  83:    */     throws MobileApplicationException
/*  84:    */   {
/*  85: 94 */     this.mbo.setIntValue(attributeName, value, isAccessCheck(flags));
/*  86:    */   }
/*  87:    */   
/*  88:    */   public void setValue(String attributeName, Date value)
/*  89:    */     throws MobileApplicationException
/*  90:    */   {
/*  91: 98 */     setValue(attributeName, value, 0L);
/*  92:    */   }
/*  93:    */   
/*  94:    */   public void setValue(String attributeName, Date value, long flags)
/*  95:    */     throws MobileApplicationException
/*  96:    */   {
/*  97:102 */     this.mbo.setDateValue(attributeName, value, isAccessCheck(flags));
/*  98:    */   }
/*  99:    */   
/* 100:    */   protected boolean isAccessCheck(long flags)
/* 101:    */   {
/* 102:114 */     return (flags & 0x2) != 2L;
/* 103:    */   }
/* 104:    */   
/* 105:    */   public String getString(String attributeName)
/* 106:    */     throws MobileApplicationException
/* 107:    */   {
/* 108:120 */     return this.mbo.getValue(attributeName);
/* 109:    */   }
/* 110:    */   
/* 111:    */   public boolean getBoolean(String attributeName)
/* 112:    */     throws MobileApplicationException
/* 113:    */   {
/* 114:124 */     return this.mbo.getBooleanValue(attributeName);
/* 115:    */   }
/* 116:    */   
/* 117:    */   public int getInt(String attributeName)
/* 118:    */     throws MobileApplicationException
/* 119:    */   {
/* 120:128 */     return this.mbo.getIntValue(attributeName);
/* 121:    */   }
/* 122:    */   
/* 123:    */   public Date getDate(String attributeName)
/* 124:    */     throws MobileApplicationException
/* 125:    */   {
/* 126:132 */     return this.mbo.getDateValue(attributeName);
/* 127:    */   }
/* 128:    */   
/* 129:    */   public MboSetAdapter getMboSet(String relationshipName)
/* 130:    */     throws MobileApplicationException
/* 131:    */   {
/* 132:138 */     int index = getMboPositionInDatabean(this.mbo, this.databean);
/* 133:139 */     MobileMboDataBean newdatabean = this.databean.getDataBean(index, relationshipName);
/* 134:140 */     return new MobileMboSetAdapter(newdatabean);
/* 135:    */   }
/* 136:    */   
/* 137:    */   public MboSetAdapter getThisMboSet()
/* 138:    */     throws Exception
/* 139:    */   {
/* 140:144 */     return new MobileMboSetAdapter(this.databean);
/* 141:    */   }
/* 142:    */   
/* 143:    */   public boolean isNull(String attributeName)
/* 144:    */     throws MobileApplicationException
/* 145:    */   {
/* 146:148 */     return this.mbo.isNull(attributeName);
/* 147:    */   }
/* 148:    */   
/* 149:    */   public boolean isReadOnly(String attributeName)
/* 150:    */     throws MobileApplicationException
/* 151:    */   {
/* 152:152 */     return this.mbo.isReadOnly(attributeName);
/* 153:    */   }
/* 154:    */   
/* 155:    */   public void setReadOnly(String attributeName, boolean readOnly)
/* 156:    */   {
/* 157:156 */     this.mbo.setReadOnly(attributeName, readOnly);
/* 158:    */   }
/* 159:    */   
/* 160:    */   public String getName()
/* 161:    */   {
/* 162:160 */     return this.mbo.getName();
/* 163:    */   }
/* 164:    */   
/* 165:    */   public Exception newApplicationException(String group, String key, Object[] params)
/* 166:    */   {
/* 167:167 */     return new MobileApplicationException(group + "_" + key, params);
/* 168:    */   }
/* 169:    */   
/* 170:    */   public Exception newApplicationException(String group, String key)
/* 171:    */   {
/* 172:174 */     return newApplicationException(group, key, null);
/* 173:    */   }
/* 174:    */   
/* 175:    */   protected int getMboPositionInDatabean(MobileMbo mbo, MobileMboDataBean databean)
/* 176:    */     throws MobileApplicationException
/* 177:    */   {
/* 178:185 */     if (databean.getMobileMbo() == mbo) {
/* 179:186 */       return databean.getCurrentPosition();
/* 180:    */     }
/* 181:190 */     for (int i = 0; i < databean.count(); i++) {
/* 182:191 */       if (databean.getMobileMbo(i) == mbo) {
/* 183:192 */         return i;
/* 184:    */       }
/* 185:    */     }
/* 186:196 */     return -1;
/* 187:    */   }
/* 188:    */   
/* 189:    */   public boolean toBeDeleted()
/* 190:    */   {
/* 191:201 */     return false;
/* 192:    */   }
/* 193:    */   
/* 194:    */   public static void wrapException(Exception e)
/* 195:    */     throws MobileApplicationException
/* 196:    */   {
/* 197:214 */     if ((e instanceof MobileApplicationException)) {
/* 198:215 */       throw ((MobileApplicationException)e);
/* 199:    */     }
/* 200:216 */     if ((e instanceof RuntimeException)) {
/* 201:217 */       throw ((RuntimeException)e);
/* 202:    */     }
/* 203:219 */     e.printStackTrace();
/* 204:220 */     throw new MobileApplicationException("internalerror", e);
/* 205:    */   }
/* 206:    */   
/* 207:    */   public boolean getMaxVarBoolean(String maxvarName)
/* 208:    */     throws Exception
/* 209:    */   {
/* 210:226 */     return Integer.parseInt(((WOApp)UIUtil.getApplication()).getMaxVar(this.databean, maxvarName)) != 0;
/* 211:    */   }
/* 212:    */   
/* 213:    */   public int getMaxVarInt(String maxvarName)
/* 214:    */     throws Exception
/* 215:    */   {
/* 216:231 */     return Integer.parseInt(((WOApp)UIUtil.getApplication()).getMaxVar(this.databean, maxvarName));
/* 217:    */   }
/* 218:    */   
/* 219:    */   public String getMaxVarString(String maxvarName)
/* 220:    */     throws Exception
/* 221:    */   {
/* 222:236 */     return ((WOApp)UIUtil.getApplication()).getMaxVar(this.databean, maxvarName);
/* 223:    */   }
/* 224:    */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.ibm.tivoli.maximo.util.mboadapter.mobile.MobileMboAdapter
 * JD-Core Version:    0.7.0.1
 */