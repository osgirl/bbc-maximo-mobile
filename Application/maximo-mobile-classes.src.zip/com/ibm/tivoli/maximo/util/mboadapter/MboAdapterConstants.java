package com.ibm.tivoli.maximo.util.mboadapter;

public abstract interface MboAdapterConstants
{
  public static final long NOADD = 1L;
  public static final long NOUPDATE = 2L;
  public static final long NODELETE = 4L;
  public static final long NOSAVE = 8L;
  public static final long NO_RELATEDMBOS_OF_OWNERSCHILDREN_FETCH = 16L;
  public static final long READONLY = 7L;
  public static final long DISCARDABLE = 39L;
  public static final long REQUIRED = 8L;
  public static final long SAMEVALUEVALIDATION = 16L;
  public static final long USER = 256L;
  public static final long NOVALIDATION = 1L;
  public static final long NOACCESSCHECK = 2L;
  public static final long DELAYVALIDATION = 4L;
  public static final long NOACTION = 8L;
  public static final long NOVALIDATION_AND_NOACTION = 9L;
  public static final long NOSETVALUE = 32L;
  public static final long CHANGEDBY_USER = 16L;
  public static final long NONE = 0L;
  public static final int ALLROWS = 10000000;
  public static final long REBUILD = 1L;
  public static final long NOCOMMIT = 2L;
  public static final int COUNT_DATABASE = 1;
  public static final int COUNT_ADDITIONS = 2;
  public static final int COUNT_DELETED = 4;
  public static final int COUNT_EXISTING = 8;
  public static final int COUNT_AFTERSAVE = 16;
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.ibm.tivoli.maximo.util.mboadapter.MboAdapterConstants
 * JD-Core Version:    0.7.0.1
 */