package com.ibm.tivoli.maximo.util.mboadapter;

import java.util.Iterator;

public abstract interface MboSetAdapter
{
  public abstract MboAdapter getMbo()
    throws Exception;
  
  public abstract MboAdapter getMbo(int paramInt)
    throws Exception;
  
  public abstract int count()
    throws Exception;
  
  public abstract boolean isEmpty()
    throws Exception;
  
  public abstract Iterator iterator();
  
  public abstract MboAdapter[] getMbosByAttribValues(String[][] paramArrayOfString)
    throws Exception;
  
  public abstract void reset()
    throws Exception;
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.ibm.tivoli.maximo.util.mboadapter.MboSetAdapter
 * JD-Core Version:    0.7.0.1
 */