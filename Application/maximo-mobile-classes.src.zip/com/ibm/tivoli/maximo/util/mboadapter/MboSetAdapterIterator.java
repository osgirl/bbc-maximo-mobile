/*  1:   */ package com.ibm.tivoli.maximo.util.mboadapter;
/*  2:   */ 
/*  3:   */ import java.util.Iterator;
/*  4:   */ 
/*  5:   */ public class MboSetAdapterIterator
/*  6:   */   implements Iterator
/*  7:   */ {
/*  8:   */   protected MboSetAdapter mboSet;
/*  9:30 */   protected int pos = 0;
/* 10:   */   
/* 11:   */   public MboSetAdapterIterator(MboSetAdapter mboSet)
/* 12:   */   {
/* 13:33 */     this.mboSet = mboSet;
/* 14:   */   }
/* 15:   */   
/* 16:   */   public boolean hasNext()
/* 17:   */   {
/* 18:   */     try
/* 19:   */     {
/* 20:38 */       return this.mboSet.getMbo(this.pos) != null;
/* 21:   */     }
/* 22:   */     catch (Exception e)
/* 23:   */     {
/* 24:40 */       e.printStackTrace();
/* 25:   */     }
/* 26:42 */     return false;
/* 27:   */   }
/* 28:   */   
/* 29:   */   public Object next()
/* 30:   */   {
/* 31:   */     try
/* 32:   */     {
/* 33:47 */       return this.mboSet.getMbo(this.pos++);
/* 34:   */     }
/* 35:   */     catch (Exception e)
/* 36:   */     {
/* 37:49 */       e.printStackTrace();
/* 38:   */     }
/* 39:51 */     return null;
/* 40:   */   }
/* 41:   */   
/* 42:   */   public void remove()
/* 43:   */   {
/* 44:55 */     throw new UnsupportedOperationException();
/* 45:   */   }
/* 46:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.ibm.tivoli.maximo.util.mboadapter.MboSetAdapterIterator
 * JD-Core Version:    0.7.0.1
 */