/*  1:   */ package com.ibm.tivoli.maximo.util.mboadapter.mobile;
/*  2:   */ 
/*  3:   */ import com.ibm.tivoli.maximo.util.mboadapter.MboAdapter;
/*  4:   */ import com.ibm.tivoli.maximo.util.mboadapter.MboSetAdapter;
/*  5:   */ import com.ibm.tivoli.maximo.util.mboadapter.MboSetAdapterBase;
/*  6:   */ import com.ibm.tivoli.maximo.util.mboadapter.MboSetAdapterIterator;
/*  7:   */ import com.mro.mobile.MobileApplicationException;
/*  8:   */ import com.mro.mobile.mbo.MobileMbo;
/*  9:   */ import com.mro.mobile.ui.MobileMboDataBean;
/* 10:   */ import java.util.Iterator;
/* 11:   */ 
/* 12:   */ public class MobileMboSetAdapter
/* 13:   */   extends MboSetAdapterBase
/* 14:   */   implements MboSetAdapter
/* 15:   */ {
/* 16:   */   MobileMboDataBean databean;
/* 17:   */   
/* 18:   */   public MobileMboSetAdapter(MobileMboDataBean databean)
/* 19:   */   {
/* 20:40 */     this.databean = databean;
/* 21:   */   }
/* 22:   */   
/* 23:   */   public MobileMboDataBean getDataBean()
/* 24:   */   {
/* 25:44 */     return this.databean;
/* 26:   */   }
/* 27:   */   
/* 28:   */   public MboAdapter getMbo()
/* 29:   */     throws MobileApplicationException
/* 30:   */   {
/* 31:48 */     MobileMbo mbo = this.databean.getMobileMbo();
/* 32:49 */     return mbo == null ? null : new MobileMboAdapter(mbo, this.databean);
/* 33:   */   }
/* 34:   */   
/* 35:   */   public MboAdapter getMbo(int index)
/* 36:   */     throws MobileApplicationException
/* 37:   */   {
/* 38:53 */     MobileMbo mbo = this.databean.getMobileMbo(index);
/* 39:54 */     return mbo == null ? null : new MobileMboAdapter(mbo, this.databean);
/* 40:   */   }
/* 41:   */   
/* 42:   */   public int count()
/* 43:   */     throws MobileApplicationException
/* 44:   */   {
/* 45:58 */     return this.databean.count();
/* 46:   */   }
/* 47:   */   
/* 48:   */   public boolean isEmpty()
/* 49:   */     throws MobileApplicationException
/* 50:   */   {
/* 51:62 */     return this.databean.count() <= 0;
/* 52:   */   }
/* 53:   */   
/* 54:   */   public Iterator iterator()
/* 55:   */   {
/* 56:66 */     return new MboSetAdapterIterator(this);
/* 57:   */   }
/* 58:   */   
/* 59:   */   public void reset()
/* 60:   */     throws MobileApplicationException
/* 61:   */   {
/* 62:70 */     this.databean.reset();
/* 63:   */   }
/* 64:   */ }


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.ibm.tivoli.maximo.util.mboadapter.mobile.MobileMboSetAdapter
 * JD-Core Version:    0.7.0.1
 */