package com.ibm.tivoli.maximo.util.mboadapter;

import java.util.Date;

public abstract interface MboAdapter
{
  public abstract MboSetAdapter getMboSet(String paramString)
    throws Exception;
  
  public abstract MboSetAdapter getThisMboSet()
    throws Exception;
  
  public abstract void setValue(String paramString1, String paramString2)
    throws Exception;
  
  public abstract void setValue(String paramString1, String paramString2, long paramLong)
    throws Exception;
  
  public abstract void setValue(String paramString, boolean paramBoolean)
    throws Exception;
  
  public abstract void setValue(String paramString, boolean paramBoolean, long paramLong)
    throws Exception;
  
  public abstract void setValueIfDifferent(String paramString, boolean paramBoolean)
    throws Exception;
  
  public abstract void setValueIfDifferent(String paramString, boolean paramBoolean, long paramLong)
    throws Exception;
  
  public abstract void setValue(String paramString, int paramInt)
    throws Exception;
  
  public abstract void setValue(String paramString, int paramInt, long paramLong)
    throws Exception;
  
  public abstract void setValue(String paramString, Date paramDate)
    throws Exception;
  
  public abstract void setValue(String paramString, Date paramDate, long paramLong)
    throws Exception;
  
  public abstract String getString(String paramString)
    throws Exception;
  
  public abstract boolean getBoolean(String paramString)
    throws Exception;
  
  public abstract int getInt(String paramString)
    throws Exception;
  
  public abstract Date getDate(String paramString)
    throws Exception;
  
  public abstract boolean isNull(String paramString)
    throws Exception;
  
  public abstract boolean isReadOnly(String paramString)
    throws Exception;
  
  public abstract void setReadOnly(String paramString, boolean paramBoolean)
    throws Exception;
  
  public abstract String getName()
    throws Exception;
  
  public abstract Exception newApplicationException(String paramString1, String paramString2, Object[] paramArrayOfObject);
  
  public abstract Exception newApplicationException(String paramString1, String paramString2);
  
  public abstract String getMaxVarString(String paramString)
    throws Exception;
  
  public abstract int getMaxVarInt(String paramString)
    throws Exception;
  
  public abstract boolean getMaxVarBoolean(String paramString)
    throws Exception;
  
  public abstract boolean toBeDeleted();
}


/* Location:           C:\Users\timminsa\Documents\BBC\Code\maximo-mobile-classes\
 * Qualified Name:     com.ibm.tivoli.maximo.util.mboadapter.MboAdapter
 * JD-Core Version:    0.7.0.1
 */